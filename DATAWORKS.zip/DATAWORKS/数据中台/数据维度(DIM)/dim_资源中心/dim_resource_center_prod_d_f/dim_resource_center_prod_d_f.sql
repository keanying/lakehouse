--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-08 10:29:30
--EMR任务只能运行在独享资源组上
--********************************************************************--


-- alter table dim_resource_center_purchase_d_f add columns(supply_type string comment '资源中心供应类型：自动拉取/手动供应');
-- alter table dim_resource_center_purchase_d_f add columns(ticket_name string comment '票名称');
--资源中心产品采购情况表

create table if not exists dim_resource_center_purchase_d_f(
    `supply_user_id`                INT     COMMENT '供应商id',
    `purchase_user_id`              INT     COMMENT '采购商id',
    `ticket_id`                     INT     COMMENT '票id',
    `ticket_fullname`               STRING  COMMENT '票全称',
    `pid`                           INT     COMMENT '产品pid',
    `purchase_time`                 STRING  COMMENT '产品被采购时间',
    `add_time`                      STRING  COMMENT '产品首次上架资源中心时间',
    `max_add_time`                  STRING  COMMENT '产品最新上架资源中心时间',
    `resource_update_time`          STRING  COMMENT '资源中心产品更新时间',
    `off_time`                      STRING  COMMENT '产品下架时间',
    `opid`                          INT     COMMENT '操作员id',
    `price_state`                   STRING  COMMENT '采购价格是否相同',
    `land_id`                       INT     COMMENT '景区id',
    `land_name`                     STRING  COMMENT '景区名称',
    `land_province`                 STRING  COMMENT '景区省',
    `land_city`                     STRING  COMMENT '景区市',
    `land_type_name`                STRING  COMMENT '景区/产品类型',
    `apply_did`                     INT     COMMENT '景区供应商',
    `purchase_distribute_num`       INT     COMMENT '采购者将产品分销下级数',
    `purchase_ota_num`              INT     COMMENT '采购者将产品上架OTA数',
    `ticket_max_expiration_date`    STRING  COMMENT '产品过期时间',
    `resource_product_status`       STRING  COMMENT '资源中心产品状态',
    `product_status`                STRING  COMMENT '产品状态',
    `purchace_status`               STRING  COMMENT '采购状态',
    `is_auto_purchace`              STRING  COMMENT '是否自动采购',

    `ticket_validity`               STRING  COMMENT'票有效性，有效，失效：产品下架/资源中心下架/票过期',
    `purchase_chain_validity`       STRING  COMMENT '票采购链有效性，有效，失效：产品下架/资源中心下架/票过期，采购状态<>已采购',
    `supply_type`                   STRING  COMMENT '资源中心供应类型：自动拉取/手动供应',

    `ticket_name`                   STRING  COMMENT '票名称'

--    purchase_distribute_count INT COMMENT'采购者分销下级次数'
) COMMENT'资源中心面板采购表' PARTITIONED BY(
    `pt` INT
)STORED AS ORC;

----资源中心上架产品相关信息

insert OVERWRITE    table dim_resource_center_purchase_d_f PARTITION (pt="${ds}" )           
SELECT
        a.sid as supply_user_id,
        rp.fid as purchase_user_id,
        a.ticket_id,
        pro.ticket_fullname,
        a.pid,
        from_unixtime(rp.insert_time) as purchase_time,
        re.min_add_time as add_time,
        re.max_add_time as max_add_time,
        from_unixtime(a.update_time) as resource_update_time,
        case 
           when a.status=0 and (pro.ticket_status='下架' or pro.ticket_status='删除') then if(re.max_off_time>from_unixtime(pro.ticket_update_time),from_unixtime(pro.ticket_update_time),re.max_off_time) 
           when a.status=0 then re.max_off_time
           when pro.ticket_status='下架' or pro.ticket_status='删除' then from_unixtime(pro.ticket_update_time)
        end off_time,
        rp.opid,
        case 
            when rp.price_state=1 then '相同' 
            else '不同' 
        end price_state,
        a.lid,
        pro.land_name as land_name,
        pro.land_province,
        pro.land_city,
        l.land_type_name,
        pro.land_publisher_id as apply_did,
        ev.distribute_num as purchase_distribute_num,
        ota.ota_num as purchase_ota_num,
        pro.ticket_max_expiration_date ,
        -----产品下架情况可能出现于正常状态ticket_id重叠情况，原因为pft_resource_product上的不同供应商发布的ticket_id下架
        case 
            when a.status=1 then '上架' 
            else '下架' 
        end resource_product_status,
        case 
            when (pro.ticket_status='上架'  or pro.ticket_status='新增') and pro.land_status='上架' then '上架'      
            when pro.ticket_status!='上架' then '票下架'          
            when pro.land_status!='上架' then '产品下架'           
        end product_status,
        case 
            when rp.status=1 then '已采购' 
            when rp.status=0 then '取消采购'
            else '未采购'  end purchace_status,
        case 
            when b.operation_status=0 then '是' else '否'
        end is_auto_purchace,

        -- 票失效：产品非上架/票非上架（下架/过期/删除...）/资源中心非上架
        case 
           when  pro.ticket_status!='上架' or a.status<>1  then '失效'
           else  '有效'
        end                             as ticket_validity,
        -- 票采购链失效：产品非上架/票非上架（下架/过期/删除...）/资源中心非上架/非已采购
        case 
           when  pro.ticket_status!='上架' or a.status<>1 or rp.status<>1  then '失效'
           else  '有效'
        end                             as purchase_chain_validity,

        l.supply_type         as supply_type,
        pro.ticket_name

FROM     (select   *   from  ods_pft_resource_product_d_f    where  pt="${ds}"   ) a

----关联资源中心产品状态变化表
left join (select sid,pid,
                  max(case when operate_type=0 then record_time end) as max_off_time,
                  min(case when operate_type=0 then record_time end) as min_off_time,
                  max(case when operate_type=1 then record_time end) as max_add_time,
                  min(case when operate_type=1 then record_time end) as min_add_time
           from ods_pft_resource_product_record_d_f 
           where  pt="${ds}"
           group by sid,pid) re   on a.sid=re.sid and a.pid=re.pid 

----关联采购表              
left join   (select * from ods_pft_resource_purchase_d_f  where  pt="${ds}")  rp  on a.ticket_id=rp.ticket_id  and a.sid=rp.sid   and a.pid=rp.pid                         
            
----判断批量采购状态    
LEFT JOIN   (SELECT *  FROM ods_pft_resource_purchase_recode_list_d_f  WHERE  pt="${ds}"   AND `status` = 1   ) b 
            ON rp.sid = b.sid   AND rp.fid = b.fid    AND rp.pid = b.pid      AND rp.ticket_id = b.ticket_id       

----关联产品相关信息         
left join   (select
                ticket_id,
                ticket_name,
                SUBSTR(ticket_fullname, 1, 30)  AS ticket_fullname,
                land_name,
                land_publisher_id,
                land_province,
                land_city,
                ticket_status,
                ticket_update_time,
                land_status,
                ticket_max_expiration_date             
             
             from  dim_prod_d_f              
             where   pt="${ds}"     )  pro   on a.ticket_id=pro.ticket_id    

----关联分销情况   
left join (select supplier_id,ticket_id,distributor_chain,count(distributor_id) distribute_num 
           from  dim_prod_distribute_d_f
           where pt='${ds}'
           group by supplier_id,ticket_id,distributor_chain) ev  on  ev.ticket_id=rp.ticket_id and ev.supplier_id=rp.fid and LOCATE(concat(rp.sid,',',rp.fid),ev.distributor_chain,1)>0
-- 产品上架OTA
left join (select fid,tid,count(distinct DockingMode) ota_num from ods_uu_qunar_use_d_f 
      where pt='${ds}' and itime>'2019-06-01'
      group by fid,tid) ota on ota.fid= rp.sid and ota.tid=rp.ticket_id
----关联景区类型
join (select land_id,land_type_name,supply_type from dim_land_d_f where pt='${ds}') l on l.land_id= a.lid
-- ---删除测试用户(发布商/上架商/采购商 任一为测试用户)
where   -- pro.land_publisher_id IN (SELECT   user_id  FROM  dim_resource_center_user_d_f  where pt="${ds}" )   -- edit by gl 2022-12-16
           pro.land_publisher_id IN (select user_id from dim_user_d_f where  pt="${ds}"  and user_type in ('供应商','分销商') and user_is_test='正式')   
        AND a.sid IN (SELECT  user_id FROM dim_resource_center_user_d_f   where  pt="${ds}"  )
        AND (rp.fid is null or rp.fid in ( SELECT user_id  FROM  dim_resource_center_user_d_f    where  pt="${ds}"));


