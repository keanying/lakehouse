--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-08 10:11:57
--EMR任务只能运行在独享资源组上
--********************************************************************--

create table if NOT EXISTS dim_resource_center_user_d_f(
    stat_date              STRING COMMENT "统计日期",
    dw_ins_time            STRING COMMENT "数据插入日期",

    user_id                INT    COMMENT "用户id",  
    user_account           STRING COMMENT"账号",
    user_type              string comment '账户类型',
    user_name              string comment '账户名称',
    user_company_name      string comment '企业名称',
    user_login_lasttime    string comment '最近登录时间',

    customer_mobile        string comment '手机号',
    customer_type          string comment '用户类型',
    customer_service_hotline string comment '服务热线',
    customer_certi_status  string comment '资质认证',
    customer_province      STRING COMMENT "客户省",
    customer_city          STRING COMMENT "客户市",


    signer                 string comment '签单人',
    enter_status           string COMMENT '入驻状态：0未入驻，1入驻',
    settled_status         string COMMENT  '供货商入驻状态',
    purchase_settled_status  string  COMMENT '采购商入驻状态',
    settled_time           string COMMENT '供货商入驻时间 ',
    purchase_settled_time  string COMMENT '采购商入驻时间 ',
    enter_time             string COMMENT '入驻日期',
    first_begin_time       string COMMENT '开通资源中心第一次开通日期',
    attr_status            string COMMENT '状态: 0:无效,1:有效',
    bond_state             string comment '保证金状态',

    user_open_datav        string COMMENT '开通datav大屏状态：开通/未开通',
    user_bind_taobao       string COMMENT '绑定淘宝状态：绑定/空',
    distribute_system_name string comment '对接分销平台名称'

)COMMENT'开通资源中心商户表'PARTITIONED BY(
    pt INT  
 )STORED AS ORC;



-- 开通资源中心商户（过滤 员工账号、测试账号）
INSERT OVERWRITE TABLE dim_resource_center_user_d_f PARTITION (pt="${ds}") 
select /*+mapjoin(tu,m1,m2,c,s)*/
    ${ds}     as stat_date,
    current_date              as dw_ins_time,

    rm1.sid                                 as user_id,
    m.user_account                          as user_account,
    m.user_type                             as user_type,
    m.user_name                             as user_name,
    m.user_company_name                     as user_company_name,
    m.user_login_lasttime                   as user_login_lasttime,

    m.customer_mobile                       as customer_mobile,
    m.customer_type                         as customer_type,
    case 
         when locate('hotline',rm1.attr_expand,1)>0 and locate('","',rm1.attr_expand,1)<=0  then substr(rm1.attr_expand,13,locate('}',rm1.attr_expand,1)-14)
         when locate('hotline',rm1.attr_expand,1)>0 and locate('","',rm1.attr_expand,1)>0   then substr(rm1.attr_expand,13,locate('","',rm1.attr_expand,1)-13)
         else NULL 
    end                                    as customer_service_hotline,
    m.customer_certi_status                 as customer_certi_status,
    m.customer_province                     as customer_province,
    m.customer_city                         as customer_city,

    m.signer                                as signer,
    case 
         when rm1.settled_time>0 or rm1.purchase_settled_time>0   then '入驻'
         else '未入驻'
    end                                     as enter_status,
    case rm1.settled_time 
         when 0 then '未入驻'
         else '入驻' 
    end                                     as settled_status,
    case  rm1.purchase_settled_time  
         when 0 then '未入驻'
         else '入驻' 
         end                               as purchase_settled_status,   
    if(rm2.settled_time>0,from_unixtime(rm2.settled_time,"yyyy-MM-dd"),null)                   as settled_time,
    if(rm2.purchase_settled_time>0,from_unixtime(rm2.purchase_settled_time,"yyyy-MM-dd"),null) as purchase_settled_time,
    case 
        when  rm1.settled_time>0 and rm1.purchase_settled_time>0 and rm1.settled_time<rm1.purchase_settled_time then from_unixtime(rm1.purchase_settled_time,"yyyy-MM-dd")
        when  rm1.settled_time>0 and rm1.purchase_settled_time>0 and rm1.settled_time>=rm1.purchase_settled_time then from_unixtime(rm1.settled_time,"yyyy-MM-dd") 
        when  rm1.settled_time>0 and rm1.purchase_settled_time=0 then from_unixtime(rm1.settled_time,"yyyy-MM-dd")  
        when  rm1.settled_time=0 and rm1.purchase_settled_time>0 then from_unixtime(rm1.purchase_settled_time,"yyyy-MM-dd")
        when  fi.first_time>0 then from_unixtime(fi.first_time,"yyyy-MM-dd") 

        -- when fi.first_time>0 and rm1.settled_time=0 and rm1.purchase_settled_time=0 then from_unixtime(fi.first_time,"yyyy-MM-dd hh:mm:ss") 
        -- when fi.first_time>0 and rm1.settled_time=0 and rm1.purchase_settled_time>0 then from_unixtime(if(fi.first_time<rm1.purchase_settled_time,fi.first_time,rm1.purchase_settled_time),"yyyy-MM-dd hh:mm:ss") 
        -- when fi.first_time>0 and rm1.settled_time>0 and rm1.purchase_settled_time=0 then from_unixtime(if(fi.first_time<rm1.settled_time,fi.first_time,rm1.settled_time),"yyyy-MM-dd hh:mm:ss") 
        -- when fi.first_time=0 and rm1.settled_time>0 and rm1.purchase_settled_time>0 then from_unixtime(if(rm1.settled_time<rm1.purchase_settled_time,rm1.settled_time,rm1.purchase_settled_time),"yyyy-MM-dd hh:mm:ss")
        -- when fi.first_time<rm1.settled_time and fi.first_time<rm1.purchase_settled_time then from_unixtime(fi.first_time,"yyyy-MM-dd hh:mm:ss") 
        -- when rm1.settled_time<fi.first_time and rm1.settled_time<rm1.purchase_settled_time then from_unixtime(rm1.settled_time,"yyyy-MM-dd hh:mm:ss") 
        -- when rm1.purchase_settled_time<fi.first_time and rm1.purchase_settled_time<rm1.settled_time then from_unixtime(rm1.purchase_settled_time,"yyyy-MM-dd hh:mm:ss") 
    end enter_time,
    from_unixtime(rm1.create_time,"yyyy-MM-dd hh:mm:ss")                         as first_begin_time,
    case rm1.attr_state
        when 0 then '无效'
        when 1 then '有效'
        else '未知'
    end                                     as attr_status,
    case rm1.bond_sate 
        when 0 then '未缴纳'
        when 1 then '已缴纳'
        when 2 then '部分缴纳' 
        else '未知' 
    end                                     as bond_state,

    m.user_open_datav                       as user_open_datav,
    m.user_bind_taobao                      as user_bind_taobao,
    m.distribute_system_name                as distribute_system_name

from (select sid,create_time,attr_state,attr_expand,attr_state,settled_state,settled_time,bond_sate,purchase_settled_time
      from ods_myuu_pft_resource_supplier_attr_d_f
      where pt='${ds}'
      ) rm1
-- left join (SELECT user_id,module_begin_time,module_end_time 
--            from data_middle_bi.dim_user_module_d_f
--                    where pt="${ds}" AND module_id=57 and module_end_time>=current_date              --应用中心.资源中心模块有效
--            ) mu  on rm1.sid=mu.user_id
join (select user_id,user_is_test,user_open_datav,user_company_name,user_name,customer_mobile,user_type,user_account,
             user_login_lasttime,signer,customer_certi_status,customer_type,user_bind_taobao,customer_province,customer_city,distribute_system_name
      from dim_user_d_f 
      where pt="${ds}" and user_type in ('供应商','分销商') and user_is_test='正式') as m on m.user_id=rm1.sid
-- 入驻时间      
left join (select sid,min(add_time) first_time  from ods_pft_resource_user_function_d_f where pt="${ds}" group by sid) as fi on fi.sid=rm1.sid
LEFT JOIN (select sid,create_time,attr_state,attr_expand,attr_state,settled_state,settled_time,bond_sate,purchase_settled_time from ods_myuu_pft_resource_supplier_attr_d_f 
           where pt = '${ds}' ) rm2 on rm1.sid=rm2.sid
;

-- SELECT user_id,enter_status,enter_time
-- from dim_resource_center_user_d_f
-- where  pt="${ds}"



-- 永久开通资源中心功能模块+ 限时开通应用中心.资源中心模块
-- select rm.member_id  member_id,min(rm.create_time) create_time
--       from 
--             (-- 开通‘资源中心’功能模块
--               select r.member_id,from_unixtime(rmenu.create_time) create_time 
--               from (select role_id,create_time from data_middle_bi.ods_pft_authority_role_menu_relation_d_f 
--                     where pt="${ds}" AND is_deleted=0 and menu_tag='resource_center'
--                             and FROM_UNIXTIME(create_time)>='2019-06-01 00:00:00' ) as rmenu
--               join (select role_id,member_id from data_middle_bi.s_pft001_pft_authority_role_member_relation_d_f
--                     where pt="${ds}" ) as r on r.role_id=rmenu.role_id 
              
--               UNION 
--               -- 应用中心开通‘资源中心’模块
--               SELECT member_id,FROM_UNIXTIME(create_time) create_time 
--               from data_middle_bi.s_pft001_pft_module_used_d_f
--                     where pt="${ds}" AND module_id=57 and FROM_UNIXTIME(expire_time)>current_date              --应用中心.资源中心模块有效
--               ) rm
--       group by rm.member_id