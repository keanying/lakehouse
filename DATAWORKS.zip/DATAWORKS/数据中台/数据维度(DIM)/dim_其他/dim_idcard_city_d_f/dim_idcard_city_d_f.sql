--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-05 14:24:53
--EMR任务只能运行在独享资源组上
--********************************************************************--

CREATE TABLE IF NOT EXISTS dim_idcard_city_d_f(
    stat_date        STRING COMMENT '统计日期',
    dw_ins_time      STRING COMMENT '插入时间',

    idcard_city_id   INT    COMMENT '身份证号归属城市id',
    idcard           INT    COMMENT '身份证号前6位',
    area_code        STRING COMMENT '区域编码：省编码|市编码|区县编码',
    zip_code         INT    COMMENT '邮编',
    province_name    STRING COMMENT '省名称',
    city_name        STRING COMMENT '市名称',
    district_name    STRING COMMENT '区县名称',
    country_name     STRING COMMENT '国家名称',

    lng              STRING COMMENT '经度',
    lat              STRING COMMENT '纬度'
) COMMENT'身份证归属城市' PARTITIONED BY(
    pt INT 
) STORED AS ORC;


INSERT OVERWRITE TABLE dim_idcard_city_d_f PARTITION(pt=${ds})
SELECT
    ${ds}   AS stat_date,
    CURRENT_DATE            AS dw_ins_time,
        
    ic.id                   AS idcard_city_id,
    ic.idcard               AS idcard,
    ''                      AS area_code,
    INT('')                      AS zip_code,
    ic.province             AS province_name,
    ic.city                 AS city_name,
    ic.country              AS district_name,
    '中国'                   AS country_name,
    c.lng                   AS lng,
    c.lat                   AS lat
FROM 
(
    SELECT * 
    FROM ods_idcard_city_d_f 
    WHERE pt = "${ds}"
    AND ISNOTNULL(idcard)
) AS ic
LEFT JOIN 
(
    SELECT * 
    FROM dim_city_d_f 
    WHERE pt = "${ds}"
) AS c 
ON (c.city_name = ic.city AND c.province_name = ic.province) OR (c.city_name = ic.country AND c.province_name = ic.city);

