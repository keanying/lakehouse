--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-01 11:34:31
--EMR任务只能运行在独享资源组上
--********************************************************************--

-- drop table dim_channel_d_f; 
-- alter table dim_channel_d_f        DROP IF EXISTS PARTITION (pt=${before6day});

CREATE TABLE IF NOT EXISTS dim_channel_d_f(
    stat_date               STRING COMMENT'统计日期',
    dw_ins_time             STRING COMMENT'插入时间',

    order_channel_id        INT     COMMENT'uu_ss_order.ordermode，下单渠道ID',
    track_source_id         int     COMMENT'pft_order_track.source（action=0/16）,下单渠道id',
    channel_name            STRING  COMMENT'下单渠道名称',
    is_line_off             STRING  COMMENT'线上/线下渠道',
    is_group                INT     COMMENT'散客/团队渠道'

 )COMMENT'下单渠道'PARTITIONED BY(
    pt INT 
 )STORED AS ORC;

INSERT OVERWRITE TABLE dim_channel_d_f PARTITION(pt=${ds})
SELECT
        ${ds}       as stat_date,
        current_date                as dw_ins_time,

        ch.order_channel_id         as order_channel_id,
        ch.track_source_id          as track_source_id,
        ch.channel_name             as channel_name,
        ch.is_line_off              as is_line_off,
        ch.is_group                 as is_group

from (select * from ods_bi_business_dim_channel_d_f where pt ="${ds}") ch

