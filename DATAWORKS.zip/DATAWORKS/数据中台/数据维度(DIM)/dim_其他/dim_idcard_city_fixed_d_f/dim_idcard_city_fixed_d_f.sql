--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-05 17:09:04
--EMR任务只能运行在独享资源组上
--********************************************************************--
-- desc 身份证归属城市

CREATE TABLE IF NOT EXISTS dim_idcard_city_fixed_d_f(
    stat_date        STRING COMMENT '统计日期',
    dw_ins_time      STRING COMMENT '插入时间',

    idcard_city_id   INT    COMMENT '身份证号归属城市id',
    idcard           INT    COMMENT '身份证号前6位',
    area_code        STRING COMMENT '区域编码：省编码|市编码|区县编码',
    zip_code         INT    COMMENT '邮编',
    province_name    STRING COMMENT '省名称',
    city_name        STRING COMMENT '市名称',
    district_name    STRING COMMENT '区县名称',
    country_name     STRING COMMENT '国家名称',

    lng              STRING COMMENT '经度',
    lat              STRING COMMENT '纬度'
) COMMENT'身份证归属城市' PARTITIONED BY(
    pt INT 
) STORED AS ORC;

INSERT OVERWRITE TABLE dim_idcard_city_fixed_d_f PARTITION(pt=${ds})
SELECT
    ${ds}   AS stat_date,
    CURRENT_DATE            AS dw_ins_time,
        
    ic.id                   AS idcard_city_id,
    ic.identity_code        AS idcard,
    ''                      AS area_code,
    c.zip_code              AS zip_code,
    c.province_name         AS province_name,
    c.city_name             AS city_name,
    c.district_name         AS district_name,
    c.country_name          AS country_name,
    c.lng                   AS lng,
    c.lat                   AS lat
FROM 
(
    SELECT * 
    FROM ods_identity_area_code_d_f 
    WHERE pt = "${ds}"
    AND ISNOTNULL(identity_code)
) AS ic
LEFT JOIN 
(
    SELECT * 
    FROM dim_city_fixed_d_f 
    WHERE pt = "${ds}"
) AS c 
ON ic.region_id = c.region_id;