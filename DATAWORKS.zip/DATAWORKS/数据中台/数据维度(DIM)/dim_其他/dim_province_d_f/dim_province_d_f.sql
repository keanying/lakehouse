--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-07 14:47:13
--EMR任务只能运行在独享资源组上
--********************************************************************--
CREATE TABLE IF NOT EXISTS dim_province_d_f(
    stat_date               STRING COMMENT'统计日期',
    dw_ins_time             STRING COMMENT'插入时间',

    province_code           int     COMMENT'省编码',
    province_name           STRING  COMMENT'省名称',
    province_adcode         string comment '省行政编码'

 )COMMENT'城市信息表'PARTITIONED BY(
    pt INT 
 )STORED AS ORC;

INSERT OVERWRITE   TABLE dim_province_d_f PARTITION(pt='${ds}')
SELECT
        '${ds}'     as stat_date,
        current_date                as dw_ins_time,

        province_code             as province_code,
        province_name             as province_name,
        province_adcode           as province_adcode
        
from ods_bi_datav_province_d_f 
where pt ="${ds}"
;

--select * from dim_city_d_f;

--select count(*) from dim_city_d_f where isnotnull(lat);
--select count(*) from data_middle_bi.s_bi_business_city_d_f where pt ="${ds}" and isnotnull(lat)