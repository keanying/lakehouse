--@exclude_output=default_workspace_svwh.dim_pft_module_package_classify_d_f
--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-01 17:49:08
--EMR任务只能运行在独享资源组上
--********************************************************************--

-- desc 套餐分组
-- drop table dim_pft_module_package_classify_d_f;

create table if not EXISTS dim_pft_module_package_classify_d_f(
    package_classify_name              string COMMENT '套餐组名称',
    package_id                 string COMMENT '套餐id',
    operate_id                 INT comment '操作人员',
    operate_time               string comment '操作时间'
    
)COMMENT '套餐分组' PARTITIONED by(
    pt string
) STORED AS ORC;

--1、将套餐组包含套餐列表变成 多条记录
--2、过滤 删除标记（id_delete=1)的数据
--3、时间戳改为年月日格式
INSERT OVERWRITE table dim_pft_module_package_classify_d_f PARTITION (pt='${ds}')
select 
   classify_name                        as   package_classify_name,
   explode(split(package_ids,','))      as   package_id,
   op_id                                as   operate_id,
   from_unixtime(update_time)           as   operate_time

FROM  ods_pft_module_package_classify_d_f 
where pt='${ds}'  and is_delete=0

;


-- select package_classify_name,package_id
-- from dim_pft_module_package_classify_d_f 
-- where pt='${bdp.system.bizdate}'
-- group by package_id 
-- having num>1
