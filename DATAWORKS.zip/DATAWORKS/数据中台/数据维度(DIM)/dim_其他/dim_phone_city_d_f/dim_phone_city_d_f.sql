--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-04 17:46:55
--EMR任务只能运行在独享资源组上
--********************************************************************--

-- drop table dim_phone_city_d_f; 
-- alter table dim_phone_city_d_f        DROP IF EXISTS PARTITION (pt=${before6day});

CREATE TABLE IF NOT EXISTS dim_phone_city_d_f(
    stat_date               STRING COMMENT'统计日期',
    dw_ins_time             STRING COMMENT'插入时间',

    phone_city_id           int     comment'ID',
    phone_number            INT     COMMENT'手机号前7位',
    area_code               STRING  COMMENT'区域编码：省编码|市编码|区县编码',
    zip_code                INT     COMMENT'邮编',
    province_name           STRING  COMMENT'省名称',
    city_name               STRING  COMMENT'市名称',
    district_name           STRING  COMMENT'区县名称',
    country_name            STRING  COMMENT'国家名称',

    lng                     STRING  COMMENT'经度',
    lat                     STRING  COMMENT'纬度'
 )COMMENT'手机号归属城市表'PARTITIONED BY(
    pt INT 
 )STORED AS ORC;

INSERT OVERWRITE   TABLE dim_phone_city_d_f PARTITION(pt=${ds})
SELECT  distinct

        ${ds}       as stat_date,
        current_date                as dw_ins_time,
        pc.id                       as phone_city_id,
        pc.number                   as phone_number,
        pc.area_code                as area_code,
        INT(city.zip_code)          as zip_code,
        city.province_name          as province_name,
        city.city_name              as city_name,
        ''                          as district_name,
        '中国'                      as country_name,
        city.lng                    as lng,
        city.lat                    as lat
from (select * from s_city_phone_o_f) pc
join (select * from dim_city_d_f where pt ="${ds}") city
on pc.province_code = city.province_code and pc.city_code = city.city_code;
-- SELECT  distinct

--         ${bdp.system.bizdate}       as stat_date,
--         current_date                as dw_ins_time,

--         pc.id                       as phone_city_id,
--         pc.number                   as phone_number,
--         pc.pft_area_code            as area_code,
--         pc.zip_code                 as zip_code,
--         pc.province_name            as province_name,
--         pc.city_name                as city_name,
--         pc.country_name             as district_name,
--         '中国'                      as country_name,

--         pc.lng                       as lng,
--         pc.lat                       as lat
-- from (select * from data_middle_bi.s_bi_business_city_phone_d_f where pt ="${bdp.system.bizdate}") pc


