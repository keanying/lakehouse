--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-07-31 18:15:04
--EMR任务只能运行在独享资源组上
--********************************************************************--

--alter table dim_city_d_f        DROP IF EXISTS PARTITION (pt=${before6day});

CREATE TABLE IF NOT EXISTS dim_city_d_f(
    stat_date               STRING COMMENT'统计日期',
    dw_ins_time             STRING COMMENT'插入时间',

    city_id                 INT     COMMENT'城市ID',
    city_code               int     COMMENT'城市编码',
    city_name               STRING  COMMENT'城市名称',
    province_code           INT     COMMENT'省编码',
    province_name           STRING  COMMENT'省名称',
    district_code           INT     COMMENT'区县编码',
    district_name           STRING  COMMENT'区县名称',
    country_code            INT     COMMENT'国家编码',
    country_name            STRING  COMMENT'国家名称',

    area_code               STRING  COMMENT'区域编码：省编码|市编码|区县编码',
    zip_code                STRING  COMMENT'城市邮政编码',
    lng                     STRING  COMMENT'城市经度',
    lat                     STRING  COMMENT'城市纬度',
    city_adcode             string comment '城市行政编码',

    province_adcode         string comment '省行政编码',
    province_lng            string comment '省经度',
    province_lat            string comment '省维度'

--     district_adcode         string comment '区县行政编码',
--     district_lng            string comment '区县经度',
--     district_lat            string comment '区县维度'

 )COMMENT'城市信息表'PARTITIONED BY(
    pt INT 
 )STORED AS ORC;

INSERT OVERWRITE   TABLE dim_city_d_f PARTITION(pt='${ds}')
SELECT
        '${ds}'                             as stat_date,
        current_date                                as dw_ins_time,
        c.id                                        as city_id,
        c.area_code                                 as city_code,
        c.area_name                                 as city_name,
        d.area_code                                 as province_code,
        d.area_name                                 as province_name,
        0                                           as district_code,
        0                                           as district_name,
        c.country_code                              as country_code,
        '中国'                                      as country_name,
        concat(d.area_code, '|', c.area_code,'|0')  as area_code,
        c.zip_code                                  as zip_code,
        c.lng                                       as lng,
        c.lat                                       as lat,
        c.adcode                                    as city_adcode,
        d.adcode                                    as province_adcode,
        d.lng                                       as province_lng,
        d.lat                                       as province_lat
from (
    select id, country_code, area_code, area_name, area_type, parent_code, adcode, center, lng, lat, zip_code 
    from s_city_d_f 
    where pt ="20240325" and area_type=2
) c
left join (
    select id, country_code, area_code, area_name, area_type, parent_code, adcode, center, lng, lat, zip_code 
    from s_city_d_f 
    where pt ="20240325" and area_type=1
) d on c.parent_code = d.area_code
;
-- SELECT
--         '${bdp.system.bizdate}'     as stat_date,
--         current_date                as dw_ins_time,

--         c.id                        as city_id,
--         c.city_code                 as city_code,
--         c.city_name                 as city_name,
--         c.province_code             as province_code,
--         c.province_name             as province_name,
--         0                           as district_code,
--         0                           as district_name,
--         c.country_code              as country_code,
--         c.country_name              as country_name,
--         c.area_code                 as area_code,
--         c.zip_code                  as zip_code,
--         if(isnotnull(d.city_lng),d.city_lng,if(isnotnull(c.lng),c.lng,d1.district_lng))                  as lng,
--         if(isnotnull(d.city_lat),d.city_lat,if(isnotnull(c.lat),c.lat,d1.district_lat))                  as lat,
--         if(isnotnull(d.city_adcode),d.city_adcode,d1.district_adcode)         as city_adcode,

--         d.province_adcode           as province_adcode,
--         d.province_lng              as province_lng,
--         d.province_lat              as province_lat

--         -- d.district_adcode           as district_adcode,
--         -- d.district_lng              as district_lng,
--         -- d.district_lat              as district_lat
        
-- from (select * from data_middle_bi.s_bi_business_city_d_f where pt ="${bdp.system.bizdate}") c
-- left join (select distinct province_name,province_adcode,province_lng,province_lat,city_adcode,city_name,city_lng,city_lat
--            from data_middle_bi.s_bi_datav_districts_info_d_f 
--            where pt ="${bdp.system.bizdate}") d ON d.province_name=c.province_name and d.city_name=c.city_name -- and d.district_name=c.country_name
-- left join (select distinct province_name,province_adcode,province_lng,province_lat,district_adcode,district_name,district_lng,district_lat
--            from data_middle_bi.s_bi_datav_districts_info_d_f 
--            where pt ="${bdp.system.bizdate}") d1 ON d1.province_name=c.province_name and d1.district_name=c.city_name -- and d.district_name=c.country_name
-- ;

--select * from dim_city_d_f;

--select count(*) from dim_city_d_f where isnotnull(lat);
--select count(*) from data_middle_bi.s_bi_business_city_d_f where pt ="${bdp.system.bizdate}" and isnotnull(lat)