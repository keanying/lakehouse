--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-01 11:51:13
--EMR任务只能运行在独享资源组上
--********************************************************************--

-- drop table dim_land_topic_d_f; 
-- alter table dim_land_topic_d_f        DROP IF EXISTS PARTITION (pt=${before6day});

CREATE TABLE IF NOT EXISTS dim_land_topic_d_f(
    stat_date               STRING COMMENT'统计日期',
    dw_ins_time             STRING COMMENT'插入时间',

    land_topic              string COMMENT'景区旅游主题',
    land_topic_name         string COMMENT'标准化景区主题'

 )COMMENT'订单状态'PARTITIONED BY(
    pt INT 
 )STORED AS ORC;

INSERT OVERWRITE   TABLE dim_land_topic_d_f PARTITION(pt=${ds})
SELECT  
        ${ds}       as stat_date,
        current_date                as dw_ins_time,

        land_topic                  as land_topic,
        land_topic_name             as land_topic_name

from ods_bi_business_dim_land_topic_d_f where pt ="${ds}"
;   

