--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-04 16:22:39
--EMR任务只能运行在独享资源组上
--********************************************************************--


CREATE TABLE IF NOT EXISTS dim_city_fixed_d_f(
    stat_date               STRING COMMENT'统计日期',
    dw_ins_time             STRING COMMENT'插入时间',

    country_code            INT     COMMENT'国家编码',
    country_name            STRING  COMMENT'国家名称',
    region_id               INT     COMMENT'区域ID',

    province_id             INT     COMMENT'省区域ID',
    province_code           INT     COMMENT'省行政编码',
    province_name           STRING  COMMENT'省名称',

    city_id                 INT     COMMENT'城市区域ID',
    city_code               int     COMMENT'城市行政编码',
    city_name               STRING  COMMENT'城市名称',
   
    district_id             INT     COMMENT'区县区域ID',
    district_code           INT     COMMENT'区县行政编码',
    district_name           STRING  COMMENT'区县名称',

    concat_area_code        STRING  COMMENT'区域行政编码：省行政编码|市行政编码|区县行政编码',
    concat_area_name        STRING  COMMENT'区域名称：省名称|市名称|区县名称',
   
    province_zip_code       STRING  COMMENT'省份邮政编码',
    province_lng            STRING  COMMENT'省份经度',
    province_lat            STRING  COMMENT'省份纬度',

    city_zip_code           STRING  COMMENT'城市邮政编码',
    city_lng                STRING  COMMENT'城市经度',
    city_lat                STRING  COMMENT'城市纬度',

    district_zip_code       STRING  COMMENT'区县邮政编码',
    district_lng            STRING  COMMENT'区县经度',
    district_lat            STRING  COMMENT'区县纬度',

    zip_code                STRING  COMMENT'末级邮政编码',
    lng                     STRING comment '末级经度',
    lat                     STRING comment '末级维度'

 )COMMENT'城市维表'PARTITIONED BY(
    pt INT 
 )STORED AS ORC;

-- 一条完整的省市区, 如:内蒙古自治区-通辽市-库伦旗, 在这个表里至少会存在三条:
-- 只有省份:        内蒙古自治区-内蒙古自治区-内蒙古自治区
-- 只有省份城市:    内蒙古自治区-通辽市-通辽市
-- 完整省市区:      内蒙古自治区-通辽市-库伦旗
INSERT OVERWRITE  TABLE dim_city_fixed_d_f PARTITION(pt='${ds}')
SELECT
        '${ds}'                     as stat_date,
        current_date                                as dw_ins_time,
        country_code                                as country_code,
        country_name                                as country_name,
        region_id                                   AS region_id,
        province_id                                 as province_id,
        province_code                               as province_code,
        province_name                               as province_name,

        city_id                                     as city_id,
        city_code                                   as city_code,
        city_name                                   as city_name,

        district_id                                 AS district_id,
        district_code                               AS district_code,
        district_name                               as district_name,
       
        concat_area_code                            as concat_area_code,
        concat_area_name                            AS concat_area_name,

        province_zip_code                           AS province_zip_code,
        province_lng                                AS province_lng,
        province_lat                                AS province_lat,

        city_zip_code                               AS city_zip_code,
        city_lng                                    AS city_lng,
        city_lat                                    AS city_lat,

        district_zip_code                           AS district_zip_code,
        district_lng                                AS district_lng,
        district_lat                                AS district_lat,

        zip_code                                    as zip_code,
        lng                                         as lng,
        lat                                         as lat
FROM(
    SELECT 
        countryTab.id as country_code,
        countryTab.name_zh as country_name,
        district_id as region_id, 
        province_id, province_code, province_name,
        city_id, city_code, city_name,
        district_id, district_code, district_name,
        CONCAT(province_code, '|', city_code, '|', district_code) as concat_area_code,
        CONCAT(province_name, '|', city_name, '|', district_name) as concat_area_name,
        district_zip_code, city_zip_code, province_zip_code,
        district_lng, city_lng, province_lng,
        district_lat, city_lat, province_lat,
        COALESCE(district_zip_code, city_zip_code, province_zip_code) as zip_code, 
        COALESCE(district_lng, city_lng, province_lng) as lng, 
        COALESCE(district_lat, city_lat, province_lat) as lat
    FROM(
        -- 同时存在省市区, 如:内蒙古自治区-通辽市-库伦旗
        SELECT 
            id as province_id, 
            country_id as country_code, 
            area_code as province_code, 
            area_name as province_name,
            area_code as province_adcode, 
            zip_code as province_zip_code, 
            lng as province_lng, 
            lat as province_lat
        FROM ods_region_area_d_f 
        WHERE pt = ${ds}
        AND level = 1 
        AND status in (1, 4)
    ) provinceTab
    JOIN(
        SELECT  
            id as city_id, 
            parent_code as city_parent_code, 
            area_code as city_code, 
            area_name as city_name,
            area_code AS city_adcode, 
            zip_code as city_zip_code, 
            lng as city_lng, 
            lat as city_lat
        FROM ods_region_area_d_f 
        WHERE pt =  ${ds}
        AND level = 2
        AND status in (1, 4)
    ) cityTab
    ON cityTab.city_parent_code = provinceTab.province_code
    JOIN(
        SELECT 
            id as district_id,  
            parent_code as district_parent_code, 
            area_code as district_code, 
            area_name as district_name,
            area_code AS district_adcode, 
            zip_code as district_zip_code, 
            lng as district_lng, 
            lat as district_lat
        FROM ods_region_area_d_f 
        WHERE pt =  ${ds}
        AND level = 3
        AND status in (1, 4)
    ) districtTab
    ON cityTab.city_code = districtTab.district_parent_code
    JOIN (
        select id, name_zh
        FROM ods_country_region_d_f
        WHERE pt = ${ds}
    ) countryTab
    ON provinceTab.country_code = countryTab.id

    UNION ALL 
    -- 只有省份和城市, 如:内蒙古自治区-鄂尔多斯市-鄂尔多斯市
    SELECT 
        countryTab.id as country_code,
        countryTab.name_zh as country_name,
        city_id as region_id, 
        province_id, province_code, province_name,
        city_id, city_code, city_name,
        city_id as district_id, city_code as district_code, city_name as district_name,

        CONCAT(province_code, '|', city_code, '|', city_code) as concat_area_code,
        CONCAT(province_name, '|', city_name, '|', city_name) as concat_area_name,

        city_zip_code as district_zip_code, city_zip_code, province_zip_code,
        city_lng as district_lng, city_lng, province_lng,
        city_lat as district_lat, city_lat, province_lat,
        COALESCE(city_zip_code, province_zip_code) as zip_code, 
        COALESCE(city_lng, province_lng) as lng, 
        COALESCE(city_lat, province_lat) as lat
    FROM(
        SELECT 
            id as province_id, 
            country_id as country_code, 
            area_code as province_code, 
            area_name as province_name,
            area_code as province_adcode, 
            zip_code as province_zip_code, 
            lng as province_lng, 
            lat as province_lat
        FROM ods_region_area_d_f 
        WHERE pt = ${ds}
        AND level = 1 
        AND status in (1, 4)
    ) provinceTab
    JOIN(
        SELECT  
            id as city_id, 
            parent_code as city_parent_code, 
            area_code as city_code, 
            area_name as city_name,
            area_code AS city_adcode, 
            zip_code as city_zip_code, 
            lng as city_lng, 
            lat as city_lat
        FROM ods_region_area_d_f 
        WHERE pt =  ${ds}
        AND level = 2
        AND status in (1, 4)
    ) cityTab
    ON cityTab.city_parent_code = provinceTab.province_code
    JOIN (
        select id, name_zh
        FROM ods_country_region_d_f
        WHERE pt = ${ds}
    ) countryTab
    ON provinceTab.country_code = countryTab.id

    -- 只有省, 如台湾-台湾-台湾
    UNION ALL
    SELECT 
        countryTab.id as country_code,
        countryTab.name_zh as country_name,
        province_id as region_id, 
        province_id, province_code, provinceTab.province_name,
        province_id as city_id, province_code as city_code, province_name as city_name,
        province_id as district_id, province_code as district_code, province_name as district_name,
        CONCAT(province_code, '|', province_code, '|', province_code) as concat_area_code,
        CONCAT(province_name, '|', province_name, '|', province_name) as concat_area_name,
        province_zip_code as district_zip_code, province_zip_code as city_zip_code, province_zip_code,
        province_lng as district_lng, province_lng as city_lng, province_lng,
        province_lat as district_lat, province_lat as city_lat, province_lat,
        province_zip_code as zip_code, 
        province_lng as lng, 
        province_lat as lat
    FROM(
        SELECT 
            id as province_id, 
            country_id as country_code, 
            area_code as province_code, 
            area_name as province_name,
            area_code as province_adcode, 
            zip_code as province_zip_code, 
            lng as province_lng, 
            lat as province_lat
        FROM ods_region_area_d_f 
        WHERE pt = ${ds}
        AND level = 1 
        AND status in (1, 4)
    ) provinceTab
    JOIN (
        select id, name_zh
        FROM ods_country_region_d_f
        WHERE pt = ${ds}
    ) countryTab
    ON provinceTab.country_code = countryTab.id
) tmp;