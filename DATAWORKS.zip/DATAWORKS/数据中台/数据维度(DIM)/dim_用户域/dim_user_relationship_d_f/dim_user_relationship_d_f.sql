--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-08 09:57:24
--EMR任务只能运行在独享资源组上
--********************************************************************--
-- desc 商户合作伙伴情况

--drop table if  EXISTS dim_user_relationship_d_f;
create table if NOT EXISTS dim_user_relationship_d_f(
    stat_date                       STRING COMMENT"统计日期",
    dw_ins_time                     STRING COMMENT"数据插入日期",
    
    parent_id                       INT    COMMENT"父用户id",
    son_id                          INT    COMMENT"子用户id",
    son_type                        string  COMMENT"子用户类型，分销商/OTA/员工",
    relationship_type               INT    COMMENT"关系类型，0供销关系1从属关系2平级关系3推荐关系4资源中心供销",
    distributor_group               INT    COMMENT"分销商分组ID",

    add_time                        string comment "添加时间",
    cut_time                        string comment "取消时间",
    status                          string comment '状态，0 正常，1断连'
    
 )COMMENT'商户合作伙伴'PARTITIONED BY(
    pt INT
 )STORED AS ORC;

-- 筛选供销、从属员工关系
-- 仅保留有效关系链
INSERT OVERWRITE    TABLE dim_user_relationship_d_f  PARTITION(pt='${ds}')
select
    ${ds}                   as stat_date,
    current_date                            as dw_ins_time,

    r.parent_id                             as parent_id,
    if(isnotnull(u.user_id),r.son_id,null)  as son_id,
    if(u.user_type in ('供应商','分销商'),if(u.user_is_OTA='OTA','OTA','分销商'),if(u.user_type ='员工','员工','其它'))  as son_type,
    r.ship_type                             as relationship_type,
    
    INT(g.distributor_group_name)                as distributor_group,
--    g1.group_name                                  as distributor_group,

    r.add_time                              as add_time,
    r.cut_time                              as cut_time,
    r.status                                as status

from (select parent_id,son_id,son_id_type,ship_type,max(id) max_id,min(rectime) add_time,max(cuttime) cut_time,status
      from ods_myuu_pft_member_relationship_d_f
      where  pt=${ds}  and ((ship_type in(0,1)  and status=0) or ship_type=4)
      group by parent_id,son_id,son_id_type,ship_type,status) r
left join (select * from dim_distributor_group_d_f where pt= '${ds}') g on r.parent_id=g.supplier_id and r.son_id=g.distributor_id
-- left join (select sid,fid,max(group_id) max_id  from s_pft_evolute_group_fid_d_f where pt= ${ds} 
--       group by sid,fid) g on g.sid=r.parent_id and g.fid=r.son_id
-- join  (select id,group_name from s_pft_evolute_group_d_f where pt= ${ds} ) g1 on g1.id=g.max_id
left join (select user_id,user_is_OTA,user_status,user_type from dim_user_d_f  
            where  pt=${ds} and user_type in ('供应商','分销商','员工') and user_status in ('正常','未审核')) u 
            on u.user_id=r.son_id
;


--  select parent_id,son_id,son_type,relationship_type,count(*) num
--  from dim_user_relationship_d_f where pt='${ds}'
--  group by parent_id,son_id,son_type,relationship_type
--  having num>1

--  select parent_id,son_type,relationship_type,count(distinct son_id) num
--  from dim_user_relationship_d_f 
--  where pt='${ds}' and parent_id =73 and relationship_type=0
--  group by parent_id,son_type,relationship_type
-- ;

--  select user_id,user_name,user_type_code,user_type
--  from dim_user_d_f 
--  where pt='${ds}' and user_id=4355