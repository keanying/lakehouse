--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-01 16:34:55
--EMR任务只能运行在独享资源组上
--********************************************************************--


CREATE table if not EXISTS dim_user_module_d_f(
    stat_date                STRING  COMMENT '统计日期',
    dw_ins_time              STRING  COMMENT '插入时间',

    user_id                  STRING  COMMENT '用户id',
    module_id                STRING  COMMENT '应用模块id',
    module_name              STRING  COMMENT '应用模块名称',

    begin_time               STRING  COMMENT '模块开始时间',
    end_time                 STRING  COMMENT '模块到期时间',
    module_user_status       STRING  COMMENT '模块使用状态,当前/过期',

    is_use_free              STRING  COMMENT '是否免费试用过 0=不是，1=是',
    create_time              STRING  COMMENT '创建时间',
    update_time              STRING  COMMENT '更新时间',
    module_open_type         STRING  comment '开通类型 0自开通 1管理员开通 2管理员关闭',

    module_type              STRING  COMMENT '模块所属类型',
    module_status            STRING  COMMENT '模块是否上下架，0=下架，1=上架',
    module_price             float   COMMENT '模块单价（元）',
    module_pay_amount        float   COMMENT '模块支付金额（元）'

)COMMENT "商户当前模块状态表" PARTITIONED  BY (
    pt STRING   
)STORED AS ORC;


-- 取当前模块状态
INSERT OVERWRITE TABLE dim_user_module_d_f PARTITION (pt="${ds}")
SELECT 
       ${ds}                 as stat_date,
       current_date()                        as dw_ins_time,
       
       m1.member_id                          AS user_id,
       m1.module_id                          AS module_id,
       m2.name                               AS module_name,

       from_unixtime(m1.begin_time)          AS begin_time,
       from_unixtime(m1.expire_time)         AS end_time,
       case when m1.status=1 then '当前'
            when m1.status=2 then '过期'
       end                                   AS module_user_status,

       m1.use_free                           AS is_use_free,
       from_unixtime(m1.create_time)         AS create_time,
       from_unixtime(m1.update_time)         AS update_time,
       m1.type                               AS module_open_type,
       m2.category                           AS module_type,
       m2.status                             AS module_status,
       price.fee/100                         AS module_price,
       price.discount_price/100              AS module_pay_amount
FROM (SELECT * FROM ods_pft001_pft_module_used_d_f WHERE pt="${ds}") as m1
JOIN (SELECT * FROM ods_pft001_pft_module_d_f WHERE pt="${ds}") as m2 ON m1.module_id = m2.id
left join (select member_id,module_id,price_id,add_time from (
                select member_id,module_id,price_id,from_unixtime(add_time) as add_time,row_number() OVER(PARTITION by member_id,module_id order by add_time desc) as rn  from ods_pft001_pft_module_used_log_d_f 
                            where pt="${ds}" and status not in (1,3)) a
                where rn=1) m3 on m1.module_id = m3.module_id and m1.member_id=m3.member_id
left join (select *  from ods_pft001_pft_module_price_d_f
        where pt="${ds}" 
    )  price  on price.id=m3.price_id;

