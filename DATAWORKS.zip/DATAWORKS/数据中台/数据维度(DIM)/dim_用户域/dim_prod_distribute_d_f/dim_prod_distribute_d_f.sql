--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-07 19:19:24
--EMR任务只能运行在独享资源组上
--********************************************************************--

CREATE TABLE IF NOT EXISTS dim_prod_distribute_d_f (
  stat_date            STRING COMMENT '统计日期',
  dw_ins_time          STRING COMMENT '插入时间',

  supplier_id          INT COMMENT '上级供应商ID',
  distributor_id       INT COMMENT '分销商ID',
  distributor_chain    string COMMENT '分销商链',
  land_id              int COMMENT '景区ID',
  resource_id          int COMMENT '资源ID',
  ticket_id            INT COMMENT '票ID',
  ticket_fullname      STRING COMMENT '票全称=景区名称+“-”+票名称',

  distribute_level     int COMMENT '分销层级',
  channel              STRING COMMENT '分销渠道',
  land_publisher_id    int COMMENT '顶级供应商ID',

  ticket_is_test       string COMMENT '是否测试票？'

)COMMENT '商品(票)分销维表' PARTITIONED BY(
  pt int
)STORED AS ORC;


-- 仅保留上架、分销有效的票
INSERT OVERWRITE    TABLE dim_prod_distribute_d_f  PARTITION(pt=${ds}) 
SELECT  /*+mapjoin(c)*/
        ${ds}           as stat_date,
        current_date                    as dw_ins_time,

        e.sid                           as supplier_id,
        e.fid                           as distributor_id,
        e.aids                          as distributor_chain,
        e.lid                           as land_id,
        p.resource_id                   as resource_id,
        e.ticket_id                     as ticket_id,
        p.ticket_fullname               as ticket_fullname,

        e.lvl                           as distribute_level,
        e.channel                       as channel,
        p.land_publisher_id             as land_publisher_id,

        p.ticket_is_test                as ticket_is_test

from (select * from ods_myuu_pft_evolute_group_speciality_d_f where status=0) as e
--from (select * from ods_pft_p_apply_evolute_d_f where pt='${ds}' and status=0) as e  -- 2021-06-03修改
--from (select * from s_myuu_pft_p_apply_evolute_d_f where pt='${ds}' and status=0) as e
join (select ticket_id,ticket_status,resource_id,ticket_fullname,land_publisher_id,ticket_is_test 
      from dim_prod_d_f 
      where pt=${ds} and ticket_status='上架') as p on e.ticket_id=p.ticket_id
;
