--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-01 15:46:31
--EMR任务只能运行在独享资源组上
--********************************************************************--
-- desc 应用模块信息
-- DROP table if EXISTS dim_company_report_date_d_f;


create table if NOT EXISTS dim_company_report_date_d_f(
    stat_date              STRING     COMMENT "统计日期",
    dw_ins_time            STRING     COMMENT "数据插入日期",

    stat_month             string     COMMENT "统计月份yyyy-MM",    
    begin_date             string     COMMENT "开始日期",    
    end_date               string     COMMENT "结束日期"

)COMMENT'用户运营报表统计周期'PARTITIONED BY(
    pt STRING  
 )STORED AS ORC;

INSERT OVERWRITE TABLE dim_company_report_date_d_f PARTITION (pt="${ds}") 
select 
    ${ds}               as stat_date,
    current_date                        as dw_ins_time,

    stat_month                          as stat_month  ,
    start_date                          as begin_date  ,
    end_date                            as end_date    
from  ods_company_report_date_d_f where pt="${ds}" 
;


-- select *
-- from dim_company_report_date_d_f
-- where pt="${bdp.system.bizdate}"