--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-05 17:58:28
--EMR任务只能运行在独享资源组上
--********************************************************************--

create table if NOT EXISTS dim_plat_staff_d_f(
    stat_date              STRING COMMENT "统计日期",
    dw_ins_time            STRING COMMENT "数据插入日期",

    plat_staff_id         INT    COMMENT "用户id",    
    plat_staff_name       string COMMENT "员工名称", 
    plat_staff_department string COMMENT "员工部门", 
    plat_staff_role       string COMMENT "角色：0是签单人员 1是客服 2:区域经理 3:部门经理 4:其它",
    plat_staff_group      STRING COMMENT "员工分组 1:华东大区 2:华北大区 3:西南大区 4:华中大区 5:全部 99:项目组", 
    plat_staff_status     STRING COMMENT "状态：0正常 1离职 2已删除",

    plat_staff_team2_oa   string comment "客功/签单人OA上二级分组",
    plat_staff_team1_oa    string comment "客功/签单人OA上一级分组",
    plat_staff_team_oa    string comment "客功/签单人OA上分组",
    plat_staff_department_oa    string comment "客功/签单人OA上部门"

)COMMENT'平台员工维表'PARTITIONED BY(
    pt STRING  
 )STORED AS ORC;

-- 员工姓名包含部门信息，'-'前拆为部门，后拆为姓名
INSERT OVERWRITE TABLE dim_plat_staff_d_f PARTITION (pt="${ds}") 
select /*+mapjoin(s,sg)*/  distinct
    ${ds}       as stat_date,
    current_date                as dw_ins_time,

    s.st_memberid               as plat_staff_id,
--    s.st_name                   as plat_staff_name,
    if(m.user_name like '%-%',substr(m.user_name,locate('-',m.user_name)+1,50),m.user_name)         as plat_staff_name,
    if(m.user_name like '%-%',substr(m.user_name,1,locate('-',m.user_name)-1),null)                 as plat_staff_department,
    case s.st_type
       when 0 then '签单'
       when 1 then '客服'
       when 2 then '区经'
       when 3 then '部门经理'
       else '其它'
    end                         as plat_staff_role,
    sg.staff_group_name         as plat_staff_group,
    CASE s.st_status 
        WHEN 0 THEN "正常"
        WHEN 1 THEN "离职"
        when 2 THEN "删除"
    END                         as plat_staff_status,

    st2.lv2_team                as plat_staff_team2_oa, 
    st2.lv1_team                as plat_staff_team1_oa, 
    st2.team                    as plat_staff_team_oa, 
    st2.departmentname          as plat_staff_department_oa 

from (select * from ods_pft001_pft_staff_d_f where pt="${ds}"  and st_memberid>0 and st_status<2) as s
-- 按st_memberid 去重
join (select st_memberid,max(id) max_id from ods_pft001_pft_staff_d_f 
      where pt="${ds}"  and st_memberid>0 and st_status<2
      group by st_memberid) ss on ss.max_id=s.id
-- 按 姓名 去重      
join (select if(LOCATE("-",st_name)>0,substr(st_name,LOCATE("-",st_name)+1,50),st_name) staff_name,max(id) max_id 
      from ods_pft001_pft_staff_d_f 
      where pt="${ds}"  and st_memberid>0 and st_status<2
      group by if(LOCATE("-",st_name)>0,substr(st_name,LOCATE("-",st_name)+1,50),st_name)) ss1 on ss1.max_id=s.id
LEFT JOIN (select * from dim_staff_group_d_f where pt="${ds}" ) as sg on sg.staff_group_id=s.st_group
join (select user_id,user_name from ods_pft_member_d_f where pt="${ds}" and user_type='员工') m on m.user_id=s.st_memberid
-- 员工OA上二级小组(暂时过滤增值组陈萍)
left join (select distinct name,lv2_team,lv1_team,team,departmentname
           from dwd_staff_basic_d_f where pt='${ds}' and staff_id<>341) st2 on st2.name=if(m.user_name like '%-%',substr(m.user_name,locate('-',m.user_name)+1,50),m.user_name)
;

-- select *
-- from dim_plat_staff_d_f
-- where pt='${ds}' AND plat_staff_name='蓝燕珍'

-- select *
-- from s_pft001_pft_staff_d_f where pt="${ds}"  and st_memberid>0
-- group by st_memberid
-- having num>1
-- select a.name,count(*) num
-- from (
-- select distinct name,lv2_team,lv1_team,team,departmentname
-- from dwd_staff_basic_d_f where pt='${ds}' and departmentname in ('运营部','平台事业部')
-- ) a
-- group by a.name
-- having num>1


-- select a.user_id,count(*) num
-- from (
-- select user_id,user_name from ods_pft_member_d_f where pt="${ds}" and user_type='员工') a
-- group by a.user_id
-- having num>1


-- select * from dim_staff_group_d_f where pt="${ds}"
-- select * from  s_pft001_pft_staff_d_f where pt="${ds}";

-- select count(distinct plat_staff_id) from dim_plat_staff_d_f where pt="${ds}";
-- select * from dim_plat_staff_d_f where pt="${ds}";

--select count(*) from s_myuu_pft_member_d_f where pt="${ds}" and dtype=6

