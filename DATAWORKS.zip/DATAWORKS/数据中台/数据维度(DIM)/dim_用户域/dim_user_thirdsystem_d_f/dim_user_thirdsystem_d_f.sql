--@exclude_input=4727510829336901128
--@exclude_input=default_workspace_svwh.dwd_staff_basic_d_f
--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-05 18:29:24
--EMR任务只能运行在独享资源组上
--********************************************************************--
CREATE TABLE IF NOT EXISTS dim_user_thirdsystem_d_f(
    stat_date                             STRING COMMENT'统计日期',
    dw_ins_time                           STRING COMMENT'插入时间',

    user_id                                int    COMMENT'对接第三方票务商户id',
    thirdsystem_id                         INT    COMMENT'第三方票务系统id',
    thirdsystem_name                       string COMMENT'第三方票务系统名称',
    thirdsystem_ver_name                   string COMMENT'第三方票务系统版本名称',
    bindings_status                        string comment'绑定状态 0绑定/解绑'

 )COMMENT'商户对接第三方系统'PARTITIONED BY(
    pt INT 
 )STORED AS ORC;


INSERT OVERWRITE   TABLE dim_user_thirdsystem_d_f PARTITION(pt=${ds})
SELECT
        ${ds}        as stat_date,
        current_date                 as dw_ins_time,

        cm.pft_memberid              as user_id,
        cs.thirdsystem_id            as thirdsystem_id,
        cs.thirdsystem_name          as thirdsystem_name,
        cs.thirdsystem_ver_name      as thirdsystem_ver_name,
        if(cm.status=0,'绑定','解绑') as bindings_status

from (select * from ods_pft_con_sys_member_d_f where pt =${ds} and status=0) cm    --0绑定状态
left join (select * from dim_thirdsystem_d_f where pt=${ds}) cs on cs.thirdsystem_id=cm.cid
;
