--@exclude_output=default_workspace_svwh.dim_staff_group_d_f
--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-01 11:56:26
--EMR任务只能运行在独享资源组上
--********************************************************************--

-- DROP table if EXISTS dim_staff_group_d_f;

-- alter table dim_staff_group_d_f         DROP IF EXISTS PARTITION (pt=${before6day});


create table if NOT EXISTS dim_staff_group_d_f(
    stat_date              STRING COMMENT "统计日期",
    dw_ins_time            STRING COMMENT "数据插入日期",

    staff_group_id         INT    COMMENT "签单人员分组id",    
    staff_group_name       string COMMENT "签单人员分组名"    

)COMMENT'平台员工维表'PARTITIONED BY(
    pt STRING  
 )STORED AS ORC;

INSERT OVERWRITE TABLE dim_staff_group_d_f PARTITION (pt="${ds}") 
select 
    ${ds}       as stat_date,
    current_date                as dw_ins_time,

    staff_group_id              as staff_group_id,
    staff_group_name              as staff_group_name

from  ods_bi_datav_dim_staff_group_d_f where pt="${ds}" 
;
