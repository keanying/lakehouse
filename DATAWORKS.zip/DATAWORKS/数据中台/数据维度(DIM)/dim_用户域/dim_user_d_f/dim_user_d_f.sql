--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-07 14:43:38
--EMR任务只能运行在独享资源组上
--********************************************************************--
-- DROP table if EXISTS dim_user_d_f;

-- alter table dim_user_d_f         DROP IF EXISTS PARTITION (pt=${before6day});
-- alter table dim_user_d_f add columns(is_resource_center_auto_get_user string comment '资源中心自动拉取产品商户标识');
-- alter table dim_user_d_f add columns(user_land_topic string comment '景区业态');
-- alter table dim_user_d_f add columns(user_level string comment '级别');
-- alter table dim_user_d_f add columns(tourist_source string comment '客源：直营/渠道');
-- alter table dim_user_d_f add columns(format_type int comment '企业业态');
-- alter table dim_user_d_f add columns(group_id    string COMMENT '账号分组');
    

create table if NOT EXISTS dim_user_d_f(
    stat_date                   STRING COMMENT "统计日期",
    dw_ins_time                 STRING COMMENT "数据插入日期",

    user_id                     INT    COMMENT "用户id",    
    user_account_id             INT    COMMENT "账户id", 
    user_customer_id            INT    COMMENT "客户ID",
    user_name                   STRING COMMENT "用户名称/账户名称", 
    user_company_name           STRING COMMENT "公司名称",
    user_company_short_name     STRING COMMENT "公司简称",
    user_type_code              int    COMMENT "用户类型编码",
    user_type                   STRING COMMENT "用户类型",
    user_account                STRING COMMENT "账号", 
    user_status                 STRING COMMENT "用户状态", 

    user_regist_time            STRING COMMENT"用户注册时间",
    user_contarct_firstdate     STRING COMMENT"用户首次合日期",
    user_login_lasttime         STRING COMMENT"用户上次登录时间",

    user_bank_card_1            STRING COMMENT "用户银行卡号1", 
    user_bank_card_2            STRING COMMENT "用户银行卡号2",
    user_alipay                 STRING COMMENT "用户支付宝账号",


    customer_id                 INT    COMMENT"客户id",
    customer_name               STRING COMMENT"客户名称",
    customer_mobile             STRING COMMENT"客户手机号",
    customer_city_fullcode      string COMMENT"城市全编码，省编码|市编码|区域编码",
    customer_province           STRING COMMENT"客户省",
    customer_city               STRING COMMENT"客户市",
    customer_country            STRING COMMENT"客户区域",
    customer_type_code          int    COMMENT"客户类型编码",
    customer_type               STRING COMMENT"客户类型",
    customer_service_hotline    STRING COMMENT"客户服务热线",
    customer_certi_status_code  STRING COMMENT"资质审核状态编码",
    customer_certi_status       STRING COMMENT"资质审核状态",

    --商户有关信息
    user_is_OTA                 STRING COMMENT"用户是否为分销平台",
    distribute_system_type      STRING COMMENT"对接分销平台类型",
    distribute_system_name      STRING COMMENT"对接分销平台名称",
    
    user_used_date              STRING COMMENT"用户启用日期",
    user_contract_model_code    int    COMMENT"合作模式编码",
    user_contract_model         STRING COMMENT"合作模式",

    signer_id                   INT    COMMENT"签单人id",
    signer                      STRING COMMENT"签单人姓名",
    signer_region               STRING COMMENT"签单人所属区域",
    signer_team_oa              string comment '签单人OA上二级分组',
    signer_department           string comment '签单人部门',
    
    servicer_id                 INT    COMMENT"客服id",
    servicer                    STRING COMMENT"客服姓名",
    servicer_team_oa            string comment '客功OA上二级分组',
    servicer_department         string comment '客功部门',

    fee_sms                     DOUBLE  COMMENT"平台短信费收取标准",
    fee_code                    DOUBLE COMMENT"平台凭证费收取标准",
    fee_code_unit               STRING COMMENT"平台凭证费单位",
    fee_withdraw                DOUBLE COMMENT"平台提现手续费百分比",
    gathering_self_way          string COMMENT"独立收款方式： 支付宝,微信",

--    customer_is_resource      BOOLEAN COMMENT"客户是否为资源方",
--    customer_resource_id      INT     COMMENT"客户资源id",
--    customer_resource_name    STRING COMMENT"客户资源名称",
--    customer_resource_type    STRING COMMENT"客户资源类型",
--    customer_resource_level   STRING COMMENT"客户资源级别"

    user_is_test                string COMMENT '测试账号？',
    user_open_datav             string COMMENT '开通/未开通',
    user_bind_taobao            string comment '绑定/空',
    is_resource_center_auto_get_user   string comment '资源中心自动拉取产品商户 是/否',

    user_land_topic             string comment '景区业态',
    user_level                  string comment '级别',
    is_operate_user             string comment '运营客户/null',

    tourist_source             string comment '客户来源:直营/渠道',
    format_type                int comment '企业业态',
    group_id                   string COMMENT '账号分组'

)COMMENT'用户维表'PARTITIONED BY(
    pt STRING  
 )STORED AS ORC;


INSERT OVERWRITE TABLE dim_user_d_f PARTITION (pt="${ds}") 
select /*+mapjoin(tu,m1,m2,c,s,p1,cd,cd1,cd2)*/
    '${ds}'                                              as stat_date,
    current_date                                                         as dw_ins_time,

    m.user_id                                                            as user_id,
    m.user_account_id                                                    as user_account_id,
    m.user_customer_id                                                   as user_customer_id,
    m.user_name                                                          as user_name,
    me.com_name                                                          as user_company_name,
    if(isnotnull(s.short_name),s.short_name,substr(me.com_name,1,4))     as user_company_short_name,
    m.user_type_code                                                     as user_type_code,
    m.user_type                                                          as user_type, 
    m.user_account                                                       as user_account,
    m.user_status                                                        as user_status , 
                                    
    m.user_regist_time                                                  as user_regist_time,         --注册日期
    m.user_regist_time                                                  as user_contarct_firstdate,  -- 首次合作日期,默认为注册时间，后续用市场直签表签协议日期
    m.user_login_lasttime                                               as user_login_lasttime,     -- 上次登录日期

    m.user_bank_card_1                                                   as user_bank_card_1,
    m.user_bank_card_2                                                   as user_bank_card_2,
    m.user_alipay                                                       as user_alipay,

    -- 客户信息
    m.customer_id                                                       as customer_id,      -- 客户ID
    me.com_name                                                         as customer_name,    -- 客户名称
    m.customer_mobile                                                   as customer_mobile,  -- 客户手机号
    -- 配置的省市>联系人手机号归属省市
    -- 配置省信息特殊情况：
    --   * 只配置直辖市，未配置区的 仅取省信息,市/县信息为空
    --   * 配置的country 为null时 补0，进行省市名称匹配
    if(isnull(p1.province_name),pc.area_code,concat(c.province_code,'|',c.city_code,'|',if(isnull(c.country_code),'0',c.country_code)))   as custormer_area_code,
    if(isnull(c.province_name),if(isnotnull(p1.province_name),p1.province_name,pc.province_name),c.province_name)        as customer_province,-- 省
    --if(isnull(c.province_name),if(isnotnull(p1.province_name),null,pc.city_name),c.city_name)                as customer_city,    -- 市
    case when c.province_name is null then pc.city_name else c.city_name end as customer_city,    -- 市   edit by sjw 补齐数据，原始在上一行
    --if(isnull(c.province_name),if(isnotnull(p1.province_name),null,pc.country_name),c.country_name)          as customer_country, -- 区县
    case when c.province_name is null then pc.country_name else c.country_name end as customer_country, -- 区县  edit by sjw 补齐数据，原始在上一行
    me.corp_kind                                                        as customer_type_code ,
    -- case me.corp_kind                
    --     when 1 then '景区'                
    --     when 0 then '酒店'                
    --     when 2 then '旅行社'
    --     when 3 then '加盟门店'
    --     when 4 then '电商'
    --     when 5 then '淘宝/天猫'
    --     when 6 then '团购'
    --     when 7 then '个人'
    --     when 8 then '其他'
    --     else me.corp_kind
    -- end                                                                 as customer_type ,            --- 客户类型
    cd.name                                                             as customer_type ,            --- 客户类型
    me.hotline                                                          as customer_service_hotline,  -- 客服热线
    cer.certi_status                                                    as customer_certi_status_code, -- 资质审核状态编码
    case cer.certi_status
        when 0 then '未认证'
        when 1 then '审核中'
        when 2 then '已认证'
        when 3 then '拒绝'
    end                                                                 as customer_certi_status,     -- 资质审核状态


    -- 商户平台合作及服务人员
    m.user_is_OTA                                                       as user_is_OTA,             --是否对接分销平台
    m.distribute_system_type                                            as distribute_system_type,  --分销平台类型
    m.distribute_system_name                                            as distribute_system_name,  --分销平台名称
    substr(FROM_UNIXTIME(s.enable_time,'yyyy-MM-dd'),1,10)              as user_used_date,          -- 启用日期
    me.contract_model                                                   as user_contract_model_code,--合作模式编码
    case me.contract_model
        when 1 then '套餐'
        when 2 then '项目'
        when 3 then '订单预存'
        else ''
    end                                                                 as  user_contract_model,              -- 用户合作模式

    m.signer_id                                                         as  signer_id,                        -- 签单人id
    m1.plat_staff_name                                                  as  signer,                           -- 签单人
    m1.plat_staff_group                                                 as  signer_region,                    -- 签单人区域
    m1.plat_staff_team_oa                                               as  signer_team_oa,
    m1.plat_staff_department                                            as  signer_department,


    m.servicer_id                                                       as  servicer_id,                      -- 客服id
    m2.plat_staff_name                                                  as  servicer,                         -- 客服
    m2.plat_staff_team_oa                                               as  servicer_team_oa,
    m2.plat_staff_department                                            as  servicer_department,

    -- 供应商使用平台收费标准
    m.fee_sms                                                           as fee_sms,                           --短信费
    m.fee_code                                                          as fee_code,        --凭证费
    m.fee_code_unit                                                     as fee_code_unit,   -- 凭证费单位
    m.fee_withdraw                                                      as fee_withdraw,    -- 提现手续费百分
    --concat(if(isnull(ali.memberid),'','支付宝,'),if(isnull(we.memberid),'','微信')) as gathering_self_way,    --独立收款      
    pay.channel_name                                                   as gathering_self_way,    --独立收款      

-- bi测试用户库作废，统一试用pft_member.group_id
--    if(m.group_id in (2,3) or m.user_name like '%测试%' or me.com_name like '%测试%'  or isnotnull(tu.test_user_id) ,'测试','正式')   as user_is_test,
    if(m.group_id in (2,3) ,'测试','正式')                              as user_is_test,
    if(isnull(d.user_id),'未开通','开通')                               as user_open_datav,
    if(isnull(tb.user_id),'','绑定')                                    as user_bind_taobao,
    if(isnull(au.user_id),'否','是')                                    as is_resource_center_auto_get_user,

    cd1.name                                                           as user_land_topic,
    cd2.name                                                           as user_level,
    if(uf.ptid is null,null,'运营客户')                                 as is_operate_user,

    case  
        when me.tourist_source='1'  then '直营'
        when me.tourist_source='2'  then '渠道'
        else null
    end                                                                as tourist_source,

    me.format_type,
    m.group_id
from (select * from ods_pft_member_d_f where pt="${ds}" ) as m
--企业名称简称
left join (select * from ods_bi_datav_user_short_name_d_f where pt="${ds}") as s on s.user_id=m.user_id 
-- --测试账号
-- left join (select test_user_id from s_bi_business_dim_test_user_d_f where pt="${ds}") as tu on tu.test_user_id=m.user_id 
--资质认证
left join (select customer_id,certi_status from ods_myuu_pft_customer_certification_d_f where pt="${ds}") cer on cer.customer_id=m.customer_id
--商户启用时间
left join  (select distinct fid,enable_time from ods_myuu_pft_supplier_extinfo_d_f where pt ='${ds}' and isnotnull(enable_time)) as s  on s.fid=m.user_id -- and m.dtype=0    
-- left JOIN  (select id,dname plat_staff_name from s_myuu_pft_member_d_f where pt ='${ds}' and dtype=6) as m1   on m.salesid=m1.id  
-- left JOIN  (select id,dname plat_staff_name from s_myuu_pft_member_d_f where pt ='${ds}' and dtype=6) as m2   on m.kefuID=m2.id  
--签单人
left JOIN  (select plat_staff_id,plat_staff_name,plat_staff_group,plat_staff_team_oa,plat_staff_department
            from dim_plat_staff_d_f where pt ='${ds}') as m1   on m.signer_id=m1.plat_staff_id  
--客服姓名
left JOIN  (select plat_staff_id,plat_staff_name,plat_staff_team_oa,plat_staff_department 
            from dim_plat_staff_d_f where  pt ='${ds}') as m2   on m.servicer_id=m2.plat_staff_id
-- 联系人手机号确定企业归属省市
left join  (select * from dim_phone_city_d_f where pt='${ds}') as pc on pc.phone_number=substr(m.customer_mobile,1,7)
LEFT join (select fid,com_name,contract_model,corp_kind,province,city,country,hotline,format_type,types,
                  if(ext like '%source_user%',substr(ext,locate('source_user',ext,1)+14,1) ,null) tourist_source
           from ods_myuu_pft_member_extinfo_d_f where pt="${ds}" ) as me  on m.user_id = me.fid
-- 仅配置直辖市的情况
left join  (select * from dim_province_d_f where pt ='${ds}' ) as p1 on p1.province_code=me.province 
-- 对于country 为null 的补"0"
left join  (select province_name,city_name,country_name,province_code,city_code,country_code  
            from dim_city_d_f  
            where pt ='${ds}' ) as c on c.province_code=me.province and c.city_code=me.city and c.country_code=if(isnull(me.country),'0',me.country) -- and (isnotnull(me.province) and me.province>0)
-- 商户独立收款
LEFT join (select distinct member_id,channel_name from ods_pft001_pft_merchant_payment_method_d_f where pt="${ds}" ) as pay  on m.user_id = pay.member_id
-- 开通数据大屏
left join (select * from ods_datav_auth_d_f where pt="${ds}") d on d.user_id=m.user_id
--绑定淘宝
left join (select distinct id2  as user_id from ods_pft_tb_bind_d_f where pt="${ds}") tb on tb.user_id=m.user_id
--资源中心自动拉取产品商户
left join (select distinct user_id from ods_resource_center_auto_get_user_d_f where pt="${ds}") au on au.user_id=m.user_id
-- 企业类型
left join (select * from ods_pft_common_dict_d_f where pt="${ds}" and dict_type='cType') cd on cd.code=me.corp_kind 
-- 景区业态
left join (select * from ods_pft_common_dict_d_f where pt="${ds}" and dict_type='format' and parent_dict_type='cType') cd1 on cd1.code=me.format_type  and cd1.parent_code=me.corp_kind 
-- 级别
left join (select * from ods_pft_common_dict_d_f where pt="${ds}" and dict_type='type' and parent_dict_type='cType') cd2 on cd2.code=me.types  and cd2.parent_code=me.corp_kind 
-- 运营接收客户
left join (select distinct ptid from ods_oa_uf_xkhjjdtz_d_f where pt='${ds}' and sfqrjs=0) uf on uf.ptid=m.user_id

-- LEFT join (select distinct memberid from s_pft001_pft_merchant_alipay_d_f where pt="${ds}" ) as ali  on m.user_id = ali.memberid
-- LEFT join (select distinct memberid,status from s_pft001_pft_merchant_wepay_d_f where pt="${ds}" and status=1 ) as we  on m.user_id = we.memberid and m.dtype=0
           
--left join s_myuu_exclusive_account_sms_d_f sms on sms.user_id=m.user_id  and m.dtype=0     -- 短信专款
--left join s_myuu_exclusive_account_code_d_f code on code.user_id=m.user_id  AND m.dtype=0  -- 凭证专款
--left join s_myuu_deposite_config_d_f csms on csms.id=sms.config_id                    -- 短信专款收费标准
--left join s_myuu_deposite_config_d_f ccode on ccode.id=code.config_id                 -- 凭证专款收费标准

;



-- 最近商户套餐时间及状态
-- select  p.user_id,
        --    if(p.package_open_id=p1.last_package_open_id,p.begin_time,null)      as package_start_date,
        --    if(p.package_open_id=p1.last_package_open_id,p.end_time,null)        as package_end_date,
        --    if(p.package_open_id=p1.end_package_open_id,p.end_time,null)         as end_package_end_date,
        --    if(p.package_open_id=p1.last_package_open_id,p.package_status,null)  as package_status,
-- from (select * from dwd_user_package_d_f  where pt='${ds}') p
-- join (SELECT  user_id, 
--               max(if(package_status in ('过期','当前'),package_open_id,null))        as last_package_open_id,
--               max(package_open_id)                                                  as end_package_open_id
--       from dwd_user_package_d_f 
--       where pt='${ds}' 
--       group by user_id ) p1 on p.package_open_id in (p1.last_package_open_id,p1.end_package_open_id)
-- group by p.user_id


-- 合作商户分布
--  select d.customer_province,d.customer_city,c.administrative_code,round(count(*)*6132/3991,0) company_num
--  from (select * from dim_company_d_f where pt='${ds}'  and user_type='供应商' and customer_province<>'' ) d
--  left join (select * from s_bi_business_city_d_f where pt='${ds}') c on c.province_name=d.customer_province and c.city_name=d.customer_city
--  group by d.customer_province,d.customer_city,c.administrative_code;

