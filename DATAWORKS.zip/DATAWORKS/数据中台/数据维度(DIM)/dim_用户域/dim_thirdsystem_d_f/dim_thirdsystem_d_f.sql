--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-05 14:45:04
--EMR任务只能运行在独享资源组上
--********************************************************************--
-- desc  对接票务系统
-- drop table dim_thirdsystem_d_f; 
-- alter table dim_thirdsystem_d_f        DROP IF EXISTS PARTITION (pt=${before6day});

CREATE TABLE IF NOT EXISTS dim_thirdsystem_d_f(
    stat_date                             STRING COMMENT'统计日期',
    dw_ins_time                           STRING COMMENT'插入时间',

    thirdsystem_id                         INT    COMMENT'第三方票务系统id',
    thirdsystem_name                       string COMMENT'第三方票务系统名称',
    thirdsystem_ver_name                   string COMMENT'第三方票务系统版本名称',
    connect_type                           string COMMENT'对接类型 票付通/九天闸机/第三方/开放接口',
    thirdsystem_type                       string COMMENT'是团购网  团购网/非团购',
    thirdsystem_coopB                      int    COMMENT'第三方系统标识',
    thirdsystem_create_time                string comment '创建时间'

 )COMMENT'对接系统'PARTITIONED BY(
    pt INT 
 )STORED AS ORC;


INSERT OVERWRITE   TABLE dim_thirdsystem_d_f PARTITION(pt=${ds})
SELECT
        ${ds}       as stat_date,
        current_date                as dw_ins_time,

        c.id                          as thirdsystem_id,
        if(isnull(t.system_name),c.name,t.system_name)                 as thirdsystem_name,
        c.name                        as thirdsystem_ver_name,
        c.sourceT                     as connect_type            ,
        c.system_type                 as thirdsystem_type       ,
        c.coopB                       as thirdsystem_code        ,
        from_unixtime(c.create_time)  as thirdsystem_create_time

from (select * from ods_pft_con_sys_d_f where pt='${ds}') c
left join (select * from ods_third_purchase_system_d_f where pt='${ds}') t on t.coopB=c.coopB
;
