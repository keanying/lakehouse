--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-01 15:22:46
--EMR任务只能运行在独享资源组上
--********************************************************************--


create table if NOT EXISTS dim_user_datav_d_f(
    stat_date              STRING COMMENT "统计日期",
    dw_ins_time            STRING COMMENT "数据插入日期",

    user_id                INT        COMMENT "用户id",    
    account                string     COMMENT "账号",    
    certificate            string     COMMENT "密码（2次MD5加密）",
    capacity               int        COMMENT "景区最大接待人数",    
    dataV_token            string     COMMENT "景区大屏用户token",    
    dataV_title            string     COMMENT "景区大屏名称",    
    dataV_index_url        string     COMMENT "景区大屏首页url",    
    dataV_sale_analyst_url  string     COMMENT "景区大屏销售分析url",    
    dataV_tourist_url       string     COMMENT "景区大屏游客画像url",    
    dataV_analyst_url       string     COMMENT "景区大屏客流分析url",    
    12301_data_secret_code    string     COMMENT "12301大数据分析用户token",    
    park_entry_land_id      int        COMMENT "12301大数据分析：闸机出入园统计景区id"  

)COMMENT'平台员工维表'PARTITIONED BY(
    pt STRING  
 )STORED AS ORC;

INSERT OVERWRITE TABLE dim_user_datav_d_f PARTITION (pt="${ds}") 
select 
    ${ds}       as stat_date,
    current_date                as dw_ins_time,

    user_id                     as user_id,
    account                     as account,
    certificate                 as certificate,
    capacity                    as capacity,
    DataV_token                 as dataV_token,
    land_name                   as dataV_title,
    `index`                     as dataV_index_url,
    sale                        as dataV_sale_analyst_url,
    tourist                     as dataV_tourist_url,
    analyst                     as dataV_analyst_url,
    secret_code                 as 12301_data_secret_code,
    land_id                     as park_entry_land_id

from  ods_datav_auth_d_f where pt="${ds}" 
;
