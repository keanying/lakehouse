--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-07 19:16:48
--EMR任务只能运行在独享资源组上
--********************************************************************--

create table if NOT EXISTS dim_distributor_group_d_f(
    stat_date              STRING COMMENT "统计日期",
    dw_ins_time            STRING COMMENT "数据插入日期",

    supplier_id            INT    COMMENT "供应商id",    
    supplier_name          string COMMENT "供应商账户名称",    
    supplier_company_name  string COMMENT "供应商企业名称",
    supplier_type          string COMMENT "供应商类型",
    supplier_is_OTA        string COMMENT "供应商是否OTA",
        
    distributor_group         INT    COMMENT "分销商组ID", 
    distributor_group_name    string COMMENT "分销商组名称", 
    distributor_id            INT    COMMENT "分销商id",
    distributor_name          string    COMMENT "分销商账户名称",
    distributor_company_name  string    COMMENT "分销商企业名称",
    distributor_type          string    COMMENT "分销商类型",
    distributor_is_OTA        string COMMENT "分销商是否OTA"

)COMMENT'分销商分组'PARTITIONED BY(
    pt STRING  
 )STORED AS ORC;

-- 分销商在多个分组时，取id大的组
INSERT OVERWRITE TABLE dim_distributor_group_d_f PARTITION (pt="${ds}") 
select 
     ${ds}     as stat_date,
    current_date              as dw_ins_time,

    g.sid                     as supplier_id,
    su.user_name              as supplier_name,
    su.user_company_name      as supplier_company_name,
    su.user_type              as supplier_type,
    su.user_is_OTA            as supplier_is_OTA,

    g1.id                     as distributor_group,
    g1.group_name             as distributor_group_name,
    g.fid                     as distributor_id,
    dis.user_name             as distributor_name,
    dis.user_company_name     as distributor_company_name,
    dis.user_type             as distributor_type,
    dis.user_is_OTA           as distributor_is_OTA

from (select sid,fid,max(group_id) max_id  from ods_pft_evolute_group_fid_d_f where pt= ${ds} 
      group by sid,fid ) as g
join  (select id,group_name from ods_pft_evolute_group_d_f where pt= ${ds} ) g1 on g1.id=g.max_id
left join (select user_id,user_company_name,user_name,user_type,user_is_OTA from dim_user_d_f where pt= ${ds}) as su on su.user_id=g.sid
left join (select user_id,user_company_name,user_name,user_type,user_is_OTA from dim_user_d_f where pt= ${ds} ) as dis on dis.user_id=g.fid
;
