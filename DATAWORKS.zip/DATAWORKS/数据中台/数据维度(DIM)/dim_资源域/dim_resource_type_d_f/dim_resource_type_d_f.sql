--@exclude_input=default_workspace_svwh.default.ods_bi_business_dim_resource_type_d_f
--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-07-31 18:11:05
--EMR任务只能运行在独享资源组上
--********************************************************************--
-- desc 资源维表
-- alter table dim_resource_type_d_f         DROP IF EXISTS PARTITION (pt=${before6day});


CREATE TABLE if not EXISTS  dim_resource_type_d_f(
    stat_date                STRING COMMENT"统计日期",
    dw_ins_time              STRING COMMENT"数据插入日期",

    resource_type            STRING COMMENT"资源类型",
    resource_type_name       STRING COMMENT"资源类型名称"
 )COMMENT'资源类型维表'PARTITIONED BY(
    pt STRING
 )STORED AS ORC;

INSERT OVERWRITE TABLE dim_resource_type_d_f PARTITION(pt=${ds}) 
select
        ${ds}      as  stat_date,
        current_date               as  dw_ins_time,

        rt.resource_type           as  resource_type,
        rt.resource_type_name      as  resource_type_name
from (select * from  ods_bi_business_dim_resource_type_d_f l   where pt=${ds}  ) rt

