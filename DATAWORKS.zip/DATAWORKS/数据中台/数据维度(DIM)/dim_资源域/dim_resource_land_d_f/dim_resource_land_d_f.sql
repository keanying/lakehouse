--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-05 15:12:21
--EMR任务只能运行在独享资源组上
--********************************************************************--


CREATE TABLE IF NOT EXISTS dim_resource_land_d_f(
    stat_date               STRING COMMENT'统计日期',
    dw_ins_time             STRING COMMENT'插入时间',

    resource_land_id        INT     COMMENT'资源ID',
    resource_land_name      STRING  COMMENT'资源名称',
    resource_type_name      string  COMMENT'资源类型',
    resource_land_level     STRING  COMMENT'资源级别',
    address                 STRING  COMMENT'地址',
    publisher_id            STRING  COMMENT'供应商id',

    area_code               string  COMMENT'区域代码',
    resource_province       string  COMMENT'省',
    resource_city           string  COMMENT'市',
    lng                     STRING  COMMENT'经度',
    lat                     STRING  COMMENT'纬度',
    topic                   STRING  COMMENT'旅游主题',
    oversea                 string  comment '境内外  0：境内,1:境外',

    is_del                  string  COMMENT'是否删除？ 0：否1：是'

 )COMMENT'业态景区表'PARTITIONED BY(
    pt INT 
 )STORED AS ORC;

INSERT OVERWRITE   TABLE dim_resource_land_d_f PARTITION(pt='${ds}')
SELECT /*+ mapjoin(rt)*/
        '${ds}'     as stat_date,
        current_date                as dw_ins_time,

        r.id                        as  resource_land_id,
        r.title                     as  resource_land_name,
        rt.resource_type_name       as  resource_type_name,
        r.jtype                     as  resource_level,
        r.address                   as  address,
        r.apply_did                 as  publisher_id,

        concat(r.province,'|',r.municipality,'|',r.oversea)                      as  area_code,
        c.province_name             as  resource_province,
        c.city_name                 as  resource_city,
        substr(r.lng_lat_pos,1,locate(',',r.lng_lat_pos,1)-1)                       as  lng,
        substr(r.lng_lat_pos,locate(',',r.lng_lat_pos,1)+1,50)                      as  lat,
        r.topic                     as  topic,
        r.oversea                   as oversea,

        r.is_del                    as is_del
from (select * from ods_pft_management_land_d_f where pt ="${ds}") r
left join (select * from dim_resource_type_d_f where pt ="${ds}") rt on rt.resource_type=r.mtype
left join  (select * from dim_city_d_f where pt="${ds}") c on c.province_code=r.province  and c.city_code=r.municipality
;

