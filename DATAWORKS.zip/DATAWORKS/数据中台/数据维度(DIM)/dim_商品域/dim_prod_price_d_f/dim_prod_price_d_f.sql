--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-04 15:20:44
--EMR任务只能运行在独享资源组上
--********************************************************************--
--drop table if exists dim_prod_price_d_f;
--alter table dim_prod_price_d_f         DROP IF EXISTS PARTITION (pt=${before6day});


CREATE TABLE IF NOT EXISTS dim_prod_price_d_f(
  stat_date            STRING COMMENT '统计日期',
  dw_ins_time          STRING COMMENT '插入时间',

  ticket_id            INT    COMMENT '票ID',

  ptype                STRING COMMENT '价格类型，1：特殊，0：平日',
  cost_price           STRING COMMENT '成本价',
  sale_price           STRING COMMENT '零售价',

  start_date           STRING COMMENT '开始日期',
  end_date             STRING COMMENT '结束日期',
  status               int    COMMENT '状态:0=未审核,1=被拒绝,2=已通过',
  weekdays             STRING COMMENT '适用日期[例如：0,1,2,3,4,5,6],0=周日，1=周一...',
  update_time          string COMMENT '更新时间',

  curr_price_rank       int    comment '今日价格 优先顺序，1=今日价格'

)COMMENT '商品(票)价格维表' PARTITIONED BY(
  pt int
)STORED AS ORC;


INSERT OVERWRITE    TABLE dim_prod_price_d_f PARTITION(pt=${ds}) 
SELECT 
      stat_date,
      dw_ins_time,
      
      ticket_id,
      ptype,
      
      cost_price,
      sale_price,
      
      start_date,
      end_date,
      status,
      weekdays,
      
      update_time,

      row_number() over(partition by ticket_id order by period_type desc,current_date_diff,ptype desc) as curr_price_rank
from (
      SELECT  
              ${ds}           as stat_date,
              current_date                    as dw_ins_time,
      
              ticket_id                       as ticket_id,
              ptype,
      
              if(ptype=1,s_price,n_price)     as cost_price,
              l_price                         as sale_price,
      
              start_date                      as start_date,
              end_date                        as end_date,
              status                          as status,
              weekdays                        as weekdays,
      
              from_unixtime(update_time)     as update_time,

              CASE 
                 WHEN  start_date<=current_date and current_date<date_add(end_date,1)
                      and weekdays like concat('%',pmod(floor((unix_timestamp(current_date)-unix_timestamp('1970-01-05 00:00:00'))/(3600*24))+1,7) ,'%')    then 3
                 WHEN start_date<=current_date and current_date<date_add(end_date,1)          then 2
                 WHEN current_date<=date_add(end_date,1)                                      then 1
                 else 0
              end                                             as period_type,

              abs(datediff(end_date,current_date))            as current_date_diff
      
      
      from ods_uu_product_price_d_f
      where pt=${ds} 
      )
;


-- select *
-- --                 row_number() over(partition by ticket_id order by if(datediff(end_date,current_date)>=0,if(datediff(start_date,current_date)<=0,2,1),0) desc,abs(datediff(end_date,current_date)),ptype desc) as rn 
-- from dim_prod_price_d_f 
-- where pt=20220110 and ticket_id=1286789
