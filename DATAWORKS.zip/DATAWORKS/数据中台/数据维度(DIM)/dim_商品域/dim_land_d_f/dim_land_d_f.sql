--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-07 18:21:29
--EMR任务只能运行在独享资源组上
--********************************************************************--

CREATE TABLE IF NOT EXISTS dim_land_d_f(
    stat_date               STRING  COMMENT'统计日期',
    dw_ins_time             STRING  COMMENT'插入时间',
    land_id                 INT     COMMENT'景区ID',
    land_name               STRING  COMMENT'景区名称',
    land_status_code        TINYINT COMMENT'景区状态编码',
    land_status             STRING  COMMENT'景区状态',
    land_publisher_id       INT     COMMENT'景区发布商ID',
    land_publisher_name     STRING  COMMENT'景区发布商账户名称',
    land_type_code          STRING  COMMENT'景区类型编码',
    land_type_name          STRING  COMMENT'景区类型',
    land_level_code         STRING  COMMENT'景区级别编码',
    land_level              STRING  COMMENT'景区级别',
    land_topic              STRING  COMMENT'主题列表第一个主题',
    land_area_code          string  COMMENT '景区区域代码',
    land_province_code      SMALLINT    COMMENT'景区省编码',
    land_city_code          SMALLINT    COMMENT'景区城市编码',
    land_country_code       SMALLINT    COMMENT'景区区县编码',
    land_province           STRING  COMMENT'景区省名称',
    land_city               STRING  COMMENT'景区城市名称',
    land_country            STRING  COMMENT'景区区县名称',
    land_lng                STRING  COMMENT'景区经度',
    land_lat                STRING  COMMENT'景区维度',
    land_zip_code           STRING  COMMENT'景区市邮政编码',
    land_province_adcode    STRING  COMMENT'景区省邮政编码',
    resource_id             INT     COMMENT'资源ID',
    resource_name           STRING  COMMENT'资源名称',
    land_is_test            STRING  COMMENT '是否测试？',
    supply_type             STRING  COMMENT '供应类型：自动拉取/手动供应',
    resource_land_id        INT     COMMENT '业态景区id',
    resource_land_name      INT     COMMENT '业态景区名称',
    land_topics             STRING  COMMENT '主题列表',
    belong_area             STRING  COMMENT '归属区域',
    resource_land_add_time  STRING  COMMENT '业态景区关联时间'
)COMMENT '景区维表' PARTITIONED BY(
   pt INT 
)STORED AS ORC;

INSERT OVERWRITE TABLE dim_land_d_f PARTITION(pt=${ds})
SELECT   
    /*+mapjoin(rt,c) */
    ${ds}       AS stat_date,
    CURRENT_DATE                AS dw_ins_time,
    
    l.id                        AS land_id,
    l.title                     AS land_name,
    l.status                    AS land_status_code,
    CASE l.status                                                                
        WHEN 1 THEN '上架'                                                                
        WHEN 2 THEN '下架'                                                                
        WHEN 3 THEN '删除'                                                              
        ELSE  '新增'                                             
    END                         AS land_status,
    l.apply_did                 AS land_publisher_id,
    u.user_name                 AS land_publisher_name,

    l.p_type                    AS land_type_code,
    rt.resource_type_name       AS land_type_name,

    l.jtype                     AS land_level_code,
    IF(l.jtype IN ('0', ''), '其他', l.jtype)                     
                                AS land_level,
    IF(ISNULL(topic.land_topic_name), l.land_topic, topic.land_topic_name)  
                                AS land_topic,
    l.area                      AS land_area_code,
    -- SUBSTR(l.area, 1, LOCATE('|', l.area) - 1)                                                               
    --                             AS land_province_code,
    
    -- 增强版：处理非数字情况（返回 NULL 或默认值）
    CAST(
        CASE 
            WHEN SUBSTR(l.area, 1, LOCATE('|', l.area) - 1) REGEXP '^[0-9]+$' 
            THEN SUBSTR(l.area, 1, LOCATE('|', l.area) - 1) 
            ELSE NULL  -- 或默认省份编码，如 0
        END AS SMALLINT
    ) AS land_province_code,

    -- SUBSTR(l.area, LOCATE('|', l.area) + 1 , LOCATE('|', SUBSTR(l.area, LOCATE('|', l.area) + 1, 20)) - 1)            
    --                             AS land_city_code,
    CAST(
        CASE 
            -- 校验截取结果是否为纯数字
            WHEN SUBSTR(l.area, LOCATE('|', l.area) + 1 , LOCATE('|', SUBSTR(l.area, LOCATE('|', l.area) + 1, 20)) - 1) REGEXP '^[0-9]+$' 
            THEN SUBSTR(l.area, LOCATE('|', l.area) + 1 , LOCATE('|', SUBSTR(l.area, LOCATE('|', l.area) + 1, 20)) - 1) 
            ELSE NULL  -- 非数字则返回 NULL（避免转换失败）
        END AS SMALLINT
    ) AS land_city_code,

    -- SUBSTR(l.area, LOCATE('|', l.area, LOCATE('|', l.area) + 1) + 1, 6)                                          
    --                             AS land_country_code,
    CAST(
        CASE 
            WHEN SUBSTR(l.area, LOCATE('|', l.area, LOCATE('|', l.area) + 1) + 1, 6) REGEXP '^[0-9]+$' 
            THEN SUBSTR(l.area, LOCATE('|', l.area, LOCATE('|', l.area) + 1) + 1, 6) 
            ELSE NULL 
        END AS SMALLINT
    ) AS land_country_code,

    p.province_name             AS land_province,
    c.city_name                 AS land_city,
    c.country_name              AS land_country,
    c.lng                       AS land_lng,
    c.lat                       AS land_lat,
    c.zip_code                  AS land_zip_code,
    c.province_adcode           AS land_province_adcode,
    l.resourceID                AS resource_id,
    -- r.resource_name             AS resource_name,
    ''                          AS resource_name,
    IF(l.title LIKE '%测试%' OR l.title LIKE '%压测%' OR u.user_is_test='测试','测试','正式')             
                                    AS land_is_test,
    IF(is_resource_center_auto_get_user = '是', '自动拉取', '手动供应')              
                                AS supply_type,

    mr.mt_id                    AS resource_land_id,
    -- rl.resource_land_name       AS resource_land_name,
    -- 仅当 resource_land_name 是纯数字字符串时可用
    CAST(rl.resource_land_name AS INT) AS resource_land_name,
    l.topic                     AS land_topics,
    di.district                 AS belong_area,
    mr.create_time              AS resource_land_add_time
FROM 
(
    SELECT id, title, status, apply_did, p_type, jtype, area, resourceID, SPLIT(topic, ",")[0] AS land_topic,topic 
    FROM ods_uu_land_d_f 
    WHERE pt ='${ds}' 
) AS l   
-- LEFT JOIN 
-- (
--     SELECT resource_id, resource_name, is_test 
--     FROM dim_resource_d_f 
--     WHERE pt ='${ds}'
-- ) AS r   
-- ON r.resource_id = l.resourceID   
LEFT JOIN 
(
    SELECT resource_type, resource_type_name 
    FROM dim_resource_type_d_f 
    WHERE pt ='${ds}'
) AS rt   
ON rt.resource_type = l.p_type   
LEFT JOIN 
(
    SELECT user_id, user_name, user_is_test, is_resource_center_auto_get_user 
    FROM dim_user_d_f 
    WHERE pt ='${ds}'
) AS u    
ON u.user_id = l.apply_did                                                                           
LEFT JOIN 
(
    SELECT * 
    FROM dim_city_d_f 
    WHERE pt = '${ds}'
) AS c 
-- ON c.area_code=l.area
ON c.area_code = CAST(
    SUBSTR(l.area, LOCATE('|', l.area) + 1 , LOCATE('|', SUBSTR(l.area, LOCATE('|', l.area) + 1, 20)) - 1) 
    AS SMALLINT
)
LEFT JOIN 
(
    select DISTINCT province_code, province_name 
    from dim_city_d_f 
    where pt ='${ds}'
) AS p 
ON p.province_code = CAST(SUBSTR(l.area, 1, LOCATE('|', l.area) - 1) AS SMALLINT)
LEFT JOIN 
(
    SELECT * 
    FROM dim_land_topic_d_f 
    WHERE pt ='${ds}'
) AS topic  
ON topic.land_topic = l.land_topic 
LEFT JOIN 
(
    SELECT pmr.land_id,pmr.mt_id,pmr.create_time 
    FROM (SELECT * FROM ods_pft_management_resource_d_f WHERE pt ='${ds}') AS pmr
    JOIN (SELECT land_id,MAX(id) max_id FROM ods_pft_management_resource_d_f WHERE pt ='${ds}' GROUP BY land_id) AS pmr2 
    ON pmr2.max_id = pmr.id
) AS mr 
ON mr.land_id = l.id                                
LEFT JOIN 
(
    SELECT * 
    FROM dim_resource_land_d_f 
    WHERE pt ='${ds}'
) AS rl 
ON rl.resource_land_id = mr.mt_id 
-- 关联归属区域
LEFT JOIN dim_resource_center_district_o_f AS di 
ON p.province_name=di.province


