--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-07 19:05:14
--EMR任务只能运行在独享资源组上
--********************************************************************--


CREATE TABLE IF NOT EXISTS dim_prod_d_f(
  stat_date            STRING COMMENT '统计日期',
  dw_ins_time          STRING COMMENT '插入时间',

  product_id           INT COMMENT '产品ID',
  ticket_id            INT COMMENT '票ID',
  ticket_name          STRING COMMENT '票名称',
  ticket_fullname      STRING COMMENT '票全称=景区名称+“-”+票名称',
  ticket_status_code   TINYINT COMMENT '票状态编码',
  ticket_status        STRING COMMENT '票状态',
  ticket_max_expiration_date  string comment '票最大过期日期',
  ticket_update_time   string comment '创建/更新时间',

  resource_id          INT COMMENT '资源ID',
  resource_name        STRING COMMENT '资源名称',

  land_id              INT COMMENT '景区ID',
  land_name            STRING COMMENT '景区名称',
  land_status_code     TINYINT COMMENT '景区状态编码',
  land_status          STRING COMMENT '景区状态',
  land_publisher_id    INT COMMENT '景区发布商ID',
  land_publisher_name  STRING COMMENT '景区发布商账户名称',

  land_zip_code        string   comment'景区邮政编码',
  land_area_code       string COMMENT '景区区域编码',
  land_province_code   SMALLINT COMMENT '景区省编码',
  land_city_code       SMALLINT COMMENT '景区城市编码',
  land_country_code    SMALLINT COMMENT '景区区县编码',
  land_province        STRING COMMENT '景区省名称',
  land_city            STRING COMMENT '景区城市名称',
  land_country         STRING COMMENT '景区区县名称',
  land_lng             string   comment'景区经度',
  land_lat             string   comment'景区维度',

  land_type_code       STRING COMMENT '景区类型编码',
  land_type_name       STRING COMMENT '景区类型',
  land_level_code      STRING COMMENT '景区级别编码',
  land_level           STRING COMMENT '景区级别',
  land_topic           STRING COMMENT '景区主题',

  ticket_is_test       string COMMENT '是否测试票？',

  resource_land_id     int comment '业态景区id',
  resource_land_name   string comment '业态景区名称',

  land_topic_list      string comment '主题列表',
  belong_area          string comment '归属区域',
  resource_land_add_time  string comment '业态景区关联时间'


)COMMENT '商品(票)维表' PARTITIONED BY(
  pt int
)STORED AS ORC;


INSERT OVERWRITE    TABLE dim_prod_d_f PARTITION(pt=${ds}) 
SELECT  /*+mapjoin(c)*/
        ${ds}           as stat_date,
        current_date                    as dw_ins_time,

        t.pid                           as product_id,
        t.id                            as ticket_id,
        t.title                         as ticket_name,
        CONCAT(l.land_name,"-",t.title) as ticket_fullname,
        t.status                        as ticket_status_code,
        case 
           when t.status in (3,6)  then '删除'
           when t.max_expiration_date<current_date then '过期'
           when t.status=1 and l.land_status_code=1 then '上架'
           when t.status=2 or l.land_status_code=2 then '下架'
           else  '新增状态'
        end                            as ticket_status,
       t.max_expiration_date           as ticket_max_expiration_date,
       from_unixtime(t.update_time)    as ticket_update_time,

       l.resource_id                   as resource_id,
       l.resource_name                 as resource_name,

       l.land_id                       as land_id,
       l.land_name                     as land_name,
       l.land_status_code              as land_status_code,
       l.land_status                   as land_status,
      --  case l.status
      --      when 1 then '上架'
      --      when 2 then '下架'
      --      when 3 then '删除'
      --      else  '新增'
      --   end  land_status,   -- ,decode(l.status,'1','上架','2','下架','3','删除','新增')  land_status,

       l.land_publisher_id             as land_publisher_id,
       l.land_publisher_name           as land_publisher_name,

       l.land_zip_code                 as land_zip_code,
       l.land_area_code                as land_area_code,
       l.land_province_code            as land_province_code,
       l.land_city_code                as land_city_code,
       l.land_country_code             as land_country_code,
       l.land_province                 as land_province,
       l.land_city                     as land_city,
       l.land_country                  as land_country,
       l.land_lng                      as land_lng,
       l.land_lat                      as land_lat,

       l.land_type_code                as land_type_code,
       l.land_type_name                as land_type_name,
      --  case l.p_type
      --     when 'A' then '景区' 
      --     when 'B' then '线路' 
      --     when 'C' then '酒店' 
      --     when 'F' then '套票' 
      --     when 'G' then '餐饮' 
      --     when 'I' then '年卡' 
      --     when 'H' then '演出' 
      --     when 'J' then '特产' 
      --     when 'K' then '计时产品'
      --     when '' then '空数据'
      --     else '新类型' 
      --   end land_type,
       l.land_level_code              as land_level_code,
       l.land_level                   as land_level,
       l.land_topic                   as land_topic,

      if(t.title like '%测试%' or l.land_is_test='测试','测试','正式')                as ticket_is_test,

      l.resource_land_id              as resource_land_id,
      l.resource_land_name            as resource_land_name,

      l.land_topics                   as land_topic_list,
      l.belong_area                   as belong_area,
      l.resource_land_add_time

from (select id,pid,landid,title,status,max_expiration_date,update_time 
      from   ods_uu_jq_ticket_d_f 
      where  pt = ${ds}
      ) t      
left join (select *  from dim_land_d_f  where pt = ${ds}) l on l.land_id=t.landid
;

-- select count(*)
-- from dim_prod_d_f
-- where   pt ="${ds}" and land_publisher_id=4 and quarter(from_unixtime(ticket_update_time))=quarter(current_date) and year(from_unixtime(ticket_update_time))=year(current_date)