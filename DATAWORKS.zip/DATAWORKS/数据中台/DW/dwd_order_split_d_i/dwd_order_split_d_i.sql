--@exclude_input=7098992821964577940
--@exclude_input=7754045688226130304
--@exclude_input=6728476340022401733
--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-08 16:53:38
--EMR任务只能运行在独享资源组上
--********************************************************************--

-- SET spark.sql.mode = PERMISSIVE;
-- SET spark.sql.legacy.typeCoercion.mode = LEGACY;
-- SET spark.sql.caseSensitive = false;

-- SET spark.sql.ansi.enabled = false;

CREATE TABLE IF NOT EXISTS dwd_order_split_d_i (
    stat_date               STRING  COMMENT '统计日期',
    dw_ins_time             STRING  COMMENT '插入时间',
    order_id                STRING  COMMENT '订单号',
    main_order_id           STRING  COMMENT '主票id',
    order_type              STRING  COMMENT '订单类型 套票主票/套票子票/单票',
    remote_order_id         STRING  COMMENT '远程订单号',
    is_team                 TINYINT COMMENT '是否为团队订单：0否 1是',
    team_order_id           STRING  COMMENT '团队订单号',
    order_status_code       INT     COMMENT '订单状态编码',
    order_status            STRING  COMMENT '订单状态',
    order_pay_status        INT     COMMENT '订单支付状态:0=现场支付,1=已支付,2=未支付', 
    booking_time            STRING  COMMENT '下单时间',
    verify_time             STRING  COMMENT '验证时间,注意在原dwd_order_d_f表中为vertify_time',
    cancel_time             STRING  COMMENT '取消时间',
    play_time               STRING  COMMENT '预计游玩时间',
    begin_time              STRING  COMMENT '开始时间',
    end_time                STRING  COMMENT '结束时间', 
    pre_booked_days         INT     COMMENT '提前预定天数', 
    verify_code             INT     COMMENT '核销码,注意在原dwd_order_d_f表中为vertify_code',
    cancel_status           STRING  COMMENT '退票状态:0=未审核,1=同意,2=拒绝,3=等待第三方平台审核通过', 
    apply_did               STRING  COMMENT '顶级供应商id',
    booker_id               STRING  COMMENT '购买者', 
    booker_name             STRING  COMMENT '购买者名称', 
    booker_type             STRING  COMMENT '购买者身份',
    distribute_system_type  STRING  COMMENT '对接分销平台类型',
    distribute_system_name  STRING  COMMENT '对接分销平台名称',
    booking_channel         STRING  COMMENT '销售渠道ID',
    booking_channel_name    STRING  COMMENT '销售渠道名称',
    distribute_num          INT     COMMENT '总分销级别', 
    distributor_id          INT     COMMENT '一级分销商id', 
    distributor_name        STRING  COMMENT '一级分销商企业名称', 
    distributor_type        STRING  COMMENT '一级分销商类型', 
    distributor_group       STRING  COMMENT '一级分销商分组', 
    distributor_is_OTA      STRING  COMMENT '用户对接分销平台？',
    distribute_1_type       STRING  COMMENT '一级分销类型',
    distributor_price       INT     COMMENT '一级分销价', 
    distributor_amount      BIGINT  COMMENT '一级分销商支付金额', 
    booking_price           INT     COMMENT '售价',
    ticket_num              INT     COMMENT '票数',
    order_pay_amount        BIGINT  COMMENT '订单支付金额',
    use_coupon              STRING  COMMENT '是否使用优惠券，0正常1使用优惠价支付2修改过的订单' ,
    non_refund_withdraw     STRING  COMMENT '是否下单不可退而且可提现的订单 1=是，0=不是',
    pay_funding_type        INT     COMMENT '付款资金账户类型', 
    ticket_taker_name       STRING  COMMENT '取票人姓名', 
    ticket_taker_mobile     STRING  COMMENT '取票人手机号',
    ticket_taker_idcard     STRING  COMMENT '取票人身份证', 
    ticket_taker_age        INT     COMMENT '取票人年龄',
    ticket_taker_sex        STRING  COMMENT '取票人性别', 
    ticket_taker_province   STRING  COMMENT '取票人所在省-活动地归属',
    ticket_taker_city       STRING  COMMENT '取票人所在市-活动地归属',
    ticket_taker_country    STRING  COMMENT '取票人所在县-活动地归属',    
    ticket_zip_code         INT     COMMENT '取票人邮编',
    ticket_taker_adcode     INT     COMMENT '取票人行政编码',
    is_around               INT     COMMENT '是否周边游 0=周边游，1=国内游',
    land_type               STRING  COMMENT '景区类型代码：A景区B线路C酒店F套票G餐饮I年卡H演出J特产K计时产品',
    land_type_name          STRING  COMMENT '景区类型：A景区B线路C酒店F套票G餐饮I年卡H演出J特产K计时产品',
    land_topic              STRING  COMMENT '景区主题类型',
    resource_id             INT     COMMENT '资源ID',
    resource_name           STRING  COMMENT '资源名',
    product_id              INT     COMMENT '产品id',
    ticket_id               INT     COMMENT '票id',
    ticket_fullname         STRING  COMMENT '票名',
    land_id                 INT     COMMENT '景区id',
    land_name               STRING  COMMENT '景区名',
    land_publisher_id       INT     COMMENT '景区发布商id',
    land_publisher_name     STRING  COMMENT '景区名'  ,
    land_province           STRING  COMMENT '景区所在省',
    land_city               STRING  COMMENT '景区城市名称',    
    land_country            STRING  COMMENT '景区区县名称',
    land_zip_code           STRING  COMMENT '景区邮编',
    land_adcode             INT     COMMENT '景区行政编码',
    order_is_test               STRING  COMMENT '测试订单？ 正式/测试（测试账号发布，景区名称包含测试）',
    resource_center_supplier_id INT     COMMENT '资源中心 供应产品商户',
    resource_center_purchase_id INT     COMMENT '资源中心 采购产品商户',
    mall_supplier_account_id    INT     COMMENT '微商城 商户id',
    mall_distinguish            STRING  COMMENT '区分新旧版 005为新版微商城003为旧版微商城',
    purchase_system             STRING  COMMENT '对接采购平台名称',
    purchase_system_code        STRING  COMMENT '对接采购平台编码',
    booking_num                 INT     COMMENT '预定数',
    add_ticket_time             STRING  COMMENT '添加票时间',
    add_ticket_num              INT     COMMENT '添加票数',
    booking_pay_amount          BIGINT  COMMENT '预定金额',
    record_id                   INT     COMMENT '记录id',
    resource_land_id            INT     COMMENT '业态景区id',
    resource_land_name          STRING  COMMENT '业态景区名称',
    ticket_taker_province_idcard    STRING  COMMENT '取票人所在省-身份证号归属', 
    ticket_taker_city_idcard        STRING  COMMENT '取票人所在市-身份证号归属', 
    ticket_taker_county_idcard      STRING  COMMENT '取票人所在县-身份证号归属' ,
    pay_time            TIMESTAMP   COMMENT '支付时间',
    expiration_time     DATE        COMMENT '过期日期=有效结束日期+1',
    booking_hour        INT     COMMENT '下单时间,小时,例如:8,15',
    booking_year        INT     COMMENT '下单时间,年,例如:2022',
    booking_month       INT     COMMENT '下单时间,年+月,例如:202203',
    -- booking_week        INT     COMMENT '下单时间,年+ISOweek,例如:202211',
    booking_quarter     INT     COMMENT '下单时间,年+季节,例如:202201',
    booking_date        STRING  COMMENT '下单时间',
    cancel_hour         INT     COMMENT '取消时间,小时 例如:8, 15',
    cancel_year         INT     COMMENT '取消时间,年,例如:2022',
    cancel_month        INT     COMMENT '取消时间,年+月,例如:202203',
    -- cancel_week         INT     COMMENT '取消时间,年+ISOweek,例如:202211',
    cancel_quarter      INT     COMMENT '取消时间,年+季节,例如:202201',
    cancel_date         STRING  COMMENT '下单时间',
    play_year           INT     COMMENT '预计游玩时间,年,例如:2022',
    play_month          INT     COMMENT '预计游玩时间,年+月,例如:202203',
    -- play_week           INT     COMMENT '预计游玩时间,年+ISOweek,例如:202211',
    play_quarter        INT     COMMENT '预计游玩时间,年+季节,例如:202201',
    play_date           STRING  COMMENT '预计游玩时间',
    pay_hour            INT     COMMENT '支付时间,小时 例如:8, 15',
    pay_year            INT     COMMENT '支付时间,年,例如:2022',
    pay_month           INT     COMMENT '支付时间,年+月,例如:202203',
    -- pay_week            INT     COMMENT '支付时间,年+ISOweek,例如:202211',
    pay_quarter         INT     COMMENT '支付时间,年+季节,例如:202201',
    pay_date            STRING  COMMENT '支付时间',
    expiration_year     INT     COMMENT '过期日期<有效结束日期+1>,年,例如:2022',
    expiration_month    INT     COMMENT '过期日期<有效结束日期+1>,年+月,例如:202203',
    -- expiration_week     INT     COMMENT '过期日期<有效结束日期+1>,年+ISOweek,例如:202211',
    expiration_quarter  INT     COMMENT '过期日期<有效结束日期+1>,年+季节,例如:202201',
    verify_date         STRING  COMMENT '验证日期',
    -- member_kind         STRING  COMMENT '商户类型',
    -- member_type         STRING  COMMENT '商户业态',
    original_order_amount   BIGINT      COMMENT '订单金额',
    visitors                TINYINT     COMMENT '订单客户类型：1=游客,2=分销商',
    sale_price              INT         COMMENT '实际售价',
    origin_num              BIGINT      COMMENT '原始票数',
    aids_buyer_id           INT         COMMENT '购买者id',
    aids_seller_id          INT         COMMENT '销售者id',  
    aids_level              INT         COMMENT '本笔分销层级原始字段 1/-1/2/0',    
    aids_buyername          STRING      COMMENT '购买者姓名', 
    aids_sellername         STRING      COMMENT '销售者姓名', 
    aids_sellerkind         INT         COMMENT '销售者类型', 
    aids_sellertype         INT         COMMENT '销售者业态',
    seller_group_id         INT         COMMENT '购买者账户分组',
    aids_buyerking          INT         COMMENT '购买者类型', 
    aids_buyertype          INT         COMMENT '购买者业态',
    detail_split_level      INT         COMMENT '本层具体分销层级[1-5]',
    is_end_level            INT         COMMENT '本层是否是分销链最后一级',
    is_test                 INT         COMMENT '是否测试商户1=true,0=false'
) COMMENT "订单分销维度表按下单日期分区"
PARTITIONED BY (
    `orderdate`             INT      COMMENT '下单日期'  
) STORED AS ORC;


DROP VIEW IF EXISTS dim_user_d_f_cache;
CACHE TABLE dim_user_d_f_cache
AS
SELECT 
    member.id               AS user_id,
    member.dtype            AS user_type_code,
    CASE member.dtype
        WHEN 0 THEN "供应商"
        WHEN 1 THEN "分销商"
        when 2 THEN "资源方"
        when 3 THEN "合并终端后的资源方"
        WHEN 5 THEN "普通用户"
        WHEN 6 THEN "员工"
        when 7 THEN "集团帐号"
        WHEN 9 THEN "平台管理员"
    END                     AS user_type,
    extinfo.com_name        AS user_company_name,
    member.dname            AS user_name, 
    member.group_id         AS group_id,
    extinfo.corp_kind       AS customer_type_code,
    extinfo.format_type     AS format_type,
    CASE
        WHEN member.id = 3034  THEN 'OTA'   --南京途牛
        WHEN member.dcodeURL <> '' THEN IF(ISNULL(distribute.distribute_system_type), '其他分销平台', distribute.distribute_system_type)
        ELSE NULL
    END                     AS distribute_system_type, 
    IF(
        member.id=3034, 
        '南京途牛', 
        distribute.distribute_system_name
    )                       AS distribute_system_name
FROM 
(
    SELECT id, dtype, dname, dcodeURL, group_id
    FROM s_myuu_pft_member_d_f
    WHERE pt = ${ds}
) AS member 
LEFT JOIN 
(
    SELECT fid, com_name, corp_kind, format_type
    FROM ods_myuu_pft_member_extinfo_d_f 
    WHERE pt = ${ds} 
) AS extinfo  
ON member.id = extinfo.fid
LEFT JOIN 
(
    SELECT distribute_system_type, distribute_system_name, dcodeurl_like 
    FROM ods_distribute_system_type_d_f 
    WHERE pt = ${ds}
) AS distribute 
ON member.dcodeURL LIKE CONCAT('%',distribute.dcodeurl_like,'%');


INSERT OVERWRITE TABLE dwd_order_split_d_i PARTITION (`orderdate` = ${ds}) 
SELECT 
    '${ds}'                                 AS `stat_date`,
    CURRENT_DATE()                          AS `dw_ins_time`,
    o.ordernum                              AS `order_id`,
    o.main_order_id                         AS `main_order_id`,
    o.order_type                            AS `order_type`,
    o.remotenum                             AS `remote_order_id`,
    IF(ISNOTNULL(o.team_order_id), 1, 0)    AS `is_team`,
    o.team_order_id                         AS `team_order_id`,
    o.status                                AS `order_status_code`,
    s.order_status_name                     AS `order_status`,
    o.pay_status                            AS `order_pay_status`,
    o.ordertime                             AS `booking_time`,        
    o.dtime                                 AS `verify_time`,
    o.ctime                                 AS `cancel_time`,
    o.playtime                              AS `play_time`,
    o.begintime                             AS `begin_time`,
    o.endtime                               AS `end_time`,
    DATEDIFF(TO_DATE(o.playtime),TO_DATE(o.ordertime))  AS `pre_booked_days`,        
    o.code                                  AS `verify_code`,
    o.cancel_status                         AS `cancel_status`,
    -- o.aid                                   AS `seller_id`,
    o.apply_did                             AS `apply_did`,
    o.member                                AS `booker_id`,
    u.user_name                             AS `booker_name`,
    u.user_type                             AS `booker_type`,
    -- 淘宝/飞猪 归为OTA
    IF(o.ordermode=17, 'OTA', u.distribute_system_type)         AS  `distribute_system_type`,
    IF(o.ordermode=17, '淘宝/飞猪', u.distribute_system_name)    AS  `distribute_system_name`,
    o.ordermode                             AS `booking_channel`,
    ch.channel_name                         AS `booking_channel_name`,
    oa.distribute_num                       AS `distribute_num`,
    oa.distributor_1_id                     AS `distributor_id`, 
    ud.user_company_name                    AS `distributor_name`, 
    ud.user_type                            AS `distributor_type`, 
    gr.distributor_group                    AS `distributor_group`, 
    ud.distribute_system_type               AS `distributor_is_OTA`,
    CASE
       WHEN oa.distribute_num=1 AND (u.user_type='普通用户' OR o.member=o.aid) AND o.ordermode<>17 THEN '直销'
       WHEN ud.distribute_system_type='OTA' OR (o.ordermode=17 AND oa.distributor_1_id=o.member)  THEN  'OTA'
       ELSE '分销'
    END                                     AS `distributor_1_type`,
    
    oa.distribute_1_price                   AS `distributor_price`, 
    oa.distribute_1_price*o.tnum            AS `distributor_amount`,

    o.tprice                                AS `booking_price`,
    dim_order.origin_num                    AS `ticket_num`,
    -- IF(
    --     o.status IN (3, 6, 9) 
    --         OR o.pay_status=2 
    --         OR (o.ordermode = 18 AND o.paymode = 13), 
    --     0, 
    --     o.totalmoney
    -- ) AS `order_pay_amount`,                       
    dim_order.pay_num * dim_order.sale_price   AS `order_pay_amount`,       
    o.onsale                                AS `use_coupon`,
    o.unionCheck                            AS `non_refund_withdraw`,                           
    o.paymode                               AS `pay_funding_type`,
    o.ordername                             AS `ticket_taker_name`,
    o.ordertel                              AS `ticket_taker_mobile`,
    o.personid                              AS `ticket_taker_idcard`,
    INT(IF(
        ISNOTNULL(o.personid),
        YEAR(CURRENT_DATE()) - SUBSTR(o.personid, 7, 4),
        -1 
    ))                                       AS `ticket_taker_age`,

    IF(
        ISNOTNULL(o.personid),
        IF(
            SUBSTR(o.personid, 17, 1) % 2 = 0,
            "女",
            "男"
        ),
        "未知"
    )                                       AS `ticket_taker_sex`,
    -- 优先级：报团>电话>身份证，需要考虑有报团信息和电话号码，但是归属地识别为空的情况。
    IF(
        ISNOTNULL(o.team_order_id) AND ISNOTNULL(o.team_province),
        o.team_province,
        IF(
            (ISNOTNULL(o.ordertel) OR o.ordertel != "") AND ISNOTNULL(cp.province_name), 
            cp.province_name,
            IF(
                ISNOTNULL(o.personid) OR o.personid != "",
                idc.province_name,
                "未知" 
            )
        )
    )                                               AS `ticket_taker_province`,
            
    -- 优先级：报团>电话>身份证，需要考虑有报团信息和电话号码，但是归属地识别为空的情况。
    IF(
        ISNOTNULL(o.team_order_id) AND ISNOTNULL(o.team_city),
        o.team_city,
        IF(
            (ISNOTNULL(o.ordertel) OR o.ordertel != "") AND ISNOTNULL(cp.city_name),
            cp.city_name,
            IF(
                ISNOTNULL(o.personid) OR o.personid != "",
                idc.city_name,
                "未知" 
            )
        )
    )                                               AS `ticket_taker_city`,


    IF(
        ISNOTNULL(o.personid) OR o.personid != "",
        idc.district_name,
        "未知" 
    )                                               AS `ticket_taker_country`,
            
    cp.zip_code                                     AS `ticket_zip_code`,
    idc.idcard                                      AS `ticket_taker_adcode`,
    IF(
        IF(
            ISNOTNULL(o.team_order_id),
            o.team_city,
            IF(
                ISNOTNULL(o.ordertel) OR o.ordertel != "",
                cp.city_name,
                IF(
                    ISNOTNULL(o.personid) OR o.personid != "",
                    idc.city_name,
                    "未知" 
                )
            )
        ) = prod.land_city,
        0,
        1
    )                                               AS `is_around`,

    -- 商品信息
    prod.land_type_code                                AS `land_type`,
    prod.land_type_name                                AS `land_type_name`,
    SPLIT(prod.land_topic,",")[0]                      AS `land_topic`,
    prod.resource_id                                   AS `resource_id`,
    prod.resource_name                                 AS `resource_name`,
    prod.product_id                                    AS `product_id`,
    o.tid                                              AS `ticket_id`,
    prod.ticket_fullname                               AS `ticket_fullname`,
    prod.land_id                                       AS `land_id`,
    prod.land_name                                     AS `land_name`,
    prod.land_publisher_id                             AS `land_publisher_id`,
    prod.land_publisher_name                           AS `land_publisher_name`,
    prod.land_province                                 AS `land_province`,
    prod.land_city                                     AS `land_city`,
    prod.land_country                                  AS `land_country`,
    prod.land_zip_code                                 AS `land_zip_code`,
    NULL                                                AS `land_adcode`,
    prod.ticket_is_test                                AS `order_is_test`,
    oa.resource_center_supplier_id                     AS `resource_center_supplier_id`,
    oa.resource_center_purchase_id                     AS `resource_center_purchase_id`,
    -1                                                 AS `mall_supplier_account_id`,
    ''                                                 AS `mall_distinguish`,
    th.third_name                                      AS `purchase_system`,
    th.third_coopB                                     AS `purchase_system_code`,
    o.booking_num                                      AS `booking_num`,
    o.add_ticket_time                                  AS `add_ticket_time`,
    o.add_ticket_num                                   AS `add_ticket_num`,
    -- o.tprice*o.booking_num                             AS `booking_pay_amount`,
    dim_order.origin_num * dim_order.sale_price        AS `booking_pay_amount`, 
    o.id                                               AS `record_id`,
    prod.resource_land_id                              AS `resource_land_id`,
    prod.resource_land_name                            AS `resource_land_name`,
    -- 游客归属 按照身份证号
    IF (ISNOTNULL(o.personid) OR o.personid != "", idc.province_name, "未知") AS `ticket_taker_province_idcard`, 
    IF (ISNOTNULL(o.personid) OR o.personid != "", idc.city_name, "未知") AS `ticket_taker_city_idcard`,
    IF (ISNOTNULL(o.personid) OR o.personid != "", idc.district_name, "未知") AS `ticket_taker_county_idcard`,
    TIMESTAMP(o.pay_time),
    o.expiration_time,   
    --下单时间系列
    HOUR(o.ordertime)                                               AS `booking_hour`,
    YEAR(o.ordertime)                                               AS `booking_year`,
    YEAR(o.ordertime) * 100 + MONTH(o.ordertime)                    AS `booking_month`,
    -- IF(o.ordertime IS NOT NULL, ISOWEEK_UDF(o.ordertime), '')       AS `booking_week`,
    YEAR(o.ordertime) * 100 + QUARTER(o.ordertime)                  AS `booking_quarter`,
    SUBSTR(o.ordertime, 0, 10)                                      AS `booking_date`,
    --取消时间系列
    HOUR(o.ctime)                                                   AS `cancel_hour`,
    YEAR(o.ctime)                                                   AS `cancel_year`,
    YEAR(o.ctime) * 100 + MONTH(o.ctime)                            AS `cancel_month`,
    -- IF(o.ctime IS NOT NULL, ISOWEEK_UDF(o.ctime), '')               AS `cancel_week`,
    YEAR(o.ctime) * 100 + QUARTER(o.ctime)                          AS `cancel_quarter`,
    SUBSTR(o.ctime, 0, 10)                                          AS `cancel_date`,
    --预计游玩时间系列
    YEAR(o.playtime)                                                AS `play_year`,
    YEAR(o.playtime) * 100 + MONTH(o.playtime)                      AS `play_month`,
    -- IF(o.playtime IS NOT NULL, ISOWEEK_UDF(o.playtime), '')         AS `play_week`,
    YEAR(o.playtime) * 100 + QUARTER(o.playtime)                    AS `play_quarter`,
    SUBSTR(o.playtime, 0, 10)                                       AS `play_date`,
    --支付时间系列
    HOUR(o.pay_time)                                                AS `pay_hour`,
    YEAR(o.pay_time)                                                AS `pay_year`,
    YEAR(o.pay_time) * 100 + MONTH(o.pay_time)                      AS `pay_month`,
    -- IF(o.pay_time IS NOT NULL, ISOWEEK_UDF(o.pay_time), '')         AS `pay_week`,
    YEAR(o.pay_time) * 100 + QUARTER(o.pay_time)                    AS `pay_quarter`,
    SUBSTR(o.pay_time, 0, 10)                                       AS `pay_date`,
    --过期时间系列
    YEAR(o.expiration_time)                                         AS `expiration_year`,
    YEAR(o.expiration_time) * 100 + MONTH(o.expiration_time)        AS `expiration_month`,
    -- IF(o.expiration_time IS NOT NULL, ISOWEEK_UDF(o.expiration_time), '')    AS `expiration_week`,
    YEAR(o.expiration_time) * 100 + QUARTER(o.expiration_time)      AS `expiration_quarter`,
    -- 验证时间
    SUBSTR(o.dtime, 0, 10)              AS `verify_date`,
    -- --商户类型
    -- business_message.corp_kind                                      AS `member_kind`,
    -- --商户业态
    -- business_message.format_type                                    AS `member_type`,
    --订单金额
    -- o.totalmoney                        AS `original_order_amount`,
    dim_order.pay_num * dim_order.sale_price    AS `original_order_amount`,
    o.visitors                          AS `visitors`,
    -- 实际售价
    -- order_apply.sale_price              AS `sale_price`,
    dim_order.sale_price                AS `sale_price`,
    -- 原始票数 
    order_apply.origin_num              AS `orgin_num`,
    --购买者id    
    order_split.buyerid                 AS `aids_buyer_id`,
    --销售者id    
    order_split.sellerid                AS `aids_seller_id`,
    --本笔分销层级，原始字段 1/-1/2/0   
    order_split.level                   AS `aids_level`,
    --购买者姓名       
    member_buyer_name.user_name         AS `aids_buyername`,
    --销售者姓名   
    member_seller_name.user_name        AS `aids_sellername`,  
    --销售者类型   
    member_seller_format.corp_kind      AS `aids_sellerkind`,  
    --销售者业态   
    member_seller_format.format_type    AS `aids_sellertype`,
    --购买者账户分组
    INT(member_buyer_format.group_id)        AS `seller_group_id`,
    --购买者公司类型
    member_buyer_format.customer_type_code AS `aids_buyerking`,
    --购买者公司业态
    member_buyer_format.format_type     AS `aids_buyertype`,
    --本层具体分销层级[1-5]
    order_split.detail_split_level      AS `detail_split_level`,
    --本层是否是分销链最后一级
    order_split.is_end_level            AS `is_end_level`,
    --是否为测试商户
    IF(member_group.group_id = 2, 1, 0) AS `is_test`
FROM 
(
    SELECT  
        order_table.id                  AS id,
        order_table.member              AS member,
        order_table.ordernum            AS ordernum,
        --团单信息
        IF(ISNOTNULL(team_table.son_order_id), 1, 0)    AS is_team,
        team_table.team_order_id        AS team_order_id,
        team_table.tourist_province     AS team_province,
        team_table.tourist_city         AS team_city,
        team_table.tourist_country      AS team_country,
        --套票信息
        order_table.main_order_id       AS main_order_id,
        order_table.order_type          AS order_type,
        order_table.remotenum           AS remotenum,
        order_table.lid                 AS lid,
        order_table.tid                 AS tid,
        order_table.aid                 AS aid,
        order_table.tnum                AS tnum,
        order_table.tprice              AS tprice,
        order_table.ordername           AS ordername,
        order_table.ordertel            AS ordertel,
        order_table.ordertime           AS ordertime,
        order_table.playtime            AS playtime,
        order_table.begintime           AS begintime,
        order_table.endtime             AS endtime,
        order_table.ctime               AS ctime,
        order_table.dtime               AS dtime,
        order_table.status              AS status,
        order_table.pay_status          AS pay_status,
        CASE cancel.dstatus
            WHEN 0 THEN '待审核'
            WHEN 1 THEN '同意'
            WHEN 2 THEN '拒绝'
            WHEN 3 THEN '等第三方平台审核'
        END                             AS cancel_status,       
        order_table.paymode             AS paymode,
        order_table.totalmoney          AS totalmoney,
        order_table.ordermode           AS ordermode,
        order_table.onsale              AS onsale,
        order_table.personid      	    AS personid,
        order_table.code                AS code,
        order_table.unionCheck          AS unionCheck,
        --未支付订单，预定数=0
        IF(
            order_table.pay_status < 2, 
            IF(order_track.booking_num > order_table.tnum, order_track.booking_num, order_table.tnum),
            0
        )       			            AS booking_num,
        order_track.add_ticket_time     AS add_ticket_time,
        order_track.add_ticket_num      AS add_ticket_num,
        -- 支付时间
        IF(
            order_table.pay_time != 0, 
            FROM_UNIXTIME(order_table.pay_time), 
            NULL
        )                               AS pay_time,
        -- 过期时间=有效期结束日期+1
        IF(
            order_table.status = 2, 
            DATE_ADD(TO_DATE(order_table.endtime), 1), 
            NULL
        )                               AS expiration_time,
        order_table.apply_did           AS apply_did,
        order_table.visitors            AS visitors
    FROM 
    (
        SELECT  
            IF(
                ISNOTNULL(addon_table.pack_order), 
                addon_table.pack_order, 
                order_table.ordernum
            )           AS main_order_id,
            CASE addon_table.ifpack
                WHEN 1  THEN '套票主票'
                WHEN 2  THEN '套票子票'
                ELSE '单票'
            END         AS order_type,
            order_table.*
        FROM 
        (
            -- 订单信息
            SELECT * 
            FROM ods_order_d_i  
            WHERE orderdate = ${ds}
        ) AS order_table
        LEFT JOIN 
        (
            -- 套票信息
            SELECT orderid, pack_order, ifpack   
            FROM ods_order_addon_d_i   
            WHERE orderdate = ${ds}
        ) AS addon_table  
        ON addon_table.orderid = order_table.ordernum 
    ) AS order_table
    LEFT JOIN 
    (
        -- 团单
        SELECT son_order_id, team_order_id, tourist_province, tourist_city, tourist_country
        FROM ods_team_order_d_f 
        WHERE pt = ${ds}
    )  AS team_table         
    ON  order_table.main_order_id = team_table.son_order_id     
    LEFT JOIN 
    (
        -- 历史注释：预定数、添加票时间及数量 （默认仅添加一次）。现场支付订单无 支付记录，所以使用下单操作
        SELECT  
            ordernum,
            SUM(IF(action=0, tnum, 0))      AS booking_num,
            MIN(IF(action=16, tnum, null))  AS add_ticket_time,
            SUM(IF(action=16, tnum, 0))     AS add_ticket_num 
        FROM s_order_track_d_i 
        WHERE insertdate = ${ds}
        AND action IN (0, 16)
        GROUP BY ordernum
    ) AS order_track 
    ON  order_track.ordernum = order_table.ordernum
    LEFT JOIN 
    (
        -- 订单退票状态
        SELECT ordernum, dstatus
        FROM ods_uu_order_terminal_change_d_f 
        WHERE pt=${ds}
    ) AS cancel  
    ON cancel.ordernum = order_table.ordernum
) AS o
LEFT JOIN 
(
    SELECT order_status, order_status_name 
    FROM dim_order_status_o_f
) AS s 
ON s.order_status = o.status
-- 客源地：团队订单客源地>身份证号归属地>游客手机号归属地
LEFT JOIN 
(
    SELECT phone_number, zip_code, city_name, province_name, district_name, zip_code
    FROM dim_phone_city_d_f 
    WHERE pt = ${ds}
) AS cp 
ON SUBSTR(o.ordertel, 1, 7) = cp.phone_number      
LEFT JOIN  
(
    SELECT idcard,city_name,province_name,district_name 
    FROM dim_idcard_city_d_f 
    WHERE pt=${ds}
) AS idc 
ON SUBSTR(o.personid, 1, 6) = idc.idcard
LEFT JOIN 
(
    -- SELECT 
    --     ticket_id, land_city, land_type_code, land_type_name, land_topic, resource_id, resource_name,
    --     product_id, ticket_fullname, land_id, land_name, land_publisher_id, ticket_is_test,
    --     land_publisher_name, land_province, land_city, land_country, land_zip_code, resource_land_id, resource_land_name 
    -- FROM  data_middle_bi.dim_prod_d_f 
    -- WHERE pt="${ds}"
    SELECT   
        t.id                                                                                    AS ticket_id,
        t.pid                                                                                   AS product_id,
        CONCAT(l.title, "-", t.title)                                                           AS ticket_fullname,
        l.id                                                                                    AS land_id,
        l.title                                                                                 AS land_name,
        l.apply_did                                                                             AS land_publisher_id,
        u.user_name                                                                             AS land_publisher_name,
        l.p_type                                                                                AS land_type_code,
        rt.resource_type_name                                                                   AS land_type_name,
        IF(ISNULL(topic.land_topic_name), l.land_topic, topic.land_topic_name)                  AS land_topic,
        p.province_name                                                                         AS land_province,
        c.city_name                                                                             AS land_city,
        c.country_name                                                                          AS land_country,
        c.zip_code                                                                              AS land_zip_code,
        l.resourceID                                                                            AS resource_id,
        ''                                                                                      AS resource_name,
        IF(t.title like '%测试%' OR l.title LIKE '%测试%' OR l.title LIKE '%压测%' OR u.user_is_test='测试','测试','正式')   AS ticket_is_test,
        mr.mt_id                                                                                AS resource_land_id,
        rl.resource_land_name                                                                   AS resource_land_name
    FROM
    (
        SELECT id, landid, pid, title
        FROM ods_uu_jq_ticket_d_f 
        WHERE  pt =${ds}
    ) AS t
    LEFT JOIN 
    (
        SELECT id, title, apply_did, p_type, area, resourceID, SPLIT(topic, ",")[0] AS land_topic 
        FROM ods_uu_land_d_f 
        WHERE pt =${ds}
    ) AS l 
    ON l.id = t.landid
    LEFT JOIN 
    (
        -- 确定需要
        SELECT resource_type, resource_type_name
        FROM  ods_bi_business_dim_resource_type_d_f
        WHERE pt=${ds}
    ) AS rt   
    ON rt.resource_type = l.p_type   
    LEFT JOIN 
    (
        -- 确定需要
        SELECT 
            id                                      AS user_id,
            dname                                   AS user_name,
            IF(group_id IN (2,3) ,'测试','正式')    AS user_is_test
        FROM s_myuu_pft_member_d_f 
        WHERE pt=${ds}
    ) AS u    
    ON u.user_id = l.apply_did                                                                           
    LEFT JOIN 
    (
        -- 确定需要
        SELECT city_name, country_name, zip_code, area_code                
        FROM ods_bi_business_city_d_f 
        WHERE pt =${ds}
    ) AS c 
    ON c.area_code=l.area
    LEFT JOIN 
    (
        -- 确定需要
        SELECT DISTINCT province_code, province_name 
        FROM ods_bi_business_city_d_f 
        WHERE pt =${ds}
    ) AS p 
    ON p.province_code = SUBSTR(l.area, 1, LOCATE('|', l.area)-1)
    LEFT JOIN 
    (
        -- 确定需要
        SELECT land_topic, land_topic_name 
        FROM ods_bi_business_dim_land_topic_d_f 
        WHERE pt =${ds}
    ) AS topic  
    ON topic.land_topic = l.land_topic 
    LEFT JOIN 
    (
        -- 确定需要
        SELECT land_id, mt_id
        FROM 
        (
            SELECT land_id, mt_id, ROW_NUMBER() OVER(PARTITION BY land_id ORDER BY id DESC) AS version_num
            FROM ods_pft_management_resource_d_f 
            WHERE pt =${ds}
        )
        WHERE version_num = 1
    ) AS mr 
    ON mr.land_id = l.id                                
    LEFT JOIN 
    (
        -- 确定需要
        SELECT id AS resource_land_id, title AS resource_land_name  
        FROM ods_pft_management_land_d_f 
        WHERE pt =${ds}
    ) AS rl 
    ON rl.resource_land_id = mr.mt_id
) AS prod 
ON o.tid = prod.ticket_id  
-- 末级销售渠道
LEFT JOIN 
(
    SELECT order_channel_id, channel_name 
    FROM  dim_channel_d_f 
    WHERE pt=${ds}
) AS ch 
ON o.ordermode = ch.order_channel_id      
-- 末级商户信息
LEFT JOIN 
(
    SELECT user_id, user_type, user_company_name, user_name, distribute_system_type, distribute_system_name 
    FROM dim_user_d_f_cache
) AS u 
ON o.member = u.user_id   
-- 一级分销 及 资源中心商户信息
LEFT JOIN 
(
    -- SELECT order_id, distribute_num, distributor_1_id, distribute_1_price, resource_center_supplier_id, resource_center_purchase_id 
    -- FROM data_middle_bi.ods_order_aids_distribute_d_i 
    -- WHERE orderdate="${ds2}"
    SELECT orderid AS order_id, distribute_num, distributor_1_id, distribute_1_price, resource_center_supplier_id, resource_center_purchase_id 
    FROM ods_order_split_d_i 
    WHERE orderdate=${ds}
    GROUP BY orderid, distribute_num, distributor_1_id, distribute_1_price, resource_center_supplier_id, resource_center_purchase_id
) AS oa 
ON oa.order_id=o.ordernum
LEFT JOIN 
(
    SELECT user_id, user_type, user_company_name, user_name, distribute_system_type 
    FROM dim_user_d_f_cache 
    WHERE user_type_code IN (0, 1)
) AS ud 
ON oa.distributor_1_id = ud.user_id
-- 一级分销商分组信息
LEFT JOIN  
(
    SELECT 
        g.sid           AS supplier_id,
        g.fid           AS distributor_id,
        g1.id           AS distributor_group
    FROM
    (
        SELECT sid, fid, MAX(group_id) AS max_id
        FROM ods_pft_evolute_group_fid_d_f 
        WHERE pt = ${ds}
        GROUP BY sid, fid
    ) AS g 
    JOIN
    (
        SELECT id, group_name 
        FROM ods_pft_evolute_group_d_f 
        WHERE pt = ${ds}
    ) AS g1 
    ON g.max_id = g1.id
)AS gr 
ON gr.supplier_id=prod.land_publisher_id AND gr.distributor_id=oa.distributor_1_id
-- 微商城区分新旧版订单
-- LEFT JOIN 
-- (
--     SELECT order_id, business_id, platid 
--     FROM 
--     (
--         SELECT order_id, business_id, platid, ROW_NUMBER() OVER(PARTITION BY order_id ORDER BY click_date) AS rn  
--         FROM data_middle_bi.ods_micromessage_order_success_d_f 
--     ) AS a 
--     WHERE a.rn=1
-- ) AS mo 
-- ON o.ordernum = mo.order_id
-- 从第三方票务采购订单
LEFT JOIN 
(
    SELECT third_name, third_coopB, order_id 
    FROM ods_third_purchase_order_d_f 
    WHERE pt=${ds}
) AS th 
ON th.order_id = o.ordernum
LEFT JOIN 
(
    SELECT orderid, origin_num, sale_price
    FROM ods_order_apply_d_i
    WHERE `orderdate` = ${ds}
) AS order_apply
ON o.ordernum = order_apply.orderid
LEFT JOIN 
(
    -- 分销拆分
    SELECT 
        order_split_table.orderid,
        order_split_table.buyerid,
        order_split_table.sellerid,
        order_split_table.level,
        IF(
            level = 0 OR level = 1,
            1,
            IF (
                level = -1,
                order_count_level_table.order_count_level,
                IF (
                    sellerid = level2_sellerid_table.level2_sellerid,
                    2,
                    IF (
                        (order_count_level_table.order_count_level > 3) AND (order_split_table.buyerid = level_2_buyerid_table.level_2_buyerid),
                        order_count_level_table.order_count_level - 1,
                        3
                    )
                )
            )
        ) AS detail_split_level,
        IF(
            level = 0 OR level = -1,
            1, 
            0
        ) AS is_end_level
    FROM 
    (
        SELECT orderid, buyerid, sellerid, level
        FROM s_order_split_d_i
        WHERE orderdate = ${ds}
    ) AS order_split_table
    LEFT JOIN 
    (
        SELECT orderid, COUNT(1) AS order_count_level 
        FROM s_order_split_d_i 
        WHERE orderdate = ${ds}
        GROUP BY orderid
    ) AS order_count_level_table
    ON order_split_table.orderid = order_count_level_table.orderid
    LEFT JOIN 
    (
        SELECT orderid, buyerid AS level2_sellerid 
        FROM s_order_split_d_i 
        WHERE orderdate = ${ds} 
        AND level = 1
    ) AS level2_sellerid_table
    ON order_split_table.orderid = level2_sellerid_table.orderid
    LEFT JOIN 
    (
        SELECT orderid, sellerid AS level_2_buyerid 
        FROM s_order_split_d_i 
        WHERE orderdate = ${ds}
        AND level = -1
    ) AS level_2_buyerid_table
    ON order_split_table.orderid = level_2_buyerid_table.orderid 
) AS order_split
ON o.ordernum = order_split.orderid
LEFT JOIN
(
    -- 购买者名
    SELECT user_id, user_name
    FROM ods_pft_member_d_f
    WHERE pt = ${ds}
) AS member_buyer_name
ON order_split.buyerid = member_buyer_name.user_id
LEFT JOIN
(
    -- 购买者业态
    SELECT user_id, group_id, customer_type_code, format_type
    FROM dim_user_d_f_cache
    WHERE user_type IN ('供应商','分销商')
) AS member_buyer_format
ON order_split.buyerid = member_buyer_format.user_id
LEFT JOIN
(
    -- 销售者名
    SELECT user_id, user_name
    FROM ods_pft_member_d_f
    WHERE pt = ${ds}
) AS member_seller_name
ON order_split.sellerid = member_seller_name.user_id
LEFT JOIN
(
    -- 销售者类型和业态
    SELECT fid, corp_kind, format_type
    FROM ods_myuu_pft_member_extinfo_d_f
    WHERE pt = ${ds}
) AS member_seller_format
ON order_split.sellerid = member_seller_format.fid
LEFT JOIN 
(
    SELECT user_id, group_id
    FROM ods_pft_member_d_f
    WHERE pt=${ds}
) AS member_group
ON o.apply_did = member_group.user_id
LEFT JOIN 
(
    SELECT orderid, sale_price, origin_num, pay_num   
    FROM dim_order_d_i
    WHERE orderdate = ${ds}
) AS dim_order
ON o.ordernum = dim_order.orderid;


