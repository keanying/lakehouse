--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-15 10:32:24
--EMR任务只能运行在独享资源组上
--********************************************************************--



CREATE TABLE IF NOT EXISTS `dwd_tourist_verify_d_i`
(
    -- 重要 id
    `apply_did`             INT     COMMENT '原始供应商ID', 
    `orderid`               STRING  COMMENT '订单号ID', 
    `lid`                   INT     COMMENT '景点ID', 
    `tid`                   INT     COMMENT '门票id',
    `pid`                   INT     COMMENT '产品id',
    `product_type`          STRING  COMMENT '商品类型',

    `order_type`            STRING  COMMENT '票类型：套票主票/单票/套票子票',

    -- 游客画像使用
    `age`                   STRING  COMMENT '年龄-来自身份证', 
    `sex`                   STRING  COMMENT '性别-来自身份证', 

    -- 新增
    `country_name`          STRING  COMMENT '国家-优先使用字段',
    `province_name`         STRING  COMMENT '省-优先使用字段', 
    `city_name`             STRING  COMMENT '市-优先使用字段', 
    `district_name`         STRING  COMMENT '区县-优先使用字段',

    `phone_country_name`    STRING  COMMENT '国家-手机号归属地', 
    `phone_province_name`   STRING  COMMENT '省-手机号归属地', 
    `phone_city_name`       STRING  COMMENT '市-手机号归属地', 
    -- 新增
    `phone_district_name`   STRING  COMMENT '区县-手机号归属地', 

    `idcard_country_name`   STRING  COMMENT '国家-证件归属地', 
    `idcard_province_name`  STRING  COMMENT '省-证件归属地', 
    `idcard_city_name`      STRING  COMMENT '市-证件归属地', 
    `idcard_district_name`  STRING  COMMENT '区县-证件归属地', 

    -- 渠道信息
    `channel_class1_id`     INT     COMMENT '渠道一级分类id',
    `channel_class1_name`   STRING  COMMENT '渠道一级分类名称',
    `channel_class2_id`     INT     COMMENT '渠道二级分类id',
    `channel_class2_name`   STRING  COMMENT '渠道二级分类名称',

    -- 游客原始数据
    `idx`                   BIGINT  COMMENT '订单序号', 
    `idcard`                STRING  COMMENT '游客身份信息', 
    `voucher_type`          TINYINT COMMENT '身份信息类型:0=未知,1=身份证,2=护照,3=军官证,4=回乡证,5=台胞证,6=外国人永久居留证,7=港澳通行证,8=台湾通行证,9=港澳居民居住证,10=台湾居民居住证,99=其他', 
    `order_time`            INT     COMMENT '逻辑下单时间', 
    `mobile`                STRING  COMMENT '游客手机号', 

    `terminal`              STRING  COMMENT '终端号', 
    `branch_terminal`       STRING  COMMENT '分终端号', 
    `ext_content`           STRING  COMMENT '验证或是取消过程中的一些数据', 

    -- 验证信息
    `verify_num`            INT     COMMENT '验证数量',
    `msg`                   STRING  COMMENT '备注信息',
    `is_first_used`         INT     COMMENT '是否首次验证,1=首次,0=非首次。211209之后有效',
    `is_overdue`            INT     COMMENT '是否过期验证,1=过期验证,0=非过期验证',

    -- 26/05 新增字段
    `verify_money`              INT         COMMENT '验证金额',
    `main_sid`                  STRING      COMMENT '套票子票(主票的 sid)，套票主票/单票（原订单的 sid）',
    `main_lid`                  STRING      COMMENT '套票子票(主票的 lid)，套票主票/单票（原订单的 lid）',
    `main_tid`                  STRING      COMMENT '套票子票(主票的 tid)，套票主票/单票（原订单的 tid）',
    `main_product_type`         STRING      COMMENT '套票子票(主票的 p_type)，套票主票/单票（原订单的 p_type）',
    `main_pid`                  STRING      COMMENT '套票子票(主票的 pid)，套票主票/单票（原订单的 pid）',
    `paymode`                   TINYINT     COMMENT '支付方式：0 = 余额支付,1 = 支付宝,2 = 授信支付,3 = 产品自销,4 = 现场支付,5 = 微信支付,6 = 会员卡支付,7 = 银联支付,8 = 环迅支付,9 = 现金支付,10 = 会员卡,11 = 拉卡拉（商户）,12 = 拉卡拉（平台）,13 = 特权支付（年卡）,14 = 微信（聚合）,15 = 平安银行,16 = 支付宝（聚合）,17 = 会员卡支付,18 = 计时卡支付,25 = 招行一网通支付,26 = 银联商务支付,27 = 银联商务POS支付,28 = 威富通支付,29 = 易宝云企付,33 = 博思支付,35 = 积分支付,36 = POS支',
    `ordermode`                 TINYINT     COMMENT '下单方式:0=正常分销商下单,1=普通用户支付,2=用户手机支付,3=会员卡购票,10=云票务,11=微信商城,12=自助机,13=二级店铺,14=闸机购票,15=智能终端,16=计调下单,17=淘宝码商,18=年卡,19=微信端,20=外部接口OTA下单,22=一卡通,23=套票子票',
    `distribute_1_id`           INT         COMMENT '一级分销商id',
    `tourist`                   STRING      COMMENT '游客姓名'
)
COMMENT '核销游客信息表，按核销日期分区'
PARTITIONED BY 
(
    `insertdate`            INT     COMMENT '核销日期'
)
STORED AS ORC;


-- 基础内存配置（核心）
-- SET spark.executor.memory=8g;          -- 每个Executor分配8G内存（根据集群调整，至少4G以上）
-- SET spark.executor.memoryOverhead=2g;  -- 堆外内存，避免JVM被系统杀死（通常为executor内存的1/4~1/2）
-- SET spark.driver.memory=4g;            -- Driver内存，分区写入/元数据处理需要
-- SET spark.driver.memoryOverhead=1g;

-- 针对OOM的优化配置
SET spark.sql.adaptive.maxPartitionBytes=64MB;  -- 降低AQE单分区大小（从128MB下调，减少单Task处理量）
SET spark.sql.shuffle.partitions=200;           -- 增加shuffle分区数，分散数据量（默认20太少）
-- SET spark.memory.offHeap.enabled=true;          -- 开启堆外内存
-- SET spark.memory.offHeap.size=4g;               -- 堆外内存大小，缓解堆内压力

-- 保留你原有的配置
SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=128MB;

-----------
-- 旧有配置参数
-- -- 保留有用的合并小文件和动态分区参数
-- SET spark.sql.mergeSmallFiles.enabled=true;
-- SET spark.sql.sources.partitionOverwriteMode=dynamic;
-- SET spark.sql.adaptive.enabled=true;
-- SET spark.sql.adaptive.coalescePartitions.enabled=true;
-- SET spark.sql.adaptive.coalescePartitions.minPartitionSize=128MB;

-- -- 删除以下 2 个参数（强制并行度为 1，是导致磁盘溢出的核心）
-- -- SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
-- -- SET spark.sql.adaptive.coalescePartitions.parallelism=1;

-- -- 新增：设置合理的任务并行度（根据集群资源调整，建议 50-200）
-- SET spark.sql.shuffle.partitions=10;
-- -- 新增：增大单个 Task 的内存（减少 spill 频率）
-- -- SET spark.task.maxFailures=8;
-- -- SET spark.executor.memoryOverhead=2048m;
-----------

INSERT OVERWRITE TABLE dwd_tourist_verify_d_i PARTITION(insertdate)
SELECT 
    NVL(track.`apply_did`, -1)              AS `apply_did`,
    NVL(track.`ordernum`, -1)               AS `orderid`,
    NVL(info.`lid`, -1)                     AS `lid`,
    NVL(track.`tid`, -1)                    AS `tid`,
    NVL(info.`pid`, -1)                     AS `pid`,
    NVL(info.`product_type`, -1)            AS `product_type`,

    NVL(info.`order_type`, -1)              AS `order_type`,

    NVL(info.`age`, -1)                     AS `age`,
    NVL(info.`sex`, '未知')                  AS `sex`,

    NVL(info.`country_name`, '未知')            AS `country_name`,
    NVL(info.`province_name`, '未知')           AS `province_name`,
    NVL(info.`city_name`, '未知')               AS `city_name`,
    NVL(info.`district_name`, '未知')           AS `district_name`,

    NVL(info.`phone_country_name`, '未知')      AS `phone_country_name`,
    NVL(info.`phone_province_name`, '未知')     AS `phone_province_name`,
    NVL(info.`phone_city_name`, '未知')         AS `phone_city_name`,
    NVL(info.`phone_district_name`, '未知')     AS `phone_district_name`,

    NVL(info.`idcard_country_name`, '未知')     AS `idcard_country_name`,
    NVL(info.`idcard_province_name`, '未知')    AS `idcard_province_name`,
    NVL(info.`idcard_city_name`, '未知')        AS `idcard_city_name`,
    NVL(info.`idcard_district_name`, '未知')    AS `idcard_district_name`,

    NVL(info.`channel_class1_id`, 4)            AS `channel_class1_id`,
    NVL(info.`channel_class1_name`, '其他')      AS `channel_class1_name`,
    NVL(info.`channel_class2_id`, -1)           AS `channel_class2_id`,
    NVL(info.`channel_class2_name`, '其他')     AS `channel_class2_name`,

    NVL(track.`idx`, -1)                    AS `idx`,
    NVL(info.`idcard`, -1)                  AS `idcard`,
    NVL(info.`voucher_type`, -1)            AS `voucher_type` ,
    NVL(info.`order_time`, -1)              AS `order_time`,
    NVL(info.`mobile`, -1)                  AS `mobile`,

    NVL(track.`terminal`, -1)               AS `terminal`,
    NVL(track.`branch_terminal`, -1)        AS `branch_terminal`,
    NVL(track.`ext_content`, -1)            AS `ext_content`,

    NVL(track.`tnum`, 0)                                    AS `verify_num`,
    NVL(track.`msg`, -1)                                    AS `msg`,
    IF(`ext_content` LIKE '%"is_first_used":1%', 1, 0)      AS `is_first_used`,
    IF(`msg` LIKE '%过期%', 1, 0)                           AS `is_is_overdue`,

    NVL(track.`tnum` * info.`sale_price`, 0)        AS `verify_money`,
    NVL(info.`main_sid`, 0)                         AS `main_sid`,              
    NVL(info.`main_lid`, 0)                         AS `main_lid`,              
    NVL(info.`main_tid`, 0)                         AS `main_tid`,              
    NVL(info.`main_product_type`, 0)                AS `main_product_type`,             
    NVL(info.`main_pid`, 0)                         AS `main_pid`,              
    NVL(info.`paymode`, 0)                          AS `paymode`,               
    NVL(info.`ordermode`, 0)                        AS `ordermode`,             
    NVL(info.`distribute_1_id`, 0)                  AS `distribute_1_id`,               
    NVL(info.`tourist`, 0)                          AS `tourist`,         

    track.`insertdate`                              AS `insertdate`
FROM 
(
    -- 昨天验证的游客数量
    SELECT 
        -- 原始字段
        `ordernum`,    
        `idx`,  
        `tnum`,
        `insertdate`,
        `apply_did`,
        `tid`,
        `msg`,
        `terminal`,       
        `branch_terminal`,
        `ext_content`    
    FROM s_tourist_track_d_i
    WHERE 1=1
      AND insertdate = ${ds}
      AND track_action = 1
) AS track 
LEFT JOIN 
(
    -- 近一年下单游客
    SELECT 
        `orderid`,
        `pid`,
        `product_type`,
        `age`,
        `sex`,

        `lid`,

        `country_name`,
        `province_name`,
        `city_name`,
        `district_name`,

        `phone_country_name`,
        `phone_province_name`,
        `phone_city_name`,
        `phone_district_name`,

        `idcard_country_name`,
        `idcard_province_name`,
        `idcard_city_name`,
        `idcard_district_name`,

        `channel_class1_id`,
        `channel_class1_name`,
        `channel_class2_id`,
        `channel_class2_name`,
        
        `idx`,
        `idcard`,
        `voucher_type`,
        `order_time`,
        `mobile`,
        `order_type`,

        `sale_price`,
        `main_sid`,
        `main_lid`,
        `main_tid`,
        `main_product_type`,
        `main_pid`,
        `paymode`,
        `ordermode`,
        `distribute_1_id`,
        `tourist`
    FROM dwd_tourist_info_d_i
    WHERE 1 = 1
      AND orderdate >= CAST(DATE_FORMAT(DATE_SUB(TO_DATE(CAST(${ds} AS STRING), 'yyyyMMdd'), 732), 'yyyyMMdd') AS INT)
) AS info 
ON track.`ordernum` = info.`orderid`
AND track.`idx` = info.`idx`;

