--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-13 15:25:50
--EMR任务只能运行在独享资源组上
--********************************************************************--
-- 修订增加一级分销商 id 以及订单类型

CREATE TABLE IF NOT EXISTS `dws_distribution_aggregation_d_i`(
    `sid`                       INT     COMMENT '商户ID，销售商',

    `channel_class1_id`         INT     COMMENT '渠道一级分类id',
    `channel_class1_name`       STRING  COMMENT '渠道一级分类名称',
    `channel_class2_id`         INT     COMMENT '渠道二级分类id',
    `channel_class2_name`       STRING  COMMENT '渠道二级分类名称',

    `land_id`                   INT     COMMENT '景区ID',
    `land_name`                 STRING  COMMENT '景区名称',
    `p_type`                    STRING  COMMENT '景区类型：A景区B线路C酒店F套票',
    `pid`                       INT     COMMENT '产品id',
    `ticket_id`                 INT     COMMENT '票ID',
    `ticket_fullname`           STRING  COMMENT '票名称',

    `order_type`                STRING  COMMENT '订单类型 套票主票/套票子票/单票',
    `distribution_seller_1_id`  INT     COMMENT '一级分销商id', 

    `paid_count`                BIGINT  COMMENT '已支付订单量',
    `paid_ticket_count`         BIGINT  COMMENT '已支付票量',
    `paid_amount`               BIGINT  COMMENT '已支付订单金额'
 )comment'订单渠道统计表/基于原始票数/不含分销'partitioned by(
    fulldate STRING  COMMENT '全日期，例如：2021-01-01'
 )STORED AS ORC;


-- 通过回调地址确认的商户缓存表
DROP VIEW IF EXISTS cache_table_loopback;
CACHE TABLE cache_table_loopback 
AS 
SELECT 
    id, channel_aggregation_name, target_id
FROM
(
    -- 商户回调地址
    SELECT id, dcodeURL, dcode
    FROM s_myuu_pft_member_d_f
    WHERE pt = '${ds}'
      AND dtype IN (0, 1)
      AND group_id != 2
) AS member 
INNER JOIN 
(
    SELECT loopback_address, channel_aggregation_name, target_id
    FROM dim_distribute_ota_o_f
    -- 通过回调地址确认
    WHERE rule_code = 1
) AS OTA 
ON member.dcodeURL RLIKE OTA.loopback_address;


-- 通过商户 id 确认的 商户
DROP VIEW IF EXISTS cache_table_member;
CACHE TABLE cache_table_member 
SELECT 
    member_id AS id, channel_aggregation_name, target_id
FROM 
(
    SELECT member_id, channel_aggregation_name, target_id
    FROM dim_distribute_ota_o_f
    -- 通过回调地址确认
    WHERE rule_code = 2
      AND member_id NOT IN (
        SELECT id FROM cache_table_loopback
      )
);


------------------------------------------------------------------------------------------


INSERT OVERWRITE TABLE dws_distribution_aggregation_d_i PARTITION(`fulldate` = '${ds}')
-- 渠道非20
SELECT 
    INT(order.apply_did),

    type.channel_class1_id,
    type.channel_class1_name,
    int(type.channel_class2_id),
    type.channel_class2_name,

    order.land_id, 
    order.land_name,
    order.land_type         AS p_type,
    order.product_id        AS pid,

    order.ticket_id, 
    order.ticket_fullname, 

    order.order_type        AS order_type,
    split.distribution_seller_1_id  AS distribution_seller_1_id,

    COUNT(1)                AS paid_count,
    SUM(ticket_num)         AS paid_ticket_count,
    SUM(order_pay_amount)   AS paid_amount

    -- ,order.booking_date
FROM 
(
    SELECT apply_did, land_id, land_name, product_id, ticket_id, ticket_fullname, booking_date, booking_channel, ticket_num, order_pay_amount, land_type, order_type, order_id
    FROM dwd_order_d_i 
    WHERE 1=1
      AND booking_date =  '${ds}'
    --   AND ISNOTNULL(pay_time)
      AND booking_channel != 20
) AS order
LEFT JOIN 
(
    SELECT channel_class1_id, channel_class1_name, channel_class2_id, channel_class2_name
    FROM dim_distribute_channel_type_o_f
) AS type 
ON order.booking_channel = type.channel_class2_id
LEFT JOIN 
(
    SELECT
        orderid,
        buyerid     AS distribution_seller_1_id
    FROM s_order_split_d_i
    WHERE orderdate = "${ds}"
    AND level IN (0, 1)
) AS split 
ON order.order_id = split.orderid
GROUP BY 
    type.channel_class1_id,
    type.channel_class1_name,
    type.channel_class2_id,
    type.channel_class2_name,
    order.apply_did, 
    order.land_id, 
    order.land_name, 
    order.land_type,
    order.product_id,
    order.ticket_id, 
    order.ticket_fullname, 
    order.booking_date,
    order.order_type,
    split.distribution_seller_1_id


UNION ALL


-- 渠道为20的
SELECT 
    INT(order.apply_did),

    3                                       AS channel_class1_id, 
    'OTA'                                   AS channel_class1_name,

    int(NVL(ota.target_id, 2000))                      AS channel_class2_id,
    NVL(ota.channel_aggregation_name, '商家自研')   AS channel_class2_name,

    order.land_id, 
    order.land_name,
    order.land_type         AS p_type,
    order.product_id        AS pid,

    order.ticket_id, 
    order.ticket_fullname, 

    order.order_type        AS order_type,
    split.distribution_seller_1_id  AS distribution_seller_1_id,

    COUNT(1)                AS paid_count,
    SUM(ticket_num)         AS paid_ticket_count,
    SUM(order_pay_amount)   AS paid_amount

    -- ,order.booking_date
FROM 
(
    SELECT apply_did, land_id, land_name, product_id, ticket_id, ticket_fullname, booking_date, booking_channel, ticket_num, order_pay_amount, booker_id, land_type, order_type, order_id
    FROM dwd_order_d_i 
    WHERE 1=1
      AND booking_date =  '${ds}'
    --   AND ISNOTNULL(pay_time)
      AND booking_channel = 20
) AS order
LEFT JOIN 
(
    SELECT id, target_id, channel_aggregation_name
    FROM cache_table_loopback

    UNION ALL 
    
    SELECT id, target_id, channel_aggregation_name
    FROM cache_table_member
) AS ota 
ON order.booker_id = ota.id
LEFT JOIN 
(
    SELECT
        orderid,
        buyerid     AS distribution_seller_1_id
    FROM s_order_split_d_i
    WHERE orderdate = "${ds}"
    AND level IN (0, 1)
) AS split 
ON order.order_id = split.orderid
GROUP BY 
    ota.target_id,
    ota.channel_aggregation_name,
    order.apply_did, 
    order.land_id, 
    order.land_name, 
    order.land_type,
    order.product_id,
    order.ticket_id, 
    order.ticket_fullname, 
    order.booking_date,
    order.order_type,
    split.distribution_seller_1_id;




-- CREATE TABLE IF NOT EXISTS `dws_distribution_aggregation_d_i`(
--     `sid` int COMMENT'商户ID，销售商',
--     `channel_class1_id`     INT     COMMENT'渠道一级分类id',
--     `channel_class1_name`   STRING  COMMENT'渠道一级分类名称',
--     `channel_class2_id`     INT     COMMENT'渠道二级分类id',
--     `channel_class2_name`   STRING  COMMENT'渠道二级分类名称',
--     `land_id`               INT     COMMENT'景区ID',
--     `land_name`             STRING  COMMENT'景区名称',
--     `p_type`                STRING  COMMENT'景区类型：A景区B线路C酒店F套票',
--     `pid`                   INT     COMMENT '产品id',
--     `ticket_id`             INT     COMMENT'票ID',
--     `ticket_fullname`       STRING  COMMENT'票名称',
--     `paid_count`            BIGINT  COMMENT'已支付订单量',
--     `paid_ticket_count`     BIGINT  COMMENT'已支付票量',
--     `paid_amount`           BIGINT  COMMENT'已支付订单金额'
--  )comment'订单渠道统计表/基于原始票数/不含分销'partitioned by(
--     fulldate STRING  COMMENT '全日期，例如：2021-01-01'
--  )stored as orc 
--  lifecycle 9999;

-- -- 通过回调地址确认的商户缓存表
-- CACHE TABLE cache_table_loopback
-- AS 
-- SELECT 
--     id, channel_aggregation_name, target_id
-- FROM
-- (
--     -- 商户回调地址
--     SELECT id, dcodeURL, dcode
--     FROM s_myuu_pft_member_d_f
--     WHERE pt = '${bdp.system.bizdate}'
--       AND dtype IN (0, 1)
--       AND group_id != 2
-- ) AS member 
-- INNER JOIN 
-- (
--     SELECT 
--         loopback_address, channel_aggregation_name, target_id
--     FROM dim_distribute_ota_o_f
--     -- 通过回调地址确认
--     WHERE rule_code = 1
-- ) AS OTA 
-- ON member.dcodeURL RLIKE OTA.loopback_address;


-- -- 通过商户 id 确认的 商户
-- CACHE TABLE cache_table_member
-- SELECT 
--     member_id AS id, channel_aggregation_name, target_id
-- FROM 
-- (
--     SELECT member_id, channel_aggregation_name, target_id
--     FROM dim_distribute_ota_o_f
--     -- 通过回调地址确认
--     WHERE rule_code = 2
--       AND member_id NOT IN (
--         SELECT id FROM cache_table_loopback
--       )
-- );


-- ------------------------------------------------------------------------------------------


-- INSERT OVERWRITE TABLE dws_distribution_aggregation_d_i PARTITION(`fulldate` = '${bdp.system.bizdate2}')
-- -- 渠道非20
-- SELECT 
--     order.apply_did,

--     type.channel_class1_id,
--     type.channel_class1_name,
--     type.channel_class2_id,
--     type.channel_class2_name,

--     order.land_id, 
--     order.land_name,
--     order.land_type         AS p_type,
--     order.product_id        AS pid,

--     order.ticket_id, 
--     order.ticket_fullname, 

--     COUNT(1)                AS paid_count,
--     SUM(ticket_num)         AS paid_ticket_count,
--     SUM(order_pay_amount)   AS paid_amount

--     -- ,order.booking_date
-- FROM 
-- (
--     SELECT apply_did, land_id, land_name, product_id, ticket_id, ticket_fullname, booking_date, booking_channel, ticket_num, order_pay_amount, land_type
--     FROM dwd_order_d_i 
--     WHERE 1=1
--       AND booking_date =  '${bdp.system.bizdate2}'
--     --   AND ISNOTNULL(pay_time)
--       AND booking_channel != 20
-- ) AS order
-- LEFT JOIN 
-- (
--     SELECT channel_class1_id, channel_class1_name, channel_class2_id, channel_class2_name
--     FROM dim_distribute_channel_type_o_f
-- ) AS type 
-- ON order.booking_channel = type.channel_class2_id
-- GROUP BY 
--     type.channel_class1_id,
--     type.channel_class1_name,
--     type.channel_class2_id,
--     type.channel_class2_name,
--     order.apply_did, 
--     order.land_id, 
--     order.land_name, 
--     order.land_type,
--     order.product_id,
--     order.ticket_id, 
--     order.ticket_fullname, 
--     order.booking_date


-- UNION ALL


-- -- 渠道为20的
-- SELECT 
--     order.apply_did,

--     3                                       AS channel_class1_id, 
--     'OTA'                                   AS channel_class1_name,

--     NVL(ota.target_id, 2000)                        AS channel_class2_id,
--     NVL(ota.channel_aggregation_name, '商家自研')   AS channel_class2_name,

--     order.land_id, 
--     order.land_name,
--     order.land_type         AS p_type,
--     order.product_id        AS pid,

--     order.ticket_id, 
--     order.ticket_fullname, 

--     COUNT(1)                AS paid_count,
--     SUM(ticket_num)         AS paid_ticket_count,
--     SUM(order_pay_amount)   AS paid_amount

--     -- ,order.booking_date
-- FROM 
-- (
--     SELECT apply_did, land_id, land_name, product_id, ticket_id, ticket_fullname, booking_date, booking_channel, ticket_num, order_pay_amount, booker_id, land_type
--     FROM dwd_order_d_i 
--     WHERE 1=1
--       AND booking_date =  '${bdp.system.bizdate2}'
--     --   AND ISNOTNULL(pay_time)
--       AND booking_channel = 20
-- ) AS order
-- LEFT JOIN 
-- (
--     SELECT id, target_id, channel_aggregation_name
--     FROM cache_table_loopback

--     UNION ALL 
    
--     SELECT id, target_id, channel_aggregation_name
--     FROM cache_table_member
-- ) AS ota 
-- ON order.booker_id = ota.id
-- GROUP BY 
--     ota.target_id,
--     ota.channel_aggregation_name,
--     order.apply_did, 
--     order.land_id, 
--     order.land_name, 
--     order.land_type,
--     order.product_id,
--     order.ticket_id, 
--     order.ticket_fullname, 
--     order.booking_date;