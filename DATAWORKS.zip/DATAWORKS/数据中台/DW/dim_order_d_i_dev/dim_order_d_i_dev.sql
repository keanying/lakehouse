--Serverless Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2026-04-13 17:06:43
--Serverless Spark SQL任务只能运行在独享资源组上
--********************************************************************--


-- - 渠道规则
-- 1. 通过回调地址确定的商户
--     - member 表中有回调地址的。先用回调地址确定此商户的渠道聚合名称以及聚合id
-- 2. 通过商户id确定商户
--     - 直接通过商户id，确定渠道聚合名称以及聚合id
-- - 原始售价/票数（取消）
-- - 一级分销商id/售价/成本
-- - 订单主子票（原始类型，特殊套票需要修正）
-- - 取票人归属地，手机计算
-- 1. 判断国籍，省市区
-- 2. 港澳台特殊处理
-- - 取票人归属地，证件号码
-- 1. 按证件类型不同规则
-- - 性别年龄
-- 1. 使用身份证计算
-- - 取票人归属地性别年龄
-- 1. 优先手机号码
-- 2. 若手机城市与证件城市相同，则取证件号码区县填充为手机区县，否则填充未知

-- 25/05/26 增加修订
-- 1. 预定票数及支付票数从订单轨迹表出
-- 2. 票价从使用订单原始数据表的票价，改为使用订单表的票价
-- 3. 增加支付票数列

-- 26/05/14 增加修订
-- 增加：`main_sid`、 `main_lid`、 `main_tid`、 `main_product_type`、 `main_pid`          


CREATE TABLE IF NOT EXISTS `dim_order_d_i_dev`
(
    `orderid`                   STRING  COMMENT '订单号',

    `apply_did`                 INT     COMMENT '原始供应商ID',
    `aid`                       INT     COMMENT '供应商ID',
    `salerid`                   INT     COMMENT '商家ID',
    `member`                    INT     COMMENT '购买者ID',

    `lid`                       INT     COMMENT '景区id',
    `tid`                       INT     COMMENT '门票id',
    `pid`                       INT     COMMENT '产品id',
    `product_type`              STRING  COMMENT '商品类型',

    `playdate`                  STRING  COMMENT '预计游玩时间',
    `paymode`                   TINYINT COMMENT '支付方式：0 = 余额支付,1 = 支付宝,2 = 授信支付,3 = 产品自销,4 = 现场支付,5 = 微信支付,6 = 会员卡支付,7 = 银联支付,8 = 环迅支付,9 = 现金支付,10 = 会员卡,11 = 拉卡拉（商户）,12 = 拉卡拉（平台）,13 = 特权支付（年卡）,14 = 微信（聚合）,15 = 平安银行,16 = 支付宝（聚合）,17 = 会员卡支付,18 = 计时卡支付,25 = 招行一网通支付,26 = 银联商务支付,27 = 银联商务POS支付,28 = 威富通支付,29 = 易宝云企付,33 = 博思支付,35 = 积分支付,36 = POS支',
    `ordermode`                 TINYINT COMMENT '下单方式:0=正常分销商下单,1=普通用户支付,2=用户手机支付,3=会员卡购票,10=云票务,11=微信商城,12=自助机,13=二级店铺,14=闸机购票,15=智能终端,16=计调下单,17=淘宝码商,18=年卡,19=微信端,20=外部接口OTA下单,22=一卡通,23=套票子票',
    
    `channel_class1_id`         INT     COMMENT '渠道一级分类id',
    `channel_class1_name`       STRING  COMMENT '渠道一级分类名称',
    `channel_class2_id`         INT     COMMENT '渠道二级分类id',
    `channel_class2_name`       STRING  COMMENT '渠道二级分类名称',

    `sale_price`                INT     COMMENT '实际售价(uu_ss_order表的tprice)',
    `origin_num`                INT     COMMENT '预定票数(订单轨迹表清洗的预定票数)',
    `pay_num`                   INT     COMMENT '支付票数(订单轨迹表清洗的支付票数)',

    `distribute_1_id`           INT     COMMENT '一级分销商id',
    `distribute_1_price`        INT     COMMENT '一级分销商销售价',
    `distribute_1_cost_price`   INT     COMMENT '一级分销商成本价',

    -- 取票人归属地
    `ticket_taker_country`      STRING  COMMENT '取票人所在国(优先手机号码，为空则身份证)',
    `ticket_taker_province`     STRING  COMMENT '取票人所在省(优先手机号码，为空则身份证)',
    `ticket_taker_city`         STRING  COMMENT '取票人所在市(优先手机号码，为空则身份证)',
    `ticket_taker_district`     STRING  COMMENT '取票人所在县(优先手机号码，为空则身份证)',

    `ticket_taker_country_phone`        STRING  COMMENT '取票人所在国(手机号码)',
    `ticket_taker_province_phone`       STRING  COMMENT '取票人所在省(手机号码)',
    `ticket_taker_city_phone`           STRING  COMMENT '取票人所在市(手机号码)',
    `ticket_taker_district_phone`       STRING  COMMENT '取票人所在县(手机号码)',

    `ticket_taker_country_idcard`       STRING  COMMENT '取票人所在国(证件号码)',
    `ticket_taker_province_idcard`      STRING  COMMENT '取票人所在省(证件号码)',
    `ticket_taker_city_idcard`          STRING  COMMENT '取票人所在市(证件号码)',
    `ticket_taker_district_idcard`      STRING  COMMENT '取票人所在县(证件号码)',

    -- 取票人年龄性别
    `ticket_taker_sex`          STRING  COMMENT '取票人性别',
    `ticket_taker_age`          STRING  COMMENT '取票人年龄', 

    -- 套票系列
    `order_type`                STRING  COMMENT '票类型：套票主票/单票/套票子票',
    `pack_order_main_ordernum`  STRING  COMMENT '套票主单号，单票为-1',

    -- 三个字段最近十五日将刷新
    `order_pay_status`          INT     COMMENT '订单支付状态:0=现场支付,1=已支付,2=未支付',
    `pay_date`                  STRING  COMMENT '支付时间',
    `order_status`              STRING  COMMENT '订单状态',

    -- 主子单相关信息
    `main_sid`                  STRING  COMMENT '套票子票(主票的 sid)，套票主票/单票（原订单的 sid）',
    `main_lid`                  STRING  COMMENT '套票子票(主票的 lid)，套票主票/单票（原订单的 lid）',
    `main_tid`                  STRING  COMMENT '套票子票(主票的 tid)，套票主票/单票（原订单的 tid）',
    `main_product_type`         STRING  COMMENT '套票子票(主票的 p_type)，套票主票/单票（原订单的 p_type）',
    `main_pid`                  STRING  COMMENT '套票子票(主票的 pid)，套票主票/单票（原订单的 pid）'
)
COMMENT '订单维度表'
PARTITIONED BY (
    `orderdate`                 INT     COMMENT '下单日期'
)
STORED AS ORC;


-----------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------
-------------------------------------------------- 渠道规则 ------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------

SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=128MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;

-- 通过回调地址确认的 商户
DROP VIEW IF EXISTS cache_table_loopback;
CACHE TABLE cache_table_loopback
AS 
SELECT 
    id, channel_aggregation_name, target_id
FROM
(
    -- 商户回调地址
    SELECT id, dcodeURL
    FROM s_myuu_pft_member_d_f
    WHERE pt = FROM_UNIXTIME(UNIX_TIMESTAMP(DATE_SUB(CURRENT_DATE, 1)), 'yyyyMMdd')
      -- 供应商，分销商
      AND dtype IN (0, 1)
      -- 排除测试
      AND group_id != 2
) AS member 
INNER JOIN 
(
    SELECT loopback_address, channel_aggregation_name, target_id
    FROM dim_distribute_ota_o_f
    -- 通过回调地址确认
    WHERE rule_code = 1
) AS OTA 
ON member.dcodeURL RLIKE OTA.loopback_address;


-- 通过商户 id 确认的 商户
DROP VIEW IF EXISTS cache_table_member;
CACHE TABLE cache_table_member
AS 
SELECT 
    member_id AS id, channel_aggregation_name, target_id
FROM 
(
    SELECT member_id, channel_aggregation_name, target_id
    FROM dim_distribute_ota_o_f
    -- 通过member_id确认
    WHERE rule_code = 2
      AND member_id NOT IN (
        SELECT id FROM cache_table_loopback
      )
);


-----------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------- 预定/支付票数 ---------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------


-- CACHE TABLE order_apply
-- AS
-- SELECT orderid, sale_price, origin_num
-- FROM s_order_apply_d_i
-- WHERE orderdate = '${bdp.system.bizdate2}';


DROP VIEW IF EXISTS order_tnum;
CACHE TABLE order_tnum
AS
SELECT 
    ordernum, 
    SUM(booking_ticket_num) AS booking_ticket_num_sum, 
    SUM(pay_ticket_num)     AS pay_ticket_num_sum
FROM ods_track_tnum_d_i
WHERE insertdate = ${ds}
-- WHERE insertdate >= ${date1} AND insertdate <= ${date2}
GROUP BY ordernum;

-----------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------
------------------------------------------------- 一级分销商id / 销售价 / 成本价 ------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------


DROP VIEW IF EXISTS order_split;
CACHE TABLE order_split
AS
SELECT orderid, buyerid AS distribute_1_id, sale_money AS distribute_1_price, cost_money AS distribute_1_cost_price
FROM s_order_split_d_i
WHERE orderdate = ${ds}
-- WHERE orderdate >= ${date1} AND orderdate <= ${date2}
  AND level IN (0, 1);


-----------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------
------------------------------------------------ 订单主子票（原始类型，未修正特殊套票） -------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------


DROP VIEW IF EXISTS order_addon;
CACHE TABLE order_addon
AS
SELECT  
    order.ordernum,
    IF(addon.ifpack=2, '套票子票', IF(addon.ifpack=1, '套票主票', '单票'))  AS order_type,
    addon.pack_order                                                    AS pack_order_main_ordernum
FROM 
(
    SELECT ordernum
    FROM ods_order_d_i  
    WHERE orderdate = ${ds}
    -- WHERE orderdate >= ${date1} AND orderdate <= ${date2}

) AS order
-- 套票信息
LEFT JOIN 
(
    SELECT  
        orderid,
        -- 套票主子票的主单号
        IF(pack_order='1', orderid, pack_order) AS pack_order,
        ifpack   
    FROM ods_order_addon_d_i
    WHERE orderdate = ${ds}   
    -- WHERE orderdate >= ${date1} AND orderdate <= ${date2}
    -- pack_order = 1 套票主单
    -- pack_order > 1 套票子单
      AND NOT ISNULL(pack_order)
) AS addon  
ON order.ordernum = addon.orderid;


-----------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------
----------------------------------------------- 取票人归属地 - 手机 ------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------
 

-- 手机号码归属地
DROP VIEW IF EXISTS phone_area;
CACHE TABLE phone_area
AS 
SELECT 
    ot.ordernum,

    IF (
        dt.name_zh IN ('中国', '香港', '澳门', '台湾'),
        '中国',
        NVL(dt.name_zh, '未知')
    )                                       AS country_name,

    -- 取票人省份
    IF (
        -- 港澳台的特殊处理
        dt.name_zh IN ('中国', '香港', '澳门', '台湾'),

        CASE dt.name_zh
            WHEN '香港' THEN '香港特别行政区'
            WHEN '澳门' THEN '澳门特别行政区'
            WHEN '台湾' THEN '台湾省'
            WHEN '中国' THEN IF(LENGTH(ot.ordertel) = 11 AND ISNOTNULL(phone.province_name), phone.province_name, '未知')
        END, 

        -- 非中国情况,外国都归为未知
        -- IF (
        --     ISNULL(dt.name_zh) OR dt.name_zh = '',
        --     '未知',
        --     dt.name_zh
        -- )
        '未知'
    )                                       AS province_name,

    -- 取票人市
    IF (
        dt.name_zh IN ('中国', '香港', '澳门', '台湾'),

        CASE dt.name_zh
            WHEN '香港' THEN '香港特别行政区'
            WHEN '澳门' THEN '澳门特别行政区'
            WHEN '台湾' THEN '台湾省'
            WHEN '中国' THEN IF(LENGTH(ot.ordertel) = 11 AND ISNOTNULL(phone.city_name), phone.city_name, '未知')
        END, 

        -- 非中国情况,外国都归为未知
        -- IF (
        --     ISNULL(dt.name_zh) OR dt.name_zh = '',
        --     '未知',
        --     dt.name_zh
        -- )
        '未知'
    )                                       AS city_name     

FROM 
(
    -- 取票人信息
    SELECT ordernum, ordertel, mobile_area
    FROM ods_order_user_info_d_i 
    WHERE orderdate = ${ds}
    -- WHERE orderdate >= ${date1} AND orderdate <= ${date2}
) AS ot
LEFT JOIN 
(
    -- 手机号国籍
    SELECT phone_area_code, name_zh
    FROM dim_phone_global_d_f
    WHERE pt = FROM_UNIXTIME(UNIX_TIMESTAMP(DATE_SUB(CURRENT_DATE, 1)), 'yyyyMMdd')
) AS dt 
ON ot.mobile_area = dt.phone_area_code
LEFT JOIN 
(
    -- 手机号码地区维表
    SELECT phone_number, province_name, city_name
    FROM dim_phone_city_fixed_d_f 
    WHERE pt = FROM_UNIXTIME(UNIX_TIMESTAMP(DATE_SUB(CURRENT_DATE, 1)), 'yyyyMMdd')
) AS phone 
ON SUBSTR(ot.ordertel, 1, 7) = phone.phone_number;

-----------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------
---------------------------------------------- 取票人归属地 - 证件号码 ----------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------

DROP VIEW IF EXISTS idcard_area;
CACHE TABLE idcard_area
AS
-- voucher_type = 1 身份证
SELECT 
    ordernum,
    '中国'                      AS idcard_country_name,
    NVL(province_name, '未知')  AS idcard_province_name,
    NVL(city_name, '未知')      AS idcard_city_name,
    NVL(district_name, '未知')  AS idcard_district_name
FROM 
(
    SELECT ordernum,  personid
    FROM ods_order_user_info_d_i 
    WHERE voucher_type = 1
      AND orderdate = ${ds}
      -- AND orderdate >= ${date1} AND orderdate <= ${date2}
      -- AND LENGTH(idcard) = 18
) AS info
LEFT JOIN 
(
    -- 身份证地区维表
    SELECT idcard, country_name, province_name, city_name, district_name
    FROM dim_idcard_city_fixed_d_f 
    WHERE pt = FROM_UNIXTIME(UNIX_TIMESTAMP(DATE_SUB(CURRENT_DATE, 1)), 'yyyyMMdd')
) AS city_table 
ON SUBSTR(info.personid, 1, 6) = city_table.idcard

UNION ALL 

-- voucher_type = 2 护照
SELECT 
    ordernum,
    '境外'          AS idcard_country_name,
    '未知'          AS idcard_province_name,
    '未知'          AS idcard_city_name,
    '未知'          AS idcard_district_name
FROM ods_order_user_info_d_i 
WHERE voucher_type = 2
  AND orderdate = ${ds}
  -- AND orderdate >= ${date1} AND orderdate <= ${date2}
    
UNION ALL 

-- voucher_type = 3  军官证
SELECT 
    ordernum,
    '中国'              AS idcard_country_name,
    '未知'              AS idcard_province_name,
    '未知'              AS idcard_city_name,
    '未知'              AS idcard_district_name
FROM ods_order_user_info_d_i 
WHERE voucher_type = 3
  AND orderdate = ${ds}
  -- AND orderdate >= ${date1} AND orderdate <= ${date2}

UNION ALL 

-- voucher_type = 4 港澳居民来往大陆通行证（回乡证）
SELECT 
    ordernum,
    '中国'      AS idcard_country_name,
    CASE 
        WHEN SUBSTR(personid, 1, 1) = 'H' THEN '香港特别行政区'
        WHEN SUBSTR(personid, 1, 1) = 'M' THEN '澳门特别行政区'
        ELSE  '未知'
    END        AS idcard_province_name,
    CASE 
        WHEN SUBSTR(personid, 1, 1) = 'H' THEN '香港特别行政区'
        WHEN SUBSTR(personid, 1, 1) = 'M' THEN '澳门特别行政区'
        ELSE  '未知'
    END         AS idcard_city_name,
    CASE 
        WHEN SUBSTR(personid, 1, 1) = 'H' THEN '香港特别行政区'
        WHEN SUBSTR(personid, 1, 1) = 'M' THEN '澳门特别行政区'
        ELSE  '未知'
    END         AS idcard_district_name
FROM ods_order_user_info_d_i 
WHERE voucher_type = 4
  AND orderdate = ${ds}
  -- AND orderdate >= ${date1} AND orderdate <= ${date2}

UNION ALL 

-- voucher_type = 5  台胞证
SELECT 
    ordernum,
    '中国'  AS idcard_country_name,
    '台湾省'  AS idcard_province_name,
    '台湾省'  AS idcard_city_name,
    '台湾省'  AS idcard_district_name
FROM ods_order_user_info_d_i 
WHERE voucher_type = 5
  AND orderdate = ${ds}
  -- AND orderdate >= ${date1} AND orderdate <= ${date2}

UNION ALL 

-- voucher_type = 6   外国人永久居留证
SELECT 
    ordernum,
    '中国'  AS idcard_country_name,
    '未知'  AS idcard_province_name,
    '未知'  AS idcard_city_name,
    '未知'  AS idcard_district_name
FROM ods_order_user_info_d_i 
WHERE voucher_type = 6
  AND orderdate = ${ds}
  -- AND orderdate >= ${date1} AND orderdate <= ${date2}

UNION ALL 

-- voucher_type = 7  港澳通行证
SELECT 
    ordernum,
    '中国'  AS idcard_country_name,
    '未知'  AS idcard_province_name,    
    '未知'  AS idcard_city_name,
    '未知'  AS idcard_district_name
FROM ods_order_user_info_d_i 
WHERE voucher_type = 7
  AND orderdate = ${ds}
  -- AND orderdate >= ${date1} AND orderdate <= ${date2}

UNION ALL 

-- voucher_type = 8  台湾省通行证
SELECT 
    ordernum,
    '中国'  AS idcard_country_name,
    '台湾省'  AS idcard_province_name,
    '台湾省'  AS idcard_city_name,
    '台湾省'  AS idcard_district_name
FROM ods_order_user_info_d_i 
WHERE voucher_type = 8
  AND orderdate = ${ds}
  -- AND orderdate >= ${date1} AND orderdate <= ${date2}

UNION ALL 

-- voucher_type = 9  港澳居民居住证
SELECT 
    ordernum,
    '中国'  AS idcard_country_name,
    CASE 
        WHEN SUBSTR(personid, 1, 2) = 81 THEN '香港特别行政区'
        WHEN SUBSTR(personid, 1, 2) = 82 THEN '澳门特别行政区'
        ELSE  '未知'
    END         AS idcard_province_name, 
    CASE 
        WHEN SUBSTR(personid, 1, 2) = 81 THEN '香港特别行政区'
        WHEN SUBSTR(personid, 1, 2) = 82 THEN '澳门特别行政区'
        ELSE  '未知'
    END         AS idcard_city_name,
    CASE 
        WHEN SUBSTR(personid, 1, 2) = 81 THEN '香港特别行政区'
        WHEN SUBSTR(personid, 1, 2) = 82 THEN '澳门特别行政区'
        ELSE  '未知'
    END         AS idcard_district_name
FROM ods_order_user_info_d_i 
WHERE voucher_type = 9
  AND orderdate = ${ds}
  -- AND orderdate >= ${date1} AND orderdate <= ${date2}

UNION ALL 

-- voucher_type = 10  台湾省居民居住证
SELECT 
    ordernum,
    '中国'  AS idcard_country_name,
    '台湾省'  AS idcard_province_name,
    '台湾省'  AS idcard_city_name,
    '台湾省'  AS idcard_district_name
FROM ods_order_user_info_d_i 
WHERE voucher_type = 10
  AND orderdate = ${ds}
  -- AND orderdate >= ${date1} AND orderdate <= ${date2}

UNION ALL 

-- voucher_type = 99  其他
SELECT 
    ordernum,
    '未知'  AS idcard_country_name,
    '未知'  AS idcard_province_name,
    '未知'  AS idcard_city_name,
    '未知'  AS idcard_district_name
FROM ods_order_user_info_d_i 
WHERE voucher_type = 99
  AND orderdate = ${ds}
  -- AND orderdate >= ${date1} AND orderdate <= ${date2}

UNION ALL 

-- voucher_type 其他取值
SELECT 
    ordernum,
    '未知'  AS idcard_country_name,
    '未知'  AS idcard_province_name,
    '未知'  AS idcard_city_name,
    '未知'  AS idcard_district_name
FROM ods_order_user_info_d_i 
WHERE voucher_type NOT IN (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 99)
  AND orderdate = ${ds};
  -- AND orderdate >= ${date1} AND orderdate <= ${date2};


-----------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------
-------------------------------------------------------- 性别年龄 ------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------

DROP VIEW IF EXISTS age_sex_table;
CACHE TABLE age_sex_table
AS
SELECT ordernum, age, sex
FROM (
    SELECT 
        ordernum, 
        FLOOR (
                DATEDIFF(
                    TO_DATE(CAST(orderdate AS STRING), 'yyyyMMdd'), 
                    FROM_UNIXTIME(UNIX_TIMESTAMP(SUBSTR(personid, 7, 8), 'yyyyMMdd'))
                ) / 365
            )   AS age,
        IF (SUBSTR(personid, 17, 1) % 2 = 0, "女", "男")  AS sex
    FROM ods_order_user_info_d_i 
    WHERE voucher_type = 1 
      AND LENGTH(personid) = 18
      AND orderdate = ${ds}
      -- AND orderdate >= ${date1} AND orderdate <= ${date2}

) WHERE age >= 0 AND age <= 116;

-----------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------
----------------------------------------------- 取票人归属地性别年龄  -----------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------

DROP VIEW IF EXISTS result_table;
CACHE TABLE result_table
AS 
SELECT 
    ot.ordernum                             AS ordernum, 

    NVL(phone_area.`country_name`, '未知')   AS `phone_country_name`, 
    NVL(phone_area.`province_name`, '未知')  AS `phone_province_name`,
    NVL(phone_area.`city_name`, '未知')      AS `phone_city_name`, 
    IF (
        phone_area.`city_name` = idcard_area.`idcard_city_name`,
        idcard_area.`idcard_district_name`,
        NVL(phone_area.`city_name`, '未知')
    )                                               AS `phone_district_name`,    

    NVL(idcard_area.`idcard_country_name`, '未知')   AS `idcard_country_name`,
    NVL(idcard_area.`idcard_province_name`, '未知')  AS `idcard_province_name`,
    NVL(idcard_area.`idcard_city_name`, '未知')      AS `idcard_city_name`,
    NVL(idcard_area.`idcard_district_name`, '未知')  AS `idcard_district_name`,

    NVL(age_sex_table.`age`, -1)                   AS `age`, 
    NVL(age_sex_table.`sex`, '未知')                AS `sex`
FROM 
(
    SELECT ordernum
    FROM ods_order_d_i
    WHERE orderdate = ${ds}  
    -- WHERE orderdate >= ${date1} AND orderdate <= ${date2}

) AS ot 
LEFT JOIN phone_area ON ot.ordernum = phone_area.ordernum
LEFT JOIN idcard_area ON ot.ordernum = idcard_area.ordernum
LEFT JOIN age_sex_table ON ot.ordernum = age_sex_table.ordernum;


-----------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------
----------------------------------------------- 订单子票的主票相关信息  ---------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------


DROP VIEW IF EXISTS order_addon_dim;
CACHE TABLE order_addon_dim
AS 
-- 子票订单
SELECT 
    -- addon.main_orderid  AS main_orderid, 
    -- 子票 id
    addon.orderid       AS sub_orderid,

    o.apply_did         AS main_sid,
    o.lid               AS main_lid, 
    o.tid               AS main_tid, 
    o.product_type      AS main_p_type, 
    o.pid               AS main_pid
    -- o.orderdate
FROM
(
    -- 主票的各种信息
    SELECT ordernum, lid, tid, apply_did, product_type, pid, orderdate
    FROM ods_order_d_i
    WHERE orderdate = ${ds}
) AS o
JOIN
(
    SELECT
        pack_order  AS main_orderid,
        orderid     AS orderid,
        ifpack
    FROM ods_order_addon_d_i
    WHERE 1 = 1 
    -- ifpack: 1=套票主票, 2=套票子票
      AND ifpack=2
      AND orderdate = ${ds}
) AS addon
-- 主票
ON o.ordernum = addon.main_orderid;


-----------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------

INSERT OVERWRITE TABLE dim_order_d_i_dev PARTITION(`orderdate` = ${ds})
-- 渠道非20
SELECT 
    order.ordernum      AS orderid,
    order.apply_did,
    order.aid,
    order.salerid,
    order.member,
    order.lid,
    order.tid,
    order.pid,
    order.product_type,
    DATE_FORMAT(order.playtime, 'yyyy-MM-dd') AS play_date,
    try_cast(order.paymode as tinyint) AS paymode,
    order.ordermode,

    type.channel_class1_id, 
    type.channel_class1_name, 
    INT(type.channel_class2_id), 
    type.channel_class2_name,

    order.tprice                            AS `sale_price`,
    NVL(ordert.booking_ticket_num_sum, 0)   AS `origin_num`,
    NVL(ordert.pay_ticket_num_sum, 0)       AS `pay_num`,

    split.distribute_1_id, 
    split.distribute_1_price, 
    split.distribute_1_cost_price,

    -- 归属地，性别年龄
    IF (`phone_country_name` != '未知', `phone_country_name`, `idcard_country_name`)        AS `ticket_taker_country`,
    IF (`phone_country_name` != '未知', `phone_province_name`, `idcard_province_name`)      AS `ticket_taker_province`,
    IF (`phone_country_name` != '未知', `phone_city_name`, `idcard_city_name`)              AS `ticket_taker_city`,
    IF (`phone_country_name` != '未知', `phone_district_name`, `idcard_district_name`)      AS `ticket_taker_district`,

    `phone_country_name`    AS `ticket_taker_country_phone`,  
    `phone_province_name`   AS `ticket_taker_province_phone`, 
    `phone_city_name`       AS `ticket_taker_city_phone`,     
    `phone_district_name`   AS `ticket_taker_district_phone`, 

    `idcard_country_name`   AS `ticket_taker_country_idcard`,
    `idcard_province_name`  AS `ticket_taker_province_idcard`, 
    `idcard_city_name`      AS `ticket_taker_city_idcard`,    
    `idcard_district_name`  AS `ticket_taker_district_idcard`,

    `sex`                   AS `ticket_taker_sex`,
    `age`                   AS `ticket_taker_age`,

    addon.order_type,
    IF((addon.pack_order_main_ordernum IS NULL) OR (addon.pack_order_main_ordernum = ''), -1, addon.pack_order_main_ordernum),
    -- NVL(addon.pack_order_main_ordernum, -1),

    pay_status                              AS order_pay_status,
    FROM_UNIXTIME(pay_time, 'yyyy-MM-dd')   AS pay_date,
    status                                  AS order_status,

    NVL(order_addon_dim.main_sid, order.apply_did)          AS main_sid,   
    NVL(order_addon_dim.main_lid, order.lid)                AS main_lid,   
    NVL(order_addon_dim.main_tid, order.tid)                AS main_tid,   
    NVL(order_addon_dim.main_p_type, order.product_type)    AS main_product_type,
    NVL(order_addon_dim.main_pid, order.pid)                AS main_pid  

FROM 
(
    SELECT ordernum, apply_did, aid, salerid, member, lid, tid, pid, product_type, playtime, paymode, ordermode, pay_status, pay_time, status, tprice
    FROM ods_order_d_i 
    WHERE 1=1
      AND orderdate = ${ds}
    --   AND orderdate >= ${date1} AND orderdate <= ${date2}
      AND ordermode != 20
) AS order
LEFT JOIN 
(
    SELECT channel_class1_id, channel_class1_name, channel_class2_id, channel_class2_name
    FROM dim_distribute_channel_type_o_f
) AS type 
ON order.ordermode = type.channel_class2_id
LEFT JOIN 
(
    SELECT *
    FROM order_tnum
) AS ordert 
ON order.ordernum = ordert.ordernum 
LEFT JOIN 
(
    SELECT orderid, distribute_1_id, distribute_1_price, distribute_1_cost_price
    FROM order_split
) AS split 
ON order.ordernum = split.orderid
LEFT JOIN 
(
    SELECT ordernum, order_type, pack_order_main_ordernum
    FROM order_addon
) AS addon
ON order.ordernum = addon.ordernum
LEFT JOIN result_table
ON order.ordernum = result_table.ordernum
LEFT JOIN order_addon_dim
ON order.ordernum = order_addon_dim.sub_orderid

UNION ALL

-- 渠道为20的
SELECT 
    order.ordernum      AS orderid,
    order.apply_did,
    order.aid,
    order.salerid,
    order.member,
    order.lid,
    order.tid,
    order.pid,
    order.product_type,
    DATE_FORMAT(order.playtime, 'yyyy-MM-dd')       AS play_date,
    try_cast(order.paymode as tinyint)              AS paymode,
    order.ordermode,

    3                                               AS channel_class1_id, 
    'OTA'                                           AS channel_class1_name,
    INT(NVL(ota.target_id, 2000))                   AS channel_class2_id,
    NVL(ota.channel_aggregation_name, '商家自研')    AS channel_class2_name,

    order.tprice                                    AS `sale_price`,
    NVL(ordert.booking_ticket_num_sum, 0)           AS `origin_num`,
    NVL(ordert.pay_ticket_num_sum, 0)               AS `pay_num`,

    split.distribute_1_id, 
    split.distribute_1_price, 
    split.distribute_1_cost_price,

    IF (`phone_country_name` != '未知', `phone_country_name`, `idcard_country_name`)    AS `ticket_taker_country`,
    IF (`phone_country_name` != '未知', `phone_province_name`, `idcard_province_name`)  AS `ticket_taker_province`,
    IF (`phone_country_name` != '未知', `phone_city_name`, `idcard_city_name`)          AS `ticket_taker_city`,
    IF (`phone_country_name` != '未知', `phone_district_name`, `idcard_district_name`)  AS `ticket_taker_district`,
    
    `phone_country_name`    AS `ticket_taker_country_phone`,  
    `phone_province_name`   AS `ticket_taker_province_phone`, 
    `phone_city_name`       AS `ticket_taker_city_phone`,     
    `phone_district_name`   AS `ticket_taker_district_phone`, 

    `idcard_country_name`   AS `ticket_taker_country_idcard`,
    `idcard_province_name`  AS `ticket_taker_province_idcard`, 
    `idcard_city_name`      AS `ticket_taker_city_idcard`,    
    `idcard_district_name`  AS `ticket_taker_district_idcard`,

    `sex`                   AS `ticket_taker_sex`,
    `age`                   AS `ticket_taker_age`,

    addon.order_type,
    IF((addon.pack_order_main_ordernum IS NULL) OR (addon.pack_order_main_ordernum = ''), -1, addon.pack_order_main_ordernum),
    -- NVL(addon.pack_order_main_ordernum, -1),

    pay_status                              AS order_pay_status,
    FROM_UNIXTIME(pay_time, 'yyyy-MM-dd')   AS pay_date,
    status                                  AS order_status,

    NVL(order_addon_dim.main_sid, order.apply_did)          AS main_sid,   
    NVL(order_addon_dim.main_lid, order.lid)                AS main_lid,   
    NVL(order_addon_dim.main_tid, order.tid)                AS main_tid,   
    NVL(order_addon_dim.main_p_type, order.product_type)    AS main_product_type,
    NVL(order_addon_dim.main_pid, order.pid)                AS main_pid
FROM 
(
    SELECT ordernum, apply_did, aid, salerid, member, lid, tid, pid, product_type, playtime, paymode, ordermode, pay_status, pay_time, status, tprice
    FROM ods_order_d_i 
    WHERE 1=1
      AND orderdate = ${ds}
      -- AND orderdate >= ${date1} AND orderdate <= ${date2}
      AND ordermode = 20
) AS order
LEFT JOIN 
(
    SELECT id, target_id, channel_aggregation_name
    FROM cache_table_loopback

    UNION 
    
    SELECT id, target_id, channel_aggregation_name
    FROM cache_table_member
) AS ota 
ON order.member = ota.id
LEFT JOIN 
(
    SELECT *
    FROM order_tnum
) AS ordert 
ON order.ordernum = ordert.ordernum 
LEFT JOIN 
(
    SELECT orderid, distribute_1_id, distribute_1_price, distribute_1_cost_price
    FROM order_split
) AS split 
ON order.ordernum = split.orderid
LEFT JOIN 
(
    SELECT ordernum, order_type, pack_order_main_ordernum
    FROM order_addon
) AS addon
ON order.ordernum = addon.ordernum
LEFT JOIN result_table
ON order.ordernum = result_table.ordernum
LEFT JOIN order_addon_dim
ON order.ordernum = order_addon_dim.sub_orderid;


-----------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------


INSERT OVERWRITE TABLE dim_order_d_i_dev PARTITION(`orderdate`)
-- 增加逻辑:更新昨日之前二十九日更新状态的数据
-- 支付时间，支付状态，预计游玩时间
SELECT 
    `orderid`,
    `apply_did`,
    `aid`,
    `salerid`,
    `member`,
    `lid`,
    `tid`,
    `pid`,
    `product_type`,
    -- 刷新最近三十日数据
    -- `playdate`,
    NVL(DATE_FORMAT(t2.playtime, 'yyyy-MM-dd'), t1.playdate)    AS `playdate`,

    `paymode`,
    `ordermode`,
    `channel_class1_id`,
    `channel_class1_name`,
    `channel_class2_id`,
    `channel_class2_name`,
    `sale_price`,
    `origin_num`,
    `pay_num`,
    `distribute_1_id`,
    `distribute_1_price`,
    `distribute_1_cost_price`,
    `ticket_taker_country`,
    `ticket_taker_province`,
    `ticket_taker_city`,
    `ticket_taker_district`,
    `ticket_taker_country_phone`,
    `ticket_taker_province_phone`,
    `ticket_taker_city_phone`,
    `ticket_taker_district_phone`,
    `ticket_taker_country_idcard`,
    `ticket_taker_province_idcard`,
    `ticket_taker_city_idcard`,
    `ticket_taker_district_idcard`,
    `ticket_taker_sex`,
    `ticket_taker_age`,
    `order_type`,
    `pack_order_main_ordernum`,

    -- 刷新最近三十日数据
    -- `order_pay_status`,
    -- `pay_date`,
    -- `order_status`,
    NVL(t2.pay_status, t1.order_pay_status)                      AS `order_pay_status`,
    NVL(FROM_UNIXTIME(t2.pay_time, 'yyyy-MM-dd'), t1.pay_date)   AS `pay_date`,
    NVL(t2.status, t1.order_status)                              AS `order_status`,

    `main_sid`,
    `main_lid`,
    `main_tid`,
    `main_product_type`,
    `main_pid`,

    `orderdate`
FROM 
(
    SELECT *
    FROM dim_order_d_i_dev 
    WHERE 1=1
      AND orderdate >= CAST(DATE_FORMAT(DATE_SUB(TO_DATE(CAST(${ds} AS STRING), 'yyyyMMdd'), 30), 'yyyyMMdd') AS INT)
      AND orderdate <= CAST(DATE_FORMAT(DATE_SUB(TO_DATE(CAST(${ds} AS STRING), 'yyyyMMdd'), 1), 'yyyyMMdd') AS INT)
) AS t1
LEFT JOIN 
(
    SELECT 
        `ordernum`,
        `pay_status`,
        `pay_time`,
        `status`,
        `playtime`
    FROM ods_order_update_d_i 
    WHERE 1=1 
      AND `update` = ${ds}
) AS t2 
ON t1.orderid = t2.ordernum;

