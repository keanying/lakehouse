--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-15 14:36:20
--EMR任务只能运行在独享资源组上
--********************************************************************--


CREATE TABLE IF NOT EXISTS dwd_split_d_i(
    -- 分销表字段
    `id`                        BIGINT  COMMENT '', 
    `orderid`                   STRING  COMMENT '订单号', 
    `buyerid`                   INT     COMMENT '购买用户ID', 
    `sellerid`                  INT     COMMENT '供应商ID', 
    `apply_did`                 INT     COMMENT '原始供应商ID', 

    -- 替代ods_order_aids_distribute_d_i
    `distribute_num`            INT     COMMENT '订单总分销级别',
    `distributor_1_id`          INT     COMMENT '一级分销商id',

    -- 补充字段
    `detail_split_level`        INT     COMMENT '标识具体分销层级,1~6', 
    `is_end_level`              INT     COMMENT '是否分销末级',

    -- 订单表字段
    `lid`                       INT     COMMENT '景区id',
    `tid`                       INT     COMMENT '门票id',
    `pid`                       INT     COMMENT '产品id',
    `product_type`              STRING  COMMENT '商品类型',

    `paymode`                   TINYINT COMMENT '支付方式：0 = 余额支付,1 = 支付宝,2 = 授信支付,3 = 产品自销,4 = 现场支付,5 = 微信支付,6 = 会员卡支付,7 = 银联支付,8 = 环迅支付,9 = 现金支付,10 = 会员卡,11 = 拉卡拉（商户）,12 = 拉卡拉（平台）,13 = 特权支付（年卡）,14 = 微信（聚合）,15 = 平安银行,16 = 支付宝（聚合）,17 = 会员卡支付,18 = 计时卡支付,25 = 招行一网通支付,26 = 银联商务支付,27 = 银联商务POS支付,28 = 威富通支付,29 = 易宝云企付,33 = 博思支付,35 = 积分支付,36 = POS支',
    `ordermode`                 TINYINT COMMENT '下单方式:0=正常分销商下单,1=普通用户支付,2=用户手机支付,3=会员卡购票,10=云票务,11=微信商城,12=自助机,13=二级店铺,14=闸机购票,15=智能终端,16=计调下单,17=淘宝码商,18=年卡,19=微信端,20=外部接口OTA下单,22=一卡通,23=套票子票',

    -- 渠道
    `channel_class1_id`         INT     COMMENT '渠道一级分类id',
    `channel_class1_name`       STRING  COMMENT '渠道一级分类名称',
    `channel_class2_id`         INT     COMMENT '渠道二级分类id',
    `channel_class2_name`       STRING  COMMENT '渠道二级分类名称',

    -- 票钱
    `sale_price`                INT     COMMENT '实际售价(uu_ss_order表的tprice)',
    `origin_num`                INT     COMMENT '预定票数(订单轨迹表清洗的预定票数)',
    `pay_num`                   INT     COMMENT '支付票数(订单轨迹表清洗的支付票数)',

    -- 取票人游客画像
    `ticket_taker_country`      STRING  COMMENT '取票人所在国(优先手机号码，为空则身份证)',
    `ticket_taker_province`     STRING  COMMENT '取票人所在省(优先手机号码，为空则身份证)',
    `ticket_taker_city`         STRING  COMMENT '取票人所在市(优先手机号码，为空则身份证)',
    `ticket_taker_district`     STRING  COMMENT '取票人所在县(优先手机号码，为空则身份证)',

    -- 取票人年龄性别
    `ticket_taker_sex`          STRING  COMMENT '取票人性别',
    `ticket_taker_age`          STRING  COMMENT '取票人年龄', 

    -- 主子单
    `order_type`                STRING  COMMENT '票类型：套票主票/单票/套票子票',

    `order_pay_status`          INT     COMMENT '订单支付状态:0=现场支付,1=已支付,2=未支付',
    `pay_date`                  STRING  COMMENT '支付时间',
    `order_status`              STRING  COMMENT '订单状态',
    `playdate`                  STRING  COMMENT '预计游玩时间',

    -- 主子单相关信息
    `main_sid`                  STRING  COMMENT '套票子票(主票的 sid)，套票主票/单票（原订单的 sid）',
    `main_lid`                  STRING  COMMENT '套票子票(主票的 lid)，套票主票/单票（原订单的 lid）',
    `main_tid`                  STRING  COMMENT '套票子票(主票的 tid)，套票主票/单票（原订单的 tid）',
    `main_product_type`         STRING  COMMENT '套票子票(主票的 p_type)，套票主票/单票（原订单的 p_type）',
    `main_pid`                  STRING  COMMENT '套票子票(主票的 pid)，套票主票/单票（原订单的 pid）'

)COMMENT '订单分销链-增量表' PARTITIONED by(
    orderdate                   INT     COMMENT '下单日期'
)STORED AS ORC;

SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=128MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;

DROP VIEW IF EXISTS CACHE_TABLE_1;
CACHE TABLE CACHE_TABLE_1
AS
SELECT 
    split_table.`id`,       
    split_table.`orderid`,  
    split_table.`buyerid`,  
    split_table.`sellerid`, 
    split_table.`apply_did`,
    split_table.`distribute_num`,   
    split_table.`distributor_1_id`, 
    split_table.`detail_split_level`, 
    split_table.`is_end_level`,

    order_table.`lid`,
    order_table.`tid`,
    order_table.`pid`,
    order_table.`product_type`,
    order_table.`paymode`,
    order_table.`ordermode`,
    order_table.`channel_class1_id`,
    order_table.`channel_class1_name`,
    order_table.`channel_class2_id`,
    order_table.`channel_class2_name`,

    order_table.`sale_price`,
    order_table.`origin_num`,
    order_table.`pay_num`,

    order_table.`ticket_taker_country`,
    order_table.`ticket_taker_province`,
    order_table.`ticket_taker_city`,
    order_table.`ticket_taker_district`,
    order_table.`ticket_taker_sex`,
    order_table.`ticket_taker_age`,

    order_table.`order_type`,
    order_table.`pack_order_main_ordernum`,
    order_table.`order_pay_status`,
    order_table.`pay_date`,
    order_table.`order_status`,
    order_table.`playdate`,

    order_table.`main_sid`,
    order_table.`main_lid`,
    order_table.`main_tid`,
    order_table.`main_product_type`,
    order_table.`main_pid`
FROM 
(
    SELECT 
        `id`,       
        `orderid`,  
        `buyerid`,  
        `sellerid`, 
        `apply_did`,
        `distribute_num`,   
        `distributor_1_id`, 
        `detail_split_level`, 
        `is_end_level`       
    FROM ods_order_split_d_i
    WHERE `orderdate` = ${ds}
) AS split_table
LEFT JOIN 
(
    SELECT 
        `orderid`, 
        `lid`,
        `tid`,
        `pid`,
        `product_type`,
        `paymode`,
        `ordermode`,
        `channel_class1_id`,
        `channel_class1_name`,
        `channel_class2_id`,
        `channel_class2_name`,

        `sale_price`,
        `origin_num`,
        `pay_num`,
        
        `ticket_taker_country`,
        `ticket_taker_province`,
        `ticket_taker_city`,
        `ticket_taker_district`,
        `ticket_taker_sex`,
        `ticket_taker_age`,
        `order_type`,
        `pack_order_main_ordernum`,
        `order_pay_status`,
        `pay_date`,
        `order_status`,
        `playdate`,

        `main_sid`,
        `main_lid`,
        `main_tid`,
        `main_product_type`,
        `main_pid`
    FROM dim_order_d_i
    WHERE `orderdate` = ${ds}
) AS order_table
ON split_table.orderid = order_table.orderid;


-- 套票的主票分销顶级供应商
DROP VIEW IF EXISTS CACHE_TABLE_2;
CACHE TABLE CACHE_TABLE_2
AS
SELECT 
    t1.orderid,
    t1.sellerid,
    t2.apply_did
FROM 
(
    -- 分销套票主子票
    SELECT orderid, sellerid, pack_order_main_ordernum
    FROM CACHE_TABLE_1
    WHERE pack_order_main_ordernum != '-1'
) AS t1 
LEFT JOIN 
(
    -- 套票主票分销链顶级供应商
    SELECT orderid, apply_did
    FROM CACHE_TABLE_1
    WHERE order_type = '套票主票' AND detail_split_level = 1 
) AS t2
ON t1.pack_order_main_ordernum = t2.orderid;


-- 不是由自己销售出去的套票子票（以套票主票分销顶级销售商为准）修改订单类型为单票
INSERT OVERWRITE TABLE dwd_split_d_i PARTITION(`orderdate` = ${ds})
SELECT
    `id`,       
    CACHE_TABLE_1.`orderid`,  
    `buyerid`,  
    CACHE_TABLE_1.`sellerid`, 
    CACHE_TABLE_1.`apply_did`,
    `distribute_num`,   
    `distributor_1_id`, 
    `detail_split_level`, 
    `is_end_level`,

    `lid`,
    `tid`,
    `pid`,
    `product_type`,
    `paymode`,
    `ordermode`,
    `channel_class1_id`,
    `channel_class1_name`,
    `channel_class2_id`,
    `channel_class2_name`,

    `sale_price`,
    `origin_num`,
    `pay_num`,

    `ticket_taker_country`,
    `ticket_taker_province`,
    `ticket_taker_city`,
    `ticket_taker_district`,
    `ticket_taker_sex`,
    `ticket_taker_age`,
    -- 修正套票类型
    IF (
        CACHE_TABLE_1.`sellerid` != CACHE_TABLE_2.apply_did,
        '单票',
        CACHE_TABLE_1.`order_type`
    )                   AS `order_type`,
    `order_pay_status`,
    `pay_date`,
    `order_status`,
    `playdate`,

    `main_sid`,
    `main_lid`,
    `main_tid`,
    `main_product_type`,
    `main_pid`
FROM CACHE_TABLE_1
LEFT JOIN CACHE_TABLE_2
ON CACHE_TABLE_1.orderid = CACHE_TABLE_2.orderid AND CACHE_TABLE_1.sellerid = CACHE_TABLE_2.sellerid;


------------------------------------------------------------------------------------------------------------------------


INSERT OVERWRITE TABLE dwd_split_d_i PARTITION(`orderdate`)
SELECT
    -- 增加逻辑:更新昨日之前二十九日更新状态的数据
    -- 支付时间，支付状态，预计游玩时间
    `id`,
    `orderid`,
    `buyerid`,
    `sellerid`,
    `apply_did`,
    `distribute_num`,
    `distributor_1_id`,
    `detail_split_level`,
    `is_end_level`,
    `lid`,
    `tid`,
    `pid`,
    `product_type`,
    `paymode`,
    `ordermode`,
    `channel_class1_id`,
    `channel_class1_name`,
    `channel_class2_id`,
    `channel_class2_name`,
    `sale_price`,
    `origin_num`,
    `pay_num`,
    `ticket_taker_country`,
    `ticket_taker_province`,
    `ticket_taker_city`,
    `ticket_taker_district`,
    `ticket_taker_sex`,
    `ticket_taker_age`,
    `order_type`,

    -- `order_pay_status`,
    -- `pay_date`,
    -- `order_status`,
    -- `playdate`,

    -- 刷新最近三十日数据
    -- `order_pay_status`,
    -- `pay_date`,
    -- `order_status`,
    NVL(t2.pay_status, t1.order_pay_status)                         AS `order_pay_status`,
    NVL(FROM_UNIXTIME(t2.pay_time, 'yyyy-MM-dd'), t1.pay_date)      AS `pay_date`,
    NVL(t2.status, t1.order_status)                                 AS `order_status`,
    NVL(DATE_FORMAT(t2.playtime, 'yyyy-MM-dd'), t1.playdate)        AS `playdate`,

    `main_sid`,
    `main_lid`,
    `main_tid`,
    `main_product_type`,
    `main_pid`,

    `orderdate`
FROM 
(
    SELECT *
    FROM dwd_split_d_i 
    WHERE 1=1
    AND orderdate >= CAST(DATE_FORMAT(DATE_SUB(TO_DATE(CAST(${ds} AS STRING), 'yyyyMMdd'), 30), 'yyyyMMdd') AS INT)
    AND orderdate <= CAST(DATE_FORMAT(DATE_SUB(TO_DATE(CAST(${ds} AS STRING), 'yyyyMMdd'), 1), 'yyyyMMdd') AS INT)
) AS t1
LEFT JOIN 
(
    SELECT 
        `ordernum`,
        `pay_status`,
        `pay_time`,
        `status`,
        `playtime`
    FROM ods_order_update_d_i 
    WHERE 1=1 
    AND `update` = ${ds}
) AS t2 
ON t1.orderid = t2.ordernum;

