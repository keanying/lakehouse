--Serverless Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2026-04-14 13:56:53
--Serverless Spark SQL任务只能运行在独享资源组上
--********************************************************************--

-----------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------
----------------------------------------------- 订单子票的主票相关信息  ---------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------


DROP VIEW IF EXISTS order_addon_dim;
CACHE TABLE order_addon_dim
AS 
-- 子票订单
SELECT 
    -- addon.main_orderid  AS main_orderid, 
    -- 子票 id
    addon.orderid       AS sub_orderid,

    o.apply_did         AS main_sid,
    o.lid               AS main_lid, 
    o.tid               AS main_tid, 
    o.product_type      AS main_p_type, 
    o.pid               AS main_pid
    -- o.orderdate
FROM
(
    -- 主票的各种信息
    SELECT ordernum, lid, tid, apply_did, product_type, pid, orderdate
    FROM ods_order_d_i
    WHERE orderdate = ${ds}
) AS o
JOIN
(
    SELECT
        pack_order  AS main_orderid,
        orderid     AS orderid,
        ifpack
    FROM ods_order_addon_d_i
    WHERE 1 = 1 
    -- ifpack: 1=套票主票, 2=套票子票
      AND ifpack=2
      AND orderdate = ${ds}
) AS addon
-- 主票
ON o.ordernum = addon.main_orderid;


-----------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------

INSERT OVERWRITE TABLE dim_order_d_i_dev PARTITION(`orderdate` = ${ds})
SELECT 

    `orderid`,
    `apply_did`,
    `aid`,
    `salerid`,
    `member`,
    `lid`,
    `tid`,
    `pid`,
    `product_type`,
    `playdate`,
    `paymode`,
    `ordermode`,
    `channel_class1_id`,
    `channel_class1_name`,
    `channel_class2_id`,
    `channel_class2_name`,
    `sale_price`,
    `origin_num`,
    `pay_num`,
    `distribute_1_id`,
    `distribute_1_price`,
    `distribute_1_cost_price`,
    `ticket_taker_country`,
    `ticket_taker_province`,
    `ticket_taker_city`,
    `ticket_taker_district`,
    `ticket_taker_country_phone`,
    `ticket_taker_province_phone`,
    `ticket_taker_city_phone`,
    `ticket_taker_district_phone`,
    `ticket_taker_country_idcard`,
    `ticket_taker_province_idcard`,
    `ticket_taker_city_idcard`,
    `ticket_taker_district_idcard`,
    `ticket_taker_sex`,
    `ticket_taker_age`,
    `order_type`,
    `pack_order_main_ordernum`,

    `order_pay_status`,
    `pay_date`,
    `order_status`,

    NVL(order_addon_dim.main_sid, order.apply_did)          AS main_sid,   
    NVL(order_addon_dim.main_lid, order.lid)                AS main_lid,   
    NVL(order_addon_dim.main_tid, order.tid)                AS main_tid,   
    NVL(order_addon_dim.main_p_type, order.product_type)    AS main_product_type,
    NVL(order_addon_dim.main_pid, order.pid)                AS main_pid

FROM 
(
    SELECT *
    FROM dim_order_d_i
    WHERE orderdate = ${ds}
) AS order
LEFT JOIN order_addon_dim
ON order.orderid = order_addon_dim.sub_orderid;


