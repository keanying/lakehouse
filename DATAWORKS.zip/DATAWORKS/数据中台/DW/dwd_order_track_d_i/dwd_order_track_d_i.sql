--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-15 16:17:52
--EMR任务只能运行在独享资源组上
--********************************************************************--


CREATE TABLE IF NOT EXISTS `dwd_order_track_d_i`
(
    `ordernum`                  STRING  COMMENT '订单号ID',     
    `apply_did`                 INT     COMMENT '原始供应商ID',

    `lid`                       INT     COMMENT '景区id',
    `tid`                       INT     COMMENT '门票id',
    `pid`                       INT     COMMENT '产品id',
    `product_type`              STRING  COMMENT '商品类型',

    `paymode`                   TINYINT COMMENT '支付方式：0 = 余额支付,1 = 支付宝,2 = 授信支付,3 = 产品自销,4 = 现场支付,5 = 微信支付,6 = 会员卡支付,7 = 银联支付,8 = 环迅支付,9 = 现金支付,10 = 会员卡,11 = 拉卡拉（商户）,12 = 拉卡拉（平台）,13 = 特权支付（年卡）,14 = 微信（聚合）,15 = 平安银行,16 = 支付宝（聚合）,17 = 会员卡支付,18 = 计时卡支付,25 = 招行一网通支付,26 = 银联商务支付,27 = 银联商务POS支付,28 = 威富通支付,29 = 易宝云企付,33 = 博思支付,35 = 积分支付,36 = POS支',
    `ordermode`                 TINYINT COMMENT '下单方式:0=正常分销商下单,1=普通用户支付,2=用户手机支付,3=会员卡购票,10=云票务,11=微信商城,12=自助机,13=二级店铺,14=闸机购票,15=智能终端,16=计调下单,17=淘宝码商,18=年卡,19=微信端,20=外部接口OTA下单,22=一卡通,23=套票子票',

    `channel_class1_id`         INT     COMMENT '渠道一级分类id',
    `channel_class1_name`       STRING  COMMENT '渠道一级分类名称',
    `channel_class2_id`         INT     COMMENT '渠道二级分类id',
    `channel_class2_name`       STRING  COMMENT '渠道二级分类名称',
    
    `order_type`                STRING  COMMENT '订单类型 套票主票/套票子票/单票',
    `distribute_1_id`           INT     COMMENT '一级分销商id',
    
    `booking_ticket_num`        INT     COMMENT '预定票数',
    `booking_ticket_monery`     INT     COMMENT '预定金额',

    `pay_ticket_num`            INT     COMMENT '支付票数',
    `pay_ticket_moner`          INT     COMMENT '支付金额',

    -- 就是取消
    `cancel_ticket_num`         INT     COMMENT '退票数',
    `cancel_ticket_moner`       INT     COMMENT '退票金额',

    `verify_ticket_num`         INT     COMMENT '验证票数',
    `verify_ticket_moner`       INT     COMMENT '验证金额',

    `revoke_ticket_num`         INT     COMMENT '撤改/撤销票数',
    `revoke_ticket_moner`       INT     COMMENT '撤改/撤销金额',

    `take_ticket_num`           INT     COMMENT '取票数',
    `take_ticket_moner`         INT     COMMENT '取票金额',

    `after_sale_ticket_num`     INT     COMMENT '售后票数',
    `after_sale_ticket_moner`   INT     COMMENT '售后票金额',

    -- 新增字段
    `finish_ticket_num`         INT     COMMENT '完结票数',
    `finish_ticket_moner`       INT     COMMENT '完结金额'
)
COMMENT '订单轨迹宽表'
PARTITIONED BY (`insertdate`    INT COMMENT '动作日期')
STORED AS ORC;


SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=128MB;
SET spark.sql.adaptive.coalescePartitions.maxPartitionSize=512MB; -- 增加最大分区大小，减少分区数
SET spark.sql.adaptive.coalescePartitions.parallelism=10;


-- 倒排第一条的 
DROP VIEW IF EXISTS CACHE_LEFT;
CACHE TABLE CACHE_LEFT
AS 
SELECT ordernum, left_num
FROM (
    SELECT 
        ordernum, 
        left_num, 
        insertTime,
        ROW_NUMBER() OVER (PARTITION BY ordernum ORDER BY insertTime DESC) as rn
    FROM s_order_track_d_i
    WHERE insertdate >= CAST(DATE_FORMAT(DATE_SUB(TO_DATE(CAST(${ds} AS STRING), 'yyyyMMdd'), 732), 'yyyyMMdd') AS INT)
      AND action = 5 AND source = 32
) t
WHERE t.rn = 1;


DROP VIEW IF EXISTS CACHE_APPLY;
CACHE TABLE CACHE_APPLY
SELECT orderid, origin_num, refund_num
FROM ods_order_apply_d_i
WHERE orderdate >= CAST(DATE_FORMAT(DATE_SUB(TO_DATE(CAST(${ds} AS STRING), 'yyyyMMdd'), 732), 'yyyyMMdd') AS INT);


INSERT OVERWRITE TABLE dwd_order_track_d_i PARTITION(`insertdate` = ${ds})
SELECT 
    track.ordernum              AS `ordernum`,
    track.apply_did             AS `apply_did`,                 
    dim.lid                     AS `lid`,                       
    track.tid                   AS `tid`,                       
    dim.pid                     AS `pid`,                       
    dim.product_type            AS `product_type`,              
    dim.paymode                 AS `paymode`,                   
    dim.ordermode               AS `ordermode`,                 
    dim.channel_class1_id       AS `channel_class1_id`,         
    dim.channel_class1_name     AS `channel_class1_name`,       
    dim.channel_class2_id       AS `channel_class2_id`,         
    dim.channel_class2_name     AS `channel_class2_name`,       
    dim.order_type              AS `order_type`,                
    dim.distribute_1_id         AS `distribute_1_id`,  

    track.booking_ticket_num                    AS `booking_ticket_num`,        
    track.booking_ticket_num * dim.sale_price   AS `booking_ticket_monery`,  

    track.pay_ticket_num                        AS `pay_ticket_num`,            
    track.pay_ticket_num * dim.sale_price       AS `pay_ticket_moner`, 
                
    track.cancel_ticket_num                     AS `cancel_ticket_num`,         
    track.cancel_ticket_num * dim.sale_price    AS `cancel_ticket_moner`,  

    INT(track.verify_ticket_num)                AS `verify_ticket_num`,        
    track.verify_ticket_num * dim.sale_price    AS `verify_ticket_moner`, 
            
    track.revoke_ticket_num                     AS `revoke_ticket_num`,         
    track.revoke_ticket_num * dim.sale_price    AS `revoke_ticket_moner`,  

    track.take_ticket_num                       AS `take_ticket_num`,           
    track.take_ticket_num * dim.sale_price      AS `take_ticket_moner`, 

    track.after_sale_ticket_num                 AS `after_sale_ticket_num`,     
    track.after_sale_ticket_num * dim.sale_price    AS `after_sale_ticket_moner`, 

    IF(
        finish_ticket_num != 0, 
        finish_ticket_num, 
        IF (
            CACHE_LEFT.left_num > 0,
            NVL(CACHE_APPLY.origin_num - CACHE_APPLY.refund_num, 0),
            0
        )
    )                                           AS `finish_ticket_num`,

    IF(
        finish_ticket_num != 0, 
        finish_ticket_num, 
        IF (
            CACHE_LEFT.left_num > 0,
            NVL(CACHE_APPLY.origin_num - CACHE_APPLY.refund_num, 0),
            0
        )
    ) * dim.sale_price                           AS `finish_ticket_moner`

FROM 
(
    SELECT 
        apply_did                               AS apply_did,
        ordernum                                AS ordernum,
        tid                                     AS tid,

        IF(action IN (0, 16),   tnum, 0)        AS booking_ticket_num, 
        IF(action IN (4, 16),   tnum, 0)        AS pay_ticket_num, 
        IF(action IN (1, 2),    tnum, 0)        AS cancel_ticket_num, 
        CASE 
            WHEN (action = 5 AND get_json_object(ext_content, '$.need_write_num') > 0 )                                                       
            THEN get_json_object(ext_content, '$.need_write_num')
            WHEN 
            (
                (action = 5 AND source not in (53, 54, 32, 85)) 
                OR 
                (action = 33 AND source IN(32, 85)) 
            )    
            THEN tnum
            ELSE 0
        END                                     AS verify_ticket_num,
        IF(action IN (6, 7) ,tnum, 0)           AS revoke_ticket_num, 
        IF(action IN (3)    ,tnum, 0)           AS take_ticket_num, 
        IF(action IN (38)   ,tnum, 0)           AS after_sale_ticket_num, 

        IF(
            action IN (17),
            IF (
                tnum > 0,
                tnum,
                0
            ),
            0
        )                                       AS finish_ticket_num, 

        tnum                                    AS tnum
    FROM s_order_track_d_i 
    WHERE insertdate = ${ds} 
      AND tnum > 0
) AS track 
LEFT JOIN 
(
    SELECT 
        `orderid`,
        `aid`,
        `salerid`,
        `member`,
        `lid`,
        `pid`,
        `product_type`,
        `playdate`,
        NVL(`paymode`, -1)  AS `paymode`,
        `ordermode`,
        `channel_class1_id`,
        `channel_class1_name`,
        `channel_class2_id`,
        `channel_class2_name`,
        `sale_price`,
        `distribute_1_id`,
        `order_type`
    FROM dim_order_d_i
    WHERE orderdate >= CAST(DATE_FORMAT(DATE_SUB(TO_DATE(CAST(${ds} AS STRING), 'yyyyMMdd'), 732), 'yyyyMMdd') AS INT)
) AS dim 
ON track.ordernum = dim.orderid
LEFT JOIN CACHE_APPLY
ON track.ordernum = CACHE_APPLY.orderid
LEFT JOIN CACHE_LEFT
ON track.ordernum = CACHE_LEFT.ordernum;

