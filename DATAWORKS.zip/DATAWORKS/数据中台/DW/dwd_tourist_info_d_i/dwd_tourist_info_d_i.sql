--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-15 10:01:45
--EMR任务只能运行在独享资源组上
--********************************************************************--

-- desc 预定游客信息表

CREATE TABLE IF NOT EXISTS `dwd_tourist_info_d_i`
(
    -- 重要 id
    `apply_did`             INT     COMMENT '原始供应商ID', 
    `orderid`               STRING  COMMENT '订单号ID', 
    `lid`                   INT     COMMENT '景点ID', 
    `tid`                   INT     COMMENT '门票id',
    `pid`                   INT     COMMENT '产品id',
    `product_type`          STRING  COMMENT '商品类型',

    `order_type`            STRING  COMMENT '票类型：套票主票/单票/套票子票',

    -- 新增字段
    `paymode`               TINYINT COMMENT '支付方式：0 = 余额支付,1 = 支付宝,2 = 授信支付,3 = 产品自销,4 = 现场支付,5 = 微信支付,6 = 会员卡支付,7 = 银联支付,8 = 环迅支付,9 = 现金支付,10 = 会员卡,11 = 拉卡拉（商户）,12 = 拉卡拉（平台）,13 = 特权支付（年卡）,14 = 微信（聚合）,15 = 平安银行,16 = 支付宝（聚合）,17 = 会员卡支付,18 = 计时卡支付,25 = 招行一网通支付,26 = 银联商务支付,27 = 银联商务POS支付,28 = 威富通支付,29 = 易宝云企付,33 = 博思支付,35 = 积分支付,36 = POS支',
    `ordermode`             TINYINT COMMENT '下单方式:0=正常分销商下单,1=普通用户支付,2=用户手机支付,3=会员卡购票,10=云票务,11=微信商城,12=自助机,13=二级店铺,14=闸机购票,15=智能终端,16=计调下单,17=淘宝码商,18=年卡,19=微信端,20=外部接口OTA下单,22=一卡通,23=套票子票',
    `distribute_1_id`       INT     COMMENT '一级分销商id',

    -- 游客画像使用
    `age`                   STRING  COMMENT '年龄-来自身份证', 
    `sex`                   STRING  COMMENT '性别-来自身份证', 

    -- 新增字段
    `country_name`          STRING  COMMENT '国家-优先使用字段',
    `province_name`         STRING  COMMENT '省-优先使用字段', 
    `city_name`             STRING  COMMENT '市-优先使用字段', 
    `district_name`         STRING  COMMENT '区县-优先使用字段',

    `phone_country_name`    STRING  COMMENT '国家-手机号归属地', 
    `phone_province_name`   STRING  COMMENT '省-手机号归属地', 
    `phone_city_name`       STRING  COMMENT '市-手机号归属地', 
    `phone_district_name`   STRING  COMMENT '区县-手机号归属地', 

    `idcard_country_name`   STRING  COMMENT '国家-证件归属地', 
    `idcard_province_name`  STRING  COMMENT '省-证件归属地', 
    `idcard_city_name`      STRING  COMMENT '市-证件归属地', 
    `idcard_district_name`  STRING  COMMENT '区县-证件归属地', 

    `multiple`              INT     COMMENT '放大倍数(一码多核，本条记录代表预定游客数)',
    `sale_price`            INT     COMMENT '实际售价,单张票',

    -- 游客原始数据
    `idx`                   BIGINT  COMMENT '订单序号', 
    `idcard`                STRING  COMMENT '游客身份信息', 
    `voucher_type`          TINYINT COMMENT '身份信息类型:0=未知,1=身份证,2=护照,3=军官证,4=回乡证,5=台胞证,6=外国人永久居留证,7=港澳通行证,8=台湾通行证,9=港澳居民居住证,10=台湾居民居住证,99=其他', 
    `order_time`            INT     COMMENT '逻辑下单时间', 
    `mobile`                STRING  COMMENT '游客手机号', 


    -- 渠道信息
    `channel_class1_id`     INT     COMMENT '渠道一级分类id',
    `channel_class1_name`   STRING  COMMENT '渠道一级分类名称',
    `channel_class2_id`     INT     COMMENT '渠道二级分类id',
    `channel_class2_name`   STRING  COMMENT '渠道二级分类名称',

    -- 其他字段
    `id`                    BIGINT  COMMENT '自增ID', 
    `tourist`               STRING  COMMENT '游客姓名', 
    `update_time`           INT     COMMENT '订单更新时间', 
    `order_month`           TINYINT COMMENT '逻辑下单月份', 
    `check_state`           TINYINT COMMENT '0未验证1已验证2已取消', 
    `print_state`           TINYINT COMMENT '打印状态0未打印1已打印', 
    `check_time`            INT     COMMENT '验证时间', 
    `chk_code`              STRING  COMMENT '升级过的凭证号', 
    `member_id`             BIGINT  COMMENT '游客ID', 
    `is_checked`            TINYINT COMMENT '这个门票码是否全部验证', 
    `sync_state`            TINYINT COMMENT '是否同步标示 1:同步,0:无需同步',

    -- 主子单相关信息
    `main_sid`                  STRING  COMMENT '套票子票(主票的 sid)，套票主票/单票（原订单的 sid）',
    `main_lid`                  STRING  COMMENT '套票子票(主票的 lid)，套票主票/单票（原订单的 lid）',
    `main_tid`                  STRING  COMMENT '套票子票(主票的 tid)，套票主票/单票（原订单的 tid）',
    `main_product_type`         STRING  COMMENT '套票子票(主票的 p_type)，套票主票/单票（原订单的 p_type）',
    `main_pid`                  STRING  COMMENT '套票子票(主票的 pid)，套票主票/单票（原订单的 pid）'

)
COMMENT '游客身份证等信息表,按天分区'
PARTITIONED BY 
(
    `orderdate`             INT     COMMENT '下单日期'
)
STORED AS ORC;

SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=128MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;

INSERT OVERWRITE TABLE dwd_tourist_info_d_i PARTITION(orderdate = ${ds})
SELECT 
    -- 重要 id
    info.`apply_did`                AS `apply_did`,
    info.`orderid`                  AS `orderid`, 
    info.`lid`                      AS `lid`, 
    NVL(order.`tid`, -1)            AS `tid`,
    NVL(order.`pid`, -1)            AS `pid`,
    NVL(order.`product_type`, -1)   AS `product_type`,

    order.`order_type`              AS `order_type`,
    order.`paymode`                 AS `paymode`,
    order.`ordermode`               AS `ordermode`,
    order.`distribute_1_id`         AS `distribute_1_id`,

    -- 游客画像使用
    info.`age`                      AS `age`, 
    info.`sex`                      AS `sex`,

    info.`country_name`             AS `country_name`,
    info.`province_name`            AS `province_name`,
    info.`city_name`                AS `city_name`,
    info.`district_name`            AS `district_name`,

    info.`phone_country_name`       AS `phone_country_name`, 
    info.`phone_province_name`      AS `phone_province_name`,
    info.`phone_city_name`          AS `phone_city_name`,    
    info.`phone_district_name`      AS `phone_district_name`,    

    info.`idcard_country_name`      AS `idcard_country_name`,
    info.`idcard_province_name`     AS `idcard_province_name`,
    info.`idcard_city_name`         AS `idcard_city_name`,
    info.`idcard_district_name`     AS `idcard_district_name`,

    info.`multiple`                 AS `multiple`,
    order.`sale_price`              AS `sale_price`,

    -- 游客原始数据
    info.`idx`                      AS `idx`,                 
    info.`idcard`                   AS `idcard`,              
    info.`voucher_type`             AS `voucher_type`,        
    info.`order_time`               AS `order_time`,          
    info.`mobile`                   AS `mobile`,              

    -- 渠道信息
    NVL(order.`channel_class1_id`, 4)           AS `channel_class1_id`,
    NVL(order.`channel_class1_name`, '其他')     AS `channel_class1_name`,
    NVL(order.`channel_class2_id`, -1)          AS `channel_class2_id`,
    NVL(order.`channel_class2_name`, -1)        AS `channel_class2_name`,

    -- 其他字段
    info.`id`                   AS `id`,           
    info.`tourist`              AS `tourist`,      
    info.`update_time`          AS `update_time`,   
    info.`order_month`          AS `order_month`,   
    info.`check_state`          AS `check_state`,   
    info.`print_state`          AS `print_state`,   
    info.`check_time`           AS `check_time`,    
    info.`chk_code`             AS `chk_code`,     
    info.`member_id`            AS `member_id`,     
    info.`is_checked`           AS `is_checked`,    
    info.`sync_state`           AS `sync_state`,

    order.`main_sid`            AS `main_sid`,
    order.`main_lid`            AS `main_lid`,
    order.`main_tid`            AS `main_tid`,
    order.`main_product_type`   AS `main_product_type`,
    order.`main_pid`            AS `main_pid`
    
FROM 
(
    SELECT *
    FROM ods_tourist_info_d_i
    WHERE orderdate = ${ds}  
) AS info 
LEFT JOIN 
(
    SELECT 
        `orderid`,
        `tid`,         
        `pid`,         
        `product_type`,
        `channel_class1_id`,  
        `channel_class1_name`,
        `channel_class2_id`,  
        `channel_class2_name`,
        `sale_price`,
        `order_type`,
        
        `paymode`,
        `ordermode`,
        `distribute_1_id`,

        `main_sid`,
        `main_lid`,
        `main_tid`,
        `main_product_type`,
        `main_pid`
        
    FROM dim_order_d_i
    WHERE orderdate >= CAST(DATE_FORMAT(DATE_SUB(TO_DATE(CAST(${ds} AS STRING), 'yyyyMMdd'), 2), 'yyyyMMdd') AS INT) 
    AND orderdate <= ${ds}
) AS order 
ON info.orderid = order.orderid

