-- name dim_sid_white_list_d_f
-- type Spark SQL
-- author wanghaiyang@12301.cc
-- create time 2024-12-26 14:29:38
-- desc 供应商白名单(指标层只保留白名单用户的数据)


CREATE TABLE IF NOT EXISTS `dim_sid_white_list_d_f`(
    `sid` bigint COMMENT'供应商ID'
)comment'白名单商户维表'
partitioned by(
    pt int
)stored as orc 
;


INSERT OVERWRITE TABLE dim_sid_white_list_d_f PARTITION(`pt`=${ds})
SELECT sid FROM(
    SELECT distinct apply_did  AS  sid
    FROM ods_ticket_d_f
    WHERE pt = DATE_FORMAT(DATE_SUB(CURRENT_DATE(), 1),"yyyyMMdd")
    and status !=6
    -- 移除资源中心通过接口上架产品的特殊账号:携程旅行/携程美食林/驴妈妈旅游/同程旅行
    and apply_did NOT IN(
        4871146,
        13992569,
        5961260,
        8667237
    )
    and apply_did NOT IN(
        SELECT member_id
        FROM dim_distribute_ota_o_f
        -- 通过回调地址确认
        WHERE rule_code = 2
    )
) applyTab
-- 移除测试组账号,但保留3385和6970
JOIN (
	SELECT user_id
	FROM ods_pft_member_d_f
	WHERE pt = DATE_FORMAT(DATE_SUB(CURRENT_DATE(), 1),"yyyyMMdd")
		AND (group_id != 2 or user_id = 3385 or user_id = 6970) 
) userTab
ON applyTab.sid = userTab.user_id
; 