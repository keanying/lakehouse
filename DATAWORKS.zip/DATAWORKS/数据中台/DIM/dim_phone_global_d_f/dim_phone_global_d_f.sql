--@exclude_input=6249803122802140640
--@exclude_input=8012330450963703278
--@exclude_output=default_workspace_svwh.dim_phone_global_d_f
--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-07-07 10:48:31
--EMR任务只能运行在独享资源组上
--********************************************************************--


CREATE TABLE IF NOT EXISTS dim_phone_global_d_f(
    `phone_area_code`   STRING  COMMENT '手机区号: 中国86',
    `name_zh`           STRING  COMMENT '中文名称',
    `name_en`           STRING  COMMENT '英文名称',
    `full_name_zh`      STRING  COMMENT '中文全称', 
    `full_name_en`      STRING  COMMENT '英文全称', 
    `is_country`        INT     COMMENT '是否为独立国家： 0.否 1.是',
    `alpha_2_code`      STRING  COMMENT 'ISO 3166-1标准中的二位字母代码: 美国.US 中国.CN 香港.HK 台湾.TW', 
    `alpha_3_code`      STRING  COMMENT 'ISO 3166-1标准中的三位字母代码',
    `numeric_3_code`    STRING  COMMENT 'ISO 3166-1标准中的三位数字代码'
) COMMENT'手机号归属城市表'
PARTITIONED BY(
    pt STRING
)STORED AS ORC;


INSERT OVERWRITE TABLE dim_phone_global_d_f PARTITION(pt='${ds}')
SELECT 
    gt.phone_area_code,
    ct.name_zh, 
    ct.name_en, 
    ct.full_name_zh, 
    ct.full_name_en,
    ct.is_country, 
    ct.alpha_2_code, 
    ct.alpha_3_code, 
    ct.numeric_3_code
FROM 
(
    SELECT country_id, phone_area_code
    FROM ods_global_phone_area_d_f
    WHERE pt='${ds}'
) AS gt 
LEFT JOIN 
(
    SELECT 
        `id`, `name_zh`, `name_en`, `full_name_zh`, `full_name_en`,
        `is_country`, `alpha_2_code`, `alpha_3_code`, `numeric_3_code`
    FROM ods_country_region_d_f
    WHERE pt='${ds}'
) AS ct 
ON gt.country_id = ct.id

