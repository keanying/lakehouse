CREATE TABLE IF NOT EXISTS dim_phone_city_fixed_d_f(
    stat_date       STRING  COMMENT '统计日期',
    dw_ins_time     STRING  COMMENT '插入时间',

    phone_city_id   INT     COMMENT 'ID',
    phone_number    INT     COMMENT '手机号前7位',
    area_code       STRING  COMMENT '区域编码：省编码|市编码|区县编码',
    zip_code        STRING  COMMENT '邮编',
    province_name   STRING  COMMENT '省名称',
    city_name       STRING  COMMENT '市名称',
    district_name   STRING  COMMENT '区县名称',
    country_name    STRING  COMMENT '国家名称',

    lng             STRING  COMMENT '经度',
    lat             STRING  COMMENT '纬度'
) COMMENT '手机号归属城市表'
PARTITIONED BY(
    pt INT 
) STORED AS ORC;

-- REFRESH TABLE s_city_phone_fixed_d_f;

INSERT OVERWRITE TABLE dim_phone_city_fixed_d_f PARTITION(pt='${ds}')
SELECT  
    DISTINCT
    '${ds}'         AS stat_date,
    CURRENT_DATE    AS dw_ins_time,
    city_code       AS phone_city_id,
    number          AS phone_number,
    area_code       AS area_code,
    zip_code        AS zip_code,
    province_name   AS province_name,
    city_name       AS city_name,
    ''              AS district_name,
    country_name    AS country_name,
    lng             AS lng,
    lat             AS lat
FROM s_city_phone_fixed_d_f
WHERE pt = '${ds}';

