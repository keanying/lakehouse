--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-01 15:06:29
--EMR任务只能运行在独享资源组上
--********************************************************************--


create table if not EXISTS ods_pft_login_log_d_f(
    id                      INT COMMENT "id",
    user_id                 INT COMMENT "登录用户ID",
    login_ip                bigINT COMMENT "登录ip",
    login_source            INT COMMENT "登录来源  1=平台，2=终端设备，3=微信端，4=手机验证码登录",

    login_location          string COMMENT "登录地",
    login_browser           string COMMENT "登录浏览器",
    login_os                string COMMENT "登录设备",
    login_time              STRING COMMENT "登录时间"
    
)COMMENT "登录日志" PARTITIONED by(
    pt string
)STORED AS ORC;


INSERT into ods_pft_login_log_d_f PARTITION (pt="pt")
select 
    id                                                as id,
    mid                                               as user_id,
    login_ip                                          as login_ip,
    login_source                                      as login_source,
    
    login_location                                    as login_location,
    login_browser                                     as login_browser,
    login_os                                          as login_os,
    from_unixtime(login_time)                         as login_time
FROM  ods_pft_logging_pft_login_log_d_i 
where pt="${ds}" 