--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-05 15:01:20
--EMR任务只能运行在独享资源组上
--********************************************************************--
-- desc 报团预定订单

CREATE TABLE IF NOT EXISTS ods_team_order_d_f(
    stat_date               STRING  COMMENT '统计日期',
    dw_ins_time             STRING  COMMENT '插入时间',

    team_order_id           STRING  COMMENT '团队订单号',
    son_order_id            string  COMMENT '订单号',
    ticker_tacker_name      STRING  COMMENT '联系人',
    ticker_tacker_mobile    STRING  COMMENT '联系人手机',

    status                  STRING  COMMENT '订单状态',
    pay_status              STRING  COMMENT '支付状态',
    supplier_id             INT     COMMENT '供应商ID',
    dist_id                 INT     COMMENT '分销商id',
    land_id                 INT     COMMENT '景区id',
    ticket_id               INT     COMMENT '票id',
    booking_time            STRING  COMMENT '预订时间',
    team_num                INT     COMMENT '团队人数',

    tourist_province        STRING  COMMENT '游客省份',
    tourist_city            STRING  COMMENT '游客城市',
    tourist_country         STRING  COMMENT '游客县城',
    order_type              STRING  COMMENT '下单类型'
) COMMENT '团队订单表' 
PARTITIONED  BY (
    pt INT   
) STORED AS ORC;

INSERT OVERWRITE TABLE ods_team_order_d_f PARTITION (pt=${ds})
SELECT 
    '${ds}'         AS stat_date,
    CURRENT_DATE()                  AS dw_ins_time,

    usot.ordernum                   AS team_order_id,
    usotl.son_ordernum              AS son_order_id,
    usot.ordername                  AS ticker_tacker_name,
	usot.contacttel                 AS ticker_tacker_mobile,

    CASE usot.status
        WHEN 0 THEN '未确认'
        WHEN 1 THEN '已确认'
        WHEN 2 THEN '已验证'
        WHEN 3 THEN '已取消'
        ELSE NULL                                          
    END                             AS status,
    CASE usot.pay_status                                       
        WHEN 0 THEN '未支付'
        WHEN 1 THEN '已支付'
        WHEN 2 THEN '部分支付'     
        ELSE NULL                                         
    END                             AS pay_status,	
    usot.aid                        AS supplier_id,
    usot.fid                        AS dist_id,
	usotl.lid                       AS land_id,
	usotl.tid                       AS ticket_id,
	usot.playtime                   AS booking_time,
	usot.tnum                       AS team_num,

	ct.province_name                AS tourist_province,
	ct.city_name                    AS tourist_city,
	''                              AS tourist_country,
    CASE usot.ordertype
        WHEN 1 THEN '云票务'
        WHEN 2 THEN '微平台' 
        WHEN 3 THEN '分销商报团预定'
        WHEN 4 THEN '报团计调'
        ELSE NULL                                         
    END                             AS order_type
FROM 
(
    SELECT * 
    FROM ods_uu_ss_order_team_d_f 
    WHERE pt="${ds}"
)  AS usot
LEFT JOIN 
(
    SELECT main_ordernum, son_ordernum, lid, tid 
    FROM ods_uu_ss_order_team_link_d_f 
    WHERE pt="${ds}"
) AS usotl 
ON usot.ordernum = usotl.main_ordernum 
LEFT JOIN  
(
    SELECT province_name, city_name, city_code, province_code  
    FROM dim_city_d_f 
    WHERE pt="${ds}"
) AS ct  
ON CAST(usot.city AS INT) = CAST(ct.city_code AS INT) 
AND CAST(usot.province AS INT)=CAST(ct.province_code AS INT)
WHERE ISNOTNULL(usotl.son_ordernum);
