--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-05 14:55:41
--EMR任务只能运行在独享资源组上
--********************************************************************--

-- desc 第三方订单


CREATE TABLE IF NOT EXISTS ods_third_purchase_order_d_f(
    stat_date               STRING  COMMENT'统计日期',
    dw_ins_time             STRING  COMMENT'插入时间',
    third_name              STRING  COMMENT'第三方线下票务系统名称',
    third_ver_name          STRING  COMMENT'第三方线下票务系统版本名称',
    third_coopB             INT     COMMENT'第三方线下票务系统编码',
    order_id                STRING  COMMENT'订单号',
    booking_time            STRING  COMMENT'预定时间'
)PARTITIONED BY(
    pt                      INT
 )STORED AS ORC;


INSERT  OVERWRITE    TABLE   ods_third_purchase_order_d_f PARTITION (pt=${ds}) 
SELECT  /*+mapjoin(cs)*/
        ${ds}                               AS stat_date,
        CURRENT_DATE                                        AS dw_ins_time,
        IF(ISNULL(t.system_name),cs.name,t.system_name)     AS third_name,
        cs.name                                             AS third_ver_name,
        o.coopB                                             AS third_coopB,
        o.pftOrder                                          AS order_id,
        o.cTime                                             AS booking_time
FROM (
    SELECT  coopB,
            pftOrder,
            cTime 
    FROM    ods_all_api_order_d_f
    ) AS O
-- coopB对应系统版本名称
LEFT JOIN (
    SELECT  name,
            coopB 
    FROM    ods_pft_con_sys_d_f 
    WHERE   pt="${ds}"
    ) AS cs 
ON cs.coopB = o.coopB
-- coopB对应系统名称，表仅列出有不同版本的系统
LEFT JOIN (
    SELECT  * 
    FROM    ods_third_purchase_system_d_f 
    WHERE   pt="${ds}"
        ) AS t 
ON t.coopB = o.coopB