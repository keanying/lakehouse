--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-04 15:56:02
--EMR任务只能运行在独享资源组上
--********************************************************************--
SET hive.exec.dynamic.partition.mode= nonstrict;


CREATE TABLE IF NOT EXISTS ods_order_fx_details_d_i(
    id                      INT     COMMENT "id",
    orderid                 STRING  COMMENT "订单id",
    series                  STRING  COMMENT '演出类座位等信息或是团号',
    assembly                INT     COMMENT '0不用处理|其他数字到线路表取相应的值',
    memo                    STRING  COMMENT '备注',
    origin                  STRING  COMMENT '客源地',
    concat_id               STRING  COMMENT '关联的订单号',
    pay_status              INT     COMMENT '支付状态:0=现场支付,1=已支付,2=未支付(弃用)',
    aids_money              STRING  COMMENT '供应商进化线付款详情',
    aids                    STRING  COMMENT '转分销各级分销链',
    aids_price              STRING  COMMENT '转分销各级分销链购买价格',
    ext_content             STRING  COMMENT '扩展属性',
    product_ext             STRING  COMMENT '产品扩展json数据，演出、线路等产品的一些定制数据 - {"show":{},"line":{}}',
    partner_ext             STRING  COMMENT '合作方的一些数据，三方系统订单号，凭证码等数据',
    offline_ext             STRING  COMMENT '线下售票系统的一些数据，线下自填的流水号等一些数据',
    notice_ext              STRING  COMMENT '通知类数据，是否需要回调，通知邮件，remsg短信通知次数等',
    order_time              INT     COMMENT '逻辑下单时间',
    order_month             INT     COMMENT '逻辑下单月份',
    update_time             INT     COMMENT '订单更新时间',
    apply_did               INT     COMMENT '原始供应商ID',
    sync_state              INT     COMMENT '是否同步标示 1:同步,0:无需同步'
)COMMENT "订单分销明细" PARTITIONED BY (
     `orderdate`            INT     COMMENT '下单日期'
) STORED AS ORC;


INSERT OVERWRITE TABLE ods_order_fx_details_d_i PARTITION(orderdate)
SELECT 
    `id`,
    `orderid`,
    `series`,
    `assembly`,
    `memo`,
    `origin`,
    `concat_id`,
    `pay_status`,
    `aids_money`,
    `aids`,
    `aids_price`,
    `ext_content`,
    `product_ext`,
    `partner_ext`,
    `offline_ext`,
    `notice_ext`,
    `order_time`,
    `order_month`,
    `update_time`,
    `apply_did`,
    `sync_state`,
    INT(FROM_UNIXTIME(order_time, 'yyyyMMdd')) AS orderdate
FROM s_order_fx_details_15d_i
WHERE pt = ${ds};

