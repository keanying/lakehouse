--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-13 11:24:13
--EMR任务只能运行在独享资源组上
--********************************************************************--



CREATE TABLE IF NOT EXISTS ods_pft_order_track_d_f(
    stat_date               STRING  COMMENT '统计日期, bdp.system.bizdate',
    dw_ins_time             STRING  COMMENT '数据插入日期, CURRENT_DATE',

    -- action_id               INT     COMMENT '操作id',
    action_time             STRING  COMMENT '操作时间',
    action                  INT     COMMENT '操作码',
    order_id                STRING  COMMENT '订单id',
    ticket_id               INT     COMMENT '票id',


    booking_ticket_num      INT     COMMENT '预定票数',
    pay_ticket_num          INT     COMMENT '支付票数',
    cancel_ticket_num       INT     COMMENT '退票数',
    vertify_ticket_num      INT     COMMENT '验证票数',
    revoke_ticket_num       INT     COMMENT '撤改/撤销票数',
    take_ticket_num         INT     COMMENT '取票数',
    after_sale_ticket_num   INT     COMMENT '售后票数',

    tnum                    INT     COMMENT '操作票数',

    terminal                INT     COMMENT '操作主终端id',
    branchTerminal          INT     COMMENT '操作分终端id',
    id_card                 STRING  COMMENT '验证身份证',
    oper_member             INT     COMMENT '操作员id',
    remark                  INT     COMMENT '备注',
    apply_did               INT     COMMENT '原始供应商id',
    pt                      STRING  COMMENT '兼容历史任务使用字段, 恒定为pt'
)COMMENT '订单操作日志' PARTITIONED by(
    action_date             STRING  COMMENT '操作日期'
) STORED AS ORC;



INSERT OVERWRITE TABLE ods_pft_order_track_d_f PARTITION (action_date='${ds}')
SELECT 
    ${ds}                                   AS stat_date,
    CURRENT_DATE                                            AS dw_ins_time,
    -- pft_order.id                                            AS action_id,
    pft_order.insertTime                                    AS action_time,
    pft_order.action                                        AS action,
    pft_order.ordernum                                      AS order_id,
    pft_order.tid                                           AS ticket_id,

    IF(pft_order.action IN (0,16),pft_order.tnum, 0)        AS booking_ticket_num, 
    IF(pft_order.action IN (4,16),pft_order.tnum, 0)        AS pay_ticket_num, 
    IF(pft_order.action IN (1,2) ,pft_order.tnum, 0)        AS cancel_ticket_num, 
    INT(
        CASE 
            WHEN (pft_order.action = 5 AND pft_order.ext_content_need_write_num > 0 )                                                       
            THEN pft_order.ext_content_need_write_num
            WHEN (
                (pft_order.action = 5 AND pft_order.source not in (53, 54, 32, 85)) 
                OR 
                (pft_order.action = 33 AND pft_order.source IN(32, 85)) 
                )    
            THEN pft_order.tnum
            ELSE 0
        END
    )                                                       AS vertify_ticket_num,
    IF(pft_order.action IN (6,7) ,pft_order.tnum, 0)        AS revoke_ticket_num, 
    IF(pft_order.action IN (3)   ,pft_order.tnum, 0)        AS take_ticket_num, 
    IF(pft_order.action IN (38)   ,pft_order.tnum, 0)       AS after_sale_ticket_num, 


    pft_order.tnum                                          AS tnum,
    pft_order.terminal                                      AS terminal,
    pft_order.branchTerminal                                AS branchTerminal,
    IF(
        LENGTH(id_card)=18,
        CONCAT(SUBSTR(id_card,1,10), REPEAT('*',6), SUBSTR(id_card,17,2)),
        NULL
        )                                                   AS id_card,
    pft_order.oper_member                                   AS oper_member,
    int(pft_order.msg)                                      AS remark,
    pft_order.apply_did                                     AS apply_did,
    'pt'                                                    AS pt
FROM ( 
        SELECT  id                    ,
                ordernum              ,
                action                ,
                tid                   ,
                tnum                  ,
                left_num              ,
                source                ,
                terminal              ,
                branchTerminal        ,
                SalerID               ,
                id_card               ,
                insertTime            ,
                oper_member           ,
                msg                   ,
                ext_content           ,
                order_time            ,
                update_time           ,
                order_month           ,
                apply_did             ,
                sync_state            ,
                get_json_object(ext_content, '$.need_write_num')    AS ext_content_need_write_num
        FROM    s_order_track_d_i 
        WHERE   insertdate = '${ds}' 
        AND     tnum > 0
    ) AS pft_order

