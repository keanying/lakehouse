--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-04 14:52:03
--EMR任务只能运行在独享资源组上
--********************************************************************--


-- create time 2019-08-20 18:06:13
-- desc 2020.1.1 日后第三方订单track
-- drop table if EXISTS ods_api_order_track_d_f;

create table if not EXISTS ods_api_order_track_d_f(
    stat_date                 STRING COMMENT"统计日期",
    dw_ins_time               STRING COMMENT"数据插入日期",

    pftOrder                  string COMMENT '票付通订单id',
    fail_reason               string COMMENT '失败原因',
    fail_code                 string COMMENT '请求代码'
    
)COMMENT '第三方订单操作日志' PARTITIONED by(
    pt int
) STORED AS ORC;


INSERT OVERWRITE TABLE ods_api_order_track_d_f PARTITION (pt=${ds})
select 
    '${ds}'                                 as stat_date,
    current_date                                            as dw_ins_time,
    
    pftOrder,
    max(case 
       when response like '%ErrorCode%' then substr(response,locate('CustomerErrorMessage',response)+23,locate('"ErrorMessage":',response)-2-locate('CustomerErrorMessage',response)-23)
       when response like '%ErrCode%'   then substr(response,locate('ErrMsg',response)+9,length(response)-2-locate('ErrMsg',response)-9)
       when response like '%<code>%'    then substr(response,locate('<message>',response)+9,locate('</message>',response,1)-locate('<message>',response)-9)
    end)                as fail_reason,
    max(case 
       when response like '%ErrorCode%' then substr(response,locate('ErrorCode',response)+12,locate('CustomerErrorMessage',response)-3-locate('ErrorCode',response)-12)
       when response like '%ErrCode%'   then substr(response,locate('ErrCode',response)+9,locate('ErrMsg',response)-2-locate('ErrCode',response)-9)
       when response like '%<code>%'    then substr(response,locate('<code>',response)+6,locate('</code>',response,1)-locate('<code>',response)-6)
    end)                as fail_code
 from s_api_order_track_d_i
 where pt=${ds}
       and response is not null and trim(response)<>'' and pftOrder<>'0'
       and (response like '%ErrorCode%' or response like '%ErrCode%' or response like '%<code>%')
       and not(response like '%success%' or response like '%成功%' or response like '%"ErrorCode":null%')
 group by pftOrder

;