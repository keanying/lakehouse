--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-01 14:21:13
--EMR任务只能运行在独享资源组上
--********************************************************************--

CREATE TABLE IF NOT EXISTS ods_uu_order_terminal_change_d_f(
    id                      INT COMMENT "id",
    ordernum                STRING COMMENT "订单号",
    dstatus                 INT  COMMENT "状态:0=未审核,1=同意,2=拒绝,3=等待第三方平台审核通过"
    -- client_num              STRING COMMENT "终端号",
    -- saler_id                STRING COMMENT "商户号",
    -- land_id                 INT COMMENT "商户ID",
    -- ticket_id               INT COMMENT "票ID",
    -- change_type             int COMMENT "变更类型:0=撤改,1=撤销,2=修改,3=取消,4=改签",
    -- change_ticket_num       INT COMMENT "票数变更到几张，取消的话为0",
    -- status                  INT COMMENT "状态:0=未审核,1=同意,2=拒绝,3=等待第三方平台审核通过",
    -- reason                  STRING COMMENT "原因",
    -- oper                    STRING COMMENT "操作人员",
    -- add_time                STRING COMMENT "添加时间",
    -- hdl_time                STRING COMMENT "处理时间",
    -- appli_sponsor           STRING COMMENT "申请发起人",
    -- platform_seq            STRING COMMENT "平台流水号",
    -- third_party_seq         STRING COMMENT "第三方流水号",
    -- modify_ticket_num       STRING COMMENT "本次修改票数",
    -- transfer_chain          STRING COMMENT "转分销各级分销链",
    -- land_name               string COMMENT "景区名",
    -- ticket_name             STRING COMMENT "票名",
    -- coupon_main_order_id    STRING COMMENT "联票主订单id",
    -- no_package_order_id     STRING COMMENT "非套票订单",
    -- supplier_order_id       STRING COMMENT "供应商ID",
    -- docking_type            STRING COMMENT "对接类型",
    -- callback_url            STRING COMMENT "回调地址",
    -- package_main_order_id   STRING COMMENT "套票主订单号",
    -- system_auto_check       STRING COMMENT "系统自动处理"
)COMMENT "终端订单变动记录表"  PARTITIONED  BY (
    pt INT   
)STORED AS ORC;


-- CACHE TABLE temp_table
-- AS 
-- SELECT id, ordernum, dstatus
-- FROM s_myuu_uu_order_terminal_change_d_i
-- WHERE pt='${bdp.system.bizdate}'
-- UNION ALL
-- SELECT id, ordernum, dstatus
-- FROM ods_uu_order_terminal_change_d_f
-- WHERE pt='${bdp.system.bizdate}'-1;


-- INSERT OVERWRITE TABLE ods_uu_order_terminal_change_d_f PARTITION(pt='${bdp.system.bizdate}')
-- SELECT id, ordernum, dstatus 
-- FROM temp_table
-- INNER JOIN (
-- 	SELECT max(id) AS max_id 
-- 	FROM temp_table
-- 	GROUP BY ordernum
-- ) AS max_id_table
-- ON temp_table.id = max_id_table.max_id


INSERT OVERWRITE TABLE ods_uu_order_terminal_change_d_f PARTITION(pt=${ds})
SELECT id, ordernum, dstatus
FROM (
    SELECT id, ordernum, dstatus, ROW_NUMBER() OVER(PARTITION BY ordernum ORDER BY id DESC) AS version_num
    FROM (
        SELECT id, ordernum, dstatus
        FROM ods_myuu_uu_order_terminal_change_d_i
        WHERE pt=${ds}
        -- UNION ALL
        -- SELECT id, ordernum, dstatus
        -- FROM ods_uu_order_terminal_change_d_f
        -- WHERE pt='${ds}'-1
    )
) AS temp_table
WHERE temp_table.version_num = 1;

-- -- 前天全量 过滤昨天增量
-- SELECT
--     id      ,
--     ordernum,
--     dstatus 
-- FROM data_middle_bi.ods_uu_order_terminal_change_d_f 
-- WHERE pt="${last_yesterday}" 
--   AND id NOT IN (
--       SELECT id 
--       FROM data_middle_bi.s_myuu_uu_order_terminal_change_7d_i 
--       WHERE pt="${bdp.system.bizdate}"
--   )
-- --昨天增量
-- UNION ALL
-- SELECT
--     id      ,
--     ordernum,
--     dstatus 
-- FROM data_middle_bi.s_myuu_uu_order_terminal_change_7d_i 
-- WHERE pt="${bdp.system.bizdate}";


-- select 
--     id      ,
--     ordernum,
--     dstatus 

-- from data_middle_bi.s_myuu_uu_order_terminal_change_d_f 
-- where pt="${bdp.system.bizdate}"

-- UNION ALL 

-- select 
--     id      ,
--     ordernum,
--     dstatus 

-- from data_middle_bi.s_order_202001_uu_order_terminal_change_d_f 
-- ;
