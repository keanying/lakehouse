--@exclude_output=default_workspace_svwh.ods_pft_member_d_f
--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-07-25 11:23:09
--EMR任务只能运行在独享资源组上
--********************************************************************--


CREATE TABLE IF NOT EXISTS ods_pft_member_d_f(
    user_id                     INT    COMMENT "用户id",    
    user_account_id             INT    COMMENT "账户id", 
    user_customer_id            INT    COMMENT "客户ID",
    user_name                   STRING COMMENT "用户名称/账户名称", 

    user_type_code              INT    COMMENT "用户类型编码",
    user_type                   STRING COMMENT "用户类型",
    user_account                STRING COMMENT "账号", 
    user_status                 STRING COMMENT "用户状态", 

    user_regist_time            STRING COMMENT"用户注册时间",
    user_contarct_firstdate     STRING COMMENT"用户首次合日期",
    user_login_lasttime         STRING COMMENT"用户上次登录时间",

    user_bank_card_1            STRING COMMENT "用户银行卡号1", 
    user_bank_card_2            STRING COMMENT "用户银行卡号2",
    user_alipay                 STRING COMMENT "用户支付宝账号",

    customer_id                 INT    COMMENT"客户id",
    customer_mobile             STRING COMMENT"客户手机号",

    --商户有关信息
    user_is_OTA                 STRING  COMMENT"是否对接第三方分销平台",
    distribute_system_type      STRING  COMMENT"对接分销平台类型",
    distribute_system_name      STRING  COMMENT"对接分销平台名称",

    signer_id                   INT     COMMENT"签单人id",
    servicer_id                 INT     COMMENT"客服id",

    fee_sms                     DOUBLE  COMMENT"平台短信费收取标准",
    fee_code                    DOUBLE  COMMENT"平台凭证费收取标准",
    fee_code_unit               STRING  COMMENT"平台凭证费单位",
    fee_withdraw                DOUBLE  COMMENT"平台提现手续费百分比",

--    customer_is_resource          BOOLEAN COMMENT"客户是否为资源方",
--    customer_resource_id          INT     COMMENT"客户资源id",
--    customer_resource_name        STRING COMMENT"客户资源名称",
--    customer_resource_type        STRING COMMENT"客户资源类型",
--    customer_resource_level       STRING COMMENT"客户资源级别"
    group_id                   STRING COMMENT '账号分组'
) COMMENT "会员账号信息表" 
PARTITIONED by (pt INT)
STORED AS ORC;


-- 普通用户的手机号7~11位脱敏
INSERT OVERWRITE table ods_pft_member_d_f PARTITION (pt=${ds})
SELECT 
    m.id                                                               AS user_id,
    INT(m.account_id)                                                     AS user_account_id,
    INT(m.customer_id)                                                      AS user_customer_id,
    m.dname                                                            AS user_name,

    m.dtype                                                            AS user_type_code,
    CASE m.dtype 
        WHEN 0 THEN "供应商"
        WHEN 1 THEN "分销商"
        when 2 THEN "资源方"
        when 3 THEN "合并终端后的资源方"
        WHEN 5 THEN "普通用户"
        WHEN 6 THEN "员工"
        when 7 THEN "集团帐号"
        WHEN 9 THEN "平台管理员"
    END                                                                 AS user_type, 
    m.account                                                           AS user_account,
    CASE m.status
       WHEN 0 THEN "正常"
       when 1 THEN "禁用"
       WHEN 2 THEN "删除"
       WHEN 3 THEN "未审核" 
    END                                                                 AS user_status , 
                                    
    SUBSTR(m.creattime,1,10)                                            AS user_regist_time,         --注册日期
    SUBSTR(m.creattime,1,10)                                            AS user_contarct_firstdate,  -- 首次合作日期,默认为注册时间，后续用市场直签表签协议日期
    IF(m.lasttime='0000-00-00 00:00:00','', m.lasttime)                 AS user_login_lasttime,     -- 上次登录日期

    m.bank_account1                                                     AS user_bank_card1,
    m.bank_account2                                                     AS user_bank_card2,
    m.alipay                                                            AS user_alipay,

    -- 客户信息
    INT(m.customer_id)                                                      AS customer_id,                      -- 客户ID
    -- 散客手机号隐藏后4位
    IF(m.dtype=5,IF(LENGTH(m.mobile)=11,CONCAT(SUBSTR(m.mobile,1,7),REPEAT('*',4)),NULL),m.mobile)    AS customer_mobile,           -- 客户手机号

    -- m.dcodeURL<>'' 对接第三方分销平台,根据对接网址判断对接系统商户,对接系统类型
    IF(m.dcodeURL<>'' AND d.distribute_system_type='OTA','OTA','普通商户')                                  AS user_is_OTA,                    --用户是否对接OTA平台
    CASE
      WHEN m.id=3034  THEN 'OTA'   --南京途牛
      WHEN m.dcodeURL<>''  THEN IF(ISNULL(d.distribute_system_type),'其他分销平台',d.distribute_system_type)
      ELSE NULL
    END                                                                 AS distribute_system_name,   --分销平台类型
    --if(m.dcodeURL<>'',if(isnull(d.distribute_system_type),'其他分销平台',d.distribute_system_type),null)    as distribute_system_name,         --分销平台类型
    IF(m.id=3034,'南京途牛',d.distribute_system_name)               AS distribute_system_name,           --分销平台名称

    -- 商户平台合作及服务人员
    INT(IF(m.salesid=0,NULL,m.salesid))                                      AS signer_id,                        -- 签单人id
    INT(IF(m.kefuID=0,NULL,m.kefuID))                                        AS servicer_id,                      -- 客服id

    -- 供应商使用平台收费标准
    IF(m.dtype=0,m.fee_sms,0)                                           AS fee_sms,                           --短信费
    IF(m.dtype=0,IF(m.fee_platform>0,m.fee_platform,m.fee_code),0)      AS fee_code,                          --凭证费
    IF(m.dtype=0,IF(m.fee_code<>0,'元/单','元/人'),'')                   AS fee_code_unit,                     --凭证费单位
 --     if(isnull(csms.fee),if(m.dtype=0,m.fee_sms,null),csms.fee)/100  fee_sms,                                       -- 短信费标准
 --     if(isnull(ccode.fee),if(m.dtype=0,if(m.fee_code<>0,m.fee_code,m.fee_platform),null),ccode.fee)/100 fee_code,   -- 凭证费标准
 --     if(isnull(ccode.fee),if(m.dtype=0,if(m.fee_code<>0,'/单','/人'),null),'/单') fee_code_unit,                     -- 凭证费单位
    m.fee_bank/100                                                      AS fee_withdraw,                               -- 提现手续费百分

    m.group_id                                                          AS group_id

FROM 
(
    SELECT
        id,         
        account_id, 
        customer_id,
        dname,
        dtype,
        account,
        status,
        creattime,
        lasttime,
        bank_account1,
        bank_account2,
        alipay,
        customer_id,
        dcodeURL,
        salesid,
        kefuID,
        fee_platform,
        fee_code,
        fee_bank,
        group_id ,
        mobile,
        fee_sms
    FROM s_myuu_pft_member_d_f 
    WHERE pt=${ds}
) AS m
LEFT JOIN 
(
    SELECT distribute_system_type, distribute_system_name,dcodeurl_like 
    FROM ods_distribute_system_type_d_f 
    WHERE pt=${ds}
) AS d 
ON m.dcodeurl LIKE CONCAT('%',d.dcodeurl_like,'%');
