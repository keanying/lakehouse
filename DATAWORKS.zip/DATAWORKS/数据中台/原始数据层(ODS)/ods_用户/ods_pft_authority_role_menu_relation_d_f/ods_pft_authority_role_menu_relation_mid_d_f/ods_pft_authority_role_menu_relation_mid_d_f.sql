CREATE TABLE if not EXISTS `ods_pft_authority_role_menu_relation_mid_d_f`(
    `id` bigint COMMENT'主键ID',
    `role_id` bigint COMMENT'角色ID',
    `menu_id` bigint COMMENT'菜单ID',
    `menu_tag` string COMMENT'菜单值',
    `expire_time` bigint COMMENT'过期时间，应用中心模块',
    `begin_time` bigint COMMENT'过期时间，应用中心模块',
    `create_time` bigint COMMENT'创建时间',
    `update_time` bigint COMMENT'更新时间',
    `is_deleted` bigint COMMENT'状态 0=正常 1=已删除'
 )COMMENT "角色菜单关联表" PARTITIONED BY(
    `pt` string
 )STORED AS ORC;
 
insert 
into 
    ods_pft_authority_role_menu_relation_mid_d_f
    partition(pt='pt')  select
        id,
        role_id,
        menu_id,
        menu_tag,
        expire_time,
        begin_time,
        create_time,
        update_time,
        is_deleted 
    from
        ods_pft001_pft_authority_role_menu_relation_d_i 
    where
        pt='${ds}' ;


--插入历史数据生成全量表
-- insert into 
--     ods_pft_authority_role_menu_relation_mid_d_f
--     partition(pt='pt')  select
--         id,
--         role_id,
--         menu_id,
--         menu_tag,
--         expire_time,
--         begin_time,
--         create_time,
--         update_time,
--         is_deleted 
--     from
--         data_middle_bi.s_pft001_pft_authority_role_menu_relation_d_f 
--     where
--         pt='${bdp.system.bizdate}' 
--         and update_time<UNIX_TIMESTAMP(concat('${bdp.system.bizdate}','000000'),'yyyyMMddHHmmss') ;

