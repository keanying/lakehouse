CREATE TABLE if not EXISTS `ods_pft_authority_role_menu_relation_d_f`(
    `role_id` bigint COMMENT'角色ID',
    `menu_id` bigint COMMENT'菜单ID',
    `menu_tag` string COMMENT'菜单值',
    `expire_time` bigint COMMENT'过期时间，应用中心模块',
    `begin_time` bigint COMMENT'过期时间，应用中心模块',
    `create_time` bigint COMMENT'创建时间',
    `update_time` bigint COMMENT'更新时间',
    `is_deleted` bigint COMMENT'状态 0=正常 1=已删除'
 )PARTITIONED BY(
    `pt` string
 )STORED AS ORC;

insert OVERWRITE
    table ods_pft_authority_role_menu_relation_d_f partition(pt='${ds}') select
        a.role_id,
        a.menu_id,
        a.menu_tag,
        a.expire_time,
        a.begin_time,
        a.create_time,
        a.update_time,
        a.is_deleted              
    from
        ods_pft_authority_role_menu_relation_mid_d_f a                
    inner join
        (
            SELECT
                role_id,
                menu_id,
                menu_tag,
                is_deleted,
                max(update_time) as update_time                                        
            FROM
                ods_pft_authority_role_menu_relation_mid_d_f                                         
            where
                pt='pt'                          
            group by
                role_id,
                menu_id,
                menu_tag,
                is_deleted                           
        ) b                                        
            on a.role_id=b.role_id                                        
            and a.menu_id=b.menu_id                                        
            and a.menu_tag=b.menu_tag                                        
            and a.is_deleted=b.is_deleted                                        
            and a.update_time=b.update_time                           
    where
        a.pt='pt';
