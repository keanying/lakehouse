--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-04 14:26:47
--EMR任务只能运行在独享资源组上
--********************************************************************--

-- drop table if exists ods_pft_common_dict_d_f;

create table if not EXISTS ods_pft_common_dict_d_f(
    id                           INT    COMMENT "记录id",    
    name                         string COMMENT "名称", 
    code                         INT    COMMENT "父编码",
    dict_type                    STRING COMMENT "类型", 

    parent_id                    int    COMMENT "父id",
    parent_name                  string COMMENT "父名称",
    parent_code                  int    COMMENT "父编码", 
    parent_dict_type             string COMMENT "父类型"
    
)COMMENT "通用字典表" PARTITIONED by(
    pt string
)STORED AS ORC;



INSERT OVERWRITE table ods_pft_common_dict_d_f PARTITION (pt="${ds}")
select 
    d.id         ,
    d.name       ,
    INT(d.code)       ,
    d.dict_type  ,

    d1.id          as parent_id,
    d1.name        as parent_name,
    INT(d1.code)        as parent_code,
    d1.dict_type   as parent_dict_type

FROM  (select * from ods_myuu_pft_common_dict_d_f 
       where pt="${ds}" )  d
left join (select * from ods_myuu_pft_common_dict_d_f   where pt="${ds}" ) d1 on d1.id=d.parent_id
;