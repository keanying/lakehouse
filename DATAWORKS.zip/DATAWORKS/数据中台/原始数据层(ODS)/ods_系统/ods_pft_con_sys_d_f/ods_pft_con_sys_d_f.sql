--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-01 14:18:48
--EMR任务只能运行在独享资源组上
--********************************************************************--


create table if not EXISTS ods_pft_con_sys_d_f(
    id                         INT COMMENT 'id',
    name                       string COMMENT '第三方票务系统名称',
    Mpath                      string COMMENT '对接程序地址',
    sourceT                    string COMMENT '对接类型：0=票付通，1=九天闸机权限，2=第三方，3=开放接口',

    Mdetails                   INT COMMENT '1 第三方请求权限（二次交互时）0 票付通',
    system_type                INT COMMENT '团购标志0-非团购1- 团购网',
    account_name               string COMMENT '票务系统的账号标识',
    password_name              STRING COMMENT '票务系统的账号密码标识',
    if_Pftcode                 int comment '是否采用票务系统的凭证码,0- 使用票付通凭证码1- 使用票务系统凭证码2- 异步返回票务系统凭证码',

    sms                         int comment '发短信方,0-票付通1-票务系统',
    coopB                       int comment '三方系统标识',
    encoding_products           string comment '填写格式：由三方系统提供',
    timeout                     int comment '接口请求超时时间',
    errortime                   int comment '最大的错误次数',
    is_offline                  int comment '该对接系统是不是被下线',
    offline_time                int comment '系统被下线的时间',
    contact_info                STRING  comment '对接系统联系人信息[{mobile:"",phone:"",qq:",name:"},{}]',
    notice_code                 int comment '1:同步发码 2:异步发码 3:不发码',
    white_ip                    string comment '白名单ip  多个地址逗号分隔',
    create_time                 int comment '创建时间戳'
    
)COMMENT '对接票务系统' PARTITIONED by(
    pt int
) STORED AS ORC;

--Mpath='group' 非上游系统，为下游报错订单创建的
INSERT OVERWRITE table ods_pft_con_sys_d_f PARTITION (pt='${ds}')
select 
    id                  as   id,
   name                 as   name,
   Mpath                as   Mpath,
   sourceT              as   sourceT,

   Mdetails             as   Mdetails,
   system_type          as   system_type,
   account_name         as   account_name,
   password_name        as   password_name,
   if_Pftcode           as   if_Pftcode,
   
   sms                  as   sms ,
   coopB                as   coopB,
   encoding_products    as   encoding_products,
   timeout              as   timeout,
   errortime            as   errortime,
   is_offline           as   is_offline,
   offline_time         as   offline_time,
   contact_info         as   contact_info,
   INT(notice_code)          as   notice_code ,
   white_ip             as   white_ip ,
   create_time          as   create_time          

FROM  s_pft_con_sys_d_f 
where pt='${ds}' and Mpath<>'group'

;
