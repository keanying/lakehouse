
INSERT OVERWRITE TABLE ods_order_addon_d_i PARTITION(`orderdate` = '${ds}')
SELECT 
    t1.`id`,
    t1.`orderid`,
    t1.`dstatus`,
    t1.`confirm_time`,
    t1.`confirm_op`,
    t1.`ifpack`,
    t1.`sysorder`,
    t1.`pack_order`,
    t1.`pack_process`,
    t1.`ifprint`,
    t1.`vcode`,
    t1.`tordernum`,
    t1.`partner_mark`,
    t1.`link_ordernum`,
    t1.`order_time`,
    t1.`update_time`,
    t1.`order_month`,
    t1.`apply_did`,
    `sync_state`
FROM 
(
    SELECT *
    FROM s_order_addon_d_i 
    WHERE orderdate = ${ds}
) AS t1 
INNER JOIN 
(
    SELECT ordernum
    FROM ods_order_d_i 
    WHERE orderdate = ${ds}
) AS t2
ON t1.orderid = t2.ordernum