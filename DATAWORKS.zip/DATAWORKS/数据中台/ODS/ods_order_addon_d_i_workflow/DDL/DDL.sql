

CREATE TABLE IF NOT EXISTS `s_order_addon_d_i`(
    `id`            BIGINT      COMMENT '表ID', 
    `orderid`       STRING      COMMENT '订单号', 
    `dstatus`       TINYINT     COMMENT '确认订单状态0无需确认 1待确认 2已确认未验证 3已确认已验证 4确认后取消 5确认后修改,6演出套票的订单', 
    `confirm_time`  STRING      COMMENT '确认时间', 
    `confirm_op`    INT         COMMENT '分销商ID', 
    `ifpack`        INT         COMMENT '0非套票订单1套票主订单 >100000套票从订单（2票付通从订单）', 
    `sysorder`      TINYINT     COMMENT '子票是否已经处理完成:100=处理完,0=没有', 
    `pack_order`    STRING      COMMENT '套票主票订单号', 
    `pack_process`  STRING      COMMENT '线下自填的流水号json数据', 
    `ifprint`       TINYINT     COMMENT '是否被打印 1代表被打印', 
    `vcode`         STRING      COMMENT '对接第三方系统的凭证码', 
    `tordernum`     STRING      COMMENT '对接第三方系统的对方订单', 
    `partner_mark`  SMALLINT    COMMENT '是否对接三方系统标识', 
    `link_ordernum` STRING      COMMENT '原来uu_order_fx_details->concat_id', 
    `order_time`    INT         COMMENT '逻辑下单时间', 
    `update_time`   INT         COMMENT '订单更新时间', 
    `order_month`   TINYINT     COMMENT '逻辑下单月份', 
    `apply_did`     INT         COMMENT '原始供应商ID', 
    `sync_state`    TINYINT     COMMENT '是否同步标示 1:同步,0:无需同步'
)
COMMENT '订单扩展表_每日增量表'
PARTITIONED BY (
    `orderdate`     INT         COMMENT '逻辑下单日期'
) STORED AS ORC;


CREATE TABLE IF NOT EXISTS `ods_order_addon_d_i`(
    `id`            BIGINT      COMMENT '表ID', 
    `orderid`       STRING      COMMENT '订单号', 
    `dstatus`       TINYINT     COMMENT '确认订单状态0无需确认 1待确认 2已确认未验证 3已确认已验证 4确认后取消 5确认后修改,6演出套票的订单', 
    `confirm_time`  STRING      COMMENT '确认时间', 
    `confirm_op`    INT         COMMENT '分销商ID', 
    `ifpack`        INT         COMMENT '0非套票订单1套票主订单 >100000套票从订单（2票付通从订单）', 
    `sysorder`      TINYINT     COMMENT '子票是否已经处理完成:100=处理完,0=没有', 
    `pack_order`    STRING      COMMENT '套票主票订单号', 
    `pack_process`  STRING      COMMENT '线下自填的流水号json数据', 
    `ifprint`       TINYINT     COMMENT '是否被打印 1代表被打印', 
    `vcode`         STRING      COMMENT '对接第三方系统的凭证码', 
    `tordernum`     STRING      COMMENT '对接第三方系统的对方订单', 
    `partner_mark`  SMALLINT    COMMENT '是否对接三方系统标识', 
    `link_ordernum` STRING      COMMENT '原来uu_order_fx_details->concat_id', 
    `order_time`    INT         COMMENT '逻辑下单时间', 
    `update_time`   INT         COMMENT '订单更新时间', 
    `order_month`   TINYINT     COMMENT '逻辑下单月份', 
    `apply_did`     INT         COMMENT '原始供应商ID', 
    `sync_state`    TINYINT     COMMENT '是否同步标示 1:同步,0:无需同步'
)
COMMENT '订单扩展表_每日增量表'
PARTITIONED BY (
    `orderdate`     INT         COMMENT '逻辑下单日期'
) STORED AS ORC;

