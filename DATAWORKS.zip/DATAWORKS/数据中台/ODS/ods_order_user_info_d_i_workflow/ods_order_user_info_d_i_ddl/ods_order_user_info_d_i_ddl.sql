CREATE TABLE IF NOT EXISTS `s_order_user_info_d_i`(
    `id`            BIGINT  COMMENT '',
    `ordernum`      STRING  COMMENT '订单号',
    `ordername`     STRING  COMMENT '取票人姓名',
    `ordertel`      STRING  COMMENT '取票人电话',
    `personid`      STRING  COMMENT '取票人身份信息',
    `voucher_type`  TINYINT COMMENT '身份信息类型:1=身份证,2=护照,3=军官证,4=回乡证,5=台胞证,99=其他',
    `create_time`   INT     COMMENT '创建时间',
    `province_code` STRING  COMMENT '省份',
    `city_code`     STRING  COMMENT '城市',
    `town_code`     STRING  COMMENT '乡镇',
    `address`       STRING  COMMENT '具体地址',
    `apply_did`     INT     COMMENT '原始供应商ID',
    `sync_state`    TINYINT COMMENT '是否同步标示 1:同步,0:无需同步',
    `mobile_area`   STRING  COMMENT '手机区号',
    `mobile_region` STRING  COMMENT '手机区号的区域代码'
) COMMENT '订单取票人信息表-归档表' 
PARTITIONED BY(
    `orderdate`     INT     COMMENT '下单日期'
)STORED AS ORC;


CREATE TABLE IF NOT EXISTS `ods_order_user_info_d_i`(
    `id`            BIGINT  COMMENT '',
    `ordernum`      STRING  COMMENT '订单号',
    `ordername`     STRING  COMMENT '取票人姓名',
    `ordertel`      STRING  COMMENT '取票人电话',
    `personid`      STRING  COMMENT '取票人身份信息',
    `voucher_type`  TINYINT COMMENT '身份信息类型:1=身份证,2=护照,3=军官证,4=回乡证,5=台胞证,99=其他',
    `create_time`   INT     COMMENT '创建时间',
    `province_code` STRING  COMMENT '省份',
    `city_code`     STRING  COMMENT '城市',
    `town_code`     STRING  COMMENT '乡镇',
    `address`       STRING  COMMENT '具体地址',
    `apply_did`     INT     COMMENT '原始供应商ID',
    `sync_state`    TINYINT COMMENT '是否同步标示 1:同步,0:无需同步',
    `mobile_area`   STRING  COMMENT '手机区号',
    `mobile_region` STRING  COMMENT '手机区号的区域代码'
) COMMENT '订单取票人信息表-归档表' 
PARTITIONED BY(
    `orderdate`     INT     COMMENT '下单日期'
)STORED AS ORC;

