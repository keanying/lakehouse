INSERT OVERWRITE TABLE ods_order_user_info_d_i PARTITION(`orderdate` = '${ds}')
SELECT 
    t1.`id`,
    t1.`ordernum`,
    t1.`ordername`,
    t1.`ordertel`,
    t1.`personid`,
    t1.`voucher_type`,
    t1.`create_time`,
    t1.`province_code`,
    t1.`city_code`,
    t1.`town_code`,
    t1.`address`,
    t1.`apply_did`,
    t1.`sync_state`,
    -- t1.`mobile_area`,

    IF(
        LENGTH(t1.`ordertel`) = 11  AND (ISNULL(t1.`mobile_area`) OR t1.`mobile_area` = ''), 
        86, 
        t1.`mobile_area`
    ) AS `mobile_area`,

    t1.`mobile_region`
FROM
(
    SELECT *
    FROM s_order_user_info_d_i 
    WHERE orderdate = ${ds}
) AS t1 
INNER JOIN 
(
    SELECT ordernum
    FROM ods_order_d_i 
    WHERE orderdate = ${ds}
) AS t2
ON t1.ordernum = t2.ordernum