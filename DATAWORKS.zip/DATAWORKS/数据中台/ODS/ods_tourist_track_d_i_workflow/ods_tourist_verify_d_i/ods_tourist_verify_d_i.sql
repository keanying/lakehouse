
CREATE TABLE IF NOT EXISTS `ods_tourist_verify_d_i`
(
    `apply_did`             INT     COMMENT '原始供应商ID', 
    `orderid`               STRING  COMMENT '订单号ID', 

    `verify_num`            INT     COMMENT '验证数量',

    `age`                   STRING  COMMENT '年龄-来自身份证', 
    `sex`                   STRING  COMMENT '性别-来自身份证', 

    `country_name`          STRING  COMMENT '国家-优先使用字段', 
    `province_name`         STRING  COMMENT '省-优先使用字段', 
    `city_name`             STRING  COMMENT '市-优先使用字段', 
    `district_name`         STRING  COMMENT '区县-优先使用字段', 

    `phone_country_name`    STRING  COMMENT '国家-手机号归属地', 
    `phone_province_name`   STRING  COMMENT '省-手机号归属地', 
    `phone_city_name`       STRING  COMMENT '市-手机号归属地', 
    `phone_district_name`   STRING  COMMENT '区县-手机号归属地', 

    `idcard_country_name`   STRING  COMMENT '国家-证件归属地', 
    `idcard_province_name`  STRING  COMMENT '省-证件归属地', 
    `idcard_city_name`      STRING  COMMENT '市-证件归属地', 
    `idcard_district_name`  STRING  COMMENT '区县-证件归属地', 

    `idcard`                STRING  COMMENT '游客身份信息', 
    `voucher_type`          TINYINT COMMENT '身份信息类型:1=身份证,2=护照,3=军官证,4=回乡证,5=台胞证,99=其他', 
    `mobile`                STRING  COMMENT '游客手机号', 
    `lid`                   INT     COMMENT '景点ID',
    `tid`                   INT     COMMENT '门票id',
    `idx`                   BIGINT  COMMENT '订单序号', 
    `terminal`              STRING  COMMENT '终端号', 
    `branch_terminal`       STRING  COMMENT '分终端号', 
    `ext_content`           STRING  COMMENT '验证或是取消过程中的一些数据', 

    `tourist`               STRING  COMMENT '游客姓名', 
    `orderdate_detail`      STRING  COMMENT '详细验证时间', 

    `msg`                   STRING  COMMENT '备注信息',
    `is_first_used`         INT     COMMENT '是否首次验证,1=首次,0=非首次。211209之后有效',
    `is_overdue`            INT     COMMENT '是否过期验证,1=过期验证,0=非过期验证'
)
COMMENT '核销游客信息表，按核销日期分区'
PARTITIONED BY (`insertdate` STRING COMMENT '核销日期')
STORED AS ORC;


-- INSERT OVERWRITE TABLE ods_tourist_verify_d_i PARTITION(insertdate)
-- SELECT 
--     track.`apply_did`                           AS `apply_did`,
--     track.`ordernum`                            AS `orderid`,
--     track.`tnum`                                AS `verify_num`,

--     NVL(info.`age`, -1)                         AS `age`,
--     NVL(info.`sex`, '未知')                     AS `sex`,

--     NVL(info.`country_name`, '未知')            AS `country_name`,
--     NVL(info.`province_name`, '未知')           AS `province_name`,
--     NVL(info.`city_name`, '未知')               AS `city_name`,
--     NVL(info.`district_name`, '未知')           AS `district_name`,

--     NVL(info.`phone_country_name`, '未知')      AS `phone_country_name`,
--     NVL(info.`phone_province_name`, '未知')     AS `phone_province_name`,
--     NVL(info.`phone_city_name`, '未知')         AS `phone_city_name`,
--     NVL(info.`phone_district_name`, '未知')     AS `phone_district_name`,

--     NVL(info.`idcard_country_name`, '未知')     AS `idcard_country_name`,
--     NVL(info.`idcard_province_name`, '未知')    AS `idcard_province_name`,
--     NVL(info.`idcard_city_name`, '未知')        AS `idcard_city_name`,
--     NVL(info.`idcard_district_name`, '未知')    AS `idcard_district_name`,

--     info.`idcard`               AS `idcard`,
--     info.`voucher_type`         AS `voucher_type`,
--     info.`mobile`               AS `mobile`,
--     info.`lid`                  AS `lid`,
--     track.`tid`                 AS `tid`,
--     track.`idx`                 AS `idx`,
--     track.`terminal`            AS `terminal`,
--     track.`branch_terminal`     AS `branch_terminal`,
--     track.`ext_content`         AS `ext_content`,
    
--     info.`tourist`              AS `tourist`,
--     FROM_UNIXTIME(insert_time)  AS `orderdate_detail`,

--     track.`msg`                 AS `msg`,
--     IF(ext_content LIKE '%"is_first_used":1%', 1, 0)    AS is_first_used,
--     IF(msg LIKE '%过期%', 1, 0)                         AS is_is_overdue,

--     track.`insertdate`
-- FROM 
-- (
--     -- 昨天验证的游客数量
--     SELECT 
--         ordernum, 
--         idx,  
--         tnum,
--         insertdate,
--         tid,
--         apply_did,
--         msg,
--         terminal,
--         branch_terminal,
--         ext_content,
--         insert_time
--     FROM s_tourist_track_d_i 
--     WHERE 1=1
--       AND insertdate = '${ds}' 
--       AND track_action = 1 
-- ) AS track 
-- LEFT JOIN 
-- (
--     -- 近一年下单游客
--     SELECT 
--         `apply_did`,      
--         `orderid`,        
--         `age`,           
--         `sex`,   

--         `country_name`,
--         `province_name`,
--         `city_name`,
--         `district_name`,

--         `phone_country_name`,   
--         `phone_province_name`,  
--         `phone_city_name`,   
--         `phone_district_name`,  

--         `idcard_country_name`,  
--         `idcard_province_name`, 
--         `idcard_city_name`,     
--         `idcard_district_name`, 

--         `idcard`,      
--         `voucher_type`,
--         `mobile`,      
--         `lid`,
--         `idx`,
--         `tourist`  
--     FROM ods_tourist_info_d_i
--     WHERE 1 = 1
--       AND orderdate >= '${ds}' - 732
-- ) AS info 
-- ON track.ordernum = info.orderid
-- AND track.idx = info.idx;
