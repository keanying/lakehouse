

CREATE TABLE IF NOT EXISTS `ods_order_d_i`(
    `id`                BIGINT      COMMENT '表id',
    `member`            INT         COMMENT '购买者ID',
    `ordernum`          STRING      COMMENT '订单号',
    `certnum`           BIGINT      COMMENT '资源ID',
    `remotenum`         STRING      COMMENT '远端订单号',
    `lid`               INT         COMMENT '景区id',
    `tid`               INT         COMMENT '门票id',
    `pid`               INT         COMMENT '产品id',
    `aid`               INT         COMMENT '供应商ID',
    `tnum`              BIGINT      COMMENT '门票数量',
    `tprice`            INT         COMMENT '单价',
    `ordername`         STRING      COMMENT '取票人姓名',
    `ordertel`          STRING      COMMENT '取票人电话',
    `contacttel`        STRING      COMMENT '取票人电话',
    `ordertime`         STRING      COMMENT '下单时间',
    `playtime`          TIMESTAMP   COMMENT '预计游玩时间',
    `begintime`         TIMESTAMP   COMMENT '开始时间',
    `endtime`           TIMESTAMP   COMMENT '结束时间',
    `ctime`             STRING      COMMENT '取消时间',
    `dtime`             STRING      COMMENT '验证时间',
    `status`            INT         COMMENT '订单状态：0=未使用,1=已使用,2=已过期,3=被取消,4=待确认(酒店)，待收货(特产),5=被终端修改,6=被终端撤销,7=部分使用,8=订单完结,9=被删除',
    `pay_status`        INT         COMMENT '支付方式:0=现场支付,1=已支付,2=未支付',
    `salerid`           INT         COMMENT '商家ID',
    `remsg`             BIGINT      COMMENT '短信重发限制次数',
    `smserror`          SMALLINT    COMMENT '短信错误信息',
    `paymode`           INT         COMMENT '支付方式：0 = 余额支付,1 = 支付宝,2 = 授信支付,3 = 产品自销,4 = 现场支付,5 = 微信支付,6 = 会员卡支付,7 = 银联支付,8 = 环迅支付,9 = 现金支付,10 = 会员卡,11 = 拉卡拉（商户）,12 = 拉卡拉（平台）,13 = 特权支付（年卡）,14 = 微信（聚合）,15 = 平安银行,16 = 支付宝（聚合）,17 = 会员卡支付,18 = 计时卡支付,25 = 招行一网通支付,26 = 银联商务支付,27 = 银联商务POS支付,28 = 威富通支付,29 = 易宝云企付,33 = 博思支付,35 = 积分支付,36 = POS支',
    `totalmoney`        INT         COMMENT '总的支付金额',
    `ordermode`         INT         COMMENT '下单方式:0=正常分销商下单,1=普通用户支付,2=用户手机支付,3=会员卡购票,10=云票务,11=微信商城,12=自助机,13=二级店铺,14=闸机购票,15=智能终端,16=计调下单,17=淘宝码商,18=年卡,19=微信端,20=外部接口OTA下单,22=一卡通,23=套票子票',
    `onsale`            INT         COMMENT '0正常1使用优惠价支付2修改过的订单',
    `personid`          STRING      COMMENT '取票人身份信息',
    `callback`          INT         COMMENT '是否需要回调0无需1必需',
    `code`              BIGINT      COMMENT '凭证码',
    `unionCheck`        INT         COMMENT '提现类型：0=正常订单，1=不可退而且可提现的订单，2=独立收款',
    `visitors`          INT         COMMENT '订单客户类型：1=游客,2=分销商',
    `pay_time`          BIGINT      COMMENT '订单支付时间',
    `order_time`        BIGINT      COMMENT '逻辑下单时间',
    `update_time`       INT         COMMENT '订单更新时间',
    `order_month`       INT         COMMENT '逻辑下单月份',
    `product_type`      STRING      COMMENT '商品类型',
    `apply_did`         INT         COMMENT '原始供应商ID',
    `sync_state`        INT         COMMENT '是否同步标示 1:同步,0:无需同步',
    `trade_order_id`    STRING      COMMENT '交易订单号'
) COMMENT '订单状态表，按订单下单时间分区'
PARTITIONED BY (
    `orderdate`         INT         COMMENT '下单日期'
) STORED AS ORC;


INSERT OVERWRITE TABLE ods_order_d_i PARTITION(`orderdate` = ${ds})
SELECT 
    `id`,
    `member`,
    `ordernum`,
    `certnum`,
    `remotenum`,
    `lid`,
    `tid`,
    `pid`,
    `aid`,
    `tnum`,
    `tprice`,
    `ordername`,
    `ordertel`,
    `contacttel`,
    `ordertime`,
    `playtime`,
    `begintime`,
    `endtime`,
    `ctime`,
    `dtime`,
    `status`,
    `pay_status`,
    `salerid`,
    `remsg`,
    `smserror`,
    `paymode`,
    `totalmoney`,
    `ordermode`,
    `onsale`,
    `personid`,
    `callback`,
    `code`,
    `unionCheck`,
    `visitors`,
    `pay_time`,
    `order_time`,
    `update_time`,
    `order_month`,
    `product_type`,
    `apply_did`,
    `sync_state`,
    `trade_order_id`
FROM ods_order_update_d_i
-- WHERE `orderdate` = ${ds};
WHERE `update` = ${ds}
--   AND order_time >= UNIX_TIMESTAMP('${ds}', 'yyyyMMdd') 
--   AND order_time < UNIX_TIMESTAMP(
--                     DATE_ADD(
--                         FROM_UNIXTIME(UNIX_TIMESTAMP('${ds}', 'yyyyMMdd'), 'yyyy-MM-dd'),
--                         1
--                     ),
--                     'yyyy-MM-dd'
--                 );
  AND ordertime >= TO_DATE('${ds}', 'yyyyMMdd') 
  AND ordertime < DATE_ADD(TO_DATE('${ds}', 'yyyyMMdd'), 1);
