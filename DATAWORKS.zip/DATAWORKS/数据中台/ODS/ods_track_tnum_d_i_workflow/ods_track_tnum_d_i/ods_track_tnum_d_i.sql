-- 根据订单日志，清洗出每一笔行为的票数

CREATE TABLE IF NOT EXISTS `ods_track_tnum_d_i`
(
    `id`                        BIGINT  COMMENT '表id',
    `ordernum`                  STRING  COMMENT '订单号ID', 
    `apply_did`                 INT     COMMENT '原始供应商ID',

    `tid`                       INT     COMMENT '门票id',
    -- `sale_price`                INT     COMMENT '票售价',

    `booking_ticket_num`        INT     COMMENT '预定票数',
    `pay_ticket_num`            INT     COMMENT '支付票数',
    -- 就是取消
    `cancel_ticket_num`         INT     COMMENT '退票数',
    `verify_ticket_num`         INT     COMMENT '验证票数',
    `revoke_ticket_num`         INT     COMMENT '撤改/撤销票数',
    `take_ticket_num`           INT     COMMENT '取票数',
    `after_sale_ticket_num`     INT     COMMENT '售后票数',
    `finish_ticket_num`         INT     COMMENT '完结票数',

    `action`                    BIGINT   COMMENT '变更状态:1=0=下单,1=修改,2=取消,3=出票,4=支付,验证,撤销,7=撤改,8=重打印,9=离线订单下载,10=处理退票申请,11=提交退票申请,12=过期,13=同意退票申请,14=拒绝退票申请,15=核销,16=订单加票,17=完结',
    `source`                    BIGINT   COMMENT '操作来源:0=终端机,1=软终端,2=自助机,3=外部通知更新,4=云票务,5=云闸机,6=PC-支付宝,7=手机支付宝,8=支付宝刷卡,9=支付宝扫码,10=微信支付,11=微信刷卡,12=微信扫码,13=PC-银联,14=手机-银联,15=PC-环迅,16=内部接口,17=外部接口,18=undefined,19=自运行服务,20=安卓智能终端机,21=验证服务器,22=微信商城,23=二级店铺,24=OTA,25=会员购票,26=年卡特权,27=平安银行,28=内部接口,29=民生乐收银,30=一卡通',

    `left_num`                  BIGINT  COMMENT '剩余票数',
    `insertTime`                STRING  COMMENT '添加时间'
)
COMMENT '订单轨迹日增量表，以插入日期作为分区字段'
PARTITIONED BY (
    `insertdate`                INT     COMMENT '插入日期'
)
STORED AS ORC;


------------------------------------------------------------------------------------------------------------------------

-- 倒排第一条的 left_num, 计算完结票数使用
-- CACHE TABLE CACHE_LEFT
-- AS 
-- SELECT ordernum, left_num
-- FROM (
--     SELECT 
--         ordernum, 
--         left_num, 
--         ROW_NUMBER() OVER (PARTITION BY ordernum ORDER BY insertTime DESC) as rn
--     FROM s_order_track_d_i
--     WHERE insertdate >= DATE_SUB(${date1}, 732)
--       AND insertdate <= ${date2}
--       AND action = 5 AND source = 32
-- ) t
-- WHERE t.rn = 1;


------------------------------------------------------------------------------------------------------------------------

DROP VIEW IF EXISTS FILTER_ID;
CACHE TABLE FILTER_ID
AS
-- 需要过滤的记录
-- 同一笔订单，4 之前的 1 和 16 删除。(注意：必须用id过滤，不能用插入时间过滤)
SELECT DISTINCT t1.id AS id
FROM 
(
    SELECT id, ordernum
    FROM s_order_track_d_i 
    -- WHERE insertdate >= ${date1} AND insertdate <= ${date2}
    WHERE insertdate = ${ds}
      AND action IN (1, 16)
) AS t1 
LEFT JOIN
(
    SELECT id, ordernum
    FROM s_order_track_d_i 
    -- WHERE insertdate >= ${date1} AND insertdate <= ${date2}
    WHERE insertdate = ${ds}
      AND action IN (4)
) AS t2
ON t1.ordernum = t2.ordernum
WHERE t1.id < t2.id;


------------------------------------------------------------------------------------------------------------------------


INSERT OVERWRITE TABLE ods_track_tnum_d_i PARTITION(`insertdate`)
SELECT 
    `id`,
    `ordernum`,
    `apply_did`,
    `tid`,
    `booking_ticket_num`,
    `pay_ticket_num`,
    `cancel_ticket_num`,
    `verify_ticket_num`,
    `revoke_ticket_num`,
    `take_ticket_num`,
    `after_sale_ticket_num`,
    `finish_ticket_num`,
    `action`,
    `source`,  
    `left_num`,
    `insertTime`,
    `insertdate`
FROM 
(
    SELECT 
        id                                      AS `id`,
        ordernum                                AS `ordernum`,
        apply_did                               AS `apply_did`, 
        tid                                     AS `tid`,   

        -- CACHE_APPLY.sale_price                  AS `sale_price`,
        IF(action IN (0, 16),   tnum, 0)        AS `booking_ticket_num`, 
        IF(action IN (4, 16),   tnum, 0)        AS `pay_ticket_num`, 
        IF(action IN (1, 2),    tnum, 0)        AS `cancel_ticket_num`, 
        CAST(
                CASE 
                WHEN (action = 5 AND GET_JSON_OBJECT(ext_content, '$.need_write_num') > 0 )                                                       
                THEN GET_JSON_OBJECT(ext_content, '$.need_write_num')
                WHEN 
                (
                    (action = 5 AND source not in (53, 54, 32, 85)) 
                    OR 
                    (action = 33 AND source IN(32, 85)) 
                )    
                THEN tnum
                ELSE 0
            END 
         AS INT)                                AS `verify_ticket_num`,
        IF(action IN (6, 7) ,tnum, 0)           AS `revoke_ticket_num`, 
        IF(action IN (3)    ,tnum, 0)           AS `take_ticket_num`, 
        IF(action IN (38)   ,tnum, 0)           AS `after_sale_ticket_num`,     

        -- IF(action IN (17), tnum, 0)             
        IF(
            action IN (17),
            IF (
                tnum > 0,
                tnum,
                0
            ),
            0
        )                                       AS `finish_ticket_num`,

        `action`,
        `source`,       

        `left_num`,
        `insertTime`,
        insertdate
    -- FROM 
    -- (
    --     SELECT 
    --         id,
    --         apply_did,
    --         ordernum,
    --         tid,
    --         action,
    --         tnum,
    --         source,
    --         ext_content,
    --         insertdate
    FROM s_order_track_d_i 
    -- WHERE insertdate >= ${date1} AND insertdate <= ${date2} 
    WHERE insertdate = ${ds}
      AND tnum > 0
      AND id NOT IN (
          SELECT id FROM FILTER_ID
      )
    -- ) AS track 

    -- LEFT JOIN 
    -- (
    --     SELECT orderid, sale_price, origin_num, refund_num
    --     FROM s_order_apply_d_i
    --     WHERE orderdate >= TRUNC(ADD_MONTHS(${date1}, -24), 'YEAR')
    --       AND orderdate <= ${date2}
    -- ) AS CACHE_APPLY
    -- ON track.ordernum = CACHE_APPLY.orderid

    -- LEFT JOIN CACHE_LEFT
    -- ON track.ordernum = CACHE_LEFT.ordernum;
) 
WHERE (`booking_ticket_num` + `pay_ticket_num` + `cancel_ticket_num` + `verify_ticket_num` + `revoke_ticket_num` + `take_ticket_num` + `after_sale_ticket_num` + `finish_ticket_num`) > 0

