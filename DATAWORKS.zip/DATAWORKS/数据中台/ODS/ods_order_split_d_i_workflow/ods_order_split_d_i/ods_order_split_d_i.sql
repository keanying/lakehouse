CREATE TABLE IF NOT EXISTS ods_order_split_d_i(
    -- 原分销表字段
    id                          BIGINT          COMMENT '', 
    orderid                     STRING          COMMENT '订单号', 
    buyerid                     INT             COMMENT '购买用户ID', 
    sellerid                    INT             COMMENT '供应商ID', 
    level                       TINYINT         COMMENT '所处的级别：1=第一级，0=既是1级也是末级，-1=最末级，2=中间级别', 
    pmode                       INT             COMMENT '该级别的支付方式', 
    cost_money                  DECIMAL(12,0)   COMMENT '成本价（分为单位）', 
    sale_money                  DECIMAL(12,0)   COMMENT '销售价（分为单位）', 
    member_relationship         TINYINT         COMMENT '订单会员关系 0:平台关系,1:资源中心关系', 
    order_time                  INT             COMMENT '逻辑下单时间', 
    update_time                 INT             COMMENT '订单更新时间', 
    order_month                 TINYINT         COMMENT '逻辑下单月份', 
    apply_did                   INT             COMMENT '原始供应商ID', 
    sync_state                  TINYINT         COMMENT '是否同步标示 1:同步,0:无需同步', 

    -- 替代ods_order_aids_distribute_d_i
    distribute_num              INT             COMMENT '订单总分销级别',
    publisher_id                INT             COMMENT '产品发布商id',
    distributor_1_id            INT             COMMENT '一级分销商id',
    distribute_1_price          INT             COMMENT '一级分销价',
    resource_center_supplier_id INT             COMMENT '资源中心上架产品商户id',
    resource_center_purchase_id INT             COMMENT '资源中心采购商户id',

    -- 补充字段
    detail_split_level          INT             COMMENT '标识具体分销层级,1~6', 
    is_end_level                INT             COMMENT '是否分销末级'
)COMMENT '订单分销链-增量表' PARTITIONED by(
    orderdate       INT    COMMENT '下单日期'
)STORED AS ORC;


DROP VIEW IF EXISTS CACHE_TABLE;
CACHE TABLE CACHE_TABLE
AS
SELECT    
    -- 原始分销字段
    order_split_table.id,                                     
    order_split_table.orderid, 
    order_split_table.buyerid, 
    order_split_table.sellerid, 
    order_split_table.level, 
    order_split_table.pmode, 
    order_split_table.cost_money, 
    order_split_table.sale_money, 
    order_split_table.member_relationship, 
    order_split_table.order_time,         
    order_split_table.update_time, 
    order_split_table.order_month, 
    order_split_table.apply_did, 
    order_split_table.sync_state, 
    order_split_table.orderdate,

    -- 替代 ods_order_aids_distribute_d_i表用字段
    -- 1.本单级别（未考虑补一级之前）
    order_count_level_table.order_count_level       AS distribute_num,
    order_split_table_2.publisher_id                AS publisher_id,
    order_split_table_2.distributor_1_id            AS distributor_1_id,
    order_split_table_2.distribute_1_price          AS distribute_1_price,
    order_split_table_2.resource_center_supplier_id AS resource_center_supplier_id,
    order_split_table_2.resource_center_purchase_id AS resource_center_purchase_id,


    -- 标识具体分销层级(0~5标识方法)
    IF (
        level = 0 OR level = 1,
        -- 顶级供应商销售记录，标志为 0
        0,
        -- 非顶级供应商销售记录
        IF (
            level = -1,
            -- 最末级
            order_count_level_table.order_count_level - 1,
            IF (
                sellerid = level2_sellerid_table.level2_sellerid,
                -- 第一级销售
                1,
                -- 非第二级
                IF (
                    -- 本笔分销大于三级，且本级购买者为倒数第二级的购买者
                    (order_count_level_table.order_count_level > 3) AND (order_split_table.buyerid = level_2_buyerid_table.level_2_buyerid),
                    -- 本笔为倒数第二级
                    order_count_level_table.order_count_level - 2,
                    -- 第二级分销
                    2
                )
            )
        )
    )               AS detail_split_level,

    -- 是否分销末级
    IF(
        level = 0 OR level = -1,
        1, 
        0
    )               AS is_end_level,
    order.visitors  AS visitors
    -- order_split_table.orderdate
FROM 
(
    -- 分销记录
    SELECT 
        id, orderid, buyerid, sellerid, level, 
        pmode, cost_money, sale_money, member_relationship, order_time,         
        update_time, order_month, apply_did, sync_state, orderdate
    FROM s_order_split_d_i
    WHERE orderdate >= date_format(date_sub(to_date(${ds}, 'yyyyMMdd'), 15), 'yyyyMMdd')
) AS order_split_table
LEFT JOIN 
(
    -- 本订单总共分销级别
    SELECT orderid, COUNT(1) AS order_count_level 
    FROM s_order_split_d_i 
    WHERE orderdate >= date_format(date_sub(to_date(${ds}, 'yyyyMMdd'), 15), 'yyyyMMdd')
    GROUP BY orderid
) AS order_count_level_table
ON order_split_table.orderid = order_count_level_table.orderid
LEFT JOIN 
(
    -- 第二级销售者（第一级的购买者）可能无
    SELECT orderid, buyerid AS level2_sellerid 
    FROM s_order_split_d_i 
    WHERE orderdate >= date_format(date_sub(to_date(${ds}, 'yyyyMMdd'), 15), 'yyyyMMdd')
      AND level = 1
) AS level2_sellerid_table
ON order_split_table.orderid = level2_sellerid_table.orderid
LEFT JOIN 
(
    -- 倒数第二级购买者（最后一级销售者）可能无
    SELECT orderid, sellerid AS level_2_buyerid 
    FROM s_order_split_d_i 
    WHERE orderdate >= date_format(date_sub(to_date(${ds}, 'yyyyMMdd'), 15), 'yyyyMMdd')
      AND level = -1
) AS level_2_buyerid_table
ON order_split_table.orderid = level_2_buyerid_table.orderid 
LEFT JOIN
(
    SELECT ordernum, orderdate, visitors
    FROM ods_order_d_i
    WHERE orderdate >= date_format(date_sub(to_date(${ds}, 'yyyyMMdd'), 15), 'yyyyMMdd')
) AS order 
ON order_split_table.orderid = order.ordernum
LEFT JOIN 
(
    SELECT
        orderid,
        -- COUNT(*)                                        AS distribute_num,
        SUM(IF(level IN (0,1), sellerid, NULL))         AS publisher_id,
        SUM(IF(level IN (0,1), buyerid, NULL))          AS distributor_1_id,
        SUM(IF(level IN (0,1), sale_money, NULL))       AS distribute_1_price,
        SUM(IF(member_relationship=1, sellerid, NULL))  AS resource_center_supplier_id,
        SUM(IF(member_relationship=1, buyerid, NULL))   AS resource_center_purchase_id
    FROM s_order_split_d_i
    WHERE orderdate >= date_format(date_sub(to_date(${ds}, 'yyyyMMdd'), 15), 'yyyyMMdd')
    GROUP BY orderid
) AS order_split_table_2
ON order_split_table.orderid = order_split_table_2.orderid;


DROP VIEW IF EXISTS CACHE_TABLE_2;
CACHE TABLE CACHE_TABLE_2
AS
SELECT 
    id,
    orderid,
    buyerid,
    sellerid,
    level,
    pmode,
    cost_money,
    sale_money,
    member_relationship,
    order_time,
    update_time,
    order_month,
    apply_did,
    sync_state,
    distribute_num,
    publisher_id,
    distributor_1_id,
    distribute_1_price,
    resource_center_supplier_id,
    resource_center_purchase_id,
    detail_split_level,
    is_end_level,
    orderdate
FROM 
(
    -- 订单购买者非商家的，不需要补充一级
    SELECT 
        id, orderid, sellerid, buyerid, level, 
        pmode, cost_money, sale_money, member_relationship, order_time,         
        update_time, order_month, apply_did, sync_state, orderdate,

        distribute_num,
        publisher_id,
        distributor_1_id,
        distribute_1_price,
        resource_center_supplier_id,
        resource_center_purchase_id,

        detail_split_level + 1 AS detail_split_level,
        is_end_level
        -- visitors
    FROM CACHE_TABLE
    WHERE visitors != 2

    UNION ALL 

    -- 订单购买者为商家的，非末级数据需更改
    SELECT 
        id, orderid, sellerid, buyerid, level, 
        pmode, cost_money, sale_money, member_relationship, order_time,         
        update_time, order_month, apply_did, sync_state, orderdate,

        distribute_num + 1      AS distribute_num, 
        publisher_id,
        distributor_1_id,
        distribute_1_price,
        resource_center_supplier_id,
        resource_center_purchase_id,

        detail_split_level + 1  AS detail_split_level, 
        is_end_level
        -- visitors
    FROM CACHE_TABLE
    WHERE visitors = 2
      AND is_end_level != 1

    UNION ALL 

    -- 订单购买者为商家的，末级数据需更改
    SELECT 
        id, orderid, sellerid, buyerid, level, 
        pmode, cost_money, sale_money, member_relationship, order_time,         
        update_time, order_month, apply_did, sync_state, orderdate,

        distribute_num + 1      AS distribute_num, 
        publisher_id,
        distributor_1_id,
        distribute_1_price,
        resource_center_supplier_id,
        resource_center_purchase_id,

        detail_split_level + 1  AS detail_split_level,
        0                       AS is_end_level
        -- visitors
    FROM CACHE_TABLE
    WHERE visitors = 2
      AND is_end_level = 1

    -- 订单购买者为商家的，需要补一级
    UNION ALL 

    SELECT 
        id, orderid, buyerid AS sellerid, buyerid, level, 
        pmode, cost_money, sale_money, member_relationship, order_time,         
        update_time, order_month, apply_did, sync_state, orderdate,

        distribute_num + 1      AS distribute_num, 
        publisher_id,
        distributor_1_id,
        distribute_1_price,
        resource_center_supplier_id,
        resource_center_purchase_id,

        detail_split_level + 2  AS detail_split_level, 
        1                       AS is_end_level
        -- visitors
    FROM CACHE_TABLE
    WHERE visitors = 2
      AND is_end_level = 1
);


INSERT OVERWRITE TABLE ods_order_split_d_i PARTITION (orderdate)
-- 订单分销链只有一级的，一级分销商修正为销售商
SELECT 
    id,
    CACHE_TABLE_2.orderid,
    buyerid,
    CACHE_TABLE_2.sellerid,
    level,
    pmode,
    cost_money,
    sale_money,
    member_relationship,
    order_time,
    update_time,
    order_month,
    apply_did,
    sync_state,
    distribute_num,
    publisher_id,
    NVL(t1.sellerid, CACHE_TABLE_2.distributor_1_id)    AS distributor_1_id,
    distribute_1_price,
    resource_center_supplier_id,
    resource_center_purchase_id,
    detail_split_level,
    is_end_level,
    orderdate
FROM CACHE_TABLE_2
LEFT JOIN 
(
    SELECT orderid, sellerid
    FROM CACHE_TABLE_2
    WHERE detail_split_level = 1 AND is_end_level = 1
) AS t1
ON t1.orderid = CACHE_TABLE_2.orderid;

