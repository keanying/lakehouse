

CREATE TABLE IF NOT EXISTS `s_order_split_update_d_i`(
    `id`                   BIGINT         COMMENT '', 
    `orderid`              STRING         COMMENT '订单号', 
    `buyerid`              INT            COMMENT '购买用户ID', 
    `sellerid`             INT            COMMENT '供应商ID', 
    `level`                TINYINT        COMMENT '所处的级别：1=第一级，0=既是1级也是末级，-1=最末级，2=中间级别', 
    `pmode`                INT            COMMENT '该级别的支付方式', 
    `cost_money`           DECIMAL(12,0)  COMMENT '成本价（分为单位）', 
    `sale_money`           DECIMAL(12,0)  COMMENT '销售价（分为单位）', 
    `member_relationship`  TINYINT        COMMENT '订单会员关系 0:平台关系,1:资源中心关系', 
    `order_time`           INT            COMMENT '逻辑下单时间', 
    `update_time`          INT            COMMENT '订单更新时间', 
    `order_month`          TINYINT        COMMENT '逻辑下单月份', 
    `apply_did`            INT            COMMENT '原始供应商ID', 
    `sync_state`           TINYINT        COMMENT '是否同步标示 1:同步,0:无需同步'
)
COMMENT '订单分销关系表,每日更新'
PARTITIONED BY (
   `update` STRING COMMENT '更新日期'
)
STORED AS ORC;

