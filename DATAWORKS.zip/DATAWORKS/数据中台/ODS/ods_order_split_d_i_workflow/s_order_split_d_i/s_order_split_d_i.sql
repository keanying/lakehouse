CREATE TABLE IF NOT EXISTS `s_order_split_d_i`(
    `id`                   BIGINT         COMMENT '', 
    `orderid`              STRING         COMMENT '订单号', 
    `buyerid`              INT            COMMENT '购买用户ID', 
    `sellerid`             INT            COMMENT '供应商ID', 
    `level`                TINYINT        COMMENT '所处的级别：1=第一级，0=既是1级也是末级，-1=最末级，2=中间级别', 
    `pmode`                INT            COMMENT '该级别的支付方式', 
    `cost_money`           DECIMAL(12,0)  COMMENT '成本价（分为单位）', 
    `sale_money`           DECIMAL(12,0)  COMMENT '销售价（分为单位）', 
    `member_relationship`  TINYINT        COMMENT '订单会员关系 0:平台关系,1:资源中心关系', 
    `order_time`           INT            COMMENT '逻辑下单时间', 
    `update_time`          INT            COMMENT '订单更新时间', 
    `order_month`          TINYINT        COMMENT '逻辑下单月份', 
    `apply_did`            INT            COMMENT '原始供应商ID', 
    `sync_state`           TINYINT        COMMENT '是否同步标示 1:同步,0:无需同步'
)
COMMENT '订单分销关系表,每日更新'
PARTITIONED BY (
   `orderdate`              INT           COMMENT '订单下单日期'
)
STORED AS ORC;


INSERT OVERWRITE TABLE s_order_split_d_i PARTITION(orderdate)
SELECT 
    `id`, `orderid`, `buyerid`, `sellerid`, `level`, 
    `pmode`, `cost_money`, `sale_money`, `member_relationship`, `order_time`,         
    `update_time`, `order_month`, `apply_did`, `sync_state`, `orderdate`          
FROM 
(
    SELECT
        `id`, `orderid`, `buyerid`, `sellerid`, `level`,              
        `pmode`, `cost_money`, `sale_money`, `member_relationship`, `order_time`,         
        `update_time`, `order_month`, `apply_did`, `sync_state`, `orderdate`,          
        ROW_NUMBER() OVER(PARTITION BY id, orderid ORDER BY update_time DESC) AS version_num
    FROM  
    (
        --  昨日更新的，近十五日下单订单，的分销链信息
        SELECT 
            `id`, `orderid`, `buyerid`, `sellerid`, `level`,              
            `pmode`, `cost_money`, `sale_money`, `member_relationship`, `order_time`,         
            `update_time`, `order_month`, `apply_did`, `sync_state`, `orderdate`
        FROM 
        (
            -- 昨日更新的分销关系
            SELECT 
                `id`, `orderid`, `buyerid`, `sellerid`, `level`,              
                `pmode`, `cost_money`, `sale_money`, `member_relationship`, `order_time`,         
                `update_time`, `order_month`, `apply_did`, `sync_state`         
            FROM s_order_split_update_d_i
            WHERE `update`=${ds}
        ) AS update_split_table
        INNER JOIN 
        (
            -- 获取最近十五日内订单的下单时间
            SELECT ordernum, orderdate 
            FROM ods_order_d_i
            WHERE orderdate >= date_format(date_sub(to_date(${ds}, 'yyyyMMdd'), 15), 'yyyyMMdd')
        ) AS order_table
        ON update_split_table.orderid = order_table.ordernum

        UNION ALL 

        -- 最近十五日分销关系
        SELECT 
            `id`, `orderid`, `buyerid`, `sellerid`, `level`,              
            `pmode`, `cost_money`, `sale_money`, `member_relationship`, `order_time`,         
            `update_time`, `order_month`, `apply_did`, `sync_state`, `orderdate`   
        FROM s_order_split_d_i 
        WHERE orderdate >= date_format(date_sub(to_date(${ds}, 'yyyyMMdd'), 15), 'yyyyMMdd')
    ) AS t1
) AS t2
WHERE t2.version_num = 1 