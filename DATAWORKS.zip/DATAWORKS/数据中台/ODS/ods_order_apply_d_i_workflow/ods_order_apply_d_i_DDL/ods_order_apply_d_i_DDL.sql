CREATE TABLE IF NOT EXISTS `s_order_apply_update_d_i`
(
    `id`            BIGINT          COMMENT '表ID', 
    `orderid`       STRING          COMMENT '订单号', 
    `apply_id`      INT             COMMENT '顶级供应商ID', 
    `aprice`        DECIMAL(12,0)   COMMENT '供应价', 
    `lprice`        DECIMAL(12,0)   COMMENT '零售价表', 
    `counter_price` DECIMAL(12,0)   COMMENT '下单时的门市价', 
    `sale_price`    INT             COMMENT '实际售价', 
    `pid`           INT             COMMENT '产品ID', 
    `refund_num`    BIGINT          COMMENT '退票数', 
    `verified_num`  BIGINT          COMMENT '已验证票数', 
    `origin_num`    BIGINT          COMMENT '原始票数', 
    `playtime`      TIMESTAMP       COMMENT '游玩时间（弃用）', 
    `addtime`       STRING          COMMENT '添加时间', 
    `flag`          TINYINT         COMMENT '处理标识：1=已经处理，0=没有', 
    `current_num`   SMALLINT        COMMENT '记录当前总的票数', 
    `order_time`    INT             COMMENT '逻辑下单时间', 
    `update_time`   INT             COMMENT '订单更新时间', 
    `order_month`   TINYINT         COMMENT '逻辑下单月份', 
    `sync_state`    TINYINT         COMMENT '是否同步标示 1:同步,0:无需同步', 
    `can_take`      SMALLINT        COMMENT '可取票数', 
    `can_refund`    SMALLINT        COMMENT '可退票数'
)
COMMENT '订单原始数据表昨日更新数据'
PARTITIONED BY (`update`    STRING COMMENT '更新日期')
STORED AS ORC;


CREATE TABLE IF NOT EXISTS `ods_order_apply_d_i`
(
    `id`            BIGINT          COMMENT '表ID', 
    `orderid`       STRING          COMMENT '订单号', 
    `apply_id`      INT             COMMENT '顶级供应商ID', 
    `aprice`        DECIMAL(12,0)   COMMENT '供应价', 
    `lprice`        DECIMAL(12,0)   COMMENT '零售价表', 
    `counter_price` DECIMAL(12,0)   COMMENT '下单时的门市价', 
    `sale_price`    INT             COMMENT '实际售价', 
    `pid`           INT             COMMENT '产品ID', 
    `refund_num`    BIGINT          COMMENT '退票数', 
    `verified_num`  BIGINT          COMMENT '已验证票数', 
    `origin_num`    BIGINT          COMMENT '原始票数', 
    `playtime`      TIMESTAMP       COMMENT '游玩时间（弃用）', 
    `addtime`       STRING          COMMENT '添加时间', 
    `flag`          TINYINT         COMMENT '处理标识：1=已经处理，0=没有', 
    `current_num`   SMALLINT        COMMENT '记录当前总的票数', 
    `order_time`    INT             COMMENT '逻辑下单时间', 
    `update_time`   INT             COMMENT '订单更新时间', 
    `order_month`   TINYINT         COMMENT '逻辑下单月份', 
    `sync_state`    TINYINT         COMMENT '是否同步标示 1:同步,0:无需同步', 
    `can_take`      SMALLINT        COMMENT '可取票数', 
    `can_refund`    SMALLINT        COMMENT '可退票数'
) COMMENT '订单原始数据表, 每日增量数据'
PARTITIONED BY (
    `orderdate`     INT             COMMENT '更新日期'
)
STORED AS ORC;

