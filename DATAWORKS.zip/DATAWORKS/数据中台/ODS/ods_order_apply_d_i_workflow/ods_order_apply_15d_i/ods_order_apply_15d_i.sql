INSERT OVERWRITE TABLE ods_order_apply_d_i PARTITION(orderdate)
SELECT 
    `id`, `orderid`, `apply_id`, `aprice`, `lprice`,       
    `counter_price`, `sale_price`, `pid`, `refund_num`, `verified_num`, 
    `origin_num`, `playtime`, `addtime`, `flag`, `current_num`, 
    `order_time`, `update_time`, `order_month`, `sync_state`, `can_take`, 
    `can_refund`, `orderdate`        
FROM 
(
    SELECT
        `id`, `orderid`, `apply_id`, `aprice`, `lprice`,       
        `counter_price`, `sale_price`, `pid`, `refund_num`, `verified_num`, 
        `origin_num`, `playtime`, `addtime`, `flag`, `current_num`, 
        `order_time`, `update_time`, `order_month`, `sync_state`, `can_take`, 
        `can_refund`, `orderdate`, ROW_NUMBER() OVER(PARTITION BY orderid ORDER BY update_time DESC) AS version_num
    FROM  
    (
        --  昨日更新的，近十五日下单订单，的apply信息
        SELECT 
            `id`, `orderid`, `apply_id`, `aprice`, `lprice`,       
            `counter_price`, `sale_price`, `pid`, `refund_num`, `verified_num`, 
            `origin_num`, `playtime`, `addtime`, `flag`, `current_num`, 
            `order_time`, `update_time`, `order_month`, `sync_state`, `can_take`, 
            `can_refund`, `orderdate`
        FROM 
        (
            -- 昨日更新的apply
            SELECT 
                `id`, `orderid`, `apply_id`, `aprice`, `lprice`,       
                `counter_price`, `sale_price`, `pid`, `refund_num`, `verified_num`, 
                `origin_num`, `playtime`, `addtime`, `flag`, `current_num`, 
                `order_time`, `update_time`, `order_month`, `sync_state`, `can_take`, 
                `can_refund`        
            FROM s_order_apply_update_d_i
            WHERE `update`=${ds}
        ) AS update_apply_table
        INNER JOIN 
        (
            -- 获取最近十五日内订单的下单时间
            SELECT ordernum, orderdate 
            FROM ods_order_d_i
            WHERE orderdate >= date_format(date_sub(to_date(${ds}, 'yyyyMMdd'), 15), 'yyyyMMdd')
        ) AS order_table
        ON update_apply_table.orderid = order_table.ordernum

        UNION ALL 

        -- 最近十五日
        SELECT 
            `id`, `orderid`, `apply_id`, `aprice`, `lprice`,       
            `counter_price`, `sale_price`, `pid`, `refund_num`, `verified_num`, 
            `origin_num`, `playtime`, `addtime`, `flag`, `current_num`, 
            `order_time`, `update_time`, `order_month`, `sync_state`, `can_take`, 
            `can_refund`, `orderdate` 
        FROM ods_order_apply_d_i 
        WHERE orderdate >= date_format(date_sub(to_date(${ds}, 'yyyyMMdd'), 15), 'yyyyMMdd')
    ) AS t1
) AS t2
WHERE t2.version_num = 1 