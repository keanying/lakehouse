--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-12 15:15:44
--EMR任务只能运行在独享资源组上
--********************************************************************--
-- desc 应用模块开通情况

-- drop table if exists dwd_user_module_d_f;
-- alter table dwd_user_module_d_f         DROP IF EXISTS PARTITION (pt=${before6day});


CREATE table if not EXISTS dwd_user_module_d_f(
    stat_date               STRING  COMMENT '统计日期',
    dw_ins_time             STRING  COMMENT '插入时间',

    user_id                 int     COMMENT '用户id',
    module_id               int     COMMENT '应用模块id',
    module_name             string  COMMENT '应用模块名称',
    contract_no             string  comment '合同编号',
    out_trade_no            STRING  COMMENT '支付流水',
    sign_time               STRING  COMMENT '签约时间',
    sale_man_id             STRING  COMMENT '签单人id',
    sale_man_name           STRING  COMMENT '签单人姓名',
    sale_man_department     STRING  COMMENT '签单人部门',
    
    buy_no                  int     COMMENT '购买序号',

    open_type               int     COMMENT '开通类型：0 自助,1管理员',
    module_price            int     COMMENT '模块单价（分）',
    module_pay_amount       int     COMMENT '模块支付金额（分）',
    module_negotiated_price    int     COMMENT '模块开票金额（分）',
    module_performance_amount  int     COMMENT '模块业绩金额（分）',
    module_actual_amount       int     COMMENT '模块终止时实际消费金额（分）',

    add_time                string  COMMENT '开通日期',
    begin_time              STRING  COMMENT '模块开始日期',
    end_time                STRING  COMMENT '模块结束日期',
    stop_time               string  COMMENT '模块终止日期',
    stop_type               STRING  COMMENT '终止类型',

    period_days             int     COMMENT '期限（天）',
    module_status           string  comment '模块状态   过期/当前/未到',
    remark                  string  COMMENT '备注',
    back_detail             string  comment '回款明细'

)COMMENT "商户开通表" PARTITIONED  BY (
    pt STRING   
)STORED AS ORC;


-- 开通应用模块
INSERT OVERWRITE TABLE dwd_user_module_d_f PARTITION (pt="${ds}")
select 
    ${ds}                    as stat_date,
    current_date()                           as dw_ins_time,

    mo.member_id                             as user_id,
    mo.module_id                             as module_id,
    module.name                              as module_name,
    me.contract_no                           as contract_no,
    me.out_trade_no                          as out_trade_no,
    from_unixtime(me.create_time)            as sign_time,
    me.saleman                               as sale_man_id,
    u1.plat_staff_name                       as sale_man_name,
    u1.plat_staff_department                 as sale_man_department,

    row_number() OVER  (order by mo.module_id,mo.add_time)           as buy_no,
 
    pl.type                                  as open_type,
    mo.module_price                          as module_price,
    INT(substr(me.details,locate('receipt',me.details)+10,locate('agree',me.details)-locate('receipt',me.details)-13))                         as module_pay_mount,
    INT(substr(me.details,locate('agree',me.details)+8,locate('achievement_money',me.details)-locate('agree',me.details)-11))                  as module_negotiated_price,
    INT(substr(me.details,locate('achievement_money',me.details)+20,locate('real_money',me.details)-locate('achievement_money',me.details)-23))     as module_performance_amount,
    INT(substr(me.details,locate('real_money',me.details)+13,length(me.details)-locate('real_money',me.details)-14))                                as module_actual_amount,

    if(me.sign_time is not null and me.sign_time>0,from_unixtime(me.sign_time), mo.add_time)                                                    as add_time,
    coalesce(from_unixtime(substr(me.time_details,locate('start_time',me.time_details)+13,10)),mo.begin_time)                   as begin_time,
    coalesce(from_unixtime(substr(me.time_details,locate('end_time',me.time_details)+11,10)),from_unixtime(pl.expire_time))     as end_time,
    from_unixtime(if(me.stop_type=1,substr(me.time_details,locate('stop_time',me.time_details)+11,10),substr(me.time_details,locate('end_time',me.time_details)+11,10))) as stop_time,
    case me.stop_type
        WHEN 0 then '正常'
        WHEN 1 then '作废'
        WHEN 2 then '提前终止'
    end   stop_type,

    mo.period_days                           as period_days,
    if(CURRENT_DATE> mo.end_time,'过期',if(CURRENT_DATE>=mo.begin_time,'当前','未到')) as module_status,
    mo.remark                                as remark,
    me.repayment_record                      as back_detail

from  (select pl.member_id                 as member_id,
              pl.module_id                 as module_id,
              from_unixtime(pl.add_time)   as add_time,
              from_unixtime(pl.add_time)   as begin_time,
              date_add(from_unixtime(pl.add_time),if(price.mode=1,365,if(price.mode=2,90,30)))  as end_time,
              if(price.mode=1,365,if(price.mode=2,90,30))                                       as period_days,

              pl.remarks                   as remark,
              price.fee                    as module_price,

              pl.out_trade_no              as out_trade_no
       from (select * from ods_pft001_pft_module_used_log_d_f 
             where pt="${ds}" and type=1  and status not in (1,3,7)   --功能模块 非未支付/支付失败/管理员关闭
            ) pl
       left join (select * from ods_pft001_pft_module_price_d_f
             where pt="${ds}"  and type=1              --功能模块 
            )  price  on price.id=pl.price_id
     ) mo
left join (select * from ods_pft001_pft_module_d_f
           where pt="${ds}"  
          )  module  on module.id=mo.module_id
left join  (select * from ods_pft001_pft_module_used_d_f 
            where pt="${ds}" 
           ) pl on pl.member_id=mo.member_id and pl.module_id=mo.module_id -- and from_unixtime(pl.expire_time)=mo.end_time
left join  (select * from ods_pft_module_used_ext_d_f
            where pt="${ds}")   me on me.out_trade_no=mo.out_trade_no and me.module_id=mo.module_id    
left join (select plat_staff_id,plat_staff_name,plat_staff_department from dim_plat_staff_d_f where pt='${ds}') u1 on u1.plat_staff_id=me.saleman
join (select user_id,user_type from dim_user_d_f where pt="${ds}" and user_type in ('供应商','分销商')) m on mo.member_id=m.user_id
;
