--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-12 14:51:12
--EMR任务只能运行在独享资源组上
--********************************************************************--


CREATE table if not EXISTS dwd_user_package_d_f(
    stat_date                   STRING  COMMENT '统计日期',
    dw_ins_time                 STRING  COMMENT '插入时间',

    id                          int     COMMENT '套餐表id',
    package_open_id             int     COMMENT '用户套餐开通id',
    user_id                     int     COMMENT '用户id',
    package_no                  int     COMMENT '套餐购买序号',
    package_id                  int     COMMENT '套餐id',
    package_role                string  COMMENT '套餐角色,供应商/分销商',
    package_name                string  COMMENT '套餐名称',
    package_price               int     COMMENT '套餐单价（分）',
    package_negotiated_price    int     COMMENT '套餐协议价（分）',
    package_pay_amount          int     COMMENT '套餐支付金额（分）',
    package_achievement         int     COMMENT '套餐业绩金额（分）',

    user_contract_model         string  COMMENT '合作方式',
    add_time                    string  COMMENT '开通日期',
    begin_time                  STRING  COMMENT '套餐开始日期',
    end_time                    STRING  COMMENT '套餐结束日期',
    period_days                 int     COMMENT '套餐期限（天）',
    package_status              string  comment '套餐状态   过期/当前/未到',
    remark                      string  COMMENT '备注',
    package_classify_name       string  comment '套餐组名称',

    contract_no                 string  comment '合同编号',
    repayment_record            string  COMMENT '回款记录',
    stop_type                   string  comment '终止类型',

    stop_time                   string  comment '终止时间',
    cooperation_mode            string  comment '合作模式',
    open_type                   int     comment '开通类型id',
    open_type_name              string  comment '开通类型名称',
    open_type_catalogue         string  comment '开通类型大类',
    sign_time                   string  comment '合同生效时间',

    sale_man_id                 int     comment '签单人平台账户id',
    sale_man_name               string  comment '签单人姓名',
    sale_man_department         string  comment '签单人部门',
    customer_service_id         int     comment '客户成功经理平台账户id',
    customer_service_name       string  comment '客户成功经理姓名',
    customer_service_department string  comment '客户成功经理部门',
    back_detail                 string  comment '回款明细'


)COMMENT "商户套餐开通表" PARTITIONED  BY (
    pt STRING   
)STORED AS ORC;


-- 签单人、客服部门为12301平台归属部门
-- 过滤 作废的套餐
INSERT OVERWRITE TABLE dwd_user_package_d_f PARTITION (pt="${ds}")
select 
    ${ds}                   as stat_date,
    current_date()                          as dw_ins_time,

    pack.id                                 as id,
    row_number() OVER  (order by pack.end_time,pack.begin_time )             as package_open_id,
    pack.user_id                            as user_id,
    row_number() OVER (partition by pack.user_id order by pack.begin_time )  as package_no,
    pack.package_id                         as package_id,
    pack.package_role                       as package_role,
    pack.package_name                       as package_name,
    pack.package_price                      as package_price,

    -- 修改过的记录金额会用引号括起来
    INT(if(pack.package_negotiated_price like '%"%',substr(pack.package_negotiated_price,2,length(pack.package_negotiated_price)-2),pack.package_negotiated_price))  as package_negotiated_price,
    INT(if(pack.package_pay_mount like '%"%',substr(pack.package_pay_mount,2,length(pack.package_pay_mount)-2),pack.package_pay_mount))                              as package_pay_amount,
    -- if(pack.package_achievement like '%"%',substr(pack.package_achievement,2,length(pack.package_achievement)-2),pack.package_achievement)                      as package_achievement,
    pack.package_achievement                      as package_achievement,
    
    if(isnull(ple.cooperation_mode) ,pack.user_contract_model,ple.cooperation_mode) as user_contract_model,
    pack.add_time                           as add_time,
    pack.begin_time                         as begin_time,
    pack.end_time                           as end_time,
    pack.period_days                        as period_days,
    pack.package_status                     as package_status,
    pack.remark                             as remark,

    --套餐组名称
    pc.package_classify_name               as package_classify_name,

    -- 套餐情况扩展
    ple.contract_no,
    ple.repayment_record,
    case ple.stop_type
         when 0 THEN '正常'
         when 1 THEN '作废'
         when 2 THEN '提前终止'
         else '正常'
    END                                 as stop_type,
    from_unixtime(substr(ple.time_details,locate('stop_time',ple.time_details)+11,10)) as stop_time,
    case ple.cooperation_mode
       when 1 then '套餐'
       when 2 then '项目'
       when 3 then '订单预存'
       else '未知'
    end                                 as cooperation_mode,
    ple.open_type                       as open_type,
    ot.type_name                        as open_type_name,
    ot.catalogue                        as open_type_catalogue,
    if(ple.sign_time is null ,pack.add_time,from_unixtime(ple.sign_time))        as sign_time,

    pack.saleman                        as sale_man_id,
    pack.saleman_name                   as sale_man_name,
    pack.saleman_department             as sale_man_department,
    pack.customer_service               as customer_service_id,
    pack.customer_service_name          as customer_service_name,
    pack.customer_service_department    as customer_service_department,
    ple.repayment_record                as back_detail

from 
    (select  
            pl.id,
            pl.member_id                  as user_id,
            pl.package_id                 as package_id,
            if(p.role=0,'供应商','分销商') as package_role,
            p.name                        as package_name,
            p.fee                         as package_price,
            substr(substr(pl.details,locate('agree',pl.details)+7,200),1,locate(",",substr(pl.details,locate('agree',pl.details)+7,200))-1)        as package_negotiated_price,
            substr( pl.details,12,locate(',', pl.details,1)-12)                         as package_pay_mount,
            INT(if(pl.details like '%achievement_money%',substr(pl.details,locate('achievement_money', pl.details)+19,length(pl.details)-locate('achievement_money', pl.details)-19),0))       as package_achievement,

            u.user_contract_model         as user_contract_model,
            from_unixtime(pl.add_time)    as add_time,
            from_unixtime(pl.begin_time)  as begin_time,
            from_unixtime(pl.end_time)    as end_time,
            -- 计算period_days（在SELECT中定义）
            datediff(from_unixtime(pl.end_time),from_unixtime(pl.begin_time)) as period_days,
            if(CURRENT_DATE> FROM_UNIXTIME(cast(substr(pl.end_time,1,10) as bigint),'yyyy-MM-dd'),'过期',if(CURRENT_DATE>=FROM_UNIXTIME(cast(substr(pl.begin_time,1,10) as bigint),'yyyy-MM-dd'),'当前','未到')) as package_status,
            pl.remarks                    as remark,
            pl.saleman                    as saleman,
            u1.plat_staff_name            as saleman_name,
            u1.plat_staff_department      as saleman_department,
            pl.customer_service           as customer_service,
            u2.plat_staff_name            as customer_service_name,
            u2.plat_staff_department      as customer_service_department
    -- 关键修正：将计算逻辑移到子查询中，先计算period_days再筛选
    from (
        -- 内层子查询：先计算period_days
        select 
            pl.*,
            datediff(from_unixtime(pl.end_time), from_unixtime(pl.begin_time)) as period_days  -- 提前计算
        from (select * from ods_pft001_pft_module_package_log_d_f 
              where pt='${ds}' and is_update<>2 
              ) pl
    ) pl  -- 外层引用内层子查询的period_days
    join (select  member_id,begin_time,max(id) id
                from ods_pft001_pft_module_package_log_d_f 
                where pt='${ds}' and is_update<>2
                group by member_id,begin_time
                ) p2 on pl.id=p2.id
    left join (select id,name,fee,role from ods_pft001_pft_module_package_d_f where pt='${ds}') p on p.id=pl.package_id
    left join (select user_id,user_contract_model from dim_user_d_f where pt='${ds}') u on u.user_id=pl.member_id
    left join (select plat_staff_id,plat_staff_name,plat_staff_department from dim_plat_staff_d_f where pt='${ds}') u1 on u1.plat_staff_id=pl.saleman
    left join (select plat_staff_id,plat_staff_name,plat_staff_department from dim_plat_staff_d_f where pt='${ds}') u2 on u2.plat_staff_id=pl.customer_service
    left join (select user_id,start_time from ods_bi_business_package_history_d_f 
               where pt='${ds}'  and add_time<='2017-07-18 00:00:00') his on his.user_id=pl.member_id and his.start_time=to_date(from_unixtime(pl.begin_time))
    -- 筛选条件使用内层子查询计算的period_days
    where  isnull(his.user_id)  and pl.period_days>=25  -- 此处修改为pl.period_days

    union all

    select 
           0 as id,
           user_id user_id,
           if(cooper_price<=6800,66,if(cooper_price<=9800,67,69))      as package_id,
           '供应商'                                                                     as package_role,
           if(cooper_price<=6800,'标准版',if(cooper_price<=9800,'高级版','旗舰版'))      as package_name,
           if(cooper_price<=6800,680000,if(cooper_price<=9800,980000,1980000))         as package_price,
           cooper_price*100                                                            as package_negotiated_price,
           cooper_price*100                                                            as package_pay_mount,
           cooper_price*100                                                            as package_achievement,

           cooperation                                                                 as user_contract_model,
           add_time                                                                    as add_time,
           start_time                                                                  as begin_time,
           end_time                                                                    as end_time,
           cooper_month*30                                                             as period_days,
           if(CURRENT_DATE> end_time,'过期',if(CURRENT_DATE>=start_time,'当前','未到')) as package_status,
           remark                                                                      as remark,
           null                                                                        as saleman,
           null                                                                        as saleman_name,
           null                                                                        as saleman_department,
           null                                                                        as customer_service,
           null                                                                        as customer_service_name,
           null                                                                        as customer_service_department
    from ods_bi_business_package_history_d_f 
    where pt='${ds}'  and add_time<='2017-07-18 00:00:00' and end_time<'2020-01-01'
    ) pack
-- 后续JOIN逻辑保持不变，但需修正ple的cooperation_mode CASE逻辑
left join (select package_classify_name,package_id from dim_pft_module_package_classify_d_f where pt='${ds}') pc on pack.package_id=pc.package_id
LEFT JOIN (select package_log_id, open_type,contract_no,repayment_record,stop_type,time_details,sign_time,
                  case cooperation_mode
                       when 1   then  '套餐' 
                       when 2   then  '项目' 
                       when 3   then  '订单预存'  -- 修正：原SQL此处重复when 1，导致逻辑错误
                       else '未知'
                  end  cooperation_mode
           from ods_pft001_pft_module_package_log_ext_d_f  where pt='${ds}') ple on pack.id=ple.package_log_id
left join ods_package_open_type_d_f ot on ot.package_open_type_id=ple.open_type and ot.pt='${ds}'
;

-- select user_id,begin_time,count(*) num
-- from dwd_user_package_d_f
-- where pt="${ds}" 
-- group by user_id,begin_time
-- having num>1


-- select user_id,id,sign_time,begin_time,end_time,package_pay_amount/100,package_achievement/100,package_negotiated_price/100,sale_man_id,sale_man_name,sale_man_department
-- from dwd_user_package_d_f
-- where pt="${ds}"  -- and sign_time>'2020-12-01' 
--       and user_id=716755
;

-- select user_id,sign_time,begin_time,end_time,package_pay_amount
-- from dwd_user_package_d_f
-- where pt="${ds}"  and user_id=5002428


