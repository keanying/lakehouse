--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-05 14:33:41
--EMR任务只能运行在独享资源组上
--********************************************************************--
-- desc 商户登录明细

create table if NOT EXISTS  dwd_company_login_d_f(
    stat_date               STRING COMMENT '统计日期',
    dw_ins_time             STRING COMMENT '插入时间',

    user_id                 int COMMENT '商户id',
    login_time              string   comment '登录日期',
    login_source            int comment '登录渠道，1=平台，2=终端设备，3=微信端，4=手机验证码登录 '
    
)PARTITIONED BY(
    pt STRING  
 )STORED AS ORC;


-- 仅筛选商户
INSERT OVERWRITE  TABLE dwd_company_login_d_f PARTITION (pt="${ds}") 
SELECT 
        ${ds}               as stat_date,
        current_date()                      as dw_ins_time,

        user_id                             as user_id,
        login_time                          as login_time,
        login_source                        as login_source

from ods_pft_login_log_d_f
where pt='pt'
-- from data_middle_bi.s_pft_logging_pft_login_log_d_f
-- where pt='${bdp.system.bizdate}'
;


