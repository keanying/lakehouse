--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-13 16:13:57
--EMR任务只能运行在独享资源组上
--********************************************************************--

-- desc 预订单游客信息宽表， 增量任务

-- 1. 每个游客的身份证和手机号码所属的地区信息
-- 2. 每个订单取票人所属的地区信息

DROP VIEW IF EXISTS dim_phone_city;
CACHE TABLE dim_phone_city 
AS 
-- 手机号码对应地区维度表
SELECT phone_number, country_name, province_name, city_name, district_name
FROM dim_phone_city_d_f
WHERE pt=FROM_UNIXTIME(UNIX_TIMESTAMP(DATE_SUB(CURRENT_DATE, 1)), 'yyyyMMdd');

DROP VIEW IF EXISTS dim_idcard_city;
CACHE TABLE dim_idcard_city 
AS
-- 身份证信息对应地区维度表
SELECT idcard, zip_code, province_name, city_name, district_name, country_name
FROM dim_idcard_city_d_f
WHERE pt=FROM_UNIXTIME(UNIX_TIMESTAMP(DATE_SUB(CURRENT_DATE, 1)), 'yyyyMMdd');

DROP VIEW IF EXISTS order_tourist;
CACHE TABLE order_tourist 
AS
-- 游客信息流水表, 需游客身份证和手机
SELECT  orderid,
		IF((voucher_type=1 AND ISNOTNULL(idcard) AND idcard != ''), idcard, '') AS idcard,
		mobile	AS phone
FROM s_tourist_info_d_i
WHERE orderdate = '${ds}';

DROP VIEW IF EXISTS order_aids;
CACHE TABLE order_aids 
AS
-- 分销宽表，拿到分销商id及支付日期
SELECT  order_id,
		pay_date,
		aids_seller_id,
		ticket_taker_age,
		ticket_taker_sex,
		ticket_taker_province,
		ticket_taker_city,
		ticket_taker_country
FROM dwd_order_split_d_i
WHERE orderdate >= "${ds}" - 20
	AND pay_date = '${ds}';


INSERT OVERWRITE TABLE dwd_order_tourist_info_d_i PARTITION(`pay_date`)
SELECT 
	order_aids.aids_seller_id		AS `sid`,
	order_tourist.orderid			AS `orderid`,

	dim_idcard_city.country_name	AS `idcard_country_name`,
	dim_idcard_city.province_name	AS `idcard_province_name`,
	dim_idcard_city.city_name		AS `idcard_city_name`,
	dim_idcard_city.district_name	AS `idcard_district_name`,

	IF (ISNOTNULL(order_tourist.idcard) AND order_tourist.idcard != '',
        IF (SUBSTR(order_tourist.idcard, 17, 1) % 2 = 0,
            "女",
            "男"
		),
		-1
	)								AS `idcard_sex`,
	if (ISNOTNULL(order_tourist.idcard),
        FLOOR(YEAR(CURRENT_DATE()) - SUBSTR(order_tourist.idcard, 7, 4)),
        -1 
	)								AS `idcard_age`,

	dim_phone_city.country_name		AS `phone_country_name`,
	dim_phone_city.province_name	AS `phone_province_name`,
	dim_phone_city.city_name		AS `phone_city_name`,
	dim_phone_city.district_name	AS `phone_district_name`,

	order_aids.ticket_taker_age		AS `ticket_taker_age`,
	order_aids.ticket_taker_sex		AS `ticket_taker_sex`,
	order_aids.ticket_taker_province	AS `ticket_taker_province`,
	order_aids.ticket_taker_city	AS `ticket_taker_city`,
	order_aids.ticket_taker_country	AS `ticket_taker_country`,
	
	order_aids.pay_date				AS `pay_date`
FROM order_tourist
LEFT JOIN  order_aids
ON order_tourist.orderid = order_aids.order_id
LEFT JOIN  dim_idcard_city
ON SUBSTR(order_tourist.idcard, 0, 6) = dim_idcard_city.idcard
LEFT JOIN  dim_phone_city
ON SUBSTR(order_tourist.phone, 0, 7) = dim_phone_city.phone_number;



