--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-13 16:27:39
--EMR任务只能运行在独享资源组上
--********************************************************************--
-- desc 预订单游客信息宽表， 全量任务，需要时手动运行一次

-- 1. 每个游客的身份证和手机号码所属的地区信息
-- 2. 每个订单取票人所属的地区信息

CREATE TABLE IF NOT EXISTS dwd_order_tourist_info_d_i(
    `sid`           		STRING  COMMENT '商户ID',
	`orderid`				STRING	COMMENT '订单号',

	`idcard_country_name`	STRING	COMMENT '游客身份证国家名称',
	`idcard_province_name`	STRING	COMMENT '游客身份证省名称',
	`idcard_city_name`		STRING	COMMENT '游客身份证市名称',
	`idcard_district_name`	STRING	COMMENT '游客身份证区县名称',
	`idcard_sex`           	STRING  COMMENT '游客身份证性别',
    `idcard_age`           	INT  	COMMENT '游客身份证年龄',

	`phone_country_name`	STRING	COMMENT '游客手机号码国家名称',
	`phone_province_name`	STRING	COMMENT '游客手机号码省名称',
	`phone_city_name`		STRING	COMMENT '游客手机号码市名称',
	`phone_district_name`	STRING	COMMENT '游客手机号码区县名称',

	`ticket_taker_age`		STRING	COMMENT '取票人年龄',
	`ticket_taker_sex`		STRING	COMMENT '取票人性别',
	`ticket_taker_province` STRING	COMMENT '取票人所在省',
	`ticket_taker_city`		STRING	COMMENT '取票人所在市',
	`ticket_taker_country`	STRING	COMMENT '取票人所在区'
	
)COMMENT '预订单游客信息宽表' PARTITIONED BY(
    `pay_date`				STRING  COMMENT '预定时间'
)STORED AS ORC;


INSERT OVERWRITE TABLE dwd_order_tourist_info_d_i PARTITION(`pay_date`)
SELECT 
	order_aids.aids_seller_id		AS `sid`,
	order_tourist.orderid			AS `orderid`,

	dim_idcard_city.country_name	AS `idcard_country_name`,
	dim_idcard_city.province_name	AS `idcard_province_name`,
	dim_idcard_city.city_name		AS `idcard_city_name`,
	dim_idcard_city.district_name	AS `idcard_district_name`,

	IF (ISNOTNULL(order_tourist.idcard) AND order_tourist.idcard != '',
        IF (SUBSTR(order_tourist.idcard, 17, 1) % 2 = 0,
            "女",
            "男"
		),
		-1
	)								AS `idcard_sex`,
	if (ISNOTNULL(order_tourist.idcard),
        FLOOR(YEAR(CURRENT_DATE()) - SUBSTR(order_tourist.idcard, 7, 4)),
        -1 
	)								AS `idcard_age`,

	dim_phone_city.country_name		AS `phone_country_name`,
	dim_phone_city.province_name	AS `phone_province_name`,
	dim_phone_city.city_name		AS `phone_city_name`,
	dim_phone_city.district_name	AS `phone_district_name`,

	order_aids.ticket_taker_age		AS `ticket_taker_age`,
	order_aids.ticket_taker_sex		AS `ticket_taker_sex`,
	order_aids.ticket_taker_province	AS `ticket_taker_province`,
	order_aids.ticket_taker_city	AS `ticket_taker_city`,
	order_aids.ticket_taker_country	AS `ticket_taker_country`,
	
	order_aids.pay_date				AS `pay_date`
FROM 
(
	-- 游客信息流水表, 需游客身份证和手机
	SELECT
		orderid,
		IF((voucher_type=1 AND ISNOTNULL(idcard) AND idcard != ''), idcard, '') AS idcard,
		mobile	AS phone
	FROM s_tourist_info_d_i
	WHERE orderdate >= '2022-01-01'
) AS order_tourist
LEFT JOIN 
(
	-- 分销宽表，拿到分销商id及支付日期
	SELECT 
		order_id,
		pay_date,
		aids_seller_id,
		ticket_taker_age,
		ticket_taker_sex,
		ticket_taker_province,
		ticket_taker_city,
		ticket_taker_country
	FROM dwd_order_aids_d_f
	WHERE pt='${ds}'
	  AND pay_date >= '20220101'
) AS order_aids
ON order_tourist.orderid = order_aids.order_id
LEFT JOIN 
(
	-- 身份证信息对应地区维度表
	SELECT 
		idcard,
		zip_code,
		province_name,
		city_name,
		district_name,
		country_name
	FROM dim_idcard_city_d_f
	WHERE pt='${ds}'
) AS dim_idcard_city
ON SUBSTR(order_tourist.idcard, 0, 6) = dim_idcard_city.idcard
LEFT JOIN 
(
	-- 手机号码对应地区维度表
	SELECT phone_number, country_name, province_name, city_name, district_name
	FROM dim_phone_city_d_f
	WHERE pt='${ds}'
) AS dim_phone_city
ON SUBSTR(order_tourist.phone, 0, 7) = dim_phone_city.phone_number


