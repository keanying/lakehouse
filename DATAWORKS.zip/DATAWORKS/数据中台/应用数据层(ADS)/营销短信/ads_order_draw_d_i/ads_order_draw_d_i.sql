--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-12 17:16:34
--EMR任务只能运行在独享资源组上
--********************************************************************--


-- desc 营销短信

CREATE TABLE IF NOT EXISTS ads_order_draw_d_i(
    stat_date               STRING COMMENT '统计日期',
    dw_ins_time             STRING COMMENT '插入时间',
    order_id                STRING COMMENT '订单号',

    order_status_code       INT     COMMENT '订单状态编码',
    order_status            STRING  COMMENT '订单状态',
    booking_time            STRING  COMMENT '下单时间',
    vertify_time            STRING  COMMENT '验证时间',

    booking_channel         STRING  COMMENT '销售渠道ID',
    booking_channel_name    STRING  COMMENT '销售渠道名称',

    booking_price           INT     COMMENT '售价',
    ticket_num              INT     COMMENT '票数',
    order_pay_amount        BIGINT  COMMENT '订单支付金额',
    
    ticket_taker_name       STRING  COMMENT '取票人姓名', 
    ticket_taker_mobile     STRING  COMMENT '取票人手机号',
    ticket_taker_idcard     STRING  COMMENT '取票人身份证', 
    ticket_taker_age        INT     COMMENT '取票人年龄',
    ticket_taker_sex        STRING  COMMENT '取票人性别', 
    ticket_taker_province   STRING  COMMENT '取票人所在省',
    ticket_taker_city       STRING  COMMENT '取票人所在市',

    is_around               INT     COMMENT "是否周边游 0=周边游，1=国内游",

    land_type               STRING  COMMENT '景区类型代码：A景区B线路C酒店F套票G餐饮I年卡H演出J特产K计时产品',
    land_type_name          STRING  COMMENT '景区类型：A景区B线路C酒店F套票G餐饮I年卡H演出J特产K计时产品',
    product_id              INT     COMMENT '产品id',
    ticket_id               INT     COMMENT '票id',
    ticket_fullname         STRING  COMMENT '票名',
    land_id                 INT     COMMENT '景区id',
    land_name               STRING  COMMENT "景区名",
    land_publisher_id       INT     COMMENT '景区发布商id',
    land_publisher_name     STRING  COMMENT "景区名"  ,

    booking_num             INT    COMMENT '预定数'
)COMMENT'营销短信游客信息'PARTITIONED BY(
    pt STRING  
 )STORED AS ORC;

-- 过滤手机号为空
INSERT OVERWRITE TABLE ads_order_draw_d_i PARTITION (pt="${ds}") 
SELECT 
    '${ds}'     AS stat_date,
    current_date                AS dw_ins_time,
    order_id,

    order_status_code,
    order_status,
    booking_time,
    verify_time,

    booking_channel,
    booking_channel_name,

    booking_price,
    ticket_num,
    order_pay_amount,
    
    ticket_taker_name, 
    ticket_taker_mobile,
    ticket_taker_idcard, 
    ticket_taker_age,
    ticket_taker_sex, 
    ticket_taker_province,
    ticket_taker_city,

    is_around,

    land_type,
    land_type_name,
    product_id,
    ticket_id,
    ticket_fullname,
    land_id,
    land_name,
    land_publisher_id,
    land_publisher_name,

    booking_num
FROM
(
    SELECT * 
    FROM  dwd_order_d_i
    WHERE 1 = 1
      -- 过滤手机号为空的
      AND ticket_taker_mobile IS NOT NULL
      AND ticket_taker_mobile <> ''
      AND booking_date = '${ds}' 
      -- 过滤供应商打包套票的子票
      AND NOT(booking_channel=23 AND land_publisher_id=booker_id)
) AS o
JOIN 
(
    SELECT user_id 
    FROM dim_user_d_f 
    WHERE pt='${ds}' 
    AND user_type='供应商'
) AS m 
ON m.user_id=o.land_publisher_id
-- 开通营销短信的用户
-- join (select distinct user_id from dwd_user_module_d_f 
--       where pt='${bdp.system.bizdate}' and module_id=176
--             and end_time>current_date ) n ON n.user_id=o.land_publisher_id
JOIN 
(
    SELECT DISTINCT member_id AS user_id 
    FROM ods_pft001_pft_module_used_d_f
    WHERE pt="${ds}" 
      AND module_id=176
      AND from_unixtime(expire_time, 'yyyy-MM-dd') >= to_date("${ds2}") 
) AS n 
ON n.user_id=o.land_publisher_id;


