--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-12 15:55:14
--EMR任务只能运行在独享资源组上
--********************************************************************--


CREATE TABLE IF NOT EXISTS ads_booking_sum_d_f(
    user_id         STRING COMMENT "商户id",
    booking_date    STRING COMMENT "预定日期",
    today           STRING COMMENT "当天预定",
    yesterday       STRING COMMENT "提前一天预定",
    weeks           STRING COMMENT "二到七天预定",
    more_week       STRING COMMENT "超一周预定"
)COMMENT '预定人数按照预定日期区分' 
PARTITIONED BY(
    pt STRING 
)STORED AS ORC;


INSERT OVERWRITE TABLE ads_booking_sum_d_f PARTITION (pt="${ds}")
SELECT 
    o.seller_id                                                             AS user_id,
    substr(o.booking_time, 1, 10)                                           AS booking_date,
    SUM(IF(pre_booked_days = 0, ticket_num, 0))                             AS today,
    SUM(IF(pre_booked_days = 1, ticket_num, 0))                             AS yesterday,
    SUM(IF(pre_booked_days >= 2 AND pre_booked_days <= 7, ticket_num, 0))   AS weeks,
    SUM(IF(pre_booked_days > 7, ticket_num, 0))                             AS more_week
FROM 
(
    SELECT * 
    FROM dwd_order_d_i 
    WHERE booking_date > "${ds732}"
      AND pay_time IS NOT NULL 
      AND NOT (order_type='套票子票' AND land_publisher_id = booker_id)
) AS o
GROUP BY 
    o.seller_id, 
    SUBSTR(o.booking_time, 1, 10)

