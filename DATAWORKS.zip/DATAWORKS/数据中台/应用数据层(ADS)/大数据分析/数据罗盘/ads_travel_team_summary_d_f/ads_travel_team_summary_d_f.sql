--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-12 15:27:33
--EMR任务只能运行在独享资源组上
--********************************************************************--


CREATE TABLE IF NOT EXISTS ads_travel_team_summary_d_f(
    vertify_time            STRING   COMMENT "检票时间",
    land_publisher_id       STRING   COMMENT "用户ID",
    land_publisher_name     STRING   COMMENT "用户名称",
    resource_id             STRING   COMMENT "资源id",
    resource_name           STRING   COMMENT "资源名称",
	land_id				    STRING   COMMENT "产品ID",
	land_name			    STRING 	 COMMENT "产品名称",
    team_type               STRING   COMMENT "团队散客类型",
    tnum                    STRING   COMMENT "人数",
    update_time             STRING   COMMENT "更新时间"
)COMMENT '团散游玩汇总'
PARTITIONED BY(
    pt STRING
)STORED AS ORC;


INSERT OVERWRITE TABLE ads_travel_team_summary_d_f PARTITION (pt = "${ds}")    
SELECT
    vertify_time,
    land_publisher_id,
    land_publisher_name,
    resource_id,
    resource_name,
    land_id,
    land_name,
    team_type,
    SUM(ticket_num) AS tnum,
    NOW()           AS update_time       
FROM
( 
    SELECT
        SUBSTR(verify_time, 1, 10) AS vertify_time,
        land_publisher_id,
        land_publisher_name,
        resource_id,
        resource_name,
        land_id,
        land_name,
        CASE                     
            WHEN booker_type = '普通用户' THEN '散客'                  
            ELSE '团队'                
        END                         AS team_type,
        ticket_num           
    FROM dwd_order_d_i 
    -- WHERE booking_date > DATE_SUB("${bdp.system.bizdate2}", 732)                
    WHERE booking_date > "${ds733}"              
      AND order_pay_status <> 2                
      AND verify_time IS NOT NULL   
      AND NOT (order_type = '套票子票' AND land_publisher_id = booker_id)  
) AS a       
GROUP BY
    vertify_time,
    land_publisher_id,
    land_publisher_name,
    resource_id,
    resource_name,
    land_id,
    land_name,
    team_type;

