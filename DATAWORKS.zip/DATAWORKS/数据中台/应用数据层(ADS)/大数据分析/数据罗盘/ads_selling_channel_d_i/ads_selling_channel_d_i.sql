--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-13 15:20:48
--EMR任务只能运行在独享资源组上
--********************************************************************--
CREATE TABLE IF NOT EXISTS ads_selling_channel_d_i(
    booking_time             STRING COMMENT "预定时间",
    user_id                  STRING COMMENT "商户id",
    user_name                STRING COMMENT "商户名称",
    ticket_id                STRING COMMENT "票id",
    ticket_fullname          STRING COMMENT "票名称",
    land_id                  STRING COMMENT "景区id",
    land_name                STRING COMMENT "景区名称",
    resource_id              STRING COMMENT "资源id",
    resource_name            STRING COMMENT "资源名称",
    dimension_methods        STRING COMMENT "售卖渠道",
    channel_id               STRING COMMENT "渠道id",
    channel_name             STRING COMMENT "渠道名称",
    order_num                STRING COMMENT "订单数",
    ticket_num               STRING COMMENT "票数",
    pay_amount               STRING COMMENT "金额"
)COMMENT '分销 OTA 直销渠道占比' PARTITIONED BY(
    pt STRING 
)STORED AS ORC;


INSERT OVERWRITE TABLE ads_selling_channel_d_i PARTITION (pt="${ds}")
SELECT 
    booking_time,
    user_id,
    user_name,
    ticket_id,
    ticket_fullname,
    land_id,
    land_name,
    resource_id,
    resource_name,
    dimension_methods,
    channel_id,
    channel_name,
    SUM(o1.order_num)                         AS order_num,
    SUM(o1.order_ticket)                      AS ticket_num,
    SUM(o1.sale_money)                        AS pay_amount
FROM
(
    SELECT
        o.fid                         AS user_id,
        t.land_publisher_name         AS user_name,
        o.tid                         AS ticket_id,
        t.ticket_name                 AS ticket_fullname,
        t.land_id                     AS land_id,
        t.land_name                   AS land_name,
        t.resource_id                 AS resource_id,
        t.resource_name               AS resource_name,
        CONCAT(
            SUBSTR(o.`date`,1,4),
            '-',
            SUBSTR(o.`date`,5,2),
            '-',
            SUBSTR(o.`date`,7,2)
        )                             AS booking_time,
        CASE 
            WHEN (o.fid=o.reseller_id)  OR (u1.user_type_code=5 AND o.channel<>17) THEN '直销'    -- 自供自销B端下单/销售给散客 为直销
            WHEN (u1.user_type_code<>5 AND u1.user_is_OTA='OTA') OR (u1.user_type_code=5 AND o.channel=17 ) THEN 'OTA'    -- 淘宝/飞猪 归OTA
            WHEN u1.user_type_code<>5 AND u1.user_is_OTA<>'OTA' THEN '分销'
            ELSE '其他'
        END                             AS dimension_methods,
        CASE 
            WHEN u1.user_type_code=5 THEN ch.order_channel_id
            ELSE o.reseller_id 
        END                             AS channel_id,
        CASE 
            WHEN u1.user_type_code=5 THEN ch.channel_name
            ELSE u1.user_name 
        END                             AS channel_name,
        order_num,
        order_ticket,
        sale_money
    FROM (
        SELECT 
            sid as fid,
            tid,
            order_ticket,
            order_num,
            order_sale_money AS sale_money,
            channel,
            reseller_id,
            `date`
        FROM dws_report_order_d_i 
        WHERE `date` ='${ds}'
            AND main_tid=0
    ) AS o
    -- JOIN (SELECT * FROM dim_user_datav_d_f where pt='${ds}') AS a ON o.fid = a.user_id
    JOIN 
    (
        SELECT ticket_id,ticket_name,land_id,land_name,land_publisher_id,land_publisher_name,resource_id,resource_name 
        FROM dim_prod_d_f 
        WHERE pt='${ds}'
    ) AS t ON o.tid=t.ticket_id AND o.fid=t.land_publisher_id
    LEFT JOIN (SELECT order_channel_id,channel_name FROM dim_channel_d_f  WHERE pt='${ds}') AS ch ON o.channel=ch.order_channel_id
    LEFT JOIN (SELECT user_id,user_name,user_type_code,user_is_OTA FROM dim_user_d_f WHERE pt='${ds}') AS u1 ON o.reseller_id=u1.user_id
) AS o1
    
GROUP BY user_id,user_name,ticket_id,ticket_fullname,land_id,land_name,booking_time,dimension_methods,channel_id,channel_name,resource_id,resource_name
;