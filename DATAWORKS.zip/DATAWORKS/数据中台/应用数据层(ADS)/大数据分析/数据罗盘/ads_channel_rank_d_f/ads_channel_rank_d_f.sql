--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-12 16:49:57
--EMR任务只能运行在独享资源组上
--********************************************************************--


CREATE TABLE IF NOT EXISTS ads_channel_rank_d_f(
    ordertime       STRING COMMENT "下单时间",
    sellerid        STRING COMMENT "售卖者",
    DataV_token     STRING COMMENT "商户token",
    channel         STRING COMMENT "渠道id",
    channel_name    STRING COMMENT "渠道名称",
    order_ticket    STRING COMMENT "票数",
    order_amount    STRING COMMENT "金额（分）"
)COMMENT "景区大屏渠道排行" 
PARTITIONED BY(
    pt              STRING 
)STORED AS ORC;


INSERT OVERWRITE TABLE ads_channel_rank_d_f PARTITION (pt="${ds}")
SELECT  
    ordertime,
    sellerid,
    DataV_token,
    channel,
    channel_name,
    SUM(order_ticket)   AS order_ticket,
    SUM(order_amount)   AS order_amount
FROM 
(
    SELECT  
        SUBSTR(o.booking_time, 1, 10)   AS ordertime,
        o.order_id,
        a.sellerid,
        au.DataV_token,
        CASE o.booking_channel
            WHEN 17 THEN a.buyerid
            WHEN 20 THEN a.buyerid
            ELSE o.booking_channel
        END                             AS channel,
        CASE o.booking_channel
            WHEN 10 THEN '云票务'
            WHEN 11 THEN '微商城'
            WHEN 12 THEN '自助机'
            WHEN 15 THEN '智能终端'
            WHEN 24 THEN '团队预定'
            WHEN 17 THEN me.com_name
            WHEN 20 THEN me.com_name
            ELSE '其他'
        END                     	    AS channel_name, 
        o.ticket_num                    AS order_ticket,
        o.ticket_num * a.sale_money     AS order_amount
    FROM 
    (
        SELECT order_id, booking_time, booking_channel, ticket_num
        FROM dwd_order_d_i 
        WHERE booking_date > "${ds}" - 732  
          AND pay_time IS NOT NULL 
          AND order_pay_status < 2
          AND booking_channel NOT IN (18, 23)
          AND order_status_code NOT IN (3, 6, 9)
    ) AS o
    JOIN 
    (
        SELECT sellerid, buyerid, sale_money, orderid
        FROM s_order_split_d_i
        WHERE orderdate > "${ds}" - 732 
          AND sellerid IN (567997, 3192946)
    ) AS a 
    ON a.orderid = o.order_id 
    JOIN 
    (
        SELECT fid, com_name
        FROM ods_myuu_pft_member_extinfo_d_f
        WHERE pt = '${ds}'
    ) AS me 
    ON me.fid = a.buyerid 
    JOIN 
    (
        SELECT user_id, DataV_token
        FROM ods_datav_auth_d_f
        WHERE pt = '${ds}'
    ) AS au 
    ON au.user_id = a.sellerid 
) AS k
GROUP BY    
    ordertime,
    sellerid,
    DataV_token,
    channel,
    channel_name


