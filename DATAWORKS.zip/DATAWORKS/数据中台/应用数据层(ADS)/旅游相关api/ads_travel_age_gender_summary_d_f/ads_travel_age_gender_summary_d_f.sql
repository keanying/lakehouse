--@exclude_input=default_workspace_svwh.dim_age_id
--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-12 16:22:48
--EMR任务只能运行在独享资源组上
--********************************************************************--


----游客年龄和性别汇总
----细化到资源,产品维度

CREATE TABLE IF NOT EXISTS ads_travel_age_gender_summary_d_f(
    vertify_time                STRING   COMMENT "检票时间",
    land_publisher_id           STRING   COMMENT "用户ID",
    land_publisher_name         STRING   COMMENT "用户名称",
    resource_id                 STRING   COMMENT "资源id",
    resource_name               STRING   COMMENT "资源名称",
	land_id						STRING   COMMENT "产品ID",
	land_name					STRING 	 COMMENT "产品名称",
    ticket_taker_sex			STRING   COMMENT "性别",
	age_id 						STRING   COMMENT "年龄id",
    age_name                    STRING   COMMENT "年龄段",
    age_describe                STRING   COMMENT "年龄描述",
	order_num   				STRING 	 COMMENT "订单数",
    tnum                        STRING   COMMENT "票数",
	order_pay_amount            STRING   COMMENT "金额（元）",
    update_time                 STRING   COMMENT "更新时间"
)COMMENT'游玩年龄和性别汇总' 
PARTITIONED BY(
    pt STRING
)STORED AS ORC;


INSERT OVERWRITE TABLE ads_travel_age_gender_summary_d_f PARTITION (pt='${ds}')
SELECT
	a.verify_time,
	a.land_publisher_id,
	a.land_publisher_name,
	a.resource_id,
	a.resource_name,
	a.land_id,
	a.land_name,
	a.ticket_taker_sex,
	b.age_id                        AS age_id,
	b.age_name                      AS age_name,
	b.age_describe                  AS age_describe,
	COUNT(DISTINCT a.order_id)      AS order_num,
	SUM(a.ticket_num)               AS tnum,
	SUM(a.order_pay_amount) / 100   AS order_pay_amount,
	NOW()                           AS update_time 
FROM
(
    SELECT
        SUBSTR(verify_time, 1, 10) AS verify_time,
        land_publisher_id,
        land_publisher_name,
        resource_id,
        resource_name,
        land_id,
        land_name,
        ticket_taker_sex,
        order_id,
        ticket_num,
        order_pay_amount,
        ticket_taker_age
    FROM dwd_order_d_i
    WHERE booking_date > "${ds733}"
      AND order_pay_status <> 2 
      AND ticket_taker_sex <>'未知'
      -- 24/04/07 增加修订排除未支付以及票数为 0
      AND pay_time IS NOT NULL
      AND ticket_num > 0
      AND NOT (order_type='套票子票' AND land_publisher_id = booker_id)
) AS a
JOIN dim_age_id AS b 
ON a.ticket_taker_age >= b.start_age 
AND a.ticket_taker_age <= b.end_age 
GROUP BY
	a.verify_time,
	a.land_publisher_id,
	a.land_publisher_name,
	a.resource_id,
	a.resource_name,
	a.land_id,
	a.land_name,
	a.ticket_taker_sex,
	b.age_id,
	b.age_name,
	b.age_describe;