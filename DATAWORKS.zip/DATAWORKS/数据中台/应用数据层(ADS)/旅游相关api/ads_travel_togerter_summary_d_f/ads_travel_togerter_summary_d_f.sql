--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-12 15:31:40
--EMR任务只能运行在独享资源组上
--********************************************************************--

CREATE TABLE IF NOT EXISTS ads_travel_togerter_summary_d_f(
    vertify_time        	STRING   COMMENT "检票时间",
    land_publisher_id   	STRING   COMMENT "用户ID",
    land_publisher_name 	STRING   COMMENT "用户名称",
    resource_id         	STRING   COMMENT "资源id",
    resource_name       	STRING   COMMENT "资源名称",
	land_id					STRING   COMMENT "产品id",
	land_name				STRING   COMMENT "产品名称",
    num_type            	STRING   COMMENT "游玩人数类型",
    onum		        	STRING   COMMENT "订单数",
    update_time         	STRING   COMMENT "更新时间"
) COMMENT '团队人数游玩汇总' 
PARTITIONED BY(
    pt STRING
)STORED AS ORC;

INSERT OVERWRITE TABLE ads_travel_togerter_summary_d_f PARTITION (pt = "${ds}") 
SELECT
	vertify_time,
	land_publisher_id,
	land_publisher_name,
	resource_id,
	resource_name,
	land_id,
	land_name,
	num_type,
	COUNT(DISTINCT order_id) AS onum,
	NOW() AS update_time 
FROM 
(
    SELECT
        order_id,
        SUBSTR(verify_time, 1, 10) AS vertify_time,
        land_publisher_id,
        land_publisher_name,
        resource_id,
        resource_name,
        land_id,
        land_name,
        CASE
            WHEN ticket_num > 0 AND ticket_num <= 1 THEN "1人" 
            WHEN ticket_num > 1 AND ticket_num <= 3 THEN "2~3人"
            WHEN ticket_num > 3 AND ticket_num <= 9 THEN "4~9人" 
            WHEN ticket_num > 9 THEN "10人以上" 
        END     AS num_type
    FROM dwd_order_d_i                                      
    WHERE booking_date > "${ds733}"
      AND order_pay_status <> 2 
      AND verify_time IS NOT NULL 
      AND NOT (order_type='套票子票' AND land_publisher_id=booker_id)  
) AS a
GROUP BY
	vertify_time,
	land_publisher_id,
	land_publisher_name,
	resource_id,
	resource_name,
	land_id,
	land_name,
	num_type;

