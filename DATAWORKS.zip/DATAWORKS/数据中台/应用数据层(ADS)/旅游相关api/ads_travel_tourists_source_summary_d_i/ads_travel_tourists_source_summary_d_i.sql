--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-12 19:14:03
--EMR任务只能运行在独享资源组上
--********************************************************************--

----客源地汇总
----根据省市产品维度汇总


CREATE TABLE IF NOT EXISTS ads_travel_tourists_source_summary_d_i(
    vertify_time            STRING  COMMENT "检票时间",
    land_publisher_id       STRING  COMMENT "用户ID",
    land_publisher_name     STRING  COMMENT "用户名称",
    resource_id             STRING  COMMENT "资源id",
    resource_name           STRING  COMMENT "资源名称",
    land_id		            STRING  COMMENT "产品ID",
    land_name		        STRING  COMMENT "产品名称",
    ticket_taker_province   STRING  COMMENT "游客省份",
    ticket_taker_city       STRING  COMMENT "游客市",
    ticket_taker_country    STRING  COMMENT "游客县",
    order_num   		    STRING  COMMENT "订单数",
    tnum                    STRING  COMMENT "票数",
    order_pay_amount        STRING  COMMENT "金额（元）",
    update_time             STRING  COMMENT "更新时间"
) COMMENT '客源地汇总' 
PARTITIONED BY(
    pt STRING
) STORED AS ORC;


INSERT OVERWRITE TABLE ads_travel_tourists_source_summary_d_i PARTITION (pt = '${ds}')
SELECT 
    SUBSTR(t.action_time, 1, 10)            AS vertify_time,
    o.land_publisher_id,
    o.land_publisher_name,
    o.resource_id,
    o.resource_name,
    o.land_id,
    o.land_name,
    NVL(o.ticket_taker_province, '未知'),
    NVL(o.ticket_taker_city, '未知'),
    NVL(o.ticket_taker_country, '未知'),
    COUNT(DISTINCT o.order_id)              AS order_num,
    SUM(t.tnum)                             AS tnum,
    SUM(o.booking_price * t.tnum) / 100     AS order_pay_amount,
    NOW()                                   AS update_time
FROM 
(
    SELECT order_id, action_time, vertify_ticket_num AS tnum 
    FROM ods_pft_order_track_d_f
    WHERE 1 = 1 
      -- 0918修订状态为5的是验证
      AND vertify_ticket_num > 0 
      -- AND action = 5 
      -- 验证时间在昨天
      AND action_date = "${ds}" 
) AS t        
JOIN 
(
    SELECT * 
    FROM dwd_order_d_i 
    WHERE booking_date > "${ds366}"
      -- 支付方式2=未支付                 
      AND order_pay_status <> 2 
      -- 不是(套票子票且自购自销)
      AND NOT (order_type = '套票子票' AND land_publisher_id = booker_id)
)  AS o 
ON t.order_id = o.order_id
GROUP BY
    SUBSTR(t.action_time, 1, 10),
    o.land_publisher_id,
    o.land_publisher_name,
    o.resource_id,
    o.resource_name,
    o.land_id,
    o.land_name,
    o.ticket_taker_province,
    o.ticket_taker_city,
    o.ticket_taker_country;



-- SELECT ticket_taker_province, count(1) ct 
-- FROM 
-- (
--     SELECT 
--         SUBSTR(t.action_time, 1, 10)            AS vertify_time,
--         o.land_publisher_id,
--         o.land_publisher_name,
--         o.resource_id,
--         o.resource_name,
--         o.land_id,
--         o.land_name,
--         NVL(o.ticket_taker_province, '未知')    AS ticket_taker_province,
--         COUNT(DISTINCT o.order_id)              AS order_num,
--         SUM(t.tnum)                             AS tnum,
--         SUM(o.booking_price * t.tnum) / 100     AS order_pay_amount,
--         NOW()                                   AS update_time
--     FROM 
--     (
--         SELECT order_id, action_time, vertify_ticket_num AS tnum 
--         FROM ods_pft_order_track_d_f
--         WHERE 1 = 1 
--         -- 0918修订状态为5的是验证
--         AND vertify_ticket_num > 0 
--         -- AND action = 5 
--         -- 验证时间在昨天
--         AND action_date = "${ds}" 
--     ) AS t        
--     JOIN 
--     (
--         SELECT * 
--         FROM dwd_order_d_i 
--         WHERE booking_date > "${ds366}"
--         -- 支付方式2=未支付                 
--         AND order_pay_status <> 2 
--         -- 不是(套票子票且自购自销)
--         AND NOT (order_type = '套票子票' AND land_publisher_id = booker_id)
--     )  AS o 
--     ON t.order_id = o.order_id
--     GROUP BY
--         SUBSTR(t.action_time, 1, 10),
--         o.land_publisher_id,
--         o.land_publisher_name,
--         o.resource_id,
--         o.resource_name,
--         o.land_id,
--         o.land_name,
--         o.ticket_taker_province,
--         o.ticket_taker_city,
--         o.ticket_taker_country
-- ) AS t
-- WHERE land_publisher_id = 7239266
-- GROUP BY ticket_taker_province
-- ORDER BY count(1) DESC 




-- SELECT "${ds}"


-- SELECT "${ds366}"

