--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-12 15:44:56
--EMR任务只能运行在独享资源组上
--********************************************************************--


create table if not EXISTS ads_travel_product_summary_d_f(
    booking_time            STRING COMMENT "下单时间",
    land_publisher_id       STRING COMMENT "用户ID",
    land_publisher_name     STRING COMMENT "用户名称",
    resource_id             STRING COMMENT "资源id",
    resource_name           STRING COMMENT "资源名称",
    land_id                 STRING COMMENT "景区id",
    land_name               STRING COMMENT "景区名称",
    ticket_id               STRING COMMENT "产品id",
    ticket_fullname         STRING COMMENT "产品名",
    tnum                    STRING COMMENT "票数",
    onum                    STRING COMMENT "订单数",
    sale_money              STRING COMMENT "预定金额",
    update_time             STRING COMMENT "更新时间"
)COMMENT'产品销量汇总'PARTITIONED BY(
    pt STRING
)STORED AS ORC;

INSERT overwrite TABLE  ads_travel_product_summary_d_f PARTITION (pt='${ds}') 
SELECT
    CONCAT(
        SUBSTR(o.`date`,1,4),
        '-',
        SUBSTR(o.`date`,5,2),
        '-',
        SUBSTR(o.`date`,7,2)
    )                                       AS booking_time,
    o.fid                                   AS land_publisher_id,
    SUBSTR(t.land_publisher_name, 0, 30)    AS land_publisher_name,
    t.resource_id                           AS resource_id,                        
    SUBSTR(t.resource_name, 0, 30)          AS resource_name,
    t.land_id                               AS land_id,
    SUBSTR(t.land_name, 0, 30)              AS land_name,
    t.ticket_id                             AS ticket_id,
    SUBSTR(t.ticket_fullname, 0, 30)        AS ticket_fullname,
    o.order_ticket                          AS tnum,
    o.order_num                             AS onum,
    o.sale_money                            AS sale_money,
    current_date()                          AS update_time    
FROM 
(
     SELECT 
        sid as fid,
        tid,
        SUM(order_ticket) AS order_ticket,
        SUM(order_num) AS order_num,
        SUM(order_sale_money) AS sale_money,
        `date`
    FROM dws_report_order_d_i
    WHERE `date` >= "${ds733}"
        AND main_tid=0
    GROUP BY sid, tid, `date`
) AS o 
JOIN 
(
    SELECT * 
    FROM dim_user_datav_d_f 
    WHERE pt='${ds}'
) AS a 
ON o.fid = a.user_id
JOIN 
(
    SELECT ticket_id, ticket_name, ticket_fullname, land_id, land_name, resource_id, resource_name, land_publisher_id, land_publisher_name 
    FROM dim_prod_d_f 
    where pt='${ds}'
) AS t 
ON o.tid=t.ticket_id 
AND o.fid=t.land_publisher_id; 

