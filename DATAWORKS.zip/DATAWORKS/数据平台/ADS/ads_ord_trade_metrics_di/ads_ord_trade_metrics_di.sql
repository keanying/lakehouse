--Serverless Spark SQL
--********************************************************************--
--author: 韩瑞
--create time: 2026-09-23 16:39:53
--Serverless Spark SQL任务只能运行在独享资源组上
--********************************************************************--


CREATE TABLE IF NOT exists ads_ord_trade_metrics_di
(
    apply_did            INT COMMENT '原始供应商ID'
    ,scenic_id           INT COMMENT '景区id'
    ,scenic_name         STRING COMMENT '景区名称'
    ,ticket_id           INT COMMENT '门票id'
    ,ticket_name         STRING COMMENT '门票名称'
    ,channel_class1_id   INT COMMENT '渠道一级分类id'
    ,channel_class1_name STRING COMMENT '渠道一级分类名称'
    ,channel_class2_id   INT COMMENT '渠道二级分类id(ordermode)'
    ,channel_class2_name STRING COMMENT '渠道二级分类名称'
    ,order_status_code   INT COMMENT '订单状态：0=未使用,1=已使用,2=已过期,3=被取消,4=待确认(酒店)，待收货(特产),5=被终端修改,6=被终端撤销,7=部分使用,8=订单完结,9=被删除'
    ,is_package_ticket   INT COMMENT '是否组合套票[1:是,0:否]'
    ,ticket_package_type INT COMMENT '组合类型[0:单票,1:套票中的主票,2:套票中的子票,3:1+2情况]'
    ,scenic_type_code    STRING COMMENT '景区类型编码[A:景区,B:线路,C:酒店,F:套票,G:餐饮,H:演出,I:年卡,J:特产,K:计时产品]'
    ,scenic_type_name    STRING COMMENT '景区类型名称'
    ,pay_order_cnt       BIGINT COMMENT '销售订单数'
    ,pay_ticket_num      BIGINT COMMENT '销售票数'
    ,pay_total_amount    DOUBLE COMMENT '总销售金额【GMV】(数量*单价)'
    ,pay_amount          DOUBLE COMMENT '总支付金额'
    ,cost_amount         DOUBLE COMMENT '累计成本额'
    ,sale_amount         DOUBLE COMMENT '累计销售额'
)
COMMENT '订单交易主题指标表-多维'
PARTITIONED BY 
(
    travel_date           INT COMMENT '支付日期yyyyMMdd'
)
STORED AS ORC
;


INSERT OVERWRITE TABLE ads_ord_trade_metrics_di PARTITION (travel_date)
SELECT  apply_did
         ,scenic_id
         ,max(scenic_name) AS scenic_name
         ,ticket_id
         ,max(ticket_name) AS ticket_name
         ,channel_class1_id
         ,max(channel_class1_name) AS channel_class1_name
         ,channel_class2_id
         ,max(channel_class2_name) AS channel_class2_name
         ,order_status_code
         ,is_package_ticket
         ,ticket_package_type
         ,scenic_type_code
         ,max(scenic_type_name) as scenic_type_name
        ,COUNT(order_id) AS pay_order_cnt
        ,SUM(tnum) AS pay_ticket_num
        ,ROUND(SUM(tnum*order_price) / 100,2) AS pay_total_amount
        ,ROUND(SUM(original_order_amount) / 100,2) AS pay_amount
        ,ROUND(SUM(cost_money) / 100,2) AS cost_amount
        ,ROUND(SUM(sale_money) / 100,2) AS sale_amount
        ,travel_date
FROM    dws_ord_order_detail_wide_di
WHERE   travel_date = ${yesterday}
GROUP BY 
    travel_date
    ,apply_did
    ,scenic_id
    ,ticket_id
    ,channel_class1_id
    ,channel_class2_id
    ,order_status_code
    ,is_package_ticket
    ,ticket_package_type
    ,scenic_type_code
;












