--Serverless Spark SQL
--********************************************************************--
--author: 韩瑞
--create time: 2026-09-30 17:14:25
--Serverless Spark SQL任务只能运行在独享资源组上
--********************************************************************--



-- CREATE TABLE ads.ads_ord_order_booking_metric_di (
--     stat_date             STRING COMMENT '统计日期（YYYYMMDD）',
--     booking_order_qty     BIGINT COMMENT '预定订单量',
--     booking_traveler_qty  BIGINT COMMENT '预定游客数',
--     booking_amt           DECIMAL(16,2) COMMENT '预定金额',
--     paid_amt              DECIMAL(16,2) COMMENT '实付金额',
--     cancel_order_qty      BIGINT COMMENT '取消订单量',
--     booking_success_rate  DECIMAL(8,4) COMMENT '预定成功率',
--     avg_booking_amt       DECIMAL(16,2) COMMENT '平均预定金额',
--     -- 其他指标字段...
--     etl_load_time         STRING COMMENT 'ETL加载时间（yyyy-MM-dd HH:mm:ss）'
-- ) COMMENT '订单预定指标表（ADS应用层，天级增量）'
-- PARTITIONED BY (travel_date STRING COMMENT '分区字段，格式YYYYMMDD');

-- DROP TABLE IF exists ads_ord_order_booking_metric_di;
CREATE TABLE IF NOT exists ads_ord_order_booking_metric_di
(
    apply_did            INT COMMENT '原始供应商ID'
    ,scenic_id           INT COMMENT '景点ID'
    ,channel_class1_id   INT COMMENT '渠道一级分类id'
    ,channel_class1_name STRING COMMENT '渠道一级分类名称'
    ,channel_class2_id   INT COMMENT '渠道二级分类id(ordermode)'
    ,channel_class2_name STRING COMMENT '渠道二级分类名称'
    ,order_status_code   INT COMMENT '订单状态：0=未使用,1=已使用,2=已过期,3=被取消,4=待确认(酒店)，待收货(特产),5=被终端修改,6=被终端撤销,7=部分使用,8=订单完结,9=被删除'
    ,province_code       INT COMMENT '归属省份编码'
    ,province_name       STRING COMMENT '归属省份名称'
    ,city_code           INT COMMENT '归属市编码'
    ,city_name           STRING COMMENT '归属市名称'
    ,district_code       INT COMMENT '归属区/县编码'
    ,district_name       STRING COMMENT '归属区/县名称'
    ,ext_sex             INT COMMENT '性别:0女;1男'
    ,ext_age             INT COMMENT '年龄'
    ,ext_country_code    STRING COMMENT '国家编码'
    ,qty                 BIGINT COMMENT '人数'
)
COMMENT '订单预定交易主题指标表-多维'
STORED AS ORC
;

INSERT OVERWRITE TABLE ads_ord_order_booking_metric_di
SELECT 
    apply_did
    ,scenic_id
    ,channel_class1_id
    ,MAX(channel_class1_name) AS channel_class1_name
    ,channel_class2_id
    ,MAX(channel_class2_name) AS channel_class2_name
    ,order_status_code
    ,province_code
    ,max(province_name) AS province_name
    ,city_code
    ,max(city_name) AS city_name
    ,district_code
    ,MAX(district_name) AS district_name
    ,ext_sex
    ,ext_age
    ,ext_country_code
    ,COUNT(*) AS qty
FROM dws_ord_traveler_booking_wide_di
WHERE travel_date >= ${yesterday}
GROUP BY 
    apply_did
    ,scenic_id
    ,channel_class1_id
    ,channel_class2_id
    ,order_status_code
    ,province_code
    ,city_code
    ,district_code
    ,ext_sex
    ,ext_age
    ,ext_country_code
;







