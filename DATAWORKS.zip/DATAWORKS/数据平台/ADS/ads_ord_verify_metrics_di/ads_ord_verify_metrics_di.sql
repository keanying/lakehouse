--Serverless Spark SQL
--********************************************************************--
--author: 韩瑞
--create time: 2026-10-23 16:21:00
--Serverless Spark SQL任务只能运行在独享资源组上
--********************************************************************--



CREATE TABLE IF NOT EXISTS ads_ord_verify_metrics_di
  (
      apply_did            INT COMMENT '原始供应商ID'
      ,track_action        BIGINT COMMENT '变更状态:0=预出票,1=入园,2=取消,3=过期,4=验证,5=撤销撤改,6=出票且有效,7=售后'
      ,ticket_id           BIGINT COMMENT '票类ID'
      ,channel_class1_id   INT COMMENT '渠道一级分类id'
      ,channel_class1_name STRING COMMENT '渠道一级分类名称'
      ,channel_class2_id   INT COMMENT '渠道二级分类id(ordermode)'
      ,channel_class2_name STRING COMMENT '渠道二级分类名称'
      ,order_status_code   INT COMMENT '订单状态：0=未使用,1=已使用,2=已过期,3=被取消,4=待确认(酒店)，待收货(特产),5=被终端修改,6=被终端撤销,7=部分使用,8=订单完结,9=被删除'
      ,is_first_used       INT COMMENT '是否首次入园[1是,0否]'
      ,is_overdue          INT COMMENT '是否过期验证,1=过期验证,0=非过期验证'
      ,province_code       INT COMMENT '归属省份编码'
      ,province_name       STRING COMMENT '归属省份名称'
      ,city_code           INT COMMENT '归属市编码'
      ,city_name           STRING COMMENT '归属市名称'
      ,district_code       INT COMMENT '归属区/县编码'
      ,district_name       STRING COMMENT '归属区/县名称'
      ,ext_sex             INT COMMENT '性别:0女;1男'
      ,ext_age             INT COMMENT '年龄'
      ,verify_qty          BIGINT COMMENT '验证数量'
  )
  COMMENT '订单验证主题指标表-多维'
  PARTITIONED BY
  (
      verify_date         INT COMMENT '验证日期yyyyMMdd'
  )
  STORED AS ORC
  ;


--   INSERT OVERWRITE TABLE ads_ord_verify_metrics_di PARTITION (verify_date)
  SELECT
      apply_did
      ,track_action
      ,ticket_id
      ,channel_class1_id
      ,MAX(channel_class1_name) AS channel_class1_name
      ,channel_class2_id
      ,MAX(channel_class2_name) AS channel_class2_name
      ,order_status_code
      ,is_first_used
      ,is_overdue
      ,province_code
      ,MAX(province_name) AS province_name
      ,city_code
      ,MAX(city_name) AS city_name
      ,district_code
      ,MAX(district_name) AS district_name
      ,ext_sex
      ,ext_age
      ,SUM(change_qty) AS verify_qty
      ,verify_date
  FROM dws_ord_traveler_verify_log_wide_di
  WHERE verify_date = ${yesterday}
  and channel_class1_id is not NULL 
--   WHERE verify_date >= 20260101
  GROUP BY
      verify_date
      ,apply_did
      ,track_action
      ,ticket_id
      ,channel_class1_id
      ,channel_class2_id
      ,order_status_code
      ,is_first_used
      ,is_overdue
      ,province_code
      ,city_code
      ,district_code
      ,ext_sex
      ,ext_age
  ;



-- select * from ads_ord_verify_metrics_di;

-- show partitions dws_ord_traveler_verify_log_wide_di;


