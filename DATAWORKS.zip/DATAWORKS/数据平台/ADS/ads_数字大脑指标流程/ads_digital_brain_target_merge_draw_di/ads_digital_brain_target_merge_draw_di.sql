--Serverless Spark SQL
--********************************************************************--
--author: 王海阳
--create time: 2026-10-20 15:29:04
--Serverless Spark SQL任务只能运行在独享资源组上
--********************************************************************--

WITH base AS (
-- ============================================================
-- 一、人口属性
-- ============================================================
-- 1.1 性别构成 (占比%)
SELECT
    MD5(CONCAT_WS('|', ${bizdate} ,'画像-人口属性', src.scenic_id, CONCAT('性别构成(', src.tag_value, ')'), src.period_granularity, ind.target_desc)) AS key_id,
    src.scenic_id                    AS scenic_id,
    dim_scenic.scenic_name           AS scenic_name,
    '画像-人口属性'                   AS indicator_domain,
    CONCAT('性别构成(', src.tag_value, ')') AS target_name,
    ind.target_desc                  AS target_desc,
    'first_half_year'                             AS date_type,
    ind.data_value                   AS data_value,
    '画像'                           AS data_domain,
    ${bizdate}                       AS travel_date
FROM (
    SELECT scenic_id, period_granularity, tag_value, proportion
    FROM ads_scenic_customer_insight_basic_profile_mo
    WHERE metric_level = '性别'
      AND period_granularity = '2026H1'
      AND scenic_id IN('PFTSCA01018088', 'PFTSCA01016184', 'PFTSCA01018066', 'PFTSCM00000001', 'PFTSCZ01022547')
) src
JOIN dim_prd_scenic_supplier_relation_f dim_scenic
    ON src.scenic_id = dim_scenic.scenic_id
LATERAL VIEW stack(1,
    '占比(%)', CAST(src.proportion AS DECIMAL(10,2))
) ind AS target_desc, data_value

UNION ALL
-- 1.2 年龄分布 (占比% + TGI值)
SELECT
    MD5(CONCAT_WS('|', ${bizdate} ,'画像-人口属性', src.scenic_id, CONCAT('年龄分布(', src.tag_value, ')'), src.period_granularity, ind.target_desc)) AS key_id,
    src.scenic_id                    AS scenic_id,
    dim_scenic.scenic_name           AS scenic_name,
    '画像-人口属性'                   AS indicator_domain,
    CONCAT('年龄分布(', src.tag_value, ')') AS target_name,
    ind.target_desc                  AS target_desc,
    'first_half_year'                             AS date_type,
    ind.data_value                   AS data_value,
    '画像'                           AS data_domain,
    ${bizdate}                       AS travel_date
FROM (
    SELECT scenic_id, period_granularity, tag_value, proportion, tgi
    FROM ads_scenic_customer_insight_basic_profile_mo
    WHERE metric_level = '年龄'
      AND period_granularity = '2026H1'
      AND scenic_id IN('PFTSCA01018088', 'PFTSCA01016184', 'PFTSCA01018066', 'PFTSCM00000001', 'PFTSCZ01022547')
) src
JOIN dim_prd_scenic_supplier_relation_f dim_scenic
    ON src.scenic_id = dim_scenic.scenic_id
LATERAL VIEW stack(2,
    '占比(%)',  CAST(src.proportion AS DECIMAL(10,2)),
    'TGI值',    CAST(src.tgi         AS DECIMAL(10,2))
) ind AS target_desc, data_value

UNION ALL
-- 1.3 学历结构 (占比% + 全国对照值%)
SELECT
    MD5(CONCAT_WS('|', ${bizdate} ,'画像-人口属性', src.scenic_id, CONCAT('学历结构(', src.tag_value, ')'), src.period_granularity, ind.target_desc)) AS key_id,
    src.scenic_id                    AS scenic_id,
    dim_scenic.scenic_name           AS scenic_name,
    '画像-人口属性'                   AS indicator_domain,
    CONCAT('学历结构(', src.tag_value, ')') AS target_name,
    ind.target_desc                  AS target_desc,
    'first_half_year'                             AS date_type,
    ind.data_value                   AS data_value,
    '画像'                           AS data_domain,
    ${bizdate}                       AS travel_date
FROM (
    SELECT scenic_id, period_granularity, tag_value, proportion, tgi, national_baseline
    FROM ads_scenic_customer_insight_basic_profile_mo
    WHERE metric_level = '学历'
      AND period_granularity = '2026H1'
      AND scenic_id IN('PFTSCA01018088', 'PFTSCA01016184', 'PFTSCA01018066', 'PFTSCM00000001', 'PFTSCZ01022547')
) src
JOIN dim_prd_scenic_supplier_relation_f dim_scenic
    ON src.scenic_id = dim_scenic.scenic_id
LATERAL VIEW stack(3,
    '占比(%)',        CAST(src.proportion        AS DECIMAL(10,2)),
    'TGI值',          CAST(src.tgi        AS DECIMAL(10,2)),
    '全国对照值(%)',  CAST(src.national_baseline AS DECIMAL(10,2))
) ind AS target_desc, data_value

UNION ALL
-- 1.4 人生阶段 (占比% + TGI值)
SELECT
    MD5(CONCAT_WS('|', ${bizdate} ,'画像-人口属性', src.scenic_id, CONCAT('人生阶段(', src.tag_value, ')'), src.period_granularity, ind.target_desc)) AS key_id,
    src.scenic_id                    AS scenic_id,
    dim_scenic.scenic_name           AS scenic_name,
    '画像-人口属性'                   AS indicator_domain,
    CONCAT('人生阶段(', src.tag_value, ')') AS target_name,
    ind.target_desc                  AS target_desc,
    'first_half_year'                             AS date_type,
    ind.data_value                   AS data_value,
    '画像'                           AS data_domain,
    ${bizdate}                       AS travel_date
FROM (
    SELECT scenic_id, period_granularity, tag_value, proportion, tgi
    FROM ads_scenic_customer_insight_basic_profile_mo
    WHERE metric_level = '人生阶段'
      AND period_granularity = '2026H1'
      AND scenic_id IN('PFTSCA01018088', 'PFTSCA01016184', 'PFTSCA01018066', 'PFTSCM00000001', 'PFTSCZ01022547')
) src
JOIN dim_prd_scenic_supplier_relation_f dim_scenic
    ON src.scenic_id = dim_scenic.scenic_id
LATERAL VIEW stack(2,
    '占比(%)',  CAST(src.proportion AS DECIMAL(10,2)),
    'TGI值',    CAST(src.tgi         AS DECIMAL(10,2))
) ind AS target_desc, data_value

UNION ALL
-- 1.5 有孩一族 (占比%)
SELECT
    MD5(CONCAT_WS('|', ${bizdate} ,'画像-人口属性', src.scenic_id, CONCAT('有孩一族(', src.tag_value, ')'), src.period_granularity, ind.target_desc)) AS key_id,
    src.scenic_id                    AS scenic_id,
    dim_scenic.scenic_name           AS scenic_name,
    '画像-人口属性'                   AS indicator_domain,
    CONCAT('有孩一族(', src.tag_value, ')') AS target_name,
    ind.target_desc                  AS target_desc,
    'first_half_year'                             AS date_type,
    ind.data_value                   AS data_value,
    '画像'                           AS data_domain,
    ${bizdate}                       AS travel_date
FROM (
    SELECT scenic_id, period_granularity, tag_value, proportion
    FROM ads_scenic_customer_insight_basic_profile_mo
    WHERE metric_level = '有孩一族'
      AND period_granularity = '2026H1'
      AND scenic_id IN('PFTSCA01018088', 'PFTSCA01016184', 'PFTSCA01018066', 'PFTSCM00000001', 'PFTSCZ01022547')
) src
JOIN dim_prd_scenic_supplier_relation_f dim_scenic
    ON src.scenic_id = dim_scenic.scenic_id
LATERAL VIEW stack(1,
    '占比(%)', CAST(src.proportion AS DECIMAL(10,2))
) ind AS target_desc, data_value

UNION ALL
-- ============================================================
-- 二、客源地
-- ============================================================
-- 2.1 客源省份 (占比%, 动态标签 如 客源省份(广东))
SELECT
    MD5(CONCAT_WS('|', ${bizdate} ,'画像-客源地', src.scenic_id, '客源省份(省内)', src.period_granularity, '占比(%)')) AS key_id,
    src.scenic_id                    AS scenic_id,
    dim_scenic.scenic_name           AS scenic_name,
    '画像-客源地'                     AS indicator_domain,
    '客源省份(省内)'                  AS target_name,
    '占比(%)'                        AS target_desc,
    'first_half_year'                             AS date_type,
    CAST(src.proportion AS DECIMAL(10,2)) AS data_value,
    '画像'                           AS data_domain,
    ${bizdate}                       AS travel_date
FROM (
    SELECT scenic_id, period_granularity, SUM(proportion) AS proportion
    FROM ads_scenic_customer_insight_source_ranking_mo
    WHERE metric_level = '省内客源市'
      AND period_granularity = '2026H1'
      AND scenic_id IN('PFTSCA01018088', 'PFTSCA01016184', 'PFTSCA01018066', 'PFTSCM00000001', 'PFTSCZ01022547')
    GROUP BY scenic_id, period_granularity
) src
JOIN dim_prd_scenic_supplier_relation_f dim_scenic
    ON src.scenic_id = dim_scenic.scenic_id

UNION ALL
-- 省外客源市占比 = 100 - 省内合计
SELECT
    MD5(CONCAT_WS('|', ${bizdate} ,'画像-客源地', agg.scenic_id, '客源省份(省外)', agg.period_granularity, '占比(%)')) AS key_id,
    agg.scenic_id                    AS scenic_id,
    dim_scenic.scenic_name           AS scenic_name,
    '画像-客源地'                     AS indicator_domain,
    '客源省份(省外)'                  AS target_name,
    '占比(%)'                        AS target_desc,
    'first_half_year'                             AS date_type,
    CAST(agg.out_share AS DECIMAL(10,2)) AS data_value,
    '画像'                           AS data_domain,
    ${bizdate}                       AS travel_date
FROM (
    SELECT scenic_id, period_granularity,
           100 - SUM(proportion) AS out_share
    FROM ads_scenic_customer_insight_source_ranking_mo
    WHERE metric_level = '省内客源市'
      AND period_granularity = '2026H1'
      AND scenic_id IN('PFTSCA01018088', 'PFTSCA01016184', 'PFTSCA01018066', 'PFTSCM00000001', 'PFTSCZ01022547')
    GROUP BY scenic_id, period_granularity
) agg
JOIN dim_prd_scenic_supplier_relation_f dim_scenic
    ON agg.scenic_id = dim_scenic.scenic_id

UNION ALL
-- 2.2 客源城市 (占比%, 动态标签)
SELECT
    MD5(CONCAT_WS('|', ${bizdate} ,'画像-客源地', src.scenic_id, CONCAT('客源城市(', src.name, ')'), src.period_granularity, ind.target_desc)) AS key_id,
    src.scenic_id                    AS scenic_id,
    dim_scenic.scenic_name           AS scenic_name,
    '画像-客源地'                     AS indicator_domain,
    CONCAT('客源城市(', src.name, ')') AS target_name,
    ind.target_desc                  AS target_desc,
    'first_half_year'                             AS date_type,
    ind.data_value                   AS data_value,
    '画像'                           AS data_domain,
    ${bizdate}                       AS travel_date
FROM (
    SELECT scenic_id, period_granularity, name, proportion
    FROM ads_scenic_customer_insight_source_ranking_mo
    WHERE metric_level = '客源城市'
      AND period_granularity = '2026H1'
      AND scenic_id IN('PFTSCA01018088', 'PFTSCA01016184', 'PFTSCA01018066', 'PFTSCM00000001', 'PFTSCZ01022547')
) src
JOIN dim_prd_scenic_supplier_relation_f dim_scenic
    ON src.scenic_id = dim_scenic.scenic_id
LATERAL VIEW stack(1,
    '占比(%)', CAST(src.proportion AS DECIMAL(10,2))
) ind AS target_desc, data_value

UNION ALL
-- 2.3 省内客源市 (占比%, 动态标签)
SELECT
    MD5(CONCAT_WS('|', ${bizdate} ,'画像-客源地', src.scenic_id, CONCAT('省内客源市(', src.name, ')'), src.period_granularity, ind.target_desc)) AS key_id,
    src.scenic_id                    AS scenic_id,
    dim_scenic.scenic_name           AS scenic_name,
    '画像-客源地'                     AS indicator_domain,
    CONCAT('省内客源市(', src.name, ')') AS target_name,
    ind.target_desc                  AS target_desc,
    'first_half_year'                             AS date_type,
    ind.data_value                   AS data_value,
    '画像'                           AS data_domain,
    ${bizdate}                       AS travel_date
FROM (
    SELECT scenic_id, period_granularity, name, proportion
    FROM ads_scenic_customer_insight_source_ranking_mo
    WHERE metric_level = '省内客源市'
      AND period_granularity = '2026H1'
      AND scenic_id IN('PFTSCA01018088', 'PFTSCA01016184', 'PFTSCA01018066', 'PFTSCM00000001', 'PFTSCZ01022547')
) src
JOIN dim_prd_scenic_supplier_relation_f dim_scenic
    ON src.scenic_id = dim_scenic.scenic_id
LATERAL VIEW stack(1,
    '占比(%)', CAST(src.proportion AS DECIMAL(10,2))
) ind AS target_desc, data_value

-- UNION ALL
-- -- 2.4 省内 vs 省外(本省): 汇总客源省份中本省占比
-- --     注: 本省按景区所在省判断 (PFTSCA01018088=泰宁九龙潭景区 -> 福建省), 换景区时调整
-- SELECT
--     MD5(CONCAT_WS('|', ${bizdate} ,'画像-客源地', agg.scenic_id, '省内 vs 省外(本省)', agg.period_granularity, '占比(%)')) AS key_id,
--     agg.scenic_id                    AS scenic_id,
--     agg.scenic_name                  AS scenic_name,
--     '画像-客源地'                     AS indicator_domain,
--     '省内 vs 省外(本省)'              AS target_name,
--     '占比(%)'                        AS target_desc,
--     'first_half_year'                             AS date_type,
--     CAST(agg.jx_share AS DECIMAL(10,2)) AS data_value,
--     '画像'                           AS data_domain,
--     ${bizdate}                       AS travel_date
-- FROM (
--     SELECT
--         MAX(scenic_id)          AS scenic_id,
												  
--         MAX(period_granularity) AS period_granularity,
--         SUM(IF(name = '福建省', proportion, 0)) AS jx_share
--     FROM ads_scenic_customer_insight_source_ranking_mo
--     WHERE metric_level = '客源省份'
--       AND period_granularity = '2026H1'
--       AND scenic_id IN('PFTSCA01018088', 'PFTSCA01016184', 'PFTSCA01018066', 'PFTSCM00000001', 'PFTSCZ01022547')
-- ) agg

-- UNION ALL
-- -- 2.5 省内 vs 省外(省外): 汇总客源省份中省外占比
-- SELECT
--     MD5(CONCAT_WS('|', ${bizdate} ,'画像-客源地', agg.scenic_id, '省内 vs 省外(省外)', agg.period_granularity, '占比(%)')) AS key_id,
--     agg.scenic_id                    AS scenic_id,
--     agg.scenic_name                  AS scenic_name,
--     '画像-客源地'                     AS indicator_domain,
--     '省内 vs 省外(省外)'              AS target_name,
--     '占比(%)'                        AS target_desc,
--     'first_half_year'                             AS date_type,
--     CAST(agg.out_share AS DECIMAL(10,2)) AS data_value,
--     '画像'                           AS data_domain,
--     ${bizdate}                       AS travel_date
-- FROM (
--     SELECT
--         MAX(scenic_id)          AS scenic_id,
												  
--         MAX(period_granularity) AS period_granularity,
--         SUM(IF(name <> '福建省', proportion, 0)) AS out_share
--     FROM ads_scenic_customer_insight_source_ranking_mo
--     WHERE metric_level = '客源省份'
--       AND period_granularity = '2026H1'
--       AND scenic_id IN('PFTSCA01018088', 'PFTSCA01016184', 'PFTSCA01018066', 'PFTSCM00000001', 'PFTSCZ01022547')
-- ) agg

UNION ALL
-- ============================================================
-- 三、消费能力
-- ============================================================
-- 3.1 收入水平 (占比% + TGI值)
SELECT
    MD5(CONCAT_WS('|', ${bizdate} ,'画像-消费能力', src.scenic_id, CONCAT('收入水平(', src.tag_value, ')'), src.period_granularity, ind.target_desc)) AS key_id,
    src.scenic_id                    AS scenic_id,
    dim_scenic.scenic_name           AS scenic_name,
    '画像-消费能力'                   AS indicator_domain,
    CONCAT('收入水平(', src.tag_value, ')') AS target_name,
    ind.target_desc                  AS target_desc,
    'first_half_year'                             AS date_type,
    ind.data_value                   AS data_value,
    '画像'                           AS data_domain,
    ${bizdate}                       AS travel_date
FROM (
    SELECT scenic_id, period_granularity, tag_value, proportion, tgi
    FROM ads_scenic_customer_insight_wealth_consume_mo
    WHERE metric_level = '收入水平'
      AND period_granularity = '2026H1'
      AND scenic_id IN('PFTSCA01018088', 'PFTSCA01016184', 'PFTSCA01018066', 'PFTSCM00000001', 'PFTSCZ01022547')
) src
JOIN dim_prd_scenic_supplier_relation_f dim_scenic
    ON src.scenic_id = dim_scenic.scenic_id
LATERAL VIEW stack(2,
    '占比(%)',  CAST(src.proportion AS DECIMAL(10,2)),
    'TGI值',    CAST(src.tgi         AS DECIMAL(10,2))
) ind AS target_desc, data_value

UNION ALL
-- 3.2 消费水平 (占比% + 全国对照值%)
SELECT
    MD5(CONCAT_WS('|', ${bizdate} ,'画像-消费能力', src.scenic_id, CONCAT('消费水平(', src.tag_value, ')'), src.period_granularity, ind.target_desc)) AS key_id,
    src.scenic_id                    AS scenic_id,
    dim_scenic.scenic_name           AS scenic_name,
    '画像-消费能力'                   AS indicator_domain,
    CONCAT('消费水平(', src.tag_value, ')') AS target_name,
    ind.target_desc                  AS target_desc,
    'first_half_year'                             AS date_type,
    ind.data_value                   AS data_value,
    '画像'                           AS data_domain,
    ${bizdate}                       AS travel_date
FROM (
    SELECT scenic_id, period_granularity, tag_value, proportion, national_baseline
    FROM ads_scenic_customer_insight_wealth_consume_mo
    WHERE metric_level = '全国消费水平'
      AND period_granularity = '2026H1'
      AND scenic_id IN('PFTSCA01018088', 'PFTSCA01016184', 'PFTSCA01018066', 'PFTSCM00000001', 'PFTSCZ01022547')
) src
JOIN dim_prd_scenic_supplier_relation_f dim_scenic
    ON src.scenic_id = dim_scenic.scenic_id
LATERAL VIEW stack(2,
    '占比(%)',        CAST(src.proportion        AS DECIMAL(10,2)),
    '全国对照值(%)',  CAST(src.national_baseline AS DECIMAL(10,2))
) ind AS target_desc, data_value

UNION ALL
-- 3.3 有车一族 (占比% + TGI值)
SELECT
    MD5(CONCAT_WS('|', ${bizdate} ,'画像-消费能力', src.scenic_id, CONCAT('有车一族(', src.tag_value, ')'), src.period_granularity, ind.target_desc)) AS key_id,
    src.scenic_id                    AS scenic_id,
    dim_scenic.scenic_name           AS scenic_name,
    '画像-消费能力'                   AS indicator_domain,
    CONCAT('有车一族(', src.tag_value, ')') AS target_name,
    ind.target_desc                  AS target_desc,
    'first_half_year'                             AS date_type,
    ind.data_value                   AS data_value,
    '画像'                           AS data_domain,
    ${bizdate}                       AS travel_date
FROM (
    SELECT scenic_id, period_granularity, tag_value, proportion, tgi
    FROM ads_scenic_customer_insight_wealth_consume_mo
    WHERE metric_level = '是否有车'
      AND period_granularity = '2026H1'
      AND scenic_id IN('PFTSCA01018088', 'PFTSCA01016184', 'PFTSCA01018066', 'PFTSCM00000001', 'PFTSCZ01022547')
) src
JOIN dim_prd_scenic_supplier_relation_f dim_scenic
    ON src.scenic_id = dim_scenic.scenic_id
LATERAL VIEW stack(2,
    '占比(%)',  CAST(src.proportion AS DECIMAL(10,2)),
    'TGI值',    CAST(src.tgi         AS DECIMAL(10,2))
) ind AS target_desc, data_value

UNION ALL
-- 3.4 通勤方式 (占比% + TGI值)
SELECT
    MD5(CONCAT_WS('|', ${bizdate} ,'画像-消费能力', src.scenic_id, CONCAT('通勤方式(', src.tag_value, ')'), src.period_granularity, ind.target_desc)) AS key_id,
    src.scenic_id                    AS scenic_id,
    dim_scenic.scenic_name           AS scenic_name,
    '画像-消费能力'                   AS indicator_domain,
    CONCAT('通勤方式(', src.tag_value, ')') AS target_name,
    ind.target_desc                  AS target_desc,
    'first_half_year'                             AS date_type,
    ind.data_value                   AS data_value,
    '画像'                           AS data_domain,
    ${bizdate}                       AS travel_date
FROM (
    SELECT scenic_id, period_granularity, tag_value, proportion, tgi
    FROM ads_scenic_customer_insight_wealth_consume_mo
    WHERE metric_level = '通勤方式'
      AND period_granularity = '2026H1'
      AND scenic_id IN('PFTSCA01018088', 'PFTSCA01016184', 'PFTSCA01018066', 'PFTSCM00000001', 'PFTSCZ01022547')
) src
JOIN dim_prd_scenic_supplier_relation_f dim_scenic
    ON src.scenic_id = dim_scenic.scenic_id
LATERAL VIEW stack(2,
    '占比(%)',  CAST(src.proportion AS DECIMAL(10,2)),
    'TGI值',    CAST(src.tgi         AS DECIMAL(10,2))
) ind AS target_desc, data_value

UNION ALL
-- 3.5 酒店消费水平 (占比%)
SELECT
    MD5(CONCAT_WS('|', ${bizdate} ,'画像-消费能力', src.scenic_id, CONCAT('酒店消费水平(', src.tag_value, ')'), src.period_granularity, ind.target_desc)) AS key_id,
    src.scenic_id                    AS scenic_id,
    dim_scenic.scenic_name           AS scenic_name,
    '画像-消费能力'                   AS indicator_domain,
    CONCAT('酒店消费水平(', src.tag_value, ')') AS target_name,
    ind.target_desc                  AS target_desc,
    'first_half_year'                             AS date_type,
    ind.data_value                   AS data_value,
    '画像'                           AS data_domain,
    ${bizdate}                       AS travel_date
FROM (
    SELECT scenic_id, period_granularity, tag_value, proportion, tgi
    FROM ads_scenic_customer_insight_wealth_consume_mo
    WHERE metric_level = '酒店消费水平'
      AND period_granularity = '2026H1'
      AND scenic_id IN('PFTSCA01018088', 'PFTSCA01016184', 'PFTSCA01018066', 'PFTSCM00000001', 'PFTSCZ01022547')
) src
JOIN dim_prd_scenic_supplier_relation_f dim_scenic
    ON src.scenic_id = dim_scenic.scenic_id
LATERAL VIEW stack(2,
    '占比(%)', CAST(src.proportion AS DECIMAL(10,2)),
    'TGI值', CAST(src.tgi AS DECIMAL(10,2))
) ind AS target_desc, data_value

UNION ALL
-- 3.6 餐饮消费水平 (占比%)
SELECT
    MD5(CONCAT_WS('|', ${bizdate} ,'画像-消费能力', src.scenic_id, CONCAT('餐饮消费水平(', src.tag_value, ')'), src.period_granularity, ind.target_desc)) AS key_id,
    src.scenic_id                    AS scenic_id,
    dim_scenic.scenic_name           AS scenic_name,
    '画像-消费能力'                   AS indicator_domain,
    CONCAT('餐饮消费水平(', src.tag_value, ')') AS target_name,
    ind.target_desc                  AS target_desc,
    'first_half_year'                             AS date_type,
    ind.data_value                   AS data_value,
    '画像'                           AS data_domain,
    ${bizdate}                       AS travel_date
FROM (
    SELECT scenic_id, period_granularity, tag_value, proportion, tgi
    FROM ads_scenic_customer_insight_wealth_consume_mo
    WHERE metric_level = '餐饮消费水平'
      AND period_granularity = '2026H1'
      AND scenic_id IN('PFTSCA01018088', 'PFTSCA01016184', 'PFTSCA01018066', 'PFTSCM00000001', 'PFTSCZ01022547')
) src
JOIN dim_prd_scenic_supplier_relation_f dim_scenic
    ON src.scenic_id = dim_scenic.scenic_id
LATERAL VIEW stack(2,
    '占比(%)', CAST(src.proportion AS DECIMAL(10,2)),
    'TGI值', CAST(src.tgi AS DECIMAL(10,2))
) ind AS target_desc, data_value

UNION ALL
-- 3.7 手机价格 (占比% + TGI值)
SELECT
    MD5(CONCAT_WS('|', ${bizdate} ,'画像-消费能力', src.scenic_id, CONCAT('手机价格(', src.tag_value, ')'), src.period_granularity, ind.target_desc)) AS key_id,
    src.scenic_id                    AS scenic_id,
    dim_scenic.scenic_name           AS scenic_name,
    '画像-消费能力'                   AS indicator_domain,
    CONCAT('手机价格(', src.tag_value, ')') AS target_name,
    ind.target_desc                  AS target_desc,
    'first_half_year'                             AS date_type,
    ind.data_value                   AS data_value,
    '画像'                           AS data_domain,
    ${bizdate}                       AS travel_date
FROM (
    SELECT scenic_id, period_granularity, tag_value, proportion, tgi
    FROM ads_scenic_customer_insight_wealth_consume_mo
    WHERE metric_level = '手机价格'
      AND period_granularity = '2026H1'
      AND scenic_id IN('PFTSCA01018088', 'PFTSCA01016184', 'PFTSCA01018066', 'PFTSCM00000001', 'PFTSCZ01022547')
) src
JOIN dim_prd_scenic_supplier_relation_f dim_scenic
    ON src.scenic_id = dim_scenic.scenic_id
LATERAL VIEW stack(2,
    '占比(%)',  CAST(src.proportion AS DECIMAL(10,2)),
    'TGI值',    CAST(src.tgi         AS DECIMAL(10,2))
) ind AS target_desc, data_value

UNION ALL
-- ============================================================
-- 四、旅行偏好
-- ============================================================
-- 4.1 旅游距离 (占比% + TGI值 + 全国对照值%)
SELECT
    MD5(CONCAT_WS('|', ${bizdate} ,'画像-旅行偏好', src.scenic_id, CONCAT('旅游距离(', src.tag_value, ')'), src.period_granularity, ind.target_desc)) AS key_id,
    src.scenic_id                    AS scenic_id,
    dim_scenic.scenic_name           AS scenic_name,
    '画像-旅行偏好'                   AS indicator_domain,
    CONCAT('旅游距离(', src.tag_value, ')') AS target_name,
    ind.target_desc                  AS target_desc,
    'first_half_year'                             AS date_type,
    ind.data_value                   AS data_value,
    '画像'                           AS data_domain,
    ${bizdate}                       AS travel_date
FROM (
    SELECT scenic_id, period_granularity, tag_value, proportion, tgi, national_baseline
    FROM ads_scenic_customer_insight_travel_behavior_mo
    WHERE metric_level = '旅游距离'
      AND period_granularity = '2026H1'
      AND scenic_id IN('PFTSCA01018088', 'PFTSCA01016184', 'PFTSCA01018066', 'PFTSCM00000001', 'PFTSCZ01022547')
) src
JOIN dim_prd_scenic_supplier_relation_f dim_scenic
    ON src.scenic_id = dim_scenic.scenic_id
LATERAL VIEW stack(3,
    '占比(%)',        CAST(src.proportion        AS DECIMAL(10,2)),
    'TGI值',          CAST(src.tgi               AS DECIMAL(10,2)),
    '全国对照值(%)',  CAST(src.national_baseline AS DECIMAL(10,2))
) ind AS target_desc, data_value

UNION ALL
-- 4.2 出游月份 (占比%)
SELECT
    MD5(CONCAT_WS('|', ${bizdate} ,'画像-旅行偏好', src.scenic_id, CONCAT('出游月份(', src.tag_value, ')'), src.period_granularity, ind.target_desc)) AS key_id,
    src.scenic_id                    AS scenic_id,
    dim_scenic.scenic_name           AS scenic_name,
    '画像-旅行偏好'                   AS indicator_domain,
    CONCAT('出游月份(', src.tag_value, ')') AS target_name,
    ind.target_desc                  AS target_desc,
    'first_half_year'                             AS date_type,
    ind.data_value                   AS data_value,
    '画像'                           AS data_domain,
    ${bizdate}                       AS travel_date
FROM (
    SELECT scenic_id, period_granularity, tag_value, proportion, tgi
    FROM ads_scenic_customer_insight_travel_behavior_mo
    WHERE metric_level = '出游月份'
      AND period_granularity = '2026H1'
      AND scenic_id IN('PFTSCA01018088', 'PFTSCA01016184', 'PFTSCA01018066', 'PFTSCM00000001', 'PFTSCZ01022547')
) src
JOIN dim_prd_scenic_supplier_relation_f dim_scenic
    ON src.scenic_id = dim_scenic.scenic_id
LATERAL VIEW stack(2,
    '占比(%)', CAST(src.proportion AS DECIMAL(10,2)),
    'TGI值', CAST(src.tgi AS DECIMAL(10,2))
) ind AS target_desc, data_value

UNION ALL
-- 4.3 同行程关联景区 (热度值, 动态标签)
SELECT
    MD5(CONCAT_WS('|', ${bizdate} ,'画像-旅行偏好', src.scenic_id, CONCAT('同行程关联景区(', src.poi_name, ')'), src.period_granularity, ind.target_desc)) AS key_id,
    src.scenic_id                    AS scenic_id,
    dim_scenic.scenic_name           AS scenic_name,
    '画像-旅行偏好'                   AS indicator_domain,
    CONCAT('同行程关联景区(', src.poi_name, ')') AS target_name,
    ind.target_desc                  AS target_desc,
    'first_half_year'                             AS date_type,
    ind.data_value                   AS data_value,
    '画像'                           AS data_domain,
    ${bizdate}                       AS travel_date
FROM (
    SELECT scenic_id, period_granularity, poi_name, popularity
    FROM ads_scenic_customer_insight_hot_poi_mo
    WHERE metric_level = '旅游景点'
      AND period_granularity = '2026H1'
      AND scenic_id IN('PFTSCA01018088', 'PFTSCA01016184', 'PFTSCA01018066', 'PFTSCM00000001', 'PFTSCZ01022547')
) src
JOIN dim_prd_scenic_supplier_relation_f dim_scenic
    ON src.scenic_id = dim_scenic.scenic_id
LATERAL VIEW stack(1,
    '热度值', CAST(src.popularity AS DECIMAL(10,2))
) ind AS target_desc, data_value

UNION ALL
-- 4.4 交通设施到访 (热度值, 动态标签)
SELECT
    MD5(CONCAT_WS('|', ${bizdate} ,'画像-旅行偏好', src.scenic_id, CONCAT('交通设施到访(', src.poi_name, ')'), src.period_granularity, ind.target_desc)) AS key_id,
    src.scenic_id                    AS scenic_id,
    dim_scenic.scenic_name           AS scenic_name,
    '画像-旅行偏好'                   AS indicator_domain,
    CONCAT('交通设施到访(', src.poi_name, ')') AS target_name,
    ind.target_desc                  AS target_desc,
    'first_half_year'                             AS date_type,
    ind.data_value                   AS data_value,
    '画像'                           AS data_domain,
    ${bizdate}                       AS travel_date
FROM (
    SELECT scenic_id, period_granularity, poi_name, popularity
    FROM ads_scenic_customer_insight_hot_poi_mo
    WHERE metric_level = '基础设施'
      AND period_granularity = '2026H1'
      AND scenic_id IN('PFTSCA01018088', 'PFTSCA01016184', 'PFTSCA01018066', 'PFTSCM00000001', 'PFTSCZ01022547')
) src
JOIN dim_prd_scenic_supplier_relation_f dim_scenic
    ON src.scenic_id = dim_scenic.scenic_id
LATERAL VIEW stack(1,
    '热度值', CAST(src.popularity AS DECIMAL(10,2))
) ind AS target_desc, data_value

UNION ALL
-- ============================================================
-- 五、到访偏好
-- ============================================================
-- 5.1 美食偏好(xxx) (占比% + TGI值)
SELECT
    MD5(CONCAT_WS('|', ${bizdate} ,'画像-到访偏好', src.scenic_id, CONCAT('美食偏好(', src.preference_object, ')'), src.period_granularity, ind.target_desc)) AS key_id,
    src.scenic_id                    AS scenic_id,
    dim_scenic.scenic_name           AS scenic_name,
    '画像-到访偏好'                   AS indicator_domain,
    CONCAT('美食偏好(', src.preference_object, ')') AS target_name,
    ind.target_desc                  AS target_desc,
    'first_half_year'                             AS date_type,
    ind.data_value                   AS data_value,
    '画像'                           AS data_domain,
    ${bizdate}                       AS travel_date
FROM (
    SELECT scenic_id, period_granularity, preference_object, proportion, tgi
    FROM ads_scenic_customer_insight_visit_preference_mo
    WHERE metric_level = '美食偏好'
      AND period_granularity = '2026H1'
      AND scenic_id IN('PFTSCA01018088', 'PFTSCA01016184', 'PFTSCA01018066', 'PFTSCM00000001', 'PFTSCZ01022547')
) src
JOIN dim_prd_scenic_supplier_relation_f dim_scenic
    ON src.scenic_id = dim_scenic.scenic_id
LATERAL VIEW stack(2,
    '占比(%)',  CAST(src.proportion AS DECIMAL(10,2)),
    'TGI值',    CAST(src.tgi         AS DECIMAL(10,2))
) ind AS target_desc, data_value

UNION ALL
-- 5.2 购物偏好(xxx) (占比% + TGI值)
SELECT
    MD5(CONCAT_WS('|', ${bizdate} ,'画像-到访偏好', src.scenic_id, CONCAT('购物偏好(', src.preference_object, ')'), src.period_granularity, ind.target_desc)) AS key_id,
    src.scenic_id                    AS scenic_id,
    dim_scenic.scenic_name           AS scenic_name,
    '画像-到访偏好'                   AS indicator_domain,
    CONCAT('购物偏好(', src.preference_object, ')') AS target_name,
    ind.target_desc                  AS target_desc,
    'first_half_year'                             AS date_type,
    ind.data_value                   AS data_value,
    '画像'                           AS data_domain,
    ${bizdate}                       AS travel_date
FROM (
    SELECT scenic_id, period_granularity, preference_object, proportion, tgi
    FROM ads_scenic_customer_insight_visit_preference_mo
    WHERE metric_level = '购物偏好'
      AND period_granularity = '2026H1'
      AND scenic_id IN('PFTSCA01018088', 'PFTSCA01016184', 'PFTSCA01018066', 'PFTSCM00000001', 'PFTSCZ01022547')
) src
JOIN dim_prd_scenic_supplier_relation_f dim_scenic
    ON src.scenic_id = dim_scenic.scenic_id
LATERAL VIEW stack(2,
    '占比(%)',  CAST(src.proportion AS DECIMAL(10,2)),
    'TGI值',    CAST(src.tgi         AS DECIMAL(10,2))
) ind AS target_desc, data_value

UNION ALL
-- 5.3 酒店偏好(xxx) (占比% + TGI值)
SELECT
    MD5(CONCAT_WS('|', ${bizdate} ,'画像-到访偏好', src.scenic_id, CONCAT('酒店偏好(', src.preference_object, ')'), src.period_granularity, ind.target_desc)) AS key_id,
    src.scenic_id                    AS scenic_id,
    dim_scenic.scenic_name           AS scenic_name,
    '画像-到访偏好'                   AS indicator_domain,
    CONCAT('酒店偏好(', src.preference_object, ')') AS target_name,
    ind.target_desc                  AS target_desc,
    'first_half_year'                             AS date_type,
    ind.data_value                   AS data_value,
    '画像'                           AS data_domain,
    ${bizdate}                       AS travel_date
FROM (
    SELECT scenic_id, period_granularity, preference_object, proportion, tgi
    FROM ads_scenic_customer_insight_visit_preference_mo
    WHERE metric_level = '酒店偏好'
      AND period_granularity = '2026H1'
      AND scenic_id IN('PFTSCA01018088', 'PFTSCA01016184', 'PFTSCA01018066', 'PFTSCM00000001', 'PFTSCZ01022547')
) src
JOIN dim_prd_scenic_supplier_relation_f dim_scenic
    ON src.scenic_id = dim_scenic.scenic_id
LATERAL VIEW stack(2,
    '占比(%)',  CAST(src.proportion AS DECIMAL(10,2)),
    'TGI值',    CAST(src.tgi         AS DECIMAL(10,2))
) ind AS target_desc, data_value

UNION ALL
-- 5.4 景点偏好(xxx) (占比% + TGI值)
SELECT
    MD5(CONCAT_WS('|', ${bizdate} ,'画像-到访偏好', src.scenic_id, CONCAT('景点偏好(', src.preference_object, ')'), src.period_granularity, ind.target_desc)) AS key_id,
    src.scenic_id                    AS scenic_id,
    dim_scenic.scenic_name           AS scenic_name,
    '画像-到访偏好'                   AS indicator_domain,
    CONCAT('景点偏好(', src.preference_object, ')') AS target_name,
    ind.target_desc                  AS target_desc,
    'first_half_year'                             AS date_type,
    ind.data_value                   AS data_value,
    '画像'                           AS data_domain,
    ${bizdate}                       AS travel_date
FROM (
    SELECT scenic_id, period_granularity, preference_object, proportion, tgi
    FROM ads_scenic_customer_insight_visit_preference_mo
    WHERE metric_level = '景点偏好'
      AND period_granularity = '2026H1'
      AND scenic_id IN('PFTSCA01018088', 'PFTSCA01016184', 'PFTSCA01018066', 'PFTSCM00000001', 'PFTSCZ01022547')
) src
JOIN dim_prd_scenic_supplier_relation_f dim_scenic
    ON src.scenic_id = dim_scenic.scenic_id
LATERAL VIEW stack(2,
    '占比(%)',  CAST(src.proportion AS DECIMAL(10,2)),
    'TGI值',    CAST(src.tgi         AS DECIMAL(10,2))
) ind AS target_desc, data_value
)


INSERT OVERWRITE TABLE ads_digital_brain_target_merge_di PARTITION(`data_domain`, `travel_date`)
SELECT
    key_id,
    scenic_id,
    scenic_name,
    indicator_domain,
    target_name,
    target_desc,
    date_type,
    data_value,
    data_domain,
    travel_date
FROM base

UNION ALL

SELECT
    CONCAT(key_id, '1') AS key_id,
    'PFTSCM00000001'    AS scenic_id,
    'A级景区'            AS scenic_name,
    indicator_domain,
    target_name,
    target_desc,
    date_type,
    data_value,
    data_domain,
    travel_date
FROM base
WHERE scenic_id = 'PFTSCA01018088';

REFRESH TABLE ads_digital_brain_target_merge_di;