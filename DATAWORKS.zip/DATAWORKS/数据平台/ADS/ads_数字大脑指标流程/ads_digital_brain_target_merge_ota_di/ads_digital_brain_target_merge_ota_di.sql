--Serverless Spark SQL
--********************************************************************--
--author: 韩瑞
--create time: 2026-10-14 14:09:35
--Serverless Spark SQL任务只能运行在独享资源组上
--********************************************************************--



-- -- 动态分区相关设置（按需，建议放在 SQL 前）
--   set hive.exec.dynamic.partition=true;
--   set hive.exec.dynamic.partition.mode=nonstrict;
--   set spark.sql.sources.partitionOverwriteMode=dynamic;

-- DROP TABLE if EXISTS ads_digital_brain_target_merge_di;
CREATE TABLE IF NOT EXISTS ads_digital_brain_target_merge_di
(
    `key_id`            STRING COMMENT '唯一值【拼接字符串生成的md5】'
    ,`scenic_id`        STRING COMMENT '景区ID'
    ,`scenic_name`      STRING COMMENT '景区名称'
    ,`indicator_domain` STRING COMMENT '指标域【具体位置描述，没有默认null】'
    ,`target_name`      STRING COMMENT '指标名称'
    ,`target_desc`      STRING COMMENT '指标描述'
    ,`date_type`        STRING COMMENT '时间类型 1d:昨日,7d:近7日,30d:近30日,90d:近90日,180d:近半年,week:本周, month:本月'
    ,`data_value`       DECIMAL(10,2) COMMENT '指标值'
)
COMMENT '数字大脑-统一指标表'
PARTITIONED BY 
(
    data_domain      STRING COMMENT '数据域【总览｜票务｜客流花香｜舆情｜OTA直销】'
    ,travel_date         INT COMMENT '统计日期'
)
STORED AS ORC
;


  WITH
  -- ==================== 交易指标（7 个时间周期） ====================
  trade_base AS (
    SELECT date_sub('${today}', 1) AS yesterday
  ),
  trade_periods AS (
    -- 1d 昨日
    SELECT '1d'   AS date_type, yesterday AS cur_start, yesterday AS cur_end,
           date_sub(yesterday, 1) AS mom_start, date_sub(yesterday, 1) AS mom_end,
           add_months(yesterday, -12) AS yoy_start, add_months(yesterday, -12) AS yoy_end
    FROM trade_base
    UNION ALL
    -- 7d 近7日
    SELECT '7d', date_sub(yesterday, 6), yesterday,
           date_sub(yesterday, 13), date_sub(yesterday, 7),
           add_months(date_sub(yesterday, 6), -12), add_months(yesterday, -12)
    FROM trade_base
    UNION ALL
    -- 30d 近30日
    SELECT '30d', date_sub(yesterday, 29), yesterday,
           date_sub(yesterday, 59), date_sub(yesterday, 30),
           add_months(date_sub(yesterday, 29), -12), add_months(yesterday, -12)
    FROM trade_base
    UNION ALL
    -- 90d 近90日
    SELECT '90d', date_sub(yesterday, 89), yesterday,
           date_sub(yesterday, 179), date_sub(yesterday, 90),
           add_months(date_sub(yesterday, 89), -12), add_months(yesterday, -12)
    FROM trade_base
    UNION ALL
    -- 180d 近半年
    SELECT '180d', date_sub(yesterday, 179), yesterday,
           date_sub(yesterday, 359), date_sub(yesterday, 180),
           add_months(date_sub(yesterday, 179), -12), add_months(yesterday, -12)
    FROM trade_base
    UNION ALL
    -- week 本周（周一 ~ 昨日）
    SELECT 'week', date_sub(next_day(yesterday, 'MON'), 7), yesterday,
           date_sub(next_day(yesterday, 'MON'), 14), date_sub(yesterday, 7),
           add_months(date_sub(next_day(yesterday, 'MON'), 7), -12), add_months(yesterday, -12)
    FROM trade_base
    UNION ALL
    -- month 本月（1号 ~ 昨日）
    SELECT 'month', date_trunc('month', yesterday), yesterday,
           add_months(date_trunc('month', yesterday), -1), add_months(yesterday, -1),
           add_months(date_trunc('month', yesterday), -12), add_months(yesterday, -12)
    FROM trade_base
  ),
  trade_daily AS (
    SELECT
      d.scenic_id,
      p.date_type,
      -- 销售额：当期 / 环比 / 同比
      sum(CASE WHEN d.transaction_date BETWEEN p.cur_start AND p.cur_end THEN coalesce(d.turnover, 0) ELSE 0 END) AS cur_total_amount,
      sum(CASE WHEN d.transaction_date BETWEEN p.mom_start AND p.mom_end THEN coalesce(d.turnover, 0) ELSE 0 END) AS mom_total_amount,
      sum(CASE WHEN d.transaction_date BETWEEN p.yoy_start AND p.yoy_end THEN coalesce(d.turnover, 0) ELSE 0 END) AS yoy_total_amount,
      -- 订单数：当期 / 环比
      sum(CASE WHEN d.transaction_date BETWEEN p.cur_start AND p.cur_end THEN coalesce(d.order_count, 0) ELSE 0 END) AS cur_total_order_num,
      sum(CASE WHEN d.transaction_date BETWEEN p.mom_start AND p.mom_end THEN coalesce(d.order_count, 0) ELSE 0 END) AS mom_total_order_num,
      -- 成交票量：当期 / 环比
      sum(CASE WHEN d.transaction_date BETWEEN p.cur_start AND p.cur_end THEN coalesce(d.sold_ticket_cnt, 0) ELSE 0 END) AS cur_deal_ticket_qty,
      sum(CASE WHEN d.transaction_date BETWEEN p.mom_start AND p.mom_end THEN coalesce(d.sold_ticket_cnt, 0) ELSE 0 END) AS mom_deal_ticket_qty,
      -- 核验票量：当期 / 环比
      sum(CASE WHEN d.transaction_date BETWEEN p.cur_start AND p.cur_end THEN coalesce(d.validated_ticket_volume, 0) ELSE 0 END) AS cur_verify_ticket_qty,
      sum(CASE WHEN d.transaction_date BETWEEN p.mom_start AND p.mom_end THEN coalesce(d.validated_ticket_volume, 0) ELSE 0 END) AS mom_verify_ticket_qty,
      -- 成交资源数：当期 / 环比
      sum(CASE WHEN d.transaction_date BETWEEN p.cur_start AND p.cur_end THEN coalesce(d.deal_resource_count, 0) ELSE 0 END) AS cur_deal_resource_qty,
      sum(CASE WHEN d.transaction_date BETWEEN p.mom_start AND p.mom_end THEN coalesce(d.deal_resource_count, 0) ELSE 0 END) AS mom_deal_resource_qty,
      -- 退订率加权分子/分母：当期
      sum(CASE WHEN d.transaction_date BETWEEN p.cur_start AND p.cur_end THEN coalesce(d.refund_rate, 0) * coalesce(d.sold_ticket_cnt, 0) ELSE 0 END) AS cur_refund_w,
      sum(CASE WHEN d.transaction_date BETWEEN p.cur_start AND p.cur_end THEN coalesce(d.sold_ticket_cnt, 0) ELSE 0 END) AS cur_sold_w
    FROM ads_sup_ota_ctrip_trade_di d
    CROSS JOIN trade_periods p
    WHERE d.period_type  = '1d'
      AND d.signing_code = '7'
      AND d.biz_type     = '门票'
      AND d.date_type    = '使用日期'
      AND d.scenic_id    IS NOT NULL
      AND (
             d.transaction_date BETWEEN p.cur_start AND p.cur_end
          OR d.transaction_date BETWEEN p.mom_start AND p.mom_end
          OR d.transaction_date BETWEEN p.yoy_start AND p.yoy_end
      )
    GROUP BY d.scenic_id, p.date_type
  ),
  trade_wide AS (
    SELECT
      scenic_id,
      date_type,
      cur_total_amount                                        AS total_amount,
      round((cur_total_amount      - mom_total_amount)      / coalesce(mom_total_amount, 0)      * 100, 2) AS total_amount_mom_rate,
      round((cur_total_amount      - yoy_total_amount)      / coalesce(yoy_total_amount, 0)      * 100, 2) AS total_amount_yoy_rate,
      cur_total_order_num                                     AS total_order_num,
      round((cur_total_order_num   - mom_total_order_num)   / coalesce(mom_total_order_num, 0)   * 100, 2) AS total_order_num_mom_rate,
      cur_deal_ticket_qty                                     AS deal_ticket_qty,
      round((cur_deal_ticket_qty   - mom_deal_ticket_qty)   / coalesce(mom_deal_ticket_qty, 0)   * 100, 2) AS deal_ticket_qty_mom_rate,
      cur_verify_ticket_qty                                   AS verify_ticket_qty,
      round((cur_verify_ticket_qty - mom_verify_ticket_qty) / coalesce(mom_verify_ticket_qty, 0) * 100, 2) AS verify_ticket_qty_mom_rate,
      cur_deal_resource_qty                                   AS deal_resource_qty,
      round((cur_deal_resource_qty - mom_deal_resource_qty) / coalesce(mom_deal_resource_qty, 0) * 100, 2) AS deal_resource_qty_mom_rate,
      round(coalesce(cur_refund_w / coalesce(cur_sold_w, 0), 0) * 100, 2)                         AS cancel_order_num_rate
    FROM trade_daily
  ),
  trade_long AS (
    SELECT
      md5(concat_ws('|', trade_wide.scenic_id, metric.target_name, trade_wide.date_type,
          date_format(date_sub('${today}', 1), 'yyyyMMdd')))              AS key_id,
      trade_wide.scenic_id                                                    AS scenic_id,
      cast(t2.scenic_name AS string)                                                    AS scenic_name,
      cast('OTA直销-指标' AS string)                                                    AS indicator_domain,
      metric.target_name                                                      AS target_name,
      metric.target_desc                                                      AS target_desc,
      trade_wide.date_type                                                    AS date_type,
      metric.data_value                                                       AS data_value,
      'OTA直销'                                                               AS data_domain,
      cast(date_format(date_sub('${today}', 1), 'yyyyMMdd') AS int)      AS travel_date
    FROM trade_wide
    left join dim_prd_scenic_supplier_relation_f t2
    ON  trade_wide.scenic_id = t2.scenic_id
    LATERAL VIEW explode(array(
      named_struct('target_name', '成交销售额',     'target_desc', '成交销售额（元）',     'data_value', cast(total_amount            AS decimal(10,2))),
      named_struct('target_name', '成交销售额环比', 'target_desc', '成交销售额环比（%）',   'data_value', cast(total_amount_mom_rate   AS decimal(10,2))),
      named_struct('target_name', '成交销售额同比', 'target_desc', '成交销售额同比（%）',   'data_value', cast(total_amount_yoy_rate   AS decimal(10,2))),
      named_struct('target_name', '订单数',         'target_desc', '订单数（笔）',         'data_value', cast(total_order_num         AS decimal(10,2))),
      named_struct('target_name', '订单数环比',     'target_desc', '订单数环比（%）',       'data_value', cast(total_order_num_mom_rate  AS decimal(10,2))),
      named_struct('target_name', '成交票量',       'target_desc', '成交票量（张）',       'data_value', cast(deal_ticket_qty         AS decimal(10,2))),
      named_struct('target_name', '成交票量环比',   'target_desc', '成交票量环比（%）',     'data_value', cast(deal_ticket_qty_mom_rate AS decimal(10,2))),
      named_struct('target_name', '核验票量',       'target_desc', '核验票量（张）',       'data_value', cast(verify_ticket_qty       AS decimal(10,2))),
      named_struct('target_name', '核验票量环比',   'target_desc', '核验票量环比（%）',     'data_value', cast(verify_ticket_qty_mom_rate AS decimal(10,2))),
      named_struct('target_name', '成交资源数',     'target_desc', '成交资源数',           'data_value', cast(deal_resource_qty       AS decimal(10,2))),
      named_struct('target_name', '成交资源数环比', 'target_desc', '成交资源数环比（%）',   'data_value', cast(deal_resource_qty_mom_rate AS decimal(10,2))),
      named_struct('target_name', '退订率',         'target_desc', '退订率（%）',           'data_value', cast(cancel_order_num_rate   AS decimal(10,2)))
    )) tmp AS metric
  ),
  -- ==================== 评分雷达图（月度） ====================
  score_base AS (
    -- 上月（T+1）：如今天 2026-10-14 → '2026-09'
    SELECT date_format(add_months('${today}', -1), 'yyyy-MM') AS evaluation_month
  ),
  score_scenic_month AS (
    -- region 粒度上卷到景区粒度：同一景区多个地区取均值（NULL 默认 3）
    SELECT
      t1.scenic_id,
      avg(coalesce(t1.ocr_score, 3))                      AS ocr_score,
      avg(coalesce(t1.fdr_score, 3))                      AS fdr_score,
      avg(coalesce(t1.manual_intervention_rate_score, 3)) AS manual_intervention_rate_score,
      avg(coalesce(t1.timely_response_20s_score, 3))      AS timely_response_20s_score,
      avg(coalesce(t1.im_neg_rate_score, 3))              AS im_neg_rate_score
    FROM ads_sup_ota_ctrip_score_di t1
    CROSS JOIN score_base
    WHERE t1.evaluation_month = score_base.evaluation_month
      AND t1.scenic_id IS NOT NULL
    GROUP BY t1.scenic_id
  ),
  score_global_avg AS (
    -- 全景区均值：对所有景区再取一次平均
    SELECT
      avg(ocr_score)                      AS ocr_score_avg,
      avg(fdr_score)                      AS fdr_score_avg,
      avg(manual_intervention_rate_score) AS manual_intervention_rate_score_avg,
      avg(timely_response_20s_score)      AS timely_response_20s_score_avg,
      avg(im_neg_rate_score)              AS im_neg_rate_score_avg
    FROM score_scenic_month
  ),
  score_wide AS (
    SELECT
      s.scenic_id,
      t2.scenic_name,
      s.ocr_score                      AS own_ocr,
      s.fdr_score                      AS own_fdr,
      s.manual_intervention_rate_score AS own_manual,
      s.timely_response_20s_score      AS own_timely,
      s.im_neg_rate_score              AS own_im_neg,
      g.ocr_score_avg                      AS among_ocr,
      g.fdr_score_avg                      AS among_fdr,
      g.manual_intervention_rate_score_avg AS among_manual,
      g.timely_response_20s_score_avg      AS among_timely,
      g.im_neg_rate_score_avg              AS among_im_neg
    FROM score_scenic_month s
    left join dim_prd_scenic_supplier_relation_f t2
    ON  s.scenic_id = t2.scenic_id
    CROSS JOIN score_global_avg g
  ),
  score_long AS (
    SELECT
      md5(concat_ws('|', score_wide.scenic_id, metric.target_name, 'month',
          date_format(date_sub('${today}', 1), 'yyyyMMdd')))              AS key_id,
      score_wide.scenic_id                                                    AS scenic_id,
      cast(score_wide.scenic_name AS string)                                                    AS scenic_name,
      cast('OTA直销-雷达图' AS string)                                                    AS indicator_domain,
      metric.target_name                                                      AS target_name,
      metric.target_name                                                      AS target_desc,
      'month'                                                                 AS date_type,
      metric.data_value                                                       AS data_value,
      'OTA直销'                                                               AS data_domain,
      cast(date_format(date_sub('${today}', 1), 'yyyyMMdd') AS int)      AS travel_date
    FROM score_wide
    LATERAL VIEW explode(array(
      -- 全景区最大值 = 常量 5
      named_struct('target_name', '全景区最大值-N分钟订单确认率',    'data_value', cast(5.00 AS decimal(10,2))),
      named_struct('target_name', '全景区最大值-履约缺陷率',        'data_value', cast(5.00 AS decimal(10,2))),
      named_struct('target_name', '全景区最大值-客服人工介入率',    'data_value', cast(5.00 AS decimal(10,2))),
      named_struct('target_name', '全景区最大值-IM120秒回复及时率', 'data_value', cast(5.00 AS decimal(10,2))),
      named_struct('target_name', '全景区最大值-电话接通率',        'data_value', cast(5.00 AS decimal(10,2))),
      -- 全景区均值
      named_struct('target_name', '全景区均值-N分钟订单确认率',    'data_value', cast(among_ocr    AS decimal(10,2))),
      named_struct('target_name', '全景区均值-履约缺陷率',        'data_value', cast(among_fdr    AS decimal(10,2))),
      named_struct('target_name', '全景区均值-客服人工介入率',    'data_value', cast(among_manual AS decimal(10,2))),
      named_struct('target_name', '全景区均值-IM120秒回复及时率', 'data_value', cast(among_timely AS decimal(10,2))),
      named_struct('target_name', '全景区均值-电话接通率',        'data_value', cast(among_im_neg AS decimal(10,2))),
      -- 本景区值
      named_struct('target_name', '本景区值-N分钟订单确认率',    'data_value', cast(own_ocr    AS decimal(10,2))),
      named_struct('target_name', '本景区值-履约缺陷率',        'data_value', cast(own_fdr    AS decimal(10,2))),
      named_struct('target_name', '本景区值-客服人工介入率',    'data_value', cast(own_manual AS decimal(10,2))),
      named_struct('target_name', '本景区值-IM120秒回复及时率', 'data_value', cast(own_timely AS decimal(10,2))),
      named_struct('target_name', '本景区值-电话接通率',        'data_value', cast(own_im_neg AS decimal(10,2)))
    )) tmp AS metric
  )


INSERT OVERWRITE TABLE ads_digital_brain_target_merge_di PARTITION(data_domain, travel_date)
SELECT
  key_id, scenic_id, scenic_name, indicator_domain, target_name, target_desc, date_type, data_value, data_domain, travel_date
FROM trade_long
where scenic_id IN ('PFTSCA01018088','PFTSCA01016184','PFTSCA01018066','PFTSCZ01022547')
UNION ALL
SELECT
  key_id, scenic_id, scenic_name, indicator_domain, target_name, target_desc, date_type, data_value, data_domain, travel_date
FROM score_long
where scenic_id IN ('PFTSCA01018088','PFTSCA01016184','PFTSCA01018066','PFTSCZ01022547')
;



INSERT INTO TABLE ads_digital_brain_target_merge_di PARTITION(data_domain, travel_date)
SELECT concat(key_id,'_mock'), --拼接字符
    'PFTSCM00000001' AS scenic_id,
    'A级景区'scenic_name,
    indicator_domain,
    target_name,
    target_desc,
    date_type,
    data_value,
    data_domain,
    travel_date
FROM  ads_digital_brain_target_merge_di
WHERE data_domain = 'OTA直销'
AND scenic_id = 'PFTSCA01018088'
AND travel_date = ${yesterday}
;




