--Serverless Spark SQL
--********************************************************************--
--author: 韩瑞
--create time: 2026-10-19 11:23:28
--Serverless Spark SQL任务只能运行在独享资源组上
--********************************************************************--


-- DROP TABLE if EXISTS ads_digital_brain_target_merge_di;
-- CREATE TABLE IF NOT EXISTS ads_digital_brain_target_merge_di
-- (
--     `key_id`            STRING COMMENT '唯一值【拼接字符串生成的md5】'
--     ,`scenic_id`        STRING COMMENT '景区ID'
--     ,`scenic_name`      STRING COMMENT '景区名称'
--     ,`indicator_domain` STRING COMMENT '指标域【具体位置描述，没有默认null】'
--     ,`target_name`      STRING COMMENT '指标名称'
--     ,`target_desc`      STRING COMMENT '指标描述'
--     ,`date_type`        STRING COMMENT '时间类型 1d:昨日,7d:近7日,30d:近30日,90d:近90日,180d:近半年,week:本周, month:本月'
--     ,`data_value`       DECIMAL(10,2) COMMENT '指标值'
-- )
-- COMMENT '数字大脑-统一指标表'
-- PARTITIONED BY 
-- (
--     data_domain      STRING COMMENT '数据域【总览｜票务｜客流花香｜舆情｜OTA直销】'
--     ,travel_date         INT COMMENT '统计日期'
-- )
-- STORED AS ORC
-- ;

INSERT OVERWRITE TABLE ads_digital_brain_target_merge_di PARTITION(data_domain, travel_date)

  WITH macro_base AS (
      SELECT
          scenic_id,
          scenic_name,
          channel,
          channel_name,
          CASE time_granularity
              WHEN 'td'         THEN 'td'
              WHEN 'wtd'        THEN 'week'
              WHEN 'mtd'        THEN 'month'
              WHEN 'qtd'        THEN 'quarter'
              WHEN 'latest_1d'  THEN '1d'
              WHEN 'latest_7d'  THEN '7d'
              WHEN 'latest_30d' THEN '30d'
              WHEN 'latest_60d' THEN '60d'
              WHEN 'latest_90d' THEN '90d'
          END AS date_type,
          travel_date,
          overall_sentiment_score,
          comment_total,
          comment_rate,
          comment_total_yoy,
          comment_total_mom,
          positive_comment_cnt,
          neutral_comment_cnt,
          negative_comment_cnt,
          positive_comment_rate,
          neutral_comment_rate,
          negative_comment_rate,
          positive_comment_mom,
          neutral_comment_mom,
          negative_comment_mom,
          positive_comment_yoy,
          neutral_comment_yoy,
          negative_comment_yoy,
          dimension_breakdown,
          wordcloud_map
      FROM ads_trf_social_opinion_macro_gran_metric_di
      WHERE travel_date = cast(date_format(date_sub(current_date(), 1), 'yyyyMMdd') AS int)
        AND scenic_id IS NOT NULL
        AND scenic_id != ''
        AND scenic_id IN ('PFTSCA01018088','PFTSCA01016184','PFTSCA01018066','PFTSCZ01022547')
  ),

  macro_long AS (
      SELECT
          scenic_id, scenic_name, channel, travel_date,
          metric.indicator_domain, metric.target_name, metric.target_desc, metric.date_type, metric.data_value
      FROM macro_base
      LATERAL VIEW explode(array(
          named_struct('indicator_domain', '舆情-游客综合评价得分', 'target_name', '游客综合评价得分', 'target_desc', channel_name, 'date_type', date_type, 'data_value', cast(overall_sentiment_score AS
  decimal(10,2))),

          named_struct('indicator_domain', '舆情-平台评论分布', 'target_name', '总评论数',   'target_desc', channel_name, 'date_type', date_type, 'data_value', cast(comment_total     AS decimal(10,2))),
          named_struct('indicator_domain', '舆情-平台评论分布', 'target_name', '评论占比',   'target_desc', channel_name, 'date_type', date_type, 'data_value', cast(comment_rate      AS decimal(10,2))),
          named_struct('indicator_domain', '舆情-平台评论分布', 'target_name', '总评论数同比', 'target_desc', channel_name, 'date_type', date_type, 'data_value', cast(comment_total_yoy AS decimal(10,2))),
          named_struct('indicator_domain', '舆情-平台评论分布', 'target_name', '总评论数环比', 'target_desc', channel_name, 'date_type', date_type, 'data_value', cast(comment_total_mom AS decimal(10,2))),

          named_struct('indicator_domain', '舆情-情绪趋势', 'target_name', '好评数', 'target_desc', channel_name, 'date_type', date_type, 'data_value', cast(positive_comment_cnt AS decimal(10,2))),
          named_struct('indicator_domain', '舆情-情绪趋势', 'target_name', '中评数', 'target_desc', channel_name, 'date_type', date_type, 'data_value', cast(neutral_comment_cnt  AS decimal(10,2))),
          named_struct('indicator_domain', '舆情-情绪趋势', 'target_name', '差评数', 'target_desc', channel_name, 'date_type', date_type, 'data_value', cast(negative_comment_cnt AS decimal(10,2))),

          named_struct('indicator_domain', '舆情-评价得分、情绪占比、评论数', 'target_name', '好评占比', 'target_desc', channel_name, 'date_type', date_type, 'data_value', cast(positive_comment_rate AS
  decimal(10,2))),
          named_struct('indicator_domain', '舆情-评价得分、情绪占比、评论数', 'target_name', '中评占比', 'target_desc', channel_name, 'date_type', date_type, 'data_value', cast(neutral_comment_rate  AS
  decimal(10,2))),
          named_struct('indicator_domain', '舆情-评价得分、情绪占比、评论数', 'target_name', '差评占比', 'target_desc', channel_name, 'date_type', date_type, 'data_value', cast(negative_comment_rate AS
  decimal(10,2))),
          named_struct('indicator_domain', '舆情-评价得分、情绪占比、评论数', 'target_name', '好评环比', 'target_desc', channel_name, 'date_type', date_type, 'data_value', cast(positive_comment_mom AS
  decimal(10,2))),
          named_struct('indicator_domain', '舆情-评价得分、情绪占比、评论数', 'target_name', '中评环比', 'target_desc', channel_name, 'date_type', date_type, 'data_value', cast(neutral_comment_mom  AS
  decimal(10,2))),
          named_struct('indicator_domain', '舆情-评价得分、情绪占比、评论数', 'target_name', '差评环比', 'target_desc', channel_name, 'date_type', date_type, 'data_value', cast(negative_comment_mom AS
  decimal(10,2))),
          named_struct('indicator_domain', '舆情-评价得分、情绪占比、评论数', 'target_name', '好评同比', 'target_desc', channel_name, 'date_type', date_type, 'data_value', cast(positive_comment_yoy AS
  decimal(10,2))),
          named_struct('indicator_domain', '舆情-评价得分、情绪占比、评论数', 'target_name', '中评同比', 'target_desc', channel_name, 'date_type', date_type, 'data_value', cast(neutral_comment_yoy  AS
  decimal(10,2))),
          named_struct('indicator_domain', '舆情-评价得分、情绪占比、评论数', 'target_name', '差评同比', 'target_desc', channel_name, 'date_type', date_type, 'data_value', cast(negative_comment_yoy AS
  decimal(10,2)))
      )) t AS metric
  ),

  dimension_split AS (
      SELECT scenic_id, scenic_name, channel, date_type, travel_date,
             d.dimension1,
             d.dimension1Score,
             d.preDimension1Score
      FROM macro_base
      LATERAL VIEW explode(
          from_json(dimension_breakdown,
              'array<struct<dimension1:string,dimension1Score:double,preDimension1:string,preDimension1Score:double>>')
      ) t AS d
  ),

  dimension_long AS (
      SELECT scenic_id, scenic_name, channel, travel_date,
             '舆情-各维度游客满意度评分'               AS indicator_domain,
             concat(dimension1, '-满意度评分')         AS target_name,
             concat(dimension1, '维度')               AS target_desc,
             date_type,
             cast(dimension1Score AS decimal(10,2))   AS data_value
      FROM dimension_split
      UNION ALL
      SELECT scenic_id, scenic_name, channel, travel_date,
             '舆情-各维度游客满意度评分'               AS indicator_domain,
             concat(dimension1, '-上期满意度评分')     AS target_name,
             concat(dimension1, '维度')               AS target_desc,
             date_type,
             cast(preDimension1Score AS decimal(10,2)) AS data_value
      FROM dimension_split
  ),

  wordcloud_raw AS (
      SELECT scenic_id, scenic_name, channel, date_type, travel_date,
             from_json(wordcloud_map,
                 'struct<positiveWord:array<struct<word:string,rate:double>>,neutralWord:array<struct<word:string,rate:double>>,negativeWord:array<struct<word:string,rate:double>>>'
             ) AS wc
      FROM macro_base
  ),

  wordcloud_long AS (
      SELECT scenic_id, scenic_name, channel, travel_date,
             '舆情-正向词'                 AS indicator_domain,
             '舆情-正向词'                 AS target_name,
             w.word                       AS target_desc,
             date_type,
             cast(w.rate AS decimal(10,2)) AS data_value
      FROM wordcloud_raw
      LATERAL VIEW explode(wc.positiveWord) t AS w
      UNION ALL
      SELECT scenic_id, scenic_name, channel, travel_date,
             '舆情-负向词'                 AS indicator_domain,
             '舆情-负向词'                 AS target_name,
             w.word                       AS target_desc,
             date_type,
             cast(w.rate AS decimal(10,2)) AS data_value
      FROM wordcloud_raw
      LATERAL VIEW explode(wc.negativeWord) t AS w
  )


  SELECT
      md5(concat_ws('|', scenic_id, channel, target_name, target_desc, date_type, cast(travel_date AS string))) AS key_id,
      scenic_id,
      scenic_name,
      indicator_domain,
      target_name,
      target_desc,
      date_type,
      data_value,
      '舆情' AS data_domain,
      travel_date
  FROM (
      SELECT scenic_id, scenic_name, channel, travel_date,
             indicator_domain, target_name, target_desc, date_type, data_value
      FROM macro_long
      UNION ALL
      SELECT scenic_id, scenic_name, channel, travel_date,
             indicator_domain, target_name, target_desc, date_type, data_value
      FROM dimension_long
      UNION ALL
      SELECT scenic_id, scenic_name, channel, travel_date,
             indicator_domain, target_name, target_desc, date_type, data_value
      FROM wordcloud_long
  )
  ;





-- 分表写法
--   SET hive.exec.dynamic.partition=true;
--   SET hive.exec.dynamic.partition.mode=nonstrict;
--   SET spark.sql.sources.partitionOverwriteMode=dynamic;

--   WITH social_base AS (
--       -- 昨日分区，按 (景区, 一级维度) 聚合去重
--       -- 源表同一 dimension_level1 下可能有多行（对应不同 level2/level3），
--       -- 一级维度分数取 max 作为确定性去重（同一 level1 下该值应一致）
--       SELECT
--           scenic_spot_code,
--           max(scenic_spot_name)      AS scenic_spot_name,
--           dimension_level1,
--           max(dimension_1_score)      AS score_1d,
--           max(dimension_1_score_7d)   AS score_7d,
--           max(dimension_1_score_30d)  AS score_30d,
--           max(dimension_1_score_60d)  AS score_60d,
--           max(dimension_1_score_90d)  AS score_90d 
--       FROM ads_trf_social_opinion_comment_dimension_score_di
--       WHERE travel_date = cast(date_format(date_sub(current_date(), 1), 'yyyyMMdd') AS int)
--         AND dimension_level1 IS NOT NULL
--       GROUP BY scenic_spot_code, dimension_level1
--   ),
--   social_long AS (
--       -- 宽表 → 长表：每个 (景区, 一级维度) 展开成 5 行
--       SELECT
--           scenic_spot_code,
--           scenic_spot_name,
--           metric.target_name,
--           metric.target_desc,
--           metric.date_type,
--           metric.data_value
--       FROM social_base
--       LATERAL VIEW explode(array(
--           named_struct('target_name', concat(dimension_level1, '-满意度评分'), 'target_desc', concat(dimension_level1, '维度满意度评分'), 'date_type', '1d',  'data_value', cast(score_1d  AS decimal(10,2))),
--           named_struct('target_name', concat(dimension_level1, '-满意度评分'), 'target_desc', concat(dimension_level1, '维度满意度评分'), 'date_type', '7d',  'data_value', cast(score_7d  AS decimal(10,2))),
--           named_struct('target_name', concat(dimension_level1, '-满意度评分'), 'target_desc', concat(dimension_level1, '维度满意度评分'), 'date_type', '30d', 'data_value', cast(score_30d AS decimal(10,2))),
--           named_struct('target_name', concat(dimension_level1, '-满意度评分'), 'target_desc', concat(dimension_level1, '维度满意度评分'), 'date_type', '60d', 'data_value', cast(score_60d AS decimal(10,2))),
--           named_struct('target_name', concat(dimension_level1, '-满意度评分'), 'target_desc', concat(dimension_level1, '维度满意度评分'), 'date_type', '90d', 'data_value', cast(score_90d AS decimal(10,2)))
--       )) t AS metric
--   )

--   INSERT OVERWRITE TABLE ads_digital_brain_target_merge_di PARTITION(data_domain, travel_date)
--   SELECT
--       md5(concat_ws('|',
--           scenic_spot_code,
--           target_name,
--           date_type,
--           date_format(date_sub(current_date(), 1), 'yyyyMMdd')
--       ))                                AS key_id,
--       scenic_spot_code                  AS scenic_id,
--       scenic_spot_name                  AS scenic_name,
--       cast('舆情-各维度游客满意度评分' AS string)              AS indicator_domain,
--       target_name,
--       target_desc,
--       date_type,
--       data_value,
--       '舆情'                            AS data_domain,
--       cast(date_format(date_sub(current_date(), 1), 'yyyyMMdd') AS int) AS travel_date
--   FROM social_long;





-- WITH platform_raw AS (
--       -- 昨日分区
--       SELECT *
--       FROM ads_trf_social_opinion_comment_platform_di
--       WHERE travel_date = cast(date_format(date_sub(current_date(), 1), 'yyyyMMdd') AS int)
--         AND scenic_spot_code IS NOT NULL
--         AND platform_code  IS NOT NULL
--   ),
--   platform_dedup AS (
--       -- 同 (景区, 渠道) 若有多行（唯一键含 publish_time），取 etl_time 最新那行
--       SELECT *
--       FROM (
--           SELECT
--               *,
--               row_number() OVER (
--                   PARTITION BY scenic_spot_code, platform_code
--                   ORDER BY etl_time DESC
--               ) AS rn
--           FROM platform_raw
--       ) t
--       WHERE rn = 1
--   ),
--   platform_wide AS (
--       -- 渠道评论占比分母：该景区全部渠道评论数合计（窗口函数，同一景区所有渠道一起算）
--       SELECT
--           scenic_spot_code,
--           scenic_spot_name,
--           platform_name,
--           platform_code,
--           comment_rate,
--           good_rate_1d, week_good_rate, mon_good_rate, good_rate_60d, good_rate_90d,
--           comment_cnt, comment_cnt_7d, comment_cnt_30d, comment_cnt_60d, comment_cnt_90d,
--           plat_positive_count, plat_positive_7d_count, plat_positive_30d_count, plat_positive_60d_count, plat_positive_90d_count,
--           good_rate_wow_1d, week_good_rate_wow, mon_good_rate_wow, good_rate_wow_60d, good_rate_wow_90d,
--           sum(comment_cnt)     OVER (PARTITION BY scenic_spot_code) AS sum_comment_cnt_1d,
--           sum(comment_cnt_7d)  OVER (PARTITION BY scenic_spot_code) AS sum_comment_cnt_7d,
--           sum(comment_cnt_30d) OVER (PARTITION BY scenic_spot_code) AS sum_comment_cnt_30d,
--           sum(comment_cnt_60d) OVER (PARTITION BY scenic_spot_code) AS sum_comment_cnt_60d,
--           sum(comment_cnt_90d) OVER (PARTITION BY scenic_spot_code) AS sum_comment_cnt_90d
--       FROM platform_dedup
--   ),
--   platform_long AS (
--       -- 宽表 → 长表：每个 (景区, 渠道) 展开成 26 行
--       SELECT
--           scenic_spot_code,
--           scenic_spot_name,
--           platform_name,
--           platform_code,
--           metric.target_name,
--           metric.target_desc,
--           metric.date_type,
--           metric.data_value
--       FROM platform_wide
--       LATERAL VIEW explode(array(
--           -- 好评占比 ×5（×100 统一成百分比）
--           named_struct('target_name', '好评占比', 'target_desc', platform_name, 'date_type', '1d',  'data_value', cast(round(good_rate_1d  * 100, 2) AS decimal(10,2))),
--           named_struct('target_name', '好评占比', 'target_desc', platform_name, 'date_type', '7d',  'data_value', cast(round(week_good_rate * 100, 2) AS decimal(10,2))),
--           named_struct('target_name', '好评占比', 'target_desc', platform_name, 'date_type', '30d', 'data_value', cast(round(mon_good_rate  * 100, 2) AS decimal(10,2))),
--           named_struct('target_name', '好评占比', 'target_desc', platform_name, 'date_type', '60d', 'data_value', cast(round(good_rate_60d  * 100, 2) AS decimal(10,2))),
--           named_struct('target_name', '好评占比', 'target_desc', platform_name, 'date_type', '90d', 'data_value', cast(round(good_rate_90d  * 100, 2) AS decimal(10,2))),
--           -- 总评数 ×5
--           named_struct('target_name', '总评数', 'target_desc', platform_name, 'date_type', '1d',  'data_value', cast(comment_cnt     AS decimal(10,2))),
--           named_struct('target_name', '总评数', 'target_desc', platform_name, 'date_type', '7d',  'data_value', cast(comment_cnt_7d  AS decimal(10,2))),
--           named_struct('target_name', '总评数', 'target_desc', platform_name, 'date_type', '30d', 'data_value', cast(comment_cnt_30d AS decimal(10,2))),
--           named_struct('target_name', '总评数', 'target_desc', platform_name, 'date_type', '60d', 'data_value', cast(comment_cnt_60d AS decimal(10,2))),
--           named_struct('target_name', '总评数', 'target_desc', platform_name, 'date_type', '90d', 'data_value', cast(comment_cnt_90d AS decimal(10,2))),
--           -- 好评数 ×5
--           named_struct('target_name', '好评数', 'target_desc', platform_name, 'date_type', '1d',  'data_value', cast(plat_positive_count     AS decimal(10,2))),
--           named_struct('target_name', '好评数', 'target_desc', platform_name, 'date_type', '7d',  'data_value', cast(plat_positive_7d_count  AS decimal(10,2))),
--           named_struct('target_name', '好评数', 'target_desc', platform_name, 'date_type', '30d', 'data_value', cast(plat_positive_30d_count AS decimal(10,2))),
--           named_struct('target_name', '好评数', 'target_desc', platform_name, 'date_type', '60d', 'data_value', cast(plat_positive_60d_count AS decimal(10,2))),
--           named_struct('target_name', '好评数', 'target_desc', platform_name, 'date_type', '90d', 'data_value', cast(plat_positive_90d_count AS decimal(10,2))),
--           -- 好评环比 ×5（×100 统一成百分比）
--           named_struct('target_name', '好评环比', 'target_desc', platform_name, 'date_type', '1d',  'data_value', cast(round(good_rate_wow_1d  * 100, 2) AS decimal(10,2))),
--           named_struct('target_name', '好评环比', 'target_desc', platform_name, 'date_type', '7d',  'data_value', cast(round(week_good_rate_wow * 100, 2) AS decimal(10,2))),
--           named_struct('target_name', '好评环比', 'target_desc', platform_name, 'date_type', '30d', 'data_value', cast(round(mon_good_rate_wow  * 100, 2) AS decimal(10,2))),
--           named_struct('target_name', '好评环比', 'target_desc', platform_name, 'date_type', '60d', 'data_value', cast(round(good_rate_wow_60d  * 100, 2) AS decimal(10,2))),
--           named_struct('target_name', '好评环比', 'target_desc', platform_name, 'date_type', '90d', 'data_value', cast(round(good_rate_wow_90d  * 100, 2) AS decimal(10,2))),
--           -- 渠道评论占比 ×5（comment_cnt / 该景区合计 ×100）
--           named_struct('target_name', '渠道评论占比', 'target_desc', platform_name, 'date_type', '1d',  'data_value', cast(round(comment_cnt     * 100.0 / nullif(sum_comment_cnt_1d,  0), 2) AS decimal(10,2))),
--           named_struct('target_name', '渠道评论占比', 'target_desc', platform_name, 'date_type', '7d',  'data_value', cast(round(comment_cnt_7d  * 100.0 / nullif(sum_comment_cnt_7d,  0), 2) AS decimal(10,2))),
--           named_struct('target_name', '渠道评论占比', 'target_desc', platform_name, 'date_type', '30d', 'data_value', cast(round(comment_cnt_30d * 100.0 / nullif(sum_comment_cnt_30d, 0), 2) AS decimal(10,2))),
--           named_struct('target_name', '渠道评论占比', 'target_desc', platform_name, 'date_type', '60d', 'data_value', cast(round(comment_cnt_60d * 100.0 / nullif(sum_comment_cnt_60d, 0), 2) AS decimal(10,2))),
--           named_struct('target_name', '渠道评论占比', 'target_desc', platform_name, 'date_type', '90d', 'data_value', cast(round(comment_cnt_90d * 100.0 / nullif(sum_comment_cnt_90d, 0), 2) AS decimal(10,2))),
--           -- 评论占比 ×1（单值，无窗口，先用 1d）
--           named_struct('target_name', '评论占比', 'target_desc', platform_name, 'date_type', '1d',  'data_value', cast(round(comment_rate * 100, 2) AS decimal(10,2)))
--       )) t AS metric
--   )
--   INSERT OVERWRITE TABLE ads_digital_brain_target_merge_di PARTITION(data_domain, travel_date)
--   SELECT
--       md5(concat_ws('|',
--           scenic_spot_code,
--           platform_code,
--           target_name,
--           date_type,
--           date_format(date_sub(current_date(), 1), 'yyyyMMdd')
--       ))                                AS key_id,
--       scenic_spot_code                  AS scenic_id,
--       scenic_spot_name                  AS scenic_name,
--       cast('舆情-平台评论分布' AS string) AS indicator_domain,
--       target_name,
--       target_desc,
--       date_type,
--       data_value,
--       '舆情'                            AS data_domain,
--       cast(date_format(date_sub(current_date(), 1), 'yyyyMMdd') AS int) AS travel_date
--   FROM platform_long;



--   WITH core_raw AS (
--       -- 拉 91 天数据用于滚动求和（近90日需 89 天前数据，多 1 天余量）
--       SELECT *
--       FROM ads_trf_social_opinion_comment_core_di
--       WHERE travel_date BETWEEN cast(date_format(date_sub(current_date(), 91), 'yyyyMMdd') AS int)
--                             AND cast(date_format(date_sub(current_date(), 1),  'yyyyMMdd') AS int)
--         AND scenic_spot_code IS NOT NULL
--   ),
--   core_dedup AS (
--       -- 同 (景区,天) 若有多行（唯一键含 publish_time），取 etl_time 最新，保证一天一行
--       SELECT *
--       FROM (
--           SELECT
--               *,
--               row_number() OVER (
--                   PARTITION BY scenic_spot_code, travel_date
--                   ORDER BY etl_time DESC
--               ) AS rn
--           FROM core_raw
--       ) t
--       WHERE rn = 1
--   ),
--   core_wide AS (
--       -- 评论数滚动求和：按天排序，6/29/59/89 前推（窗口函数）
--       SELECT
--           scenic_spot_code,
--           scenic_spot_name,
--           travel_date,
--           comment_count,
--           positive_count,
--           neutral_count,
--           negative_count,
--           emotional_score,
--           emotional_score_7d,
--           emotional_score_30d,
--           emotional_score_60d,
--           emotional_score_90d,
--           positive_rate_7d,
--           positive_rate_30d,
--           positive_rate_60d,
--           positive_rate_90d,
--           neutral_rate_7d,
--           neutral_rate_30d,
--           neutral_rate_60d,
--           neutral_rate_90d,
--           negative_rate_7d,
--           negative_rate_30d,
--           negative_rate_60d,
--           negative_rate_90d,
--           comment_count_dod,
--           comment_count_wow,
--           comment_count_mom,
--           comment_count_60dod,
--           comment_count_90dod,
--           sum(comment_count) OVER (PARTITION BY scenic_spot_code ORDER BY travel_date ROWS BETWEEN 6  PRECEDING AND CURRENT ROW) AS comment_count_7d,
--           sum(comment_count) OVER (PARTITION BY scenic_spot_code ORDER BY travel_date ROWS BETWEEN 29 PRECEDING AND CURRENT ROW) AS comment_count_30d,
--           sum(comment_count) OVER (PARTITION BY scenic_spot_code ORDER BY travel_date ROWS BETWEEN 59 PRECEDING AND CURRENT ROW) AS comment_count_60d,
--           sum(comment_count) OVER (PARTITION BY scenic_spot_code ORDER BY travel_date ROWS BETWEEN 89 PRECEDING AND CURRENT ROW) AS comment_count_90d
--       FROM core_dedup
--   ),
--   core_yesterday AS (
--       SELECT *
--       FROM core_wide
--       WHERE travel_date = cast(date_format(date_sub(current_date(), 1), 'yyyyMMdd') AS int)
--   ),
--   core_long AS (
--       SELECT
--           scenic_spot_code,
--           scenic_spot_name,
--           metric.target_name,
--           metric.target_desc,
--           metric.date_type,
--           metric.data_value
--       FROM core_yesterday
--       LATERAL VIEW explode(array(
--           -- 好评率 ×5（1d 现算，7d+ 预计算列 ×100）
--           named_struct('target_name', '好评率', 'target_desc', cast(NULL AS string), 'date_type', '1d',  'data_value', cast(round(positive_count * 100.0 / nullif(comment_count, 0), 2) AS decimal(10,2))),
--           named_struct('target_name', '好评率', 'target_desc', cast(NULL AS string), 'date_type', '7d',  'data_value', cast(round(positive_rate_7d  * 100, 2) AS decimal(10,2))),
--           named_struct('target_name', '好评率', 'target_desc', cast(NULL AS string), 'date_type', '30d', 'data_value', cast(round(positive_rate_30d * 100, 2) AS decimal(10,2))),
--           named_struct('target_name', '好评率', 'target_desc', cast(NULL AS string), 'date_type', '60d', 'data_value', cast(round(positive_rate_60d * 100, 2) AS decimal(10,2))),
--           named_struct('target_name', '好评率', 'target_desc', cast(NULL AS string), 'date_type', '90d', 'data_value', cast(round(positive_rate_90d * 100, 2) AS decimal(10,2))),
--           -- 中评率 ×5
--           named_struct('target_name', '中评率', 'target_desc', cast(NULL AS string), 'date_type', '1d',  'data_value', cast(round(neutral_count * 100.0 / nullif(comment_count, 0), 2) AS decimal(10,2))),
--           named_struct('target_name', '中评率', 'target_desc', cast(NULL AS string), 'date_type', '7d',  'data_value', cast(round(neutral_rate_7d  * 100, 2) AS decimal(10,2))),
--           named_struct('target_name', '中评率', 'target_desc', cast(NULL AS string), 'date_type', '30d', 'data_value', cast(round(neutral_rate_30d * 100, 2) AS decimal(10,2))),
--           named_struct('target_name', '中评率', 'target_desc', cast(NULL AS string), 'date_type', '60d', 'data_value', cast(round(neutral_rate_60d * 100, 2) AS decimal(10,2))),
--           named_struct('target_name', '中评率', 'target_desc', cast(NULL AS string), 'date_type', '90d', 'data_value', cast(round(neutral_rate_90d * 100, 2) AS decimal(10,2))),
--           -- 差评率 ×5
--           named_struct('target_name', '差评率', 'target_desc', cast(NULL AS string), 'date_type', '1d',  'data_value', cast(round(negative_count * 100.0 / nullif(comment_count, 0), 2) AS decimal(10,2))),
--           named_struct('target_name', '差评率', 'target_desc', cast(NULL AS string), 'date_type', '7d',  'data_value', cast(round(negative_rate_7d  * 100, 2) AS decimal(10,2))),
--           named_struct('target_name', '差评率', 'target_desc', cast(NULL AS string), 'date_type', '30d', 'data_value', cast(round(negative_rate_30d * 100, 2) AS decimal(10,2))),
--           named_struct('target_name', '差评率', 'target_desc', cast(NULL AS string), 'date_type', '60d', 'data_value', cast(round(negative_rate_60d * 100, 2) AS decimal(10,2))),
--           named_struct('target_name', '差评率', 'target_desc', cast(NULL AS string), 'date_type', '90d', 'data_value', cast(round(negative_rate_90d * 100, 2) AS decimal(10,2))),
--           -- 游客综合评价得分 ×5（原始 0-100，不 ×100）
--           named_struct('target_name', '游客综合评价得分', 'target_desc', cast(NULL AS string), 'date_type', '1d',  'data_value', cast(emotional_score    AS decimal(10,2))),
--           named_struct('target_name', '游客综合评价得分', 'target_desc', cast(NULL AS string), 'date_type', '7d',  'data_value', cast(emotional_score_7d  AS decimal(10,2))),
--           named_struct('target_name', '游客综合评价得分', 'target_desc', cast(NULL AS string), 'date_type', '30d', 'data_value', cast(emotional_score_30d AS decimal(10,2))),
--           named_struct('target_name', '游客综合评价得分', 'target_desc', cast(NULL AS string), 'date_type', '60d', 'data_value', cast(emotional_score_60d AS decimal(10,2))),
--           named_struct('target_name', '游客综合评价得分', 'target_desc', cast(NULL AS string), 'date_type', '90d', 'data_value', cast(emotional_score_90d AS decimal(10,2))),
--           -- 评论数 ×5（1d 原始，7d+ 滚动求和）
--           named_struct('target_name', '评论数', 'target_desc', cast(NULL AS string), 'date_type', '1d',  'data_value', cast(comment_count     AS decimal(10,2))),
--           named_struct('target_name', '评论数', 'target_desc', cast(NULL AS string), 'date_type', '7d',  'data_value', cast(comment_count_7d  AS decimal(10,2))),
--           named_struct('target_name', '评论数', 'target_desc', cast(NULL AS string), 'date_type', '30d', 'data_value', cast(comment_count_30d AS decimal(10,2))),
--           named_struct('target_name', '评论数', 'target_desc', cast(NULL AS string), 'date_type', '60d', 'data_value', cast(comment_count_60d AS decimal(10,2))),
--           named_struct('target_name', '评论数', 'target_desc', cast(NULL AS string), 'date_type', '90d', 'data_value', cast(comment_count_90d AS decimal(10,2))),
--           -- 评论数环比 ×5（×100）
--           named_struct('target_name', '评论数环比', 'target_desc', cast(NULL AS string), 'date_type', '1d',  'data_value', cast(round(comment_count_dod    * 100, 2) AS decimal(10,2))),
--           named_struct('target_name', '评论数环比', 'target_desc', cast(NULL AS string), 'date_type', '7d',  'data_value', cast(round(comment_count_wow    * 100, 2) AS decimal(10,2))),
--           named_struct('target_name', '评论数环比', 'target_desc', cast(NULL AS string), 'date_type', '30d', 'data_value', cast(round(comment_count_mom    * 100, 2) AS decimal(10,2))),
--           named_struct('target_name', '评论数环比', 'target_desc', cast(NULL AS string), 'date_type', '60d', 'data_value', cast(round(comment_count_60dod * 100, 2) AS decimal(10,2))),
--           named_struct('target_name', '评论数环比', 'target_desc', cast(NULL AS string), 'date_type', '90d', 'data_value', cast(round(comment_count_90dod * 100, 2) AS decimal(10,2)))
--       )) t AS metric
--   )
-- --   INSERT OVERWRITE TABLE ads_digital_brain_target_merge_di PARTITION(data_domain, travel_date)

--   SELECT
--       md5(concat_ws('|',
--           scenic_spot_code,
--           target_name,
--           date_type,
--           date_format(date_sub(current_date(), 1), 'yyyyMMdd')
--       ))                                AS key_id,
--       scenic_spot_code                  AS scenic_id,
--       scenic_spot_name                  AS scenic_name,
--       cast('舆情-评价得分、情绪占比、评论数' AS string) AS indicator_domain,
--       target_name,
--       target_desc,
--       date_type,
--       data_value,
--       '舆情'                            AS data_domain,
--       cast(date_format(date_sub(current_date(), 1), 'yyyyMMdd') AS int) AS travel_date
--   FROM core_long;






-- --   INSERT OVERWRITE TABLE ads_digital_brain_target_merge_di PARTITION(data_domain, travel_date)
--   SELECT
--       md5(concat_ws('|', scenic_spot_code, e.col.target_name, e.col.date_type, cast(travel_date AS string), emotion_word)) AS key_id,
--       scenic_spot_code AS scenic_id,
--       scenic_spot_name  AS scenic_name,
--       CASE WHEN emotion_type = 'positive' THEN '舆情-正向词' ELSE '舆情-负向词' END AS indicator_domain,
--       e.col.target_name  AS target_name,
--       e.col.target_desc  AS target_desc,
--       e.col.date_type    AS date_type,
--       e.col.data_value   AS data_value,
--       '舆情' AS data_domain,
--       travel_date
--   FROM (
--       SELECT
--           scenic_spot_code,
--           scenic_spot_name,
--           emotion_type,
--           emotion_word,
--           travel_date,
--           emotion_value,
--           emotion_value_7d,
--           emotion_value_30d,
--           emotion_value_60d,
--           emotion_value_90d,
--           emotion_rate_1d,
--           emotion_rate_7d,
--           emotion_rate_30d,
--           emotion_rate_60d,
--           emotion_rate_90d
--       FROM ads_trf_social_opinion_comment_content_di
--       WHERE travel_date = cast(date_format(date_sub(current_date(), 1), 'yyyyMMdd') AS int)
--         AND emotion_type IN ('positive', 'negative')
--   ) t
--   LATERAL VIEW explode(array(
--       named_struct('target_name', if(emotion_type = 'positive', '正向词占比', '负向词占比'), 'target_desc', emotion_word, 'date_type', '1d',  'data_value', round(emotion_rate_1d  * 100, 2)),
--       named_struct('target_name', if(emotion_type = 'positive', '正向词占比', '负向词占比'), 'target_desc', emotion_word, 'date_type', '7d',  'data_value', round(emotion_rate_7d  * 100, 2)),
--       named_struct('target_name', if(emotion_type = 'positive', '正向词占比', '负向词占比'), 'target_desc', emotion_word, 'date_type', '30d', 'data_value', round(emotion_rate_30d * 100, 2)),
--       named_struct('target_name', if(emotion_type = 'positive', '正向词占比', '负向词占比'), 'target_desc', emotion_word, 'date_type', '60d', 'data_value', round(emotion_rate_60d * 100, 2)),
--       named_struct('target_name', if(emotion_type = 'positive', '正向词占比', '负向词占比'), 'target_desc', emotion_word, 'date_type', '90d', 'data_value', round(emotion_rate_90d * 100, 2)),
--       named_struct('target_name', if(emotion_type = 'positive', '正向词值',   '负向词值'),   'target_desc', emotion_word, 'date_type', '1d',  'data_value', cast(emotion_value    AS decimal(10,2))),
--       named_struct('target_name', if(emotion_type = 'positive', '正向词值',   '负向词值'),   'target_desc', emotion_word, 'date_type', '7d',  'data_value', cast(emotion_value_7d AS decimal(10,2))),
--       named_struct('target_name', if(emotion_type = 'positive', '正向词值',   '负向词值'),   'target_desc', emotion_word, 'date_type', '30d', 'data_value', cast(emotion_value_30d AS decimal(10,2))),
--       named_struct('target_name', if(emotion_type = 'positive', '正向词值',   '负向词值'),   'target_desc', emotion_word, 'date_type', '60d', 'data_value', cast(emotion_value_60d AS decimal(10,2))),
--       named_struct('target_name', if(emotion_type = 'positive', '正向词值',   '负向词值'),   'target_desc', emotion_word, 'date_type', '90d', 'data_value', cast(emotion_value_90d AS decimal(10,2)))
--   )) e


--   WITH trend_raw AS (
--       -- 拉 91 天数据用于滚动求和（近90日需 89 天前数据，多 1 天余量）
--       SELECT *
--       FROM ads_trf_social_opinion_comment_core_di
--       WHERE travel_date BETWEEN cast(date_format(date_sub(current_date(), 91), 'yyyyMMdd') AS int)
--                             AND cast(date_format(date_sub(current_date(), 1),  'yyyyMMdd') AS int)
--         AND scenic_spot_code IS NOT NULL
--   ),
--   trend_dedup AS (
--       -- 同 (景区,天) 若有多行，取 etl_time 最新，保证一天一行
--       SELECT *
--       FROM (
--           SELECT
--               *,
--               row_number() OVER (PARTITION BY scenic_spot_code, travel_date ORDER BY etl_time DESC) AS rn
--           FROM trend_raw
--       ) t
--       WHERE rn = 1
--   ),
--   trend_wide AS (
--       -- 四个计数各自滚动求和：6/29/59/89 前推
--       SELECT
--           scenic_spot_code,
--           scenic_spot_name,
--           travel_date,
--           comment_count,
--           positive_count,
--           neutral_count,
--           negative_count,
--           sum(comment_count) OVER (PARTITION BY scenic_spot_code ORDER BY travel_date ROWS BETWEEN 6  PRECEDING AND CURRENT ROW) AS comment_count_7d,
--           sum(comment_count) OVER (PARTITION BY scenic_spot_code ORDER BY travel_date ROWS BETWEEN 29 PRECEDING AND CURRENT ROW) AS comment_count_30d,
--           sum(comment_count) OVER (PARTITION BY scenic_spot_code ORDER BY travel_date ROWS BETWEEN 59 PRECEDING AND CURRENT ROW) AS comment_count_60d,
--           sum(comment_count) OVER (PARTITION BY scenic_spot_code ORDER BY travel_date ROWS BETWEEN 89 PRECEDING AND CURRENT ROW) AS comment_count_90d,
--           sum(positive_count) OVER (PARTITION BY scenic_spot_code ORDER BY travel_date ROWS BETWEEN 6  PRECEDING AND CURRENT ROW) AS positive_count_7d,
--           sum(positive_count) OVER (PARTITION BY scenic_spot_code ORDER BY travel_date ROWS BETWEEN 29 PRECEDING AND CURRENT ROW) AS positive_count_30d,
--           sum(positive_count) OVER (PARTITION BY scenic_spot_code ORDER BY travel_date ROWS BETWEEN 59 PRECEDING AND CURRENT ROW) AS positive_count_60d,
--           sum(positive_count) OVER (PARTITION BY scenic_spot_code ORDER BY travel_date ROWS BETWEEN 89 PRECEDING AND CURRENT ROW) AS positive_count_90d,
--           sum(neutral_count)  OVER (PARTITION BY scenic_spot_code ORDER BY travel_date ROWS BETWEEN 6  PRECEDING AND CURRENT ROW) AS neutral_count_7d,
--           sum(neutral_count)  OVER (PARTITION BY scenic_spot_code ORDER BY travel_date ROWS BETWEEN 29 PRECEDING AND CURRENT ROW) AS neutral_count_30d,
--           sum(neutral_count)  OVER (PARTITION BY scenic_spot_code ORDER BY travel_date ROWS BETWEEN 59 PRECEDING AND CURRENT ROW) AS neutral_count_60d,
--           sum(neutral_count)  OVER (PARTITION BY scenic_spot_code ORDER BY travel_date ROWS BETWEEN 89 PRECEDING AND CURRENT ROW) AS neutral_count_90d,
--           sum(negative_count) OVER (PARTITION BY scenic_spot_code ORDER BY travel_date ROWS BETWEEN 6  PRECEDING AND CURRENT ROW) AS negative_count_7d,
--           sum(negative_count) OVER (PARTITION BY scenic_spot_code ORDER BY travel_date ROWS BETWEEN 29 PRECEDING AND CURRENT ROW) AS negative_count_30d,
--           sum(negative_count) OVER (PARTITION BY scenic_spot_code ORDER BY travel_date ROWS BETWEEN 59 PRECEDING AND CURRENT ROW) AS negative_count_60d,
--           sum(negative_count) OVER (PARTITION BY scenic_spot_code ORDER BY travel_date ROWS BETWEEN 89 PRECEDING AND CURRENT ROW) AS negative_count_90d
--       FROM trend_dedup
--   ),
--   trend_yesterday AS (
--       SELECT *
--       FROM trend_wide
--       WHERE travel_date = cast(date_format(date_sub(current_date(), 1), 'yyyyMMdd') AS int)
--   ),
--   trend_long AS (
--       SELECT
--           scenic_spot_code,
--           scenic_spot_name,
--           metric.target_name,
--           metric.target_desc,
--           metric.date_type,
--           metric.data_value
--       FROM trend_yesterday
--       LATERAL VIEW explode(array(
--           -- 评论总数 ×5（1d 原始，7d+ 滚动）
--           named_struct('target_name', '评论总数', 'target_desc', cast(NULL AS string), 'date_type', '1d',  'data_value', cast(comment_count     AS decimal(10,2))),
--           named_struct('target_name', '评论总数', 'target_desc', cast(NULL AS string), 'date_type', '7d',  'data_value', cast(comment_count_7d  AS decimal(10,2))),
--           named_struct('target_name', '评论总数', 'target_desc', cast(NULL AS string), 'date_type', '30d', 'data_value', cast(comment_count_30d AS decimal(10,2))),
--           named_struct('target_name', '评论总数', 'target_desc', cast(NULL AS string), 'date_type', '60d', 'data_value', cast(comment_count_60d AS decimal(10,2))),
--           named_struct('target_name', '评论总数', 'target_desc', cast(NULL AS string), 'date_type', '90d', 'data_value', cast(comment_count_90d AS decimal(10,2))),
--           -- 好评数 ×5
--           named_struct('target_name', '好评数', 'target_desc', cast(NULL AS string), 'date_type', '1d',  'data_value', cast(positive_count     AS decimal(10,2))),
--           named_struct('target_name', '好评数', 'target_desc', cast(NULL AS string), 'date_type', '7d',  'data_value', cast(positive_count_7d  AS decimal(10,2))),
--           named_struct('target_name', '好评数', 'target_desc', cast(NULL AS string), 'date_type', '30d', 'data_value', cast(positive_count_30d AS decimal(10,2))),
--           named_struct('target_name', '好评数', 'target_desc', cast(NULL AS string), 'date_type', '60d', 'data_value', cast(positive_count_60d AS decimal(10,2))),
--           named_struct('target_name', '好评数', 'target_desc', cast(NULL AS string), 'date_type', '90d', 'data_value', cast(positive_count_90d AS decimal(10,2))),
--           -- 中评数 ×5
--           named_struct('target_name', '中评数', 'target_desc', cast(NULL AS string), 'date_type', '1d',  'data_value', cast(neutral_count     AS decimal(10,2))),
--           named_struct('target_name', '中评数', 'target_desc', cast(NULL AS string), 'date_type', '7d',  'data_value', cast(neutral_count_7d  AS decimal(10,2))),
--           named_struct('target_name', '中评数', 'target_desc', cast(NULL AS string), 'date_type', '30d', 'data_value', cast(neutral_count_30d AS decimal(10,2))),
--           named_struct('target_name', '中评数', 'target_desc', cast(NULL AS string), 'date_type', '60d', 'data_value', cast(neutral_count_60d AS decimal(10,2))),
--           named_struct('target_name', '中评数', 'target_desc', cast(NULL AS string), 'date_type', '90d', 'data_value', cast(neutral_count_90d AS decimal(10,2))),
--           -- 差评数 ×5
--           named_struct('target_name', '差评数', 'target_desc', cast(NULL AS string), 'date_type', '1d',  'data_value', cast(negative_count     AS decimal(10,2))),
--           named_struct('target_name', '差评数', 'target_desc', cast(NULL AS string), 'date_type', '7d',  'data_value', cast(negative_count_7d  AS decimal(10,2))),
--           named_struct('target_name', '差评数', 'target_desc', cast(NULL AS string), 'date_type', '30d', 'data_value', cast(negative_count_30d AS decimal(10,2))),
--           named_struct('target_name', '差评数', 'target_desc', cast(NULL AS string), 'date_type', '60d', 'data_value', cast(negative_count_60d AS decimal(10,2))),
--           named_struct('target_name', '差评数', 'target_desc', cast(NULL AS string), 'date_type', '90d', 'data_value', cast(negative_count_90d AS decimal(10,2)))
--       )) t AS metric
--   )
-- --   INSERT OVERWRITE TABLE ads_digital_brain_target_merge_di PARTITION(data_domain, travel_date)
--   SELECT
--       md5(concat_ws('|', scenic_spot_code, target_name, date_type, date_format(date_sub(current_date(), 1), 'yyyyMMdd'))) AS key_id,
--       scenic_spot_code    AS scenic_id,
--       scenic_spot_name    AS scenic_name,
--       cast('舆情-情绪趋势' AS string) AS indicator_domain,
--       target_name,
--       target_desc,
--       date_type,
--       data_value,
--       '舆情'              AS data_domain,
--       cast(date_format(date_sub(current_date(), 1), 'yyyyMMdd') AS int) AS travel_date
--   FROM trend_long;


--   WITH emotion_raw AS (
--       SELECT *
--       FROM ads_trf_social_opinion_comment_core_di
--       WHERE travel_date = cast(date_format(date_sub(current_date(), 1), 'yyyyMMdd') AS int)
--         AND scenic_spot_code IS NOT NULL
--   ),
--   emotion_dedup AS (
--       -- 同 (景区,天) 若有多行，取 etl_time 最新，保证一天一行
--       SELECT *
--       FROM (
--           SELECT *, row_number() OVER (PARTITION BY scenic_spot_code, travel_date ORDER BY etl_time DESC) AS rn
--           FROM emotion_raw
--       ) t
--       WHERE rn = 1
--   ),
--   emotion_long AS (
--       SELECT
--           scenic_spot_code,
--           scenic_spot_name,
--           metric.target_name,
--           metric.target_desc,
--           metric.date_type,
--           metric.data_value
--       FROM emotion_dedup
--       LATERAL VIEW explode(array(
--           named_struct('target_name', '情绪得分', 'target_desc', cast(NULL AS string), 'date_type', '1d',  'data_value', cast(emotional_score    AS decimal(10,2))),
--           named_struct('target_name', '情绪得分', 'target_desc', cast(NULL AS string), 'date_type', '7d',  'data_value', cast(emotional_score_7d  AS decimal(10,2))),
--           named_struct('target_name', '情绪得分', 'target_desc', cast(NULL AS string), 'date_type', '30d', 'data_value', cast(emotional_score_30d AS decimal(10,2))),
--           named_struct('target_name', '情绪得分', 'target_desc', cast(NULL AS string), 'date_type', '60d', 'data_value', cast(emotional_score_60d AS decimal(10,2))),
--           named_struct('target_name', '情绪得分', 'target_desc', cast(NULL AS string), 'date_type', '90d', 'data_value', cast(emotional_score_90d AS decimal(10,2)))
--       )) t AS metric
--   )
-- --   INSERT OVERWRITE TABLE ads_digital_brain_target_merge_di PARTITION(data_domain, travel_date)
--   SELECT
--       md5(concat_ws('|', scenic_spot_code, target_name, date_type, date_format(date_sub(current_date(), 1), 'yyyyMMdd'))) AS key_id,
--       scenic_spot_code    AS scenic_id,
--       scenic_spot_name    AS scenic_name,
--       cast('舆情-情绪得分' AS string) AS indicator_domain,
--       target_name,
--       target_desc,
--       date_type,
--       data_value,
--       '舆情'              AS data_domain,
--       cast(date_format(date_sub(current_date(), 1), 'yyyyMMdd') AS int) AS travel_date
--   FROM emotion_long;



--  INSERT OVERWRITE TABLE ads_digital_brain_target_merge_di PARTITION(data_domain, travel_date)

--   WITH
--   -- ============ 分支1：评论维度评分 ============
--   social_base AS (
--       SELECT
--           scenic_spot_code,
--           max(scenic_spot_name)      AS scenic_spot_name,
--           dimension_level1,
--           max(dimension_1_score)      AS score_1d,
--           max(dimension_1_score_7d)   AS score_7d,
--           max(dimension_1_score_30d)  AS score_30d,
--           max(dimension_1_score_60d)  AS score_60d,
--           max(dimension_1_score_90d)  AS score_90d
--       FROM ads_trf_social_opinion_comment_dimension_score_di
--       WHERE travel_date = cast(date_format(date_sub(current_date(), 1), 'yyyyMMdd') AS int)
--         AND dimension_level1 IS NOT NULL
--       GROUP BY scenic_spot_code, dimension_level1
--   ),
--   social_long AS (
--       SELECT
--           scenic_spot_code,
--           scenic_spot_name,
--           metric.target_name,
--           metric.target_desc,
--           metric.date_type,
--           metric.data_value
--       FROM social_base
--       LATERAL VIEW explode(array(
--           named_struct('target_name', concat(dimension_level1, '-满意度评分'), 'target_desc', concat(dimension_level1, '维度满意度评分'), 'date_type', '1d',  'data_value', cast(score_1d  AS decimal(10,2))),
--           named_struct('target_name', concat(dimension_level1, '-满意度评分'), 'target_desc', concat(dimension_level1, '维度满意度评分'), 'date_type', '7d',  'data_value', cast(score_7d  AS decimal(10,2))),
--           named_struct('target_name', concat(dimension_level1, '-满意度评分'), 'target_desc', concat(dimension_level1, '维度满意度评分'), 'date_type', '30d', 'data_value', cast(score_30d AS decimal(10,2))),
--           named_struct('target_name', concat(dimension_level1, '-满意度评分'), 'target_desc', concat(dimension_level1, '维度满意度评分'), 'date_type', '60d', 'data_value', cast(score_60d AS decimal(10,2))),
--           named_struct('target_name', concat(dimension_level1, '-满意度评分'), 'target_desc', concat(dimension_level1, '维度满意度评分'), 'date_type', '90d', 'data_value', cast(score_90d AS decimal(10,2)))
--       )) t AS metric
--   ),

--   -- ============ 分支2：平台评论分布 ============
--   platform_raw AS (
--       SELECT *
--       FROM ads_trf_social_opinion_comment_platform_di
--       WHERE travel_date = cast(date_format(date_sub(current_date(), 1), 'yyyyMMdd') AS int)
--         AND scenic_spot_code IS NOT NULL
--         AND platform_code  IS NOT NULL
--   ),
--   platform_dedup AS (
--       SELECT *
--       FROM (
--           SELECT *, row_number() OVER (PARTITION BY scenic_spot_code, platform_code ORDER BY etl_time DESC) AS rn
--           FROM platform_raw
--       ) t
--       WHERE rn = 1
--   ),
--   platform_wide AS (
--       SELECT
--           scenic_spot_code,
--           scenic_spot_name,
--           platform_name,
--           platform_code,
--           comment_rate,
--           good_rate_1d, week_good_rate, mon_good_rate, good_rate_60d, good_rate_90d,
--           comment_cnt, comment_cnt_7d, comment_cnt_30d, comment_cnt_60d, comment_cnt_90d,
--           plat_positive_count, plat_positive_7d_count, plat_positive_30d_count, plat_positive_60d_count, plat_positive_90d_count,
--           good_rate_wow_1d, week_good_rate_wow, mon_good_rate_wow, good_rate_wow_60d, good_rate_wow_90d,
--           sum(comment_cnt)     OVER (PARTITION BY scenic_spot_code) AS sum_comment_cnt_1d,
--           sum(comment_cnt_7d)  OVER (PARTITION BY scenic_spot_code) AS sum_comment_cnt_7d,
--           sum(comment_cnt_30d) OVER (PARTITION BY scenic_spot_code) AS sum_comment_cnt_30d,
--           sum(comment_cnt_60d) OVER (PARTITION BY scenic_spot_code) AS sum_comment_cnt_60d,
--           sum(comment_cnt_90d) OVER (PARTITION BY scenic_spot_code) AS sum_comment_cnt_90d
--       FROM platform_dedup
--   ),
--   platform_long AS (
--       SELECT
--           scenic_spot_code,
--           scenic_spot_name,
--           platform_name,
--           platform_code,
--           metric.target_name,
--           metric.target_desc,
--           metric.date_type,
--           metric.data_value
--       FROM platform_wide
--       LATERAL VIEW explode(array(
--           named_struct('target_name', '好评占比',   'target_desc', platform_name, 'date_type', '1d',  'data_value', cast(round(good_rate_1d  * 100, 2) AS decimal(10,2))),
--           named_struct('target_name', '好评占比',   'target_desc', platform_name, 'date_type', '7d',  'data_value', cast(round(week_good_rate * 100, 2) AS decimal(10,2))),
--           named_struct('target_name', '好评占比',   'target_desc', platform_name, 'date_type', '30d', 'data_value', cast(round(mon_good_rate  * 100, 2) AS decimal(10,2))),
--           named_struct('target_name', '好评占比',   'target_desc', platform_name, 'date_type', '60d', 'data_value', cast(round(good_rate_60d  * 100, 2) AS decimal(10,2))),
--           named_struct('target_name', '好评占比',   'target_desc', platform_name, 'date_type', '90d', 'data_value', cast(round(good_rate_90d  * 100, 2) AS decimal(10,2))),
--           named_struct('target_name', '总评数',     'target_desc', platform_name, 'date_type', '1d',  'data_value', cast(comment_cnt     AS decimal(10,2))),
--           named_struct('target_name', '总评数',     'target_desc', platform_name, 'date_type', '7d',  'data_value', cast(comment_cnt_7d  AS decimal(10,2))),
--           named_struct('target_name', '总评数',     'target_desc', platform_name, 'date_type', '30d', 'data_value', cast(comment_cnt_30d AS decimal(10,2))),
--           named_struct('target_name', '总评数',     'target_desc', platform_name, 'date_type', '60d', 'data_value', cast(comment_cnt_60d AS decimal(10,2))),
--           named_struct('target_name', '总评数',     'target_desc', platform_name, 'date_type', '90d', 'data_value', cast(comment_cnt_90d AS decimal(10,2))),
--           named_struct('target_name', '好评数',     'target_desc', platform_name, 'date_type', '1d',  'data_value', cast(plat_positive_count     AS decimal(10,2))),
--           named_struct('target_name', '好评数',     'target_desc', platform_name, 'date_type', '7d',  'data_value', cast(plat_positive_7d_count  AS decimal(10,2))),
--           named_struct('target_name', '好评数',     'target_desc', platform_name, 'date_type', '30d', 'data_value', cast(plat_positive_30d_count AS decimal(10,2))),
--           named_struct('target_name', '好评数',     'target_desc', platform_name, 'date_type', '60d', 'data_value', cast(plat_positive_60d_count AS decimal(10,2))),
--           named_struct('target_name', '好评数',     'target_desc', platform_name, 'date_type', '90d', 'data_value', cast(plat_positive_90d_count AS decimal(10,2))),
--           named_struct('target_name', '好评环比',   'target_desc', platform_name, 'date_type', '1d',  'data_value', cast(round(good_rate_wow_1d  * 100, 2) AS decimal(10,2))),
--           named_struct('target_name', '好评环比',   'target_desc', platform_name, 'date_type', '7d',  'data_value', cast(round(week_good_rate_wow * 100, 2) AS decimal(10,2))),
--           named_struct('target_name', '好评环比',   'target_desc', platform_name, 'date_type', '30d', 'data_value', cast(round(mon_good_rate_wow  * 100, 2) AS decimal(10,2))),
--           named_struct('target_name', '好评环比',   'target_desc', platform_name, 'date_type', '60d', 'data_value', cast(round(good_rate_wow_60d  * 100, 2) AS decimal(10,2))),
--           named_struct('target_name', '好评环比',   'target_desc', platform_name, 'date_type', '90d', 'data_value', cast(round(good_rate_wow_90d  * 100, 2) AS decimal(10,2))),
--           named_struct('target_name', '渠道评论占比', 'target_desc', platform_name, 'date_type', '1d',  'data_value', cast(round(comment_cnt     * 100.0 / nullif(sum_comment_cnt_1d,  0), 2) AS decimal(10,2))),
--           named_struct('target_name', '渠道评论占比', 'target_desc', platform_name, 'date_type', '7d',  'data_value', cast(round(comment_cnt_7d  * 100.0 / nullif(sum_comment_cnt_7d,  0), 2) AS decimal(10,2))),
--           named_struct('target_name', '渠道评论占比', 'target_desc', platform_name, 'date_type', '30d', 'data_value', cast(round(comment_cnt_30d * 100.0 / nullif(sum_comment_cnt_30d, 0), 2) AS decimal(10,2))),
--           named_struct('target_name', '渠道评论占比', 'target_desc', platform_name, 'date_type', '60d', 'data_value', cast(round(comment_cnt_60d * 100.0 / nullif(sum_comment_cnt_60d, 0), 2) AS decimal(10,2))),
--           named_struct('target_name', '渠道评论占比', 'target_desc', platform_name, 'date_type', '90d', 'data_value', cast(round(comment_cnt_90d * 100.0 / nullif(sum_comment_cnt_90d, 0), 2) AS decimal(10,2))),
--           named_struct('target_name', '评论占比',   'target_desc', platform_name, 'date_type', '1d',  'data_value', cast(round(comment_rate * 100, 2) AS decimal(10,2)))
--       )) t AS metric
--   ),

--   -- ============ 分支3：评论核心 ============
--   core_raw AS (
--       SELECT *
--       FROM ads_trf_social_opinion_comment_core_di
--       WHERE travel_date BETWEEN cast(date_format(date_sub(current_date(), 91), 'yyyyMMdd') AS int)
--                             AND cast(date_format(date_sub(current_date(), 1),  'yyyyMMdd') AS int)
--         AND scenic_spot_code IS NOT NULL
--   ),
--   core_dedup AS (
--       SELECT *
--       FROM (
--           SELECT *, row_number() OVER (PARTITION BY scenic_spot_code, travel_date ORDER BY etl_time DESC) AS rn
--           FROM core_raw
--       ) t
--       WHERE rn = 1
--   ),
--   core_wide AS (
--       SELECT
--           scenic_spot_code,
--           scenic_spot_name,
--           travel_date,
--           comment_count,
--           positive_count,
--           neutral_count,
--           negative_count,
--           emotional_score,
--           emotional_score_7d,
--           emotional_score_30d,
--           emotional_score_60d,
--           emotional_score_90d,
--           positive_rate_7d,
--           positive_rate_30d,
--           positive_rate_60d,
--           positive_rate_90d,
--           neutral_rate_7d,
--           neutral_rate_30d,
--           neutral_rate_60d,
--           neutral_rate_90d,
--           negative_rate_7d,
--           negative_rate_30d,
--           negative_rate_60d,
--           negative_rate_90d,
--           comment_count_dod,
--           comment_count_wow,
--           comment_count_mom,
--           comment_count_60dod,
--           comment_count_90dod,
--           sum(comment_count) OVER (PARTITION BY scenic_spot_code ORDER BY travel_date ROWS BETWEEN 6  PRECEDING AND CURRENT ROW) AS comment_count_7d,
--           sum(comment_count) OVER (PARTITION BY scenic_spot_code ORDER BY travel_date ROWS BETWEEN 29 PRECEDING AND CURRENT ROW) AS comment_count_30d,
--           sum(comment_count) OVER (PARTITION BY scenic_spot_code ORDER BY travel_date ROWS BETWEEN 59 PRECEDING AND CURRENT ROW) AS comment_count_60d,
--           sum(comment_count) OVER (PARTITION BY scenic_spot_code ORDER BY travel_date ROWS BETWEEN 89 PRECEDING AND CURRENT ROW) AS comment_count_90d
--       FROM core_dedup
--   ),
--   core_yesterday AS (
--       SELECT *
--       FROM core_wide
--       WHERE travel_date = cast(date_format(date_sub(current_date(), 1), 'yyyyMMdd') AS int)
--   ),
--   core_long AS (
--       SELECT
--           scenic_spot_code,
--           scenic_spot_name,
--           metric.target_name,
--           metric.target_desc,
--           metric.date_type,
--           metric.data_value
--       FROM core_yesterday
--       LATERAL VIEW explode(array(
--           named_struct('target_name', '好评率',       'target_desc', cast(NULL AS string), 'date_type', '1d',  'data_value', cast(round(positive_count * 100.0 / nullif(comment_count, 0), 2) AS decimal(10,2))),
--           named_struct('target_name', '好评率',       'target_desc', cast(NULL AS string), 'date_type', '7d',  'data_value', cast(round(positive_rate_7d  * 100, 2) AS decimal(10,2))),
--           named_struct('target_name', '好评率',       'target_desc', cast(NULL AS string), 'date_type', '30d', 'data_value', cast(round(positive_rate_30d * 100, 2) AS decimal(10,2))),
--           named_struct('target_name', '好评率',       'target_desc', cast(NULL AS string), 'date_type', '60d', 'data_value', cast(round(positive_rate_60d * 100, 2) AS decimal(10,2))),
--           named_struct('target_name', '好评率',       'target_desc', cast(NULL AS string), 'date_type', '90d', 'data_value', cast(round(positive_rate_90d * 100, 2) AS decimal(10,2))),
--           named_struct('target_name', '中评率',       'target_desc', cast(NULL AS string), 'date_type', '1d',  'data_value', cast(round(neutral_count * 100.0 / nullif(comment_count, 0), 2) AS decimal(10,2))),
--           named_struct('target_name', '中评率',       'target_desc', cast(NULL AS string), 'date_type', '7d',  'data_value', cast(round(neutral_rate_7d  * 100, 2) AS decimal(10,2))),
--           named_struct('target_name', '中评率',       'target_desc', cast(NULL AS string), 'date_type', '30d', 'data_value', cast(round(neutral_rate_30d * 100, 2) AS decimal(10,2))),
--           named_struct('target_name', '中评率',       'target_desc', cast(NULL AS string), 'date_type', '60d', 'data_value', cast(round(neutral_rate_60d * 100, 2) AS decimal(10,2))),
--           named_struct('target_name', '中评率',       'target_desc', cast(NULL AS string), 'date_type', '90d', 'data_value', cast(round(neutral_rate_90d * 100, 2) AS decimal(10,2))),
--           named_struct('target_name', '差评率',       'target_desc', cast(NULL AS string), 'date_type', '1d',  'data_value', cast(round(negative_count * 100.0 / nullif(comment_count, 0), 2) AS decimal(10,2))),
--           named_struct('target_name', '差评率',       'target_desc', cast(NULL AS string), 'date_type', '7d',  'data_value', cast(round(negative_rate_7d  * 100, 2) AS decimal(10,2))),
--           named_struct('target_name', '差评率',       'target_desc', cast(NULL AS string), 'date_type', '30d', 'data_value', cast(round(negative_rate_30d * 100, 2) AS decimal(10,2))),
--           named_struct('target_name', '差评率',       'target_desc', cast(NULL AS string), 'date_type', '60d', 'data_value', cast(round(negative_rate_60d * 100, 2) AS decimal(10,2))),
--           named_struct('target_name', '差评率',       'target_desc', cast(NULL AS string), 'date_type', '90d', 'data_value', cast(round(negative_rate_90d * 100, 2) AS decimal(10,2))),
--           named_struct('target_name', '游客综合评价得分', 'target_desc', cast(NULL AS string), 'date_type', '1d',  'data_value', cast(emotional_score    AS decimal(10,2))),
--           named_struct('target_name', '游客综合评价得分', 'target_desc', cast(NULL AS string), 'date_type', '7d',  'data_value', cast(emotional_score_7d  AS decimal(10,2))),
--           named_struct('target_name', '游客综合评价得分', 'target_desc', cast(NULL AS string), 'date_type', '30d', 'data_value', cast(emotional_score_30d AS decimal(10,2))),
--           named_struct('target_name', '游客综合评价得分', 'target_desc', cast(NULL AS string), 'date_type', '60d', 'data_value', cast(emotional_score_60d AS decimal(10,2))),
--           named_struct('target_name', '游客综合评价得分', 'target_desc', cast(NULL AS string), 'date_type', '90d', 'data_value', cast(emotional_score_90d AS decimal(10,2))),
--           named_struct('target_name', '评论数',       'target_desc', cast(NULL AS string), 'date_type', '1d',  'data_value', cast(comment_count     AS decimal(10,2))),
--           named_struct('target_name', '评论数',       'target_desc', cast(NULL AS string), 'date_type', '7d',  'data_value', cast(comment_count_7d  AS decimal(10,2))),
--           named_struct('target_name', '评论数',       'target_desc', cast(NULL AS string), 'date_type', '30d', 'data_value', cast(comment_count_30d AS decimal(10,2))),
--           named_struct('target_name', '评论数',       'target_desc', cast(NULL AS string), 'date_type', '60d', 'data_value', cast(comment_count_60d AS decimal(10,2))),
--           named_struct('target_name', '评论数',       'target_desc', cast(NULL AS string), 'date_type', '90d', 'data_value', cast(comment_count_90d AS decimal(10,2))),
--           named_struct('target_name', '评论数环比',   'target_desc', cast(NULL AS string), 'date_type', '1d',  'data_value', cast(round(comment_count_dod    * 100, 2) AS decimal(10,2))),
--           named_struct('target_name', '评论数环比',   'target_desc', cast(NULL AS string), 'date_type', '7d',  'data_value', cast(round(comment_count_wow    * 100, 2) AS decimal(10,2))),
--           named_struct('target_name', '评论数环比',   'target_desc', cast(NULL AS string), 'date_type', '30d', 'data_value', cast(round(comment_count_mom    * 100, 2) AS decimal(10,2))),
--           named_struct('target_name', '评论数环比',   'target_desc', cast(NULL AS string), 'date_type', '60d', 'data_value', cast(round(comment_count_60dod * 100, 2) AS decimal(10,2))),
--           named_struct('target_name', '评论数环比',   'target_desc', cast(NULL AS string), 'date_type', '90d', 'data_value', cast(round(comment_count_90dod * 100, 2) AS decimal(10,2)))
--       )) t AS metric
--   ),

--   -- ============ 分支5：情绪趋势（评论核心表计数） ============
--   trend_raw AS (
--       SELECT *
--       FROM ads_trf_social_opinion_comment_core_di
--       WHERE travel_date BETWEEN cast(date_format(date_sub(current_date(), 91), 'yyyyMMdd') AS int)
--                             AND cast(date_format(date_sub(current_date(), 1),  'yyyyMMdd') AS int)
--         AND scenic_spot_code IS NOT NULL
--   ),
--   trend_dedup AS (
--       SELECT *
--       FROM (
--           SELECT *, row_number() OVER (PARTITION BY scenic_spot_code, travel_date ORDER BY etl_time DESC) AS rn
--           FROM trend_raw
--       ) t
--       WHERE rn = 1
--   ),
--   trend_wide AS (
--       SELECT
--           scenic_spot_code,
--           scenic_spot_name,
--           travel_date,
--           comment_count,
--           positive_count,
--           neutral_count,
--           negative_count,
--           sum(comment_count) OVER (PARTITION BY scenic_spot_code ORDER BY travel_date ROWS BETWEEN 6  PRECEDING AND CURRENT ROW) AS comment_count_7d,
--           sum(comment_count) OVER (PARTITION BY scenic_spot_code ORDER BY travel_date ROWS BETWEEN 29 PRECEDING AND CURRENT ROW) AS comment_count_30d,
--           sum(comment_count) OVER (PARTITION BY scenic_spot_code ORDER BY travel_date ROWS BETWEEN 59 PRECEDING AND CURRENT ROW) AS comment_count_60d,
--           sum(comment_count) OVER (PARTITION BY scenic_spot_code ORDER BY travel_date ROWS BETWEEN 89 PRECEDING AND CURRENT ROW) AS comment_count_90d,
--           sum(positive_count) OVER (PARTITION BY scenic_spot_code ORDER BY travel_date ROWS BETWEEN 6  PRECEDING AND CURRENT ROW) AS positive_count_7d,
--           sum(positive_count) OVER (PARTITION BY scenic_spot_code ORDER BY travel_date ROWS BETWEEN 29 PRECEDING AND CURRENT ROW) AS positive_count_30d,
--           sum(positive_count) OVER (PARTITION BY scenic_spot_code ORDER BY travel_date ROWS BETWEEN 59 PRECEDING AND CURRENT ROW) AS positive_count_60d,
--           sum(positive_count) OVER (PARTITION BY scenic_spot_code ORDER BY travel_date ROWS BETWEEN 89 PRECEDING AND CURRENT ROW) AS positive_count_90d,
--           sum(neutral_count)  OVER (PARTITION BY scenic_spot_code ORDER BY travel_date ROWS BETWEEN 6  PRECEDING AND CURRENT ROW) AS neutral_count_7d,
--           sum(neutral_count)  OVER (PARTITION BY scenic_spot_code ORDER BY travel_date ROWS BETWEEN 29 PRECEDING AND CURRENT ROW) AS neutral_count_30d,
--           sum(neutral_count)  OVER (PARTITION BY scenic_spot_code ORDER BY travel_date ROWS BETWEEN 59 PRECEDING AND CURRENT ROW) AS neutral_count_60d,
--           sum(neutral_count)  OVER (PARTITION BY scenic_spot_code ORDER BY travel_date ROWS BETWEEN 89 PRECEDING AND CURRENT ROW) AS neutral_count_90d,
--           sum(negative_count) OVER (PARTITION BY scenic_spot_code ORDER BY travel_date ROWS BETWEEN 6  PRECEDING AND CURRENT ROW) AS negative_count_7d,
--           sum(negative_count) OVER (PARTITION BY scenic_spot_code ORDER BY travel_date ROWS BETWEEN 29 PRECEDING AND CURRENT ROW) AS negative_count_30d,
--           sum(negative_count) OVER (PARTITION BY scenic_spot_code ORDER BY travel_date ROWS BETWEEN 59 PRECEDING AND CURRENT ROW) AS negative_count_60d,
--           sum(negative_count) OVER (PARTITION BY scenic_spot_code ORDER BY travel_date ROWS BETWEEN 89 PRECEDING AND CURRENT ROW) AS negative_count_90d
--       FROM trend_dedup
--   ),
--   trend_yesterday AS (
--       SELECT *
--       FROM trend_wide
--       WHERE travel_date = cast(date_format(date_sub(current_date(), 1), 'yyyyMMdd') AS int)
--   ),
--   trend_long AS (
--       SELECT
--           scenic_spot_code,
--           scenic_spot_name,
--           metric.target_name,
--           metric.target_desc,
--           metric.date_type,
--           metric.data_value
--       FROM trend_yesterday
--       LATERAL VIEW explode(array(
--           named_struct('target_name', '评论总数', 'target_desc', cast(NULL AS string), 'date_type', '1d',  'data_value', cast(comment_count     AS decimal(10,2))),
--           named_struct('target_name', '评论总数', 'target_desc', cast(NULL AS string), 'date_type', '7d',  'data_value', cast(comment_count_7d  AS decimal(10,2))),
--           named_struct('target_name', '评论总数', 'target_desc', cast(NULL AS string), 'date_type', '30d', 'data_value', cast(comment_count_30d AS decimal(10,2))),
--           named_struct('target_name', '评论总数', 'target_desc', cast(NULL AS string), 'date_type', '60d', 'data_value', cast(comment_count_60d AS decimal(10,2))),
--           named_struct('target_name', '评论总数', 'target_desc', cast(NULL AS string), 'date_type', '90d', 'data_value', cast(comment_count_90d AS decimal(10,2))),
--           named_struct('target_name', '好评数',   'target_desc', cast(NULL AS string), 'date_type', '1d',  'data_value', cast(positive_count     AS decimal(10,2))),
--           named_struct('target_name', '好评数',   'target_desc', cast(NULL AS string), 'date_type', '7d',  'data_value', cast(positive_count_7d  AS decimal(10,2))),
--           named_struct('target_name', '好评数',   'target_desc', cast(NULL AS string), 'date_type', '30d', 'data_value', cast(positive_count_30d AS decimal(10,2))),
--           named_struct('target_name', '好评数',   'target_desc', cast(NULL AS string), 'date_type', '60d', 'data_value', cast(positive_count_60d AS decimal(10,2))),
--           named_struct('target_name', '好评数',   'target_desc', cast(NULL AS string), 'date_type', '90d', 'data_value', cast(positive_count_90d AS decimal(10,2))),
--           named_struct('target_name', '中评数',   'target_desc', cast(NULL AS string), 'date_type', '1d',  'data_value', cast(neutral_count     AS decimal(10,2))),
--           named_struct('target_name', '中评数',   'target_desc', cast(NULL AS string), 'date_type', '7d',  'data_value', cast(neutral_count_7d  AS decimal(10,2))),
--           named_struct('target_name', '中评数',   'target_desc', cast(NULL AS string), 'date_type', '30d', 'data_value', cast(neutral_count_30d AS decimal(10,2))),
--           named_struct('target_name', '中评数',   'target_desc', cast(NULL AS string), 'date_type', '60d', 'data_value', cast(neutral_count_60d AS decimal(10,2))),
--           named_struct('target_name', '中评数',   'target_desc', cast(NULL AS string), 'date_type', '90d', 'data_value', cast(neutral_count_90d AS decimal(10,2))),
--           named_struct('target_name', '差评数',   'target_desc', cast(NULL AS string), 'date_type', '1d',  'data_value', cast(negative_count     AS decimal(10,2))),
--           named_struct('target_name', '差评数',   'target_desc', cast(NULL AS string), 'date_type', '7d',  'data_value', cast(negative_count_7d  AS decimal(10,2))),
--           named_struct('target_name', '差评数',   'target_desc', cast(NULL AS string), 'date_type', '30d', 'data_value', cast(negative_count_30d AS decimal(10,2))),
--           named_struct('target_name', '差评数',   'target_desc', cast(NULL AS string), 'date_type', '60d', 'data_value', cast(negative_count_60d AS decimal(10,2))),
--           named_struct('target_name', '差评数',   'target_desc', cast(NULL AS string), 'date_type', '90d', 'data_value', cast(negative_count_90d AS decimal(10,2)))
--       )) t AS metric
--   ),

--   -- ============ 分支6：情绪得分（评论核心表，与分支3区分） ============
--   emotion_raw AS (
--       SELECT *
--       FROM ads_trf_social_opinion_comment_core_di
--       WHERE travel_date = cast(date_format(date_sub(current_date(), 1), 'yyyyMMdd') AS int)
--         AND scenic_spot_code IS NOT NULL
--   ),
--   emotion_dedup AS (
--       SELECT *
--       FROM (
--           SELECT *, row_number() OVER (PARTITION BY scenic_spot_code, travel_date ORDER BY etl_time DESC) AS rn
--           FROM emotion_raw
--       ) t
--       WHERE rn = 1
--   ),
--   emotion_long AS (
--       SELECT
--           scenic_spot_code,
--           scenic_spot_name,
--           metric.target_name,
--           metric.target_desc,
--           metric.date_type,
--           metric.data_value
--       FROM emotion_dedup
--       LATERAL VIEW explode(array(
--           named_struct('target_name', '情绪得分', 'target_desc', cast(NULL AS string), 'date_type', '1d',  'data_value', cast(emotional_score    AS decimal(10,2))),
--           named_struct('target_name', '情绪得分', 'target_desc', cast(NULL AS string), 'date_type', '7d',  'data_value', cast(emotional_score_7d  AS decimal(10,2))),
--           named_struct('target_name', '情绪得分', 'target_desc', cast(NULL AS string), 'date_type', '30d', 'data_value', cast(emotional_score_30d AS decimal(10,2))),
--           named_struct('target_name', '情绪得分', 'target_desc', cast(NULL AS string), 'date_type', '60d', 'data_value', cast(emotional_score_60d AS decimal(10,2))),
--           named_struct('target_name', '情绪得分', 'target_desc', cast(NULL AS string), 'date_type', '90d', 'data_value', cast(emotional_score_90d AS decimal(10,2)))
--       )) t AS metric
--   )

--   -- ============ 6 条 UNION ALL ============
--   SELECT
--       md5(concat_ws('|', scenic_spot_code, target_name, date_type, date_format(date_sub(current_date(), 1), 'yyyyMMdd'))) AS key_id,
--       scenic_spot_code    AS scenic_id,
--       scenic_spot_name    AS scenic_name,
--       cast('舆情-各维度游客满意度评分' AS string) AS indicator_domain,
--       target_name,
--       target_desc,
--       date_type,
--       data_value,
--       '舆情'              AS data_domain,
--       cast(date_format(date_sub(current_date(), 1), 'yyyyMMdd') AS int) AS travel_date
--   FROM social_long

--   UNION ALL

--   SELECT
--       md5(concat_ws('|', scenic_spot_code, platform_code, target_name, date_type, date_format(date_sub(current_date(), 1), 'yyyyMMdd'))) AS key_id,
--       scenic_spot_code    AS scenic_id,
--       scenic_spot_name    AS scenic_name,
--       cast('舆情-平台评论分布' AS string) AS indicator_domain,
--       target_name,
--       target_desc,
--       date_type,
--       data_value,
--       '舆情'              AS data_domain,
--       cast(date_format(date_sub(current_date(), 1), 'yyyyMMdd') AS int) AS travel_date
--   FROM platform_long

--   UNION ALL

--   SELECT
--       md5(concat_ws('|', scenic_spot_code, target_name, date_type, date_format(date_sub(current_date(), 1), 'yyyyMMdd'))) AS key_id,
--       scenic_spot_code    AS scenic_id,
--       scenic_spot_name    AS scenic_name,
--       cast('舆情-评价得分、情绪占比、评论数' AS string) AS indicator_domain,
--       target_name,
--       target_desc,
--       date_type,
--       data_value,
--       '舆情'              AS data_domain,
--       cast(date_format(date_sub(current_date(), 1), 'yyyyMMdd') AS int) AS travel_date
--   FROM core_long

--   UNION ALL

--   -- ============ 分支4：评论内容 ============
--   SELECT
--       md5(concat_ws('|', scenic_spot_code, e.col.target_name, e.col.date_type, cast(travel_date AS string), emotion_word)) AS key_id,
--       scenic_spot_code    AS scenic_id,
--       scenic_spot_name    AS scenic_name,
--       CASE WHEN emotion_type = 'positive' THEN '舆情-正向词' ELSE '舆情-负向词' END AS indicator_domain,
--       e.col.target_name   AS target_name,
--       e.col.target_desc   AS target_desc,
--       e.col.date_type     AS date_type,
--       e.col.data_value    AS data_value,
--       '舆情'              AS data_domain,
--       travel_date
--   FROM (
--       SELECT
--           scenic_spot_code,
--           scenic_spot_name,
--           emotion_type,
--           emotion_word,
--           travel_date,
--           emotion_value,
--           emotion_value_7d,
--           emotion_value_30d,
--           emotion_value_60d,
--           emotion_value_90d,
--           emotion_rate_1d,
--           emotion_rate_7d,
--           emotion_rate_30d,
--           emotion_rate_60d,
--           emotion_rate_90d
--       FROM ads_trf_social_opinion_comment_content_di
--       WHERE travel_date = cast(date_format(date_sub(current_date(), 1), 'yyyyMMdd') AS int)
--         AND emotion_type IN ('positive', 'negative')
--   ) t
--   LATERAL VIEW explode(array(
--       named_struct('target_name', if(emotion_type = 'positive', '正向词占比', '负向词占比'), 'target_desc', emotion_word, 'date_type', '1d',  'data_value', round(emotion_rate_1d  * 100, 2)),
--       named_struct('target_name', if(emotion_type = 'positive', '正向词占比', '负向词占比'), 'target_desc', emotion_word, 'date_type', '7d',  'data_value', round(emotion_rate_7d  * 100, 2)),
--       named_struct('target_name', if(emotion_type = 'positive', '正向词占比', '负向词占比'), 'target_desc', emotion_word, 'date_type', '30d', 'data_value', round(emotion_rate_30d * 100, 2)),
--       named_struct('target_name', if(emotion_type = 'positive', '正向词占比', '负向词占比'), 'target_desc', emotion_word, 'date_type', '60d', 'data_value', round(emotion_rate_60d * 100, 2)),
--       named_struct('target_name', if(emotion_type = 'positive', '正向词占比', '负向词占比'), 'target_desc', emotion_word, 'date_type', '90d', 'data_value', round(emotion_rate_90d * 100, 2)),
--       named_struct('target_name', if(emotion_type = 'positive', '正向词值',   '负向词值'),   'target_desc', emotion_word, 'date_type', '1d',  'data_value', cast(emotion_value    AS decimal(10,2))),
--       named_struct('target_name', if(emotion_type = 'positive', '正向词值',   '负向词值'),   'target_desc', emotion_word, 'date_type', '7d',  'data_value', cast(emotion_value_7d AS decimal(10,2))),
--       named_struct('target_name', if(emotion_type = 'positive', '正向词值',   '负向词值'),   'target_desc', emotion_word, 'date_type', '30d', 'data_value', cast(emotion_value_30d AS decimal(10,2))),
--       named_struct('target_name', if(emotion_type = 'positive', '正向词值',   '负向词值'),   'target_desc', emotion_word, 'date_type', '60d', 'data_value', cast(emotion_value_60d AS decimal(10,2))),
--       named_struct('target_name', if(emotion_type = 'positive', '正向词值',   '负向词值'),   'target_desc', emotion_word, 'date_type', '90d', 'data_value', cast(emotion_value_90d AS decimal(10,2)))
--   )) e

--   UNION ALL

--   SELECT
--       md5(concat_ws('|', scenic_spot_code, target_name, date_type, date_format(date_sub(current_date(), 1), 'yyyyMMdd'))) AS key_id,
--       scenic_spot_code    AS scenic_id,
--       scenic_spot_name    AS scenic_name,
--       cast('舆情-情绪趋势' AS string) AS indicator_domain,
--       target_name,
--       target_desc,
--       date_type,
--       data_value,
--       '舆情'              AS data_domain,
--       cast(date_format(date_sub(current_date(), 1), 'yyyyMMdd') AS int) AS travel_date
--   FROM trend_long

--   UNION ALL

--   SELECT
--       md5(concat_ws('|', scenic_spot_code, target_name, date_type, date_format(date_sub(current_date(), 1), 'yyyyMMdd'))) AS key_id,
--       scenic_spot_code    AS scenic_id,
--       scenic_spot_name    AS scenic_name,
--       cast('舆情-情绪得分' AS string) AS indicator_domain,
--       target_name,
--       target_desc,
--       date_type,
--       data_value,
--       '舆情'              AS data_domain,
--       cast(date_format(date_sub(current_date(), 1), 'yyyyMMdd') AS int) AS travel_date
--   FROM emotion_long
