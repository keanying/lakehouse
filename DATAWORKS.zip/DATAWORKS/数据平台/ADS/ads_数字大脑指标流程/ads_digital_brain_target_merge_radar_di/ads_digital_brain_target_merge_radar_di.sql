WITH base AS (
SELECT
    MD5(CONCAT_WS('|', ${bizdate}, '业态-雷达图', final.scenic_id, target_desc, date_type, target_name)) AS key_id,
    final.scenic_id            AS scenic_id,
    dim_scenic.scenic_name  AS scenic_name,
    '业态-雷达图'            AS indicator_domain,
    target_name             AS target_name,
    target_desc             AS target_desc,
    date_type               AS date_type,
    data_value              AS data_value,
    '业态'                  AS data_domain,
    ${bizdate}              AS travel_date
FROM (
WITH dates AS (
    SELECT
        ${bizdate} AS d_cur,
        INT(DATE_FORMAT(TO_DATE(CAST(${bizdate} AS STRING), 'yyyyMMdd') - 6,   'yyyyMMdd')) AS d_6,
        INT(DATE_FORMAT(TO_DATE(CAST(${bizdate} AS STRING), 'yyyyMMdd') - 29,  'yyyyMMdd')) AS d_29,
        INT(DATE_FORMAT(TO_DATE(CAST(${bizdate} AS STRING), 'yyyyMMdd') - 89,  'yyyyMMdd')) AS d_89,
        INT(DATE_FORMAT(TO_DATE(CAST(${bizdate} AS STRING), 'yyyyMMdd') - 179, 'yyyyMMdd')) AS d_179,
        INT(DATE_FORMAT(NEXT_DAY(TO_DATE(CAST(${bizdate} AS STRING), 'yyyyMMdd'), 'MON') - 7, 'yyyyMMdd')) AS d_week,
        INT(DATE_FORMAT(TRUNC(TO_DATE(CAST(${bizdate} AS STRING), 'yyyyMMdd'), 'MM'), 'yyyyMMdd')) AS d_month
),
sup_rel AS (
    SELECT t2.scenic_id, s.sup_id
    FROM dim_prd_scenic_supplier_relation_f t2
    LATERAL VIEW EXPLODE(FROM_JSON(t2.suppliers, 'ARRAY<BIGINT>')) s AS sup_id
),
scenic_agg AS (
    SELECT
        sup.scenic_id,
        SUM(IF(t.travel_date =  p.d_cur, t.net_sales_income_amt, 0)) AS net_1d,
        SUM(IF(t.travel_date >= p.d_6,   t.net_sales_income_amt, 0)) AS net_7d,
        SUM(IF(t.travel_date >= p.d_29,  t.net_sales_income_amt, 0)) AS net_30d,
        SUM(IF(t.travel_date >= p.d_89,  t.net_sales_income_amt, 0)) AS net_90d,
        SUM(IF(t.travel_date >= p.d_179, t.net_sales_income_amt, 0)) AS net_180d,
        SUM(IF(t.travel_date >= p.d_week,  t.net_sales_income_amt, 0)) AS net_week,
        SUM(IF(t.travel_date >= p.d_month, t.net_sales_income_amt, 0)) AS net_month,

        SUM(IF(t.travel_date =  p.d_cur, t.verify_ticket_qty, 0)) AS verify_1d,
        SUM(IF(t.travel_date >= p.d_6,   t.verify_ticket_qty, 0)) AS verify_7d,
        SUM(IF(t.travel_date >= p.d_29,  t.verify_ticket_qty, 0)) AS verify_30d,
        SUM(IF(t.travel_date >= p.d_89,  t.verify_ticket_qty, 0)) AS verify_90d,
        SUM(IF(t.travel_date >= p.d_179, t.verify_ticket_qty, 0)) AS verify_180d,
        SUM(IF(t.travel_date >= p.d_week,  t.verify_ticket_qty, 0)) AS verify_week,
        SUM(IF(t.travel_date >= p.d_month, t.verify_ticket_qty, 0)) AS verify_month,

        SUM(IF(t.travel_date =  p.d_cur, t.sales_income_amt, 0)) AS amt_1d,
        SUM(IF(t.travel_date >= p.d_6,   t.sales_income_amt, 0)) AS amt_7d,
        SUM(IF(t.travel_date >= p.d_29,  t.sales_income_amt, 0)) AS amt_30d,
        SUM(IF(t.travel_date >= p.d_89,  t.sales_income_amt, 0)) AS amt_90d,
        SUM(IF(t.travel_date >= p.d_179, t.sales_income_amt, 0)) AS amt_180d,
        SUM(IF(t.travel_date >= p.d_week,  t.sales_income_amt, 0)) AS amt_week,
        SUM(IF(t.travel_date >= p.d_month, t.sales_income_amt, 0)) AS amt_month,

        SUM(IF(t.travel_date =  p.d_cur, t.sales_order_qty, 0)) AS qty_1d,
        SUM(IF(t.travel_date >= p.d_6,   t.sales_order_qty, 0)) AS qty_7d,
        SUM(IF(t.travel_date >= p.d_29,  t.sales_order_qty, 0)) AS qty_30d,
        SUM(IF(t.travel_date >= p.d_89,  t.sales_order_qty, 0)) AS qty_90d,
        SUM(IF(t.travel_date >= p.d_179, t.sales_order_qty, 0)) AS qty_180d,
        SUM(IF(t.travel_date >= p.d_week,  t.sales_order_qty, 0)) AS qty_week,
        SUM(IF(t.travel_date >= p.d_month, t.sales_order_qty, 0)) AS qty_month
    FROM dws_mps_sup_report_summary_di t
    JOIN sup_rel sup ON t.sup_id = sup.sup_id
    JOIN dates p ON 1 = 1
    WHERE t.travel_date >= p.d_179
      AND t.travel_date <= p.d_cur
    GROUP BY sup.scenic_id
),
scenic_metric AS (
    SELECT scenic_id, net_1d, net_7d, net_30d, net_90d, net_180d, net_week, net_month,
           verify_1d, verify_7d, verify_30d, verify_90d, verify_180d, verify_week, verify_month,
           IF(qty_1d   > 0, ROUND(amt_1d   / qty_1d,   3), 0) AS aov_1d,
           IF(qty_7d   > 0, ROUND(amt_7d   / qty_7d,   3), 0) AS aov_7d,
           IF(qty_30d  > 0, ROUND(amt_30d  / qty_30d,  3), 0) AS aov_30d,
           IF(qty_90d  > 0, ROUND(amt_90d  / qty_90d,  3), 0) AS aov_90d,
           IF(qty_180d > 0, ROUND(amt_180d / qty_180d, 3), 0) AS aov_180d,
           IF(qty_week  > 0, ROUND(amt_week  / qty_week,  3), 0) AS aov_week,
           IF(qty_month > 0, ROUND(amt_month / qty_month, 3), 0) AS aov_month
    FROM scenic_agg
),
scenic_base AS (
    SELECT scenic_id, scenic_main_type, scenic_grade_level
    FROM dim_prd_scenic_base_yr_f
),
peer AS (
    SELECT
        bs.scenic_id,
        MAX(a.net_1d)   AS net_1d_max,   AVG(IF(a.net_1d   > 0, a.net_1d,   NULL)) AS net_1d_among,
        MAX(a.net_7d)   AS net_7d_max,   AVG(IF(a.net_7d   > 0, a.net_7d,   NULL)) AS net_7d_among,
        MAX(a.net_30d)  AS net_30d_max,  AVG(IF(a.net_30d  > 0, a.net_30d,  NULL)) AS net_30d_among,
        MAX(a.net_90d)  AS net_90d_max,  AVG(IF(a.net_90d  > 0, a.net_90d,  NULL)) AS net_90d_among,
        MAX(a.net_180d) AS net_180d_max, AVG(IF(a.net_180d > 0, a.net_180d, NULL)) AS net_180d_among,
        MAX(a.net_week)  AS net_week_max,  AVG(IF(a.net_week  > 0, a.net_week,  NULL)) AS net_week_among,
        MAX(a.net_month) AS net_month_max, AVG(IF(a.net_month > 0, a.net_month, NULL)) AS net_month_among,

        MAX(a.verify_1d)   AS verify_1d_max,   AVG(IF(a.verify_1d   > 0, a.verify_1d,   NULL)) AS verify_1d_among,
        MAX(a.verify_7d)   AS verify_7d_max,   AVG(IF(a.verify_7d   > 0, a.verify_7d,   NULL)) AS verify_7d_among,
        MAX(a.verify_30d)  AS verify_30d_max,  AVG(IF(a.verify_30d  > 0, a.verify_30d,  NULL)) AS verify_30d_among,
        MAX(a.verify_90d)  AS verify_90d_max,  AVG(IF(a.verify_90d  > 0, a.verify_90d,  NULL)) AS verify_90d_among,
        MAX(a.verify_180d) AS verify_180d_max, AVG(IF(a.verify_180d > 0, a.verify_180d, NULL)) AS verify_180d_among,
        MAX(a.verify_week)  AS verify_week_max,  AVG(IF(a.verify_week  > 0, a.verify_week,  NULL)) AS verify_week_among,
        MAX(a.verify_month) AS verify_month_max, AVG(IF(a.verify_month > 0, a.verify_month, NULL)) AS verify_month_among,

        MAX(a.aov_1d)   AS aov_1d_max,   AVG(IF(a.aov_1d   > 0, a.aov_1d,   NULL)) AS aov_1d_among,
        MAX(a.aov_7d)   AS aov_7d_max,   AVG(IF(a.aov_7d   > 0, a.aov_7d,   NULL)) AS aov_7d_among,
        MAX(a.aov_30d)  AS aov_30d_max,  AVG(IF(a.aov_30d  > 0, a.aov_30d,  NULL)) AS aov_30d_among,
        MAX(a.aov_90d)  AS aov_90d_max,  AVG(IF(a.aov_90d  > 0, a.aov_90d,  NULL)) AS aov_90d_among,
        MAX(a.aov_180d) AS aov_180d_max, AVG(IF(a.aov_180d > 0, a.aov_180d, NULL)) AS aov_180d_among,
        MAX(a.aov_week)  AS aov_week_max,  AVG(IF(a.aov_week  > 0, a.aov_week,  NULL)) AS aov_week_among,
        MAX(a.aov_month) AS aov_month_max, AVG(IF(a.aov_month > 0, a.aov_month, NULL)) AS aov_month_among
    FROM scenic_base bs
    JOIN scenic_base b
      ON b.scenic_main_type  = bs.scenic_main_type
     AND b.scenic_grade_level = bs.scenic_grade_level
    JOIN scenic_metric a ON a.scenic_id = b.scenic_id
    WHERE bs.scenic_id IN('PFTSCA01018088', 'PFTSCA01016184', 'PFTSCA01018066', 'PFTSCZ01022547')
    GROUP BY bs.scenic_id
)

SELECT m.scenic_id, '我的数据' AS target_name, target_desc, date_type, data_value
FROM scenic_metric m
LATERAL VIEW stack(21,
    '票房收入(元)', '1d',   CAST(m.net_1d   AS DECIMAL(10,2)),
    '票房收入(元)', '7d',   CAST(m.net_7d   AS DECIMAL(10,2)),
    '票房收入(元)', '30d',  CAST(m.net_30d  AS DECIMAL(10,2)),
    '票房收入(元)', '90d',  CAST(m.net_90d  AS DECIMAL(10,2)),
    '票房收入(元)', '180d', CAST(m.net_180d AS DECIMAL(10,2)),
    '票房收入(元)', 'week',  CAST(m.net_week  AS DECIMAL(10,2)),
    '票房收入(元)', 'month', CAST(m.net_month AS DECIMAL(10,2)),
    '核销票量(张)', '1d',   CAST(m.verify_1d   AS DECIMAL(10,2)),
    '核销票量(张)', '7d',   CAST(m.verify_7d   AS DECIMAL(10,2)),
    '核销票量(张)', '30d',  CAST(m.verify_30d  AS DECIMAL(10,2)),
    '核销票量(张)', '90d',  CAST(m.verify_90d  AS DECIMAL(10,2)),
    '核销票量(张)', '180d', CAST(m.verify_180d AS DECIMAL(10,2)),
    '核销票量(张)', 'week',  CAST(m.verify_week  AS DECIMAL(10,2)),
    '核销票量(张)', 'month', CAST(m.verify_month AS DECIMAL(10,2)),
    '客单价(元)',   '1d',   CAST(m.aov_1d   AS DECIMAL(10,2)),
    '客单价(元)',   '7d',   CAST(m.aov_7d   AS DECIMAL(10,2)),
    '客单价(元)',   '30d',  CAST(m.aov_30d  AS DECIMAL(10,2)),
    '客单价(元)',   '90d',  CAST(m.aov_90d  AS DECIMAL(10,2)),
    '客单价(元)',   '180d', CAST(m.aov_180d AS DECIMAL(10,2)),
    '客单价(元)',   'week',  CAST(m.aov_week  AS DECIMAL(10,2)),
    '客单价(元)',   'month', CAST(m.aov_month AS DECIMAL(10,2))
) ind AS target_desc, date_type, data_value
WHERE m.scenic_id IN('PFTSCA01018088', 'PFTSCA01016184', 'PFTSCA01018066', 'PFTSCZ01022547')

UNION ALL

SELECT p.scenic_id, '同类景区最高' AS target_name, target_desc, date_type, data_value
FROM peer p
LEFT JOIN scenic_metric m ON m.scenic_id = p.scenic_id
LATERAL VIEW stack(21,
    '票房收入(元)', '1d',   CAST(GREATEST(p.net_1d_max,   IFNULL(m.net_1d,   0)) AS DECIMAL(10,2)),
    '票房收入(元)', '7d',   CAST(GREATEST(p.net_7d_max,   IFNULL(m.net_7d,   0)) AS DECIMAL(10,2)),
    '票房收入(元)', '30d',  CAST(GREATEST(p.net_30d_max,  IFNULL(m.net_30d,  0)) AS DECIMAL(10,2)),
    '票房收入(元)', '90d',  CAST(GREATEST(p.net_90d_max,  IFNULL(m.net_90d,  0)) AS DECIMAL(10,2)),
    '票房收入(元)', '180d', CAST(GREATEST(p.net_180d_max, IFNULL(m.net_180d, 0)) AS DECIMAL(10,2)),
    '票房收入(元)', 'week',  CAST(GREATEST(p.net_week_max,   IFNULL(m.net_week,   0)) AS DECIMAL(10,2)),
    '票房收入(元)', 'month', CAST(GREATEST(p.net_month_max,  IFNULL(m.net_month,  0)) AS DECIMAL(10,2)),
    '核销票量(张)', '1d',   CAST(GREATEST(p.verify_1d_max,   IFNULL(m.verify_1d,   0)) AS DECIMAL(10,2)),
    '核销票量(张)', '7d',   CAST(GREATEST(p.verify_7d_max,   IFNULL(m.verify_7d,   0)) AS DECIMAL(10,2)),
    '核销票量(张)', '30d',  CAST(GREATEST(p.verify_30d_max,  IFNULL(m.verify_30d,  0)) AS DECIMAL(10,2)),
    '核销票量(张)', '90d',  CAST(GREATEST(p.verify_90d_max,  IFNULL(m.verify_90d,  0)) AS DECIMAL(10,2)),
    '核销票量(张)', '180d', CAST(GREATEST(p.verify_180d_max, IFNULL(m.verify_180d, 0)) AS DECIMAL(10,2)),
    '核销票量(张)', 'week',  CAST(GREATEST(p.verify_week_max,   IFNULL(m.verify_week,   0)) AS DECIMAL(10,2)),
    '核销票量(张)', 'month', CAST(GREATEST(p.verify_month_max,  IFNULL(m.verify_month,  0)) AS DECIMAL(10,2)),
    '客单价(元)',   '1d',   CAST(GREATEST(p.aov_1d_max,   IFNULL(m.aov_1d,   0)) AS DECIMAL(10,2)),
    '客单价(元)',   '7d',   CAST(GREATEST(p.aov_7d_max,   IFNULL(m.aov_7d,   0)) AS DECIMAL(10,2)),
    '客单价(元)',   '30d',  CAST(GREATEST(p.aov_30d_max,  IFNULL(m.aov_30d,  0)) AS DECIMAL(10,2)),
    '客单价(元)',   '90d',  CAST(GREATEST(p.aov_90d_max,  IFNULL(m.aov_90d,  0)) AS DECIMAL(10,2)),
    '客单价(元)',   '180d', CAST(GREATEST(p.aov_180d_max, IFNULL(m.aov_180d, 0)) AS DECIMAL(10,2)),
    '客单价(元)',   'week',  CAST(GREATEST(p.aov_week_max,   IFNULL(m.aov_week,   0)) AS DECIMAL(10,2)),
    '客单价(元)',   'month', CAST(GREATEST(p.aov_month_max,  IFNULL(m.aov_month,  0)) AS DECIMAL(10,2))
) ind AS target_desc, date_type, data_value

UNION ALL

SELECT p.scenic_id, '同类景区平均' AS target_name, target_desc, date_type, data_value
FROM peer p
LATERAL VIEW stack(21,
    '票房收入(元)', '1d',   CAST(IFNULL(p.net_1d_among,   0) AS DECIMAL(10,2)),
    '票房收入(元)', '7d',   CAST(IFNULL(p.net_7d_among,   0) AS DECIMAL(10,2)),
    '票房收入(元)', '30d',  CAST(IFNULL(p.net_30d_among,  0) AS DECIMAL(10,2)),
    '票房收入(元)', '90d',  CAST(IFNULL(p.net_90d_among,  0) AS DECIMAL(10,2)),
    '票房收入(元)', '180d', CAST(IFNULL(p.net_180d_among, 0) AS DECIMAL(10,2)),
    '票房收入(元)', 'week',  CAST(IFNULL(p.net_week_among,   0) AS DECIMAL(10,2)),
    '票房收入(元)', 'month', CAST(IFNULL(p.net_month_among,  0) AS DECIMAL(10,2)),
    '核销票量(张)', '1d',   CAST(ROUND(IFNULL(p.verify_1d_among,   0)) AS DECIMAL(10,2)),
    '核销票量(张)', '7d',   CAST(ROUND(IFNULL(p.verify_7d_among,   0)) AS DECIMAL(10,2)),
    '核销票量(张)', '30d',  CAST(ROUND(IFNULL(p.verify_30d_among,  0)) AS DECIMAL(10,2)),
    '核销票量(张)', '90d',  CAST(ROUND(IFNULL(p.verify_90d_among,  0)) AS DECIMAL(10,2)),
    '核销票量(张)', '180d', CAST(ROUND(IFNULL(p.verify_180d_among, 0)) AS DECIMAL(10,2)),
    '核销票量(张)', 'week',  CAST(ROUND(IFNULL(p.verify_week_among,   0)) AS DECIMAL(10,2)),
    '核销票量(张)', 'month', CAST(ROUND(IFNULL(p.verify_month_among,  0)) AS DECIMAL(10,2)),
    '客单价(元)',   '1d',   CAST(IFNULL(p.aov_1d_among,   0) AS DECIMAL(10,2)),
    '客单价(元)',   '7d',   CAST(IFNULL(p.aov_7d_among,   0) AS DECIMAL(10,2)),
    '客单价(元)',   '30d',  CAST(IFNULL(p.aov_30d_among,  0) AS DECIMAL(10,2)),
    '客单价(元)',   '90d',  CAST(IFNULL(p.aov_90d_among,  0) AS DECIMAL(10,2)),
    '客单价(元)',   '180d', CAST(IFNULL(p.aov_180d_among, 0) AS DECIMAL(10,2)),
    '客单价(元)',   'week',  CAST(IFNULL(p.aov_week_among,   0) AS DECIMAL(10,2)),
    '客单价(元)',   'month', CAST(IFNULL(p.aov_month_among,  0) AS DECIMAL(10,2))
) ind AS target_desc, date_type, data_value
) final
JOIN dim_prd_scenic_supplier_relation_f dim_scenic
    ON final.scenic_id = dim_scenic.scenic_id

UNION ALL

SELECT
    MD5(CONCAT_WS('|', ${bizdate}, '业态-雷达图', final.scenic_id, target_desc, date_type, target_name)) AS key_id,
    final.scenic_id            AS scenic_id,
    dim_scenic.scenic_name  AS scenic_name,
    '业态-雷达图'            AS indicator_domain,
    target_name             AS target_name,
    target_desc             AS target_desc,
    date_type               AS date_type,
    data_value              AS data_value,
    '业态'                  AS data_domain,
    ${bizdate}              AS travel_date
FROM (
WITH dates AS (
    SELECT
        ${bizdate} AS d_cur,
        INT(DATE_FORMAT(TO_DATE(CAST(${bizdate} AS STRING), 'yyyyMMdd') - 6,   'yyyyMMdd')) AS d_6,
        INT(DATE_FORMAT(TO_DATE(CAST(${bizdate} AS STRING), 'yyyyMMdd') - 29,  'yyyyMMdd')) AS d_29,
        INT(DATE_FORMAT(TO_DATE(CAST(${bizdate} AS STRING), 'yyyyMMdd') - 89,  'yyyyMMdd')) AS d_89,
        INT(DATE_FORMAT(TO_DATE(CAST(${bizdate} AS STRING), 'yyyyMMdd') - 179, 'yyyyMMdd')) AS d_179,
        INT(DATE_FORMAT(NEXT_DAY(TO_DATE(CAST(${bizdate} AS STRING), 'yyyyMMdd'), 'MON') - 7, 'yyyyMMdd')) AS d_week,
        INT(DATE_FORMAT(TRUNC(TO_DATE(CAST(${bizdate} AS STRING), 'yyyyMMdd'), 'MM'), 'yyyyMMdd')) AS d_month
),
sup_rel AS (
    SELECT t2.scenic_id, s.sup_id
    FROM dim_prd_scenic_supplier_relation_f t2
    LATERAL VIEW EXPLODE(FROM_JSON(t2.suppliers, 'ARRAY<BIGINT>')) s AS sup_id
),
scenic_agg AS (
    SELECT
        sup.scenic_id,
        SUM(IF(t.travel_date =  p.d_cur, t.entry_park_visitors_qty, 0)) AS visitors_1d,
        SUM(IF(t.travel_date >= p.d_6,   t.entry_park_visitors_qty, 0)) AS visitors_7d,
        SUM(IF(t.travel_date >= p.d_29,  t.entry_park_visitors_qty, 0)) AS visitors_30d,
        SUM(IF(t.travel_date >= p.d_89,  t.entry_park_visitors_qty, 0)) AS visitors_90d,
        SUM(IF(t.travel_date >= p.d_179, t.entry_park_visitors_qty, 0)) AS visitors_180d,
        SUM(IF(t.travel_date >= p.d_week,  t.entry_park_visitors_qty, 0)) AS visitors_week,
        SUM(IF(t.travel_date >= p.d_month, t.entry_park_visitors_qty, 0)) AS visitors_month
    FROM dws_tps_sup_trf_tourist_di t
    JOIN sup_rel sup ON t.sup_id = sup.sup_id
    JOIN dates p ON 1 = 1
    WHERE t.travel_date >= p.d_179
      AND t.travel_date <= p.d_cur
    GROUP BY sup.scenic_id
),
scenic_base AS (
    SELECT scenic_id, scenic_main_type, scenic_grade_level
    FROM dim_prd_scenic_base_yr_f
),
peer AS (
    SELECT
        bs.scenic_id,
        MAX(a.visitors_1d)   AS visitors_1d_max,   AVG(IF(a.visitors_1d   > 0, a.visitors_1d,   NULL)) AS visitors_1d_among,
        MAX(a.visitors_7d)   AS visitors_7d_max,   AVG(IF(a.visitors_7d   > 0, a.visitors_7d,   NULL)) AS visitors_7d_among,
        MAX(a.visitors_30d)  AS visitors_30d_max,  AVG(IF(a.visitors_30d  > 0, a.visitors_30d,  NULL)) AS visitors_30d_among,
        MAX(a.visitors_90d)  AS visitors_90d_max,  AVG(IF(a.visitors_90d  > 0, a.visitors_90d,  NULL)) AS visitors_90d_among,
        MAX(a.visitors_180d) AS visitors_180d_max, AVG(IF(a.visitors_180d > 0, a.visitors_180d, NULL)) AS visitors_180d_among,
        MAX(a.visitors_week)  AS visitors_week_max,  AVG(IF(a.visitors_week  > 0, a.visitors_week,  NULL)) AS visitors_week_among,
        MAX(a.visitors_month) AS visitors_month_max, AVG(IF(a.visitors_month > 0, a.visitors_month, NULL)) AS visitors_month_among
    FROM scenic_base bs
    JOIN scenic_base b
      ON b.scenic_main_type  = bs.scenic_main_type
     AND b.scenic_grade_level = bs.scenic_grade_level
    JOIN scenic_agg a ON a.scenic_id = b.scenic_id
    WHERE bs.scenic_id IN('PFTSCA01018088', 'PFTSCA01016184', 'PFTSCA01018066', 'PFTSCZ01022547')
    GROUP BY bs.scenic_id
)

SELECT m.scenic_id, '我的数据' AS target_name, target_desc, date_type, data_value
FROM scenic_agg m
LATERAL VIEW stack(7,
    '总客流(人)', '1d',   CAST(m.visitors_1d   AS DECIMAL(10,2)),
    '总客流(人)', '7d',   CAST(m.visitors_7d   AS DECIMAL(10,2)),
    '总客流(人)', '30d',  CAST(m.visitors_30d  AS DECIMAL(10,2)),
    '总客流(人)', '90d',  CAST(m.visitors_90d  AS DECIMAL(10,2)),
    '总客流(人)', '180d', CAST(m.visitors_180d AS DECIMAL(10,2)),
    '总客流(人)', 'week',  CAST(m.visitors_week  AS DECIMAL(10,2)),
    '总客流(人)', 'month', CAST(m.visitors_month AS DECIMAL(10,2))
) ind AS target_desc, date_type, data_value
WHERE m.scenic_id IN('PFTSCA01018088', 'PFTSCA01016184', 'PFTSCA01018066', 'PFTSCZ01022547')

UNION ALL

SELECT p.scenic_id, '同类景区最高' AS target_name, target_desc, date_type, data_value
FROM peer p
LEFT JOIN scenic_agg m ON m.scenic_id = p.scenic_id
LATERAL VIEW stack(7,
    '总客流(人)', '1d',   CAST(GREATEST(p.visitors_1d_max,   IFNULL(m.visitors_1d,   0)) AS DECIMAL(10,2)),
    '总客流(人)', '7d',   CAST(GREATEST(p.visitors_7d_max,   IFNULL(m.visitors_7d,   0)) AS DECIMAL(10,2)),
    '总客流(人)', '30d',  CAST(GREATEST(p.visitors_30d_max,  IFNULL(m.visitors_30d,  0)) AS DECIMAL(10,2)),
    '总客流(人)', '90d',  CAST(GREATEST(p.visitors_90d_max,  IFNULL(m.visitors_90d,  0)) AS DECIMAL(10,2)),
    '总客流(人)', '180d', CAST(GREATEST(p.visitors_180d_max, IFNULL(m.visitors_180d, 0)) AS DECIMAL(10,2)),
    '总客流(人)', 'week',  CAST(GREATEST(p.visitors_week_max,   IFNULL(m.visitors_week,   0)) AS DECIMAL(10,2)),
    '总客流(人)', 'month', CAST(GREATEST(p.visitors_month_max,  IFNULL(m.visitors_month,  0)) AS DECIMAL(10,2))
) ind AS target_desc, date_type, data_value

UNION ALL

SELECT p.scenic_id, '同类景区平均' AS target_name, target_desc, date_type, data_value
FROM peer p
LATERAL VIEW stack(7,
    '总客流(人)', '1d',   CAST(ROUND(IFNULL(p.visitors_1d_among,   0)) AS DECIMAL(10,2)),
    '总客流(人)', '7d',   CAST(ROUND(IFNULL(p.visitors_7d_among,   0)) AS DECIMAL(10,2)),
    '总客流(人)', '30d',  CAST(ROUND(IFNULL(p.visitors_30d_among,  0)) AS DECIMAL(10,2)),
    '总客流(人)', '90d',  CAST(ROUND(IFNULL(p.visitors_90d_among,  0)) AS DECIMAL(10,2)),
    '总客流(人)', '180d', CAST(ROUND(IFNULL(p.visitors_180d_among, 0)) AS DECIMAL(10,2)),
    '总客流(人)', 'week',  CAST(ROUND(IFNULL(p.visitors_week_among,   0)) AS DECIMAL(10,2)),
    '总客流(人)', 'month', CAST(ROUND(IFNULL(p.visitors_month_among,  0)) AS DECIMAL(10,2))
) ind AS target_desc, date_type, data_value
) final
JOIN dim_prd_scenic_supplier_relation_f dim_scenic
    ON final.scenic_id = dim_scenic.scenic_id

UNION ALL

SELECT
    MD5(CONCAT_WS('|', ${bizdate}, '业态-雷达图', final.scenic_id, target_desc, date_type, target_name)) AS key_id,
    final.scenic_id            AS scenic_id,
    dim_scenic.scenic_name  AS scenic_name,
    '业态-雷达图'            AS indicator_domain,
    target_name             AS target_name,
    target_desc             AS target_desc,
    date_type               AS date_type,
    data_value              AS data_value,
    '业态'                  AS data_domain,
    ${bizdate}              AS travel_date
FROM (
WITH score AS (
    SELECT
        scenic_id,
        time_granularity,
        overall_sentiment_score AS score
    FROM ads_trf_social_opinion_macro_gran_metric_di
    WHERE scenic_id IN('PFTSCA01018088', 'PFTSCA01016184', 'PFTSCA01018066', 'PFTSCZ01022547')
      AND channel = 'all'
      AND travel_date = ${bizdate}
      AND time_granularity IN ('latest_1d', 'latest_7d', 'latest_30d', 'latest_90d', 'wtd', 'mtd')
),
own AS (
    SELECT
        scenic_id,
        MAX(IF(time_granularity = 'latest_1d',  score, NULL)) AS score_1d,
        MAX(IF(time_granularity = 'latest_7d',  score, NULL)) AS score_7d,
        MAX(IF(time_granularity = 'latest_30d', score, NULL)) AS score_30d,
        MAX(IF(time_granularity = 'latest_90d', score, NULL)) AS score_90d,
        MAX(IF(time_granularity = 'wtd',        score, NULL)) AS score_week,
        MAX(IF(time_granularity = 'mtd',        score, NULL)) AS score_month
    FROM score
    GROUP BY scenic_id
)

SELECT o.scenic_id, '我的数据' AS target_name, target_desc, date_type, data_value
FROM own o

LATERAL VIEW stack(6,
    '口碑分', '1d',   CAST(IFNULL(o.score_1d,   0) AS DECIMAL(10,2)),
    '口碑分', '7d',   CAST(IFNULL(o.score_7d,   0) AS DECIMAL(10,2)),
    '口碑分', '30d',  CAST(IFNULL(o.score_30d,  0) AS DECIMAL(10,2)),
    '口碑分', '90d',  CAST(IFNULL(o.score_90d,  0) AS DECIMAL(10,2)),
    '口碑分', 'week',  CAST(IFNULL(o.score_week,  0) AS DECIMAL(10,2)),
    '口碑分', 'month', CAST(IFNULL(o.score_month, 0) AS DECIMAL(10,2))
) ind AS target_desc, date_type, data_value

UNION ALL

SELECT o.scenic_id, '同类景区最高' AS target_name, target_desc, date_type, 5 AS data_value
FROM own o
LATERAL VIEW stack(6,
    '口碑分', '1d',   CAST(5 AS DECIMAL(10,2)),
    '口碑分', '7d',   CAST(5 AS DECIMAL(10,2)),
    '口碑分', '30d',  CAST(5 AS DECIMAL(10,2)),
    '口碑分', '90d',  CAST(5 AS DECIMAL(10,2)),
    '口碑分', 'week',  CAST(5 AS DECIMAL(10,2)),
    '口碑分', 'month', CAST(5 AS DECIMAL(10,2))
) ind AS target_desc, date_type, data_value

-- UNION ALL

-- SELECT o.scenic_id, '同类景区平均' AS target_name, target_desc, date_type, 2.5 AS data_value
-- FROM own o
-- LATERAL VIEW stack(6,
--     '口碑分', '1d',   CAST(2.5 AS DECIMAL(10,2)),
--     '口碑分', '7d',   CAST(2.5 AS DECIMAL(10,2)),
--     '口碑分', '30d',  CAST(2.5 AS DECIMAL(10,2)),
--     '口碑分', '90d',  CAST(2.5 AS DECIMAL(10,2)),
--     '口碑分', 'week',  CAST(2.5 AS DECIMAL(10,2)),
--     '口碑分', 'month', CAST(2.5 AS DECIMAL(10,2))
-- ) ind AS target_desc, date_type, data_value
) final
JOIN dim_prd_scenic_supplier_relation_f dim_scenic
    ON final.scenic_id = dim_scenic.scenic_id
)

INSERT OVERWRITE TABLE ads_digital_brain_target_merge_di PARTITION(`data_domain`, `travel_date`)
SELECT
    key_id,
    scenic_id,
    scenic_name,
    indicator_domain,
    target_name,
    target_desc,
    date_type,
    data_value,
    data_domain,
    travel_date
FROM base

UNION ALL


SELECT
    CONCAT(key_id, '1') AS key_id,
    'PFTSCM00000001'    AS scenic_id,
    'A级景区'            AS scenic_name,
    indicator_domain,
    target_name,
    target_desc,
    date_type,
    data_value,
    data_domain,
    travel_date
FROM base
WHERE scenic_id = 'PFTSCA01018088';
