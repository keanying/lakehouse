--@exclude_input=default_workspace_svwh.default.dws_tps_sup_trf_tourist_di
--@exclude_input=default_workspace_svwh.default.dws_mps_prd_report_summary_di
--@exclude_input=default_workspace_svwh.default.dws_mps_trf_report_summary_di
--@exclude_input=default_workspace_svwh.default.dws_mps_sup_report_summary_di
--@exclude_input=default_workspace_svwh.default.dim_prd_scenic_supplier_relation_f
--@exclude_input=5084336752510044864
--@exclude_input=8431846476909318361
--Serverless Spark SQL
--********************************************************************--
--author: 王海阳
--create time: 2026-10-20 15:29:04
--Serverless Spark SQL任务只能运行在独享资源组上
--********************************************************************--

INSERT OVERWRITE TABLE ads_digital_brain_target_merge_di PARTITION(`data_domain`, `travel_date`)
SELECT 
    MD5(CONCAT_WS('|', ${bizdate}, '票务-出入园指标', agg.scenic_id, target_desc, date_type)) AS key_id,
    agg.scenic_id,
    dim_scenic.scenic_name        AS scenic_name,
    '票务-出入园指标'            AS indicator_domain,
    target_name                 AS target_name,
    target_desc                 AS target_desc,
    date_type                   AS date_type,
    data_value                  AS data_value,
    '票务'                      AS data_domain,
    ${bizdate}                  AS travel_date
FROM (
    SELECT 
        sup.scenic_id AS scenic_id,

        SUM(IF(t.travel_date =  p.d_cur, t.entry_park_visitors_qty, 0))                            AS entry_park_visitors_qty_1d,
        SUM(IF(t.travel_date >= p.d_7   AND t.travel_date <= p.d_cur, t.entry_park_visitors_qty, 0)) AS entry_park_visitors_qty_7d,
        SUM(IF(t.travel_date >= p.d_30  AND t.travel_date <= p.d_cur, t.entry_park_visitors_qty, 0)) AS entry_park_visitors_qty_30d,
        SUM(IF(t.travel_date >= p.d_90  AND t.travel_date <= p.d_cur, t.entry_park_visitors_qty, 0)) AS entry_park_visitors_qty_90d,
        SUM(IF(t.travel_date >= p.d_180 AND t.travel_date <= p.d_cur, t.entry_park_visitors_qty, 0)) AS entry_park_visitors_qty_180d,
        SUM(IF(t.travel_date >= p.d_week   AND t.travel_date <= p.d_cur, t.entry_park_visitors_qty, 0)) AS entry_park_visitors_qty_week,
        SUM(IF(t.travel_date >= p.d_month   AND t.travel_date <= p.d_cur, t.entry_park_visitors_qty, 0)) AS entry_park_visitors_qty_month,

        SUM(IF(t.travel_date =  p.d_1,     t.entry_park_visitors_qty, 0))                            AS entry_park_visitors_qty_prev_1d,
        SUM(IF(t.travel_date >= p.d_14 AND t.travel_date < p.d_7,   t.entry_park_visitors_qty, 0)) AS entry_park_visitors_qty_prev_7d,
        SUM(IF(t.travel_date >= p.d_60 AND t.travel_date < p.d_30,  t.entry_park_visitors_qty, 0)) AS entry_park_visitors_qty_prev_30d,
        SUM(IF(t.travel_date >= p.d_180 AND t.travel_date < p.d_90, t.entry_park_visitors_qty, 0)) AS entry_park_visitors_qty_prev_90d,
        SUM(IF(t.travel_date >= p.d_360 AND t.travel_date < p.d_180,t.entry_park_visitors_qty, 0)) AS entry_park_visitors_qty_prev_180d

    FROM dws_tps_sup_trf_tourist_di t
    JOIN (
        SELECT t2.scenic_id, s.sup_id
        FROM dim_prd_scenic_supplier_relation_f t2
        LATERAL VIEW EXPLODE(FROM_JSON(t2.suppliers, 'ARRAY<BIGINT>')) s AS sup_id
        WHERE t2.travel_date = ${bizdate} and t2.scenic_id IN('PFTSCA01018088', 'PFTSCA01016184', 'PFTSCA01018066', 'PFTSCM00000001', 'PFTSCZ01022547')
    ) sup ON t.sup_id = sup.sup_id
    JOIN (
        SELECT 
            ${bizdate} AS d_cur,
            INT(DATE_FORMAT(TO_DATE(CAST(${bizdate} AS STRING), 'yyyyMMdd') - 1,   'yyyyMMdd')) AS d_1,
            INT(DATE_FORMAT(TO_DATE(CAST(${bizdate} AS STRING), 'yyyyMMdd') - 6,   'yyyyMMdd')) AS d_7,
            INT(DATE_FORMAT(TO_DATE(CAST(${bizdate} AS STRING), 'yyyyMMdd') - 13,  'yyyyMMdd')) AS d_14,
            INT(DATE_FORMAT(TO_DATE(CAST(${bizdate} AS STRING), 'yyyyMMdd') - 29,  'yyyyMMdd')) AS d_30,
            INT(DATE_FORMAT(TO_DATE(CAST(${bizdate} AS STRING), 'yyyyMMdd') - 59,  'yyyyMMdd')) AS d_60,
            INT(DATE_FORMAT(TO_DATE(CAST(${bizdate} AS STRING), 'yyyyMMdd') - 89,  'yyyyMMdd')) AS d_90,
            INT(DATE_FORMAT(TO_DATE(CAST(${bizdate} AS STRING), 'yyyyMMdd') - 179, 'yyyyMMdd')) AS d_180,
            INT(DATE_FORMAT(TO_DATE(CAST(${bizdate} AS STRING), 'yyyyMMdd') - 359, 'yyyyMMdd')) AS d_360,
            INT(DATE_FORMAT(NEXT_DAY(TO_DATE(CAST(${bizdate} AS STRING), 'yyyyMMdd'), 'MON') - 7, 'yyyyMMdd')) AS d_week,
            INT(DATE_FORMAT(TRUNC(TO_DATE(CAST(${bizdate} AS STRING), 'yyyyMMdd'), 'MM'), 'yyyyMMdd')) AS d_month
    ) p ON 1 = 1
    WHERE t.travel_date >= p.d_360
      AND t.travel_date <= p.d_cur
    GROUP BY sup.scenic_id
) agg
JOIN dim_prd_scenic_supplier_relation_f dim_scenic
    ON agg.scenic_id = dim_scenic.scenic_id
LATERAL VIEW stack(12,
    '今日入园人数',    '今日入园人数(人)',        '1d',   CAST(entry_park_visitors_qty_1d   AS DECIMAL(10,2)),
    '近7天入园人数',   '近7天入园人数(人)',       '7d',   CAST(entry_park_visitors_qty_7d   AS DECIMAL(10,2)),
    '近30天入园人数',  '近30天入园人数(人)',      '30d',  CAST(entry_park_visitors_qty_30d  AS DECIMAL(10,2)),
    '近90天入园人数',  '近90天入园人数(人)',      '90d',  CAST(entry_park_visitors_qty_90d  AS DECIMAL(10,2)),
    '近180天入园人数', '近180天入园人数(人)',     '180d', CAST(entry_park_visitors_qty_180d AS DECIMAL(10,2)),
    '本周入园人数',    '本周入园人数(人)',        'week',  CAST(entry_park_visitors_qty_week    AS DECIMAL(10,2)),
    '本月入园人数',    '本月入园人数(人)',        'month', CAST(entry_park_visitors_qty_month    AS DECIMAL(10,2)),

    '今日入园人数环比',   '今日入园人数环比(%)',     '1d',   CAST(IFNULL((entry_park_visitors_qty_1d   - entry_park_visitors_qty_prev_1d)  / NULLIF(entry_park_visitors_qty_prev_1d,0)   * 100, 0) AS DECIMAL(10,2)),
    '近7天入园人数环比',  '近7天入园人数环比(%)',    '7d',   CAST(IFNULL((entry_park_visitors_qty_7d   - entry_park_visitors_qty_prev_7d)  / NULLIF(entry_park_visitors_qty_prev_7d,0)   * 100, 0) AS DECIMAL(10,2)),
    '近30天入园人数环比', '近30天入园人数环比(%)',   '30d',  CAST(IFNULL((entry_park_visitors_qty_30d  - entry_park_visitors_qty_prev_30d) / NULLIF(entry_park_visitors_qty_prev_30d,0)  * 100, 0) AS DECIMAL(10,2)),
    '近90天入园人数环比', '近90天入园人数环比(%)',   '90d',  CAST(IFNULL((entry_park_visitors_qty_90d  - entry_park_visitors_qty_prev_90d) / NULLIF(entry_park_visitors_qty_prev_90d,0)  * 100, 0) AS DECIMAL(10,2)),
    '近180天入园人数环比','近180天入园人数环比(%)',  '180d', CAST(IFNULL((entry_park_visitors_qty_180d - entry_park_visitors_qty_prev_180d)/ NULLIF(entry_park_visitors_qty_prev_180d,0) * 100, 0) AS DECIMAL(10,2))
) ind AS target_name, target_desc, date_type, data_value

UNION ALL

SELECT 
    MD5(CONCAT_WS('|', ${bizdate}, '票务-产品明细', agg.scenic_id, pft_scenic_id, date_type, target_desc)) AS key_id,
    agg.scenic_id,
    dim_scenic.scenic_name        AS scenic_name,
    '票务-产品明细'              AS indicator_domain,
    pft_scenic_name             AS target_name,
    target_desc                 AS target_desc,
    date_type                   AS date_type,
    data_value                  AS data_value,
    '票务'                      AS data_domain,
    ${bizdate}                  AS travel_date
FROM (
    SELECT 
        sup.scenic_id                    AS scenic_id,
        t.scenic_id                      AS pft_scenic_id,
        MAX(t.scenic_name)               AS pft_scenic_name,

        SUM(IF(t.travel_date =  p.d_cur, t.net_sales_income_amt, 0))                            AS net_sales_income_amt_1d,
        SUM(IF(t.travel_date >= p.d_7   AND t.travel_date <= p.d_cur, t.net_sales_income_amt, 0)) AS net_sales_income_amt_7d,
        SUM(IF(t.travel_date >= p.d_30  AND t.travel_date <= p.d_cur, t.net_sales_income_amt, 0)) AS net_sales_income_amt_30d,
        SUM(IF(t.travel_date >= p.d_90  AND t.travel_date <= p.d_cur, t.net_sales_income_amt, 0)) AS net_sales_income_amt_90d,
        SUM(IF(t.travel_date >= p.d_180 AND t.travel_date <= p.d_cur, t.net_sales_income_amt, 0)) AS net_sales_income_amt_180d,
        SUM(IF(t.travel_date >= p.d_week   AND t.travel_date <= p.d_cur, t.net_sales_income_amt, 0)) AS net_sales_income_amt_week,
        SUM(IF(t.travel_date >= p.d_month   AND t.travel_date <= p.d_cur, t.net_sales_income_amt, 0)) AS net_sales_income_amt_month,

        SUM(IF(t.travel_date =  p.d_1,     t.net_sales_income_amt, 0))                            AS net_sales_income_amt_prev_1d,
        SUM(IF(t.travel_date >= p.d_14 AND t.travel_date < p.d_7,   t.net_sales_income_amt, 0)) AS net_sales_income_amt_prev_7d,
        SUM(IF(t.travel_date >= p.d_60 AND t.travel_date < p.d_30,  t.net_sales_income_amt, 0)) AS net_sales_income_amt_prev_30d,
        SUM(IF(t.travel_date >= p.d_180 AND t.travel_date < p.d_90, t.net_sales_income_amt, 0)) AS net_sales_income_amt_prev_90d,
        SUM(IF(t.travel_date >= p.d_360 AND t.travel_date < p.d_180,t.net_sales_income_amt, 0)) AS net_sales_income_amt_prev_180d,

        SUM(IF(t.travel_date =  p.d_cur, t.net_sales_ticket_qty, 0))                             AS net_sales_ticket_qty_1d,
        SUM(IF(t.travel_date >= p.d_7   AND t.travel_date <= p.d_cur, t.net_sales_ticket_qty, 0)) AS net_sales_ticket_qty_7d,
        SUM(IF(t.travel_date >= p.d_30  AND t.travel_date <= p.d_cur, t.net_sales_ticket_qty, 0)) AS net_sales_ticket_qty_30d,
        SUM(IF(t.travel_date >= p.d_90  AND t.travel_date <= p.d_cur, t.net_sales_ticket_qty, 0)) AS net_sales_ticket_qty_90d,
        SUM(IF(t.travel_date >= p.d_180 AND t.travel_date <= p.d_cur, t.net_sales_ticket_qty, 0)) AS net_sales_ticket_qty_180d,
        SUM(IF(t.travel_date >= p.d_week   AND t.travel_date <= p.d_cur, t.net_sales_ticket_qty, 0)) AS net_sales_ticket_qty_week,
        SUM(IF(t.travel_date >= p.d_month   AND t.travel_date <= p.d_cur, t.net_sales_ticket_qty, 0)) AS net_sales_ticket_qty_month,

        SUM(IF(t.travel_date =  p.d_1,     t.net_sales_ticket_qty, 0))                             AS net_sales_ticket_qty_prev_1d,
        SUM(IF(t.travel_date >= p.d_14 AND t.travel_date < p.d_7,   t.net_sales_ticket_qty, 0)) AS net_sales_ticket_qty_prev_7d,
        SUM(IF(t.travel_date >= p.d_60 AND t.travel_date < p.d_30,  t.net_sales_ticket_qty, 0)) AS net_sales_ticket_qty_prev_30d,
        SUM(IF(t.travel_date >= p.d_180 AND t.travel_date < p.d_90, t.net_sales_ticket_qty, 0)) AS net_sales_ticket_qty_prev_90d,
        SUM(IF(t.travel_date >= p.d_360 AND t.travel_date < p.d_180,t.net_sales_ticket_qty, 0)) AS net_sales_ticket_qty_prev_180d

    FROM dws_mps_prd_report_summary_di t
    JOIN (
        SELECT t2.scenic_id, s.sup_id
        FROM dim_prd_scenic_supplier_relation_f t2
        LATERAL VIEW EXPLODE(FROM_JSON(t2.suppliers, 'ARRAY<BIGINT>')) s AS sup_id
        WHERE t2.scenic_id IN('PFTSCA01018088', 'PFTSCA01016184', 'PFTSCA01018066', 'PFTSCM00000001', 'PFTSCZ01022547')
    ) sup ON t.sup_id = sup.sup_id
    JOIN (
        SELECT 
            ${bizdate} AS d_cur,
            INT(DATE_FORMAT(TO_DATE(CAST(${bizdate} AS STRING), 'yyyyMMdd') - 1,   'yyyyMMdd')) AS d_1,
            INT(DATE_FORMAT(TO_DATE(CAST(${bizdate} AS STRING), 'yyyyMMdd') - 6,   'yyyyMMdd')) AS d_7,
            INT(DATE_FORMAT(TO_DATE(CAST(${bizdate} AS STRING), 'yyyyMMdd') - 13,  'yyyyMMdd')) AS d_14,
            INT(DATE_FORMAT(TO_DATE(CAST(${bizdate} AS STRING), 'yyyyMMdd') - 29,  'yyyyMMdd')) AS d_30,
            INT(DATE_FORMAT(TO_DATE(CAST(${bizdate} AS STRING), 'yyyyMMdd') - 59,  'yyyyMMdd')) AS d_60,
            INT(DATE_FORMAT(TO_DATE(CAST(${bizdate} AS STRING), 'yyyyMMdd') - 89,  'yyyyMMdd')) AS d_90,
            INT(DATE_FORMAT(TO_DATE(CAST(${bizdate} AS STRING), 'yyyyMMdd') - 179, 'yyyyMMdd')) AS d_180,
            INT(DATE_FORMAT(TO_DATE(CAST(${bizdate} AS STRING), 'yyyyMMdd') - 359, 'yyyyMMdd')) AS d_360,
            INT(DATE_FORMAT(NEXT_DAY(TO_DATE(CAST(${bizdate} AS STRING), 'yyyyMMdd'), 'MON') - 7, 'yyyyMMdd')) AS d_week,
            INT(DATE_FORMAT(TRUNC(TO_DATE(CAST(${bizdate} AS STRING), 'yyyyMMdd'), 'MM'), 'yyyyMMdd')) AS d_month
    ) p ON 1 = 1
    WHERE t.travel_date >= p.d_360
      AND t.travel_date <= p.d_cur 
    GROUP BY sup.scenic_id, t.scenic_id 
) agg
JOIN dim_prd_scenic_supplier_relation_f dim_scenic
    ON agg.scenic_id = dim_scenic.scenic_id
LATERAL VIEW stack(24,
    '产品营收金额(元)',      '1d',   CAST(net_sales_income_amt_1d   AS DECIMAL(10,2)),
    '产品营收金额(元)',      '7d',   CAST(net_sales_income_amt_7d   AS DECIMAL(10,2)),
    '产品营收金额(元)',      '30d',  CAST(net_sales_income_amt_30d  AS DECIMAL(10,2)),
    '产品营收金额(元)',      '90d',  CAST(net_sales_income_amt_90d  AS DECIMAL(10,2)),
    '产品营收金额(元)',      '180d', CAST(net_sales_income_amt_180d AS DECIMAL(10,2)),
    '产品营收金额(元)',      'week',  CAST(net_sales_income_amt_week  AS DECIMAL(10,2)),
    '产品营收金额(元)',      'month', CAST(net_sales_income_amt_month  AS DECIMAL(10,2)),

    '产品销量(张)',          '1d',   CAST(net_sales_ticket_qty_1d   AS DECIMAL(10,2)),
    '产品销量(张)',          '7d',   CAST(net_sales_ticket_qty_7d   AS DECIMAL(10,2)),
    '产品销量(张)',          '30d',  CAST(net_sales_ticket_qty_30d  AS DECIMAL(10,2)),
    '产品销量(张)',          '90d',  CAST(net_sales_ticket_qty_90d  AS DECIMAL(10,2)),
    '产品销量(张)',          '180d', CAST(net_sales_ticket_qty_180d AS DECIMAL(10,2)),
    '产品销量(张)',          'week',  CAST(net_sales_ticket_qty_week  AS DECIMAL(10,2)),
    '产品销量(张)',          'month', CAST(net_sales_ticket_qty_month  AS DECIMAL(10,2)),

    '产品营收金额环比(%)',   '1d',   CAST(IFNULL((net_sales_income_amt_1d   - net_sales_income_amt_prev_1d)  / NULLIF(net_sales_income_amt_prev_1d,0)   * 100, 0) AS DECIMAL(10,2)),
    '产品营收金额环比(%)',   '7d',   CAST(IFNULL((net_sales_income_amt_7d   - net_sales_income_amt_prev_7d)  / NULLIF(net_sales_income_amt_prev_7d,0)   * 100, 0) AS DECIMAL(10,2)),
    '产品营收金额环比(%)',   '30d',  CAST(IFNULL((net_sales_income_amt_30d  - net_sales_income_amt_prev_30d) / NULLIF(net_sales_income_amt_prev_30d,0)  * 100, 0) AS DECIMAL(10,2)),
    '产品营收金额环比(%)',   '90d',  CAST(IFNULL((net_sales_income_amt_90d  - net_sales_income_amt_prev_90d) / NULLIF(net_sales_income_amt_prev_90d,0)  * 100, 0) AS DECIMAL(10,2)),
    '产品营收金额环比(%)',   '180d', CAST(IFNULL((net_sales_income_amt_180d - net_sales_income_amt_prev_180d)/ NULLIF(net_sales_income_amt_prev_180d,0) * 100, 0) AS DECIMAL(10,2)),

    '产品销量环比(%)',       '1d',   CAST(IFNULL((net_sales_ticket_qty_1d   - net_sales_ticket_qty_prev_1d)  / NULLIF(net_sales_ticket_qty_prev_1d,0)   * 100, 0) AS DECIMAL(10,2)),
    '产品销量环比(%)',       '7d',   CAST(IFNULL((net_sales_ticket_qty_7d   - net_sales_ticket_qty_prev_7d)  / NULLIF(net_sales_ticket_qty_prev_7d,0)   * 100, 0) AS DECIMAL(10,2)),
    '产品销量环比(%)',       '30d',  CAST(IFNULL((net_sales_ticket_qty_30d  - net_sales_ticket_qty_prev_30d) / NULLIF(net_sales_ticket_qty_prev_30d,0)  * 100, 0) AS DECIMAL(10,2)),
    '产品销量环比(%)',       '90d',  CAST(IFNULL((net_sales_ticket_qty_90d  - net_sales_ticket_qty_prev_90d) / NULLIF(net_sales_ticket_qty_prev_90d,0)  * 100, 0) AS DECIMAL(10,2)),
    '产品销量环比(%)',       '180d', CAST(IFNULL((net_sales_ticket_qty_180d - net_sales_ticket_qty_prev_180d)/ NULLIF(net_sales_ticket_qty_prev_180d,0) * 100, 0) AS DECIMAL(10,2))
) ind AS target_desc, date_type, data_value

UNION ALL

SELECT 
    MD5(CONCAT_WS('|', ${bizdate}, '票务-渠道分布', agg.scenic_id, sales_channel_id, date_type, sales_channel_name, target_desc)) AS key_id,
    agg.scenic_id                AS scenic_id,
    dim_scenic.scenic_name        AS scenic_name,
    '票务-渠道分布'              AS indicator_domain,
    sales_channel_name          AS target_name,
    target_desc                 AS target_desc,
    date_type                   AS date_type,
    data_value                  AS data_value,
    '票务'                      AS data_domain,
    ${bizdate}                  AS travel_date
FROM (
    SELECT 
        sup.scenic_id                    AS scenic_id,
        t.sales_channel_id               AS sales_channel_id,
        MAX(t.sales_channel_name)        AS sales_channel_name,

        SUM(IF(t.travel_date =  p.d_cur, t.net_sales_income_amt, 0))                            AS net_sales_income_amt_1d,
        SUM(IF(t.travel_date >= p.d_7   AND t.travel_date <= p.d_cur, t.net_sales_income_amt, 0)) AS net_sales_income_amt_7d,
        SUM(IF(t.travel_date >= p.d_30  AND t.travel_date <= p.d_cur, t.net_sales_income_amt, 0)) AS net_sales_income_amt_30d,
        SUM(IF(t.travel_date >= p.d_90  AND t.travel_date <= p.d_cur, t.net_sales_income_amt, 0)) AS net_sales_income_amt_90d,
        SUM(IF(t.travel_date >= p.d_180 AND t.travel_date <= p.d_cur, t.net_sales_income_amt, 0)) AS net_sales_income_amt_180d,
        SUM(IF(t.travel_date >= p.d_week   AND t.travel_date <= p.d_cur, t.net_sales_income_amt, 0)) AS net_sales_income_amt_week,
        SUM(IF(t.travel_date >= p.d_month   AND t.travel_date <= p.d_cur, t.net_sales_income_amt, 0)) AS net_sales_income_amt_month,

        SUM(IF(t.travel_date =  p.d_1,     t.net_sales_income_amt, 0))                            AS net_sales_income_amt_prev_1d,   -- 前一日
        SUM(IF(t.travel_date >= p.d_14 AND t.travel_date < p.d_7,   t.net_sales_income_amt, 0)) AS net_sales_income_amt_prev_7d,   -- [D-13, D-7]
        SUM(IF(t.travel_date >= p.d_60 AND t.travel_date < p.d_30,  t.net_sales_income_amt, 0)) AS net_sales_income_amt_prev_30d,  -- [D-59, D-30]
        SUM(IF(t.travel_date >= p.d_180 AND t.travel_date < p.d_90, t.net_sales_income_amt, 0)) AS net_sales_income_amt_prev_90d,  -- [D-179, D-90]
        SUM(IF(t.travel_date >= p.d_360 AND t.travel_date < p.d_180,t.net_sales_income_amt, 0)) AS net_sales_income_amt_prev_180d  -- [D-359, D-180]

    FROM dws_mps_trf_report_summary_di t
    JOIN (
        SELECT t2.scenic_id, s.sup_id
        FROM dim_prd_scenic_supplier_relation_f t2
        LATERAL VIEW EXPLODE(FROM_JSON(t2.suppliers, 'ARRAY<BIGINT>')) s AS sup_id
        WHERE t2.scenic_id IN('PFTSCA01018088', 'PFTSCA01016184', 'PFTSCA01018066', 'PFTSCM00000001', 'PFTSCZ01022547')
    ) sup ON t.sup_id = sup.sup_id
    JOIN (
        SELECT 
            ${bizdate} AS d_cur,
            INT(DATE_FORMAT(TO_DATE(CAST(${bizdate} AS STRING), 'yyyyMMdd') - 1,   'yyyyMMdd')) AS d_1,    -- D-1
            INT(DATE_FORMAT(TO_DATE(CAST(${bizdate} AS STRING), 'yyyyMMdd') - 6,   'yyyyMMdd')) AS d_7,    -- D-6
            INT(DATE_FORMAT(TO_DATE(CAST(${bizdate} AS STRING), 'yyyyMMdd') - 13,  'yyyyMMdd')) AS d_14,   -- D-13
            INT(DATE_FORMAT(TO_DATE(CAST(${bizdate} AS STRING), 'yyyyMMdd') - 29,  'yyyyMMdd')) AS d_30,   -- D-29
            INT(DATE_FORMAT(TO_DATE(CAST(${bizdate} AS STRING), 'yyyyMMdd') - 59,  'yyyyMMdd')) AS d_60,   -- D-59
            INT(DATE_FORMAT(TO_DATE(CAST(${bizdate} AS STRING), 'yyyyMMdd') - 89,  'yyyyMMdd')) AS d_90,   -- D-89
            INT(DATE_FORMAT(TO_DATE(CAST(${bizdate} AS STRING), 'yyyyMMdd') - 179, 'yyyyMMdd')) AS d_180,  -- D-179
            INT(DATE_FORMAT(TO_DATE(CAST(${bizdate} AS STRING), 'yyyyMMdd') - 359, 'yyyyMMdd')) AS d_360,  -- D-359
            INT(DATE_FORMAT(NEXT_DAY(TO_DATE(CAST(${bizdate} AS STRING), 'yyyyMMdd'), 'MON') - 7, 'yyyyMMdd')) AS d_week,  -- 本周一
            INT(DATE_FORMAT(TRUNC(TO_DATE(CAST(${bizdate} AS STRING), 'yyyyMMdd'), 'MM'), 'yyyyMMdd')) AS d_month           -- 本月1号
    ) p ON 1 = 1
    WHERE t.travel_date >= p.d_360
      AND t.travel_date <= p.d_cur
    GROUP BY sup.scenic_id, t.sales_channel_id 
) agg
JOIN dim_prd_scenic_supplier_relation_f dim_scenic
    ON agg.scenic_id = dim_scenic.scenic_id
LATERAL VIEW stack(12,
    '单渠道营收金额(元)',      '1d',   CAST(net_sales_income_amt_1d   AS DECIMAL(10,2)),
    '单渠道营收金额(元)',      '7d',   CAST(net_sales_income_amt_7d   AS DECIMAL(10,2)),
    '单渠道营收金额(元)',      '30d',  CAST(net_sales_income_amt_30d  AS DECIMAL(10,2)),
    '单渠道营收金额(元)',      '90d',  CAST(net_sales_income_amt_90d  AS DECIMAL(10,2)),
    '单渠道营收金额(元)',      '180d', CAST(net_sales_income_amt_180d AS DECIMAL(10,2)),
    '单渠道营收金额(元)',      'week',  CAST(net_sales_income_amt_week  AS DECIMAL(10,2)),
    '单渠道营收金额(元)',      'month', CAST(net_sales_income_amt_month  AS DECIMAL(10,2)),

    '单渠道营收金额环比(%)',   '1d',   CAST(IFNULL((net_sales_income_amt_1d   - net_sales_income_amt_prev_1d)  / NULLIF(net_sales_income_amt_prev_1d,0)   * 100, 0) AS DECIMAL(10,2)),
    '单渠道营收金额环比(%)',   '7d',   CAST(IFNULL((net_sales_income_amt_7d   - net_sales_income_amt_prev_7d)  / NULLIF(net_sales_income_amt_prev_7d,0)   * 100, 0) AS DECIMAL(10,2)),
    '单渠道营收金额环比(%)',   '30d',  CAST(IFNULL((net_sales_income_amt_30d  - net_sales_income_amt_prev_30d) / NULLIF(net_sales_income_amt_prev_30d,0)  * 100, 0) AS DECIMAL(10,2)),
    '单渠道营收金额环比(%)',   '90d',  CAST(IFNULL((net_sales_income_amt_90d  - net_sales_income_amt_prev_90d) / NULLIF(net_sales_income_amt_prev_90d,0)  * 100, 0) AS DECIMAL(10,2)),
    '单渠道营收金额环比(%)',   '180d', CAST(IFNULL((net_sales_income_amt_180d - net_sales_income_amt_prev_180d)/ NULLIF(net_sales_income_amt_prev_180d,0) * 100, 0) AS DECIMAL(10,2))
) ind AS target_desc, date_type, data_value

UNION ALL 

SELECT 
    MD5(CONCAT_WS('|', ${bizdate}, '票务-总览', agg.scenic_id, date_type, target_desc)) AS key_id,
    agg.scenic_id                AS scenic_id,
    dim_scenic.scenic_name        AS scenic_name,
    '票务-总览'                  AS indicator_domain,
    target_name                 AS target_name,
    target_desc                 AS target_desc,
    date_type                   AS date_type,
    data_value                  AS data_value,
    '票务'                      AS data_domain,
    ${bizdate}                  AS travel_date
FROM (
    SELECT 
        sup.scenic_id AS scenic_id,

        SUM(IF(t.travel_date =  p.d_cur, t.net_sales_income_amt, 0))                       AS net_sales_income_amt_1d,
        SUM(IF(t.travel_date >= p.d_7   AND t.travel_date <= p.d_cur, t.net_sales_income_amt, 0)) AS net_sales_income_amt_7d,
        SUM(IF(t.travel_date >= p.d_30  AND t.travel_date <= p.d_cur, t.net_sales_income_amt, 0)) AS net_sales_income_amt_30d,
        SUM(IF(t.travel_date >= p.d_90  AND t.travel_date <= p.d_cur, t.net_sales_income_amt, 0)) AS net_sales_income_amt_90d,
        SUM(IF(t.travel_date >= p.d_180 AND t.travel_date <= p.d_cur, t.net_sales_income_amt, 0)) AS net_sales_income_amt_180d,
        SUM(IF(t.travel_date >= p.d_week   AND t.travel_date <= p.d_cur, t.net_sales_income_amt, 0)) AS net_sales_income_amt_week,
        SUM(IF(t.travel_date >= p.d_month   AND t.travel_date <= p.d_cur, t.net_sales_income_amt, 0)) AS net_sales_income_amt_month,

        SUM(IF(t.travel_date =  p.d_1,     t.net_sales_income_amt, 0))                       AS net_sales_income_amt_prev_1d,
        SUM(IF(t.travel_date >= p.d_14 AND t.travel_date < p.d_7,   t.net_sales_income_amt, 0)) AS net_sales_income_amt_prev_7d,
        SUM(IF(t.travel_date >= p.d_60 AND t.travel_date < p.d_30,  t.net_sales_income_amt, 0)) AS net_sales_income_amt_prev_30d,
        SUM(IF(t.travel_date >= p.d_180 AND t.travel_date < p.d_90, t.net_sales_income_amt, 0)) AS net_sales_income_amt_prev_90d,
        SUM(IF(t.travel_date >= p.d_360 AND t.travel_date < p.d_180,t.net_sales_income_amt, 0)) AS net_sales_income_amt_prev_180d,


        SUM(IF(t.travel_date =  p.d_cur, t.net_sales_ticket_qty, 0))                        AS net_sales_ticket_qty_1d,
        SUM(IF(t.travel_date >= p.d_7   AND t.travel_date <= p.d_cur, t.net_sales_ticket_qty, 0)) AS net_sales_ticket_qty_7d,
        SUM(IF(t.travel_date >= p.d_30  AND t.travel_date <= p.d_cur, t.net_sales_ticket_qty, 0)) AS net_sales_ticket_qty_30d,
        SUM(IF(t.travel_date >= p.d_90  AND t.travel_date <= p.d_cur, t.net_sales_ticket_qty, 0)) AS net_sales_ticket_qty_90d,
        SUM(IF(t.travel_date >= p.d_180 AND t.travel_date <= p.d_cur, t.net_sales_ticket_qty, 0)) AS net_sales_ticket_qty_180d,
        SUM(IF(t.travel_date >= p.d_week   AND t.travel_date <= p.d_cur, t.net_sales_ticket_qty, 0)) AS net_sales_ticket_qty_week,
        SUM(IF(t.travel_date >= p.d_month   AND t.travel_date <= p.d_cur, t.net_sales_ticket_qty, 0)) AS net_sales_ticket_qty_month,

        SUM(IF(t.travel_date =  p.d_1,     t.net_sales_ticket_qty, 0))                        AS net_sales_ticket_qty_prev_1d,
        SUM(IF(t.travel_date >= p.d_14 AND t.travel_date < p.d_7,   t.net_sales_ticket_qty, 0)) AS net_sales_ticket_qty_prev_7d,
        SUM(IF(t.travel_date >= p.d_60 AND t.travel_date < p.d_30,  t.net_sales_ticket_qty, 0)) AS net_sales_ticket_qty_prev_30d,
        SUM(IF(t.travel_date >= p.d_180 AND t.travel_date < p.d_90, t.net_sales_ticket_qty, 0)) AS net_sales_ticket_qty_prev_90d,
        SUM(IF(t.travel_date >= p.d_360 AND t.travel_date < p.d_180,t.net_sales_ticket_qty, 0)) AS net_sales_ticket_qty_prev_180d,


        SUM(IF(t.travel_date =  p.d_cur, t.verify_income_amt, 0))                           AS verify_income_amt_1d,
        SUM(IF(t.travel_date >= p.d_7   AND t.travel_date <= p.d_cur, t.verify_income_amt, 0)) AS verify_income_amt_7d,
        SUM(IF(t.travel_date >= p.d_30  AND t.travel_date <= p.d_cur, t.verify_income_amt, 0)) AS verify_income_amt_30d,
        SUM(IF(t.travel_date >= p.d_90  AND t.travel_date <= p.d_cur, t.verify_income_amt, 0)) AS verify_income_amt_90d,
        SUM(IF(t.travel_date >= p.d_180 AND t.travel_date <= p.d_cur, t.verify_income_amt, 0)) AS verify_income_amt_180d,
        SUM(IF(t.travel_date >= p.d_week   AND t.travel_date <= p.d_cur, t.verify_income_amt, 0)) AS verify_income_amt_week,
        SUM(IF(t.travel_date >= p.d_month   AND t.travel_date <= p.d_cur, t.verify_income_amt, 0)) AS verify_income_amt_month,

        SUM(IF(t.travel_date =  p.d_1,     t.verify_income_amt, 0))                           AS verify_income_amt_prev_1d,
        SUM(IF(t.travel_date >= p.d_14 AND t.travel_date < p.d_7,   t.verify_income_amt, 0)) AS verify_income_amt_prev_7d,
        SUM(IF(t.travel_date >= p.d_60 AND t.travel_date < p.d_30,  t.verify_income_amt, 0)) AS verify_income_amt_prev_30d,
        SUM(IF(t.travel_date >= p.d_180 AND t.travel_date < p.d_90, t.verify_income_amt, 0)) AS verify_income_amt_prev_90d,
        SUM(IF(t.travel_date >= p.d_360 AND t.travel_date < p.d_180,t.verify_income_amt, 0)) AS verify_income_amt_prev_180d,


        SUM(IF(t.travel_date =  p.d_cur, t.verify_ticket_qty, 0))                           AS verify_ticket_qty_1d,
        SUM(IF(t.travel_date >= p.d_7   AND t.travel_date <= p.d_cur, t.verify_ticket_qty, 0)) AS verify_ticket_qty_7d,
        SUM(IF(t.travel_date >= p.d_30  AND t.travel_date <= p.d_cur, t.verify_ticket_qty, 0)) AS verify_ticket_qty_30d,
        SUM(IF(t.travel_date >= p.d_90  AND t.travel_date <= p.d_cur, t.verify_ticket_qty, 0)) AS verify_ticket_qty_90d,
        SUM(IF(t.travel_date >= p.d_180 AND t.travel_date <= p.d_cur, t.verify_ticket_qty, 0)) AS verify_ticket_qty_180d,
        SUM(IF(t.travel_date >= p.d_week   AND t.travel_date <= p.d_cur, t.verify_ticket_qty, 0)) AS verify_ticket_qty_week,
        SUM(IF(t.travel_date >= p.d_month   AND t.travel_date <= p.d_cur, t.verify_ticket_qty, 0)) AS verify_ticket_qty_month,

        SUM(IF(t.travel_date =  p.d_1,     t.verify_ticket_qty, 0))                           AS verify_ticket_qty_prev_1d,
        SUM(IF(t.travel_date >= p.d_14 AND t.travel_date < p.d_7,   t.verify_ticket_qty, 0)) AS verify_ticket_qty_prev_7d,
        SUM(IF(t.travel_date >= p.d_60 AND t.travel_date < p.d_30,  t.verify_ticket_qty, 0)) AS verify_ticket_qty_prev_30d,
        SUM(IF(t.travel_date >= p.d_180 AND t.travel_date < p.d_90, t.verify_ticket_qty, 0)) AS verify_ticket_qty_prev_90d,
        SUM(IF(t.travel_date >= p.d_360 AND t.travel_date < p.d_180,t.verify_ticket_qty, 0)) AS verify_ticket_qty_prev_180d,


        SUM(IF(t.travel_date =  p.d_cur, t.sales_income_amt, 0))                           AS sales_income_amt_1d,
        SUM(IF(t.travel_date >= p.d_7   AND t.travel_date <= p.d_cur, t.sales_income_amt, 0)) AS sales_income_amt_7d,
        SUM(IF(t.travel_date >= p.d_30  AND t.travel_date <= p.d_cur, t.sales_income_amt, 0)) AS sales_income_amt_30d,
        SUM(IF(t.travel_date >= p.d_90  AND t.travel_date <= p.d_cur, t.sales_income_amt, 0)) AS sales_income_amt_90d,
        SUM(IF(t.travel_date >= p.d_180 AND t.travel_date <= p.d_cur, t.sales_income_amt, 0)) AS sales_income_amt_180d,
        SUM(IF(t.travel_date >= p.d_week   AND t.travel_date <= p.d_cur, t.sales_income_amt, 0)) AS sales_income_amt_week,
        SUM(IF(t.travel_date >= p.d_month   AND t.travel_date <= p.d_cur, t.sales_income_amt, 0)) AS sales_income_amt_month,

        SUM(IF(t.travel_date =  p.d_1,     t.sales_income_amt, 0))                           AS sales_income_amt_prev_1d,
        SUM(IF(t.travel_date >= p.d_14 AND t.travel_date < p.d_7,   t.sales_income_amt, 0)) AS sales_income_amt_prev_7d,
        SUM(IF(t.travel_date >= p.d_60 AND t.travel_date < p.d_30,  t.sales_income_amt, 0)) AS sales_income_amt_prev_30d,
        SUM(IF(t.travel_date >= p.d_180 AND t.travel_date < p.d_90, t.sales_income_amt, 0)) AS sales_income_amt_prev_90d,
        SUM(IF(t.travel_date >= p.d_360 AND t.travel_date < p.d_180,t.sales_income_amt, 0)) AS sales_income_amt_prev_180d,


        SUM(IF(t.travel_date =  p.d_cur, t.sales_ticket_qty, 0))                           AS sales_ticket_qty_1d,
        SUM(IF(t.travel_date >= p.d_7   AND t.travel_date <= p.d_cur, t.sales_ticket_qty, 0)) AS sales_ticket_qty_7d,
        SUM(IF(t.travel_date >= p.d_30  AND t.travel_date <= p.d_cur, t.sales_ticket_qty, 0)) AS sales_ticket_qty_30d,
        SUM(IF(t.travel_date >= p.d_90  AND t.travel_date <= p.d_cur, t.sales_ticket_qty, 0)) AS sales_ticket_qty_90d,
        SUM(IF(t.travel_date >= p.d_180 AND t.travel_date <= p.d_cur, t.sales_ticket_qty, 0)) AS sales_ticket_qty_180d,
        SUM(IF(t.travel_date >= p.d_week   AND t.travel_date <= p.d_cur, t.sales_ticket_qty, 0)) AS sales_ticket_qty_week,
        SUM(IF(t.travel_date >= p.d_month   AND t.travel_date <= p.d_cur, t.sales_ticket_qty, 0)) AS sales_ticket_qty_month,

        SUM(IF(t.travel_date =  p.d_1,     t.sales_ticket_qty, 0))                           AS sales_ticket_qty_prev_1d,
        SUM(IF(t.travel_date >= p.d_14 AND t.travel_date < p.d_7,   t.sales_ticket_qty, 0)) AS sales_ticket_qty_prev_7d,
        SUM(IF(t.travel_date >= p.d_60 AND t.travel_date < p.d_30,  t.sales_ticket_qty, 0)) AS sales_ticket_qty_prev_30d,
        SUM(IF(t.travel_date >= p.d_180 AND t.travel_date < p.d_90, t.sales_ticket_qty, 0)) AS sales_ticket_qty_prev_90d,
        SUM(IF(t.travel_date >= p.d_360 AND t.travel_date < p.d_180,t.sales_ticket_qty, 0)) AS sales_ticket_qty_prev_180d,

        IFNULL(SUM(IF(t.travel_date =  p.d_cur, t.cancel_ticket_qty + t.revoke_ticket_qty + t.after_sale_ticket_qty, 0))
             / NULLIF(SUM(IF(t.travel_date =  p.d_cur, t.sales_ticket_qty, 0)), 0), 0)       AS refund_ticket_rate_1d,
        IFNULL(SUM(IF(t.travel_date >= p.d_7   AND t.travel_date <= p.d_cur, t.cancel_ticket_qty + t.revoke_ticket_qty + t.after_sale_ticket_qty, 0))
             / NULLIF(SUM(IF(t.travel_date >= p.d_7   AND t.travel_date <= p.d_cur, t.sales_ticket_qty, 0)), 0), 0) AS refund_ticket_rate_7d,
        IFNULL(SUM(IF(t.travel_date >= p.d_30  AND t.travel_date <= p.d_cur, t.cancel_ticket_qty + t.revoke_ticket_qty + t.after_sale_ticket_qty, 0))
             / NULLIF(SUM(IF(t.travel_date >= p.d_30  AND t.travel_date <= p.d_cur, t.sales_ticket_qty, 0)), 0), 0) AS refund_ticket_rate_30d,
        IFNULL(SUM(IF(t.travel_date >= p.d_90  AND t.travel_date <= p.d_cur, t.cancel_ticket_qty + t.revoke_ticket_qty + t.after_sale_ticket_qty, 0))
             / NULLIF(SUM(IF(t.travel_date >= p.d_90  AND t.travel_date <= p.d_cur, t.sales_ticket_qty, 0)), 0), 0) AS refund_ticket_rate_90d,
        IFNULL(SUM(IF(t.travel_date >= p.d_180 AND t.travel_date <= p.d_cur, t.cancel_ticket_qty + t.revoke_ticket_qty + t.after_sale_ticket_qty, 0))
             / NULLIF(SUM(IF(t.travel_date >= p.d_180 AND t.travel_date <= p.d_cur, t.sales_ticket_qty, 0)), 0), 0) AS refund_ticket_rate_180d,
        IFNULL(SUM(IF(t.travel_date >= p.d_week   AND t.travel_date <= p.d_cur, t.cancel_ticket_qty + t.revoke_ticket_qty + t.after_sale_ticket_qty, 0))
             / NULLIF(SUM(IF(t.travel_date >= p.d_week   AND t.travel_date <= p.d_cur, t.sales_ticket_qty, 0)), 0), 0) AS refund_ticket_rate_week,
        IFNULL(SUM(IF(t.travel_date >= p.d_month   AND t.travel_date <= p.d_cur, t.cancel_ticket_qty + t.revoke_ticket_qty + t.after_sale_ticket_qty, 0))
             / NULLIF(SUM(IF(t.travel_date >= p.d_month   AND t.travel_date <= p.d_cur, t.sales_ticket_qty, 0)), 0), 0) AS refund_ticket_rate_month,

        IFNULL(SUM(IF(t.travel_date =  p.d_1, t.cancel_ticket_qty + t.revoke_ticket_qty + t.after_sale_ticket_qty, 0))
             / NULLIF(SUM(IF(t.travel_date =  p.d_1, t.sales_ticket_qty, 0)), 0), 0)         AS refund_ticket_rate_prev_1d,
        IFNULL(SUM(IF(t.travel_date >= p.d_14 AND t.travel_date < p.d_7, t.cancel_ticket_qty + t.revoke_ticket_qty + t.after_sale_ticket_qty, 0))
             / NULLIF(SUM(IF(t.travel_date >= p.d_14 AND t.travel_date < p.d_7, t.sales_ticket_qty, 0)), 0), 0) AS refund_ticket_rate_prev_7d,
        IFNULL(SUM(IF(t.travel_date >= p.d_60 AND t.travel_date < p.d_30, t.cancel_ticket_qty + t.revoke_ticket_qty + t.after_sale_ticket_qty, 0))
             / NULLIF(SUM(IF(t.travel_date >= p.d_60 AND t.travel_date < p.d_30, t.sales_ticket_qty, 0)), 0), 0) AS refund_ticket_rate_prev_30d,
        IFNULL(SUM(IF(t.travel_date >= p.d_180 AND t.travel_date < p.d_90, t.cancel_ticket_qty + t.revoke_ticket_qty + t.after_sale_ticket_qty, 0))
             / NULLIF(SUM(IF(t.travel_date >= p.d_180 AND t.travel_date < p.d_90, t.sales_ticket_qty, 0)), 0), 0) AS refund_ticket_rate_prev_90d,
        IFNULL(SUM(IF(t.travel_date >= p.d_360 AND t.travel_date < p.d_180,t.cancel_ticket_qty + t.revoke_ticket_qty + t.after_sale_ticket_qty, 0))
             / NULLIF(SUM(IF(t.travel_date >= p.d_360 AND t.travel_date < p.d_180,t.sales_ticket_qty, 0)), 0), 0) AS refund_ticket_rate_prev_180d

    FROM dws_mps_sup_report_summary_di t
    JOIN (
        SELECT t2.scenic_id, s.sup_id
        FROM dim_prd_scenic_supplier_relation_f t2
        LATERAL VIEW EXPLODE(FROM_JSON(t2.suppliers, 'ARRAY<BIGINT>')) s AS sup_id
        WHERE t2.scenic_id IN('PFTSCA01018088', 'PFTSCA01016184', 'PFTSCA01018066', 'PFTSCM00000001', 'PFTSCZ01022547')
    ) sup ON t.sup_id = sup.sup_id
    JOIN (
        SELECT 
            ${bizdate} AS d_cur,
            INT(DATE_FORMAT(TO_DATE(CAST(${bizdate} AS STRING), 'yyyyMMdd') - 1,   'yyyyMMdd')) AS d_1,
            INT(DATE_FORMAT(TO_DATE(CAST(${bizdate} AS STRING), 'yyyyMMdd') - 6,   'yyyyMMdd')) AS d_7,
            INT(DATE_FORMAT(TO_DATE(CAST(${bizdate} AS STRING), 'yyyyMMdd') - 13,  'yyyyMMdd')) AS d_14,
            INT(DATE_FORMAT(TO_DATE(CAST(${bizdate} AS STRING), 'yyyyMMdd') - 29,  'yyyyMMdd')) AS d_30,
            INT(DATE_FORMAT(TO_DATE(CAST(${bizdate} AS STRING), 'yyyyMMdd') - 59,  'yyyyMMdd')) AS d_60,
            INT(DATE_FORMAT(TO_DATE(CAST(${bizdate} AS STRING), 'yyyyMMdd') - 89,  'yyyyMMdd')) AS d_90,
            INT(DATE_FORMAT(TO_DATE(CAST(${bizdate} AS STRING), 'yyyyMMdd') - 179, 'yyyyMMdd')) AS d_180,
            INT(DATE_FORMAT(TO_DATE(CAST(${bizdate} AS STRING), 'yyyyMMdd') - 359, 'yyyyMMdd')) AS d_360,
            INT(DATE_FORMAT(NEXT_DAY(TO_DATE(CAST(${bizdate} AS STRING), 'yyyyMMdd'), 'MON') - 7, 'yyyyMMdd')) AS d_week,
            INT(DATE_FORMAT(TRUNC(TO_DATE(CAST(${bizdate} AS STRING), 'yyyyMMdd'), 'MM'), 'yyyyMMdd')) AS d_month
    ) p ON 1 = 1
    WHERE t.travel_date >= p.d_360
      AND t.travel_date <= p.d_cur 
    GROUP BY sup.scenic_id 
) agg
JOIN dim_prd_scenic_supplier_relation_f dim_scenic
    ON agg.scenic_id = dim_scenic.scenic_id
LATERAL VIEW stack(84,

    '票务收入', '票务收入(元)',  '1d',   CAST(net_sales_income_amt_1d   AS DECIMAL(10,2)),
    '票务收入', '票务收入(元)',  '7d',   CAST(net_sales_income_amt_7d   AS DECIMAL(10,2)),
    '票务收入', '票务收入(元)',  '30d',  CAST(net_sales_income_amt_30d  AS DECIMAL(10,2)),
    '票务收入', '票务收入(元)',  '90d',  CAST(net_sales_income_amt_90d  AS DECIMAL(10,2)),
    '票务收入', '票务收入(元)',  '180d', CAST(net_sales_income_amt_180d AS DECIMAL(10,2)),
    '票务收入', '票务收入(元)',  'week',  CAST(net_sales_income_amt_week  AS DECIMAL(10,2)),
    '票务收入', '票务收入(元)',  'month', CAST(net_sales_income_amt_month  AS DECIMAL(10,2)),

    '出票量', '出票量(张)',  '1d',   CAST(net_sales_ticket_qty_1d   AS DECIMAL(10,2)),
    '出票量', '出票量(张)',  '7d',   CAST(net_sales_ticket_qty_7d   AS DECIMAL(10,2)),
    '出票量', '出票量(张)',  '30d',  CAST(net_sales_ticket_qty_30d  AS DECIMAL(10,2)),
    '出票量', '出票量(张)',  '90d',  CAST(net_sales_ticket_qty_90d  AS DECIMAL(10,2)),
    '出票量', '出票量(张)',  '180d', CAST(net_sales_ticket_qty_180d AS DECIMAL(10,2)),
    '出票量', '出票量(张)',  'week',  CAST(net_sales_ticket_qty_week  AS DECIMAL(10,2)),
    '出票量', '出票量(张)',  'month', CAST(net_sales_ticket_qty_month  AS DECIMAL(10,2)),

    '核销金额', '核销金额(元)',  '1d',   CAST(verify_income_amt_1d   AS DECIMAL(10,2)),
    '核销金额', '核销金额(元)',  '7d',   CAST(verify_income_amt_7d   AS DECIMAL(10,2)),
    '核销金额', '核销金额(元)',  '30d',  CAST(verify_income_amt_30d  AS DECIMAL(10,2)),
    '核销金额', '核销金额(元)',  '90d',  CAST(verify_income_amt_90d  AS DECIMAL(10,2)),
    '核销金额', '核销金额(元)',  '180d', CAST(verify_income_amt_180d AS DECIMAL(10,2)),
    '核销金额', '核销金额(元)',  'week',  CAST(verify_income_amt_week  AS DECIMAL(10,2)),
    '核销金额', '核销金额(元)',  'month', CAST(verify_income_amt_month  AS DECIMAL(10,2)),

    '核销票数', '核销票数(张)',  '1d',   CAST(verify_ticket_qty_1d   AS DECIMAL(10,2)),
    '核销票数', '核销票数(张)',  '7d',   CAST(verify_ticket_qty_7d   AS DECIMAL(10,2)),
    '核销票数', '核销票数(张)',  '30d',  CAST(verify_ticket_qty_30d  AS DECIMAL(10,2)),
    '核销票数', '核销票数(张)',  '90d',  CAST(verify_ticket_qty_90d  AS DECIMAL(10,2)),
    '核销票数', '核销票数(张)',  '180d', CAST(verify_ticket_qty_180d AS DECIMAL(10,2)),
    '核销票数', '核销票数(张)',  'week',  CAST(verify_ticket_qty_week  AS DECIMAL(10,2)),
    '核销票数', '核销票数(张)',  'month', CAST(verify_ticket_qty_month  AS DECIMAL(10,2)),

    '退票率', '退票率(%)',  '1d',   CAST(refund_ticket_rate_1d   * 100 AS DECIMAL(10,2)),
    '退票率', '退票率(%)',  '7d',   CAST(refund_ticket_rate_7d   * 100 AS DECIMAL(10,2)),
    '退票率', '退票率(%)',  '30d',  CAST(refund_ticket_rate_30d  * 100 AS DECIMAL(10,2)),
    '退票率', '退票率(%)',  '90d',  CAST(refund_ticket_rate_90d  * 100 AS DECIMAL(10,2)),
    '退票率', '退票率(%)',  '180d', CAST(refund_ticket_rate_180d * 100 AS DECIMAL(10,2)),
    '退票率', '退票率(%)',  'week',  CAST(refund_ticket_rate_week  * 100 AS DECIMAL(10,2)),
    '退票率', '退票率(%)',  'month', CAST(refund_ticket_rate_month  * 100 AS DECIMAL(10,2)),

    '预定金额', '预定金额(元)',  '1d',   CAST(sales_income_amt_1d   AS DECIMAL(10,2)),
    '预定金额', '预定金额(元)',  '7d',   CAST(sales_income_amt_7d   AS DECIMAL(10,2)),
    '预定金额', '预定金额(元)',  '30d',  CAST(sales_income_amt_30d  AS DECIMAL(10,2)),
    '预定金额', '预定金额(元)',  '90d',  CAST(sales_income_amt_90d  AS DECIMAL(10,2)),
    '预定金额', '预定金额(元)',  '180d', CAST(sales_income_amt_180d AS DECIMAL(10,2)),
    '预定金额', '预定金额(元)',  'week',  CAST(sales_income_amt_week  AS DECIMAL(10,2)),
    '预定金额', '预定金额(元)',  'month', CAST(sales_income_amt_month  AS DECIMAL(10,2)),

    '预定票数', '预定票数(张)',  '1d',   CAST(sales_ticket_qty_1d   AS DECIMAL(10,2)),
    '预定票数', '预定票数(张)',  '7d',   CAST(sales_ticket_qty_7d   AS DECIMAL(10,2)),
    '预定票数', '预定票数(张)',  '30d',  CAST(sales_ticket_qty_30d  AS DECIMAL(10,2)),
    '预定票数', '预定票数(张)',  '90d',  CAST(sales_ticket_qty_90d  AS DECIMAL(10,2)),
    '预定票数', '预定票数(张)',  '180d', CAST(sales_ticket_qty_180d AS DECIMAL(10,2)),
    '预定票数', '预定票数(张)',  'week',  CAST(sales_ticket_qty_week  AS DECIMAL(10,2)),
    '预定票数', '预定票数(张)',  'month', CAST(sales_ticket_qty_month  AS DECIMAL(10,2)),

    '预定金额环比', '预定金额环比(%)',  '1d',   CAST(IFNULL((sales_income_amt_1d   - sales_income_amt_prev_1d)  / NULLIF(sales_income_amt_prev_1d,0)   * 100, 0) AS DECIMAL(10,2)),
    '预定金额环比', '预定金额环比(%)',  '7d',   CAST(IFNULL((sales_income_amt_7d   - sales_income_amt_prev_7d)  / NULLIF(sales_income_amt_prev_7d,0)   * 100, 0) AS DECIMAL(10,2)),
    '预定金额环比', '预定金额环比(%)',  '30d',  CAST(IFNULL((sales_income_amt_30d  - sales_income_amt_prev_30d) / NULLIF(sales_income_amt_prev_30d,0)  * 100, 0) AS DECIMAL(10,2)),
    '预定金额环比', '预定金额环比(%)',  '90d',  CAST(IFNULL((sales_income_amt_90d  - sales_income_amt_prev_90d) / NULLIF(sales_income_amt_prev_90d,0)  * 100, 0) AS DECIMAL(10,2)),
    '预定金额环比', '预定金额环比(%)',  '180d', CAST(IFNULL((sales_income_amt_180d - sales_income_amt_prev_180d)/ NULLIF(sales_income_amt_prev_180d,0) * 100, 0) AS DECIMAL(10,2)),

    '预定票数环比', '预定票数环比(%)',  '1d',   CAST(IFNULL((sales_ticket_qty_1d   - sales_ticket_qty_prev_1d)  / NULLIF(sales_ticket_qty_prev_1d,0)   * 100, 0) AS DECIMAL(10,2)),
    '预定票数环比', '预定票数环比(%)',  '7d',   CAST(IFNULL((sales_ticket_qty_7d   - sales_ticket_qty_prev_7d)  / NULLIF(sales_ticket_qty_prev_7d,0)   * 100, 0) AS DECIMAL(10,2)),
    '预定票数环比', '预定票数环比(%)',  '30d',  CAST(IFNULL((sales_ticket_qty_30d  - sales_ticket_qty_prev_30d) / NULLIF(sales_ticket_qty_prev_30d,0)  * 100, 0) AS DECIMAL(10,2)),
    '预定票数环比', '预定票数环比(%)',  '90d',  CAST(IFNULL((sales_ticket_qty_90d  - sales_ticket_qty_prev_90d) / NULLIF(sales_ticket_qty_prev_90d,0)  * 100, 0) AS DECIMAL(10,2)),
    '预定票数环比', '预定票数环比(%)',  '180d', CAST(IFNULL((sales_ticket_qty_180d - sales_ticket_qty_prev_180d)/ NULLIF(sales_ticket_qty_prev_180d,0) * 100, 0) AS DECIMAL(10,2)),

    '票务收入环比', '票务收入环比(%)',  '1d',   CAST(IFNULL((net_sales_income_amt_1d   - net_sales_income_amt_prev_1d)  / NULLIF(net_sales_income_amt_prev_1d,0)   * 100, 0) AS DECIMAL(10,2)),
    '票务收入环比', '票务收入环比(%)',  '7d',   CAST(IFNULL((net_sales_income_amt_7d   - net_sales_income_amt_prev_7d)  / NULLIF(net_sales_income_amt_prev_7d,0)   * 100, 0) AS DECIMAL(10,2)),
    '票务收入环比', '票务收入环比(%)',  '30d',  CAST(IFNULL((net_sales_income_amt_30d  - net_sales_income_amt_prev_30d) / NULLIF(net_sales_income_amt_prev_30d,0)  * 100, 0) AS DECIMAL(10,2)),
    '票务收入环比', '票务收入环比(%)',  '90d',  CAST(IFNULL((net_sales_income_amt_90d  - net_sales_income_amt_prev_90d) / NULLIF(net_sales_income_amt_prev_90d,0)  * 100, 0) AS DECIMAL(10,2)),
    '票务收入环比', '票务收入环比(%)',  '180d', CAST(IFNULL((net_sales_income_amt_180d - net_sales_income_amt_prev_180d)/ NULLIF(net_sales_income_amt_prev_180d,0) * 100, 0) AS DECIMAL(10,2)),

    '出票量环比', '出票量环比(%)',  '1d',   CAST(IFNULL((net_sales_ticket_qty_1d   - net_sales_ticket_qty_prev_1d)  / NULLIF(net_sales_ticket_qty_prev_1d,0)   * 100, 0) AS DECIMAL(10,2)),
    '出票量环比', '出票量环比(%)',  '7d',   CAST(IFNULL((net_sales_ticket_qty_7d   - net_sales_ticket_qty_prev_7d)  / NULLIF(net_sales_ticket_qty_prev_7d,0)   * 100, 0) AS DECIMAL(10,2)),
    '出票量环比', '出票量环比(%)',  '30d',  CAST(IFNULL((net_sales_ticket_qty_30d  - net_sales_ticket_qty_prev_30d) / NULLIF(net_sales_ticket_qty_prev_30d,0)  * 100, 0) AS DECIMAL(10,2)),
    '出票量环比', '出票量环比(%)',  '90d',  CAST(IFNULL((net_sales_ticket_qty_90d  - net_sales_ticket_qty_prev_90d) / NULLIF(net_sales_ticket_qty_prev_90d,0)  * 100, 0) AS DECIMAL(10,2)),
    '出票量环比', '出票量环比(%)',  '180d', CAST(IFNULL((net_sales_ticket_qty_180d - net_sales_ticket_qty_prev_180d)/ NULLIF(net_sales_ticket_qty_prev_180d,0) * 100, 0) AS DECIMAL(10,2)),

    '核销金额环比', '核销金额环比(%)',  '1d',   CAST(IFNULL((verify_income_amt_1d   - verify_income_amt_prev_1d)  / NULLIF(verify_income_amt_prev_1d,0)   * 100, 0) AS DECIMAL(10,2)),
    '核销金额环比', '核销金额环比(%)',  '7d',   CAST(IFNULL((verify_income_amt_7d   - verify_income_amt_prev_7d)  / NULLIF(verify_income_amt_prev_7d,0)   * 100, 0) AS DECIMAL(10,2)),
    '核销金额环比', '核销金额环比(%)',  '30d',  CAST(IFNULL((verify_income_amt_30d  - verify_income_amt_prev_30d) / NULLIF(verify_income_amt_prev_30d,0)  * 100, 0) AS DECIMAL(10,2)),
    '核销金额环比', '核销金额环比(%)',  '90d',  CAST(IFNULL((verify_income_amt_90d  - verify_income_amt_prev_90d) / NULLIF(verify_income_amt_prev_90d,0)  * 100, 0) AS DECIMAL(10,2)),
    '核销金额环比', '核销金额环比(%)',  '180d', CAST(IFNULL((verify_income_amt_180d - verify_income_amt_prev_180d)/ NULLIF(verify_income_amt_prev_180d,0) * 100, 0) AS DECIMAL(10,2)),

    '核销票数环比', '核销票数环比(%)',  '1d',   CAST(IFNULL((verify_ticket_qty_1d   - verify_ticket_qty_prev_1d)  / NULLIF(verify_ticket_qty_prev_1d,0)   * 100, 0) AS DECIMAL(10,2)),
    '核销票数环比', '核销票数环比(%)',  '7d',   CAST(IFNULL((verify_ticket_qty_7d   - verify_ticket_qty_prev_7d)  / NULLIF(verify_ticket_qty_prev_7d,0)   * 100, 0) AS DECIMAL(10,2)),
    '核销票数环比', '核销票数环比(%)',  '30d',  CAST(IFNULL((verify_ticket_qty_30d  - verify_ticket_qty_prev_30d) / NULLIF(verify_ticket_qty_prev_30d,0)  * 100, 0) AS DECIMAL(10,2)),
    '核销票数环比', '核销票数环比(%)',  '90d',  CAST(IFNULL((verify_ticket_qty_90d  - verify_ticket_qty_prev_90d) / NULLIF(verify_ticket_qty_prev_90d,0)  * 100, 0) AS DECIMAL(10,2)),
    '核销票数环比', '核销票数环比(%)',  '180d', CAST(IFNULL((verify_ticket_qty_180d - verify_ticket_qty_prev_180d)/ NULLIF(verify_ticket_qty_prev_180d,0) * 100, 0) AS DECIMAL(10,2)),

    '退票率环比', '退票率环比(百分点)',  '1d',   CAST((refund_ticket_rate_1d   - refund_ticket_rate_prev_1d)   * 100 AS DECIMAL(10,2)),
    '退票率环比', '退票率环比(百分点)',  '7d',   CAST((refund_ticket_rate_7d   - refund_ticket_rate_prev_7d)   * 100 AS DECIMAL(10,2)),
    '退票率环比', '退票率环比(百分点)',  '30d',  CAST((refund_ticket_rate_30d  - refund_ticket_rate_prev_30d)  * 100 AS DECIMAL(10,2)),
    '退票率环比', '退票率环比(百分点)',  '90d',  CAST((refund_ticket_rate_90d  - refund_ticket_rate_prev_90d)  * 100 AS DECIMAL(10,2)),
    '退票率环比', '退票率环比(百分点)',  '180d', CAST((refund_ticket_rate_180d - refund_ticket_rate_prev_180d) * 100 AS DECIMAL(10,2))
) ind AS target_name, target_desc, date_type, data_value;
