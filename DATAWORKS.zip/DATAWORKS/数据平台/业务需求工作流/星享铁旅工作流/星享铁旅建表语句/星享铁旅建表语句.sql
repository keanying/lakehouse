--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2026-05-07 17:11:54
--EMR任务只能运行在独享资源组上
--********************************************************************--


CREATE TABLE IF NOT EXISTS `default`.src_uu_ss_order_di
(
   id             STRING COMMENT '表id',
   member         STRING COMMENT '购买者ID',
   ordernum       STRING COMMENT '订单号',
   certnum        STRING COMMENT '资源ID',
   remotenum      STRING COMMENT '远端订单号',
   lid            STRING COMMENT '景区id',
   tid            STRING COMMENT '门票id',
   pid            STRING COMMENT '产品id',
   aid            STRING COMMENT '供应商ID',
   tnum           STRING COMMENT '门票数量',
   tprice         STRING COMMENT '单价',
   ordername      STRING COMMENT '取票人姓名',
   ordertel       STRING COMMENT '取票人电话',
   contacttel     STRING COMMENT '取票人电话',
   ordertime      STRING COMMENT '下单时间',
   playtime       STRING COMMENT '预计游玩时间',
   begintime      STRING COMMENT '开始时间',
   endtime        STRING COMMENT '结束时间',
   ctime          STRING COMMENT '取消时间',
   dtime          STRING COMMENT '验证时间',
   `status`       STRING COMMENT '订单状态：0=未使用,1=已使用,2=已过期,3=被取消,4=待确认(酒店)，待收货(特产),5=被终端修改,6=被终端撤销,7=部分使用,8=订单完结,9=被删除',
   pay_status     STRING COMMENT '支付状态:0=现场支付,1=已支付,2=未支付',
   salerid        STRING COMMENT '商家ID',
   remsg          STRING COMMENT '短信重发限制次数',
   smserror       STRING COMMENT '短信错误信息',
   paymode        STRING COMMENT '支付方式：0=余额支付,1=支付宝,2=授信支付,3=产品自销,4=现场支付,5=微信支付,6=会员卡支付,7=银联支付,8=环迅支付,9=现金支付,10=会员卡,11=拉卡拉（商户）,12=拉卡拉（平台）,13=特权支付（年卡）,14=微信（聚合）,15=平安银行,16=支付宝（聚合）,17=会员卡支付,18=计时卡支付,25=招行一网通支付,26=银联商务支付,27=银联商务POS支付,28=威富通支付,29=易宝云企付,33=博思支付,35=积分支付,36=POSS支付',
   totalmoney     STRING COMMENT '总的支付金额',
   ordermode      STRING COMMENT '下单方式:0=正常分销商下单,1=普通用户支付,2=用户手机支付,3=会员卡购票,10=云票务,11=微信商城,12=自助机,13=二级店铺,14=闸机购票,15=智能终端,16=计调下单,17=淘宝码商,18=年卡,19=微信端,20=外部接口OTA下单,22=一卡通,23=套票子票',
   onsale         STRING COMMENT '0正常,1使用优惠价支付,2修改过的订单',
   personid       STRING COMMENT '取票人身份信息',
   callback       STRING COMMENT '是否需要回调:0无需,1必需',
   code           STRING COMMENT '凭证码',
   unionCheck     STRING COMMENT '提现类型：0=正常订单，1=不可退且可提现的订单，2=独立收款',
   visitors       STRING COMMENT '订单客户类型：1=游客,2=分销商',
   pay_time       STRING COMMENT '订单支付时间',
   order_time     STRING COMMENT '逻辑下单时间',
   update_time    STRING COMMENT '订单更新时间',
   order_month    STRING COMMENT '逻辑下单月份',
   product_type   STRING COMMENT '商品类型',
   apply_did      STRING COMMENT '原始供应商ID',
   sync_state     STRING COMMENT '是否同步标示 1:同步,0:无需同步',
   trade_order_id STRING COMMENT '交易订单号'
)
COMMENT '平台订单记录主表'
STORED AS ORC;

CREATE TABLE IF NOT EXISTS `default`.src_uu_order_tourist_info_di
(
   id            STRING COMMENT '表ID',
   orderid       STRING COMMENT '',
   tourist       STRING COMMENT '游客姓名',
   idcard        STRING COMMENT '',
   voucher_type  STRING COMMENT '身份信息类型:1=身份证, 2=护照, 3=军官证, 4=回乡证, 5=台胞证, 99=其他',
   mobile        STRING COMMENT '',
   check_state   STRING COMMENT '0未验证1已验证2已取消',
   idx           STRING COMMENT '订单序号',
   print_state   STRING COMMENT '打印状态0未打印1已打印',
   check_time    STRING COMMENT '验证时间',
   lid           STRING COMMENT '景点ID',
   chk_code      STRING COMMENT '升级过的凭证号',
   member_id     STRING COMMENT '游客ID',
   is_checked    STRING COMMENT '这个门票码是否全部验证',
   order_time    STRING COMMENT '逻辑下单时间',
   update_time   STRING COMMENT '订单更新时间',
   order_month   STRING COMMENT '逻辑下单月份',
   apply_did     STRING COMMENT '原始供应商ID',
   sync_state    STRING COMMENT '是否同步标示 1:同步,0:无需同步',
   mobile_area   STRING COMMENT '手机区号',
   mobile_region STRING COMMENT '手机区号的区域代码'
)
COMMENT '游客身份证等信息表'
STORED AS ORC;


CREATE TABLE IF NOT EXISTS `default`.src_pft_order_tourist_track_di
(
   id              STRING COMMENT '表ID',
   ordernum        STRING COMMENT '订单号',
   idx             STRING COMMENT '订单游客表序号',
   track_action    STRING COMMENT '变更状态:1=入园,2=取消,3=过期,4=验证',
   tid             STRING COMMENT '票类ID',
   tnum            STRING COMMENT '变更次数',
   left_num        STRING COMMENT '剩余可用次数',
   source          STRING COMMENT '操作来源:0=终端机,1=软终端,2=自助机,3=外部通知更新,4=云票务,5=云闸机,6=PC-支付宝,7=手机支付宝,8=支付宝刷卡,9=支付宝扫码,10=微信支付,11=微信刷卡,12=微信扫码,13=PC-银联,14=手机-银联,15=PC-环迅,16=内部接口,17=外部接口,18=undefined,19=自运行服务,20=安卓智能终端机,21=验证服务器,22=微信商城,23=二级店铺,24=OTA,25=会员购票,26=年卡特权,27=平安银行,28=内部接口,29=民生乐收银,30=一卡通',
   terminal        STRING COMMENT '终端号',
   branch_terminal STRING COMMENT '分终端号',
   saler_id        STRING COMMENT '现在存储站点ID',
   insert_time     STRING COMMENT '添加时间',
   oper_member     STRING COMMENT '操作用户',
   msg             STRING COMMENT '备注信息',
   ext_content     STRING COMMENT '验证或是取消过程中的一些数据',
   order_time      STRING COMMENT '逻辑下单时间',
   update_time     STRING COMMENT '订单更新时间',
   order_month     STRING COMMENT '逻辑下单月份',
   apply_did       STRING COMMENT '原始供应商ID',
   sync_state      STRING COMMENT '是否同步标示 1:同步,0:无需同步'
)
COMMENT '门票订单变更追踪表'
STORED AS ORC;


CREATE TABLE IF NOT EXISTS `default`.src_uu_order_addon_di
(
   id            STRING COMMENT '表ID',
   orderid       STRING COMMENT '订单号',
   dstatus       STRING COMMENT '确认订单状态:0=无需确认,1=待确认,2=已确认未验证,3=已确认已验证,4=确认后取消,5=确认后修改,6=演出套票的订单',
   confirm_time  STRING COMMENT '确认时间',
   confirm_op    STRING COMMENT '分销商ID',
   ifpack        STRING COMMENT '套票标识:0=非套票订单,1=套票主订单,>100000=套票从订单（2票付通从订单）',
   sysorder      STRING COMMENT '子票是否已经处理完成:100=处理完,0=没有',
   pack_order    STRING COMMENT '套票主票订单号',
   pack_process  STRING COMMENT '线下自填的流水号json数据',
   ifprint       STRING COMMENT '是否被打印:1=被打印',
   vcode         STRING COMMENT '对接第三方系统的凭证码',
   tordernum     STRING COMMENT '对接第三方系统的对方订单',
   partner_mark  STRING COMMENT '是否对接三方系统标识',
   link_ordernum STRING COMMENT '原来uu_order_fx_details->concat_id',
   order_time    STRING COMMENT '逻辑下单时间',
   update_time   STRING COMMENT '订单更新时间',
   order_month   STRING COMMENT '逻辑下单月份',
   apply_did     STRING COMMENT '原始供应商ID',
   sync_state    STRING COMMENT '是否同步标示:1=同步,0=无需同步'
)
COMMENT '订单扩展表'
STORED AS ORC;


CREATE TABLE IF NOT EXISTS `default`.src_order_aids_split_di
(
   id                  STRING COMMENT '',
   orderid             STRING COMMENT '订单号',
   buyerid             STRING COMMENT '购买用户ID',
   sellerid            STRING COMMENT '供应商ID',
   `level`             STRING COMMENT '所处的级别：1=第一级，0=既是1级也是末级，-1=最末级，2=中间级别',
   pmode               STRING COMMENT '该级别的支付方式',
   cost_money          STRING COMMENT '成本价（分为单位）',
   sale_money          STRING COMMENT '销售价（分为单位）',
   member_relationship STRING COMMENT '订单会员关系 0:平台关系,1:资源中心关系',
   order_time          STRING COMMENT '逻辑下单时间',
   update_time         STRING COMMENT '订单更新时间',
   order_month         STRING COMMENT '逻辑下单月份',
   apply_did           STRING COMMENT '原始供应商ID',
   sync_state          STRING COMMENT '是否同步标示 1:同步,0:无需同步'
)
COMMENT '订单每级买入卖出者'
STORED AS ORC;

