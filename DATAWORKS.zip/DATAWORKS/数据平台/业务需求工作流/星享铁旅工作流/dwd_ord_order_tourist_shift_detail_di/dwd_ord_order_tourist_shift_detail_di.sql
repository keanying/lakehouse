--Serverless Spark SQL
--********************************************************************--
--author: 尹开英
--create time: 2026-05-08 18:32:34
--Serverless Spark SQL任务只能运行在独享资源组上
--********************************************************************--
-- =====================================================================
-- 明细数据加工逻辑
-- =====================================================================

CREATE TABLE IF NOT EXISTS dwd_ord_order_tourist_shift_detail_di
(
    order_id                   STRING COMMENT '订单号',
    tourist_serial_id          STRING COMMENT '游客/票码序号',
    -- tourist_id                 STRING COMMENT '游客表ID',
    -- tourist_name               STRING COMMENT '游客姓名',
    certificate_type           STRING COMMENT '证件类型',

    age                        INT    COMMENT '年龄，基于身份证出生日期和业务日期计算；非身份证为空',
    age_group                  STRING COMMENT '年龄段：儿童/成人/老人/未知，阈值可按业务调整',
    is_child                   INT    COMMENT '是否儿童：默认年龄<18',
    is_adult                   INT    COMMENT '是否成人：默认18<=年龄<60',
    is_elderly                 INT    COMMENT '是否老人：默认年龄>=60',

    member_id                  STRING COMMENT '会员ID(分销商ID/购买者ID)',
    member_name                STRING COMMENT '会员名称（分销商名称）',
    channel_category_l1_id     INT    COMMENT '渠道一级分类ID',
    channel_category_l1_name   STRING COMMENT '渠道一级分类名称',
    channel_category_l2_id     INT    COMMENT '渠道二级分类ID',
    channel_category_l2_name   STRING COMMENT '渠道二级分类名称',
    -- accounting_channel_name    STRING COMMENT '做账用渠道名称：优先分销商名称，其次二级渠道名称',

    scenic_id                  STRING COMMENT '景区ID lid',
    prd_id                     STRING COMMENT '产品ID pid',
    ticket_id                  STRING COMMENT '门票ID/子票ID tid',
    ticket_name                STRING COMMENT '门票/子票名称',

    route_name                 STRING COMMENT '线路名称，如上饶-弋阳；优先从票名解析',
    -- shift_start_time           STRING COMMENT '班次开始时间，格式HH:mm；优先从票名解析',
    -- shift_end_time             STRING COMMENT '班次结束时间，格式HH:mm；优先从票名解析',
    -- shift_name                 STRING COMMENT '班次名称：线路+开始结束时间',
    -- shift_sort_id              INT    COMMENT '班次排序号；已知6班次内置排序，其他为空',

    order_type                 STRING COMMENT '订单类型：单票/套票主票/套票子票',
    combo_ord_id               STRING COMMENT '套票主订单号；单票为自身订单号',
    combo_flag                 STRING COMMENT '套票标识:0=非套票订单,1=套票主订单,>100000=套票从订单（2票付通从订单）',

    ord_ticket_qty             INT    COMMENT '订单票数',
    unit_price                 DECIMAL(18,2) COMMENT '单价',
    order_total_amt            DECIMAL(18,2) COMMENT '订单总支付金额',
    pay_mode                   STRING COMMENT '支付方式：0=余额支付,1=支付宝,2=授信支付,3=产品自销,4=现场支付,5=微信支付,6=会员卡支付,7=银联支付,8=环迅支付,9=现金支付,10=会员卡,11=拉卡拉（商户）,12=拉卡拉（平台）,13=特权支付（年卡）,14=微信（聚合）,15=平安银行,16=支付宝（聚合）,17=会员卡支付,18=计时卡支付,25=招行一网通支付,26=银联商务支付,27=银联商务POS支付,28=威富通支付,29=易宝云企付,33=博思支付,35=积分支付,36=POSS支付',
    pay_status                 STRING COMMENT '支付状态:0=现场支付,1=已支付,2=未支付',
    order_status               STRING COMMENT '订单状态：0=未使用,1=已使用,2=已过期,3=被取消,4=待确认(酒店)，待收货(特产),5=被终端修改,6=被终端撤销,7=部分使用,8=订单完结,9=被删除',
    ord_confirm_status         STRING COMMENT '确认订单状态:0=无需确认,1=待确认,2=已确认未验证,3=已确认已验证,4=确认后取消,5=确认后修改,6=演出套票的订单',

    order_time                 STRING COMMENT '下单时间',
    -- pay_time                   STRING COMMENT '支付时间',
    expect_tour_date           STRING COMMENT '预计游玩日期，yyyyMMdd',
    cancel_time                STRING COMMENT '取消时间',
    order_update_time          STRING COMMENT '订单更新时间',

    -- ticket_status              STRING COMMENT '门票码状态:0=未验证, 1=已验证, 2=已取消, 4=过期, 7=部分验证',
    -- is_all_verified            STRING COMMENT '票码是否全部验证',
    -- verify_time                TIMESTAMP COMMENT '游客表验证时间',
    last_enter_time            STRING COMMENT '轨迹表最近核销/入园时间',
    last_cancel_time           STRING COMMENT '轨迹表最近取消时间',
    last_expire_time           STRING COMMENT '轨迹表最近过期时间',
    -- track_action_list          STRING COMMENT '轨迹动作列表，逗号分隔',
    -- last_track_action          STRING COMMENT '最近一次轨迹动作',

    is_order_paid              INT    COMMENT '是否已支付订单',
    is_order_cancel            INT    COMMENT '是否取消订单',
    is_paid_not_cancel         INT    COMMENT '是否可作为人数统计的明细行：已支付且非取消',
    is_verified                INT    COMMENT '是否已核销/入园：游客验证状态或轨迹验证/入园满足',
    is_unchecked_play_person   INT    COMMENT '是否游玩日未核销有效人数：用于有效期结束自动验证场景下近似上车人数',
    person_cnt                 INT    COMMENT '人数计数字段，明细粒度每行固定为1',

    src_supplier_id            INT COMMENT '原始供应商ID',
    etl_time                   STRING COMMENT 'ETL处理时间'
)
COMMENT '订单-游客-子票-班次明细表，支撑上车/核销、预定、渠道'
PARTITIONED BY (travel_date STRING COMMENT '分区日期，yyyyMMdd；建议按下单日期或调度日期落分区')
STORED AS ORC;

REFRESH TABLE default.src_order_aids_split_di;
REFRESH TABLE default.src_uu_ss_order_di;
REFRESH TABLE default.src_uu_order_tourist_info_di;
REFRESH TABLE default.src_pft_order_tourist_track_di;
REFRESH TABLE default.src_uu_order_addon_di;
REFRESH TABLE default.dim_distribute_channel_type_o_f;
REFRESH TABLE default.ods_uu_jq_ticket_d_f;
REFRESH TABLE default.s_myuu_pft_member_d_f;

INSERT OVERWRITE TABLE dwd_ord_order_tourist_shift_detail_di PARTITION (travel_date)
WITH

order_base AS (
    SELECT
        o.ordernum,
        o.member,
        o.ordermode,
        o.lid,
        o.pid,
        o.tid,
        CAST(o.tnum AS INT) AS tnum,
        CAST(CAST(o.tprice AS DECIMAL(18,2)) / 100 AS DECIMAL(18,2)) AS tprice,
        CAST(CAST(o.totalmoney AS DECIMAL(18,2)) / 100 AS DECIMAL(18,2)) AS totalmoney,
        o.paymode,
        o.pay_status,
        o.status    AS order_status,
        o.ordertime AS order_ts,
        from_unixtime(o.pay_time, 'yyyy-MM-dd HH:mm:ss') AS pay_ts,
        o.playtime  AS play_date,
        o.ctime     AS cancel_ts,
        from_unixtime(o.update_time, 'yyyy-MM-dd HH:mm:ss') AS order_update_ts,
        o.order_month,
        o.apply_did,
        date_format(o.ordertime, 'yyyyMMdd') as travel_date
    FROM default.src_uu_ss_order_di o
),

-- ---------------------------------------------------------------------
-- 游客/票码表：优先使用游客表形成一人一行
-- ---------------------------------------------------------------------
person_base AS (
    SELECT
        i.id AS tourist_id,
        i.orderid AS ordernum,
        i.idx AS tourist_idx,
        i.tourist AS tourist_name,
        i.idcard,
        i.voucher_type,
        i.mobile
        -- i.check_state,
        -- i.is_checked,
        -- from_unixtime(i.insert_time, 'yyyy-MM-dd HH:mm:ss') AS check_ts
    FROM default.src_uu_order_tourist_info_di i
),


-- ---------------------------------------------------------------------
-- 轨迹表：按订单+游客序号汇总核销、取消、过期等事件
-- track_action：1=入园，2=取消，3=过期，4=验证
-- ---------------------------------------------------------------------
 
track_agg AS (
    SELECT
        tr.ordernum, tr.idx AS tourist_idx,
        MAX(CASE WHEN tr.track_action IN ('1','4') THEN from_unixtime(tr.insert_time, 'yyyy-MM-dd HH:mm:ss') END) AS track_check_ts,
        MAX(CASE WHEN tr.track_action = '2' THEN from_unixtime(tr.insert_time, 'yyyy-MM-dd HH:mm:ss') END) AS track_cancel_ts,
        MAX(CASE WHEN tr.track_action = '3' THEN from_unixtime(tr.insert_time, 'yyyy-MM-dd HH:mm:ss') END) AS track_expire_ts
    FROM default.src_pft_order_tourist_track_di tr
    GROUP BY tr.ordernum, tr.idx
),

-- ---------------------------------------------------------------------
-- 订单扩展表：识别单票、套票主票、套票子票，并保留主单号
-- ---------------------------------------------------------------------
addon_dedup AS (
    SELECT
        a.orderid AS ordernum,
        a.dstatus,
        a.ifpack,
        CASE
            WHEN a.ifpack = '1' THEN a.orderid
            WHEN a.pack_order IS NOT NULL AND a.pack_order <> '' AND a.pack_order <> '1' THEN a.pack_order
            ELSE a.orderid
        END AS pack_ordernum,
        CASE
            WHEN a.ifpack = '1' THEN '套票主票'
            WHEN a.ifpack = '2'
              OR (CASE WHEN a.ifpack RLIKE '^[0-9]+$' THEN CAST(a.ifpack AS BIGINT) ELSE NULL END) > 100000
              OR (a.pack_order IS NOT NULL AND a.pack_order <> '' AND a.pack_order <> '1') THEN '套票子票'
            ELSE '单票'
        END AS order_type
    FROM default.src_uu_order_addon_di a
    WHERE a.orderid IS NOT NULL
),


split_dim_tmp1 AS(
SELECT    
    -- 原始分销字段
    order_split_table.id,                                     
    order_split_table.orderid, 
    order_split_table.buyerid, 
    order_split_table.sellerid, 
    order_split_table.level, 
    order_split_table.pmode, 
    order_split_table.cost_money, 
    order_split_table.sale_money, 
    order_split_table.member_relationship, 
    order_split_table.order_time,         
    order_split_table.update_time, 
    order_split_table.order_month, 
    order_split_table.apply_did, 
    order_split_table.sync_state, 
    -- order_split_table.orderdate,

    -- 替代 ods_order_aids_distribute_d_i表用字段
    -- 1.本单级别（未考虑补一级之前）
    order_count_level_table.order_count_level       AS distribute_num,
    order_split_table_2.publisher_id                AS publisher_id,
    order_split_table_2.distributor_1_id            AS distributor_1_id,
    order_split_table_2.distribute_1_price          AS distribute_1_price,
    order_split_table_2.resource_center_supplier_id AS resource_center_supplier_id,
    order_split_table_2.resource_center_purchase_id AS resource_center_purchase_id,


    -- 标识具体分销层级(0~5标识方法)
    IF (
        level = 0 OR level = 1,
        -- 顶级供应商销售记录，标志为 0
        0,
        -- 非顶级供应商销售记录
        IF (
            level = -1,
            -- 最末级
            order_count_level_table.order_count_level - 1,
            IF (
                sellerid = level2_sellerid_table.level2_sellerid,
                -- 第一级销售
                1,
                -- 非第二级
                IF (
                    -- 本笔分销大于三级，且本级购买者为倒数第二级的购买者
                    (order_count_level_table.order_count_level > 3) AND (order_split_table.buyerid = level_2_buyerid_table.level_2_buyerid),
                    -- 本笔为倒数第二级
                    order_count_level_table.order_count_level - 2,
                    -- 第二级分销
                    2
                )
            )
        )
    )               AS detail_split_level,

    -- 是否分销末级
    IF(
        level = 0 OR level = -1,
        1, 
        0
    )               AS is_end_level,
    order.visitors  AS visitors
FROM 
(
    -- 分销记录
    SELECT 
        id, orderid, buyerid, sellerid, level, 
        pmode, cost_money, sale_money, member_relationship, order_time,         
        update_time, order_month, apply_did, sync_state
    FROM default.src_order_aids_split_di
) AS order_split_table
LEFT JOIN 
(
    -- 本订单总共分销级别
    SELECT orderid, COUNT(1) AS order_count_level 
    FROM default.src_order_aids_split_di 
    GROUP BY orderid
) AS order_count_level_table
ON order_split_table.orderid = order_count_level_table.orderid
LEFT JOIN 
(
    -- 第二级销售者（第一级的购买者）可能无
    SELECT orderid, buyerid AS level2_sellerid 
    FROM default.src_order_aids_split_di 
      WHERE level = 1
) AS level2_sellerid_table
ON order_split_table.orderid = level2_sellerid_table.orderid
LEFT JOIN 
(
    -- 倒数第二级购买者（最后一级销售者）可能无
    SELECT orderid, sellerid AS level_2_buyerid 
    FROM default.src_order_aids_split_di 
      WHERE level = -1
) AS level_2_buyerid_table
ON order_split_table.orderid = level_2_buyerid_table.orderid 
LEFT JOIN
(
    SELECT 
        ordernum, 
        -- orderdate, 
        visitors
    FROM default.src_uu_ss_order_di
) AS order 
ON order_split_table.orderid = order.ordernum
LEFT JOIN 
(
    SELECT
        orderid,
        -- COUNT(*)                                        AS distribute_num,
        SUM(IF(level IN (0,1), sellerid, NULL))         AS publisher_id,
        SUM(IF(level IN (0,1), buyerid, NULL))          AS distributor_1_id,
        SUM(IF(level IN (0,1), sale_money, NULL))       AS distribute_1_price,
        SUM(IF(member_relationship=1, sellerid, NULL))  AS resource_center_supplier_id,
        SUM(IF(member_relationship=1, buyerid, NULL))   AS resource_center_purchase_id
    FROM default.src_order_aids_split_di
    GROUP BY orderid
) AS order_split_table_2
ON order_split_table.orderid = order_split_table_2.orderid
),

split_dim_tmp2 AS(
SELECT 
    id,
    orderid,
    buyerid,
    sellerid,
    level,
    pmode,
    cost_money,
    sale_money,
    member_relationship,
    order_time,
    update_time,
    order_month,
    apply_did,
    sync_state,
    distribute_num,
    publisher_id,
    distributor_1_id,
    distribute_1_price,
    resource_center_supplier_id,
    resource_center_purchase_id,
    detail_split_level,
    is_end_level
    -- ,orderdate
FROM 
(
    -- 订单购买者非商家的，不需要补充一级
    SELECT 
        id, orderid, sellerid, buyerid, level, 
        pmode, cost_money, sale_money, member_relationship, order_time,         
        update_time, order_month, apply_did, sync_state, 
        
        -- orderdate,

        distribute_num,
        publisher_id,
        distributor_1_id,
        distribute_1_price,
        resource_center_supplier_id,
        resource_center_purchase_id,

        detail_split_level + 1 AS detail_split_level,
        is_end_level
        -- visitors
    FROM split_dim_tmp1
    WHERE visitors != 2

    UNION ALL 

    -- 订单购买者为商家的，非末级数据需更改
    SELECT 
        id, orderid, sellerid, buyerid, level, 
        pmode, cost_money, sale_money, member_relationship, order_time,         
        update_time, order_month, apply_did, sync_state, 
        
        -- orderdate,

        distribute_num + 1      AS distribute_num, 
        publisher_id,
        distributor_1_id,
        distribute_1_price,
        resource_center_supplier_id,
        resource_center_purchase_id,

        detail_split_level + 1  AS detail_split_level, 
        is_end_level
        -- visitors
    FROM split_dim_tmp1
    WHERE visitors = 2
      AND is_end_level != 1

    UNION ALL 

    -- 订单购买者为商家的，末级数据需更改
    SELECT 
        id, orderid, sellerid, buyerid, level, 
        pmode, cost_money, sale_money, member_relationship, order_time,         
        update_time, order_month, apply_did, sync_state, 
        
        -- orderdate,

        distribute_num + 1      AS distribute_num, 
        publisher_id,
        distributor_1_id,
        distribute_1_price,
        resource_center_supplier_id,
        resource_center_purchase_id,

        detail_split_level + 1  AS detail_split_level,
        0                       AS is_end_level
        -- visitors
    FROM split_dim_tmp1
    WHERE visitors = 2
      AND is_end_level = 1

    -- 订单购买者为商家的，需要补一级
    UNION ALL 

    SELECT 
        id, orderid, buyerid AS sellerid, buyerid, level, 
        pmode, cost_money, sale_money, member_relationship, order_time,         
        update_time, order_month, apply_did, sync_state, 
        distribute_num + 1      AS distribute_num, 
        publisher_id,
        distributor_1_id,
        distribute_1_price,
        resource_center_supplier_id,
        resource_center_purchase_id,

        detail_split_level + 2  AS detail_split_level, 
        1                       AS is_end_level
        -- visitors
    FROM split_dim_tmp1
    WHERE visitors = 2
      AND is_end_level = 1
  )
),
split_dim AS(
    SELECT 
        DISTINCT
        split_dim_tmp2.orderid,
        CAST(REGEXP_REPLACE(printf('%.0f', distributor_1_id), '\\.0+$', '') AS BIGINT)  AS distributor_1_id
    FROM split_dim_tmp2
    LEFT JOIN 
    (
        SELECT orderid, sellerid
        FROM split_dim_tmp2
        WHERE detail_split_level = 1 AND is_end_level = 1
    ) AS t1
    ON t1.orderid = split_dim_tmp2.orderid
),

-- ---------------------------------------------------------------------
-- 渠道、票名、分销商维表
-- ---------------------------------------------------------------------
channel_dim AS (
    SELECT
        channel_class1_id,
        channel_class1_name,
        channel_class2_id,
        channel_class2_name
    FROM default.dim_distribute_channel_type_o_f
),

ticket_dim AS (
    SELECT
        CAST(id AS STRING) AS tid,
        title AS ticket_title
    FROM default.ods_uu_jq_ticket_d_f
    WHERE pt = CAST(DATE_FORMAT(DATE_SUB(TO_DATE('${bizdate}', 'yyyyMMdd'), 1), 'yyyyMMdd') AS INT)
),

member_dim AS (
    SELECT
        CAST(id AS STRING) AS member_id,
        dname AS member_name
    FROM default.s_myuu_pft_member_d_f
    WHERE pt = CAST(DATE_FORMAT(DATE_SUB(TO_DATE('${bizdate}', 'yyyyMMdd'), 1), 'yyyyMMdd') AS INT)
),


ota_loopback_dim AS (
    SELECT 
        id, channel_aggregation_name, target_id
    FROM
    (
        -- 商户回调地址
        SELECT id, dcodeURL
        FROM s_myuu_pft_member_d_f
        WHERE pt = FROM_UNIXTIME(UNIX_TIMESTAMP(DATE_SUB(CURRENT_DATE, 1)), 'yyyyMMdd')
        -- 供应商，分销商
        AND dtype IN (0, 1)
        -- 排除测试
        AND group_id != 2
    ) AS member 
    INNER JOIN 
    (
        SELECT loopback_address, channel_aggregation_name, target_id
        FROM dim_distribute_ota_o_f
        -- 通过回调地址确认
        WHERE rule_code = 1
    ) AS OTA 
    ON member.dcodeURL RLIKE OTA.loopback_address
),

ota_member_dim AS (
    SELECT 
        member_id AS id, channel_aggregation_name, target_id
    FROM 
    (
        SELECT member_id, channel_aggregation_name, target_id
        FROM dim_distribute_ota_o_f
        -- 通过member_id确认
        WHERE rule_code = 2
        AND member_id NOT IN (
            SELECT id FROM ota_loopback_dim
        )
    )
),

-- ---------------------------------------------------------------------
-- 已知6个班次维度：用于排序和标准化名称。
-- 如果明日实际有16个班次，可只在这里追加16个班次，不需要改明细主逻辑。
-- ---------------------------------------------------------------------
shift_dim AS (
    SELECT 4888668 AS tid,	'上饶-弋阳8:18-8:55' AS parsed_route_name UNION ALL
    SELECT 4888682 AS tid,	'弋阳-上饶9:35-10:12' AS parsed_route_name UNION ALL
    SELECT 4888726 AS tid,	'上饶-弋阳8:18-8:55' AS parsed_route_name UNION ALL
    SELECT 4888732 AS tid,	'弋阳-上饶9:35-10:12' AS parsed_route_name UNION ALL
    SELECT 4888845 AS tid,	'上饶-弋阳8:18-8:55/弋阳-上饶9:35-10:12' AS parsed_route_name UNION ALL
    SELECT 4909591 AS tid,	'上饶-弋阳8:18-8:55/弋阳-上饶9:35-10:12' AS parsed_route_name UNION ALL
    SELECT 4910187 AS tid,	'上饶-弋阳17:05-17:45' AS parsed_route_name UNION ALL
    SELECT 4910189 AS tid,	'弋阳-上饶18:30-19:09' AS parsed_route_name UNION ALL
    SELECT 4910195 AS tid,	'弋阳-上饶18:30-19:09' AS parsed_route_name UNION ALL
    SELECT 4910263 AS tid,	'上饶-弋阳17:05-17:45/弋阳-上饶18:30-19:09' AS parsed_route_name UNION ALL
    SELECT 4910355 AS tid,	'上饶-弋阳8:18-8:55/弋阳-上饶18:30-19:09' AS parsed_route_name UNION ALL
    SELECT 4912138 AS tid,	'上饶-武夷山11:00-13:07' AS parsed_route_name UNION ALL
    SELECT 4912143 AS tid,	'武夷山-上饶14:00-16:15' AS parsed_route_name UNION ALL
    SELECT 4912145 AS tid,	'上饶-武夷山11:00-13:07' AS parsed_route_name UNION ALL
    SELECT 4912146 AS tid,	'武夷山-上饶14:00-16:15' AS parsed_route_name UNION ALL
    SELECT 4918935 AS tid,	'上饶-弋阳8:18-8:55' AS parsed_route_name UNION ALL
    SELECT 4918936 AS tid,	'弋阳-上饶9:35-10:12' AS parsed_route_name UNION ALL
    SELECT 4918937 AS tid,	'上饶-弋阳17:05-17:45' AS parsed_route_name UNION ALL
    SELECT 4918938 AS tid,	'弋阳-上饶18:30-19:09' AS parsed_route_name UNION ALL
    SELECT 4918939 AS tid,	'上饶-武夷山11:00-13:07' AS parsed_route_name UNION ALL
    SELECT 4918940 AS tid,	'武夷山-上饶14:00-16:15' AS parsed_route_name UNION ALL
    SELECT 4918976 AS tid,	'上饶-弋阳8:18-8:55/弋阳-上饶9:35-10:12' AS parsed_route_name UNION ALL
    SELECT 4920554 AS tid,	'上饶-弋阳8:18-8:55' AS parsed_route_name UNION ALL
    SELECT 4920555 AS tid,	'弋阳-上饶9:35-10:12' AS parsed_route_name UNION ALL
    SELECT 4920556 AS tid,	'上饶-弋阳17:05-17:45' AS parsed_route_name UNION ALL
    SELECT 4920557 AS tid,	'弋阳-上饶18:30-19:09' AS parsed_route_name UNION ALL
    SELECT 4920565 AS tid,	'上饶-弋阳17:05-17:45/弋阳-上饶18:30-19:09' AS parsed_route_name UNION ALL
    SELECT 4920571 AS tid,	'上饶-弋阳8:18-8:55/弋阳-上饶18:30-19:09' AS parsed_route_name UNION ALL
    SELECT 4920572 AS tid,	'上饶-弋阳8:18-8:55/弋阳-上饶18:30-19:09' AS parsed_route_name UNION ALL
    SELECT 4920573 AS tid,	'上饶-弋阳8:18-8:55/弋阳-上饶18:30-19:09' AS parsed_route_name UNION ALL
    SELECT 4920574 AS tid,	'上饶-弋阳8:18-8:55/弋阳-上饶9:35-10:12' AS parsed_route_name UNION ALL
    SELECT 4920577 AS tid,	'上饶-弋阳17:05-17:45/弋阳-上饶18:30-19:09' AS parsed_route_name UNION ALL
    SELECT 4920578 AS tid,	'上饶-弋阳8:18-8:55/弋阳-上饶18:30-19:09' AS parsed_route_name UNION ALL
    SELECT 4920655 AS tid,	'上饶-武夷山11:00-13:07' AS parsed_route_name UNION ALL
    SELECT 4920657 AS tid,	'武夷山-上饶14:00-16:15' AS parsed_route_name UNION ALL
    SELECT 4920737 AS tid,	'上饶-弋阳8:18-8:55' AS parsed_route_name UNION ALL
    SELECT 4920742 AS tid,	'弋阳-上饶9:35-10:12' AS parsed_route_name UNION ALL
    SELECT 4920744 AS tid,	'上饶-弋阳17:05-17:45' AS parsed_route_name UNION ALL
    SELECT 4920746 AS tid,	'弋阳-上饶18:30-19:09' AS parsed_route_name UNION ALL
    SELECT 4920749 AS tid,	'上饶-弋阳8:18-8:55/弋阳-上饶9:35-10:12' AS parsed_route_name UNION ALL
    SELECT 4920753 AS tid,	'上饶-弋阳17:05-17:45/弋阳-上饶18:30-19:09' AS parsed_route_name UNION ALL
    SELECT 4920754 AS tid,	'上饶-弋阳8:18-8:55/弋阳-上饶18:30-19:09' AS parsed_route_name UNION ALL
    SELECT 4920761 AS tid,	'上饶-武夷山11:00-13:07' AS parsed_route_name UNION ALL
    SELECT 4920765 AS tid,	'武夷山-上饶14:00-16:15' AS parsed_route_name UNION ALL
    SELECT 4929070 AS tid,	'上饶-弋阳17:05-17:45' AS parsed_route_name UNION ALL
    SELECT 4930364 AS tid,	'上饶-弋阳17:05-17:45/弋阳-上饶18:30-19:09' AS parsed_route_name UNION ALL
    SELECT 4933503 AS tid,	'上饶-武夷山11:00-13:07' AS parsed_route_name UNION ALL
    SELECT 4933515 AS tid,	'上饶-武夷山11:00-13:07' AS parsed_route_name UNION ALL
    SELECT 4933521 AS tid,	'武夷山-上饶14:00-16:15' AS parsed_route_name UNION ALL
    SELECT 4933528 AS tid,	'武夷山-上饶14:00-16:15' AS parsed_route_name UNION ALL
    SELECT 4933563 AS tid,	'上饶-弋阳8:18-8:55' AS parsed_route_name UNION ALL
    SELECT 4933601 AS tid,	'弋阳-上饶9:35-10:12' AS parsed_route_name UNION ALL
    SELECT 4933643 AS tid,	'上饶-弋阳17:05-17:45' AS parsed_route_name UNION ALL
    SELECT 4933651 AS tid,	'弋阳-上饶18:30-19:09' AS parsed_route_name UNION ALL
    SELECT 4933656 AS tid,	'上饶-弋阳8:18-8:55' AS parsed_route_name UNION ALL
    SELECT 4933663 AS tid,	'弋阳-上饶9:35-10:12' AS parsed_route_name UNION ALL
    SELECT 4933667 AS tid,	'上饶-弋阳17:05-17:45' AS parsed_route_name UNION ALL
    SELECT 4933679 AS tid,	'弋阳-上饶18:30-19:09' AS parsed_route_name UNION ALL
    SELECT 4970754 AS tid,	'上饶-弋阳8:18-8:55' AS parsed_route_name UNION ALL
    SELECT 4970758 AS tid,	'弋阳-上饶9:35-10:12' AS parsed_route_name UNION ALL
    SELECT 4970788 AS tid,	'上饶-弋阳17:05-17:45' AS parsed_route_name UNION ALL
    SELECT 4970792 AS tid,	'弋阳-上饶18:30-19:09' AS parsed_route_name UNION ALL
    SELECT 4970843 AS tid,	'上饶-武夷山11:00-13:07' AS parsed_route_name UNION ALL
    SELECT 4970844 AS tid,	'武夷山-上饶14:00-16:15' AS parsed_route_name UNION ALL
    SELECT 4982281 AS tid,	'上饶-弋阳8:18-8:55/弋阳-上饶18:30-19:09' AS parsed_route_name UNION ALL
    SELECT 4995886 AS tid,	'上饶-弋阳8:18-8:55/弋阳-上饶18:30-19:09' AS parsed_route_name UNION ALL
    SELECT 4996658 AS tid,	'上饶-弋阳8:18-8:55' AS parsed_route_name UNION ALL
    SELECT 4996776 AS tid,	'弋阳-上饶18:30-19:09' AS parsed_route_name
),

-- ---------------------------------------------------------------------
-- 票名解析班次：从ticket_title中抽取“线路 + HH:mm-HH:mm”。
-- 若票名格式不稳定，建议后续沉淀正式班次维表替代本段解析逻辑。
-- ---------------------------------------------------------------------
order_enriched AS (
    SELECT
        o.*,
        td.ticket_title,
        -- 线路解析：覆盖当前已知线路；若票名含更多线路，可扩展CASE或改接班次维表。
        sd.parsed_route_name
    FROM order_base o
    LEFT JOIN shift_dim sd
    ON o.tid = sd.tid
    LEFT JOIN ticket_dim td
    ON o.tid = td.tid
)

SELECT
    o.ordernum                       AS order_id,                                        -- 订单号
    p.tourist_idx                    AS tourist_serial_id,                               -- 游客/票码序号
    -- p.tourist_id                     AS tourist_id,                                      -- 游客表ID
    -- p.tourist_name                   AS tourist_name,                                    -- 游客姓名
    p.voucher_type                   AS certificate_type,                                -- 证件类型

    -- 年龄与人群标签
    CASE
        WHEN voucher_type = 1 AND p.idcard RLIKE '^[0-9]{17}[0-9Xx]$'
        THEN YEAR(TO_DATE('${bizdate}', 'yyyyMMdd')) - CAST(SUBSTR(p.idcard, 7, 4) AS INT)
             - CASE WHEN DATE_FORMAT(TO_DATE('${bizdate}', 'yyyyMMdd'), 'MMdd') < SUBSTR(p.idcard, 11, 4) THEN 1 ELSE 0 END
        ELSE NULL
    END                              AS age,                                             -- 年龄，基于身份证出生日期和业务日期计算；非身份证为空
    CASE
        WHEN voucher_type != 1 OR NOT (p.idcard RLIKE '^[0-9]{17}[0-9Xx]$') THEN '未知'
        WHEN YEAR(TO_DATE('${bizdate}', 'yyyyMMdd')) - CAST(SUBSTR(p.idcard, 7, 4) AS INT)
             - CASE WHEN DATE_FORMAT(TO_DATE('${bizdate}', 'yyyyMMdd'), 'MMdd') < SUBSTR(p.idcard, 11, 4) THEN 1 ELSE 0 END < 18 THEN '儿童'
        WHEN YEAR(TO_DATE('${bizdate}', 'yyyyMMdd')) - CAST(SUBSTR(p.idcard, 7, 4) AS INT)
             - CASE WHEN DATE_FORMAT(TO_DATE('${bizdate}', 'yyyyMMdd'), 'MMdd') < SUBSTR(p.idcard, 11, 4) THEN 1 ELSE 0 END >= 60 THEN '老人'
        ELSE '成人'
    END                              AS age_group,                                       -- 年龄段：儿童/成人/老人/未知，阈值可按业务调整
    CASE
        WHEN voucher_type = 1 AND p.idcard RLIKE '^[0-9]{17}[0-9Xx]$'
         AND YEAR(TO_DATE('${bizdate}', 'yyyyMMdd')) - CAST(SUBSTR(p.idcard, 7, 4) AS INT)
             - CASE WHEN DATE_FORMAT(TO_DATE('${bizdate}', 'yyyyMMdd'), 'MMdd') < SUBSTR(p.idcard, 11, 4) THEN 1 ELSE 0 END < 18 THEN 1
        ELSE 0
    END                              AS is_child,                                        -- 是否儿童：默认年龄<18
    CASE
        WHEN voucher_type = 1 AND p.idcard RLIKE '^[0-9]{17}[0-9Xx]$'
         AND YEAR(TO_DATE('${bizdate}', 'yyyyMMdd')) - CAST(SUBSTR(p.idcard, 7, 4) AS INT)
             - CASE WHEN DATE_FORMAT(TO_DATE('${bizdate}', 'yyyyMMdd'), 'MMdd') < SUBSTR(p.idcard, 11, 4) THEN 1 ELSE 0 END BETWEEN 18 AND 59 THEN 1
        ELSE 0
    END                              AS is_adult,                                        -- 是否成人：默认18<=年龄<60
    CASE
        WHEN voucher_type = 1 AND p.idcard RLIKE '^[0-9]{17}[0-9Xx]$'
         AND YEAR(TO_DATE('${bizdate}', 'yyyyMMdd')) - CAST(SUBSTR(p.idcard, 7, 4) AS INT)
             - CASE WHEN DATE_FORMAT(TO_DATE('${bizdate}', 'yyyyMMdd'), 'MMdd') < SUBSTR(p.idcard, 11, 4) THEN 1 ELSE 0 END >= 60 THEN 1
        ELSE 0
    END                              AS is_elderly,                                      -- 是否老人：默认年龄>=60

    -- 渠道与会员
    spd.distributor_1_id             AS member_id,                                       -- 会员ID(分销商ID/购买者ID)
    md.member_name                   AS member_name,                                     -- 会员名称（分销商名称）                    

    CASE WHEN o.ordermode = 20 THEN 3 ELSE INT(cd.channel_class1_id) END      
                                     AS channel_category_l1_id,                          -- 渠道一级分类ID
	CASE WHEN o.ordermode = 20 THEN 'OTA' ELSE cd.channel_class1_name END                -- 渠道一级分类名称
                                     AS channel_category_l1_name, 
	CASE WHEN o.ordermode = 20 THEN NVL(INT(otaTab.target_id), 2000) ELSE INT(cd.channel_class2_id) END  
                                     AS channel_category_l2_id,                          -- 渠道二级分类ID
	CASE WHEN o.ordermode = 20 THEN NVL(otaTab.channel_aggregation_name, '商家自研') ELSE cd.channel_class2_name END  
                                     AS channel_category_l2_name,                        -- 渠道二级分类名称

    -- 景区与门票
    o.lid                            AS scenic_id,                                       -- 景区ID lid
    o.pid                            AS prd_id,                                          -- 产品ID pid
    o.tid                            AS ticket_id,                                       -- 门票ID/子票ID tid
    o.ticket_title                   AS ticket_name,                                     -- 门票/子票名称
    o.parsed_route_name              AS parsed_route_name,                               -- 班次与线路

    -- 订单类型与套票
    COALESCE(ab.order_type, '单票')  AS order_type,                                     -- 订单类型：单票/套票主票/套票子票
    COALESCE(ab.pack_ordernum, o.ordernum) AS combo_ord_id,                              -- 套票主订单号；单票为自身订单号
    ab.ifpack                        AS combo_flag,                                      -- 套票标识:0=非套票订单,1=套票主订单,>100000=套票从订单（2票付通从订单）

    -- 订单金额
    o.tnum                           AS ord_ticket_qty,                                  -- 订单票数
    o.tprice                         AS unit_price,                                     -- 单价
    o.totalmoney                     AS order_total_amt,                                 -- 订单总支付金额

    -- 支付与订单状态
    o.paymode                        AS pay_mode,                                       -- 支付方式：0=余额支付,1=支付宝,2=授信支付,3=产品自销,4=现场支付,5=微信支付,6=会员卡支付,7=银联支付,8=环迅支付,9=现金支付,10=会员卡,11=拉卡拉（商户）,12=拉卡拉（平台）,13=特权支付（年卡）,14=微信（聚合）,15=平安银行,16=支付宝（聚合）,17=会员卡支付,18=计时卡支付,25=招行一网通支付,26=银联商务支付,27=银联商务POS支付,28=威富通支付,29=易宝云企付,33=博思支付,35=积分支付,36=POSS支付
    o.pay_status                     AS pay_status,                                     -- 支付状态:0=现场支付,1=已支付,2=未支付
    o.order_status                   AS order_status,                                   -- 订单状态：0=未使用,1=已使用,2=已过期,3=被取消,4=待确认(酒店)，待收货(特产),5=被终端修改,6=被终端撤销,7=部分使用,8=订单完结,9=被删除
    ab.dstatus                       AS ord_confirm_status,                             -- 确认订单状态:0=无需确认,1=待确认,2=已确认未验证,3=已确认已验证,4=确认后取消,5=确认后修改,6=演出套票的订单

    -- 时间字段
    o.order_ts                       AS order_time,                                     -- 下单时间
    -- o.pay_ts                         AS pay_time,                                       -- 支付时间
    -- o.play_ts                        AS expect_tour_time,                                -- 预计游玩时间
    o.play_date                      AS expect_tour_date,                                -- 预计游玩日期，yyyyMMdd
    -- o.begin_ts                       AS start_time,                                     -- 开始时间
    -- o.end_ts                         AS end_time,                                       -- 结束时间
    o.cancel_ts                      AS cancel_time,                                    -- 取消时间
    o.order_update_ts                AS order_update_time,                               -- 订单更新时间

    -- 门票状态与轨迹
    -- p.check_state                    AS ticket_status,                                  -- 门票码状态:0=未验证, 1=已验证, 2=已取消, 4=过期, 7=部分验证
    -- p.is_checked                     AS is_all_verified,                                -- 票码是否全部验证
    -- p.check_ts                       AS verify_time,                                    -- 游客表验证时间
    ta.track_check_ts                AS last_enter_time,                                -- 轨迹表最近核销/入园时间
    ta.track_cancel_ts               AS last_cancel_time,                               -- 轨迹表最近取消时间
    ta.track_expire_ts               AS last_expire_time,                               -- 轨迹表最近过期时间
    -- ta.track_action_list             AS track_action_list,                              -- 轨迹动作列表，逗号分隔
    -- ta.last_track_action             AS last_track_action,                              -- 最近一次轨迹动作

    -- 统计标记
    CASE WHEN o.pay_status != '2' THEN 1 ELSE 0 END AS is_order_paid,                     -- 是否已支付订单
    CASE WHEN o.order_status IN ('3','6','9') OR  ta.track_cancel_ts IS NOT NULL THEN 1 ELSE 0 END AS is_order_cancel, -- 是否取消订单
    CASE WHEN o.pay_status != '2'
          AND NOT (o.order_status IN ('3','6','9')  OR ta.track_cancel_ts IS NOT NULL)
         THEN 1 ELSE 0 END AS is_paid_not_cancel,                                       -- 是否可作为人数统计的明细行：已支付且非取消
    CASE WHEN ta.track_check_ts IS NOT NULL THEN 1 ELSE 0 END AS is_verified, -- 是否已核销/入园：游客验证状态或轨迹验证/入园满足

    CASE WHEN o.pay_status != '2'
      AND NOT (o.order_status IN ('3','6','9') OR ta.track_cancel_ts IS NOT NULL)
      AND ta.track_check_ts IS NULL
     THEN 1 ELSE 0 END AS is_unchecked_play_person,                                 --  “已支付、未取消、未核销”，不再绑定游玩日期。
--     CASE WHEN o.pay_status = '1'
--           AND NOT (o.order_status IN ('3','6','9') OR p.check_state = '2' OR ta.track_cancel_ts IS NOT NULL)
--           AND NOT (p.check_state = '1' OR p.is_checked = '1' OR ta.track_check_ts IS NOT NULL)
--           AND o.play_date = '${bizdate}'
--          THEN 1 ELSE 0 END AS is_unchecked_play_person,
    1                                AS person_cnt,                                     -- 人数计数字段，明细粒度每行固定为1

    -- 来源与ETL
    INT(o.apply_did)                 AS src_supplier_id,                                -- 原始供应商ID
    CURRENT_TIMESTAMP()              AS etl_time,                                        -- ETL处理时间,
    o.travel_date

FROM order_enriched o
JOIN person_base p
  ON o.ordernum = p.ordernum
LEFT JOIN track_agg ta
  ON p.ordernum = ta.ordernum
 AND p.tourist_idx = ta.tourist_idx
LEFT JOIN addon_dedup ab
  ON o.ordernum = ab.ordernum
LEFT JOIN channel_dim cd
  ON CAST(o.ordermode AS INT) = cd.channel_class2_id
LEFT JOIN split_dim spd
    ON COALESCE(ab.pack_ordernum, o.ordernum) = spd.orderid 
LEFT JOIN member_dim md
  ON spd.distributor_1_id = md.member_id
LEFT JOIN 
(
    SELECT id, target_id, channel_aggregation_name
    FROM ota_loopback_dim
    UNION 
    SELECT id, target_id, channel_aggregation_name
    FROM ota_member_dim
) AS otaTab
ON o.member = otaTab.id AND o.ordermode = 20
;
