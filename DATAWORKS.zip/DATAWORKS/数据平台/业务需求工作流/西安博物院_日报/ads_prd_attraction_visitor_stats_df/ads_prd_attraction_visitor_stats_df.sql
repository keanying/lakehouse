--@exclude_input=default_workspace_svwh.ods_myuu_uu_ss_order_df
--@exclude_input=5008819074904415716
--EMR Spark SQL
--********************************************************************--
--author: 韩瑞
--create time: 2026-09-25 10:41:29
--EMR任务只能运行在独享资源组上
--********************************************************************--

--历史月度统计结果字段需要每天刷新一次，保持所有日期的月度结果一致

INSERT OVERWRITE TABLE  ads_prd_attraction_visitor_stats_di PARTITION(verify_date)
WITH order_booking_table AS (
SELECT 
    id
    ,order_id
    ,idx
    ,scenic_id
    ,apply_did
    ,member_id
    ,traveler_name
    ,traveler_idcard
    ,traveler_phone
    ,traveler_phone_area
    ,traveler_phone_area_country_code 
    ,traveler_phone_area_country_name
    ,traveler_phone_region

    ,traveler_phone_province_code
    ,traveler_phone_province_name
    ,traveler_phone_city_code
    ,traveler_phone_city_name
    ,traveler_phone_district_code
    ,traveler_phone_district_name

    ,idcard_country_name
    ,idcard_province_code
    ,idcard_province_name
    ,idcard_city_code
    ,idcard_city_name
    ,idcard_district_code
    ,idcard_district_name

    ,COALESCE(traveler_phone_area_country_name,idcard_country_name) AS country_name
    ,COALESCE(traveler_phone_province_code,idcard_province_code,ext_province_code) AS province_code
    ,COALESCE(traveler_phone_province_name,idcard_province_name,ext_province_name) AS province_name
    ,COALESCE(traveler_phone_city_code,idcard_city_code,ext_city_code) AS city_code
    ,COALESCE(traveler_phone_city_name,idcard_city_name,ext_city_name) AS city_name
    ,COALESCE(traveler_phone_district_code,idcard_district_code,ext_district_code) AS district_code
    ,COALESCE(traveler_phone_district_name,idcard_district_name,ext_district_name) AS district_name

    ,ext_age
    ,ext_sex
    ,ext_region_code
    ,ext_country_code
    ,ext_province_code
    ,ext_province_name
    ,ext_city_code
    ,ext_city_name
    ,ext_district_code
    ,ext_district_name

    ,ext_info
    ,voucher_type
    ,check_state
    ,print_state
    ,chk_code
    ,is_checked
    ,check_time
    ,order_time
    ,order_date
    ,update_time
    ,sync_state
    ,end_time
    ,valid_num
    ,take_way
    ,travel_date

FROM (
    SELECT  t1.id
        ,t1.orderid AS order_id
        ,t1.idx
        ,t1.lid AS scenic_id
        ,t1.apply_did
        ,t1.member_id
        ,t1.tourist AS traveler_name
        ,t1.idcard AS traveler_idcard
        ,t1.mobile AS traveler_phone
        ,t1.mobile_area AS traveler_phone_area
        ,CASE 
            --香港、澳门、台湾
            WHEN t1.mobile_area IN (886,852,853) THEN 'CN'
            ELSE t4.alpha_2_code
        END AS traveler_phone_area_country_code 
        ,CASE 
            --香港、澳门、台湾
            WHEN t1.mobile_area IN (886,852,853) THEN '中国'
            ELSE t4.name_zh
        END AS traveler_phone_area_country_name

        ,t1.mobile_region AS traveler_phone_region

        ,t5.phone_province_code AS traveler_phone_province_code
        ,t5.phone_province_name AS traveler_phone_province_name
        ,t5.phone_city_code AS traveler_phone_city_code
        ,t5.phone_city_name AS traveler_phone_city_name
        ,t5.phone_district_code AS traveler_phone_district_code
        ,t5.phone_district_name AS traveler_phone_district_name

        ,CASE 
            WHEN t1.voucher_type IN (1,3,4,5,6,7,8,9,10) THEN '中国'
            WHEN t1.voucher_type IN (99) THEN '未知'
            WHEN t1.voucher_type IN (2) THEN '境外'
        ELSE '未知'
        END AS idcard_country_name
        ,t3.idcard_province_code
        ,t3.idcard_province_name
        ,t3.idcard_city_code
        ,t3.idcard_city_name
        ,t3.idcard_district_code
        ,t3.idcard_district_name

        ,CAST(GET_JSON_OBJECT(t2.ext_info,'$.age') AS INT) AS ext_age
        ,CAST(GET_JSON_OBJECT(t2.ext_info,'$.sex') AS INT) AS ext_sex
        ,GET_JSON_OBJECT(t2.ext_info,'$.area.region') AS ext_region_code
        ,GET_JSON_OBJECT(t2.ext_info,'$.area.country') AS ext_country_code
        ,GET_JSON_OBJECT(t2.ext_info,'$.area.province') AS ext_province_code
        ,GET_JSON_OBJECT(t2.ext_info,'$.area.provinceName') AS ext_province_name
        ,GET_JSON_OBJECT(t2.ext_info,'$.area.city') AS ext_city_code
        ,GET_JSON_OBJECT(t2.ext_info,'$.area.cityName') AS ext_city_name
        ,GET_JSON_OBJECT(t2.ext_info,'$.area.district') AS ext_district_code
        ,GET_JSON_OBJECT(t2.ext_info,'$.area.districtName') AS ext_district_name

        ,t2.ext_info
        ,t1.voucher_type
        ,t1.check_state
        ,t1.print_state
        ,t1.chk_code
        ,t1.is_checked
        ,t1.check_time
        ,t1.order_time
        ,CAST(DATE_FORMAT(TO_TIMESTAMP(t1.order_time), 'yyyyMMdd') AS int) AS order_date
        ,t1.update_time
        ,t1.sync_state
        ,t2.end_time
        ,t2.valid_num
        ,t2.take_way
        ,t1.order_date as travel_date

    FROM (
        SELECT 
            t1.id
            ,t1.orderid
            ,t1.idx
            ,t1.lid
            ,t1.apply_did
            ,t1.member_id
            ,t1.tourist
            ,t1.idcard
            ,t1.mobile
            ,t1.mobile_area
            ,t1.mobile_region
            ,t1.voucher_type
            ,t1.check_state
            ,t1.print_state
            ,t1.chk_code
            ,t1.is_checked
            ,t1.check_time
            ,t1.order_time
            ,t1.update_time
            ,t1.sync_state
            ,t1.order_date
        FROM ods_myuu_uu_order_tourist_info_f t1
        WHERE t1.order_date >= DATE_FORMAT(trunc(add_months('${today_date}', -2), 'MM'),'yyyyMMdd') 
        AND t1.apply_did = 38322930
    ) t1
    LEFT JOIN (
        SELECT 
            t1.orderid
            ,t1.idx
            ,t1.ext_info
            ,t1.end_time
            ,t1.valid_num
            ,t1.take_way
        FROM ods_myuu_uu_order_tourist_info_extend_f t1
        WHERE t1.order_date >= DATE_FORMAT(trunc(add_months('${today_date}', -2), 'MM'),'yyyyMMdd') 
        AND t1.apply_did = 38322930
    ) t2
    ON t1.orderid = t2.orderid
    AND t1.idx = t2.idx
    LEFT JOIN dim_common_idcard_area_df t3
    ON SUBSTR(t1.idcard,1,6) = t3.identity_code
    LEFT JOIN (
        SELECT phone_area_code,max(name_zh) AS  name_zh,max(alpha_2_code) AS  alpha_2_code
        FROM dim_common_phone_code_country_df
        group by phone_area_code
    ) t4
    ON t1.mobile_area = t4.phone_area_code
    LEFT JOIN dim_common_phone_prefix_area_df t5
    ON SUBSTR(t1.mobile, 1, 7) = t5.phone_prefix_number
)

)
,
order_track_table AS (
    SELECT id
        ,ordernum AS order_id
        ,idx
        ,track_action
        ,tid AS ticket_id
        ,apply_did
        ,tnum AS change_qty
        ,left_num AS remain_qty
        ,source
        ,terminal
        ,branch_terminal
        ,TO_TIMESTAMP(insert_time) AS insert_time
        ,oper_member
        ,NVL(msg, -2) AS msg
        ,ext_content
        ,CAST(GET_JSON_OBJECT(ext_content,'$.is_first_used') AS INT) AS is_first_used
        ,IF(msg LIKE '%过期%', 1, 0) AS is_overdue
        ,order_time
        ,update_time
        ,CAST(DATE_FORMAT(now(),'yyyyMMdd') AS INT) AS dwd_update_time
        ,CAST(FROM_UNIXTIME(insert_time,'yyyy-MM-dd') AS date) AS verify_date
    FROM ods_myuu_pft_order_tourist_track_di 
    where insertdate >= 20260827
    AND track_action IN (1,4)
    AND apply_did = 38322930
    -- and CAST(GET_JSON_OBJECT(ext_content,'$.is_first_used') AS INT) = 1
    AND IF(msg LIKE '%过期%', 1, 0) = 0
)
,last_month_order_track_table AS (
    SELECT DATE_FORMAT(CAST(FROM_UNIXTIME(insert_time,'yyyy-MM-dd') AS date),'yyyy-MM') AS last_verify_month
        ,count(*) AS month_verify_total_qty
    FROM ods_myuu_pft_order_tourist_track_di 
    where  insertdate >= DATE_FORMAT(trunc(add_months('${today_date}', -2), 'MM'),'yyyyMMdd') 
    AND insertdate < DATE_FORMAT(trunc(add_months('${today_date}', 1), 'MM'),'yyyyMMdd')
    AND track_action IN (1,4)
    AND apply_did = 38322930
    AND IF(msg LIKE '%过期%', 1, 0) = 0
    AND CAST(GET_JSON_OBJECT(ext_content,'$.is_first_used') AS INT) = 1
    GROUP BY DATE_FORMAT(CAST(FROM_UNIXTIME(insert_time,'yyyy-MM-dd') AS date),'yyyy-MM')
)
,
order_table AS (
    SELECT t1.id
        --============关联键==================
        ,t1.member AS member_id
        ,t1.ordernum AS order_id
        ,t1.remotenum AS remote_order_id
        ,t1.lid AS scenic_id
        ,t1.tid AS ticket_id
        ,t1.pid AS product_id
        ,t1.aid AS sup_id
        ,t1.salerid AS saler_id
        ,t1.apply_did
        --============关联维度==================
        ,t3.channel_class1_id  
        ,t3.channel_class1_name
        ,IF(
            t1.ordermode = 20
            ,NVL(CAST(t4.target_id AS INT),2000)
            ,t3.channel_class2_id  
        )  AS channel_class2_id
        ,IF(
            t1.ordermode = 20
            ,NVL(t4.channel_aggregation_name,'商家自研')
            ,t3.channel_class2_name
        ) AS channel_class2_name

        ,t1.ordername AS ticket_taker_name
        ,t1.ordertel AS ticket_taker_phone
        ,t1.personid AS ticket_taker_idcard
        ,t1.ordertime AS order_time
        ,TO_DATE(t1.ordertime) AS order_date
        ,IF(t1.pay_time != 0,TO_TIMESTAMP(t1.pay_time),NULL) AS pay_time 
        ,IF(t1.pay_time != 0,TO_DATE(t1.pay_time),NULL) AS pay_date
        -- 过期时间=有效期结束日期+1
        ,IF(t1.status = 2,DATE_ADD(TO_DATE(t1.endtime),1),NULL) AS expiration_date 
        ,t1.update_time
        ,t1.playtime AS play_time
        ,CAST(DATE_FORMAT(t1.playtime, 'yyyy-MM-dd') AS DATE) AS play_date
        ,t1.begintime AS begin_time
        ,t1.endtime AS end_time
        ,t1.ctime AS cancel_time
        ,t1.dtime AS verify_time
        ,t1.status AS order_status_code
        ,t1.pay_status AS order_pay_status
        ,t1.paymode AS pay_funding_type
        ,t1.ordermode AS order_channel
        ,t1.onsale AS use_coupon
        ,t1.code AS voucher_code
        ,t1.unionCheck AS non_refund_withdraw
        ,t1.visitors AS order_customer_type
        ,t1.product_type
        ,t1.sync_state
        ,t1.trade_order_id
        --============度量==================
        ,t1.tnum
        ,-- 年卡特权支付订单金额置零，金额为负数订单金额置零
        IF(
            t1.ordermode = 18 AND t1.paymode = 13, 
            0,
            IF(t1.tprice < 0, 0, t1.tprice)
        )  AS order_price
        -- 年卡特权支付订单金额置零，金额为负数订单金额置零
        ,IF(
            t1.ordermode = 18 AND t1.paymode = 13, 
            0,
            IF(t1.totalmoney < 0, 0, t1.totalmoney)
        ) AS original_order_amount --订单金额逻辑从dim_order 走
        ,CAST(DATE_FORMAT(now(),'yyyyMMdd') AS INT) AS dwd_update_time

        ,CAST(DATE_FORMAT(t1.ordertime, 'yyyyMMdd') AS INT) AS travel_date
    FROM ods_myuu_uu_ss_order_df t1
    LEFT JOIN dim_ord_enum_order_mode_f t3
    ON t1.ordermode = t3.channel_class2_id
    LEFT JOIN (
        SELECT user_id,MAX(channel_aggregation_name) AS channel_aggregation_name,MAX(target_id) AS target_id
        FROM (
            SELECT 
                member.user_id as user_id
                ,OTA.channel_aggregation_name
                ,OTA.target_id
            FROM
            (
                -- 商户回调地址
                SELECT user_id, dcode_url
                FROM dim_cus_member_info_df
                WHERE -- 供应商，分销商
                user_type IN (0, 1)
                -- 排除测试
                AND user_group_id != 2
            ) AS member 
            INNER JOIN 
            (
                SELECT loopback_address, channel_aggregation_name, target_id
                FROM dim_trf_ota_channel_f
                -- 通过回调地址确认
                WHERE rule_code = 1
            ) AS OTA 
            ON member.dcode_url RLIKE OTA.loopback_address
            UNION ALL
            SELECT 
                member_id AS user_id
                ,channel_aggregation_name
                ,target_id
            FROM 
            (
                SELECT member_id
                    ,channel_aggregation_name
                    ,target_id
                FROM dim_trf_ota_channel_f
                -- 通过member_id确认
                WHERE rule_code = 2
            )
        )
        GROUP BY user_id
    ) t4
    ON t1.member = t4.user_id
    WHERE t1.order_date >= DATE_FORMAT(trunc(add_months('${today_date}', -2), 'MM'),'yyyyMMdd') 
    AND t1.apply_did = 38322930
)
,
advance_booked_table AS (
    SELECT play_date
        ,sum(tnum) AS advance_book_qty
    FROM dwd_ord_order_details_di
    where travel_date >= DATE_FORMAT(trunc(add_months('${today_date}', -2), 'MM'),'yyyyMMdd') 
    AND apply_did = 38322930
    GROUP BY play_date
)
,
repeat_book_table AS (
    SELECT book_month
        ,COUNT(*) AS month_repeat_book_qty
    FROM (
        SELECT DATE_FORMAT(TO_DATE(travel_date,'yyyyMMdd'),'yyyy-MM') AS book_month
            ,md5(concat(NVL(traveler_idcard,'-'),'-',NVL(traveler_phone,'-')))
            , COUNT(DISTINCT order_id) as cnt
        FROM dwd_ord_traveler_booking_details_di t1
        where travel_date >= DATE_FORMAT(trunc(add_months('${today_date}', -2), 'MM'),'yyyyMMdd') 
        AND travel_date < DATE_FORMAT(trunc(add_months('${today_date}', 1), 'MM'),'yyyyMMdd')
        AND apply_did = 38322930
        AND (
            (traveler_idcard IS NOT NULL AND traveler_idcard <> '')
            OR 
            (traveler_phone IS NOT NULL AND traveler_phone <> '')
        )
        GROUP BY DATE_FORMAT(TO_DATE(travel_date,'yyyyMMdd'),'yyyy-MM'),md5(concat(NVL(traveler_idcard,'-'),'-',NVL(traveler_phone,'-')))
        HAVING COUNT(DISTINCT order_id) > 1
    )
    GROUP BY book_month
)
,repeat_track_table AS (
    SELECT verify_month
        ,COUNT(*) AS month_repeat_track_qty
    FROM (
        SELECT DATE_FORMAT(TO_DATE(t1.verify_date,'yyyyMMdd'),'yyyy-MM') AS verify_month
            ,md5(concat(NVL(t2.traveler_idcard,'-'),'-',NVL(t2.traveler_phone,'-')))
            ,COUNT(DISTINCT t1.order_id) as cnt
        FROM (
            SELECT ordernum as order_id,idx,CAST(FROM_UNIXTIME(insert_time,'yyyyMMdd') AS INT) AS verify_date
            FROM ods_myuu_pft_order_tourist_track_di 
            where  insertdate >= DATE_FORMAT(trunc(add_months('${today_date}', -2), 'MM'),'yyyyMMdd') 
            AND insertdate < DATE_FORMAT(trunc(add_months('${today_date}', 1), 'MM'),'yyyyMMdd')
            AND track_action IN (1,4)
            AND apply_did = 38322930
            AND IF(msg LIKE '%过期%', 1, 0) = 0
            AND CAST(GET_JSON_OBJECT(ext_content,'$.is_first_used') AS INT) = 1
        ) t1
        LEFT JOIN (
            SELECT order_id,idx,travel_date,traveler_idcard,traveler_phone,apply_did
            from dwd_ord_traveler_booking_details_di
            where travel_date >= DATE_FORMAT(trunc(add_months('${today_date}', -2), 'MM'),'yyyyMMdd') 
            AND travel_date < DATE_FORMAT(trunc(add_months('${today_date}', 1), 'MM'),'yyyyMMdd')
            AND apply_did = 38322930
            AND (
                (traveler_idcard IS NOT NULL AND traveler_idcard <> '')
                OR 
                (traveler_phone IS NOT NULL AND traveler_phone <> '')
            )
        ) t2
        ON t1.order_id = t2.order_id
        AND t1.idx = t2.idx
        GROUP BY DATE_FORMAT(TO_DATE(t1.verify_date,'yyyyMMdd'),'yyyy-MM'),md5(concat(NVL(t2.traveler_idcard,'-'),'-',NVL(t2.traveler_phone,'-')))
        HAVING COUNT(DISTINCT t1.order_id) > 1
    )
    GROUP BY verify_month
)


SELECT 
    t1.apply_did
    ,t1.verify_date AS travel_date
    ,t1.in_province_qty
    ,t1.out_province_qty
    ,t1.hmt_qty
    ,t1.foreign_qty
    ,t1.elderly_qty
    ,t1.children_qty
    ,t1.morning_exercise_qty
    ,t1.special_group_qty
    ,t1.online_booking_qty
    ,t1.onsite_booking_qty
    ,t1.in_park_qty
    ,t2.advance_book_qty
    ,nvl(t3.month_repeat_book_qty,0) AS month_repeat_book_qty
    ,nvl(t5.month_repeat_track_qty,0) AS month_repeat_track_qty
    ,nvl(t4.month_verify_total_qty,0) AS month_verify_total_qty
    ,CAST(DATE_FORMAT(t1.verify_date,'yyyyMMdd') AS INT) AS verify_date
FROM (
    SELECT apply_did
        ,verify_date
        --当前日期对应上月月份
        ,DATE_FORMAT(verify_date,'yyyy-MM') AS last_verify_month
        ,SUM(IF(is_first_used = 1 AND province_code = 610000, 1, 0)) AS in_province_qty
        ,SUM(IF(is_first_used = 1 AND country_name IN ('未知','中国','') AND province_code NOT IN (710000,820000,810000) AND province_code <> 610000, 1, 0)) AS out_province_qty
        ,SUM(IF(is_first_used = 1 AND province_code IN (710000,820000,810000), 1, 0)) AS hmt_qty
        ,SUM(IF(is_first_used = 1 AND country_name NOT IN ('未知','中国',''), 1, 0)) AS foreign_qty
        ,SUM(IF(is_first_used = 1 AND ext_age >= 65, 1, 0)) AS elderly_qty
        ,SUM(IF(is_first_used = 1 AND ext_age <= 6, 1, 0)) AS children_qty
        ,SUM(IF( ticket_id = 5373157, 1, 0)) AS morning_exercise_qty
        ,SUM(IF(is_first_used = 1 AND ticket_id = 5376735, 1, 0)) AS special_group_qty
        ,SUM(IF(is_first_used = 1 AND channel_class2_id = 2022, 1, 0)) AS online_booking_qty
        ,SUM(IF(is_first_used = 1 AND (channel_class2_id = 10 OR channel_class2_id = 3 OR channel_class2_id = 0), 1, 0)) AS onsite_booking_qty
        ,SUM(IF(is_first_used = 1 ,1,0)) AS in_park_qty

    FROM (
        SELECT 
            t1.order_id
            ,t1.idx
            ,t1.ticket_id
            ,t1.apply_did
            ,t1.change_qty
            ,t1.verify_date
            ,t1.is_first_used
            ,t3.play_date
            ,t3.order_date
            ,t3.scenic_id
            ,t3.channel_class1_id
            ,t3.channel_class1_name
            ,t3.channel_class2_id
            ,t3.channel_class2_name

            ,t2.member_id
            ,t2.traveler_name
            ,t2.traveler_idcard
            ,t2.traveler_phone
            ,t2.traveler_phone_area
            ,t2.traveler_phone_area_country_code 
            ,t2.traveler_phone_area_country_name
            ,t2.traveler_phone_region
        
            ,t2.country_name
            ,t2.province_code
            ,t2.province_name
            ,t2.city_code
            ,t2.city_name
            ,t2.district_code
            ,t2.district_name

            ,t2.ext_age
            ,t2.ext_sex
            ,t2.ext_region_code
            ,t2.ext_country_code

            ,t2.voucher_type
            ,t2.travel_date    

        FROM order_track_table t1
        LEFT JOIN order_booking_table t2
        ON t1.order_id = t2.order_id
        AND t1.idx = t2.idx
        LEFT JOIN order_table t3
        ON t1.order_id = t3.order_id
        WHERE t1.apply_did = 38322930
        AND t1.is_overdue = 0
    )
    GROUP BY apply_did,verify_date,DATE_FORMAT(verify_date,'yyyy-MM')
) t1
LEFT JOIN advance_booked_table t2
ON t1.verify_date = t2.play_date
LEFT JOIN repeat_book_table t3
ON t1.last_verify_month = t3.book_month
left JOIN last_month_order_track_table t4
ON t1.last_verify_month = t4.last_verify_month
LEFT JOIN repeat_track_table t5
ON t1.last_verify_month = t5.verify_month
;




