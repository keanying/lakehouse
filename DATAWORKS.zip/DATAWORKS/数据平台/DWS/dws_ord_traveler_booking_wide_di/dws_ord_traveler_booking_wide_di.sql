--Serverless Spark SQL
--********************************************************************--
--author: 韩瑞
--create time: 2026-07-14 14:44:51
--Serverless Spark SQL任务只能运行在独享资源组上
--********************************************************************--

-- DROP TABLE if exists dws_ord_traveler_booking_wide_di;
CREATE TABLE IF NOT exists dws_ord_traveler_booking_wide_di
(
    order_id                          STRING COMMENT '订单号ID'
    ,idx                              BIGINT COMMENT '订单序号'
    ,scenic_id                        INT COMMENT '景点ID'
    ,apply_did                        INT COMMENT '原始供应商ID'
    ,member_id                        BIGINT COMMENT '游客ID'
    ,channel_class1_id                INT COMMENT '渠道一级分类id'
    ,channel_class1_name              STRING COMMENT '渠道一级分类名称'
    ,channel_class2_id                INT COMMENT '渠道二级分类id(ordermode)'
    ,channel_class2_name              STRING COMMENT '渠道二级分类名称'
    ,order_time                       STRING COMMENT '下单时间'
    ,order_date                       DATE COMMENT '下单日期'
    ,order_status_code                INT COMMENT '订单状态：0=未使用,1=已使用,2=已过期,3=被取消,4=待确认(酒店)，待收货(特产),5=被终端修改,6=被终端撤销,7=部分使用,8=订单完结,9=被删除'
    ,order_pay_status                 INT COMMENT '支付方式:0=现场支付,1=已支付,2=未支付'
    ,pay_funding_type                 INT COMMENT '支付方式：0 = 余额支付,1 = 支付宝,2 = 授信支付,3 = 产品自销,4 = 现场支付,5 = 微信支付,6 = 会员卡支付,7 = 银联支付,8 = 环迅支付,9 = 现金支付,10 = 会员卡,11 = 拉卡拉（商户）,12 = 拉卡拉（平台）,13 = 特权支付（年卡）,14 = 微信（聚合）,15 = 平安银行,16 = 支付宝（聚合）,17 = 会员卡支付,18 = 计时卡支付,25 = 招行一网通支付,26 = 银联商务支付,27 = 银联商务POS支付,28 = 威富通支付,29 = 易宝云企付,33 = 博思支付,35 = 积分支付,36 = POS支'
    ,order_channel                    INT COMMENT '下单方式:0=正常分销商下单,1=普通用户支付,2=用户手机支付,3=会员卡购票,10=云票务,11=微信商城,12=自助机,13=二级店铺,14=闸机购票,15=智能终端,16=计调下单,17=淘宝码商,18=年卡,19=微信端,20=外部接口OTA下单,22=一卡通,23=套票子票'
    ,order_customer_type              INT COMMENT '订单客户类型：1=游客,2=分销商'
    ,product_type                     STRING COMMENT '商品类型'
    ,tnum                             BIGINT COMMENT '门票数量'
    ,order_price                      INT COMMENT '单价'
    ,original_order_amount            INT COMMENT '总的支付金额'
    ,supply_price                     BIGINT COMMENT '供应价'
    ,retail_price                     BIGINT COMMENT '零售价表'
    ,by_order_retail_price            BIGINT COMMENT '下单时的门市价'
    ,actual_selling_price             INT COMMENT '实际售价'
    ,origin_num                       BIGINT COMMENT '原始票数'
    ,current_total_num                SMALLINT COMMENT '记录当前总的票数'
    ,traveler_idcard                  STRING COMMENT '游客身份信息'
    ,traveler_name                    STRING COMMENT '游客姓名'
    ,traveler_phone                   STRING COMMENT '游客手机号'
    ,traveler_phone_area              STRING COMMENT '手机区号'
    ,traveler_phone_area_country_code STRING COMMENT '手机区号归属国家编码'
    ,traveler_phone_area_country_name STRING COMMENT '手机区号归属国家名称'
    ,traveler_phone_region            STRING COMMENT '手机区号的区域代码'
    ,traveler_phone_province_code     INT COMMENT '手机号归属省份编码'
    ,traveler_phone_province_name     STRING COMMENT '手机号归属省份名称'
    ,traveler_phone_city_code         INT COMMENT '手机号归属市编码'
    ,traveler_phone_city_name         STRING COMMENT '手机号归属市名称'
    ,traveler_phone_district_code     INT COMMENT '手机号归属区/县编码'
    ,traveler_phone_district_name     STRING COMMENT '手机号归属区/县名称'
    ,idcard_country_name              STRING COMMENT '证件归属国家名称'
    ,idcard_province_code             INT COMMENT '证件归属省份编码'
    ,idcard_province_name             STRING COMMENT '证件归属省份名称'
    ,idcard_city_code                 INT COMMENT '证件归属市编码'
    ,idcard_city_name                 STRING COMMENT '证件归属市名称'
    ,idcard_district_code             INT COMMENT '证件归属区/县编码'
    ,idcard_district_name             STRING COMMENT '证件归属区/县名称'
    ,country_name                     STRING COMMENT '归属国家名称'
    ,province_code                    INT COMMENT '归属省份编码'
    ,province_name                    STRING COMMENT '归属省份名称'
    ,city_code                        INT COMMENT '归属市编码'
    ,city_name                        STRING COMMENT '归属市名称'
    ,district_code                    INT COMMENT '归属区/县编码'
    ,district_name                    STRING COMMENT '归属区/县名称'
    ,ext_age                          INT COMMENT '年龄'
    ,ext_sex                          INT COMMENT '性别:0女;1男'
    ,ext_region_code                  STRING COMMENT '归属编码'
    ,ext_country_code                 STRING COMMENT '国家编码'
    ,ext_province_code                STRING COMMENT '归属省编码'
    ,ext_province_name                STRING COMMENT '归属省名称'
    ,ext_city_code                    STRING COMMENT '归属市编码'
    ,ext_city_name                    STRING COMMENT '归属市名称'
    ,ext_district_code                STRING COMMENT '归属区/县编码'
    ,ext_district_name                STRING COMMENT '归属区/县名称'
    ,voucher_type                     INT COMMENT '身份信息类型:0=未实名，没有身份信息 1=身份证,2=护照,3=军官证,4=回乡证,5=台胞证,6=外国人永久居留证,7=港澳通行证,8=台湾通行证,9=港澳居民居住证,10=台湾居民居住证,99=其他'
)
COMMENT '游客预定主题明细宽表'
PARTITIONED BY 
(
    travel_date            INT COMMENT '下单日期[yyyyMMdd]'
)
STORED AS ORC
;


WITH update_order_date AS (
    SELECT order_date
    FROM (
        SELECT date_value as order_date FROM dim_src_table_increment_info_di 
        WHERE table_name = 'dwd_ord_traveler_booking_details_di' AND update_date = ${yesterday}
    )
    GROUP BY order_date
)

INSERT OVERWRITE TABLE dws_ord_traveler_booking_wide_di PARTITION(travel_date)
SELECT 
     t1.order_id                                                --订单号ID
    ,t1.idx                                                     --订单序号
    ,t1.scenic_id                                               --景点ID
    ,t1.apply_did                                               --原始供应商ID
    ,t1.member_id                                               --游客ID
    -- 订单信息
    ,t2.channel_class1_id                                       --渠道一级分类id
    ,t2.channel_class1_name                                     --渠道一级分类名称
    ,t2.channel_class2_id                                       --渠道二级分类id(ordermode)
    ,t2.channel_class2_name                                     --渠道二级分类名称
    ,t2.order_time                                              --下单时间
    ,t2.order_date                                              --下单日期
    ,t2.order_status_code                                       --订单状态
    ,t2.order_pay_status                                        --支付状态
    ,t2.pay_funding_type                                        --支付方式
    ,t2.order_channel                                           --订单渠道
    ,t2.order_customer_type                                     --订单客户类型：1=游客,2=分销商
    ,t2.product_type                                            --商品类型
    ,t2.tnum                                                    --门票数量
    ,t2.order_price                                             --单价
    ,t2.original_order_amount                                   --总的支付金额
    ,t2.supply_price                                            --供应价
    ,t2.retail_price                                            --零售价表
    ,t2.by_order_retail_price                                   --下单时的门市价
    ,t2.actual_selling_price                                    --实际售价
    ,t2.origin_num                                              --原始票数
    ,t2.current_total_num                                       --记录当前总的票数

    --预定信息
    ,t1.traveler_idcard                                         --游客身份信息
    ,t1.traveler_name                                           --游客姓名
    ,t1.traveler_phone                                          --游客手机号
    ,t1.traveler_phone_area                                     --手机区号
    ,t1.traveler_phone_area_country_code                        --手机区号归属国家编码
    ,t1.traveler_phone_area_country_name                        --手机区号归属国家名称
    ,t1.traveler_phone_region                                   --手机区号的区域代码

    ,t1.traveler_phone_province_code                            --手机号归属省份编码
    ,t1.traveler_phone_province_name                            --手机号归属省份名称
    ,t1.traveler_phone_city_code                                --手机号归属市编码
    ,t1.traveler_phone_city_name                                --手机号归属市名称
    ,t1.traveler_phone_district_code                            --手机号归属区/县编码
    ,t1.traveler_phone_district_name                            --手机号归属区/县名称
    ,t1.idcard_country_name                                     --证件归属国家名称

    ,t1.idcard_province_code                                    --证件归属省份编码
    ,t1.idcard_province_name                                    --证件归属省份名称
    ,t1.idcard_city_code                                        --证件归属市编码
    ,t1.idcard_city_name                                        --证件归属市名称
    ,t1.idcard_district_code                                    --证件归属区/县编码
    ,t1.idcard_district_name                                    --证件归属区/县名称

    ,t1.country_name                                            --归属国家名称'
    ,t1.province_code                                           --归属省份编码'
    ,t1.province_name                                           --归属省份名称'
    ,t1.city_code                                               --归属市编码'
    ,t1.city_name                                               --归属市名称'
    ,t1.district_code                                           --归属区/县编码'
    ,t1.district_name                                           --归属区/县名称'

    ,t1.ext_age                                                 --年龄
    ,t1.ext_sex                                                 --性别:0女;1男
    ,t1.ext_region_code                                         --归属编码
    ,t1.ext_country_code                                        --国家编码
    ,t1.ext_province_code                                       --归属省编码
    ,t1.ext_province_name                                       --归属省名称
    ,t1.ext_city_code                                           --归属市编码
    ,t1.ext_city_name                                           --归属市名称
    ,t1.ext_district_code                                       --归属区/县编码
    ,t1.ext_district_name                                       --归属区/县名称
    ,t1.voucher_type                                            --身份信息类型
    ,t1.travel_date

FROM (
    SELECT /*+ BROADCAST(t2) */ 
        t1.order_id
        ,t1.idx
        ,t1.scenic_id
        ,t1.apply_did
        ,t1.member_id
        ,t1.traveler_idcard
        ,t1.traveler_name
        ,t1.traveler_phone
        ,t1.traveler_phone_area
        ,t1.traveler_phone_area_country_code
        ,t1.traveler_phone_area_country_name
        ,t1.traveler_phone_region
        ,t1.traveler_phone_province_code
        ,t1.traveler_phone_province_name
        ,t1.traveler_phone_city_code
        ,t1.traveler_phone_city_name
        ,t1.traveler_phone_district_code
        ,t1.traveler_phone_district_name
        ,t1.idcard_country_name
        ,t1.idcard_province_code
        ,t1.idcard_province_name
        ,t1.idcard_city_code
        ,t1.idcard_city_name
        ,t1.idcard_district_code
        ,t1.idcard_district_name
        ,t1.country_name
        ,t1.province_code
        ,t1.province_name
        ,t1.city_code
        ,t1.city_name
        ,t1.district_code
        ,t1.district_name
        ,t1.ext_age
        ,t1.ext_sex
        ,t1.ext_region_code
        ,t1.ext_country_code
        ,t1.ext_province_code
        ,t1.ext_province_name
        ,t1.ext_city_code
        ,t1.ext_city_name
        ,t1.ext_district_code
        ,t1.ext_district_name
        ,t1.voucher_type
        ,t1.travel_date
    FROM dwd_ord_traveler_booking_details_di t1
    LEFT SEMI JOIN update_order_date t2
    ON t1.travel_date = t2.order_date
) t1
LEFT JOIN (

    SELECT /*+ BROADCAST(t2) */ 
        t1.order_id
        ,t1.travel_date
        ,t1.channel_class1_id
        ,t1.channel_class1_name
        ,t1.channel_class2_id
        ,t1.channel_class2_name
        ,t1.order_time
        ,t1.order_date
        ,t1.order_status_code
        ,t1.order_pay_status
        ,t1.pay_funding_type
        ,t1.order_channel
        ,t1.order_customer_type
        ,t1.product_type
        ,t1.tnum
        ,t1.order_price
        ,t1.original_order_amount
        ,t1.supply_price
        ,t1.retail_price
        ,t1.by_order_retail_price
        ,t1.actual_selling_price
        ,t1.origin_num
        ,t1.current_total_num
    FROM dwd_ord_order_details_di t1
    LEFT SEMI JOIN update_order_date t2
    ON t1.travel_date = t2.order_date
) t2
ON t1.order_id = t2.order_id
AND t1.travel_date = t2.travel_date
;











