--Serverless Spark SQL
--********************************************************************--
--author: 韩瑞
--create time: 2026-11-17 17:14:32
--Serverless Spark SQL任务只能运行在独享资源组上
--********************************************************************--
-- ============================================================================
-- 景点门票价格拉链表（SCD Type 2）—— v4: 增量追加 + 全量区间去重整理
-- 维度: (scenic_id, ticket_id)
-- 源表: dws_ord_traveler_booking_wide_di (宽表, 主表)
--       dwd_ord_order_details_di         (订单状态表, 提供 ticket_id / 票级价格)
--
-- 架构 (比 v3 的"受影响组合重算"简单得多):
--   Step 1  增量写入  : 把增量窗口内的"每日价格行"直接 INSERT INTO 追加进表,
--                       start_date = end_date = order_date, 不做任何压缩/开链
--   Step 2  全量整理  : 一次 INSERT OVERWRITE 完成全部复杂逻辑:
--                       A. 按 (scenic_id, ticket_id, start_date) 去重, 同日取最新写入
--                       B. LAG(price) 剔除同价相邻行 —— 自动压缩 + 消除窗口重叠冗余
--                       C. LEAD(start_date) 重算 end_date / prev_change_date / is_current
--   每次调度 = Step 1 + Step 2 两段, 无受影响组合识别 / 无旧链展开 / 无三路合并
--
-- 正确性前提: 源表回刷只发生在增量窗口内 (窗口回看 N 天即可覆盖晚到数据)
-- ============================================================================


-- ============================================================================
-- 1. 拉链表 DDL (比 v3 多一个 etl_ts 用于去重判新旧)
-- ============================================================================
drop table dws_scenic_ticket_price_zipper_di;
CREATE TABLE IF NOT EXISTS dws_scenic_ticket_price_zipper_di
(
    scenic_id        INT     COMMENT '景点ID',
    ticket_id        INT     COMMENT '门票ID',
    price            INT     COMMENT '该区间生效价格',
    start_date       DATE    COMMENT '生效开始日期(即调价日)',
    end_date         DATE    COMMENT '生效结束日期(下一调价日前一天); 9999-12-31 表示当前生效',
    prev_change_date DATE    COMMENT '上一次调价日期; 首次开链为 NULL',
    is_current       TINYINT COMMENT '是否当前生效: 1=是, 0=否',
    etl_ts           BIGINT  COMMENT '写入批次时间戳, 用于同日多版本去重'
)
COMMENT '景点门票价格拉链表(景区+票维度)'
STORED AS ORC;

-- ============================================================================
-- 2. 首次初始化 (全量压缩写链, 只跑一次)
--    与日常增量不同: 初始历史太长, 逐日写每日行体积不可控, 故一次压成链
--    整理步骤(第4节)对"链"和"每日行"两种形态都兼容
-- ============================================================================
INSERT INTO dws_scenic_ticket_price_zipper_di
SELECT
    scenic_id,
    ticket_id,
    price,
    start_date,
    COALESCE(DATE_SUB(next_start, 1), DATE '9999-12-31') AS end_date,
    prev_start                                   AS prev_change_date,
    CASE WHEN next_start IS NULL THEN 1 ELSE 0 END AS is_current,
    unix_timestamp()                             AS etl_ts
FROM
(
    SELECT scenic_id, ticket_id, price, start_date,
           LEAD(start_date) OVER (PARTITION BY scenic_id, ticket_id ORDER BY start_date) AS next_start,
           LAG(start_date)  OVER (PARTITION BY scenic_id, ticket_id ORDER BY start_date) AS prev_start
    FROM
    (
        SELECT scenic_id, ticket_id, price, order_date AS start_date
        FROM
        (
            SELECT scenic_id, ticket_id, order_date, price,
                   LAG(price) OVER (PARTITION BY scenic_id, ticket_id ORDER BY order_date) AS prev_price
            FROM
            (
                SELECT
                    t1.scenic_id,
                    t2.ticket_id,
                    t1.order_date,
                    MIN(t2.order_price) AS price
                FROM dws_ord_traveler_booking_wide_di t1
                JOIN dwd_ord_order_details_di t2
                  ON t1.order_id    = t2.order_id
                 AND t1.travel_date = t2.travel_date
                 AND t1.scenic_id   = t2.scenic_id
                WHERE t1.travel_date >= 20250101
                    and t2.travel_date >= 20250101
                  AND t1.order_status_code NOT IN (3, 6, 9)
                  AND t2.order_price > 0
                  AND t2.ticket_id IS NOT NULL
                  AND t1.order_date IS NOT NULL
                GROUP BY t1.scenic_id, t2.ticket_id, t1.order_date
            ) a
        ) b
        WHERE prev_price IS NULL OR price <> prev_price
    ) c
) d;


-- -- ============================================================================
-- -- 3. 日常调度 Step 1: 增量写入 (只扫增量分区, 直接追加, 零窗口逻辑)
-- --    示例增量窗口: [2026-11-10, 2026-11-17], 建议回看 3~7 天留重叠
-- -- ============================================================================
-- INSERT INTO dws_scenic_ticket_price_zipper_di
-- SELECT
--     t1.scenic_id,
--     t2.ticket_id,
--     MIN(t2.order_price)      AS price,
--     t1.order_date            AS start_date,   -- 每日行: start = end = order_date
--     t1.order_date            AS end_date,
--     CAST(NULL AS DATE)       AS prev_change_date,
--     0                        AS is_current,   -- 待整理步骤统一重算
--     unix_timestamp()         AS etl_ts
-- FROM dws_ord_traveler_booking_wide_di t1
-- JOIN dwd_ord_order_details_di t2
--   ON t1.order_id    = t2.order_id
--  AND t1.travel_date = t2.travel_date
--  AND t1.scenic_id   = t2.scenic_id
-- WHERE t1.travel_date >= ${last_7_day}            -- p_delta_start, 分区裁剪!
--   AND t1.travel_date <= ${today}            -- p_delta_end
--   AND t1.order_status_code NOT IN (3, 6, 9)
--   AND t2.order_price > 0
--   AND t2.ticket_id IS NOT NULL
--   AND t1.order_date IS NOT NULL
-- GROUP BY t1.scenic_id, t2.ticket_id, t1.order_date;


-- -- ============================================================================
-- -- 4. 日常调度 Step 2: 全量时间区间去重整理 (三层窗口, 先落临时表再回写,
-- --    避免 Spark 同表 OVERWRITE 读写自身的快照风险)
-- -- ============================================================================
-- DROP TABLE IF EXISTS tmp_scenic_ticket_price_zipper;

-- CREATE TABLE tmp_scenic_ticket_price_zipper AS
-- SELECT
--     scenic_id,
--     ticket_id,
--     price,
--     start_date,
--     COALESCE(DATE_SUB(next_start, 1), DATE '9999-12-31') AS end_date,
--     prev_start AS prev_change_date,
--     CASE WHEN next_start IS NULL THEN 1 ELSE 0 END AS is_current,
--     etl_ts
-- FROM
-- (
--     -- C. 对"真正变化点"重算区间: LEAD -> end_date, LAG -> prev_change_date
--     SELECT scenic_id, ticket_id, price, start_date, etl_ts,
--            LEAD(start_date) OVER (PARTITION BY scenic_id, ticket_id ORDER BY start_date) AS next_start,
--            LAG(start_date)  OVER (PARTITION BY scenic_id, ticket_id ORDER BY start_date) AS prev_start
--     FROM
--     (
--         -- B. 剔除同价相邻行: 自动压缩每日行 + 消除窗口重叠产生的重复
--         --    (11-10 80 / 11-11 80 / 11-12 90 -> 只留 11-10 和 11-12)
--         SELECT scenic_id, ticket_id, start_date, price, etl_ts,
--                LAG(price) OVER (PARTITION BY scenic_id, ticket_id ORDER BY start_date) AS prev_price
--         FROM
--         (
--             -- A. 区间去重: 同一 start_date 有多个版本(旧链首 vs 新每日行/多次回刷)取最新写入
--             SELECT scenic_id, ticket_id, start_date, price, etl_ts,
--                    ROW_NUMBER() OVER (PARTITION BY scenic_id, ticket_id, start_date
--                                       ORDER BY etl_ts DESC) AS rn
--             FROM dws_scenic_ticket_price_zipper_di
--         ) x
--         WHERE rn = 1
--     ) y
--     WHERE prev_price IS NULL OR price <> prev_price
-- ) z;

-- INSERT OVERWRITE TABLE dws_scenic_ticket_price_zipper_di
-- SELECT scenic_id, ticket_id, price, start_date, end_date, prev_change_date, is_current, etl_ts
-- FROM tmp_scenic_ticket_price_zipper;

-- DROP TABLE IF EXISTS tmp_scenic_ticket_price_zipper;



