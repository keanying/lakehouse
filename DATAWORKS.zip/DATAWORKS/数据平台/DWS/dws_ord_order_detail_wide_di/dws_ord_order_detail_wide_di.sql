--Serverless Spark SQL
--********************************************************************--
--author: 韩瑞
--create time: 2026-07-20 17:52:04
--Serverless Spark SQL任务只能运行在独享资源组上
--********************************************************************--

-- DROP TABLE IF EXISTS dws_ord_order_detail_wide_di;
CREATE TABLE IF NOT EXISTS dws_ord_order_detail_wide_di
(
    member_id                          INT COMMENT '购买者ID'
    ,order_id                          STRING COMMENT '订单号'
    ,remote_order_id                   STRING COMMENT '远端订单号'
    ,scenic_id                         INT COMMENT '景区id'
    ,ticket_id                         INT COMMENT '门票id'
    ,product_id                        INT COMMENT '产品id'
    ,sup_id                            INT COMMENT '供应商ID'
    ,saler_id                          INT COMMENT '商家ID'
    ,apply_did                         INT COMMENT '原始供应商ID'
    ,order_time                        STRING COMMENT '下单时间'
    ,order_date                        DATE COMMENT '下单日期'
    ,pay_time                          TIMESTAMP COMMENT '订单支付时间'
    ,expiration_date                   DATE COMMENT '订单过期日期'
    ,pay_date                          DATE COMMENT '订单支付日期'
    ,update_time                       INT COMMENT '订单更新时间'
    ,play_time                         TIMESTAMP COMMENT '预计游玩时间'
    ,play_date                         DATE COMMENT '预计游玩日期'
    ,begin_time                        TIMESTAMP COMMENT '开始时间'
    ,end_time                          TIMESTAMP COMMENT '结束时间'
    ,cancel_time                       STRING COMMENT '取消时间'
    ,verify_time                       STRING COMMENT '验证时间'
    ,voucher_code                      BIGINT COMMENT '凭证码'
    ,trade_order_id                    STRING COMMENT '交易订单号'
    ,ticket_taker_name                 STRING COMMENT '取票人姓名'
    ,ticket_taker_phone                STRING COMMENT '取票人电话'
    ,ticket_taker_idcard               STRING COMMENT '取票人身份信息'
    ,order_status_code                 INT COMMENT '订单状态：0=未使用,1=已使用,2=已过期,3=被取消,4=待确认(酒店)，待收货(特产),5=被终端修改,6=被终端撤销,7=部分使用,8=订单完结,9=被删除'
    ,order_pay_status                  INT COMMENT '支付方式:0=现场支付,1=已支付,2=未支付'
    ,pay_funding_type                  INT COMMENT '支付方式：0 = 余额支付,1 = 支付宝,2 = 授信支付,3 = 产品自销,4 = 现场支付,5 = 微信支付,6 = 会员卡支付,7 = 银联支付,8 = 环迅支付,9 = 现金支付,10 = 会员卡,11 = 拉卡拉（商户）,12 = 拉卡拉（平台）,13 = 特权支付（年卡）,14 = 微信（聚合）,15 = 平安银行,16 = 支付宝（聚合）,17 = 会员卡支付,18 = 计时卡支付,25 = 招行一网通支付,26 = 银联商务支付,27 = 银联商务POS支付,28 = 威富通支付,29 = 易宝云企付,33 = 博思支付,35 = 积分支付,36 = POS支'
    ,use_coupon                        INT COMMENT '0正常1使用优惠价支付2修改过的订单'
    ,non_refund_withdraw               INT COMMENT '提现类型：0=正常订单，1=不可退而且可提现的订单，2=独立收款'
    ,order_customer_type               INT COMMENT '订单客户类型：1=游客,2=分销商'
    ,ticket_name                       STRING COMMENT '票名称'
    ,ticket_fullname                   STRING COMMENT '票全称=景区名称+“-”+票名称'
    ,ticket_status_code                INT COMMENT '票状态编码[1上架, 2下架, 6删除]'
    ,is_package_ticket                 INT COMMENT '是否组合套票[1:是,0:否]'
    ,ticket_package_type               INT COMMENT '组合类型[0:单票,1:套票中的主票,2:套票中的子票,3:1+2情况]'
    ,ticket_max_expiration_date        STRING COMMENT '票最大过期日期'
    ,scenic_name                       STRING COMMENT '景区名称'
    ,scenic_status_code                INT COMMENT '景区状态编码[1:上架,2:下架,3:删除,4:新增]'
    ,scenic_publisher_id               INT COMMENT '景区发布商ID'
    ,scenic_publisher_name             STRING COMMENT '景区发布商账户名称'
    ,scenic_type_code                  STRING COMMENT '景区类型编码[A:景区,B:线路,C:酒店,F:套票,G:餐饮,H:演出,I:年卡,J:特产,K:计时产品]'
    ,scenic_type_name                  STRING COMMENT '景区类型'
    ,scenic_level_code                 STRING COMMENT '景区级别编码'
    ,scenic_level                      STRING COMMENT '景区级别'
    ,scenic_topic                      STRING COMMENT '主题列表第一个主题'
    ,scenic_topics                     STRING COMMENT '主题列表'
    ,order_type                        STRING COMMENT '订单类型'
    ,is_team_order                     INT COMMENT '是否团单'
    ,is_split_order                    INT COMMENT '是否分销单'
    ,split_buyer_id                    INT COMMENT '购买用户ID'
    ,split_buyer_company_type          INT COMMENT '购买者公司类型'
    ,split_buyer_business_type         INT COMMENT '购买者业态'
    ,split_buyer_account_group         INT COMMENT '购买者账户分组'
    ,split_seller_id                   INT COMMENT '售卖用户ID'
    ,split_seller_company_type         INT COMMENT '销售者公司类型'
    ,split_seller_business_type        INT COMMENT '销售者业态'
    ,split_current_distributor_level   INT COMMENT '本层具体分销层级: [1-5]'
    ,pack_sup_id                       INT COMMENT '主票供应商ID'
    ,pack_scenic_id                    INT COMMENT '主票景区id'
    ,pack_ticket_id                    INT COMMENT '主票门票id'
    ,pack_product_id                   INT COMMENT '主票产品id'
    ,pack_product_type                 STRING COMMENT '主票商品类型'
    ,team_order_id                     STRING COMMENT '团单订单号'
    ,order_channel                     INT COMMENT '下单方式:0=正常分销商下单,1=普通用户支付,2=用户手机支付,3=会员卡购票,10=云票务,11=微信商城,12=自助机,13=二级店铺,14=闸机购票,15=智能终端,16=计调下单,17=淘宝码商,18=年卡,19=微信端,20=外部接口OTA下单,22=一卡通,23=套票子票'
    ,product_type                      STRING COMMENT '商品类型'
    ,channel_class1_id                 INT COMMENT '渠道一级分类id'
    ,channel_class1_name               STRING COMMENT '渠道一级分类名称'
    ,channel_class2_id                 INT COMMENT '渠道二级分类id(ordermode)'
    ,channel_class2_name               STRING COMMENT '渠道二级分类名称'
    ,ticket_taker_phone_province_code  INT COMMENT '取票人电话号段归属省份编码'
    ,ticket_taker_phone_province_name  STRING COMMENT '取票人电话号段归属省份名称'
    ,ticket_taker_phone_city_code      INT COMMENT '取票人电话号段归属市编码'
    ,ticket_taker_phone_city_name      STRING COMMENT '取票人电话号段归属市名称'
    ,ticket_taker_idcard_province_code INT COMMENT '取票人身份证件归属省份编码'
    ,ticket_taker_idcard_province_name STRING COMMENT '取票人身份证件归属省份名称'
    ,ticket_taker_idcard_city_code     INT COMMENT '取票人身份证件归属市编码'
    ,ticket_taker_idcard_city_name     STRING COMMENT '取票人身份证件归属市名称'
    ,ticket_taker_idcard_district_code INT COMMENT '取票人身份证件归属区/县编码'
    ,ticket_taker_idcard_district_name STRING COMMENT '取票人身份证件归属区/县名称'
    ,tnum                              BIGINT COMMENT '门票数量'
    ,origin_num                        BIGINT COMMENT '原始票数'
    ,current_total_num                 SMALLINT COMMENT '记录当前总的票数'
    ,refund_num                        BIGINT COMMENT '退票数'
    ,verified_num                      BIGINT COMMENT '已验证票数'
    ,can_take_num                      SMALLINT COMMENT '可取票数'
    ,can_refund_num                    SMALLINT COMMENT '可退票数'
    -- ,booking_ticket_num                BIGINT COMMENT '预定票数'
    -- ,pay_ticket_num                    BIGINT COMMENT '支付票数'
    -- ,cancel_ticket_num                 BIGINT COMMENT '退票数'
    -- ,verify_ticket_num                 BIGINT COMMENT '验证票数'
    -- ,revoke_ticket_num                 BIGINT COMMENT '撤改/撤销票数'
    -- ,take_ticket_num                   BIGINT COMMENT '取票数'
    -- ,after_sale_ticket_num             BIGINT COMMENT '售后票数'
    -- ,finish_ticket_num                 BIGINT COMMENT '完结票数'
    ,order_price                       INT COMMENT '单价'
    ,original_order_amount             INT COMMENT '总的支付金额'
    ,supply_price                      BIGINT COMMENT '供应价'
    ,retail_price                      BIGINT COMMENT '零售价表'
    ,by_order_retail_price             BIGINT COMMENT '下单时的门市价'
    ,actual_selling_price              INT COMMENT '实际售价'
    ,cost_money                        BIGINT COMMENT '成本价（分为单位）'
    ,sale_money                        BIGINT COMMENT '销售价（分为单位）'
    ,ticket_tprice                     STRING COMMENT '市场价'
)
COMMENT '订单主题明细宽表'
PARTITIONED BY 
(
    travel_date            INT COMMENT '下单日期[yyyyMMdd]'
)
STORED AS ORC
;


WITH update_order_date AS (
    SELECT order_date
    FROM (
        SELECT date_value as order_date FROM dim_src_table_increment_info_di 
        WHERE table_name = 'dwd_ord_order_details_di' AND update_date = ${yesterday}
    )
    GROUP BY order_date
)



INSERT OVERWRITE TABLE dws_ord_order_detail_wide_di PARTITION(travel_date)
SELECT /*+ MERGEJOIN(t5, t6) */
    --===============外部连接键===============
     t1.member_id                                                   --购买者ID 
    ,t1.order_id                                                    --订单号 
    ,t1.remote_order_id                                             --远端订单号 
    ,t1.scenic_id                                                   --景区id 
    ,t1.ticket_id                                                   --门票id 
    ,t1.product_id                                                  --产品id 
    ,t1.sup_id                                                      --供应商ID 
    ,t1.saler_id                                                    --商家ID 
    ,t1.apply_did                                                   --原始供应商ID   

    --===============订单基础信息=================
    ,t1.order_time                                                  --下单时间
    ,t1.order_date                                                  --下单日期
    ,t1.pay_time                                                    --订单支付时间
    ,t1.expiration_date                                             --订单过期日期
    ,t1.pay_date                                                    --订单支付日期
    ,t1.update_time                                                 --订单更新时间
    ,t1.play_time                                                   --预计游玩时间
    ,t1.play_date                                                   --预计游玩日期
    ,t1.begin_time                                                  --开始时间
    ,t1.end_time                                                    --结束时间
    ,t1.cancel_time                                                 --取消时间
    ,t1.verify_time                                                 --验证时间
    ,t1.voucher_code                                                --凭证码
    ,t1.trade_order_id                                              --交易订单号
    ,t1.ticket_taker_name                                           --取票人姓名
    ,t1.ticket_taker_phone                                          --取票人电话
    ,t1.ticket_taker_idcard                                         --取票人身份信息
    ,t1.order_status_code                                           --订单状态
    ,t1.order_pay_status                                            --支付状态
    ,t1.pay_funding_type                                            --支付方式
    ,t1.use_coupon                                                  --用券情况:0正常1使用优惠价支付2修改过的订单
    ,t1.non_refund_withdraw                                         --提现类型
    ,t1.order_customer_type                                         --订单客户类型

    --===============维度信息=================

    ,t6.ticket_name                                                 --票名称
    ,t6.ticket_fullname                                             --票全称=景区名称+“-”+票名称
    ,t6.ticket_status_code                                          --票状态编码[1上架, 2下架, 6删除]
    ,t6.is_package_ticket                                           --是否组合套票[1:是,0:否]
    ,t6.ticket_package_type                                         --组合类型[0:单票,1:套票中的主票,2:套票中的子票,3:1+2情况]
    ,t6.ticket_max_expiration_date                                  --票最大过期日期

    ,t5.scenic_name                                                 --景区名称
    ,t5.scenic_status_code                                          --景区状态编码[1:上架,2:下架,3:删除,4:新增]
    ,t5.scenic_publisher_id                                         --景区发布商ID
    ,t5.scenic_publisher_name                                       --景区发布商账户名称
    ,t5.scenic_type_code                                            --景区类型编码[A:景区,B:线路,C:酒店,F:套票,G:餐饮,H:演出,I:年卡,J:特产,K:计时产品]
    ,t5.scenic_type_name                                            --景区类型
    ,t5.scenic_level_code                                           --景区级别编码
    ,t5.scenic_level                                                --景区级别
    ,t5.scenic_topic                                                --主题列表第一个主题      
    ,t5.scenic_topics                                               --主题列表
    ,CASE
        WHEN t2.ifpack = 0 THEN '套票-单票'
        WHEN t2.ifpack = 1 THEN '套票-主票'
        WHEN t2.ifpack = 2 THEN '套票-子票'
    ELSE '单票'
    END AS order_type                                               --订单类型
    ,IF(t3.sub_order_id IS NOT NULL, 1, 0 ) AS is_team_order        --是否团单
    ,IF(t4.order_id IS NOT NULL, 1, 0 ) AS is_split_order           --是否分销单

    ,t4.buyer_id                            AS split_buyer_id                                                --一级分销-购买用户ID
    ,t4.buyer_company_type                  AS split_buyer_company_type                                      --一级分销-购买者公司类型
    ,t4.buyer_business_type                 AS split_buyer_business_type                                     --一级分销-购买者业态
    ,t4.buyer_account_group                 AS split_buyer_account_group                                     --一级分销-购买者账户分组
    ,t4.seller_id                           AS split_seller_id                                               --一级分销-售卖用户ID
    ,t4.seller_company_type                 AS split_seller_company_type                                     --一级分销-销售者公司类型
    ,t4.seller_business_type                AS split_seller_business_type                                    --一级分销-销售者业态
    ,t4.current_distributor_level           AS split_current_distributor_level                               --一级分销-本层具体分销层级: [1-5]


    --套票主票信息
    ,t2.pack_sup_id                                                 --套票主票供应商ID      
    ,t2.pack_scenic_id                                              --套票主票景区id      
    ,t2.pack_ticket_id                                              --套票主票门票id      
    ,t2.pack_product_id                                             --套票主票产品id      
    ,t2.pack_product_type                                           --套票主票商品类型  

    ,t3.master_order_id AS team_order_id                            --团队订单号

    ,t1.order_channel                                               --订单渠道    
    ,t1.product_type                                                --商品类型            
    ,t1.channel_class1_id                                           --渠道一级分类id        
    ,t1.channel_class1_name                                         --渠道一级分类名称            
    ,t1.channel_class2_id                                           --渠道二级分类id(ordermode)        
    ,t1.channel_class2_name                                         --渠道二级分类名称        
    ,t1.ticket_taker_phone_province_code                            --取票人电话号段归属省份编码                        
    ,t1.ticket_taker_phone_province_name                            --取票人电话号段归属省份名称                    
    ,t1.ticket_taker_phone_city_code                                --取票人电话号段归属市编码                    
    ,t1.ticket_taker_phone_city_name                                --取票人电话号段归属市名称                    
    ,t1.ticket_taker_idcard_province_code                           --取票人身份证件归属省份编码                
    ,t1.ticket_taker_idcard_province_name                           --取票人身份证件归属省份名称                    
    ,t1.ticket_taker_idcard_city_code                               --取票人身份证件归属市编码                
    ,t1.ticket_taker_idcard_city_name                               --取票人身份证件归属市名称                
    ,t1.ticket_taker_idcard_district_code                           --取票人身份证件归属区/县编码                
    ,t1.ticket_taker_idcard_district_name                           --取票人身份证件归属区/县名称                

    --===============度量值===================
    -- 票数
    ,t1.tnum                                                        --门票数量   
    ,t1.origin_num                                                  --原始票数           
    ,t1.current_total_num                                           --记录当前总的票数           
    ,t1.refund_num                                                  --退票数               
    ,t1.verified_num                                                --已验证票数                   
    ,t1.can_take_num                                                --可取票数               
    ,t1.can_refund_num                                              --可退票数     

    -- ,t7.booking_ticket_num                                          --预定票数
    -- ,t7.pay_ticket_num                                              --支付票数
    -- ,t7.cancel_ticket_num                                           --退票数
    -- ,t7.verify_ticket_num                                           --验证票数
    -- ,t7.revoke_ticket_num                                           --撤改/撤销票数
    -- ,t7.take_ticket_num                                             --取票数
    -- ,t7.after_sale_ticket_num                                       --售后票数
    -- ,t7.finish_ticket_num                                           --完结票数

    --金额
    ,t1.order_price                                                 --单价
    ,t1.original_order_amount                                       --总的支付金额
    ,t1.supply_price                                                --供应价
    ,t1.retail_price                                                --零售价表
    ,t1.by_order_retail_price                                       --下单时的门市价
    ,t1.actual_selling_price                                        --实际售价
    ,t4.cost_money                                                  --一级分销成本价（分为单位）
    ,t4.sale_money                                                  --一级分销销售价（分为单位）
    ,t6.ticket_tprice                                               --票-市场价

    ,t1.travel_date
     
FROM (
    SELECT  /*+ BROADCAST(t2) */ 
        t1.member_id
        ,t1.order_id
        ,t1.remote_order_id
        ,t1.scenic_id
        ,t1.ticket_id
        ,t1.product_id
        ,t1.sup_id
        ,t1.saler_id
        ,t1.apply_did
        ,t1.order_time
        ,t1.order_date
        ,t1.pay_time
        ,t1.expiration_date
        ,t1.pay_date
        ,t1.update_time
        ,t1.play_time
        ,t1.play_date
        ,t1.begin_time
        ,t1.end_time
        ,t1.cancel_time
        ,t1.verify_time
        ,t1.voucher_code
        ,t1.trade_order_id
        ,t1.ticket_taker_name
        ,t1.ticket_taker_phone
        ,t1.ticket_taker_idcard
        ,t1.order_status_code
        ,t1.order_pay_status
        ,t1.pay_funding_type
        ,t1.use_coupon
        ,t1.non_refund_withdraw
        ,t1.order_customer_type
        ,t1.order_channel
        ,t1.product_type
        ,t1.channel_class1_id
        ,t1.channel_class1_name
        ,t1.channel_class2_id
        ,t1.channel_class2_name
        ,t1.ticket_taker_phone_province_code
        ,t1.ticket_taker_phone_province_name
        ,t1.ticket_taker_phone_city_code
        ,t1.ticket_taker_phone_city_name
        ,t1.ticket_taker_idcard_province_code
        ,t1.ticket_taker_idcard_province_name
        ,t1.ticket_taker_idcard_city_code
        ,t1.ticket_taker_idcard_city_name
        ,t1.ticket_taker_idcard_district_code
        ,t1.ticket_taker_idcard_district_name
        ,t1.tnum
        ,t1.origin_num
        ,t1.current_total_num
        ,t1.refund_num
        ,t1.verified_num
        ,t1.can_take_num
        ,t1.can_refund_num
        ,t1.order_price
        ,t1.original_order_amount
        ,t1.supply_price
        ,t1.retail_price
        ,t1.by_order_retail_price
        ,t1.actual_selling_price
        ,t1.travel_date
    FROM dwd_ord_order_details_di t1
    LEFT SEMI JOIN update_order_date t2
    ON t1.travel_date = t2.order_date
) t1
--套票明细
LEFT JOIN (
    SELECT  /*+ BROADCAST(t2) */ 
         t1.order_id
        ,t1.ifpack
        ,t1.pack_sup_id       
        ,t1.pack_scenic_id    
        ,t1.pack_ticket_id    
        ,t1.pack_product_id   
        ,t1.pack_product_type 
    FROM dwd_ord_package_sub_order_details_di t1
    LEFT SEMI JOIN update_order_date t2
    ON t1.travel_date = t2.order_date
) t2
ON t1.order_id = t2.order_id
--团单明细
LEFT JOIN (
    SELECT  /*+ BROADCAST(t2) */ 
        t1.sub_order_id
        ,t1.master_order_id
    FROM dwd_ord_group_sub_order_details_di t1
    LEFT SEMI JOIN update_order_date t2
    ON t1.travel_date = t2.order_date
) t3
ON t1.order_id = t3.sub_order_id
--分销明细
LEFT JOIN (
    SELECT  /*+ BROADCAST(t2) */ 
        t1.order_id
        ,t1.apply_did
        ,t1.buyer_id                       
        ,t1.buyer_company_type             
        ,t1.buyer_business_type            
        ,t1.buyer_account_group            
        ,t1.seller_id                      
        ,t1.seller_company_type            
        ,t1.seller_business_type           
        ,t1.current_distributor_level      
        ,t1.cost_money                     
        ,t1.sale_money                     
    FROM dwd_ord_split_order_details_di t1
    LEFT SEMI JOIN update_order_date t2
    ON t1.travel_date = t2.order_date
    WHERE t1.apply_did = t1.seller_id
) t4
ON t1.order_id = t4.order_id
--关联一级分销订单
--景区信息
LEFT JOIN dim_attr_scenic_info_df t5
ON t1.scenic_id = t5.scenic_id
--票信息
LEFT JOIN dim_attr_ticket_info_df t6
ON t1.ticket_id = t6.ticket_id
-- --订单验证信息，计算对应票数
-- LEFT JOIN (
--     SELECT 
--     order_id
--     ,sum(IF(action IN (0, 16),   change_tnum, 0))        AS booking_ticket_num
--     ,sum(IF(action IN (4, 16),   change_tnum, 0))               AS pay_ticket_num
--     ,sum(IF(action IN (1, 2),    change_tnum, 0))               AS cancel_ticket_num
--     ,sum(CASE 
--         WHEN (action = 5 AND get_json_object(ext_content, '$.need_write_num') > 0 )                                                       
--         THEN get_json_object(ext_content, '$.need_write_num')
--         WHEN 
--         (
--             (action = 5 AND source not in (53, 54, 32, 85)) 
--             OR 
--             (action = 33 AND source IN(32, 85)) 
--         )    
--         THEN change_tnum
--         ELSE 0
--     END   
--     )                                        AS verify_ticket_num
--     ,sum(IF(action IN (6, 7) ,change_tnum, 0))                AS revoke_ticket_num
--     ,sum(IF(action IN (3)    ,change_tnum, 0))                AS take_ticket_num
--     ,sum(IF(action IN (38)   ,change_tnum, 0))                AS after_sale_ticket_num
--     ,sum(IF(
--         action IN (17),
--         IF (
--             change_tnum > 0,
--             change_tnum,
--             0
--         ),
--         0
--     ))                                             AS finish_ticket_num
--     FROM dwd_ord_verification_detail_di
--     where verify_date = 20260602
--     group by order_id
-- ) t7
-- ON t1.order_id = t7.order_id
-- where t1.travel_date = 20260602
;





--增量数据分区更新
INSERT OVERWRITE TABLE dim_src_table_increment_info_di PARTITION(table_name,update_date)
SELECT 
    'order_date' AS date_type
    ,order_date AS date_value
    ,'dws' AS table_type
    ,'dws_ord_order_detail_wide_di' AS table_name
    ,${yesterday} AS update_date
FROM (
    SELECT date_value as order_date FROM dim_src_table_increment_info_di 
    WHERE table_name = 'dwd_ord_order_details_di' AND update_date = ${yesterday}
)
GROUP BY order_date
;







