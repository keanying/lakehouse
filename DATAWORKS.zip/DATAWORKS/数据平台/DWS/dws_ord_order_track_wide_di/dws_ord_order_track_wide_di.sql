--Serverless Spark SQL
--********************************************************************--
--author: 韩瑞
--create time: 2026-07-21 18:15:57
--Serverless Spark SQL任务只能运行在独享资源组上
--********************************************************************--

-- DROP TABLE IF exists dws_ord_order_track_wide_di;
CREATE TABLE IF NOT exists  dws_ord_order_track_wide_di
(
    apply_did                   INT COMMENT '原始供应商ID'
    ,order_id                   STRING COMMENT '订单号'
    ,ticket_id                  BIGINT COMMENT '票类ID'
    ,scenic_id                  INT COMMENT '景区id'
    ,product_id                 INT COMMENT '产品id'
    ,sup_id                     INT COMMENT '供应商ID'
    ,saler_id                   INT COMMENT '商家ID'
    ,product_type               STRING COMMENT '商品类型'
    ,ticket_name                STRING COMMENT '票名称'
    ,ticket_fullname            STRING COMMENT '票全称=景区名称+“-”+票名称'
    ,ticket_status_code         INT COMMENT '票状态编码[1上架, 2下架, 6删除]'
    ,is_package_ticket          INT COMMENT '是否组合套票[1:是,0:否]'
    ,ticket_package_type        INT COMMENT '组合类型[0:单票,1:套票中的主票,2:套票中的子票,3:1+2情况]'
    ,ticket_max_expiration_date STRING COMMENT '票最大过期日期'
    ,scenic_name                STRING COMMENT '景区名称'
    ,scenic_status_code         INT COMMENT '景区状态编码[1:上架,2:下架,3:删除,4:新增]'
    ,scenic_publisher_id        INT COMMENT '景区发布商ID'
    ,scenic_publisher_name      STRING COMMENT '景区发布商账户名称'
    ,scenic_type_code           STRING COMMENT '景区类型编码[A:景区,B:线路,C:酒店,F:套票,G:餐饮,H:演出,I:年卡,J:特产,K:计时产品]'
    ,scenic_type_name           STRING COMMENT '景区类型'
    ,scenic_level_code          STRING COMMENT '景区级别编码'
    ,scenic_level               STRING COMMENT '景区级别'
    ,scenic_topic               STRING COMMENT '主题列表第一个主题'
    ,scenic_topics              STRING COMMENT '主题列表'
    ,channel_class1_id          INT COMMENT '渠道一级分类id'
    ,channel_class1_name        STRING COMMENT '渠道一级分类名称'
    ,channel_class2_id          INT COMMENT '渠道二级分类id(ordermode)'
    ,channel_class2_name        STRING COMMENT '渠道二级分类名称'
    ,order_time                 STRING COMMENT '下单时间'
    ,order_date                 DATE COMMENT '下单日期'
    ,order_status_code          INT COMMENT '订单状态：0=未使用,1=已使用,2=已过期,3=被取消,4=待确认(酒店)，待收货(特产),5=被终端修改,6=被终端撤销,7=部分使用,8=订单完结,9=被删除'
    ,order_pay_status           INT COMMENT '支付方式:0=现场支付,1=已支付,2=未支付'
    ,pay_funding_type           INT COMMENT '支付方式：0 = 余额支付,1 = 支付宝,2 = 授信支付,3 = 产品自销,4 = 现场支付,5 = 微信支付,6 = 会员卡支付,7 = 银联支付,8 = 环迅支付,9 = 现金支付,10 = 会员卡,11 = 拉卡拉（商户）,12 = 拉卡拉（平台）,13 = 特权支付（年卡）,14 = 微信（聚合）,15 = 平安银行,16 = 支付宝（聚合）,17 = 会员卡支付,18 = 计时卡支付,25 = 招行一网通支付,26 = 银联商务支付,27 = 银联商务POS支付,28 = 威富通支付,29 = 易宝云企付,33 = 博思支付,35 = 积分支付,36 = POS支'
    ,order_channel              INT COMMENT '下单方式:0=正常分销商下单,1=普通用户支付,2=用户手机支付,3=会员卡购票,10=云票务,11=微信商城,12=自助机,13=二级店铺,14=闸机购票,15=智能终端,16=计调下单,17=淘宝码商,18=年卡,19=微信端,20=外部接口OTA下单,22=一卡通,23=套票子票'
    ,order_price                INT COMMENT '单价'
    ,supply_price               BIGINT COMMENT '供应价'
    ,retail_price               BIGINT COMMENT '零售价表'
    ,by_order_retail_price      BIGINT COMMENT '下单时的门市价'
    ,actual_selling_price       INT COMMENT '实际售价'
    ,booking_ticket_num         BIGINT COMMENT '预定票数'
    ,pay_ticket_num             BIGINT COMMENT '支付票数'
    ,cancel_ticket_num          BIGINT COMMENT '退票数'
    ,verify_ticket_num          BIGINT COMMENT '验证票数'
    ,revoke_ticket_num          BIGINT COMMENT '撤改/撤销票数'
    ,take_ticket_num            BIGINT COMMENT '取票数'
    ,after_sale_ticket_num      BIGINT COMMENT '售后票数'
    ,finish_ticket_num          BIGINT COMMENT '完结票数'
)
COMMENT '订单轨迹宽表'
PARTITIONED BY 
(
    verify_date            INT COMMENT '日志插入日期'
)
STORED AS orc
;



INSERT OVERWRITE TABLE dws_ord_order_track_wide_di PARTITION(verify_date)
SELECT 

    t1.apply_did                       --原始供应商ID
    ,t1.order_id                       --订单号ID
    ,t1.ticket_id                      --门票id
    ,t2.scenic_id                      --景区id
    ,t2.product_id                     --产品id
    ,t2.sup_id                         --供应商ID
    ,t2.saler_id                       --商家ID
    ,t2.product_type                   --商品类型

    ,t4.ticket_name                    --票名称
    ,t4.ticket_fullname                --票全称=景区名称+“-”+票名称
    ,t4.ticket_status_code             --票状态编码[1上架, 2下架, 6删除]
    ,t4.is_package_ticket              --是否组合套票[1:是,0:否]
    ,t4.ticket_package_type            --组合类型[0:单票,1:套票中的主票,2:套票中的子票,3:1+2情况]
    ,t4.ticket_max_expiration_date     --票最大过期日期

    ,t3.scenic_name                    --景区名称
    ,t3.scenic_status_code             --景区状态编码[1:上架,2:下架,3:删除,4:新增]
    ,t3.scenic_publisher_id            --景区发布商ID
    ,t3.scenic_publisher_name          --景区发布商账户名称
    ,t3.scenic_type_code               --景区类型编码[A:景区,B:线路,C:酒店,F:套票,G:餐饮,H:演出,I:年卡,J:特产,K:计时产品]
    ,t3.scenic_type_name               --景区类型
    ,t3.scenic_level_code              --景区级别编码
    ,t3.scenic_level                   --景区级别
    ,t3.scenic_topic                   --主题列表第一个主题      
    ,t3.scenic_topics                  --主题列表

    ,t2.channel_class1_id              --渠道一级分类id     
    ,t2.channel_class1_name            --渠道一级分类名称  
    ,t2.channel_class2_id              --渠道二级分类id
    ,t2.channel_class2_name            --渠道二级分类名称
    ,t2.order_time                     --下单时间
    ,t2.order_date                     --下单日期
    ,t2.order_status_code              --订单状态
    ,t2.order_pay_status               --支付状态
    ,t2.pay_funding_type               --支付方式
    ,t2.order_channel                  --下单方式
    ,t2.order_price                    --单价
    ,t2.supply_price                   --供应价
    ,t2.retail_price                   --零售价表
    ,t2.by_order_retail_price          --下单时的门市价
    ,t2.actual_selling_price           --实际售价
    
    ,t1.booking_ticket_num             --预定票数
    ,t1.pay_ticket_num                 --支付票数
    ,t1.cancel_ticket_num              --退票数
    ,t1.verify_ticket_num              --验证票数
    ,t1.revoke_ticket_num              --撤改/撤销票数
    ,t1.take_ticket_num                --取票数
    ,t1.after_sale_ticket_num          --售后票数
    ,t1.finish_ticket_num              --完结票数

    ,t1.verify_date

FROM 
(
    SELECT  apply_did
            ,order_id
            ,ticket_id
            ,verify_date
            ,SUM(IF(action IN (0,16),change_tnum,0)) AS booking_ticket_num
            ,SUM(IF(action IN (4,16),change_tnum,0)) AS pay_ticket_num
            ,SUM(IF(action IN (1,2),change_tnum,0)) AS cancel_ticket_num
            ,SUM(CASE   WHEN (
                        action = 5 AND GET_JSON_OBJECT(ext_content,'$.need_write_num') > 0
                    ) THEN GET_JSON_OBJECT(ext_content,'$.need_write_num')
                    WHEN (
                                (
                                            action = 5
                                                AND source NOT IN (53,54,32,85)
                                )
                                    OR (
                                            action = 33
                                                AND source IN (32,85)
                                )
                    ) THEN change_tnum
                    ELSE 0
                END 
            ) AS verify_ticket_num
            ,SUM(IF(action IN (6,7),change_tnum,0)) AS revoke_ticket_num
            ,SUM(IF(action IN (3),change_tnum,0)) AS take_ticket_num
            ,SUM(IF(action IN (38),change_tnum,0)) AS after_sale_ticket_num
            ,SUM(IF(action IN (17),IF(change_tnum > 0,change_tnum,0),0)) AS finish_ticket_num
            ,SUM(change_tnum) AS change_tnum
    FROM    dwd_ord_verification_detail_di
    WHERE   verify_date = ${yesterday}
    GROUP BY apply_did
            ,order_id
            ,ticket_id
            ,verify_date
) t1 
LEFT JOIN dwd_ord_order_details_di t2
ON t1.order_id = t2.order_id
AND t2.travel_date >= CAST(DATE_FORMAT(DATE_SUB(TO_DATE(CAST(${yesterday} AS STRING), 'yyyyMMdd'), 732), 'yyyyMMdd') AS INT)
--景区信息
LEFT JOIN dim_attr_scenic_info_df t3
ON t2.scenic_id = t3.scenic_id
--票信息
LEFT JOIN dim_attr_ticket_info_df t4
ON t1.ticket_id = t4.ticket_id
;


