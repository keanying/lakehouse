--Serverless Spark SQL
--********************************************************************--
--author: 韩瑞
--create time: 2026-06-16 14:26:32
--Serverless Spark SQL任务只能运行在独享资源组上
--********************************************************************--
-- 加工跟日期相关的全部维度信息

CREATE TABLE IF NOT EXISTS dim_common_date_info_df (
    -- 基础日期信息
    date_key          STRING  COMMENT '日期主键(yyyyMMdd)',
    date_actual       DATE    COMMENT '日期(yyyy-MM-dd)',
    day_of_week       STRING  COMMENT '星期几(中文)',
    day_of_week_num   INT     COMMENT '星期几数字(1=周一..7=周日)',
    is_weekend        INT COMMENT '是否周末(周六/日,纯算法判断)',
    is_holiday        INT COMMENT '是否节假日',
    holiday_type      STRING COMMENT '是否节假日',
    
    -- 日维度同比环比
    day_yoy           STRING  COMMENT '同比日期(yyyyMMdd,去年同日)',
    day_mom           STRING  COMMENT '环比日期(yyyyMMdd,T-1)',
    
    -- 自然周维度(ISO标准,周一始)
    week_key          STRING  COMMENT '自然周编号(yyyyWww)',
    week_start        DATE    COMMENT '本周起始日(周一)',
    week_end          DATE    COMMENT '本周结束日(周日)',
    week_range        STRING  COMMENT '本周日期范围(yyyyMMdd~yyyyMMdd)',
    week_key_yoy      STRING  COMMENT '同比周编号(yyyyWww)',
    week_yoy_start    DATE    COMMENT '同比周起始日(去年同周周一)',
    week_yoy_end      DATE    COMMENT '同比周结束日(去年同周周日)',
    week_yoy_range    STRING  COMMENT '同比周日期范围',
    week_key_mom      STRING  COMMENT '环比周编号(yyyyWww)',
    week_mom_start    DATE    COMMENT '环比周起始日(上周周一)',
    week_mom_end      DATE    COMMENT '环比周结束日(上周周日)',
    week_mom_range    STRING  COMMENT '环比周日期范围',
    
    -- 自然月维度
    month_key         STRING  COMMENT '月份(yyyyMM)',
    month_name        STRING  COMMENT '月份中文(一月~十二月)',
    month_start       DATE    COMMENT '本月起始日',
    month_end         DATE    COMMENT '本月结束日',
    month_range       STRING  COMMENT '本月日期范围',
    month_key_yoy     STRING  COMMENT '同比月份(yyyyMM)',
    month_yoy_start   DATE    COMMENT '同比月起始日(去年同月)',
    month_yoy_end     DATE    COMMENT '同比月结束日',
    month_yoy_range   STRING  COMMENT '同比月日期范围',
    month_key_mom     STRING  COMMENT '环比月份(yyyyMM)',
    month_mom_start   DATE    COMMENT '环比月起始日(上月)',
    month_mom_end     DATE    COMMENT '环比月结束日',
    month_mom_range   STRING  COMMENT '环比月日期范围',
    
    -- 自然季度维度
    quarter_key       STRING  COMMENT '季度(yyyyQq)',
    quarter_num       INT     COMMENT '季度数字(1~4)',
    quarter_start     DATE    COMMENT '本季起始日',
    quarter_end       DATE    COMMENT '本季结束日',
    quarter_range     STRING  COMMENT '本季日期范围',
    quarter_key_yoy   STRING  COMMENT '同比季度(yyyyQq)',
    quarter_yoy_start DATE    COMMENT '同比季起始日(去年同季)',
    quarter_yoy_end   DATE    COMMENT '同比季结束日',
    quarter_yoy_range STRING  COMMENT '同比季日期范围',
    quarter_key_mom   STRING  COMMENT '环比季度(yyyyQq)',
    quarter_mom_start DATE    COMMENT '环比季起始日(上季度)',
    quarter_mom_end   DATE    COMMENT '环比季结束日',
    quarter_mom_range STRING  COMMENT '环比季日期范围',
    
    -- 自然半年维度
    half_key          STRING  COMMENT '半年(yyyyH1/H2)',
    half_start        DATE    COMMENT '本半年起始日',
    half_end          DATE    COMMENT '本半年结束日',
    half_range        STRING  COMMENT '本半年日期范围',
    half_key_yoy      STRING  COMMENT '同比半年(yyyyH1/H2)',
    half_yoy_start    DATE    COMMENT '同比半年起始日(去年同半年)',
    half_yoy_end      DATE    COMMENT '同比半年结束日',
    half_yoy_range    STRING  COMMENT '同比半年日期范围',
    half_key_mom      STRING  COMMENT '环比半年(yyyyH1/H2)',
    half_mom_start    DATE    COMMENT '环比半年起始日(上一个半年)',
    half_mom_end      DATE    COMMENT '环比半年结束日',
    half_mom_range    STRING  COMMENT '环比半年日期范围',
    
    -- 自然年维度
    year_key          STRING  COMMENT '年份(yyyy)',
    year_month        STRING  COMMENT '年月展示(yyyy-MM)',
    year_start        DATE    COMMENT '本年起始日',
    year_end          DATE    COMMENT '本年结束日',
    year_range        STRING  COMMENT '本年日期范围',
    year_key_yoy      STRING  COMMENT '同比年份(yyyy)',
    year_yoy_start    DATE    COMMENT '同比年起始日(去年)',
    year_yoy_end      DATE    COMMENT '同比年结束日',
    year_yoy_range    STRING  COMMENT '同比年日期范围',
    year_key_mom      STRING  COMMENT '环比年份(yyyy)',
    year_mom_start    DATE    COMMENT '环比年起始日(上一年,与同比年重复)',
    year_mom_end      DATE    COMMENT '环比年结束日',
    year_mom_range    STRING  COMMENT '环比年日期范围'
)
COMMENT '时间维度表(纯算法,不含节假日,需外部关联节假日维表)'
STORED AS ORC
;



-- ============================================================================
-- 脚本名称：dim_common_date_info_df 数据生成
-- 功能描述：生成日期维度表（不含节假日），覆盖日、周、月、季、半年、年各层级属性，
--           包含同比/环比日期范围及对应的周期键（key），用于多粒度时间分析。
-- 目标表：dim_common_date_info_df
-- 执行方式：INSERT OVERWRITE（每日全量覆盖，建议按业务范围定期执行）
-- 日期范围：2020-01-01 ~ 2030-12-31（可按需调整）
-- 依赖引擎：Spark SQL（需支持 SEQUENCE、DATE_TRUNC、EXPLODE 等函数）
-- 注意事项：
--   1. 节假日字段（is_holiday/holiday_type）留空为 NULL，需外部维表关联填充；
--   2. 周编号遵循 ISO 标准（周一为起始日），跨年周归属以周一所在年份为准；
--   3. 同比周采用“减 364 天”近似对齐，若需严格 ISO 周对齐可二次调整；
--   4. is_weekend 已转为 INT(0/1)，符合表定义；
--   5. 所有范围字符串格式为 yyyyMMdd~yyyyMMdd，便于直接用于 BETWEEN 查询。
-- ============================================================================

-- SELECT * FROM dim_common_date_info_df limit 1000;

INSERT OVERWRITE TABLE dim_common_date_info_df
-- 使用 WITH 子句组织 CTE，提高可读性和性能（公共表达式多次引用）
WITH
-- ============================================================
-- 1. 日期序列生成：产生从起始到结束的连续日期
--    - SEQUENCE 函数生成日期数组（包含起止日期）
--    - EXPLODE 将数组展开为多行，每行一个日期
--    - 此处作为整个维度表的基础数据源
-- ============================================================
date_series AS (
    SELECT EXPLODE(
        SEQUENCE(
            TO_DATE('2020-01-01'),   -- 起始日期（可根据业务需求调整，如最早业务日期）
            TO_DATE('2030-12-31'),   -- 结束日期（建议覆盖未来数年，便于同比分析）
            INTERVAL 1 DAY           -- 步长为 1 天，生成连续日期
        )
    ) AS date_actual                -- 基准日期列，所有后续计算均围绕此列展开
),

-- ============================================================
-- 2. 基础属性预计算层（base CTE）
--    目的：将高频使用的派生属性（如周起始、月起始、季度起始等）一次性计算，
--          避免在后续主查询中重复计算，提升性能并简化逻辑。
-- ============================================================
base AS (
    SELECT
        date_actual,
        -- 2.1 星期几（Spark 中 DAYOFWEEK: 1=周日, 2=周一, ..., 7=周六）
        DAYOFWEEK(date_actual) AS dow,
        
        -- 2.2 本周起始日（周一）
        --     公式：当前日期 - (当前星期几数字 - 2)
        --     例如：周日(dow=1) -> 减 -1 → 周一；周一(dow=2) -> 减 0 → 自身
        DATE_SUB(date_actual, DAYOFWEEK(date_actual) - 2) AS week_start,
        
        -- 2.3 本月起始日（当月1日）
        TRUNC(date_actual, 'MM') AS month_start,
        
        -- 2.4 本月结束日（当月最后一天）
        LAST_DAY(date_actual) AS month_end,
        
        -- 2.5 本季度起始日（季度第一天）
        --     DATE_TRUNC('quarter', date) 返回该季度第一天的 00:00:00（时间戳），
        --     需 CAST AS DATE 去除时间部分
        CAST(DATE_TRUNC('quarter', date_actual) AS DATE) AS quarter_start,
        
        -- 2.6 下季度起始日（用于计算本季度结束日）
        ADD_MONTHS(CAST(DATE_TRUNC('quarter', date_actual) AS DATE), 3) AS next_quarter_start,
        
        -- 2.7 当前月份数字（1~12）和年份数字
        MONTH(date_actual) AS month_num,
        YEAR(date_actual) AS year_num
    FROM date_series
)

-- ============================================================
-- 3. 主查询：生成所有维度字段，按逻辑分组
--    注意：字段顺序必须与目标表定义完全一致，包括新增的同比/环比key字段。
-- ============================================================
SELECT
    -- ==========================================================
    -- 3.1 基础日期信息
    -- ==========================================================
    DATE_FORMAT(date_actual, 'yyyyMMdd') AS date_key,          -- 日期主键，字符串格式，便于分区或关联
    date_actual,                                               -- 日期本身（DATE类型），用于直接比较
    
    -- 星期几（中文名称），根据 dow 映射
    CASE dow
        WHEN 2 THEN '星期一' WHEN 3 THEN '星期二' WHEN 4 THEN '星期三'
        WHEN 5 THEN '星期四' WHEN 6 THEN '星期五' WHEN 7 THEN '星期六'
        WHEN 1 THEN '星期日'
    END AS day_of_week,
    
    -- 星期几数字（1=周一，7=周日），将周日(dow=1)转为7，其余减1
    CASE dow WHEN 1 THEN 7 ELSE dow - 1 END AS day_of_week_num,
    
    -- 是否周末（0=否，1=是），周六(dow=7)或周日(dow=1)
    CASE WHEN dow IN (1, 7) THEN 1 ELSE 0 END AS is_weekend,
    
    -- 节假日字段（占位，需外部填充），表注释声明“不含节假日”，故先置 NULL
    CAST(NULL AS INT) AS is_holiday,
    CAST(NULL AS STRING) AS holiday_type,

    -- ==========================================================
    -- 3.2 日维度同比环比
    -- ==========================================================
    -- 同比日期：去年同月同日，使用 ADD_MONTHS 减12个月，避免闰年问题
    DATE_FORMAT(ADD_MONTHS(date_actual, -12), 'yyyyMMdd') AS day_yoy,
    -- 环比日期：前一日（T-1）
    DATE_FORMAT(DATE_SUB(date_actual, 1), 'yyyyMMdd') AS day_mom,

    -- ==========================================================
    -- 3.3 自然周维度（ISO标准，周一始）
    --     周编号格式：yyyyWww，其中 yyyy 为周一所在年份，ww 为年内周数（01~53）
    --     跨年周处理：使用 week_start 计算年份和周数，避免当前日期所属年份与周起始年份不一致
    -- ==========================================================
    CONCAT(
        CAST(YEAR(week_start) AS STRING),
        'W',
        LPAD(CAST(WEEKOFYEAR(week_start) AS STRING), 2, '0')
    ) AS week_key,
    
    week_start,                                                -- 本周一
    DATE_ADD(week_start, 6) AS week_end,                       -- 本周日（周一+6天）
    CONCAT(DATE_FORMAT(week_start, 'yyyyMMdd'), '~', DATE_FORMAT(DATE_ADD(week_start, 6), 'yyyyMMdd')) AS week_range,

    -- 周同比key：根据同比周起始日生成
    CONCAT(
        CAST(YEAR(DATE_SUB(week_start, 364)) AS STRING),
        'W',
        LPAD(CAST(WEEKOFYEAR(DATE_SUB(week_start, 364)) AS STRING), 2, '0')
    ) AS week_key_yoy,
    -- 同比周：去年同周（近似按 364天 = 52周 偏移）
    DATE_SUB(week_start, 364) AS week_yoy_start,
    DATE_SUB(DATE_ADD(week_start, 6), 364) AS week_yoy_end,
    CONCAT(
        DATE_FORMAT(DATE_SUB(week_start, 364), 'yyyyMMdd'),
        '~',
        DATE_FORMAT(DATE_SUB(DATE_ADD(week_start, 6), 364), 'yyyyMMdd')
    ) AS week_yoy_range,

    -- 周环比key：根据环比周起始日生成
    CONCAT(
        CAST(YEAR(DATE_SUB(week_start, 7)) AS STRING),
        'W',
        LPAD(CAST(WEEKOFYEAR(DATE_SUB(week_start, 7)) AS STRING), 2, '0')
    ) AS week_key_mom,
    -- 环比周：上周（前7天）
    DATE_SUB(week_start, 7) AS week_mom_start,
    DATE_SUB(DATE_ADD(week_start, 6), 7) AS week_mom_end,
    CONCAT(
        DATE_FORMAT(DATE_SUB(week_start, 7), 'yyyyMMdd'),
        '~',
        DATE_FORMAT(DATE_SUB(DATE_ADD(week_start, 6), 7), 'yyyyMMdd')
    ) AS week_mom_range,

    -- ==========================================================
    -- 3.4 自然月维度
    -- ==========================================================
    DATE_FORMAT(date_actual, 'yyyyMM') AS month_key,           -- 月份标识，如 202601
    CASE month_num                                              -- 中文月份名称
        WHEN 1 THEN '一月'  WHEN 2 THEN '二月'  WHEN 3 THEN '三月'
        WHEN 4 THEN '四月'  WHEN 5 THEN '五月'  WHEN 6 THEN '六月'
        WHEN 7 THEN '七月'  WHEN 8 THEN '八月'  WHEN 9 THEN '九月'
        WHEN 10 THEN '十月' WHEN 11 THEN '十一月' WHEN 12 THEN '十二月'
    END AS month_name,
    
    month_start,                                               -- 本月1日
    month_end,                                                 -- 本月最后一天
    CONCAT(DATE_FORMAT(month_start, 'yyyyMMdd'), '~', DATE_FORMAT(month_end, 'yyyyMMdd')) AS month_range,

    -- 月同比key：去年同月（yyyyMM）
    DATE_FORMAT(ADD_MONTHS(date_actual, -12), 'yyyyMM') AS month_key_yoy,
    -- 同比月：去年同月（月起始日减12个月）
    ADD_MONTHS(month_start, -12) AS month_yoy_start,
    LAST_DAY(ADD_MONTHS(date_actual, -12)) AS month_yoy_end,
    CONCAT(
        DATE_FORMAT(ADD_MONTHS(month_start, -12), 'yyyyMMdd'),
        '~',
        DATE_FORMAT(LAST_DAY(ADD_MONTHS(date_actual, -12)), 'yyyyMMdd')
    ) AS month_yoy_range,

    -- 月环比key：上月（yyyyMM）
    DATE_FORMAT(ADD_MONTHS(date_actual, -1), 'yyyyMM') AS month_key_mom,
    -- 环比月：上月（月起始日减1个月）
    ADD_MONTHS(month_start, -1) AS month_mom_start,
    LAST_DAY(ADD_MONTHS(date_actual, -1)) AS month_mom_end,
    CONCAT(
        DATE_FORMAT(ADD_MONTHS(month_start, -1), 'yyyyMMdd'),
        '~',
        DATE_FORMAT(LAST_DAY(ADD_MONTHS(date_actual, -1)), 'yyyyMMdd')
    ) AS month_mom_range,

    -- ==========================================================
    -- 3.5 自然季度维度
    --     季度编号格式：yyyyQq（q=1~4）
    --     起始日：DATE_TRUNC('quarter') 返回季度首日；结束日：下季度首日减1天
    -- ==========================================================
    CONCAT(CAST(year_num AS STRING), 'Q', CAST(QUARTER(date_actual) AS STRING)) AS quarter_key,
    QUARTER(date_actual) AS quarter_num,
    quarter_start,
    DATE_SUB(next_quarter_start, 1) AS quarter_end,            -- 本季最后一天
    CONCAT(DATE_FORMAT(quarter_start, 'yyyyMMdd'), '~', DATE_FORMAT(DATE_SUB(next_quarter_start, 1), 'yyyyMMdd')) AS quarter_range,

    -- 季度同比key：去年同季（yyyyQq）
    CONCAT(
        CAST(YEAR(ADD_MONTHS(quarter_start, -12)) AS STRING),
        'Q',
        CAST(QUARTER(ADD_MONTHS(date_actual, -12)) AS STRING)
    ) AS quarter_key_yoy,
    -- 同比季：去年同季（季度起始日减12个月）
    ADD_MONTHS(quarter_start, -12) AS quarter_yoy_start,
    DATE_SUB(ADD_MONTHS(next_quarter_start, -12), 1) AS quarter_yoy_end,
    CONCAT(
        DATE_FORMAT(ADD_MONTHS(quarter_start, -12), 'yyyyMMdd'),
        '~',
        DATE_FORMAT(DATE_SUB(ADD_MONTHS(next_quarter_start, -12), 1), 'yyyyMMdd')
    ) AS quarter_yoy_range,

    -- 季度环比key：上季度（yyyyQq）
    CONCAT(
        CAST(YEAR(ADD_MONTHS(quarter_start, -3)) AS STRING),
        'Q',
        CAST(QUARTER(ADD_MONTHS(date_actual, -3)) AS STRING)
    ) AS quarter_key_mom,
    -- 环比季：上季度（季度起始日减3个月）
    ADD_MONTHS(quarter_start, -3) AS quarter_mom_start,
    DATE_SUB(quarter_start, 1) AS quarter_mom_end,             -- 上季度末 = 本季首日减1天
    CONCAT(
        DATE_FORMAT(ADD_MONTHS(quarter_start, -3), 'yyyyMMdd'),
        '~',
        DATE_FORMAT(DATE_SUB(quarter_start, 1), 'yyyyMMdd')
    ) AS quarter_mom_range,

    -- ==========================================================
    -- 3.6 自然半年维度
    --     H1: 1~6月，H2: 7~12月
    --     使用 CASE 判断月份，分别构造起始/结束日期
    -- ==========================================================
    CASE WHEN month_num <= 6 THEN CONCAT(CAST(year_num AS STRING), 'H1') ELSE CONCAT(CAST(year_num AS STRING), 'H2') END AS half_key,
    CASE WHEN month_num <= 6 THEN TO_DATE(CONCAT(CAST(year_num AS STRING), '-01-01')) ELSE TO_DATE(CONCAT(CAST(year_num AS STRING), '-07-01')) END AS half_start,
    CASE WHEN month_num <= 6 THEN TO_DATE(CONCAT(CAST(year_num AS STRING), '-06-30')) ELSE TO_DATE(CONCAT(CAST(year_num AS STRING), '-12-31')) END AS half_end,
    CONCAT(
        DATE_FORMAT(CASE WHEN month_num <= 6 THEN TO_DATE(CONCAT(CAST(year_num AS STRING), '-01-01')) ELSE TO_DATE(CONCAT(CAST(year_num AS STRING), '-07-01')) END, 'yyyyMMdd'),
        '~',
        DATE_FORMAT(CASE WHEN month_num <= 6 THEN TO_DATE(CONCAT(CAST(year_num AS STRING), '-06-30')) ELSE TO_DATE(CONCAT(CAST(year_num AS STRING), '-12-31')) END, 'yyyyMMdd')
    ) AS half_range,

    -- 半年同比key：去年同半年（yyyyH1/H2）
    CASE WHEN month_num <= 6 THEN CONCAT(CAST(year_num-1 AS STRING), 'H1') ELSE CONCAT(CAST(year_num-1 AS STRING), 'H2') END AS half_key_yoy,
    -- 同比半年：去年同半年（年份减1，半年标识不变）
    CASE WHEN month_num <= 6 THEN TO_DATE(CONCAT(CAST(year_num-1 AS STRING), '-01-01')) ELSE TO_DATE(CONCAT(CAST(year_num-1 AS STRING), '-07-01')) END AS half_yoy_start,
    CASE WHEN month_num <= 6 THEN TO_DATE(CONCAT(CAST(year_num-1 AS STRING), '-06-30')) ELSE TO_DATE(CONCAT(CAST(year_num-1 AS STRING), '-12-31')) END AS half_yoy_end,
    CONCAT(
        DATE_FORMAT(CASE WHEN month_num <= 6 THEN TO_DATE(CONCAT(CAST(year_num-1 AS STRING), '-01-01')) ELSE TO_DATE(CONCAT(CAST(year_num-1 AS STRING), '-07-01')) END, 'yyyyMMdd'),
        '~',
        DATE_FORMAT(CASE WHEN month_num <= 6 THEN TO_DATE(CONCAT(CAST(year_num-1 AS STRING), '-06-30')) ELSE TO_DATE(CONCAT(CAST(year_num-1 AS STRING), '-12-31')) END, 'yyyyMMdd')
    ) AS half_yoy_range,

    -- 半年环比key：上一个半年（规则同 half_mom_start/end）
    CASE WHEN month_num <= 6 THEN CONCAT(CAST(year_num-1 AS STRING), 'H2') ELSE CONCAT(CAST(year_num AS STRING), 'H1') END AS half_key_mom,
    -- 环比半年：上一个半年（当前H1 → 去年H2；当前H2 → 今年H1）
    CASE WHEN month_num <= 6 THEN TO_DATE(CONCAT(CAST(year_num-1 AS STRING), '-07-01')) ELSE TO_DATE(CONCAT(CAST(year_num AS STRING), '-01-01')) END AS half_mom_start,
    CASE WHEN month_num <= 6 THEN TO_DATE(CONCAT(CAST(year_num-1 AS STRING), '-12-31')) ELSE TO_DATE(CONCAT(CAST(year_num AS STRING), '-06-30')) END AS half_mom_end,
    CONCAT(
        DATE_FORMAT(CASE WHEN month_num <= 6 THEN TO_DATE(CONCAT(CAST(year_num-1 AS STRING), '-07-01')) ELSE TO_DATE(CONCAT(CAST(year_num AS STRING), '-01-01')) END, 'yyyyMMdd'),
        '~',
        DATE_FORMAT(CASE WHEN month_num <= 6 THEN TO_DATE(CONCAT(CAST(year_num-1 AS STRING), '-12-31')) ELSE TO_DATE(CONCAT(CAST(year_num AS STRING), '-06-30')) END, 'yyyyMMdd')
    ) AS half_mom_range,

    -- ==========================================================
    -- 3.7 自然年维度
    -- ==========================================================
    CAST(year_num AS STRING) AS year_key,                     -- 年份
    DATE_FORMAT(date_actual, 'yyyy-MM') AS year_month,        -- 年月展示（冗余，但便于报表）
    TO_DATE(CONCAT(CAST(year_num AS STRING), '-01-01')) AS year_start,
    TO_DATE(CONCAT(CAST(year_num AS STRING), '-12-31')) AS year_end,
    CONCAT(DATE_FORMAT(TO_DATE(CONCAT(CAST(year_num AS STRING), '-01-01')), 'yyyyMMdd'), '~', DATE_FORMAT(TO_DATE(CONCAT(CAST(year_num AS STRING), '-12-31')), 'yyyyMMdd')) AS year_range,

    -- 年同比key：去年（yyyy）
    CAST(year_num-1 AS STRING) AS year_key_yoy,
    -- 同比年：去年（年份减1）
    TO_DATE(CONCAT(CAST(year_num-1 AS STRING), '-01-01')) AS year_yoy_start,
    TO_DATE(CONCAT(CAST(year_num-1 AS STRING), '-12-31')) AS year_yoy_end,
    CONCAT(DATE_FORMAT(TO_DATE(CONCAT(CAST(year_num-1 AS STRING), '-01-01')), 'yyyyMMdd'), '~', DATE_FORMAT(TO_DATE(CONCAT(CAST(year_num-1 AS STRING), '-12-31')), 'yyyyMMdd')) AS year_yoy_range,

    -- 年环比key：去年（与同比相同）
    CAST(year_num-1 AS STRING) AS year_key_mom,
    -- 环比年：上一年（与同比年相同，因年环比即与去年比较）
    TO_DATE(CONCAT(CAST(year_num-1 AS STRING), '-01-01')) AS year_mom_start,
    TO_DATE(CONCAT(CAST(year_num-1 AS STRING), '-12-31')) AS year_mom_end,
    CONCAT(DATE_FORMAT(TO_DATE(CONCAT(CAST(year_num-1 AS STRING), '-01-01')), 'yyyyMMdd'), '~', DATE_FORMAT(TO_DATE(CONCAT(CAST(year_num-1 AS STRING), '-12-31')), 'yyyyMMdd')) AS year_mom_range

-- ============================================================
-- 4. 数据来源：base CTE（已预计算基础属性）
-- ============================================================
FROM base
-- ============================================================
-- 5. 结果排序：按日期升序排列，便于人工检查及有序写入（可选）
-- ============================================================
ORDER BY date_actual;








