--Serverless Spark SQL
--********************************************************************--
--author: 韩瑞
--create time: 2026-06-16 17:16:02
--Serverless Spark SQL任务只能运行在独享资源组上
--********************************************************************--

-- DROP TABLE if exists dim_common_region_area_df;
CREATE TABLE IF NOT EXISTS dim_common_region_area_df
(
    country_id           INT COMMENT '国家ID'
    ,province_code       STRING COMMENT '省/直辖市/特别行政区/州-编码'
    ,province_name       STRING COMMENT '省/直辖市/特别行政区/州-名称'
    ,province_short_name STRING COMMENT '省/直辖市/特别行政区/州-简称'
    ,province_zip_code   STRING COMMENT '省/直辖市/特别行政区/州-邮政编码'
    ,province_area_code  STRING COMMENT '省/直辖市/特别行政区/州-区号'
    ,province_lng        DECIMAL(10,6) COMMENT '省/直辖市/特别行政区/州-经度'
    ,province_lat        DECIMAL(10,6) COMMENT '省/直辖市/特别行政区/州-纬度'
    ,city_code           STRING COMMENT '市-编码'
    ,city_name           STRING COMMENT '市-名称'
    ,city_short_name     STRING COMMENT '市-简称'
    ,city_zip_code       STRING COMMENT '市-邮政编码'
    ,city_area_code      STRING COMMENT '市-区号'
    ,city_lng            DECIMAL(10,6) COMMENT '市-经度'
    ,city_lat            DECIMAL(10,6) COMMENT '市-纬度'
    ,district_code       STRING COMMENT '区/县-编码'
    ,district_name       STRING COMMENT '区/县-名称'
    ,district_short_name STRING COMMENT '区/县-简称'
    ,district_zip_code   STRING COMMENT '区/县-邮政编码'
    ,district_area_code  STRING COMMENT '区/县-区号'
    ,district_lng        DECIMAL(10,6) COMMENT '区/县-经度'
    ,district_lat        DECIMAL(10,6) COMMENT '区/县-纬度'
)
COMMENT '行政区划归属维度表'
STORED AS ORC
;


WITH level_1_table AS (
  SELECT 
    country_id
    ,area_code as province_code
    ,area_name as province_name
    ,short_name as province_short_name
    ,zip_code as province_zip_code
    ,city_code as province_area_code
    ,lng as province_lng
    ,lat as province_lat
  FROM ods_region_area_d_f 
  where pt = '${yesterday}'
  and level = 1
  AND status in (1,4)
  AND country_id = 1
)
, level_2_table AS (
  SELECT 
    parent_code as city_parent_code
    ,area_code as city_code
    ,area_name as city_name
    ,short_name as city_short_name
    ,zip_code as city_zip_code
    ,city_code as city_area_code
    ,lng as city_lng
    ,lat as city_lat
  FROM ods_region_area_d_f 
  where pt = '${yesterday}'
  and level = 2
  AND status in (1,4)
  AND country_id = 1
)
, level_3_table AS (
  SELECT 
    parent_code as district_parent_code
    ,area_code as district_code
    ,area_name as district_name
    ,short_name as district_short_name
    ,zip_code as district_zip_code
    ,city_code as district_area_code
    ,lng as district_lng
    ,lat as district_lat
  FROM ods_region_area_d_f 
  where pt = '${yesterday}'
  and level = 3
  AND status in (1,4)
  AND country_id = 1
)

INSERT OVERWRITE TABLE dim_common_region_area_df
SELECT 
    t1.country_id
    ,t1.province_code
    ,t1.province_name
    ,t1.province_short_name
    ,t1.province_zip_code
    ,t1.province_area_code
    ,t1.province_lng
    ,t1.province_lat
    ,t2.city_code
    ,t2.city_name
    ,t2.city_short_name
    ,t2.city_zip_code
    ,t2.city_area_code
    ,t2.city_lng
    ,t2.city_lat
    ,t3.district_code
    ,t3.district_name
    ,t3.district_short_name
    ,t3.district_zip_code
    ,t3.district_area_code
    ,t3.district_lng
    ,t3.district_lat
from level_1_table t1
left join level_2_table t2
on t1.province_code  = t2.city_parent_code
left join level_3_table t3
on t2.city_code  = t3.district_parent_code
;





