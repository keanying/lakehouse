--Serverless Spark SQL
--********************************************************************--
--author: 韩瑞
--create time: 2026-06-15 17:36:00
--Serverless Spark SQL任务只能运行在独享资源组上
--********************************************************************--




CREATE TABLE IF NOT EXISTS dim_common_phone_code_country_df(
    `phone_area_code`   STRING  COMMENT '手机区号: 中国86',
    `name_zh`           STRING  COMMENT '中文名称',
    `name_en`           STRING  COMMENT '英文名称',
    `full_name_zh`      STRING  COMMENT '中文全称', 
    `full_name_en`      STRING  COMMENT '英文全称', 
    `is_country`        INT     COMMENT '是否为独立国家： 0.否 1.是',
    `alpha_2_code`      STRING  COMMENT 'ISO 3166-1标准中的二位字母代码: 美国.US 中国.CN 香港.HK 台湾.TW', 
    `alpha_3_code`      STRING  COMMENT 'ISO 3166-1标准中的三位字母代码',
    `numeric_3_code`    STRING  COMMENT 'ISO 3166-1标准中的三位数字代码'
) COMMENT'手机区号归属国家维度表'
STORED AS ORC
;


INSERT OVERWRITE TABLE dim_common_phone_code_country_df
SELECT 
    t1.phone_area_code,
    t2.name_zh, 
    t2.name_en, 
    t2.full_name_zh, 
    t2.full_name_en,
    t2.is_country, 
    t2.alpha_2_code, 
    t2.alpha_3_code, 
    t2.numeric_3_code
FROM 
(
    SELECT country_id, phone_area_code
    FROM ods_global_phone_area_d_f
    WHERE pt='${yesterday}'
) AS t1 
LEFT JOIN 
(
    SELECT 
        `id`, `name_zh`, `name_en`, `full_name_zh`, `full_name_en`,
        `is_country`, `alpha_2_code`, `alpha_3_code`, `numeric_3_code`
    FROM ods_country_region_d_f
    WHERE pt='${yesterday}'
) AS t2 
ON t1.country_id = t2.id
;


