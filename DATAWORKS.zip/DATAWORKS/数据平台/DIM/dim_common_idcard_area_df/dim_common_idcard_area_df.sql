--Serverless Spark SQL
--********************************************************************--
--author: 韩瑞
--create time: 2026-06-16 11:23:41
--Serverless Spark SQL任务只能运行在独享资源组上
--********************************************************************--


CREATE TABLE IF NOT EXISTS dim_common_idcard_area_df
(
    id                    BIGINT COMMENT 'id'
    ,identity_type        INT COMMENT '证件类型(目前只有1，身份证)'
    ,identity_code        STRING COMMENT '证件编码'
    ,country_id           INT COMMENT '国家ID'
    ,country_code         STRING COMMENT '国家编码(英文简称)'
    ,country_name         STRING COMMENT '国家名称'
    ,region_id            INT COMMENT '区域ID'
    ,extra                STRING COMMENT '扩展信息JSON：省、市、区'
    ,idcard_province_code INT COMMENT '证件归属省份编码'
    ,idcard_province_name STRING COMMENT '证件归属省份名称'
    ,idcard_city_code     INT COMMENT '证件归属市编码'
    ,idcard_city_name     STRING COMMENT '证件归属市名称'
    ,idcard_district_code INT COMMENT '证件归属区/县编码'
    ,idcard_district_name STRING COMMENT '证件归属区/县名称'
    ,create_time          TIMESTAMP COMMENT '创建时间'
    ,update_time          STRING COMMENT '更新时间'
)
COMMENT '证件归属城市维度表'
STORED AS ORC
;



INSERT OVERWRITE TABLE dim_common_idcard_area_df
SELECT  id
        ,identity_type
        ,identity_code 
        ,country_id
        ,IF(country_id = 1,'CN',NULL) AS country_code
        ,IF(country_id = 1,'中国','未知') AS country_name
        ,region_id
        ,extra
        ,CAST(GET_JSON_OBJECT(extra,'$.provinceCode') AS INT) AS provice_code
        ,GET_JSON_OBJECT(extra,'$.provinceName') AS provice_name
        ,CAST(GET_JSON_OBJECT(extra,'$.cityCode')  AS INT) AS city_code
        ,GET_JSON_OBJECT(extra,'$.cityName') AS city_name
        ,CAST(GET_JSON_OBJECT(extra,'$.districtCode')  AS INT) AS district_code
        ,GET_JSON_OBJECT(extra,'$.districtName') AS district_name
        ,create_time
        ,update_time
FROM    ods_identity_area_code_d_f 
where pt = '${yesterday}'
-- WHERE   pt = 20260615
;








