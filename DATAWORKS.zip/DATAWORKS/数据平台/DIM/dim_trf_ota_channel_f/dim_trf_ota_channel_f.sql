--Serverless Spark SQL
--********************************************************************--
--author: 韩瑞
--create time: 2026-07-01 19:44:44
--Serverless Spark SQL任务只能运行在独享资源组上
--********************************************************************--




CREATE TABLE IF NOT EXISTS dim_trf_ota_channel_f(
    member_id                 STRING  COMMENT'商户id,为-1为回调地址匹配',
    channel_name              STRING  COMMENT'渠道名称,例如抖音来客/抖音团购',
    loopback_address          STRING  COMMENT'回调地址',
    channel_aggregation_name  STRING  COMMENT'渠道聚合名称，例如抖音/美团',
    target_id                 STRING  COMMENT'渠道聚合id,例如2001/2002',
    rule_code                 STRING  COMMENT'匹配规则，为1使用回调地址匹配，为2使用member_id匹配，都匹配不上则为2000/商家自研'
) COMMENT'ota渠道细分维度表'
STORED AS ORC;

--雷晨手动一次性导入
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','天时同城','sjdzp.com/Api/LocalPiaofutongPush/api.json','天时同城','2001','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','自我游','xyj.link/api/piaofutong/finish.jsp','自我游','2002','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','蚂蚁供销','weitianxia.cn/home/pftdata/pftcallback','蚂蚁供销','2005','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('5624150','京东','-1','京东','2014','2');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('4560136','微盟','-1','微盟','2020','2');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('10141128','高德','-1','高德','2025','2');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('5269593','美团统一预定','-1','美团','2018','2');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('26856539','抖音来客','-1','抖音','2008','2');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('27003241','快手本地生活','-1','快手','2013','2');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('3663752','携程玩乐','-1','携程','2022','2');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('1472','驴妈妈','-1','驴妈妈','2016','2');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('15773020','广州自我游网络科技有限公司','-1','自我游','2002','2');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('1454','同程网','-1','同程网','2021','2');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','自我游','songdu.cc/api/piaofutong/finish.jsp','自我游','2002','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('2574530','北京直客通科技有限公司','-1','直客通','2024','2');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('8808533','杭州快盈信息科技有限公司','-1','杭州快盈','2010','2');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('4701729','成都千千文化旅游发展有限公司','-1','千千文化','2007','2');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('785631','联联永欣科技（成都）有限公司','-1','联联永欣','2015','2');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('3034','南京途牛旅游网','-1','南京途牛','2026','2');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('51603','广州酷旅旅行社有限公司','-1','广州酷旅','2009','2');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','自我游','bmqinzi.cn/api/piaofutong/finish.jsp','自我游','2002','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','自我游','s11.cn/api/piaofutong/finish.jsp','自我游','2002','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','成都千千文化旅游发展有限公司','qqzby.net/v2/pft/order/callback','千千文化','2007','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','自我游','zjktour.net/api/piaofutong/finish.jsp','自我游','2002','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','自我游','qnwer.com/api/piaofutong/finish.jsp','自我游','2002','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','自我游','dgkangfei.com/api/piaofutong/finish.jsp','自我游','2002','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','自我游','ziwoyou.net//api/piaofutong/finish.jsp','自我游','2002','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','抖音来客','12301.cc/group/DouYinLaiKeGate/NoticeDouYinOrderStatus','抖音','2008','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','标点云','shop.biaodianyun.cn/Api/Ticket/ftpOrderVerify','标点云','2004','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','抖音团购','12301.cc/group/DouYinGate/NoticeOrderStatus','抖音','2008','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','天时同城','sjdzp.cn/Api/LocalPiaofutongPush/api.json','天时同城','2001','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','自我游','goyoto.com.cn/api/piaofutong/finish.jsp','自我游','2002','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','自我游','zowoyoo.com//api/piaofutong/finish.jsp','自我游','2002','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','自我游','gxota.com/api/piaofutong/finish.jsp','自我游','2002','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','广州酷旅旅行社有限公司','yaochufa.com/v2/PiaoFuTong/OrderNotice','广州酷旅','2009','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','微程之家','ivcheng.com/msvc-ota/v1/pft/wc-callback/notice','微程之家','2003','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','自我游','seaweed.ziwoyou.net/api/piaofutong/finish.jsp','自我游','2002','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','杭州快盈信息科技有限公司','iuctrip.com/ticket-callback-service/api/callback/pft/update_order','杭州快盈','2010','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','自我游','youwanpai.com/api/piaofutong/finish.jsp','自我游','2002','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','自我游','ziwoyou.net/api/piaofutong/finish.jsp','自我游','2002','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','有赞微商城','12301.cc/group/youzanyun/notice','有赞','2011','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','自我游','showxh.com/api/piaofutong/finish.jsp','自我游','2002','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','鑫海慧科','com/api/push/piaofutong','鑫海慧科','2006','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','自我游','op118.cn/api/piaofutong/finish.jsp','自我游','2002','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','自我游','meijingtx.com/api/piaofutong/finish.jsp','自我游','2002','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','智游宝','zhiyoubao.com/pftTicket/notice','智游宝','2012','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','自我游','coolbetter.cn/api/piaofutong/finish.jsp','自我游','2002','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','自我游','aiyouyou.net/api/piaofutong/finish.jsp','自我游','2002','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','自我游','jmdftour.com/api/piaofutong/finish.jsp','自我游','2002','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','微程之家','ivcheng.com/msvc-ota/v1/pft/hyg-callback/notice','微程之家','2003','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','鑫海慧科','16piao.cn/api/push/piaofutong','鑫海慧科','2006','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','自我游','xiangziyou.com/api/piaofutong/finish.jsp','自我游','2002','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','京东','12301.cc/group/JD/Notice','京东','2014','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','自我游','qudali.com/api/piaofutong/finish.jsp','自我游','2002','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','自我游','jingchengvip.com/api/piaofutong/finish.jsp','自我游','2002','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','自我游','nanzhu.cn/api/piaofutong/finish.jsp','自我游','2002','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','快手本地生活','12301.cc/group/KuaiShouLocalGate/orderNotice','快手','2013','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','快手电商','12301.cc/group/KuaiShouOpenGate/orderNotice','快手','2013','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','自我游','tacytx.com/api/piaofutong/finish.jsp','自我游','2002','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','自我游','fspits.com/api/piaofutong/finish.jsp','自我游','2002','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','联联永欣科技（成都）有限公司','lianlianlvyou.com/v2/pft/order/callback','联联永欣','2015','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','微程之家','ivcheng.com/msvc-ota/v1/pft/vc-callback/notice','微程之家','2003','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','驴妈妈','ubatrip.com/vst_passport/PFTMRSSJCallback.do','驴妈妈','2016','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','自我游','tuxinglvyou.cn/api/piaofutong/finish.jsp','自我游','2002','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','马蜂窝自营','12301.cc/group/MaFengWoZiYingGate/orderNotice','马蜂窝','2017','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','马蜂窝','12301.cc/group/mafengwo/notice','马蜂窝','2017','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','自我游','yunnanyimao.com/api/piaofutong/finish.jsp','自我游','2002','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','自我游','51dzp.cn/api/piaofutong/finish.jsp','自我游','2002','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','美团直连V2','12301.cc/meituanV2/MT_ConsumeNotice.php','美团','2018','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','美团圈圈','12301.cc/group/MeiTuanQuanQuanGate/notice','美团','2018','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','美团统一预定','12301.cc/group/MT_Gate/Order_Notice','美团','2018','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','自我游','qdwmjq.cn/api/piaofutong/finish.jsp','自我游','2002','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','自我游','zowoyoo.com/api/piaofutong/finish.jsp','自我游','2002','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','微程之家','ivcheng.com/api/pft/order/callback','微程之家','2003','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','去哪儿','12301.cc/group/Qunar/notice/','去哪儿','2019','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','标点云','shop.biaodianyun.cn/Api/Ticket/pftTicketNotice','标点云','2004','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','自我游','worldpiao.com/api/piaofutong/finish.jsp','自我游','2002','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','同程网','lvcang.cn/jingqu/OpenAPI/Cooperation/CoopPiaoFuTongOrderCallBackNotice','同程网','2021','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','微程之家','ivcheng.com/msvc-ota/v1/pft/kedou-callback/notice','微程之家','2003','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','微盟','12301.cc/group/weimeng/notice','微盟','2020','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','自我游','888trip.cn/api/piaofutong/finish.jsp','自我游','2002','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','自我游','xalvyou.org/api/piaofutong/finish.jsp','自我游','2002','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','自我游','xly168.net/api/piaofutong/finish.jsp','自我游','2002','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','自我游','wwz.dk/service/bridge-api/e8e36e85-b9ac-920e-912d-86f8dc825671/Q0HRdClCiW39nX3abg5RtObBt8x/65175740/notify-order/api/piaofutong/finish.jsp','自我游','2002','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','自我游','minimaituan.com/api/piaofutong/finish.jsp','自我游','2002','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','携程玩乐','12301.cc/group/ctrip/orderStatusNotice','携程','2022','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','携程网','ctrip.com/ttd-connect-orderentryapi/PiaoFuTong/OrderNotice','携程','2022','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','自我游','ythongyan.cn/api/piaofutong/finish.jsp','自我游','2002','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','自我游','tatalv.com/api/piaofutong/finish.jsp','自我游','2002','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','自我游','1djz.cn/api/piaofutong/finish.jsp','自我游','2002','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','自我游','com.cn/api/piaofutong/finish.jsp','自我游','2002','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','鑫海慧科','bdhyouyou.com/api/push/piaofutong','鑫海慧科','2006','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','自我游','jiuxiangding.com/api/piaofutong/finish.jsp','自我游','2002','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','自我游','sixiju.com/api/piaofutong/finish.jsp','自我游','2002','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','自我游','gdbxyx.cn/api/piaofutong/finish.jsp','自我游','2002','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','自我游','yipiaot.com/api/piaofutong/finish.jsp','自我游','2002','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','自我游','zjhytm.com/api/piaofutong/finish.jsp','自我游','2002','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','口碑网','12301.cc/group/KbGate/Order_Notice','口碑','2023','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','北京直客通科技有限公司','zhiketong.com/Pass/orderBack/PFT','直客通','2024','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','自我游','dfxpw.cn/api/piaofutong/finish.jsp','自我游','2002','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','自我游','jiuchenlvxing.com/api/piaofutong/finish.jsp','自我游','2002','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','自我游','zhily.cn/api/piaofutong/finish.jsp','自我游','2002','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','鑫海慧科','zjbdh.com/api/push/piaofutong','鑫海慧科','2006','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('2175','去哪儿','-1','去哪儿','2019','2');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('28227','美团直连V2','-1','美团','2018','2');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('-1','天时同城','tnci.cc/Api/Duijie/apia/P/Out/5/apiLocalPiaofutongPusha.php','天时同城','2001','1');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('1214','携程网','-1','携程','2022','2');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('9718585','美团圈圈','-1','美团','2018','2');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('1252953','马蜂窝','-1','马蜂窝','2017','2');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('10406130','口碑网','-1','口碑','2023','2');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('13151618','马蜂窝自营','-1','马蜂窝','2017','2');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('12404122','抖音团购','-1','抖音','2008','2');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('12513404','快手','-1','快手','2013','2');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('13913690','抖店','-1','抖音','2008','2');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('15467659','快手电商','-1','快手','2013','2');
-- INSERT INTO TABLE dim_trf_ota_channel_f VALUES ('768763','有赞微商城','-1','有赞','2011','2');










