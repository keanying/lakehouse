--@exclude_input=default_workspace_svwh.dim_common_phone_prefix_area_df
--@exclude_input=default_workspace_svwh.sync_ods_myuu_pft_member_df
--@exclude_input=default_workspace_svwh.sync_ods_myuu_pft_member_extinfo_df
--Serverless Spark SQL
--********************************************************************--
--author: 韩瑞
--create time: 2026-06-08 10:19:51
--Serverless Spark SQL任务只能运行在独享资源组上
--********************************************************************--


-- DROP TABLE IF EXISTS dim_cus_member_info_df;
CREATE TABLE IF NOT EXISTS dim_cus_member_info_df
(
    dim_ins_time                      STRING COMMENT '数据写入时间'
    ,user_id                          INT COMMENT '用户ID (主键)'
    ,user_type                        INT COMMENT '用户类型'
    ,user_name                        STRING COMMENT '用户名称'
    ,user_group_id                    INT COMMENT '用户分组ID'
    ,user_status                      INT COMMENT '用户状态编码'
    ,payment_account_id               STRING COMMENT '用户所使用的支付账户ID'
    ,user_sign_coop_mode_id           BIGINT COMMENT '用户签约合作模式编码'
    ,register_source_id               INT COMMENT '注册来源编码'
    ,user_used_date                   STRING COMMENT '启用日期'
    ,user_scenic_topic                STRING COMMENT '用户景区主题'
    ,user_level                       STRING COMMENT '用户等级'
    ,business_type                    SMALLINT COMMENT '业态类型'
    ,types                            SMALLINT COMMENT '类型/级别'
    ,distribute_system_type           STRING COMMENT '分销系统类型'
    ,distribute_system_name           STRING COMMENT '分销系统名称'
    ,business_scope                   STRING COMMENT '经营范围'
    ,company_name                     STRING COMMENT '公司名称'
    ,company_abbr                     STRING COMMENT '公司简称'
    ,website_url                      STRING COMMENT '公司官网地址'
    ,dcode_url                        STRING COMMENT '回调地址'
    ,login_account                    STRING COMMENT '登录账号'
    ,contact_name                     STRING COMMENT '联系人姓名'
    ,contact_mobile                   STRING COMMENT '联系用手机号码'
    ,contact_tel                      STRING COMMENT '联系人电话'
    ,billing_account_name             STRING COMMENT '账务账户名称'
    ,customer_service_hotline         STRING COMMENT '热线电话'
    ,customer_id                      STRING COMMENT '客户ID'
    ,customer_company_type_id         INT COMMENT '客户公司类型编码'
    ,customer_type                    STRING COMMENT '客户类型'
    ,contract_department_id           INT COMMENT '签约合同所属部门'
    ,voucher_order_mode_id            INT COMMENT '凭证费订单模式类型'
    ,voucher_payer_id                 INT COMMENT '付凭证费人员编码'
    ,platform_fee_amt                 DECIMAL(10,6) COMMENT '平台使用费'
    ,third_party_fee_amt              DECIMAL(10,6) COMMENT '第三方支付费用'
    ,sms_unit_price                   DECIMAL(10,6) COMMENT '短信每条收费'
    ,voucher_fee                      DECIMAL(10,6) COMMENT '凭证费费用'
    ,warning_amount                   DECIMAL(12,0) COMMENT '预警金额'
    ,account_create_time              STRING COMMENT '账号创建时间'
    ,account_last_login_time          STRING COMMENT '最近登录时间'
    ,customer_certi_status_code       INT COMMENT '会员认证状态编码:0=未认证,1=审核中,2=—已认证（审核通过）,3=拒绝'
    ,customer_certi_status            STRING COMMENT '会员认证状态名称'
    ,signer_id                        INT COMMENT '签单人id'
    ,servicer_id                      INT COMMENT '客服id'
    ,gathering_self_way               STRING COMMENT '独立收款-收款方式名称'
    ,is_user_open_datav               INT COMMENT '是否开通大屏[0未开通,1开通]'
    ,is_user_bind_taobao              INT COMMENT '是否绑定淘宝'
    ,is_resource_center_auto_get_user INT COMMENT '资源中心自动拉取产品商户 1是/0否'
    ,is_operate_user                  INT COMMENT '是否运营客户[0否,1是]'
    ,is_test_user                     INT COMMENT '是否测试账号[1测试,0正式]'
)
comment '会员信息维度表'
stored as orc
;

INSERT OVERWRITE TABLE dim_cus_member_info_df
SELECT  DATE_FORMAT(CURRENT_TIMESTAMP(),'yyyy-MM-dd HH:mm:ss') AS dim_ins_time
--===================================用户属性===================================
        --用户ID (主键)
        ,t1.user_id
        --用户类型
        ,t1.user_type
        --用户名称
        ,t1.user_name
        --用户分组ID
        ,t1.user_group_id
        -- 用户状态编码
        ,t1.user_status
        -- 用户所使用的支付账户ID
        ,t1.payment_account_id
        -- 用户签约合作模式编码
        ,t1.user_sign_coop_mode_id
        -- 注册来源编码 
        ,t1.register_source_id
        -- 启用日期
        ,substr(FROM_UNIXTIME(t5.enable_time,'yyyy-MM-dd'),1,10)              as user_used_date    
        -- 用户景区主题
        ,t15.name                                                           as user_scenic_topic
        --用户等级
        ,t16.name                                                           as user_level
        -- 业态类型
        ,t1.business_type
        -- 类型/级别
        ,t1.types
        -- 分销系统类型
        ,t1.distribute_system_type
        -- 分销系统名称
        ,t1.distribute_system_name
        -- 经营范围
        ,t1.business_scope
        -- 公司名称
        ,t1.company_name
        -- 公司简称
        ,t1.company_abbr
        -- 公司官网地址 
        ,t1.website_url
        --回调地址
        ,t1.dcodeURL
        -- 登录账号
        ,t1.login_account
        -- 联系人姓名 
        ,t1.contact_name
        -- 联系用手机号码 
        ,t1.contact_mobile
        -- 联系人电话 
        ,t1.contact_tel
        -- 账务账户名称
        ,t1.billing_account_name
        -- 热线电话
        ,t1.hotline                                                     AS customer_service_hotline
--===================================客户信息===================================
        -- 客户ID
        ,t1.customer_id
        -- 客户公司类型编码 
        ,t1.customer_company_type_id
        -- 客户类型
        ,t14.name                                                           as customer_type     
        -- 签约合同所属部门
        ,t1.contract_department_id
        -- 凭证费订单模式类型
        ,t1.voucher_order_mode_id
        -- 付凭证费人员编码
        ,t1.voucher_payer_id
        -- 平台使用费
        ,t1.platform_fee_amt
        -- 第三方支付费用
        ,t1.third_party_fee_amt
        -- 短信每条收费
        ,t1.sms_unit_price
        -- 凭证费费用
        ,t1.voucher_fee
        -- 预警金额 
        ,t1.warning_amount
        -- 账号创建时间
        ,t1.account_create_time
        -- 最近登录时间
        ,t1.account_last_login_time
        -- 资质审核状态编码
        ,t4.certi_status                                                    as customer_certi_status_code 
        -- 资质审核状态
        ,case t4.certi_status
                when 0 then '未认证'
                when 1 then '审核中'
                when 2 then '已认证'
                when 3 then '拒绝'
        end                                                                 as customer_certi_status     
--===================================商户平台合作及服务人员===================================  
        -- 签单人id
        ,t1.signer_id  
        -- -- 签单人名字
        -- ,t6.plat_staff_name                                                  as  signer
        -- -- 签单人所属区域                               
        -- ,t6.plat_staff_group                                                 as  signer_region   
        -- -- 签单人OA上二级分组                        
        -- ,t6.plat_staff_team_oa                                               as  signer_team_oa
        -- -- 签单人部门
        -- ,t6.plat_staff_department                                            as  signer_department
        -- 客服id
        ,t1.servicer_id
        -- -- 客服名字
        -- ,t7.plat_staff_name                                                  as  servicer   
        -- -- 客功OA上二级分组                      
        -- ,t7.plat_staff_team_oa                                               as  servicer_team_oa
        -- -- 客功部门
        -- ,t7.plat_staff_department                                            as  servicer_department
        --独立收款
        ,t10.channel_name                                                    as gathering_self_way       
        --是否开通大屏[0未开通,1开通]
        ,if(t11.user_id IS NOT NULL ,1,0)                                    as is_user_open_datav        
        --是否绑定淘宝
        ,if(t12.user_id IS NOT NULL ,1,0)                                    as is_user_bind_taobao    
        --资源中心自动拉取产品商户 是/否
        ,if(t13.user_id IS NOT NULL ,1,0)                                    as is_resource_center_auto_get_user       
        --是否运营客户
        ,if(t17.ptid is NOT NULL,1,0)                                        as is_operate_user
        --是否测试账号1正式0测试
        ,user_is_test                                                        AS is_test_user 
FROM (
        SELECT t1.id AS user_id
                ,NVL(t1.dtype,-1) AS user_type
                ,NVL(t1.dname,'') AS user_name
                ,IF(t1.group_id = '2' OR t1.account = '70801726',1,0) AS user_group_id
                ,NVL(t1.status,-1) AS user_status
                ,NVL(t1.account_id,'') AS payment_account_id
                ,NVL(t1.customer_id,'') AS customer_id
                ,NVL(t2.corp_kind,0) AS customer_company_type_id
                ,t2.format_type     AS business_type
                ,t2.types
                ,CASE   WHEN t1.id = 3034 THEN 'OTA'
                        WHEN t1.dcodeURL <> '' THEN IF(t3.distribute_system_type IS NULL,'其他分销平台',t3.distribute_system_type)
                        ELSE NULL
                END AS distribute_system_type
                ,IF(t1.id = 3034,'南京途牛',t3.distribute_system_name) AS distribute_system_name
                ,NVL(t2.com_name,'') AS company_name
                ,NVL(t2.short_company_name,'') AS company_abbr
                ,NVL(t2.website,'') AS website_url
                ,t1.dcodeURL
                ,NVL(t1.account,'') AS login_account
                ,NVL(t1.cname,'') AS contact_name
                ,NVL(t1.mobile,'') AS contact_mobile
                ,NVL(t1.ctel,'') AS contact_tel
                ,NVL(t2.finance_name,'') AS billing_account_name
                ,NVL(t2.hotline,'') AS hotline
                ,INT(IF(t1.salesid=0,NULL,t1.salesid))                               AS signer_id                        -- 签单人id
                ,INT(IF(t1.kefuID=0,NULL,t1.kefuID))                                        AS servicer_id                -- 客服id
                ,NVL(t2.business,'') AS business_scope
                ,NVL(t1.reg_source,1) AS register_source_id
                ,NVL(t2.contract_model,0) AS user_sign_coop_mode_id
                ,NVL(t2.contract_depart,0) AS contract_department_id
                ,NVL(t2.cooperate_type,0) AS voucher_order_mode_id
                ,NVL(t1.fee_pay_way,0) AS voucher_payer_id
                ,CAST(NVL(t1.fee_platform,0) * 1.000000 / 100.0 AS DECIMAL(10,6)) AS platform_fee_amt
                ,CAST(NVL(t1.fee_bank,0) AS DECIMAL(10,6)) AS third_party_fee_amt
                ,CAST(NVL(t1.fee_sms,0) * 1.000000 / 100.0 AS DECIMAL(10,6)) AS sms_unit_price
                ,CAST(NVL(t1.fee_code,0) * 1.000000 / 100.0 AS DECIMAL(10,6)) AS voucher_fee
                ,NVL(t2.early_warning,0) AS warning_amount
                ,IF(t1.creattime != '0000-00-00 00:00:00',t1.creattime,'') AS account_create_time
                ,IF(t1.lasttime != '0000-00-00 00:00:00',t1.lasttime,'') AS account_last_login_time
                -- ,IF(
                --         t1.group_id in (2,3) OR (
                --                 NVL(t2.com_name,'') REGEXP '测试' 
                --                 OR NVL(t2.com_name,'') REGEXP 'test' 
                --                 OR NVL(t2.short_company_name,'') REGEXP '测试' 
                --                 OR NVL(t2.short_company_name,'') REGEXP 'test' 
                --         )
                --         ,1
                --         ,0
                -- )                              
                ,IF(t1.group_id in (2,3),1,0) as user_is_test

                ,t2.province
                ,t2.city
                ,t2.country
                ,t2.ext
        --用户主信息
        FROM    ods_myuu_pft_member_df t1
        --用户扩展信息
        LEFT JOIN ods_myuu_pft_member_extinfo_df t2
        ON      t1.id = t2.fid
        --回调地址枚举值
        LEFT JOIN dim_cus_enum_dcodeurl_of t3
        ON      t1.dcodeURL LIKE CONCAT('%',t3.dcodeurl_like,'%')
) t1
--资质认证-客户
left join (
        select customer_id,certi_status 
        from ods_myuu_pft_customer_certification_d_f 
        where pt='${yesterday}'
) t4 
on t4.customer_id=t1.customer_id
--商户启用时间
left join  (
        select distinct fid,enable_time 
        from ods_myuu_pft_supplier_extinfo_d_f 
        where pt ='${yesterday}'
        and enable_time IS NOT NULL 
) as t5  
on t5.fid=t1.user_id  
-- --签单人
-- left JOIN  (
--         select plat_staff_id,plat_staff_name,plat_staff_group,plat_staff_team_oa,plat_staff_department
--         from dim_plat_staff_d_f 
--         where pt =20260628
-- ) as t6   
-- on t1.signer_id=t6.plat_staff_id  
-- --客服姓名
-- left JOIN  (
--         select plat_staff_id,plat_staff_name,plat_staff_team_oa,plat_staff_department 
--         from dim_plat_staff_d_f where  pt =20260628
-- ) as t7   
-- on t1.servicer_id=t7.plat_staff_id
--联系人手机号归属地区
left join  dim_common_phone_prefix_area_df as t8 
on t8.phone_prefix_number=substr(t1.contact_mobile,1,7)
-- -- 仅配置直辖市的情况
-- left join  (select * from dim_province_d_f where pt =20260628 ) as p1 on p1.province_code=me.province 
-- -- 对于country 为null 的补"0"
-- left join  (select province_name,city_name,country_name,province_code,city_code,country_code  
--             from dim_city_d_f  
--             where pt =20260628 ) as c on c.province_code=me.province and c.city_code=me.city and c.country_code=if(isnull(me.country),'0',me.country)
-- LEFT join (
--         select fid,com_name,contract_model,corp_kind,province,city,country,hotline,format_type,types,
--                   if(ext like '%source_user%',substr(ext,locate('source_user',ext,1)+14,1) ,null) tourist_source
--         from ods_myuu_pft_member_extinfo_d_f where pt=20260628 
-- ) as me  
-- on m.user_id = me.fid
-- 商户独立收款
LEFT join (
        select distinct member_id,channel_name 
        from ods_pft001_pft_merchant_payment_method_d_f 
        where pt = '${yesterday}'
) as t10  
on t1.user_id = t10.member_id
-- 开通数据大屏
left join (
        select * 
        from ods_datav_auth_d_f 
        where pt = '${yesterday}'
) t11 
on t11.user_id=t1.user_id
--绑定淘宝
left join (
        select distinct id2  as user_id from ods_pft_open_pft_tb_bind_df
) t12
on t12.user_id=t1.user_id
--资源中心自动拉取产品商户
left join (
        select distinct user_id from ods_resource_center_auto_get_user_d_f where pt = '${yesterday}'
) t13 
on t13.user_id=t1.user_id
-- 企业类型
left join (
        select * from ods_pft_common_dict_d_f where pt = '${yesterday}' and dict_type='cType'
) t14 
on t14.code=t1.customer_company_type_id 
-- 景区业态
left join (
        select * from ods_pft_common_dict_d_f where pt = '${yesterday}' and dict_type='format' and parent_dict_type='cType'
) t15 
on t15.code=t1.business_type  
and t15.parent_code=t1.customer_company_type_id 
-- 级别
left join (
        select * from ods_pft_common_dict_d_f where pt = '${yesterday}' and dict_type='type' and parent_dict_type='cType'
) t16 
on t16.code=t1.types  
and t16.parent_code=t1.customer_company_type_id 
-- 运营接收客户
left join (
        select distinct ptid from ods_bi_rds_oa_ecology_uf_xkhjjdtz_df where sfqrjs=0
) t17 
on t17.ptid=t1.user_id
;





