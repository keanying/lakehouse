--Serverless Spark SQL
--********************************************************************--
--author: 韩瑞
--create time: 2026-06-22 19:25:44
--Serverless Spark SQL任务只能运行在独享资源组上
--********************************************************************--


-- DROP TABLE if EXISTS dim_attr_ticket_info_df;
CREATE TABLE IF NOT EXISTS dim_attr_ticket_info_df
(
    dim_ins_time                STRING COMMENT '插入时间'
    ,product_id                 INT COMMENT '产品ID'
    ,apply_did                  STRING COMMENT '供应商ID'
    ,gid                        INT COMMENT '商品id'
    ,ticket_id                  INT COMMENT '票ID'
    ,ticket_name                STRING COMMENT '票名称'
    ,ticket_tprice              STRING COMMENT '市场价'
    ,ticket_fullname            STRING COMMENT '票全称=景区名称+“-”+票名称'
    ,ticket_status_code         INT COMMENT '票状态编码[1上架, 2下架, 6删除]'
    ,is_package_ticket          INT COMMENT '是否组合套票[1:是,0:否]'
    ,ticket_package_type        INT COMMENT '组合类型[0:单票,1:套票中的主票,2:套票中的子票,3:1+2情况]'
    ,ticket_max_expiration_date STRING COMMENT '票最大过期日期'
    ,ticket_update_time         STRING COMMENT '创建/更新时间'
    ,resource_id                INT COMMENT '资源ID'
    ,scenic_id                  INT COMMENT '景区ID'
    ,scenic_name                STRING COMMENT '景区名称'
    ,scenic_status_code         INT COMMENT '景区状态编码[1:上架,2:下架,3:过期,4:删除,0:新增状态]'
    ,scenic_publisher_id        INT COMMENT '景区发布商ID'
    ,scenic_publisher_name      STRING COMMENT '景区发布商账户名称'
    ,scenic_area_code           STRING COMMENT '景区区域编码'
    ,scenic_province_code       INT COMMENT '景区省编码'
    ,scenic_province_name       STRING COMMENT '景区省名称'
    ,scenic_city_code           INT COMMENT '景区城市编码'
    ,scenic_city_name           STRING COMMENT '景区城市名称'
    ,scenic_district_code       INT COMMENT '景区区县编码'
    ,scenic_district_name       STRING COMMENT '景区区县名称'
    ,scenic_type_code           STRING COMMENT '景区类型编码'
    ,scenic_type_name           STRING COMMENT '景区类型'
    ,scenic_level_code          STRING COMMENT '景区级别编码'
    ,scenic_level               STRING COMMENT '景区级别'
    ,scenic_topic               STRING COMMENT '景区主题'
    ,scenic_is_test             STRING COMMENT '是否测试[1测试0正式]'
    ,ticket_is_test             INT COMMENT '是否测试票[1:测试,0:正式]'
    ,resource_scenic_id         INT COMMENT '业态景区id'
    ,resource_scenic_name       STRING COMMENT '业态景区名称'
    ,scenic_topic_list          STRING COMMENT '主题列表'
    ,belong_area                STRING COMMENT '归属区域'
    ,resource_scenic_add_time   STRING COMMENT '业态景区关联时间'
)
COMMENT '票信息维度表+景区维度信息'
STORED AS ORC
;


-- 是否组合套票  是/否
-- 组合类型     0:单票,1:套票中的主票,2:套票中的子票,3:1+2情况

INSERT OVERWRITE TABLE dim_attr_ticket_info_df
SELECT  
        CURRENT_DATE                                         AS dw_ins_time
        ,t1.pid                                               AS product_id
        ,t1.apply_did                                         AS apply_did
        ,t1.gid                                               AS gid
        ,t1.id                                                AS ticket_id
        ,t1.title                                             AS ticket_name
        ,t1.tprice                                            AS ticket_tprice
        ,CONCAT(t2.scenic_name,"-",t1.title)                    AS ticket_fullname
        ,t1.status                                            AS ticket_status_code
        ,IF(
            t3.parent_tid IS NOT NULL OR t4.tid IS NOT NULL 
            ,1
            ,0
        ) AS is_package_ticket
        ,CASE 
            WHEN t3.parent_tid IS NOT NULL AND t4.tid IS NOT NULL THEN 3
            WHEN t3.parent_tid IS NULL AND t4.tid IS NOT NULL THEN 2
            WHEN t3.parent_tid IS NOT NULL AND t4.tid IS NULL THEN 1
            WHEN t3.parent_tid IS NULL AND t4.tid IS NULL THEN 0
        ELSE NULL END AS ticket_package_type
        ,t1.max_expiration_date                               AS ticket_max_expiration_date
        ,FROM_UNIXTIME(t1.update_time)                        AS ticket_update_time
        ,t2.resource_id                                       AS resource_id
        ,t2.scenic_id                                         AS scenic_id
        ,t2.scenic_name                                         AS scenic_name
        ,t2.scenic_status_code                                  AS scenic_status_code
        ,t2.scenic_publisher_id                                 AS scenic_publisher_id
        ,t2.scenic_publisher_name                               AS scenic_publisher_name
        ,t2.scenic_area_code                                    AS scenic_area_code
        ,t2.scenic_province_code                                AS scenic_province_code
        ,t2.scenic_province_name                                AS scenic_province_name
        ,t2.scenic_city_code                                    AS scenic_city_code
        ,t2.scenic_city_name                                    AS scenic_city_name
        ,t2.scenic_district_code                                AS scenic_district_code
        ,t2.scenic_district_name                                AS scenic_district_name
        ,t2.scenic_type_code                                    AS scenic_type_code
        ,t2.scenic_type_name                                    AS scenic_type_name
        ,t2.scenic_level_code                                   AS scenic_level_code
        ,t2.scenic_level                                        AS scenic_level
        ,t2.scenic_topic                                        AS scenic_topic
        ,t2.is_test                                             AS scenic_is_test
        ,IF(t1.title LIKE '%测试%' OR t2.is_test = 1,1,0)        AS ticket_is_test
        ,t2.resource_scenic_id                                  AS resource_scenic_id
        ,t2.resource_scenic_name                                AS resource_scenic_name
        ,t2.scenic_topics                                       AS scenic_topic_list
        ,t2.belong_area                                         AS belong_area
        ,t2.resource_scenic_add_time                            AS resource_scenic_add_time
FROM    (
    SELECT  id
            ,pid
            ,landid AS scenic_id
            ,apply_did
            ,gid
            ,tprice
            ,title
            ,status
            ,max_expiration_date
            ,update_time
    FROM    ods_myuu_uu_jq_ticket_df
    WHERE   pt = '${yesterday}'
) t1
LEFT JOIN   dim_attr_scenic_info_df t2
ON      t2.scenic_id = t1.scenic_id
LEFT JOIN (
    SELECT distinct parent_tid 
    FROM ods_myuu_pft_package_tickets_df 
    WHERE pt = DATE_FORMAT(DATE_SUB(CURRENT_DATE(), 1),"yyyyMMdd")
) t3
ON t1.id = t3.parent_tid
LEFT JOIN (
    SELECT distinct tid 
    FROM ods_myuu_pft_package_tickets_df 
    WHERE pt = DATE_FORMAT(DATE_SUB(CURRENT_DATE(), 1),"yyyyMMdd")
    AND parent_tid <> tid
) t4
ON t1.id = t4.tid
;







