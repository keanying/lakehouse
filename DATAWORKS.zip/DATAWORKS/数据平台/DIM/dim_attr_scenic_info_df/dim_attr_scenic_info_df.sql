--Serverless Spark SQL
--********************************************************************--
--author: 韩瑞
--create time: 2026-06-08 14:42:27
--Serverless Spark SQL任务只能运行在独享资源组上
--********************************************************************--

-- DROP TABLE if EXISTS  dim_attr_scenic_info_df;

-- 1.ods层表没有完全上线
--     新ods流程
-- 2.字段命名+表命名规范
-- 3.经纬度信息、邮政编码、后期可添加
-- DROP TABLE dim_attr_scenic_info_df;
CREATE TABLE IF NOT EXISTS dim_attr_scenic_info_df
(
    dim_ins_time            STRING COMMENT '插入时间'
    ,scenic_id              INT COMMENT '景区ID'
    ,scenic_name            STRING COMMENT '景区名称'
    ,scenic_status_code     INT COMMENT '景区状态编码[1:上架,2:下架,3:删除,4:新增]'
    ,scenic_publisher_id    INT COMMENT '景区发布商ID'
    ,scenic_publisher_name  STRING COMMENT '景区发布商账户名称'
    ,scenic_type_code       STRING COMMENT '景区类型编码[A:景区,B:线路,C:酒店,F:套票,G:餐饮,H:演出,I:年卡,J:特产,K:计时产品]'
    ,scenic_type_name       STRING COMMENT '景区类型'
    ,scenic_level_code      STRING COMMENT '景区级别编码'
    ,scenic_level           STRING COMMENT '景区级别'
    ,scenic_topic           STRING COMMENT '主题列表第一个主题'
    ,scenic_area_code       STRING COMMENT '景区区域代码'
    ,scenic_province_code   INT COMMENT '景区省编码'
    ,scenic_province_name   STRING COMMENT '景区省名称'
    ,scenic_city_code       INT COMMENT '景区城市编码'
    ,scenic_city_name       STRING COMMENT '景区城市名称'
    ,scenic_district_code   INT COMMENT '景区区县编码'
    ,scenic_district_name   STRING COMMENT '景区区县名称'
    -- ,scenic_lng             STRING COMMENT '景区经度'
    -- ,scenic_lat             STRING COMMENT '景区维度'
    -- ,scenic_zip_code        STRING COMMENT '景区市邮政编码'
    -- ,scenic_province_adcode STRING COMMENT '景区省邮政编码'
    ,resource_id            INT COMMENT '资源ID'
    ,is_test           STRING COMMENT '是否测试[1测试0正式]'
    ,resource_scenic_id       INT COMMENT '业态景区id'
    ,resource_scenic_name     INT COMMENT '业态景区名称'
    ,scenic_topics         STRING COMMENT '主题列表'
    ,belong_area            STRING COMMENT '归属区域'
    ,resource_scenic_add_time STRING COMMENT '业态景区关联时间'
)
COMMENT '景区维表'
STORED AS ORC
;


INSERT OVERWRITE TABLE dim_attr_scenic_info_df 
SELECT   
     CURRENT_DATE                                            AS dw_ins_time
    ,t1.id                                                   AS scenic_id
    ,t1.title                                                AS scenic_name
    ,t1.status                                               AS scenic_status_code
    ,t1.apply_did                                            AS scenic_publisher_id
    ,t3.user_name                                            AS scenic_publisher_name
    ,t1.p_type                                               AS scenic_type_code
    ,t2.resource_type_name                                   AS scenic_type_name
    ,t1.jtype                                                AS scenic_level_code
    ,IF(t1.jtype IN ('0', ''), '其他', t1.jtype)              AS scenic_level
    ,IF(ISNULL(topic.land_topic_name), t1.land_topic, topic.land_topic_name)  AS scenic_topic
    ,t1.area                                                 AS scenic_area_code
    ,t1.area_province_code                                       AS scenic_province_code
    ,p.province_name                                             AS scenic_province_name
    ,t1.area_city_code                                           AS scenic_city_code
    ,c.city_name                                                 AS scenic_city_name
    ,t1.area_district_code                                       AS scenic_district_code
    ,d.district_name                                             AS scenic_district_name
    ,t1.resourceID                                               AS resource_id
    ,IF(t1.title LIKE '%测试%' OR t1.title LIKE '%压测%' OR t3.is_test_user=0,1,0)             AS is_test
    ,mr.mt_id                                                    AS resource_scenic_id
    -- 仅当 resource_land_name 是纯数字字符串时可用
    ,CAST(rt1.resource_land_name AS INT)                         AS resource_scenic_name
    ,t1.topic                                                    AS scenic_topics
    ,di.district                                                 AS belong_area
    ,mr.create_time                                              AS resource_scenic_add_time
FROM 
(
    SELECT  id
            ,title
            ,status
            ,apply_did
            ,p_type
            ,jtype
            ,area
            ,resourceID
            ,SPLIT(topic,",")[0] AS land_topic
            ,topic
            ,cast(split_part(area,'|',1) AS INT) as area_province_code
            ,cast(split_part(area,'|',2) AS INT) as area_city_code
            ,cast(split_part(area,'|',3) AS INT) as area_district_code
    FROM    ods_myuu_uu_land_df
    where insert_date = '${yesterday}'
) AS t1  
LEFT JOIN dim_scenic_enum_resource_type_of AS t2  
ON t2.resource_type = t1.p_type    
LEFT JOIN dim_cus_member_info_df t3
ON t3.user_id = t1.apply_did     
-- 暂时使用dim_city_d_f表,后期接入业务表生成新流程                                                                
LEFT JOIN 
(
    select DISTINCT province_code, province_name 
    from dim_city_d_f 
    where pt ='${yesterday}'
) AS p 
ON p.province_code = t1.area_province_code
LEFT JOIN 
(
    select DISTINCT city_code, city_name 
    from dim_city_d_f 
    where pt ='${yesterday}'
) AS c
ON c.city_code = t1.area_city_code
LEFT JOIN 
(
    select DISTINCT district_code, district_name 
    from dim_city_d_f 
    where pt ='${yesterday}'
) AS d
ON d.district_code = t1.area_district_code
LEFT JOIN dim_scenic_enum_topic_of AS topic  
ON topic.land_topic = t1.land_topic 
LEFT JOIN 
(
    -- 规则后期需确认
    SELECT pmr.land_id,pmr.mt_id,pmr.create_time 
    FROM (SELECT * FROM ods_pft_management_resource_d_f WHERE pt ='${ds}') AS pmr
    JOIN (SELECT land_id,MAX(id) max_id FROM ods_pft_management_resource_d_f WHERE pt ='${ds}' GROUP BY land_id) AS pmr2 
    ON pmr2.max_id = pmr.id
) AS mr 
ON mr.land_id = t1.id                                
LEFT JOIN 
(
    SELECT * 
    FROM dim_resource_land_d_f 
    WHERE pt ='${yesterday}'
) AS rt1 
ON rt1.resource_land_id = mr.mt_id 
-- 关联归属区域
LEFT JOIN dim_resource_center_district_o_f AS di 
ON p.province_name=di.province
;



