--Serverless Spark SQL
--********************************************************************--
--author: 韩瑞
--create time: 2026-06-16 10:14:59
--Serverless Spark SQL任务只能运行在独享资源组上
--********************************************************************--

CREATE TABLE IF NOT EXISTS dim_common_phone_prefix_area_df
(
    stat_date            STRING COMMENT '统计日期'
    ,dw_ins_time         STRING COMMENT '插入时间'
    ,phone_prefix_number INT COMMENT '手机号前7位'
    ,`type`              STRING COMMENT '1=移动，2=联通，3=电信，4= 电信虚拟运营商，5=联通虚拟运营商，6=移动虚拟运营商'
    ,area_code           INT COMMENT '区域编码'
    ,pft_area_code       STRING COMMENT '区域编码：省编码|市编码|区县编码'
    ,zip_code            STRING COMMENT '邮编'
    ,phone_province_code INT COMMENT '号段归属省份编码'
    ,phone_province_name STRING COMMENT '号段归属省份名称'
    ,phone_city_code     INT COMMENT '号段归属市编码'
    ,phone_city_name     STRING COMMENT '号段归属市名称'
    ,phone_district_code INT COMMENT '号段归属区/县编码'
    ,phone_district_name STRING COMMENT '号段归属区/县名称'
    ,country_code        INT COMMENT '国家编码'
    ,country_name        STRING COMMENT '国家名称'
    ,lng                 STRING COMMENT '经度'
    ,lat                 STRING COMMENT '纬度'
)
COMMENT '手机号号段归属城市维度表'
STORED AS ORC
;



INSERT OVERWRITE TABLE dim_common_phone_prefix_area_df
SELECT  '${yesterday}' AS stat_date
        ,CURRENT_DATE AS dw_ins_time
        ,number AS phone_prefix_number
        ,`type` AS type
        ,area_code AS area_code
        ,pft_area_code AS pft_area_code
        ,zip_code AS zip_code
        ,province_code AS phone_province_code
        ,province_name AS phone_province_name
        ,city_code AS phone_city_code
        ,city_name AS phone_city_name
        ,NULL AS phone_district_code
        ,NULL AS phone_district_name
        ,country_code AS country_code
        ,country_name AS country_name
        ,lng AS lng
        ,lat AS lat
FROM    s_city_phone_fixed_d_f
WHERE   pt = '${yesterday}'
;


-- number 唯一添加数据质量
-- SELECT number,COUNT(*)
-- FROM s_city_phone_fixed_d_f
-- where pt = 20260615
-- GROUP BY number
-- HAVING COUNT(*) > 1
-- ;

-- 1/2/3
-- SELECT DISTINCT type
-- FROM s_city_phone_fixed_d_f
-- where pt = 20260615
-- ;

