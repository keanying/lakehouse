--Serverless Spark SQL
--********************************************************************--
--author: 韩瑞
--create time: 2026-08-03 11:16:17
--Serverless Spark SQL任务只能运行在独享资源组上
--********************************************************************--

-- CREATE TABLE `dim_common_supplier_scenic_ticket_f` (
--   `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
-- 	`apply_did` varchar(64)   COMMENT '供应商ID',
-- 	`user_name` varchar(64)  COMMENT '供应商名称',
-- 	`user_company_name` varchar(64)  COMMENT '供应商公司名称',
-- 	`scenic_name` varchar(64) DEFAULT 0 COMMENT '景区名称',
-- 	`ticket_name` varchar(128) DEFAULT 0 COMMENT '票名称',
--     `etl_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'ETL更新时间',
--   PRIMARY KEY (`id`),
--   KEY `idx_scenic_id` (`apply_did`)
-- ) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='供应商+票+景区信息维度表';



DROP table if EXISTS  dim_common_supplier_scenic_ticket_f;
CREATE TABLE IF NOT EXISTS dim_common_supplier_scenic_ticket_f
(
    apply_did                  STRING COMMENT '供应商ID'
    ,user_name                  STRING COMMENT '供应商名称'
    ,user_company_name      STRING COMMENT '供应商公司名称'
    ,scenic_id                  INT COMMENT '景区ID'
    ,scenic_name                STRING COMMENT '景区名称'
    -- ,ticket_id                  INT COMMENT '票ID'
    ,ticket_name                STRING COMMENT '票名称'
   
)
COMMENT '供应商+票+景区信息维度表'
STORED AS ORC
;

INSERT OVERWRITE TABLE dim_common_supplier_scenic_ticket_f
SELECT  DISTINCT
    t1.apply_did
    ,t2.user_name
    ,t2.company_name as user_company_name
    ,t1.scenic_id
    ,t1.scenic_name
    -- ,t.ticket_id
    -- ,t1.ticket_id
    ,t1.ticket_name
FROM    (
    SELECT DISTINCT
    `tid` as ticket_id
  FROM s_tourist_track_d_i
  WHERE 1=1
  AND insertdate >= 20260731
  AND track_action = 1
) t
LEFT JOIN dim_attr_ticket_info_df t1
ON t.ticket_id = t1.ticket_id
LEFT JOIN dim_cus_member_info_df t2
ON      t1.apply_did = t2.user_id
-- WHERE   t1.ticket_is_test = 0
-- AND     t1.ticket_status_code = 1
-- and     t1.scenic_is_test = 0
-- AND     t2.user_name NOT LIKE  '%测试%' 
-- AND     t2.user_name NOT LIKE  '%test%' 
-- AND     t2.user_name NOT LIKE  '%demo%' 
-- AND     t2.company_name NOT LIKE  '%测试%' 
-- AND     t2.company_name NOT LIKE  '%test%' 
WHERE t1.scenic_type_code = 'A'
;








