--Serverless Spark SQL
--********************************************************************--
--author: 王海阳
--create time: 2026-04-02 11:22:51
--Serverless Spark SQL任务只能运行在独享资源组上
--********************************************************************--
CREATE TABLE IF NOT EXISTS dws_ord_scenic_package_sub_ticket_use_di
(
    `sup_id`                   INT     COMMENT '供应商ID【sid】',
    `scenic_id`                INT     COMMENT '景区ID【lid】',
    `ticket_id`                INT     COMMENT '门票ID【tid】',
    `reserved_visit_time`      STRING  COMMENT '预计游玩时间【playdate】',

    -- LID 维度汇总（同一景区、同一游玩日下所有 tid 合计）
    `pay_ticket_cnt`           BIGINT  COMMENT '总支付总票数',
    `reserve_ticket_cnt`       BIGINT  COMMENT '总预定总票数',

    -- 套票子票维度（子单人数，用于你的原始需求）
    `sub_pay_ticket_cnt`       BIGINT  COMMENT '子票支付票数',
    `sub_reserve_ticket_cnt`   BIGINT  COMMENT '子票预定票数'
)
COMMENT '景区-门票-游玩日期-下单日 人数统计表(套票+子票维度)'
PARTITIONED BY (`travel_date` INT COMMENT '数据日期分区')
STORED AS ORC;

REFRESH TABLE dws_ord_scenic_pkg_sub_ticket_reserve_di;
-- =====================================================================
-- 目标表: dws_ord_scenic_package_sub_ticket_use_di
-- 功能: 景区+门票+下单日+游玩日 人数统计
-- 数据来源: dwd_order_by_playtime_d_i（纯等值分区过滤，无范围扫描）
-- =====================================================================
INSERT OVERWRITE TABLE dws_ord_scenic_package_sub_ticket_use_di PARTITION(travel_date = ${ds})
SELECT
    sup_id                                                                         AS sup_id,
    scenic_id                                                                      AS scenic_id,
    ticket_id                                                                      AS ticket_id,
    -- travel_date 即游玩日期，格式化为 yyyy-MM-dd 与目标表字段对齐
    DATE_FORMAT(TO_DATE(CAST(travel_date AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd')    AS reserved_visit_time,
    SUM(pay_ticket_cnt)                                                            AS pay_scenic_cnt,
    SUM(reserve_ticket_cnt)                                                        AS reserve_scenic_cnt,
    SUM(IF(ticket_id != sub_ticket_id, pay_ticket_cnt, 0))                         AS sub_pay_ticket_cnt,
    SUM(IF(ticket_id != sub_ticket_id, reserve_ticket_cnt, 0))                     AS sub_reserve_scenic_cnt

FROM dws_ord_scenic_pkg_sub_ticket_reserve_di
WHERE travel_date = ${ds}
GROUP BY
    sup_id,
    scenic_id,
    ticket_id,
    travel_date

