--Serverless Spark SQL
--********************************************************************--
--author: 王海阳
--create time: 2026-04-02 11:21:33
--Serverless Spark SQL任务只能运行在独享资源组上
--********************************************************************--
CREATE TABLE IF NOT EXISTS dws_ord_scenic_pkg_sub_ticket_reserve_di
(
    `sup_id`             INT     COMMENT '供应商ID',
    `order_id`           STRING  COMMENT '订单号',
    `scenic_id`          INT     COMMENT '景区ID',
    `ticket_id`          INT     COMMENT '门票ID',

    `sub_order_id`       STRING  COMMENT '子票订单号',
    `sub_scenic_id`      INT     COMMENT '子票景区ID',
    `sub_ticket_id`      INT     COMMENT '子票门票ID',

    `order_time`         INT     COMMENT '原始下单日期',

    `pay_ticket_cnt`     INT     COMMENT '支付票数',
    `reserve_ticket_cnt` INT     COMMENT '预定票数'
)
COMMENT '按游玩日期分区的订单宽表（整合套票+票数）|套票子票支付预定汇总'
PARTITIONED BY (`travel_date` INT COMMENT '【分区】playtime_date 预计游玩日期 yyyyMMdd')
STORED AS ORC;



-- =====================================================================
-- 目标表: dwd_order_by_playtime_d_i
-- 功能: 按游玩日期分区，整合订单+套票类型+票数
-- 范围扫描只发生在这一层，后续 DWS 全部等值过滤
-- =====================================================================
INSERT OVERWRITE TABLE dws_ord_scenic_pkg_sub_ticket_reserve_di PARTITION(travel_date = ${ds})

SELECT 
    apply_did,
    main_orderid, 
    main_lid, 
    main_tid, 
    sub_orderid, 
    sub_lid, 
    sub_tid,
    orderdate,
    NVL(tn.pay_ticket_num, 0)       AS pay_ticket_cnt,
    NVL(tn.booking_ticket_num, 0)   AS reserve_ticket_cnt
FROM(
    -- 子票订单
    SELECT 
        o.apply_did,
        addon.main_orderid, 
        o.lid as main_lid, 
        o.tid as main_tid, 
        addon.orderid as sub_orderid, 
        o_sub.lid AS sub_lid, 
        o_sub.tid as sub_tid, 
        o.orderdate
    FROM
    (
        -- -------------------------------------------------------
        -- 订单主表：以游玩日期为主过滤条件
        -- 覆盖所有历史下单、今日游玩的订单
        -- orderdate 范围限制为 90 天，避免全表扫描
        -- -------------------------------------------------------
        SELECT ordernum, lid, tid, apply_did, orderdate
        FROM s_order_d_i
        WHERE DATE_FORMAT(playtime, 'yyyyMMdd') = CAST(${ds} AS STRING)
        AND playtime IS NOT NULL
        AND apply_did = 29821585
        AND orderdate >= CAST(DATE_FORMAT(DATE_SUB(TO_DATE(CAST(${ds} AS STRING), 'yyyyMMdd'), 90),'yyyyMMdd') AS INT)
    ) AS o
    JOIN
    (
        -- -------------------------------------------------------
        -- 套票关系表：取对应下单日范围内的套票类型
        -- ifpack: 1=套票主票, 2=套票子票
        -- -------------------------------------------------------
        SELECT
            pack_order as main_orderid,
            orderid as orderid,
            ifpack
        FROM s_order_addon_d_i
        WHERE ifpack=2
        AND apply_did = 29821585
        AND orderdate >= CAST(DATE_FORMAT(DATE_SUB(TO_DATE(CAST(${ds} AS STRING), 'yyyyMMdd'), 90),'yyyyMMdd') AS INT)
    ) AS addon
    ON o.ordernum = addon.main_orderid
    -- 第一次关联订单表, 是为了获取主票信息, 第二次关联订单表,是为了获取子票信息
    LEFT JOIN 
    (
        -- -------------------------------------------------------
        -- 订单主表：以游玩日期为主过滤条件
        -- 覆盖所有历史下单、今日游玩的订单
        -- orderdate 范围限制为 90 天，避免全表扫描
        -- -------------------------------------------------------
        SELECT ordernum, lid, tid
        FROM s_order_d_i
        WHERE orderdate >= CAST(DATE_FORMAT(DATE_SUB(TO_DATE(CAST(${ds} AS STRING), 'yyyyMMdd'), 90),'yyyyMMdd') AS INT)
        AND apply_did = 29821585
    ) AS o_sub
    ON addon.orderid = o_sub.ordernum


    UNION ALL

    -- 主票/单票订单
    SELECT o.apply_did, o.ordernum AS main_orderid, o.lid as main_lid, o.tid as main_tid, o.ordernum as sub_orderid, o.lid as lid, o.tid as tid, o.orderdate
    FROM
    (
        -- -------------------------------------------------------
        -- 订单主表：以游玩日期为主过滤条件
        -- 覆盖所有历史下单、今日游玩的订单
        -- orderdate 范围限制为 90 天，避免全表扫描
        -- -------------------------------------------------------
        SELECT ordernum, lid, tid, apply_did, orderdate
        FROM s_order_d_i
        WHERE DATE_FORMAT(playtime, 'yyyyMMdd') = CAST(${ds} AS STRING)
        AND playtime IS NOT NULL
        AND apply_did = 29821585
        AND orderdate >= CAST(DATE_FORMAT(DATE_SUB(TO_DATE(CAST(${ds} AS STRING), 'yyyyMMdd'), 90),'yyyyMMdd') AS INT)
    ) AS o
    LEFT JOIN
    (
        -- -------------------------------------------------------
        -- 套票关系表：取对应下单日范围内的套票类型
        -- ifpack: 1=套票主票, 2=套票子票
        -- -------------------------------------------------------
        SELECT
            pack_order as main_orderid,
            orderid as orderid,
            ifpack
        FROM s_order_addon_d_i
        WHERE ifpack=2
        AND apply_did = 29821585
        AND orderdate >= CAST(DATE_FORMAT(DATE_SUB(TO_DATE(CAST(${ds} AS STRING), 'yyyyMMdd'), 90),'yyyyMMdd') AS INT)
    ) AS addon
    ON o.ordernum = addon.orderid
    WHERE addon.main_orderid IS NULL
) orderTab
LEFT JOIN
(
    -- -------------------------------------------------------
    -- 订单轨迹票数表：按订单号聚合全部历史轨迹
    -- 注意：若记录是变更量则 SUM，若是快照则取最新一条
    -- 当前按变更量处理（SUM）
    -- -------------------------------------------------------
    SELECT
        ordernum,
        SUM(booking_ticket_num) AS booking_ticket_num,
        SUM(pay_ticket_num)     AS pay_ticket_num
    FROM ods_track_tnum_d_i
    WHERE insertdate >= CAST(DATE_FORMAT(DATE_SUB(TO_DATE(CAST(${ds} AS STRING), 'yyyyMMdd'), 90),'yyyyMMdd') AS INT)
      AND insertdate <= ${ds}
      AND apply_did = 29821585
    GROUP BY ordernum
) AS tn
ON orderTab.sub_orderid = tn.ordernum;