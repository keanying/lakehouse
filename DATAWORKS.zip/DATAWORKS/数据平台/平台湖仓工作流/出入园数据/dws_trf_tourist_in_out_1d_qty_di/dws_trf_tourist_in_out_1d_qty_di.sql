--Serverless Spark SQL
--********************************************************************--
--author: 韩瑞
--create time: 2026-06-02 17:38:34
--Serverless Spark SQL任务只能运行在独享资源组上
--********************************************************************--
-- set hive.exec.dynamic.partition.mode=nonstrict;
-- SET spark.sql.mergeSmallFiles.enabled=true;
-- SET spark.sql.sources.partitionOverwriteMode=dynamic;
-- SET spark.sql.adaptive.enabled=true;
-- SET spark.sql.adaptive.coalescePartitions.enabled=true;
-- SET spark.sql.adaptive.coalescePartitions.minPartitionSize=128MB;


CREATE TABLE IF NOT EXISTS dws_trf_tourist_in_out_1d_qty_di
(
    scenic_id    BIGINT COMMENT '景区id'
    ,sup_id      BIGINT COMMENT '供应商id'
    ,visit_date  DATE COMMENT '游览日期'
    ,roll        INT COMMENT '0 入园 1 离园'
    ,1d_qty      BIGINT COMMENT '当天出入园数量'
)
COMMENT '景区出入园汇总表'
PARTITIONED BY 
(
    travel_date  INT COMMENT '出入园日期'
)
STORED AS ORC
;



INSERT OVERWRITE TABLE dws_trf_tourist_in_out_1d_qty_di PARTITION (travel_date)
SELECT  scenic_id
        ,sup_id
        ,visit_date
        ,roll
        ,SUM(qty) AS 1d_qty
        ,travel_date
FROM    dwd_trf_tourist_in_out_details_di
WHERE   travel_date = '${yesterday}'
GROUP BY scenic_id
         ,sup_id
         ,visit_date
         ,travel_date
         ,roll
;








