--Serverless Spark SQL
--********************************************************************--
--author: 韩瑞
--create time: 2026-06-02 17:38:08
--Serverless Spark SQL任务只能运行在独享资源组上
--********************************************************************--
-- set hive.exec.dynamic.partition.mode=nonstrict;
-- SET spark.sql.mergeSmallFiles.enabled=true;
-- SET spark.sql.sources.partitionOverwriteMode=dynamic;
-- SET spark.sql.adaptive.enabled=true;
-- SET spark.sql.adaptive.coalescePartitions.enabled=true;
-- SET spark.sql.adaptive.coalescePartitions.minPartitionSize=128MB;

CREATE TABLE IF NOT EXISTS dwd_trf_tourist_in_out_details_di
(
    id                BIGINT COMMENT 'id'
    ,scenic_id        BIGINT COMMENT '景区ID'
    ,sup_id           BIGINT COMMENT '供应商ID'
    ,qty              BIGINT COMMENT '单次出入园数量'
    ,create_time      BIGINT COMMENT '创建时间'
    ,visit_date       DATE COMMENT '游览日期'
    ,visit_date_hour  BIGINT COMMENT '出入园对应小时 24小时制'
    ,device_key       STRING COMMENT '闸机特征码'
    ,roll             INT COMMENT '0 入园 1 离园'
    ,all_num          BIGINT COMMENT '当前的出入园总量'
)
COMMENT '景区出入园信息表'
PARTITIONED BY 
(
    travel_date       INT COMMENT '出入园日期'
)
STORED AS ORC
;

-- -- 全量流程 期初导入执行一次
-- INSERT OVERWRITE TABLE dwd_trf_tourist_in_out_details_di PARTITION (travel_date)
-- SELECT  id
--         ,sid AS scenic_id
--         ,land_id AS sup_id
--         ,num AS qty
--         ,create_time
--         ,TO_DATE(create_time) AS visit_date
--         ,CAST(FROM_UNIXTIME(create_time,'HH') AS INT) AS visit_date_hour
--         ,device_key
--         ,roll
--         ,all_num
--         ,travel_date
-- FROM    ods_summary_pft_dc_daycount_info_di
-- WHERE   travel_date >= 20230206
-- ;


-- 增量流程
INSERT OVERWRITE TABLE dwd_trf_tourist_in_out_details_di PARTITION(travel_date)
SELECT id          
    ,land_id AS scenic_id     
    ,sid  AS sup_id
    ,num AS   qty    
    ,create_time
    ,CAST(from_unixtime(create_time,'yyyy-MM-dd') AS DATE) AS visit_date 
    ,cast(from_unixtime(create_time,'HH') AS int) AS create_time_hour
    ,device_key 
    ,roll       
    ,all_num 
    ,travel_date
FROM ods_summary_pft_dc_daycount_info_di
WHERE travel_date = '${yesterday}'
;






