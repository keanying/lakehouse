--Serverless Spark SQL
--********************************************************************--
--author: 韩瑞
--create time: 2026-06-02 18:29:27
--Serverless Spark SQL任务只能运行在独享资源组上
--********************************************************************--
-- set hive.exec.dynamic.partition.mode=nonstrict;
CREATE TABLE IF NOT EXISTS ads_trf_tourist_in_out_qty
(
    scenic_id          BIGINT COMMENT '景区id'
    ,sup_id            BIGINT COMMENT '供应商id'
    ,visit_date        DATE COMMENT '游览日期'
    ,roll              INT COMMENT '0 入园 1 离园'
    ,1d_qty            BIGINT COMMENT '单次出入园数量'
    ,last_7d_qty       BIGINT COMMENT '近7天出入园数量'
    ,last_7d_qty_yoy   BIGINT COMMENT '近7天出入园数量(同比)'
    ,last_30d_qty      BIGINT COMMENT '近30天出入园数量'
    ,last_30d_qty_yoy  BIGINT COMMENT '近30天出入园数量(同比)'
    ,last_365d_qty     BIGINT COMMENT '近365天出入园数量'
    ,last_365d_qty_yoy BIGINT COMMENT '近365天出入园数量(同比)'
)
COMMENT '景区出入园指标表'
PARTITIONED BY 
(
    travel_date        INT COMMENT '出入园日期'
)
STORED AS ORC
;




-- 参数：target_date 为 INT 格式，例如 20260601，表示要计算的日期（T+1 中的 T）
-- 实际使用时可以通过 spark.sql 的变量替换，如 '${yesterday}'

INSERT OVERWRITE TABLE ads_trf_tourist_in_out_qty PARTITION (travel_date)
WITH
-- 目标日期（DATE 类型）
target_dt AS (
  SELECT to_date(cast('${yesterday}' as string), 'yyyyMMdd') AS dt
),

-- 基础数据：目标日期当天各景区、供应商、roll 的出入园数量
base AS (
  SELECT 
      scenic_id,
      sup_id,
      roll,
      visit_date,          -- 当天日期
      1d_qty AS qty,
      travel_date
  FROM dws_trf_tourist_in_out_1d_qty_di
  WHERE travel_date = '${yesterday}'
),

-- 近7天累计（含当天）
last_7d AS (
  SELECT 
      scenic_id,
      sup_id,
      roll,
      SUM(1d_qty) AS last_7d_qty
  FROM dws_trf_tourist_in_out_1d_qty_di
  CROSS JOIN target_dt
  WHERE travel_date BETWEEN date_format(date_sub(dt, 6), 'yyyyMMdd')
                        AND date_format(dt, 'yyyyMMdd')
  GROUP BY scenic_id, sup_id, roll
),

-- 近7天同比（去年同期的近7天）
last_7d_yoy AS (
  SELECT 
      scenic_id,
      sup_id,
      roll,
      SUM(1d_qty) AS last_7d_qty_yoy
  FROM dws_trf_tourist_in_out_1d_qty_di
  CROSS JOIN target_dt
  WHERE travel_date BETWEEN date_format(date_sub(add_months(dt, -12), 6), 'yyyyMMdd')
                        AND date_format(add_months(dt, -12), 'yyyyMMdd')
  GROUP BY scenic_id, sup_id, roll
),

-- 近30天累计
last_30d AS (
  SELECT 
      scenic_id,
      sup_id,
      roll,
      SUM(1d_qty) AS last_30d_qty
  FROM dws_trf_tourist_in_out_1d_qty_di
  CROSS JOIN target_dt
  WHERE travel_date BETWEEN date_format(date_sub(dt, 29), 'yyyyMMdd')
                        AND date_format(dt, 'yyyyMMdd')
  GROUP BY scenic_id, sup_id, roll
),

-- 近30天同比
last_30d_yoy AS (
  SELECT 
      scenic_id,
      sup_id,
      roll,
      SUM(1d_qty) AS last_30d_qty_yoy
  FROM dws_trf_tourist_in_out_1d_qty_di
  CROSS JOIN target_dt
  WHERE travel_date BETWEEN date_format(date_sub(add_months(dt, -12), 29), 'yyyyMMdd')
                        AND date_format(add_months(dt, -12), 'yyyyMMdd')
  GROUP BY scenic_id, sup_id, roll
),

-- 近365天累计
last_365d AS (
  SELECT 
      scenic_id,
      sup_id,
      roll,
      SUM(1d_qty) AS last_365d_qty
  FROM dws_trf_tourist_in_out_1d_qty_di
  CROSS JOIN target_dt
  WHERE travel_date BETWEEN date_format(date_sub(dt, 364), 'yyyyMMdd')
                        AND date_format(dt, 'yyyyMMdd')
  GROUP BY scenic_id, sup_id, roll
),

-- 近365天同比
last_365d_yoy AS (
  SELECT 
      scenic_id,
      sup_id,
      roll,
      SUM(1d_qty) AS last_365d_qty_yoy
  FROM dws_trf_tourist_in_out_1d_qty_di
  CROSS JOIN target_dt
  WHERE travel_date BETWEEN date_format(date_sub(add_months(dt, -12), 364), 'yyyyMMdd')
                        AND date_format(add_months(dt, -12), 'yyyyMMdd')
  GROUP BY scenic_id, sup_id, roll
)

-- 最终结果
SELECT 
    b.scenic_id,
    b.sup_id,
    b.visit_date,
    b.roll,
    b.qty,
    COALESCE(l7.last_7d_qty, 0) AS last_7d_qty,
    COALESCE(l7y.last_7d_qty_yoy, 0) AS last_7d_qty_yoy,
    COALESCE(l30.last_30d_qty, 0) AS last_30d_qty,
    COALESCE(l30y.last_30d_qty_yoy, 0) AS last_30d_qty_yoy,
    COALESCE(l365.last_365d_qty, 0) AS last_365d_qty,
    COALESCE(l365y.last_365d_qty_yoy, 0) AS last_365d_qty_yoy,
    b.travel_date AS travel_date
FROM base b
LEFT JOIN last_7d        l7  ON b.scenic_id = l7.scenic_id AND b.sup_id = l7.sup_id AND b.roll = l7.roll
LEFT JOIN last_7d_yoy    l7y ON b.scenic_id = l7y.scenic_id AND b.sup_id = l7y.sup_id AND b.roll = l7y.roll
LEFT JOIN last_30d       l30 ON b.scenic_id = l30.scenic_id AND b.sup_id = l30.sup_id AND b.roll = l30.roll
LEFT JOIN last_30d_yoy   l30y ON b.scenic_id = l30y.scenic_id AND b.sup_id = l30y.sup_id AND b.roll = l30y.roll
LEFT JOIN last_365d      l365 ON b.scenic_id = l365.scenic_id AND b.sup_id = l365.sup_id AND b.roll = l365.roll
LEFT JOIN last_365d_yoy  l365y ON b.scenic_id = l365y.scenic_id AND b.sup_id = l365y.sup_id AND b.roll = l365y.roll
;