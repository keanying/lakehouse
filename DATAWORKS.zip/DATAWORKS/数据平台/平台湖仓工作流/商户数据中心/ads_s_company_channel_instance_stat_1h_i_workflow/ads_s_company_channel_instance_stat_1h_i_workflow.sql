-- 指标: 预订单渠道分布


CREATE TABLE IF NOT EXISTS ads_s_company_channel_instance_stat_1h_i_workflow(
    `sid`           INT     COMMENT '商户ID',
    `fulldate`      STRING  COMMENT '全日期',
    `hour`          INT     COMMENT '小时',
    `channel_id`    INT     COMMENT '渠道id',
    `channel_name`  STRING  COMMENT '渠道名称',
    `paid_count`    INT     COMMENT '已支付订单量',
    `paid_amount`   INT     COMMENT '已支付订单金额'
)STORED AS ORC;


INSERT OVERWRITE TABLE ads_s_company_channel_instance_stat_1h_i_workflow
-- 分销订单维度
SELECT
    INT(`aids_seller_id`)                AS `sid`,
    `fulldate`,
    INT(`hour`),
    INT(`booking_channel`)               AS `channel_id`,
    NVL(FIRST(`booking_channel_name`),'未知')   
                                    AS `channel_name`,
    COUNT(1)                        AS `paid_count`,
    0                               AS `paid_amount`
FROM 
(
    SELECT
        `aids_seller_id`,
        DATE_FORMAT(`pay_time`, 'yyyy-MM-dd')   AS `fulldate`,
        DATE_FORMAT(`pay_time`, 'HH')           AS `hour`,
        `booking_channel`,
        `booking_channel_name`
    FROM dwd_order_boss_cockpit_instance_temp
    WHERE `pay_time` > CURRENT_DATE() 
      AND ISNOTNULL(`aids_seller_id`)
)
GROUP BY
    `aids_seller_id`,
    `fulldate`,
    `hour`,
    `booking_channel`

UNION ALL 

-- 景区维度
SELECT
    INT(`member_id`)                       AS `sid`,
    `fulldate`,
    INT(`hour`),
    INT(`booking_channel`)               AS `channel_id`,
    NVL(FIRST(`booking_channel_name`),'未知')
                                    AS `channel_name`,
    COUNT(1)                        AS `paid_count`,
    0                               AS `paid_amount`
FROM 
(
    SELECT
        `land_id`,
        DATE_FORMAT(`pay_time`, 'yyyy-MM-dd')   AS `fulldate`,
        DATE_FORMAT(`pay_time`, 'HH')           AS `hour`,
        `booking_channel`,
        `booking_channel_name`
    FROM dwd_order_boss_cockpit_instance_temp
    WHERE `pay_time` > CURRENT_DATE() 
      AND ISNOTNULL(`aids_seller_id`)
      AND aids_level IN(0, -1)
) AS tmp 
INNER JOIN 
(
    SELECT land_id, member_id
    FROM ods_c_member_authorize_d_f
    WHERE pt='${ds}'
      AND land_id IS NOT NULL 
) AS memberTable
ON tmp.land_id = memberTable.land_id
GROUP BY
    `member_id`,
    `fulldate`,
    `hour`,
    `booking_channel`;