CREATE TABLE IF NOT EXISTS dwd_order_boss_cockpit_instance_temp(
    vertify_time            STRING  COMMENT '验证时间',
    cancel_time             STRING  COMMENT '取消时间',
    booking_channel         STRING  COMMENT '下单渠道',
    booking_channel_name    STRING  COMMENT '下单渠道名称',
    order_pay_amount        BIGINT  COMMENT '订单支付金额',
    ticket_taker_age        INT     COMMENT '取票人年龄',
    ticket_taker_sex        STRING  COMMENT '取票人性别',
    ticket_taker_province   STRING  COMMENT '取票人所在省',
    ticket_taker_city       STRING  COMMENT '取票人所在市',
    land_id                 INT     COMMENT '景区ID',
    land_name               STRING  COMMENT '景区名称',
    pay_time                TIMESTAMP COMMENT '支付时间',
    aids_buyer_id           INT     COMMENT '购买者id',
    aids_seller_id          INT     COMMENT '销售者id',
    aids_level              INT     COMMENT '本笔分销层级',
    aids_buyername          STRING  COMMENT '购买者姓名'
)STORED AS ORC;


INSERT OVERWRITE TABLE dwd_order_boss_cockpit_instance_temp
SELECT
    uu_ss_order.dtime       AS vertify_time,
    uu_ss_order.ctime       AS cancel_time,
    uu_ss_order.ordermode   AS booking_channel,
    ch.channel_name         AS booking_channel_name,
    IF(
        uu_ss_order.status IN (3, 6, 9) OR uu_ss_order.pay_status = 2,
        0,
        uu_ss_order.totalmoney
    )                       AS order_pay_amount,
    IF(
        ISNOTNULL(uu_ss_order.personid),
        YEAR(CURRENT_DATE()) - SUBSTR(uu_ss_order.personid, 7, 4),
        -1
    )                       AS ticket_taker_age,
    IF(
        ISNOTNULL(uu_ss_order.personid),
        IF(SUBSTR(uu_ss_order.personid, 17, 1) % 2 = 0, "女", "男"),
        "未知"
    )                       AS ticket_taker_sex,
    IF(
        ISNOTNULL(uu_ss_order.team_order_id) AND ISNOTNULL(uu_ss_order.team_province),
        uu_ss_order.team_province,
        IF( 
            (ISNOTNULL(uu_ss_order.ordertel) OR uu_ss_order.ordertel != "") AND ISNOTNULL(cp.province_name),
            cp.province_name,
            IF(
                isnotnull(uu_ss_order.personid) OR uu_ss_order.personid != "",
                idc.province_name,
                "未知"
            )
        )
    )                       AS ticket_taker_province,
    IF(
        ISNOTNULL(uu_ss_order.team_order_id) AND ISNOTNULL(uu_ss_order.team_city),
        uu_ss_order.team_city,
        IF( (
                isnotnull(uu_ss_order.ordertel) OR
                uu_ss_order.ordertel != ""
            ) AND
            isnotnull(cp.city_name),
            cp.city_name,
            IF(
                isnotnull(uu_ss_order.personid) OR
                uu_ss_order.personid != "",
                idc.city_name,
                "未知"
            )
        )
    )                       AS ticket_taker_city,
    uu_ss_order.lid         AS land_id,
    prod.land_name          AS land_name,
    uu_ss_order.pay_time    AS pay_time,
    ooa.buyer_id            AS aids_buyer_id,
    ooa.seller_id           AS aids_seller_id,
    ooa.level               AS aids_level,
    ooa.buyername           AS aids_buyername
FROM 
(
    SELECT
        order.id            AS id,
        order.ordernum      AS ordernum,
        team.team_order_id  AS team_order_id,
        team.tourist_province AS team_province,
        team.tourist_city   AS team_city,
        order.tid           AS tid,
        order.tnum          AS tnum,
        order.tprice        AS tprice,
        order.ordername     AS ordername,
        order.ordertel      AS ordertel,
        order.ordertime     AS ordertime,
        order.ctime         AS ctime,
        order.dtime         AS dtime,
        order.status        AS status,
        order.pay_status    AS pay_status,
        order.totalmoney    AS totalmoney,
        order.ordermode     AS ordermode,
        order.lid           AS lid,
        IF(
            LENGTH(order.personid) = 18,
            CONCAT( SUBSTR(order.personid, 1, 10), REPEAT('*', 6), SUBSTR(order.personid, 17, 2) ),
            NULL
        ) AS personid,
        -- 关键修复：将pay_time显式转换为TIMESTAMP类型
        CASE
            WHEN order.pay_time != 0
            THEN TO_TIMESTAMP(FROM_UNIXTIME(order.pay_time), 'yyyy-MM-dd HH:mm:ss')
            ELSE NULL
        END AS pay_time
    FROM 
    (
        SELECT
            IF(isnotNULL(suit.pack_order), suit.pack_order, uu_ss_order.ordernum)           AS main_order_id,
            IF(suit.ifpack = 2,'套票子票',IF(suit.ifpack = 1, '套票主票', '单票'))          AS order_type,
            uu_ss_order.*
        FROM 
        (
            SELECT *
            FROM s_uu_ss_order_1h_i_workflow
            -- WHERE pt = "${ds}"
        ) uu_ss_order 
        LEFT JOIN 
        (
            SELECT orderid, IF(pack_order = '1', orderid, pack_order) AS pack_order, ifpack
            FROM ods_order_addon_d_i
            WHERE orderdate = ${ds}
        ) AS suit
        ON suit.orderid = uu_ss_order.ordernum
    ) AS order 
    LEFT JOIN 
    (
        SELECT
            usot.ordernum       AS team_order_id,
            usotl.son_ordernum  AS son_order_id,
            ct.province_name    AS tourist_province,
            ct.city_name        AS tourist_city
        FROM 
        (
            SELECT ordernum, city, province
            FROM ods_uu_ss_order_team_d_f
            WHERE pt = ${ds}
        ) AS usot
        LEFT JOIN 
        (
            SELECT main_ordernum, son_ordernum
            FROM ods_uu_ss_order_team_link_d_f
            WHERE pt = ${ds}
        ) AS usotl
        ON usot.ordernum = usotl.main_ordernum
        LEFT JOIN 
        (
            SELECT province_name, city_name, city_code, province_code
            FROM dim_city_d_f
            WHERE pt = ${ds}
        ) AS ct
        ON CAST(usot.city AS INT) = CAST(ct.city_code AS INT) 
            AND CAST(usot.province AS INT) = CAST(ct.province_code AS INT)
        WHERE ISNOTNULL(usotl.son_ordernum)
    ) AS team
    ON order.main_order_id = team.son_order_id 
    LEFT JOIN 
    (
        SELECT
            order_track.order_id                                                AS order_id,
            SUM(IF(order_track.action = 0, order_track.booking_ticket_num, 0))  AS booking_num
        FROM (
            SELECT
                action,
                ordernum                            AS order_id,
                IF(action IN (0, 16), tnum, NULL)   AS booking_ticket_num
            FROM s_order_track_d_i
            WHERE insertdate = ${ds}
        ) order_track
        WHERE order_track.action IN (0, 16)
        GROUP BY order_track.order_id
    ) AS track
    ON order.ordernum = track.order_id
) AS uu_ss_order
LEFT JOIN 
(
    SELECT
        DISTINCT 
        number          AS phone_number,
        city_name       AS city_name,
        province_name   AS province_name
    FROM ods_bi_business_city_phone_d_f
    WHERE pt = ${ds}
) AS cp
ON SUBSTR(uu_ss_order.ordertel, 1, 7) = cp.phone_number
LEFT JOIN 
(
    SELECT idcard, province_name, city_name
    FROM dim_idcard_city_d_f
    WHERE pt = ${ds}
        AND ISNOTNULL(idcard)
) AS idc
ON substr(uu_ss_order.personid, 1, 6) = idc.idcard
LEFT JOIN 
(
    SELECT
        t.id            AS ticket_id,
        uu_land.title   AS land_name
    FROM 
    (
        SELECT id, landid
        FROM ods_ticket_d_f
        WHERE pt = ${ds}
    ) AS t
    LEFT JOIN 
    (
        SELECT id, title
        FROM ods_uu_land_d_f
        WHERE pt = ${ds}
    ) AS uu_land
    ON t.landid = uu_land.id
) AS prod
ON uu_ss_order.tid = prod.ticket_id 
LEFT JOIN 
(
    SELECT order_channel_id, channel_name
    FROM dim_channel_d_f
    WHERE pt = ${ds}
) AS ch
ON uu_ss_order.ordermode = ch.order_channel_id 
LEFT JOIN
(
    SELECT
        aids_split.orderid         AS orderid,
        aids_split.buyer_id         AS buyer_id,
        aids_split.seller_id        AS seller_id,
        aids_split.level            AS level,
        ptf_member_buy.user_name    AS buyername
    FROM 
    (
        SELECT
            orderid AS orderid,  
            buyerid AS buyer_id,  
            sellerid AS seller_id,  
            level
        -- FROM ods_order_aids_split_d_f
        FROM ods_order_split_d_i
        WHERE orderdate = ${ds}
        UNION ALL
        SELECT
            orderid     AS orderid,
            buyerid     AS buyer_id,
            sellerid    AS seller_id,
            level
        FROM s_order_aids_split_1h_i_workflow
        -- WHERE pt = ${ds}
    ) AS aids_split 
    LEFT JOIN 
    (
        SELECT user_id, user_name
        FROM ods_pft_member_d_f
        WHERE pt = ${ds}
    ) AS ptf_member_buy
    ON aids_split.buyer_id = ptf_member_buy.user_id 
) AS ooa
ON ooa.orderid = uu_ss_order.ordernum

