CREATE TABLE IF NOT EXISTS `s_uu_ss_order_1h_i_workflow`(
    `id` bigint COMMENT 'è¡¨id', 
    `member` int COMMENT 'æ“ä½œå‘˜ID', 
    `ordernum` string COMMENT '', 
    `certnum` bigint COMMENT 'å‡­è¯å·', 
    `remotenum` string COMMENT '', 
    `lid` int COMMENT 'æ™¯åŒºid', 
    `tid` int COMMENT 'é—¨ç¥¨id', 
    `pid` int COMMENT 'äº§å“PID', 
    `aid` int COMMENT '', 
    `tnum` bigint COMMENT 'é—¨ç¥¨æ•°é‡', 
    `tprice` int COMMENT '', 
    `ordername` string COMMENT 'å–ç¥¨äººå§“å', 
    `ordertel` string COMMENT 'å–ç¥¨äººç”µè¯', 
    `contacttel` string COMMENT '', 
    `ordertime` string COMMENT 'ä¸‹å•æ—¶é—´', 
    `playtime` date COMMENT 'é¢„è®¡æ¸¸çŽ©æ—¶é—´', 
    `begintime` date COMMENT 'å¼€å§‹æ—¶é—´', 
    `endtime` date COMMENT 'ç»“æŸæ—¶é—´', 
    `ctime` string COMMENT 'å–æ¶ˆæ—¶é—´', 
    `dtime` string COMMENT 'éªŒè¯æ—¶é—´', 
    `status` tinyint COMMENT '0æœªä½¿ç”¨ï¼Œ1å·²ä½¿ç”¨ï¼Œ2å·²è¿‡æœŸ,3è¢«å–æ¶ˆ', 
    `pay_status` bigint COMMENT '支付状态1已支付2未支付', 
    `salerid` bigint COMMENT 'å•†å®¶ID', 
    `remsg` bigint COMMENT 'çŸ­ä¿¡é‡å‘é™åˆ¶æ¬¡æ•°', 
    `smserror` smallint COMMENT 'çŸ­ä¿¡é”™è¯¯ä¿¡æ¯', 
    `paymode` bigint COMMENT '', 
    `totalmoney` int COMMENT '', 
    `ordermode` tinyint COMMENT '', 
    `onsale` tinyint COMMENT '', 
    `personid` string COMMENT '', 
    `callback` tinyint COMMENT '', 
    `code` bigint COMMENT '', 
    `unionCheck` tinyint COMMENT '', 
    `visitors` tinyint COMMENT '订单客户类型：1=游客,2=分销商', 
    `pay_time` int COMMENT '订单支付时间', 
    `order_time` int COMMENT '逻辑下单时间', 
    `update_time` int COMMENT '订单更新时间', 
    `order_month` tinyint COMMENT '逻辑下单月份', 
    `product_type` string COMMENT '商品类型', 
    `apply_did` int COMMENT '原始供应商ID', 
    `sync_state` tinyint COMMENT '是否同步标示 1:同步,0:无需同步'
)
COMMENT '平台订单记录主表'
STORED AS ORC;


CREATE TABLE IF NOT EXISTS `s_order_aids_split_1h_i_workflow`(
    `id` bigint COMMENT '', 
    `orderid` string COMMENT '订单号', 
    `buyerid` int COMMENT '购买用户ID', 
    `sellerid` int COMMENT '供应商ID', 
    `level` tinyint COMMENT '所处的级别：1=第一级，0=既是1级也是末级，-1=最末级，2=中间级别', 
    `pmode` int COMMENT '该级别的支付方式', 
    `cost_money` decimal(12,0) COMMENT '成本价（分为单位）', 
    `sale_money` decimal(12,0) COMMENT '销售价（分为单位）', 
    `member_relationship` tinyint COMMENT '订单会员关系 0:平台关系,1:资源中心关系', 
    `order_time` int COMMENT '逻辑下单时间', 
    `update_time` int COMMENT '订单更新时间', 
    `order_month` tinyint COMMENT '逻辑下单月份', 
    `apply_did` int COMMENT '原始供应商ID', 
    `sync_state` tinyint COMMENT '是否同步标示 1:同步,0:无需同步'
)
COMMENT '订单每级买入卖出者'
STORED AS ORC;

