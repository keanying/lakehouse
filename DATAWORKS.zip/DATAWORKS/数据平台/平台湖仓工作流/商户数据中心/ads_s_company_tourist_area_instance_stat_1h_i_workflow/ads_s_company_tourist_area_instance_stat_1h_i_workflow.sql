

-- 指标:  预订游客归属地分布（市）
CREATE TABLE IF NOT EXISTS ads_s_company_tourist_area_instance_stat_1h_i_workflow(
    `sid`       INT     COMMENT '商户ID',
    `fulldate`  STRING  COMMENT '全日期',
    `hour`      INT     COMMENT '小时',
    `province`  STRING  COMMENT '省份',
    `city`      STRING  COMMENT '城市',
    `country`   STRING  COMMENT '区县',
    `count`     INT     COMMENT '人数'
)STORED AS ORC;


INSERT OVERWRITE TABLE ads_s_company_tourist_area_instance_stat_1h_i_workflow
-- 分销订单维度
SELECT
    CAST(aids_seller_id AS INT)     AS sid,
    `fulldate`,
    `hour`,
    `ticket_taker_province`         AS `province`,
    `ticket_taker_city`             AS `city`,
    ''                              AS `country`,
    COUNT(1)                        AS `count`
FROM 
(
    SELECT
        `aids_seller_id`,
        date_format(`pay_time`, 'yyyy-MM-dd')   AS `fulldate`,
        CAST(date_format(`pay_time`, 'HH') AS INT) AS `hour`,
        if(
            `ticket_taker_province` IS NULL,
            '未知',
            `ticket_taker_province`
        )                                       AS `ticket_taker_province`,
        if(
            `ticket_taker_city` IS NULL,
            '未知',
            `ticket_taker_city`
        )                                       AS `ticket_taker_city`
    FROM dwd_order_boss_cockpit_instance_temp
    WHERE `pay_time` > current_date() 
        AND isnotnull(`aids_seller_id`)
)
GROUP BY
    `aids_seller_id`,
    `fulldate`,
    `hour`,
    `ticket_taker_province`,
    `ticket_taker_city`

UNION ALL 
-- 景区维度
SELECT
    CAST(member_id AS INT)          AS sid,
    `fulldate`,
    `hour`,
    `ticket_taker_province`         AS `province`,
    `ticket_taker_city`             AS `city`,
    ''                              AS `country`,
    COUNT(1)                        AS `count`
FROM 
(
    SELECT
        `land_id`,
        date_format(`pay_time`, 'yyyy-MM-dd')   AS `fulldate`,
        CAST(date_format(`pay_time`, 'HH') AS INT) AS `hour`,
        if(
            `ticket_taker_province` IS NULL,
            '未知',
            `ticket_taker_province`
        )                                       AS `ticket_taker_province`,
        if(
            `ticket_taker_city` IS NULL,
            '未知',
            `ticket_taker_city`
        )                                       AS `ticket_taker_city`
    FROM dwd_order_boss_cockpit_instance_temp
    WHERE `pay_time` > current_date() 
        AND isnotnull(`aids_seller_id`)
        AND aids_level IN(0, -1)
) AS tmp 
INNER JOIN 
(
    SELECT land_id, member_id
    FROM ods_c_member_authorize_d_f
    WHERE pt=${ds}
      AND land_id IS NOT NULL 
) AS memberTable
ON tmp.land_id = memberTable.land_id
GROUP BY
    `member_id`,
    `fulldate`,
    `hour`,
    `ticket_taker_province`,
    `ticket_taker_city`;

