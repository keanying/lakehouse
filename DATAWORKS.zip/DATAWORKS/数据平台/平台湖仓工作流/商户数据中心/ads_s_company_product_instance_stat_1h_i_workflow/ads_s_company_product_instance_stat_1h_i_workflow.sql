
-- 商户分销订单维度/景区维度-预定产品热度


CREATE TABLE IF NOT EXISTS ads_s_company_product_instance_stat_1h_i(
    `sid`           INT     COMMENT '商户ID',
    `fulldate`      STRING  COMMENT '全日期',
    `hour`          INT     COMMENT '小时',
    `product_id`    INT     COMMENT '产品ID',
    `product_name`  STRING  COMMENT '产品名称',
    `paid_count`    INT     COMMENT '已支付订单量',
    `paid_amount`   INT     COMMENT '已支付订单金额'
)STORED AS ORC;


INSERT OVERWRITE TABLE ads_s_company_product_instance_stat_1h_i
-- 分销订单维度
SELECT
    INT(`aids_seller_id`)    AS `sid`,
    `fulldate`,
    INT(`hour`),
    INT(`land_id`)           AS `product_id`,
    first(`land_name`)  AS `product_name`,
    COUNT(1)            AS `paid_count`,
    0                   AS `paid_amount`
FROM 
(
    SELECT
        `aids_seller_id`,
        DATE_FORMAT(`pay_time`, 'yyyy-MM-dd')   AS `fulldate`,
        DATE_FORMAT(`pay_time`, 'HH')           AS `hour`,
        `land_id`,
        `land_name`
    FROM dwd_order_boss_cockpit_instance_temp
    WHERE `pay_time` > CURRENT_DATE() 
        AND ISNOTNULL(`aids_seller_id`)
)
GROUP BY
    `aids_seller_id`,
    `fulldate`,
    `hour`,
    `land_id`

UNION ALL 
-- 景区维度
SELECT
    INT(`member_id`)           AS `sid`,
    `fulldate`,
    INT(`hour`),
    INT(memberTable.`land_id`)   AS `product_id`,
    first(`land_name`)  AS `product_name`,
    COUNT(1)            AS `paid_count`,
    0                   AS `paid_amount`
FROM 
(
    SELECT
        DATE_FORMAT(`pay_time`, 'yyyy-MM-dd')   AS `fulldate`,
        DATE_FORMAT(`pay_time`, 'HH')           AS `hour`,
        `land_id`,
        `land_name`
    FROM dwd_order_boss_cockpit_instance_temp
    WHERE `pay_time` > CURRENT_DATE() 
        AND ISNOTNULL(`land_id`)
        AND aids_level IN(0, -1)
) AS tmp 
INNER JOIN 
(
    SELECT land_id, member_id
    FROM ods_c_member_authorize_d_f
    WHERE pt='${ds}'
      AND land_id IS NOT NULL 
) AS memberTable
ON tmp.land_id = memberTable.land_id
GROUP BY
    `member_id`,
    `fulldate`,
    `hour`,
    memberTable.`land_id`;