-- desc 此表用于每次工作流开始运行时, 生成一个标记字段, 工作流成功运行后, 写入到MySQL表中, 以通知后端本次任务成功运行

CREATE TABLE IF NOT EXISTS temp_begin_make_copy(
        `key` STRING COMMENT 'key',
        `value` STRING COMMENT '本次开始时间'
    )STORED AS ORC;

INSERT OVERWRITE TABLE temp_begin_make_copy
SELECT
    `key`,
    `value`
FROM (
    SELECT
        'instance_dimension_time'                              AS `key`,
        FROM_UNIXTIME(UNIX_TIMESTAMP(), 'yyyy-MM-dd HH:00:00') AS `value`
    )
--测试提交实时性
    UNION ALL (
    SELECT
        'instance_dimension_time_copy' AS `key`,
        CURRENT_TIMESTAMP()            AS `value`
    )