-- 分销订单-预订单分销商分布


CREATE TABLE IF NOT EXISTS ads_s_company_distributor_instance_stat_1h_i_workflow(
    `sid`               INT     COMMENT '商户ID',
    `fulldate`          STRING  COMMENT '全日期',
    `hour`              INT     COMMENT '小时',
    `distributor_id`    INT     COMMENT '分销商id',
    `distributor_name`  STRING  COMMENT '分销商名称',
    `paid_count`        INT     COMMENT '已支付订单量',
    `paid_amount`       INT     COMMENT '已支付订单金额'
);


INSERT OVERWRITE TABLE ads_s_company_distributor_instance_stat_1h_i_workflow
SELECT
    `aids_seller_id`        AS `sid`,
    `fulldate`,
    INT(`hour`),
    `aids_buyer_id`         AS `distributor_id`,
    FIRST(`aids_buyername`) AS `distributor_name`,
    COUNT(1)                AS `paid_count`,
    0                       AS `paid_amount`
FROM 
(
    SELECT
        `aids_seller_id`,
        date_format(`pay_time`, 'yyyy-MM-dd')   AS `fulldate`,
        date_format(`pay_time`, 'HH')           AS `hour`,
        `aids_buyer_id`,
        `aids_buyername`
    FROM dwd_order_boss_cockpit_instance_temp
    WHERE `pay_time` > current_date() 
        AND ISNOTNULL(`aids_seller_id`) 
        AND ISNOTNULL(`aids_buyername`)
)
GROUP BY
    `aids_seller_id`,
    `fulldate`,
    `hour`,
    `aids_buyer_id`