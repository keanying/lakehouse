-- 商户分销订单维度/景区维度-预订单量/预订单金额/验证订单量/验证订单金额/取消订单量/取消订单金额


CREATE TABLE IF NOT EXISTS ads_s_company_order_instance_stat_1h_i(
    `sid`           INT     COMMENT '商户ID',
    `fulldate`      STRING  COMMENT '全日期',
    `hour`          INT     COMMENT '小时',
    `paid_count`    INT     COMMENT '已支付订单量',
    `paid_amount`   INT     COMMENT '已支付订单金额',
    `verify_count`  INT     COMMENT '验证订单量',
    `verify_amount` INT     COMMENT '验证订单金额',
    `cancel_count`  INT     COMMENT '取消订单量',
    `cancel_amount` INT     COMMENT '取消订单金额'
)STORED AS ORC;


INSERT OVERWRITE TABLE ads_s_company_order_instance_stat_1h_i
-- 分销订单维度
SELECT
    INT(`sid`),
    `fulldate`,
    INT(`hour`),
    SUM(paid_count)     AS `paid_count`,
    SUM(paid_amount)    AS `paid_amount`,
    SUM(verify_count)   AS `verify_count`,
    SUM(verify_amount)  AS `verify_amount`,
    SUM(cancel_count)   AS `cancel_count`,
    SUM(cancel_amount)  AS `cancel_amount`
FROM 
(
    --支付系列
    SELECT
        `aids_seller_id`                        AS `sid`,
        DATE_FORMAT(`pay_time`, 'yyyy-MM-dd')   AS `fulldate`,
        DATE_FORMAT(`pay_time`, 'HH')           AS `hour`,
        1                                       AS `paid_count`,
        `order_pay_amount`                      AS `paid_amount`,
        0                                       AS `verify_count`,
        0                                       AS `verify_amount`,
        0                                       AS `cancel_count`,
        0                                       AS `cancel_amount`
    FROM dwd_order_boss_cockpit_instance_temp
    WHERE `pay_time` > CURRENT_DATE()
      AND ISNOTNULL(`aids_seller_id`)
    --验证系列
    UNION ALL
    SELECT
        `aids_seller_id`                            AS `sid`,
        DATE_FORMAT(`vertify_time`, 'yyyy-MM-dd')   AS `fulldate`,
        DATE_FORMAT(`vertify_time`, 'HH')           AS `hour`,
        0                                           AS `paid_count`,
        0                                           AS `paid_amount`,
        1                                           AS `verify_count`,
        `order_pay_amount`                          AS `verify_amount`,
        0                                           AS `cancel_count`,
        0                                           AS `cancel_amount`
    FROM dwd_order_boss_cockpit_instance_temp
    WHERE `vertify_time` > CURRENT_DATE()
      AND ISNOTNULL(`aids_seller_id`)

    --取消系列
    UNION ALL
    SELECT
        `aids_seller_id`                            AS `sid`,
        DATE_FORMAT(`cancel_time`, 'yyyy-MM-dd')    AS `fulldate`,
        DATE_FORMAT(`cancel_time`, 'HH')            AS `hour`,
        0                                           AS `paid_count`,
        0                                           AS `paid_amount`,
        0                                           AS `verify_count`,
        0                                           AS `verify_amount`,
        1                                           AS `cancel_count`,
        `order_pay_amount`                          AS `cancel_amount`
    FROM dwd_order_boss_cockpit_instance_temp
    WHERE `cancel_time` > CURRENT_DATE()
      AND ISNOTNULL(`aids_seller_id`)
)
GROUP BY
    `sid`,
    `fulldate`,
    `hour`

UNION ALL 

-- 景区维度
SELECT
    INT(`member_id`)    AS `sid`,
    `fulldate`,
    INT(`hour`),
    SUM(paid_count)     AS `paid_count`,
    SUM(paid_amount)    AS `paid_amount`,
    SUM(verify_count)   AS `verify_count`,
    SUM(verify_amount)  AS `verify_amount`,
    SUM(cancel_count)   AS `cancel_count`,
    SUM(cancel_amount)  AS `cancel_amount`
FROM 
(
    --支付系列
    SELECT
        `land_id`                               AS `land_id`,
        DATE_FORMAT(`pay_time`, 'yyyy-MM-dd')   AS `fulldate`,
        DATE_FORMAT(`pay_time`, 'HH')           AS `hour`,
        1                                       AS `paid_count`,
        `order_pay_amount`                      AS `paid_amount`,
        0                                       AS `verify_count`,
        0                                       AS `verify_amount`,
        0                                       AS `cancel_count`,
        0                                       AS `cancel_amount`
    FROM dwd_order_boss_cockpit_instance_temp
    WHERE aids_level IN(0, -1)
        AND `pay_time` > CURRENT_DATE()

    --验证系列
    UNION ALL
    SELECT
        `land_id`                                   AS `land_id`,
        DATE_FORMAT(`vertify_time`, 'yyyy-MM-dd')   AS `fulldate`,
        DATE_FORMAT(`vertify_time`, 'HH')           AS `hour`,
        0                                           AS `paid_count`,
        0                                           AS `paid_amount`,
        1                                           AS `verify_count`,
        `order_pay_amount`                          AS `verify_amount`,
        0                                           AS `cancel_count`,
        0                                           AS `cancel_amount`
    FROM dwd_order_boss_cockpit_instance_temp
    WHERE  aids_level IN(0, -1)
        AND `vertify_time` > CURRENT_DATE()
    
    --取消系列
    UNION ALL
    SELECT
        `land_id`                                   AS `land_id`,
        DATE_FORMAT(`cancel_time`, 'yyyy-MM-dd')    AS `fulldate`,
        DATE_FORMAT(`cancel_time`, 'HH')            AS `hour`,
        0                                           AS `paid_count`,
        0                                           AS `paid_amount`,
        0                                           AS `verify_count`,
        0                                           AS `verify_amount`,
        1                                           AS `cancel_count`,
        `order_pay_amount`                          AS `cancel_amount`
    FROM dwd_order_boss_cockpit_instance_temp
    WHERE  aids_level IN(0, -1)
        AND `cancel_time` > CURRENT_DATE()
) AS tmp 
INNER JOIN 
(
    SELECT land_id, member_id
    FROM ods_c_member_authorize_d_f
    WHERE pt='${ds}'
      AND land_id IS NOT NULL 
) AS memberTable
ON tmp.land_id = memberTable.land_id
GROUP BY
    `member_id`,
    `fulldate`,
    `hour`;
