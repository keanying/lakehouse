-- 预订游客性别年龄分布


CREATE TABLE IF NOT EXISTS ads_s_company_tourist_instance_stat_1h_i_workflow(
    `sid`       INT     COMMENT '商户ID',
    `fulldate`  STRING  COMMENT '全日期',
    `hour`      INT     COMMENT '小时',
    `sex`       STRING  COMMENT '性别',
    `age`       INT     COMMENT '年龄',
    `count`     INT     COMMENT '人数'
)STORED AS ORC;


INSERT OVERWRITE TABLE ads_s_company_tourist_instance_stat_1h_i_workflow
-- 分销订单维度
SELECT
    CAST(aids_seller_id AS INT) AS sid,
    `fulldate`,
    CAST(`hour` AS INT)         AS hour,
    `ticket_taker_sex`          AS `sex`,
    `ticket_taker_age`          AS `age`,
    COUNT(1)                    AS `count`
FROM 
(
    SELECT
        `aids_seller_id`,
        DATE_FORMAT(`pay_time`, 'yyyy-MM-dd')   AS `fulldate`,
        DATE_FORMAT(`pay_time`, 'HH')           AS `hour`,
        `ticket_taker_sex`,
        CASE
            WHEN `ticket_taker_age` BETWEEN 0 AND 7
            THEN 7
            WHEN `ticket_taker_age` BETWEEN 8 AND 17
            THEN 17
            WHEN `ticket_taker_age` BETWEEN 18 AND 27
            THEN 27
            WHEN `ticket_taker_age` BETWEEN 28 AND 40
            THEN 40
            WHEN `ticket_taker_age` BETWEEN 41 AND 60
            THEN 60
            ELSE -1
        END                                     AS `ticket_taker_age`
    FROM dwd_order_boss_cockpit_instance_temp
    WHERE `pay_time` > current_date() 
        AND isnotnull(`aids_seller_id`)
)
GROUP BY
    `aids_seller_id`,
    `fulldate`,
    `hour`,
    `ticket_taker_sex`,
    `ticket_taker_age`


UNION ALL 
-- 景区维度
SELECT
    CAST(member_id AS INT)  AS sid,
    `fulldate`,
    CAST(`hour` AS INT)     AS hour,
    `ticket_taker_sex`      AS `sex`,
    `ticket_taker_age`      AS `age`,
    COUNT(1)                AS `count`
FROM 
(
    SELECT
        `land_id`,
        DATE_FORMAT(`pay_time`, 'yyyy-MM-dd')   AS `fulldate`,
        DATE_FORMAT(`pay_time`, 'HH')           AS `hour`,
        `ticket_taker_sex`,
        CASE
            WHEN `ticket_taker_age` BETWEEN 0 AND 7
            THEN 7
            WHEN `ticket_taker_age` BETWEEN 8 AND 17
            THEN 17
            WHEN `ticket_taker_age` BETWEEN 18 AND 27
            THEN 27
            WHEN `ticket_taker_age` BETWEEN 28 AND 40
            THEN 40
            WHEN `ticket_taker_age` BETWEEN 41 AND 60
            THEN 60
            ELSE -1
        END                                     AS `ticket_taker_age`
    FROM dwd_order_boss_cockpit_instance_temp
    WHERE `pay_time` > current_date() 
        AND AIDS_LEVEL IN(0, -1)
        AND ISNOTNULL(`land_id`)
) AS tmp 
INNER JOIN 
(
    SELECT land_id, member_id
    FROM ods_c_member_authorize_d_f
    WHERE pt=${ds}
      AND land_id IS NOT NULL 
) AS memberTable
ON tmp.land_id = memberTable.land_id
GROUP BY
    `member_id`,
    `fulldate`,
    `hour`,
    `ticket_taker_sex`,
    `ticket_taker_age`;