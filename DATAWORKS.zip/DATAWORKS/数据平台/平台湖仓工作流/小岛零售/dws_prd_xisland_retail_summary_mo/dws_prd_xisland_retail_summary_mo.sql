--Serverless Spark SQL
--********************************************************************--
--author: 王海阳
--create time: 2026-10-12 19:05:50
--Serverless Spark SQL任务只能运行在独享资源组上
--********************************************************************--

SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;

CREATE TABLE IF NOT EXISTS dws_prd_xisland_retail_summary_mo (
    travel_year         INT             COMMENT '事件年份',
    sys_bind_id         INT             COMMENT '系统绑定ID',
    sup_id              INT             COMMENT '供应商id',
    shop_name           STRING          COMMENT '店铺名称',
    shop_category       STRING          COMMENT '店铺类别',
    product_name        STRING          COMMENT '产品名称',
    product_category    STRING          COMMENT '产品类别',
    pay_mode_name       STRING          COMMENT '支付方式名称',
    sales_amt           BIGINT          COMMENT '销售金额（分）',
    sales_qty           INT             COMMENT '销售数量',
    pay_amt             BIGINT          COMMENT '实付金额（分）',
    discount_amt        BIGINT          COMMENT '优惠金额（分）',
    refund_amt          BIGINT          COMMENT '退款金额（分）',
    refund_qty          BIGINT          COMMENT '退款数量'
) COMMENT '小岛餐饮零售商品每月汇总表'
PARTITIONED BY (
    travel_month INT COMMENT '事件年月 yyyyMM'
)
STORED AS ORC;


INSERT OVERWRITE TABLE dws_prd_xisland_retail_summary_mo PARTITION(`travel_month`) 
SELECT 
    travel_year                     AS travel_year,
    sys_bind_id                     AS sys_bind_id,
    sup_id                          AS sup_id,
    shop_name                       AS shop_name,
    shop_category                   AS shop_category,
    product_name                    AS product_name,
    product_category                AS product_category,
    pay_mode_name                   AS pay_mode_name,
    SUM(sales_amt)                  AS sales_amt,
    SUM(sales_qty)                  AS sales_qty,
    SUM(pay_amt)                    AS pay_amt,
    SUM(discount_amt)               AS discount_amt,
    SUM(refund_amt)                 AS refund_amt,
    SUM(refund_qty)                 AS refund_qty,
    travel_month
FROM dws_prd_xisland_retail_summary_di
WHERE SUBSTR(`travel_date`, 1, 6) = SUBSTR('${bizdate}', 1, 6) 
GROUP BY 
        travel_year,
        travel_month,
        sys_bind_id,
        sup_id,
        shop_name,
        shop_category,
        product_name,
        product_category,
        pay_mode_name;