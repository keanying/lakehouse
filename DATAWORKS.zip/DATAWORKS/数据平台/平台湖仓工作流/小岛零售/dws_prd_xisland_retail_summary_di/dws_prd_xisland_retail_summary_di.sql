--Serverless Spark SQL
--********************************************************************--
--author: 王海阳
--create time: 2026-10-12 19:05:50
--Serverless Spark SQL任务只能运行在独享资源组上
--********************************************************************--

SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;

CREATE TABLE IF NOT EXISTS dws_prd_xisland_retail_summary_di (
    travel_year         INT             COMMENT '事件年份',
    travel_month        INT             COMMENT '事件年月',
    travel_week         INT             COMMENT '事件年周',
    sys_bind_id         INT             COMMENT '系统绑定ID',
    sup_id              INT             COMMENT '供应商id',
    shop_name           STRING          COMMENT '店铺名称',
    shop_category       STRING          COMMENT '店铺类别',
    product_name        STRING          COMMENT '产品名称',
    product_category    STRING          COMMENT '产品类别',
    pay_mode_name       STRING          COMMENT '支付方式名称',
    sales_amt           BIGINT          COMMENT '销售金额（分）',
    sales_qty           INT             COMMENT '销售数量',
    pay_amt             BIGINT          COMMENT '实付金额（分）',
    discount_amt        BIGINT          COMMENT '优惠金额（分）',
    refund_amt          BIGINT          COMMENT '退款金额（分）',
    refund_qty          BIGINT          COMMENT '退款数量'
) COMMENT '小岛餐饮零售商品每日汇总表'
PARTITIONED BY (
    travel_date INT COMMENT '事件日期 yyyyMMdd（取order_create_time）'
)
STORED AS ORC;


INSERT OVERWRITE TABLE dws_prd_xisland_retail_summary_di PARTITION(`travel_date`) 
SELECT 
    INT(SUBSTR(travel_date, 1, 4))  AS travel_year,
    INT(SUBSTR(travel_date, 1, 6))  AS travel_month,
    INT(dim_isoweek.isoweek)        AS travel_week,
    sys_bind_id                     AS sys_bind_id,
    sup_id                          AS sup_id,
    shop_name                       AS shop_name,
    shop_category                   AS shop_category,
    product_name                    AS product_name,
    product_category                AS product_category,
    pay_mode_name                   AS pay_mode_name,
    SUM(sales_amt)                  AS sales_amt,
    SUM(sales_qty)                  AS sales_qty,
    SUM(pay_amt)                    AS pay_amt,
    SUM(discount_amt)               AS discount_amt,
    SUM(refund_amt)                 AS refund_amt,
    SUM(refund_qty)                 AS refund_qty,
    travel_date
FROM 
(

    SELECT 
        refundTab.con_sys_bind  AS sys_bind_id,
        member_id               AS sup_id,
        store_name              AS shop_name,
        business_type           AS shop_category,
        product_name            AS product_name,
        class_name              AS product_category,
        pay_type_name           AS pay_mode_name,
        amount*100              AS sales_amt,
        quantity                AS sales_qty,
        pay_amount*100          AS pay_amt,
        discount_amount*100     AS discount_amt,
        0                       AS refund_amt,
        0                       AS refund_qty, 
        travel_date
    FROM(
        SELECT 
            con_sys_bind,
            order_code,
            product_name,
            class_name,
            quantity,
            amount,
            pay_amount,
            discount_amount,
            travel_date
        FROM ods_retail_xisland_order_item_di
        WHERE travel_date = ${bizdate}
            AND length(product_name) > 0
    ) refundTab
    JOIN 
    (
        SELECT 
            order_code, 
            con_sys_bind,
            member_id,
            store_name,
            business_type,
            pay_type_name
        FROM ods_retail_xisland_order_di
        WHERE travel_date = ${bizdate}
    ) orderTab
    ON refundTab.con_sys_bind = orderTab.con_sys_bind AND refundTab.order_code = orderTab.order_code
   
    UNION ALL
 
    SELECT 
        refundItemTab.con_sys_bind      AS sys_bind_id,
        member_id                       AS sup_id,
        store_name                      AS shop_name,
        business_type                   AS shop_category,
        product_name                    AS product_name,
        class_name                      AS product_category,
        pay_type_name                   AS pay_mode_name,
        0                               AS sales_amt,
        0                               AS sales_qty,
        0                               AS pay_amt,
        0                               AS discount_amt,
        refund_amount*100               AS refund_amt,
        quantity                        AS refund_qty,
        travel_date
    FROM(
        SELECT
            con_sys_bind, 
            order_code,
            refund_code,
            product_name,
            class_name,
            refund_amount,
            quantity,
            travel_date
        FROM ods_retail_xisland_refund_order_item_di
        WHERE travel_date = ${bizdate}
            AND length(product_name) > 0
    ) refundItemTab
    JOIN 
    (
        SELECT 
            order_code, 
            con_sys_bind,
            member_id,
            store_name,
            business_type,
            pay_type_name
        FROM ods_retail_xisland_order_di
        WHERE travel_date >= CAST(DATE_FORMAT(DATE_SUB(TO_DATE(CAST(${bizdate} AS STRING), 'yyyyMMdd'), 62), 'yyyyMMdd') AS INT)
    ) orderTab
    ON refundItemTab.con_sys_bind = orderTab.con_sys_bind and refundItemTab.order_code = orderTab.order_code
    JOIN 
    (
        SELECT
            con_sys_bind, 
            refund_code
        FROM ods_retail_xisland_refund_order_di
        WHERE travel_date = ${bizdate}
            AND refund_status IN (2, 6, 7)
    ) refundTab
    ON refundItemTab.con_sys_bind = refundTab.con_sys_bind and refundItemTab.refund_code = refundTab.refund_code
) countTab
LEFT JOIN dim_date_isoweek_o_f dim_isoweek 
ON countTab.`travel_date` = dim_isoweek.`fulldate`
GROUP BY 
        travel_date,
        sys_bind_id,
        sup_id,
        shop_name,
        shop_category,
        product_name,
        product_category,
        pay_mode_name,
        dim_isoweek.isoweek;