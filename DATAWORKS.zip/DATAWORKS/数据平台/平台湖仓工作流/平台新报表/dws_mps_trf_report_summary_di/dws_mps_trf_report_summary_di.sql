--Serverless Spark SQL
--********************************************************************--
--author: 王海阳
--create time: 2026-08-13 19:35:55
--Serverless Spark SQL任务只能运行在独享资源组上
--********************************************************************--

CREATE TABLE IF NOT EXISTS dws_mps_trf_report_summary_di(
    `year`                          INT             COMMENT '年',
    `month`                         INT             COMMENT '年月',
    `sup_id`                        BIGINT          COMMENT '供应商id',
    `sales_channel_id`              INT             COMMENT '销售渠道ID',
    `sales_channel_name`            STRING          COMMENT '销售渠道名称',
    
    `sales_order_qty`               BIGINT          COMMENT '销售订单数',
    `sales_ticket_qty`              BIGINT          COMMENT '销售票数',
    `sales_income_amt`              DECIMAL(18,2)   COMMENT '销售收入金额',
    `sales_expense_amt`             DECIMAL(18,2)   COMMENT '销售支出金额',
    `sales_income_discount_amt`     DECIMAL(18,2)   COMMENT '销售收入优惠金额',
    `sales_expense_discount_amt`    DECIMAL(18,2)   COMMENT '销售支出优惠金额',

    `verify_ticket_qty`             BIGINT          COMMENT '核销票数',
    `verify_income_amt`             DECIMAL(18,2)   COMMENT '核销收入金额',
    `verify_expense_amt`            DECIMAL(18,2)   COMMENT '核销支出金额',
    `verify_income_discount_amt`    DECIMAL(18,2)   COMMENT '核销收入优惠金额',
    `verify_expense_discount_amt`   DECIMAL(18,2)   COMMENT '核销支出优惠金额',

    `cancel_ticket_qty`             BIGINT          COMMENT '取消票数',
    `cancel_income_amt`             DECIMAL(18,2)   COMMENT '取消收入金额',
    `cancel_expense_amt`            DECIMAL(18,2)   COMMENT '取消支出金额',
    `cancel_income_discount_amt`    DECIMAL(18,2)   COMMENT '取消收入优惠金额',
    `cancel_expense_discount_amt`   DECIMAL(18,2)   COMMENT '取消支出优惠金额',
    `cancel_income_fee_amt`         DECIMAL(18,2)   COMMENT '取消收入手续费',
    `cancel_expense_fee_amt`        DECIMAL(18,2)   COMMENT '取消支出手续费',

    `revoke_ticket_qty`             BIGINT          COMMENT '撤销撤改票数',
    `revoke_income_amt`             DECIMAL(18,2)   COMMENT '撤销撤改收入金额',
    `revoke_expense_amt`            DECIMAL(18,2)   COMMENT '撤销撤改支出金额',
    `revoke_income_discount_amt`    DECIMAL(18,2)   COMMENT '撤销撤改收入优惠金额',
    `revoke_expense_discount_amt`   DECIMAL(18,2)   COMMENT '撤销撤改支出优惠金额',
    `revoke_income_fee_amt`         DECIMAL(18,2)   COMMENT '撤销撤改收入手续费',
    `revoke_expense_fee_amt`        DECIMAL(18,2)   COMMENT '撤销撤改支出手续费',
        
    `after_sale_ticket_qty`         BIGINT          COMMENT '售后票数',
    `after_sale_income_amt`         DECIMAL(18,2)   COMMENT '售后收入金额',
    `after_sale_expense_amt`        DECIMAL(18,2)   COMMENT '售后支出金额',
        
    `collect_ticket_qty`            BIGINT          COMMENT '取票票数',
    `reprint_ticket_qty`            BIGINT          COMMENT '重打印票数',

    `net_sales_ticket_qty`          BIGINT          COMMENT '净销售票数,完成支付的有效总票数,不含取消、撤销、售后',
    `net_sales_income_amt`          DECIMAL(18,2)   COMMENT '净销售收入金额,完成支付的有效收入金额,不含取消、撤销、售后',
    `net_sales_expense_amt`         DECIMAL(18,2)   COMMENT '净销售支出金额,完成支付的有效支出金额,不含取消、撤销、售后',
        
    `net_verify_ticket_qty`         BIGINT          COMMENT '净核销票数,完成核销的有效总票数,不含撤销、售后',
    `net_verify_income_amt`         DECIMAL(18,2)   COMMENT '净核销收入金额,完成核销的有效收入金额,不含撤销、售后',
    `net_verify_expense_amt`        DECIMAL(18,2)   COMMENT '净核销支出金额,完成核销的有效支出金额,不含撤销、售后',
        
    `refund_fee_income_amt`         DECIMAL(18,2)   COMMENT '退票收入手续费,取消加撤销撤改收入手续费',
    `refund_fee_expense_amt`        DECIMAL(18,2)   COMMENT '退票支出手续费,取消加撤销撤改支出手续费',
        
    `pickup_ticket_qty`             BIGINT          COMMENT '总取票票数(取票+重打印票数)'
)
COMMENT '供应商销售渠道每日报表汇总'
PARTITIONED BY 
(
    travel_date  INT COMMENT '统计日期'
)
STORED AS ORC
;

INSERT OVERWRITE TABLE dws_mps_trf_report_summary_di PARTITION(`travel_date`) 
SELECT
    INT(YEAR(operated_at))                                                              AS `year`,
    INT(MONTH(operated_at))                                                             AS `month`,
    merchant_id                                                                         AS `sup_id`,
    sale_channel                                                                        AS `sales_channel_id`,
    CASE sale_channel
		    WHEN 0  THEN '分销商下单'
		    WHEN 1  THEN '普通用户支付'
		    WHEN 2  THEN '用户手机支付'
		    WHEN 9  THEN '会员卡购票'
		    WHEN 10 THEN '云票务'
		    WHEN 11 THEN '微商城'
		    WHEN 12 THEN '自助机'
		    WHEN 13 THEN '二级店铺'
		    WHEN 14 THEN '闸机购票'
		    WHEN 15 THEN '智能终端'
		    WHEN 16 THEN '计调下单'
		    WHEN 17 THEN '淘宝码商(飞猪)'
		    WHEN 18 THEN '年卡'
		    WHEN 19 THEN '微平台'
		    WHEN 20 THEN 'OTA'
		    WHEN 21 THEN '兑换码购票'
		    WHEN 22 THEN '一卡通'
		    WHEN 23 THEN '套票子票下单'
		    WHEN 24 THEN '团队订单'
		    WHEN 33 THEN 'e福州'
		    WHEN 34 THEN '拼团'
		    WHEN 35 THEN '积分商城'
		    WHEN 36 THEN 'POS支付'
		    WHEN 38 THEN '招行'
		    WHEN 39 THEN '银联商务'
		    WHEN 40 THEN '银联pos支付'
		    WHEN 41 THEN '威富通'
		    WHEN 42 THEN '易宝'
		    WHEN 43 THEN '微信-微票房'
		    WHEN 44 THEN '报团计调下单'
		    WHEN 45 THEN '云闪付'
		    WHEN 46 THEN '断网离线订单'
		    WHEN 47 THEN '员工卡'
		    WHEN 48 THEN '手牌'
		    WHEN 49 THEN '桌面云票务'
		    WHEN 50 THEN 'APP'
		    WHEN 55 THEN '特殊团队预约'
		    WHEN 56 THEN '小程序'
		    WHEN 57 THEN '抖音-微票房'
		    WHEN 58 THEN '阿里供销'
		    WHEN 59 THEN '团购导码'
		    WHEN 60 THEN '京津冀年卡'
		    WHEN 61 THEN '水韵江苏年卡'
		    WHEN 62 THEN '武汉老年卡'
		    WHEN 63 THEN '宁镇扬游园卡'
		    WHEN 64 THEN '通兑券兑换'
		    ELSE CONCAT('未知渠道(', sale_channel, ')') END                              AS sales_channel_name,
    COUNT(DISTINCT IF(pay_count > 0, order_no, NULL))                                   AS sales_order_qty,
    SUM(pay_count)                                                                      AS sales_ticket_qty,
	SUM(pay_sale_price)/100                                                             AS sales_income_amt,
    SUM(pay_cost_price)/100                                                             AS sales_expense_amt,
	SUM(pay_sale_discount_price)/100                                                    AS sales_income_discount_amt,
    SUM(pay_cost_discount_price)/100                                                    AS sales_expense_discount_amt,
    SUM(verify_count)                                                                   AS verify_ticket_qty,
	SUM(verify_sale_price)/100                                                          AS verify_income_amt,
    SUM(verify_cost_price)/100                                                          AS verify_expense_amt,
	SUM(verify_sale_discount_price)/100                                                 AS verify_income_discount_amt,
    SUM(verify_cost_discount_price)/100                                                 AS verify_expense_discount_amt,
    SUM(cancel_count)                                                                   AS cancel_ticket_qty,
	SUM(cancel_sale_price)/100                                                          AS cancel_income_amt,
    SUM(cancel_cost_price)/100                                                          AS cancel_expense_amt,
	SUM(cancel_sale_discount_price)/100                                                 AS cancel_income_discount_amt,
    SUM(cancel_cost_discount_price)/100                                                 AS cancel_expense_discount_amt,
	SUM(cancel_sale_fee)/100                                                            AS cancel_income_fee_amt,
    SUM(cancel_cost_fee)/100                                                            AS cancel_expense_fee_amt,
    SUM(revoke_count)                                                                   AS revoke_ticket_qty,
	SUM(revoke_sale_price)/100                                                          AS revoke_income_amt,
    SUM(revoke_cost_price)/100                                                          AS revoke_expense_amt,
	SUM(revoke_sale_discount_price)/100                                                 AS revoke_income_discount_amt,
    SUM(revoke_cost_discount_price)/100                                                 AS revoke_expense_discount_amt,
	SUM(revoke_sale_fee)/100                                                            AS revoke_income_fee_amt,
    SUM(revoke_cost_fee)/100                                                            AS revoke_expense_fee_amt,
    SUM(after_sale_count)                                                               AS after_sale_ticket_qty,
    SUM(after_sale_price)/100                                                           AS after_sale_income_amt,
    SUM(after_cost_price)/100                                                           AS after_sale_expense_amt,
    COALESCE(SUM(collect_count),0)                                                      AS collect_ticket_qty,
    COALESCE(SUM(reprint_count),0)                                                      AS reprint_ticket_qty,
    SUM(pay_count - cancel_count - revoke_count - after_sale_count)                     AS net_sales_ticket_qty,
    SUM(pay_sale_price - cancel_sale_price - revoke_sale_price - after_sale_price)/100  AS net_sales_income_amt,
    SUM(pay_cost_price - cancel_cost_price - revoke_cost_price - after_cost_price)/100  AS net_sales_expense_amt,
    SUM(verify_count - revoke_count - after_sale_count)                                 AS net_verify_ticket_qty,
    SUM(verify_sale_price - revoke_sale_price - after_sale_price)/100                   AS net_verify_income_amt,
    SUM(verify_cost_price - revoke_cost_price - after_cost_price)/100                   AS net_verify_expense_amt,
    SUM(cancel_sale_fee + revoke_sale_fee)/100                                          AS refund_fee_income_amt,
    SUM(cancel_cost_fee + revoke_cost_fee)/100                                          AS refund_fee_expense_amt,
    COALESCE(SUM(collect_count + reprint_count),0)					                    AS pickup_ticket_qty,
    travel_date
FROM dwd_r_report_dwm_common_di
WHERE travel_date = ${bizdate}
GROUP BY
    YEAR(operated_at),
    MONTH(operated_at),
    merchant_id,
    sale_channel,
    travel_date;
