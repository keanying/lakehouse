--Serverless Spark SQL
--********************************************************************--
--author: 王海阳
--create time: 2026-09-09 11:37:53
--Serverless Spark SQL任务只能运行在独享资源组上
--********************************************************************--
SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;

CREATE TABLE IF NOT EXISTS dws_tps_aioc_summary_di (
      `travel_year`                       INT     COMMENT '操作年份',
      `travel_month`                      INT     COMMENT '操作月份',
      `travel_week`                       INT     COMMENT '操作年周',
      `sup_id`                            INT     COMMENT '原始供应商id',
      `scenic_id`                         INT     COMMENT '景区ID',
      `ticket_id`                         INT     COMMENT '门票id',
      `product_type`                      STRING  COMMENT '景区类型：A景区B线路C酒店F套票',
      `product_id`                        INT     COMMENT '产品SPUID',
      `operation_channel_id`              INT     COMMENT '操作渠道ID  1：云票务 2：微商城 3：闸机 4：手持机',
      `operation_channel_name`            STRING  COMMENT '操作渠道名称',
      `order_pay_funding_type_id`         INT     COMMENT '订单支付方式ID',
      `order_pay_funding_type_name`       STRING  COMMENT '订单支付方式名称',
      `operation1_qty`                    INT     COMMENT '操作次数-交易类型ID:1(充值)',
      `operation1_amt`                    BIGINT  COMMENT '操作金额-交易类型ID:1(充值)',
      `operation2_qty`                    INT     COMMENT '操作次数-交易类型ID:2(工本费)',
      `operation2_amt`                    BIGINT  COMMENT '操作金额-交易类型ID:2(工本费)',
      `operation3_qty`                    INT     COMMENT '操作次数-交易类型ID:3(押金)',
      `operation3_amt`                    BIGINT  COMMENT '操作金额-交易类型ID:3(押金)',
      `operation4_qty`                    INT     COMMENT '操作次数-交易类型ID:4(激活)',
      `operation4_amt`                    BIGINT  COMMENT '操作金额-交易类型ID:4(激活)',
      `operation5_qty`                    INT     COMMENT '操作次数-交易类型ID:5(补卡)',
      `operation5_amt`                    BIGINT  COMMENT '操作金额-交易类型ID:5(补卡)',
      `operation6_qty`                    INT     COMMENT '操作次数-交易类型ID:6(退卡)',
      `operation6_amt`                    BIGINT  COMMENT '操作金额-交易类型ID:6(退卡)',
      `operation7_qty`                    INT     COMMENT '操作次数-交易类型ID:7(仅退款)',
      `operation7_amt`                    BIGINT  COMMENT '操作金额-交易类型ID:7(仅退款)',
      `operation8_qty`                    INT     COMMENT '操作次数-交易类型ID:8(奖励金)',
      `operation8_amt`                    BIGINT  COMMENT '操作金额-交易类型ID:8(奖励金)',
      `operation9_qty`                    INT     COMMENT '操作次数-交易类型ID:9(年卡套餐购买)',
      `operation9_amt`                    BIGINT  COMMENT '操作金额-交易类型ID:9(年卡套餐购买)',
      `operation10_qty`                   INT     COMMENT '操作次数-交易类型ID:10(年卡套餐续费)',
      `operation10_amt`                   BIGINT  COMMENT '操作金额-交易类型ID:10(年卡套餐续费)',
      `operation11_qty`                   INT     COMMENT '操作次数-交易类型ID:11(年卡套餐激活)',
      `operation11_amt`                   BIGINT  COMMENT '操作金额-交易类型ID:11(年卡套餐激活)',
      `operation12_qty`                   INT     COMMENT '操作次数-交易类型ID:12(普通订单消费)',
      `operation12_amt`                   BIGINT  COMMENT '操作金额-交易类型ID:12(普通订单消费)',
      `operation13_qty`                   INT     COMMENT '操作次数-交易类型ID:13(挂失)',
      `operation13_amt`                   BIGINT  COMMENT '操作金额-交易类型ID:13(挂失)',
      `operation14_qty`                   INT     COMMENT '操作次数-交易类型ID:14(买单赠送)',
      `operation14_amt`                   BIGINT  COMMENT '操作金额-交易类型ID:14(买单赠送)',
      `operation15_qty`                   INT     COMMENT '操作次数-交易类型ID:15(刷卡赠送)',
      `operation15_amt`                   BIGINT  COMMENT '操作金额-交易类型ID:15(刷卡赠送)',
      `operation16_qty`                   INT     COMMENT '操作次数-交易类型ID:16(取票绑卡)',
      `operation16_amt`                   BIGINT  COMMENT '操作金额-交易类型ID:16(取票绑卡)',
      `operation17_qty`                   INT     COMMENT '操作次数-交易类型ID:17(终端扣款)',
      `operation17_amt`                   BIGINT  COMMENT '操作金额-交易类型ID:17(终端扣款)',
      `operation18_qty`                   INT     COMMENT '操作次数-交易类型ID:18(终端退款)',
      `operation18_amt`                   BIGINT  COMMENT '操作金额-交易类型ID:18(终端退款)',
      `operation19_qty`                   INT     COMMENT '操作次数-交易类型ID:19(商家取消赠送)',
      `operation19_amt`                   BIGINT  COMMENT '操作金额-交易类型ID:19(商家取消赠送)',
      `operation20_qty`                   INT     COMMENT '操作次数-交易类型ID:20(买单赠送取消)',
      `operation20_amt`                   BIGINT  COMMENT '操作金额-交易类型ID:20(买单赠送取消)',
      `operation21_qty`                   INT     COMMENT '操作次数-交易类型ID:21(预留)',
      `operation21_amt`                   BIGINT  COMMENT '操作金额-交易类型ID:21(预留)',
      `operation22_qty`                   INT     COMMENT '操作次数-交易类型ID:22(预留)',
      `operation22_amt`                   BIGINT  COMMENT '操作金额-交易类型ID:22(预留)',
      `operation23_qty`                   INT     COMMENT '操作次数-交易类型ID:23(预留)',
      `operation23_amt`                   BIGINT  COMMENT '操作金额-交易类型ID:23(预留)',
      `operation24_qty`                   INT     COMMENT '操作次数-交易类型ID:24(预留)',
      `operation24_amt`                   BIGINT  COMMENT '操作金额-交易类型ID:24(预留)',
      `operation25_qty`                   INT     COMMENT '操作次数-交易类型ID:25(预留)',
      `operation25_amt`                   BIGINT  COMMENT '操作金额-交易类型ID:25(预留)',
      `operation26_qty`                   INT     COMMENT '操作次数-交易类型ID:26(预留)',
      `operation26_amt`                   BIGINT  COMMENT '操作金额-交易类型ID:26(预留)',
      `operation27_qty`                   INT     COMMENT '操作次数-交易类型ID:27(预留)',
      `operation27_amt`                   BIGINT  COMMENT '操作金额-交易类型ID:27(预留)',
      `operation28_qty`                   INT     COMMENT '操作次数-交易类型ID:28(预留)',
      `operation28_amt`                   BIGINT  COMMENT '操作金额-交易类型ID:28(预留)',
      `operation29_qty`                   INT     COMMENT '操作次数-交易类型ID:29(预留)',
      `operation29_amt`                   BIGINT  COMMENT '操作金额-交易类型ID:29(预留)',
      `operation30_qty`                   INT     COMMENT '操作次数-交易类型ID:30(预留)',
      `operation30_amt`                   BIGINT  COMMENT '操作金额-交易类型ID:30(预留)',

      `operation_card_consume_qty`        INT     COMMENT '操作次数-卡消费',
      `operation_card_consume_amt`        BIGINT  COMMENT '操作金额-卡消费',
      `operation_card_refund_qty`         INT     COMMENT '操作次数-卡退款',
      `operation_card_refund_amt`         BIGINT  COMMENT '操作金额-卡退款'
  )COMMENT '每日一卡通产品门票汇总表' 
  PARTITIONED BY 
  (
        travel_date INT COMMENT '操作日期 yyyyMMdd'
  ) 
  STORED AS ORC;

REFRESH TABLE ods_pft_allinone_card_trades_di;
REFRESH TABLE ods_pft_card_order_journal_di;
REFRESH TABLE ods_pft_card_order_refund_journal_di;


DROP VIEW IF EXISTS cache_table_pft_ordernum;
CACHE TABLE cache_table_pft_ordernum
AS 
SELECT ordernum
FROM ods_pft_allinone_card_trades_di
      WHERE travel_date = ${bizdate}
      AND ordernum RLIKE '^[0-9]'
UNION
SELECT ordernum
FROM ods_pft_card_order_journal_di
      WHERE travel_date = ${bizdate}
      AND pay_status != 3
      AND ordernum NOT LIKE 'CMB%'
UNION
SELECT ordernum
FROM ods_pft_card_order_refund_journal_di
WHERE travel_date = ${bizdate}
      AND refund_status = 2
;

DROP VIEW IF EXISTS cache_table_pft_order_info;
CACHE TABLE cache_table_pft_order_info
AS 
SELECT 
      orderid, 
      lid, 
      tid,
      pid,
      product_type,
      paymode
FROM dim_order_d_i
WHERE orderdate >= CAST(DATE_FORMAT(DATE_SUB(TO_DATE(CAST(${bizdate} AS STRING), 'yyyyMMdd'), 732), 'yyyyMMdd') AS INT)
AND orderid in(
      SELECT ordernum 
      FROM cache_table_pft_ordernum
);


INSERT OVERWRITE TABLE dws_tps_aioc_summary_di PARTITION(travel_date)
SELECT 
      INT(LEFT(countTab.travel_date, 4))                                            AS travel_year,
      INT(LEFT(countTab.travel_date, 6))                                            AS travel_month,
      INT(dim_isoweek.isoweek)                                                      AS travel_week,
      countTab.sup_id                                                               AS sup_id,
      countTab.scenic_id                                                            AS scenic_id,
      countTab.ticket_id                                                            AS ticket_id,
      countTab.product_type                                                         AS product_type,
      countTab.product_id                                                           AS product_id,
      countTab.operation_channel_id                                                 AS operation_channel_id,
      CASE
            WHEN operation_channel_id = 0 THEN '未知操作渠道'
            WHEN operation_channel_id = 1 THEN '云票务'
            WHEN operation_channel_id = 2 THEN '微商城'
            WHEN operation_channel_id = 3 THEN '闸机'
            WHEN operation_channel_id = 4 THEN '手持机'
            WHEN operation_channel_id = 5 THEN '小程序'
            WHEN operation_channel_id = 6 THEN '平台'
            WHEN operation_channel_id IS NULL THEN '未知'
            ELSE CONCAT('未知操作渠道(', CAST(operation_channel_id AS STRING), ')')
      END                                                                           AS operation_channel_name,
      COALESCE(pay_dict.pay_channel_mapping_id, countTab.order_pay_funding_type_id) AS order_pay_funding_type_id,
      MAX(COALESCE(pay_dict.pay_channel_mapping_name, CONCAT('未知支付渠道(', CAST(order_pay_funding_type_id AS STRING), ')')))         
                                                                                    AS order_pay_funding_type_name,
      SUM(IF(operation_type=1, countTab.operation_qty, 0))                          AS operation1_qty,
      SUM(IF(operation_type=1, countTab.operation_amt, 0))                          AS operation1_amt,
      SUM(IF(operation_type=2, countTab.operation_qty, 0))                          AS operation2_qty,
      SUM(IF(operation_type=2, countTab.operation_amt, 0))                          AS operation2_amt,
      SUM(IF(operation_type=3, countTab.operation_qty, 0))                          AS operation3_qty,
      SUM(IF(operation_type=3, countTab.operation_amt, 0))                          AS operation3_amt,
      SUM(IF(operation_type=4, countTab.operation_qty, 0))                          AS operation4_qty,
      SUM(IF(operation_type=4, countTab.operation_amt, 0))                          AS operation4_amt,
      SUM(IF(operation_type=5, countTab.operation_qty, 0))                          AS operation5_qty,
      SUM(IF(operation_type=5, countTab.operation_amt, 0))                          AS operation5_amt,
      SUM(IF(operation_type=6, countTab.operation_qty, 0))                          AS operation6_qty,
      SUM(IF(operation_type=6, countTab.operation_amt, 0))                          AS operation6_amt,
      SUM(IF(operation_type=7, countTab.operation_qty, 0))                          AS operation7_qty,
      SUM(IF(operation_type=7, countTab.operation_amt, 0))                          AS operation7_amt,
      SUM(IF(operation_type=8, countTab.operation_qty, 0))                          AS operation8_qty,
      SUM(IF(operation_type=8, countTab.operation_amt, 0))                          AS operation8_amt,
      SUM(IF(operation_type=9, countTab.operation_qty, 0))                          AS operation9_qty,
      SUM(IF(operation_type=9, countTab.operation_amt, 0))                          AS operation9_amt,
      SUM(IF(operation_type=10, countTab.operation_qty, 0))                         AS operation10_qty,
      SUM(IF(operation_type=10, countTab.operation_amt, 0))                         AS operation10_amt,
      SUM(IF(operation_type=11, countTab.operation_qty, 0))                         AS operation11_qty,
      SUM(IF(operation_type=11, countTab.operation_amt, 0))                         AS operation11_amt,
      SUM(IF(operation_type=12, countTab.operation_qty, 0))                         AS operation12_qty,
      SUM(IF(operation_type=12, countTab.operation_amt, 0))                         AS operation12_amt,
      SUM(IF(operation_type=13, countTab.operation_qty, 0))                         AS operation13_qty,
      SUM(IF(operation_type=13, countTab.operation_amt, 0))                         AS operation13_amt,
      SUM(IF(operation_type=14, countTab.operation_qty, 0))                         AS operation14_qty,
      SUM(IF(operation_type=14, countTab.operation_amt, 0))                         AS operation14_amt,
      SUM(IF(operation_type=15, countTab.operation_qty, 0))                         AS operation15_qty,
      SUM(IF(operation_type=15, countTab.operation_amt, 0))                         AS operation15_amt,
      SUM(IF(operation_type=16, countTab.operation_qty, 0))                         AS operation16_qty,
      SUM(IF(operation_type=16, countTab.operation_amt, 0))                         AS operation16_amt,
      SUM(IF(operation_type=17, countTab.operation_qty, 0))                         AS operation17_qty,
      SUM(IF(operation_type=17, countTab.operation_amt, 0))                         AS operation17_amt,
      SUM(IF(operation_type=18, countTab.operation_qty, 0))                         AS operation18_qty,
      SUM(IF(operation_type=18, countTab.operation_amt, 0))                         AS operation18_amt,
      SUM(IF(operation_type=19, countTab.operation_qty, 0))                         AS operation19_qty,
      SUM(IF(operation_type=19, countTab.operation_amt, 0))                         AS operation19_amt,
      SUM(IF(operation_type=20, countTab.operation_qty, 0))                         AS operation20_qty,
      SUM(IF(operation_type=20, countTab.operation_amt, 0))                         AS operation20_amt,
      SUM(IF(operation_type=21, countTab.operation_qty, 0))                         AS operation21_qty,
      SUM(IF(operation_type=21, countTab.operation_amt, 0))                         AS operation21_amt,
      SUM(IF(operation_type=22, countTab.operation_qty, 0))                         AS operation22_qty,
      SUM(IF(operation_type=22, countTab.operation_amt, 0))                         AS operation22_amt,
      SUM(IF(operation_type=23, countTab.operation_qty, 0))                         AS operation23_qty,
      SUM(IF(operation_type=23, countTab.operation_amt, 0))                         AS operation23_amt,
      SUM(IF(operation_type=24, countTab.operation_qty, 0))                         AS operation24_qty,
      SUM(IF(operation_type=24, countTab.operation_amt, 0))                         AS operation24_amt,
      SUM(IF(operation_type=25, countTab.operation_qty, 0))                         AS operation25_qty,
      SUM(IF(operation_type=25, countTab.operation_amt, 0))                         AS operation25_amt,
      SUM(IF(operation_type=26, countTab.operation_qty, 0))                         AS operation26_qty,
      SUM(IF(operation_type=26, countTab.operation_amt, 0))                         AS operation26_amt,
      SUM(IF(operation_type=27, countTab.operation_qty, 0))                         AS operation27_qty,
      SUM(IF(operation_type=27, countTab.operation_amt, 0))                         AS operation27_amt,
      SUM(IF(operation_type=28, countTab.operation_qty, 0))                         AS operation28_qty,
      SUM(IF(operation_type=28, countTab.operation_amt, 0))                         AS operation28_amt,
      SUM(IF(operation_type=29, countTab.operation_qty, 0))                         AS operation29_qty,
      SUM(IF(operation_type=29, countTab.operation_amt, 0))                         AS operation29_amt,
      SUM(IF(operation_type=30, countTab.operation_qty, 0))                         AS operation30_qty,
      SUM(IF(operation_type=30, countTab.operation_amt, 0))                         AS operation30_amt,
      SUM(IF(operation_type='consume', countTab.operation_qty, 0))                  AS operation_card_consume_qty,
      SUM(IF(operation_type='consume', countTab.operation_amt, 0))                  AS operation_card_consume_amt,
      SUM(IF(operation_type='refund', countTab.operation_qty, 0))                   AS operation_card_refund_qty,
      SUM(IF(operation_type='refund', countTab.operation_amt, 0))                   AS operation_card_refund_amt,

      countTab.travel_date
FROM(
      -- 一卡通流水表票付通订单汇总
      SELECT 
            sid                           AS sup_id,
            COALESCE(lid, 0)              AS scenic_id,
            COALESCE(tid, 0)              AS ticket_id,
            COALESCE(product_type, '')    AS product_type,
            COALESCE(pid, 0)              AS product_id,
            channel                       AS operation_channel_id,
            COALESCE(paymode, 255)        AS order_pay_funding_type_id,
            operation_type                AS operation_type,
            COUNT(1)                      AS operation_qty,
            SUM(money)                    AS operation_amt,
            travel_date
      FROM(
            SELECT 
                  sid, 
                  ordernum, 
                  pay_type, 
                  channel,
                  operation_type,
                  money,
                  travel_date
            FROM ods_pft_allinone_card_trades_di
            WHERE travel_date = ${bizdate}
            AND ordernum RLIKE '^[0-9]'
      ) aiocTab
      LEFT JOIN cache_table_pft_order_info orderTab
      ON aiocTab.ordernum = orderTab.orderid
      GROUP BY 
            sid,
            COALESCE(lid, 0),
            COALESCE(tid, 0),
            COALESCE(product_type, ''),
            COALESCE(pid, 0),
            channel,
            COALESCE(paymode, 255),
            operation_type,
            travel_date
      
      -- 一卡通流水表非票付通订单汇总
      UNION ALL 
      SELECT 
            sid                           AS sup_id,
            0                             AS scenic_id,
            0                             AS ticket_id,
            ''                            AS product_type,
            0                             AS product_id,
            channel                       AS operation_channel_id,
            255                           AS paymode,
            operation_type                AS operation_type,
            COUNT(1)                      AS operation_qty,
            SUM(money)                    AS operation_amt,
            travel_date
      FROM ods_pft_allinone_card_trades_di
      WHERE travel_date = ${bizdate}
      AND ordernum NOT RLIKE '^[0-9]'
      GROUP BY 
            sid,
            channel,
            operation_type,
            travel_date

      UNION ALL

      -- 一卡通卡消费订单汇总
      SELECT 
            sid                           AS sup_id,
            COALESCE(lid, 0)              AS scenic_id,
            COALESCE(tid, 0)              AS ticket_id,
            COALESCE(product_type, '')    AS product_type,
            COALESCE(pid, 0)              AS product_id,
            0                             AS operation_channel_id,
            COALESCE(paymode, 255)        AS order_pay_funding_type_id,
            operation_type                AS operation_type,
            COUNT(1)                      AS operation_qty,
            SUM(money)                    AS operation_amt,
            travel_date
      FROM(
            SELECT 
                  sid, 
                  ordernum, 
                  0         AS channel,
                  'consume' AS operation_type,
                  money,
                  travel_date
            FROM ods_pft_card_order_journal_di
            WHERE travel_date = ${bizdate}
            AND pay_status != 3
            AND ordernum NOT LIKE 'CMB%'
            AND ordernum NOT IN(
                  SELECT ordernum
                  FROM ods_pft_allinone_card_trades_di
                  WHERE pay_type = 4 
                  AND money > 0 
                  AND operation_type!=18
            )
      ) journalTab
      LEFT JOIN cache_table_pft_order_info orderTab
      ON journalTab.ordernum = orderTab.orderid
      GROUP BY 
            sid,
            COALESCE(lid, 0),
            COALESCE(tid, 0),
            COALESCE(product_type, ''),
            COALESCE(pid, 0),
            COALESCE(paymode, 255),
            operation_type,
            travel_date

      UNION ALL

      -- 一卡通卡退款订单汇总
      SELECT 
            sid                           AS sup_id,
            COALESCE(lid, 0)              AS scenic_id,
            COALESCE(tid, 0)              AS ticket_id,
            COALESCE(product_type, '')    AS product_type,
            COALESCE(pid, 0)              AS product_id,
            0                             AS operation_channel_id,
            COALESCE(paymode, 255)        AS order_pay_funding_type_id,
            operation_type                AS operation_type,
            COUNT(1)                      AS operation_qty,
            SUM(refund_money)             AS operation_amt,
            travel_date
      FROM(
            SELECT 
                  sid, 
                  ordernum, 
                  0         AS channel,
                  'refund' AS operation_type,
                  refund_money,
                  travel_date
            FROM ods_pft_card_order_refund_journal_di
            WHERE travel_date = ${bizdate}
            AND refund_status = 2
      ) journalTab
      LEFT JOIN cache_table_pft_order_info orderTab
      ON journalTab.ordernum = orderTab.orderid
      GROUP BY 
            sid,
            COALESCE(lid, 0),
            COALESCE(tid, 0),
            COALESCE(product_type, ''),
            COALESCE(pid, 0),
            COALESCE(paymode, 255),
            operation_type,
            travel_date
) countTab
LEFT JOIN dim_date_isoweek_o_f dim_isoweek 
ON countTab.`travel_date` = dim_isoweek.`fulldate`
LEFT JOIN dim_pay_channel_o_f pay_dict
ON countTab.order_pay_funding_type_id = pay_dict.pay_channel_id
GROUP BY 
      countTab.sup_id,
      countTab.scenic_id,
      countTab.ticket_id,
      countTab.product_id,
      countTab.product_type,
      countTab.operation_channel_id,
      COALESCE(pay_dict.pay_channel_mapping_id, countTab.order_pay_funding_type_id),
      dim_isoweek.isoweek,
      countTab.travel_date;
