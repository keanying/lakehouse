--Serverless Spark SQL
--********************************************************************--
--author: 王海阳
--create time: 2026-08-31 20:19:13
--Serverless Spark SQL任务只能运行在独享资源组上
--********************************************************************--
CREATE TABLE IF NOT EXISTS dws_tps_sup_trf_tourist_di
(
    sup_id                             BIGINT COMMENT '供应商id',
    entry_park_visitors_qty            BIGINT COMMENT '入园游客数',
    exit_park_visitors_qty             BIGINT COMMENT '出园游客数',
    in_park_visitors_qty               BIGINT COMMENT '在园游客数'
)
COMMENT '供应商每日客流汇总表'
PARTITIONED BY 
(
    travel_date  INT COMMENT '出入园日期'
)
STORED AS ORC
;

INSERT OVERWRITE TABLE dws_tps_sup_trf_tourist_di PARTITION(`travel_date`) 
SELECT 
    sid                     AS sup_id,
	SUM(IF(roll=0, num, 0)) AS entry_park_visitors_qty,
	SUM(IF(roll=1, num, 0)) AS exit_park_visitors_qty,
    CASE 
        WHEN SUM(IF(roll = 0, num, 0)) - SUM(IF(roll = 1, num, 0)) < 0 THEN 0
        ELSE SUM(IF(roll = 0, num, 0)) - SUM(IF(roll = 1, num, 0))
    END AS in_park_visitors_qty,
    travel_date
FROM ods_summary_pft_dc_daycount_info_di
WHERE travel_date = ${bizdate}
GROUP BY sid, travel_date;