--@exclude_input=default_workspace_svwh.dim_common_idcard_area_df
--Serverless Spark SQL
--********************************************************************--
--author: 韩瑞
--create time: 2026-06-14 22:28:47
--Serverless Spark SQL任务只能运行在独享资源组上
--********************************************************************--
-- set hive.exec.dynamic.partition.mode=nonstrict;

-- 主键：order_id+idx

-- drop table dwd_ord_traveler_booking_details_di;
CREATE TABLE IF NOT EXISTS dwd_ord_traveler_booking_details_di
(
    id                                BIGINT COMMENT '自增ID'
    ,order_id                         STRING COMMENT '订单号ID'
    ,idx                              BIGINT COMMENT '订单序号'
    ,scenic_id                        INT COMMENT '景点ID'
    ,apply_did                        INT COMMENT '原始供应商ID'
    ,member_id                        BIGINT COMMENT '游客ID'
    ,traveler_name                    STRING COMMENT '游客姓名'
    ,traveler_idcard                  STRING COMMENT '游客身份信息'
    ,traveler_phone                   STRING COMMENT '游客手机号'
    ,traveler_phone_area              STRING COMMENT '手机区号'
    ,traveler_phone_area_country_code STRING COMMENT '手机区号归属国家编码'
    ,traveler_phone_area_country_name STRING COMMENT '手机区号归属国家名称'
    ,traveler_phone_region            STRING COMMENT '手机区号的区域代码'
    ,traveler_phone_province_code     INT COMMENT '手机号归属省份编码'
    ,traveler_phone_province_name     STRING COMMENT '手机号归属省份名称'
    ,traveler_phone_city_code         INT COMMENT '手机号归属市编码'
    ,traveler_phone_city_name         STRING COMMENT '手机号归属市名称'
    ,traveler_phone_district_code     INT COMMENT '手机号归属区/县编码'
    ,traveler_phone_district_name     STRING COMMENT '手机号归属区/县名称'
    ,idcard_country_name              STRING COMMENT '证件归属国家名称'
    ,idcard_province_code             INT COMMENT '证件归属省份编码'
    ,idcard_province_name             STRING COMMENT '证件归属省份名称'
    ,idcard_city_code                 INT COMMENT '证件归属市编码'
    ,idcard_city_name                 STRING COMMENT '证件归属市名称'
    ,idcard_district_code             INT COMMENT '证件归属区/县编码'
    ,idcard_district_name             STRING COMMENT '证件归属区/县名称'
    ,country_name                     STRING COMMENT '归属国家名称'
    ,province_code                    INT COMMENT '归属省份编码'
    ,province_name                    STRING COMMENT '归属省份名称'
    ,city_code                        INT COMMENT '归属市编码'
    ,city_name                        STRING COMMENT '归属市名称'
    ,district_code                    INT COMMENT '归属区/县编码'
    ,district_name                    STRING COMMENT '归属区/县名称'
    ,ext_age                          INT COMMENT '年龄'
    ,ext_sex                          INT COMMENT '性别:0女;1男'
    ,ext_region_code                  STRING COMMENT '归属编码'
    ,ext_country_code                 STRING COMMENT '国家编码'
    ,ext_province_code                STRING COMMENT '归属省编码'
    ,ext_province_name                STRING COMMENT '归属省名称'
    ,ext_city_code                    STRING COMMENT '归属市编码'
    ,ext_city_name                    STRING COMMENT '归属市名称'
    ,ext_district_code                STRING COMMENT '归属区/县编码'
    ,ext_district_name                STRING COMMENT '归属区/县名称'
    ,ext_info                         STRING COMMENT '拓展信息字段'
    ,voucher_type                     INT COMMENT '身份信息类型:0=未实名，没有身份信息 1=身份证,2=护照,3=军官证,4=回乡证,5=台胞证,6=外国人永久居留证,7=港澳通行证,8=台湾通行证,9=港澳居民居住证,10=台湾居民居住证,99=其他'
    ,check_state                      INT COMMENT '0未验证1已验证2已取消'
    ,print_state                      INT COMMENT '打印状态0未打印1已打印'
    ,chk_code                         STRING COMMENT '升级过的凭证号'
    ,is_checked                       INT COMMENT '这个门票码是否全部验证'
    ,check_time                       INT COMMENT '验证时间'
    ,order_time                       INT COMMENT '逻辑下单时间'
    ,order_date                       INT COMMENT '下单日期'
    ,update_time                      INT COMMENT '订单更新时间'
    ,sync_state                       INT COMMENT '是否同步标示 1:同步,0:无需同步'
    ,end_time                         STRING COMMENT '门票订单有效截止时间'
    ,valid_num                        INT COMMENT '剩余可入园次数'
    ,take_way                         INT COMMENT '取票方式:1=凭证号取票,2=手机号取票,3=身份证取票,4=订单号取票,5=团单号取票'
)
COMMENT '订单游客预定信息明细表'
PARTITIONED BY 
(
    travel_date                       INT COMMENT '下单日期【yyyyMMdd】'
)
STORED AS orc
;


-- 身份证号关联地区
-- 手机号关联地区
-- 游客ID是否可以关联
WITH update_order_date AS (
    SELECT order_date
    FROM (
        SELECT date_value as order_date FROM dim_src_table_increment_info_di 
        WHERE table_name = 'ods_myuu_uu_order_tourist_info_f' AND update_date = ${yesterday}
        UNION ALL 
        SELECT date_value as order_date FROM dim_src_table_increment_info_di 
        WHERE table_name = 'ods_myuu_uu_order_tourist_info_extend_f' AND update_date = ${yesterday}
    )
    GROUP BY order_date
)


insert overwrite table dwd_ord_traveler_booking_details_di partition(travel_date)
SELECT 
    id
    ,order_id
    ,idx
    ,scenic_id
    ,apply_did
    ,member_id
    ,traveler_name
    ,traveler_idcard
    ,traveler_phone
    ,traveler_phone_area
    ,traveler_phone_area_country_code 
    ,traveler_phone_area_country_name
    ,traveler_phone_region

    ,traveler_phone_province_code
    ,traveler_phone_province_name
    ,traveler_phone_city_code
    ,traveler_phone_city_name
    ,traveler_phone_district_code
    ,traveler_phone_district_name

    ,idcard_country_name
    ,idcard_province_code
    ,idcard_province_name
    ,idcard_city_code
    ,idcard_city_name
    ,idcard_district_code
    ,idcard_district_name

    ,COALESCE(traveler_phone_area_country_name,idcard_country_name) AS country_name
    ,COALESCE(traveler_phone_province_code,idcard_province_code) AS province_code
    ,COALESCE(traveler_phone_province_name,idcard_province_name) AS province_name
    ,COALESCE(traveler_phone_city_code,idcard_city_code) AS city_code
    ,COALESCE(traveler_phone_city_name,idcard_city_name) AS city_name
    ,COALESCE(traveler_phone_district_code,idcard_district_code) AS district_code
    ,COALESCE(traveler_phone_district_name,idcard_district_name) AS district_name

    ,ext_age
    ,ext_sex
    ,ext_region_code
    ,ext_country_code
    ,ext_province_code
    ,ext_province_name
    ,ext_city_code
    ,ext_city_name
    ,ext_district_code
    ,ext_district_name

    ,ext_info
    ,voucher_type
    ,check_state
    ,print_state
    ,chk_code
    ,is_checked
    ,check_time
    ,order_time
    ,order_date
    ,update_time
    ,sync_state
    ,end_time
    ,valid_num
    ,take_way
    ,travel_date

FROM (
    SELECT  t1.id
        ,t1.orderid AS order_id
        ,t1.idx
        ,t1.lid AS scenic_id
        ,t1.apply_did
        ,t1.member_id
        ,t1.tourist AS traveler_name
        ,t1.idcard AS traveler_idcard
        ,t1.mobile AS traveler_phone
        ,t1.mobile_area AS traveler_phone_area
        ,CASE 
            --香港、澳门、台湾
            WHEN t1.mobile_area IN (886,852,853) THEN 'CN'
            ELSE t4.alpha_2_code
        END AS traveler_phone_area_country_code 
        ,CASE 
            --香港、澳门、台湾
            WHEN t1.mobile_area IN (886,852,853) THEN '中国'
            ELSE t4.name_zh
        END AS traveler_phone_area_country_name

        ,t1.mobile_region AS traveler_phone_region

        ,t5.phone_province_code AS traveler_phone_province_code
        ,t5.phone_province_name AS traveler_phone_province_name
        ,t5.phone_city_code AS traveler_phone_city_code
        ,t5.phone_city_name AS traveler_phone_city_name
        ,t5.phone_district_code AS traveler_phone_district_code
        ,t5.phone_district_name AS traveler_phone_district_name

        ,CASE 
            WHEN t1.voucher_type IN (1,3,4,5,6,7,8,9,10) THEN '中国'
            WHEN t1.voucher_type IN (99) THEN '未知'
            WHEN t1.voucher_type IN (2) THEN '境外'
        ELSE '未知'
        END AS idcard_country_name
        ,t3.idcard_province_code
        ,t3.idcard_province_name
        ,t3.idcard_city_code
        ,t3.idcard_city_name
        ,t3.idcard_district_code
        ,t3.idcard_district_name

        ,CAST(GET_JSON_OBJECT(t2.ext_info,'$.age') AS INT) AS ext_age
        ,CAST(GET_JSON_OBJECT(t2.ext_info,'$.sex') AS INT) AS ext_sex
        ,GET_JSON_OBJECT(t2.ext_info,'$.area.region') AS ext_region_code
        ,GET_JSON_OBJECT(t2.ext_info,'$.area.country') AS ext_country_code
        ,GET_JSON_OBJECT(t2.ext_info,'$.area.province') AS ext_province_code
        ,GET_JSON_OBJECT(t2.ext_info,'$.area.provinceName') AS ext_province_name
        ,GET_JSON_OBJECT(t2.ext_info,'$.area.city') AS ext_city_code
        ,GET_JSON_OBJECT(t2.ext_info,'$.area.cityName') AS ext_city_name
        ,GET_JSON_OBJECT(t2.ext_info,'$.area.district') AS ext_district_code
        ,GET_JSON_OBJECT(t2.ext_info,'$.area.districtName') AS ext_district_name

        ,t2.ext_info
        ,t1.voucher_type
        ,t1.check_state
        ,t1.print_state
        ,t1.chk_code
        ,t1.is_checked
        ,t1.check_time
        ,t1.order_time
        ,CAST(DATE_FORMAT(TO_TIMESTAMP(t1.order_time), 'yyyyMMdd') AS int) AS order_date
        ,t1.update_time
        ,t1.sync_state
        ,t2.end_time
        ,t2.valid_num
        ,t2.take_way
        ,t1.order_date as travel_date

    FROM (
        SELECT /*+ BROADCAST(t2) */ 
            t1.id
            ,t1.orderid
            ,t1.idx
            ,t1.lid
            ,t1.apply_did
            ,t1.member_id
            ,t1.tourist
            ,t1.idcard
            ,t1.mobile
            ,t1.mobile_area
            ,t1.mobile_region
            ,t1.voucher_type
            ,t1.check_state
            ,t1.print_state
            ,t1.chk_code
            ,t1.is_checked
            ,t1.check_time
            ,t1.order_time
            ,t1.update_time
            ,t1.sync_state
            ,t1.order_date
        FROM ods_myuu_uu_order_tourist_info_f t1
        LEFT SEMI JOIN update_order_date t2
        ON t1.order_date = t2.order_date
    ) t1
    LEFT JOIN (
        SELECT /*+ BROADCAST(t2) */ 
            t1.orderid
            ,t1.idx
            ,t1.ext_info
            ,t1.end_time
            ,t1.valid_num
            ,t1.take_way
        FROM ods_myuu_uu_order_tourist_info_extend_f t1
        LEFT SEMI JOIN update_order_date t2
        ON t1.order_date = t2.order_date
    ) t2
    ON t1.orderid = t2.orderid
    AND t1.idx = t2.idx
    LEFT JOIN dim_common_idcard_area_df t3
    ON SUBSTR(t1.idcard,1,6) = t3.identity_code
    LEFT JOIN (
        SELECT phone_area_code,max(name_zh) AS  name_zh,max(alpha_2_code) AS  alpha_2_code
        FROM dim_common_phone_code_country_df
        group by phone_area_code
    ) t4
    ON t1.mobile_area = t4.phone_area_code
    LEFT JOIN dim_common_phone_prefix_area_df t5
    ON SUBSTR(t1.mobile, 1, 7) = t5.phone_prefix_number
)
;


--增量数据分区更新
INSERT OVERWRITE TABLE dim_src_table_increment_info_di PARTITION(table_name,update_date)
SELECT 
    'order_date' AS date_type
    ,order_date AS date_value
    ,'dwd' AS table_type
    ,'dwd_ord_traveler_booking_details_di' AS table_name
    ,${yesterday} AS update_date
FROM (
    SELECT date_value as order_date FROM dim_src_table_increment_info_di 
    WHERE table_name = 'ods_myuu_uu_order_tourist_info_f' AND update_date = ${yesterday}
    UNION ALL 
    SELECT date_value as order_date FROM dim_src_table_increment_info_di 
    WHERE table_name = 'ods_myuu_uu_order_tourist_info_extend_f' AND update_date = ${yesterday}
)
GROUP BY order_date
;








