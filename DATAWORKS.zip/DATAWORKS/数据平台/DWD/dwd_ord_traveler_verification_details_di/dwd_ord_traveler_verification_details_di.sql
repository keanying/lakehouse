--Serverless Spark SQL
--********************************************************************--
--author: 韩瑞
--create time: 2026-06-15 15:26:18
--Serverless Spark SQL任务只能运行在独享资源组上
--********************************************************************--
--游客入园日志记录明细表

-- DROP TABLE if EXISTS dwd_ord_traveler_verification_details_di;
CREATE TABLE IF NOT EXISTS dwd_ord_traveler_verification_details_di
(
    id               BIGINT COMMENT '表ID'
    ,order_id        STRING COMMENT '订单号'
    ,idx             BIGINT COMMENT '订单游客表序号'
    ,track_action    BIGINT COMMENT '变更状态:0=预出票,1=入园,2=取消,3=过期,4=验证,5=撤销撤改,6=出票且有效,7=售后'
    ,ticket_id       BIGINT COMMENT '票类ID'
    ,apply_did       INT COMMENT '原始供应商ID'
    ,change_qty      BIGINT COMMENT '变更次数'
    ,remain_qty      BIGINT COMMENT '剩余可用次数'
    ,source          BIGINT COMMENT '操作来源:0=终端机,1=软终端,2=自助机,3=外部通知更新,4=云票务,5=云闸机,6=PC-支付宝,7=手机支付宝,8=支付宝刷卡,9=支付宝扫码,10=微信支付,11=微信刷卡,12=微信扫码,13=PC-银联,14=手机-银联,15=PC-环迅,16=内部接口,17=外部接口,18=undefined,19=自运行服务,20=安卓智能终端机,21=验证服务器,22=微信商城,23=二级店铺,24=OTA,25=会员购票,26=年卡特权,27=平安银行,28=内部接口,29=民生乐收银,30=一卡通'
    ,terminal        BIGINT COMMENT '终端号'
    ,branch_terminal BIGINT COMMENT '分终端号'
    ,insert_time     TIMESTAMP COMMENT '添加时间'
    ,oper_member     BIGINT COMMENT '操作用户'
    ,msg             STRING COMMENT '备注信息'
    ,ext_content     STRING COMMENT '验证或是取消过程中的一些数据'
    ,is_first_used   INT COMMENT '是否首次入园[1是,0否]'
    ,is_overdue      INT COMMENT '是否过期验证,1=过期验证,0=非过期验证'
    ,order_time      INT COMMENT '逻辑下单时间'
    ,update_time     INT COMMENT '订单更新时间'
    ,dwd_update_time INT COMMENT '订单更新时间[写入时间以及后期更新时间]'
)
COMMENT '游客验证信息明细表'
PARTITIONED BY 
(
    verify_date      INT COMMENT '验证日期'
)
STORED AS ORC
;

INSERT OVERWRITE TABLE dwd_ord_traveler_verification_details_di PARTITION(verify_date)
SELECT  id
        ,ordernum AS order_id
        ,idx
        ,track_action
        ,tid AS ticket_id
        ,apply_did
        ,tnum AS change_qty
        ,left_num AS remain_qty
        ,source
        ,terminal
        ,branch_terminal
        ,TO_TIMESTAMP(insert_time) AS insert_time
        ,oper_member
        ,NVL(msg, -1) AS msg
        ,ext_content
        ,CAST(GET_JSON_OBJECT(ext_content,'$.is_first_used') AS INT) AS is_first_used
        ,IF(msg LIKE '%过期%', 1, 0) AS is_overdue
        ,order_time
        ,update_time
        ,CAST(DATE_FORMAT(now(),'yyyyMMdd') AS INT) AS dwd_update_time
        ,CAST(FROM_UNIXTIME(insert_time,'yyyyMMdd') AS INT) AS verify_date
FROM    ods_myuu_pft_order_tourist_track_di
WHERE   track_action IN (1,4)
AND     insertdate = ${yesterday}
;






