--Serverless Spark SQL
--********************************************************************--
--author: 韩瑞
--create time: 2026-06-08 17:03:52
--Serverless Spark SQL任务只能运行在独享资源组上
--********************************************************************--



-- dwd_trf_app_usage_log_df


CREATE TABLE ods_ecs_pft001_pft_module_used_ext_df
(
    id                BIGINT COMMENT '自增ID'
    ,member_id        BIGINT COMMENT '用户ID'
    ,module_id        BIGINT COMMENT '模块ID'
    ,module_type        BIGINT COMMENT '类型 1=应用 2=应用组合'
    ,out_trade_no     STRING COMMENT '支付流水ID'
    ,stop_type        TINYINT COMMENT '终止类型：1作废,2提前终止'
    ,time_details     STRING COMMENT '终止相关时间记录'
    ,contract_no      STRING COMMENT '合同编号'
    ,sign_time        BIGINT COMMENT '签约时间'
    ,saleman          INT COMMENT '签单人'
    ,details          STRING COMMENT '存一些金额信息(发票金额、实收金额、业绩金额、实际消费金额)'
    ,repayment_record STRING COMMENT '回款记录'
    ,sign_remark      STRING COMMENT '签单备注'
    ,create_time      BIGINT COMMENT '添加时间'
    ,update_time      BIGINT COMMENT '更新时间'
)
COMMENT '用户使用应用扩展记录表'
stored as orc
;




SELECT 
    member_id,
    member_kind,
    member_type,
    province,
    city,
    start_time          AS start_time,
    end_time            AS end_time
    -- to_date(FROM_UNIXTIME(start_time, 'yyyy-MM-dd'))    AS start_time,
    -- to_date(FROM_UNIXTIME(end_time, 'yyyy-MM-dd'))      AS end_time
FROM 
(
    SELECT  
        member_id                               AS member_id,
        business_message.corp_kind              AS member_kind,
        business_message.format_type            AS member_type,
        area_info.customer_province             AS province,
        area_info.customer_city                 AS city,
        -- FROM_UNIXTIME(start_time,'yyyy-MM-dd')  AS start_time,
        -- FROM_UNIXTIME(end_time,'yyyy-MM-dd')    AS end_time,
        TO_DATE(FROM_UNIXTIME(start_time,'yyyy-MM-dd')) AS start_time,
        TO_DATE(FROM_UNIXTIME(end_time,'yyyy-MM-dd'))   AS end_time,
        --商户类型, 为2的是测试账户
        member_base.group_id                    AS is_test_user
    FROM (   -- 开通功能模块或套餐应用的用户, 最大开始服务时间, 最晚服务终止时间
        SELECT  
            member_id,
            MIN(service_start_time)     AS start_time,
            MAX(service_real_end_time)  AS end_time
        FROM 
        (   -- 功能模块使用情况
            SELECT  
                member_id,
                GET_JSON_OBJECT(time_details, '$.start_time')       AS service_start_time,
                IF(
                    GET_JSON_OBJECT(time_details, '$.stop_time') == '' or GET_JSON_OBJECT(time_details, '$.stop_time') is null,
                    GET_JSON_OBJECT(time_details, '$.end_time'),
                    GET_JSON_OBJECT(time_details, '$.stop_time')
                )                                                   AS service_real_end_time
            FROM (   -- "用户使用应用扩展记录表" 取出 "用户id", "终止相关时间记录", "模块ID"
                SELECT  
                    member_id,
                    time_details,
                    module_id
                FROM ods_pft_module_used_ext_d_f
            ) AS module_used_ext 
            LEFT JOIN (   -- "功能模块价格配置", 取出"功能模块ID/套餐ID", 条件: "类型为功能模块" 且 "费用非空"
                SELECT target_id
                FROM ods_pft001_pft_module_price_d_f
                WHERE pt = '${ds}'
                  AND type = 1
                  AND fee > 0
            ) AS module_price
            ON module_used_ext.module_id=module_price.target_id 
        )
        GROUP BY member_id
        HAVING start_time > 0 
          AND end_time > 0
    ) AS server_business
    LEFT JOIN (   
        -- 商家类型和业态
        -- 会员详细资料表, "商户id", "公司类型", "公司业态"
        SELECT  
            fid,
            corp_kind,
            format_type
        FROM ods_myuu_pft_member_extinfo_d_f
        WHERE pt = '${ds}' 
    ) AS business_message
    ON server_business.member_id = business_message.fid
    LEFT JOIN (   
        -- 景区维表, "景区id", "景区所在省", "景区所在城市"
        SELECT  
            user_id,
            customer_province,
            customer_city
        FROM dim_user_d_f
        WHERE pt = '${ds}' 
    ) AS area_info
    ON server_business.member_id = area_info.user_id
    LEFT JOIN (   
        -- 商户分组, 2为测试商户
        SELECT  
            id,
            group_id,
            account 
        FROM s_myuu_pft_member_d_f
        WHERE pt = '${ds}'
        -- 此商户为测试商户, 但group_id为1, 单独过滤!!
          AND account != 70801726
    ) AS member_base
    ON member_base.id = business_message.fid
)
WHERE is_test_user != 2 




