--Serverless Spark SQL
--********************************************************************--
--author: 韩瑞
--create time: 2026-06-11 15:30:07
--Serverless Spark SQL任务只能运行在独享资源组上
--********************************************************************--




-- DROP TABLE dwd_ord_package_sub_order_details_di;
CREATE TABLE IF NOT EXISTS dwd_ord_package_sub_order_details_di
(
    id                        BIGINT COMMENT '表ID'
    ,order_id                 STRING COMMENT '订单号'
    ,pack_order_id            STRING COMMENT '套票主票订单号(主票记录本身取orderid)'
    ,ifpack                   INT COMMENT '0非套票订单1套票主订单 >100000套票从订单（2票付通从订单）'
    ,dstatus                  INT COMMENT '确认订单状态0无需确认 1待确认 2已确认未验证 3已确认已验证 4确认后取消 5确认后修改,6演出套票的订单'
    ,confirm_time             STRING COMMENT '确认时间'
    ,pack_sup_id              INT COMMENT '主票供应商ID'
    ,pack_scenic_id           INT COMMENT '主票景区id'
    ,pack_ticket_id           INT COMMENT '主票门票id'
    ,pack_product_id          INT COMMENT '主票产品id'
    ,pack_product_type        STRING COMMENT '主票商品类型'
    ,distributor_id           INT COMMENT '分销商ID'
    ,apply_did                INT COMMENT '原始供应商ID'
    ,sub_order_process_status INT COMMENT '子票是否已经处理完成:100=处理完,0=没有'
    ,pack_process             STRING COMMENT '线下自填的流水号json数据'
    ,is_print                 INT COMMENT '是否被打印 1代表被打印'
    ,external_voucher_code    STRING COMMENT '对接第三方系统的凭证码'
    ,external_order_id        STRING COMMENT '对接第三方系统的对方订单'
    ,partner_mark             SMALLINT COMMENT '是否对接三方系统标识'
    ,link_ordernum            STRING COMMENT '原来uu_order_fx_details->concat_id'
    ,order_time               TIMESTAMP COMMENT '逻辑下单时间'
    ,update_time              TIMESTAMP COMMENT '订单更新时间'
    ,sync_state               INT COMMENT '是否同步标示 1:同步,0:无需同步'
    ,dwd_update_time          INT COMMENT '订单更新时间[写入时间以及后期更新时间]'
)
COMMENT '套票子票订单明细表'
PARTITIONED BY 
(
    travel_date               INT COMMENT '下单日期[yyyyMMdd]'
)
STORED AS orc
;

WITH update_order_date AS (
    select order_date
    from(
        SELECT date_value as order_date FROM dim_src_table_increment_info_di 
        WHERE table_name = 'ods_myuu_uu_ss_order_df' AND update_date = ${yesterday} AND date_type = 'order_date'
        UNION ALL 
        SELECT date_value as order_date FROM dim_src_table_increment_info_di 
        WHERE table_name = 'ods_myuu_uu_order_addon_f' AND update_date = ${yesterday} AND date_type = 'order_date'
    )
    group by order_date
)


-- 需要注意 套票子票表与主订单表 关联取数的规则，后期需要优化
-- 数据范围：当前存储2020年及以后数据，20年以前数据如有需要，手动刷新。

INSERT OVERWRITE TABLE dwd_ord_package_sub_order_details_di PARTITION(travel_date)
SELECT 
    t1.id
    ,t1.order_id
    ,t1.pack_order_id
    ,t1.ifpack
    ,t1.order_status
    ,t1.confirm_time
    ,t2.aid AS pack_sup_id
    ,t2.lid  AS pack_scenic_id
    ,t2.tid  AS pack_ticket_id
    ,t2.pid  AS pack_product_id
    ,t2.product_type AS pack_product_type
    ,t1.distributor_id
    ,t1.apply_did
    ,t1.sysorder AS sub_order_process_status
    ,t1.pack_process
    ,t1.is_print
    ,t1.vcode AS external_voucher_code
    ,t1.tordernum AS external_order_id
    ,t1.partner_mark
    ,t1.link_ordernum
    ,t1.order_time
    ,t1.update_time
    ,t1.sync_state
    ,CAST(DATE_FORMAT(now(),'yyyyMMdd') AS INT) AS dwd_update_time
    ,t1.travel_date
FROM (
    SELECT  /*+ BROADCAST(t2) */
        t1.id
        ,t1.orderid AS order_id
        ,IF(t1.pack_order = '' OR t1.pack_order = '1',t1.orderid,t1.pack_order) AS pack_order_id
        ,t1.ifpack
        ,t1.dstatus AS order_status
        ,t1.confirm_time
        ,t1.confirm_op AS distributor_id
        ,t1.apply_did
        ,t1.sysorder
        ,t1.pack_process
        ,t1.ifprint AS is_print
        ,t1.vcode
        ,t1.tordernum
        ,t1.partner_mark
        ,t1.link_ordernum
        ,to_timestamp(from_unixtime(t1.order_time)) AS order_time
        ,to_timestamp(from_unixtime(t1.update_time)) AS update_time
        ,t1.sync_state
        ,t1.order_date AS travel_date
    FROM    ods_myuu_uu_order_addon_f t1
    LEFT SEMI JOIN  update_order_date t2
    ON t1.order_date = t2.order_date
) t1
LEFT JOIN (
    -- 主票的各种信息
    SELECT /*+ BROADCAST(t2) */
        t1.ordernum
        ,t1.lid
        ,t1.tid
        ,t1.aid
        ,t1.apply_did
        ,t1.product_type
        ,t1.pid
        ,t1.order_date
    FROM    ods_myuu_uu_ss_order_df t1
    LEFT SEMI JOIN  update_order_date t2
    ON      t1.order_date = t2.order_date
) t2
ON t1.pack_order_id = t2.ordernum
;


INSERT OVERWRITE TABLE dim_src_table_increment_info_di PARTITION(table_name,update_date)
SELECT 
    'order_date' AS date_type
    ,order_date AS date_value
    ,'dwd' AS table_type
    ,'dwd_ord_package_sub_order_details_di' AS table_name
    ,${yesterday} AS update_date
FROM (
    SELECT date_value as order_date FROM dim_src_table_increment_info_di 
    WHERE table_name = 'ods_myuu_uu_ss_order_df' AND update_date = ${yesterday} AND date_type = 'order_date'
    UNION ALL 
    SELECT date_value as order_date FROM dim_src_table_increment_info_di 
    WHERE table_name = 'ods_myuu_uu_order_addon_f' AND update_date = ${yesterday} AND date_type = 'order_date'
)
GROUP BY order_date
;

--0/1/2
-- SELECT DISTINCT ifpack
-- FROM    (
--     select orderdate,ifpack
--     FROM ods_order_addon_d_i
--     WHERE   orderdate > 20260101
--     GROUP BY orderdate,ifpack
-- )

