--Serverless Spark SQL
--********************************************************************--
--author: 韩瑞
--create time: 2026-06-08 22:47:44
--Serverless Spark SQL任务只能运行在独享资源组上
--********************************************************************--
-- DROP TABLE dwd_ord_order_details_di;
CREATE TABLE IF NOT EXISTS dwd_ord_order_details_di
(
    id                     BIGINT COMMENT '表id' 
    --===============关联建===============
    ,member_id             INT COMMENT '购买者ID'
    ,order_id              STRING COMMENT '订单号'
    ,remote_order_id       STRING COMMENT '远端订单号'
    ,scenic_id             INT COMMENT '景区id'
    ,ticket_id             INT COMMENT '门票id'
    ,product_id            INT COMMENT '产品id'
    ,sup_id                INT COMMENT '供应商ID'
    ,saler_id              INT COMMENT '商家ID'
    ,apply_did             INT COMMENT '原始供应商ID' 

    --===============关联维度===============
    ,channel_class1_id     INT     COMMENT'渠道一级分类id'
    ,channel_class1_name   STRING  COMMENT'渠道一级分类名称'
    ,channel_class2_id     INT     COMMENT'渠道二级分类id(ordermode)'
    ,channel_class2_name   STRING  COMMENT'渠道二级分类名称'

    ,ticket_taker_phone_province_code INT COMMENT '取票人电话号段归属省份编码'
    ,ticket_taker_phone_province_name STRING COMMENT '取票人电话号段归属省份名称'
    ,ticket_taker_phone_city_code     INT COMMENT '取票人电话号段归属市编码'
    ,ticket_taker_phone_city_name     STRING COMMENT '取票人电话号段归属市名称'

    ,ticket_taker_idcard_province_code INT COMMENT '取票人身份证件归属省份编码'
    ,ticket_taker_idcard_province_name STRING COMMENT '取票人身份证件归属省份名称'
    ,ticket_taker_idcard_city_code     INT COMMENT '取票人身份证件归属市编码'
    ,ticket_taker_idcard_city_name     STRING COMMENT '取票人身份证件归属市名称'
    ,ticket_taker_idcard_district_code INT COMMENT '取票人身份证件归属区/县编码'
    ,ticket_taker_idcard_district_name STRING COMMENT '取票人身份证件归属区/县名称'

    --===============订单描述===============
    ,ticket_taker_name     STRING COMMENT '取票人姓名'
    ,ticket_taker_phone    STRING COMMENT '取票人电话'
    ,ticket_taker_idcard   STRING COMMENT '取票人身份信息'
    ,order_time            STRING COMMENT '下单时间'
    ,order_date            DATE COMMENT '下单日期'
    ,pay_time              TIMESTAMP COMMENT '订单支付时间'
    ,expiration_date       DATE COMMENT '订单过期日期'
    ,pay_date              DATE COMMENT '订单支付日期'
    ,update_time           INT COMMENT '订单更新时间'
    ,play_time             TIMESTAMP COMMENT '预计游玩时间'
    ,play_date             DATE COMMENT '预计游玩日期'
    ,begin_time            TIMESTAMP COMMENT '开始时间'
    ,end_time              TIMESTAMP COMMENT '结束时间'
    ,cancel_time           STRING COMMENT '取消时间'
    ,verify_time           STRING COMMENT '验证时间'
    ,order_status_code     INT COMMENT '订单状态：0=未使用,1=已使用,2=已过期,3=被取消,4=待确认(酒店)，待收货(特产),5=被终端修改,6=被终端撤销,7=部分使用,8=订单完结,9=被删除'
    ,order_pay_status      INT COMMENT '支付方式:0=现场支付,1=已支付,2=未支付'
    ,pay_funding_type      INT COMMENT '支付方式：0 = 余额支付,1 = 支付宝,2 = 授信支付,3 = 产品自销,4 = 现场支付,5 = 微信支付,6 = 会员卡支付,7 = 银联支付,8 = 环迅支付,9 = 现金支付,10 = 会员卡,11 = 拉卡拉（商户）,12 = 拉卡拉（平台）,13 = 特权支付（年卡）,14 = 微信（聚合）,15 = 平安银行,16 = 支付宝（聚合）,17 = 会员卡支付,18 = 计时卡支付,25 = 招行一网通支付,26 = 银联商务支付,27 = 银联商务POS支付,28 = 威富通支付,29 = 易宝云企付,33 = 博思支付,35 = 积分支付,36 = POS支'
    ,order_channel         INT COMMENT '下单方式:0=正常分销商下单,1=普通用户支付,2=用户手机支付,3=会员卡购票,10=云票务,11=微信商城,12=自助机,13=二级店铺,14=闸机购票,15=智能终端,16=计调下单,17=淘宝码商,18=年卡,19=微信端,20=外部接口OTA下单,22=一卡通,23=套票子票'
    ,use_coupon            INT COMMENT '0正常1使用优惠价支付2修改过的订单'
    ,voucher_code          BIGINT COMMENT '凭证码'
    ,non_refund_withdraw   INT COMMENT '提现类型：0=正常订单，1=不可退而且可提现的订单，2=独立收款'
    ,order_customer_type   INT COMMENT '订单客户类型：1=游客,2=分销商'
    ,product_type          STRING COMMENT '商品类型'
    ,sync_state            INT COMMENT '是否同步标示 1:同步,0:无需同步'
    ,trade_order_id        STRING COMMENT '交易订单号' 
    --===============度量===============
    ,tnum                  BIGINT COMMENT '门票数量'
    ,order_price           INT COMMENT '单价'
    ,original_order_amount INT COMMENT '总的支付金额'
    ,supply_price          BIGINT COMMENT '供应价'
    ,retail_price          BIGINT COMMENT '零售价表'
    ,by_order_retail_price BIGINT COMMENT '下单时的门市价'
    ,actual_selling_price  INT COMMENT '实际售价'
    ,refund_num            BIGINT COMMENT '退票数'
    ,verified_num          BIGINT COMMENT '已验证票数'
    ,origin_num            BIGINT COMMENT '原始票数'
    ,current_total_num     SMALLINT COMMENT '记录当前总的票数'
    ,can_take_num          SMALLINT COMMENT '可取票数'
    ,can_refund_num        SMALLINT COMMENT '可退票数'

    ,dwd_update_time       INT COMMENT '订单更新时间[写入时间以及后期更新时间]'
)
COMMENT '订单状态表，按订单下单时间分区'
PARTITIONED BY 
(
    travel_date            INT COMMENT '下单日期[yyyyMMdd]'
)
STORED AS ORC
;

WITH update_order_date AS (
    SELECT order_date
    FROM (
        SELECT date_value as order_date FROM dim_src_table_increment_info_di 
        WHERE table_name = 'ods_myuu_uu_ss_order_df' AND update_date = ${yesterday}
        UNION ALL 
        SELECT date_value as order_date FROM dim_src_table_increment_info_di 
        WHERE table_name = 'ods_myuu_uu_order_apply_info_f' AND update_date = ${yesterday}
    )
    GROUP BY order_date
)

-- --待完成事情
-- 1.订单主表增量数据更新逻辑完善
-- 2.

INSERT OVERWRITE TABLE dwd_ord_order_details_di PARTITION(travel_date)
SELECT  t1.id
    --============关联键==================
    ,t1.member AS member_id
    ,t1.ordernum AS order_id
    ,t1.remotenum AS remote_order_id
    ,t1.lid AS scenic_id
    ,t1.tid AS ticket_id
    ,t1.pid AS product_id
    ,t1.aid AS sup_id
    ,t1.salerid AS saler_id
    ,t1.apply_did
    --============关联维度==================
    ,t3.channel_class1_id  
    ,t3.channel_class1_name
    ,IF(
        t1.ordermode = 20
        ,NVL(CAST(t4.target_id AS INT),2000)
        ,t3.channel_class2_id  
    )  AS channel_class2_id
    ,IF(
        t1.ordermode = 20
        ,NVL(t4.channel_aggregation_name,'商家自研')
        ,t3.channel_class2_name
    ) AS channel_class2_name

    ,t5.phone_province_code AS ticket_taker_phone_province_code
    ,t5.phone_province_name AS ticket_taker_phone_province_name
    ,t5.phone_city_code AS ticket_taker_phone_city_code
    ,t5.phone_city_name AS ticket_taker_phone_city_name

    ,t6.idcard_province_code AS ticket_taker_idcard_province_code
    ,t6.idcard_province_name AS ticket_taker_idcard_province_name
    ,t6.idcard_city_code AS ticket_taker_idcard_city_code
    ,t6.idcard_city_name AS ticket_taker_idcard_city_name
    ,t6.idcard_district_code AS ticket_taker_idcard_district_code
    ,t6.idcard_district_name AS ticket_taker_idcard_district_name

    --============订单描述==================
    ,t1.ordername AS ticket_taker_name
    ,t1.ordertel AS ticket_taker_phone
    ,t1.personid AS ticket_taker_idcard


    ,t1.ordertime AS order_time
    ,TO_DATE(t1.ordertime) AS order_date
    --支付时间
    ,IF(t1.pay_time != 0,TO_TIMESTAMP(t1.pay_time),NULL) AS pay_time 
    ,IF(t1.pay_time != 0,TO_DATE(t1.pay_time),NULL) AS pay_date
    -- 过期时间=有效期结束日期+1
    ,IF(t1.status = 2,DATE_ADD(TO_DATE(t1.endtime),1),NULL) AS expiration_date 
    ,t1.update_time
    ,t1.playtime AS play_time
    ,CAST(DATE_FORMAT(t1.playtime, 'yyyy-MM-dd') AS DATE) AS play_date
    ,t1.begintime AS begin_time
    ,t1.endtime AS end_time
    ,t1.ctime AS cancel_time
    ,t1.dtime AS verify_time
    ,t1.status AS order_status_code
    ,t1.pay_status AS order_pay_status
    ,t1.paymode AS pay_funding_type
    ,t1.ordermode AS order_channel
    ,t1.onsale AS use_coupon
    ,t1.code AS voucher_code
    ,t1.unionCheck AS non_refund_withdraw
    ,t1.visitors AS order_customer_type
    ,t1.product_type
    ,t1.sync_state
    ,t1.trade_order_id
    --============度量==================
    ,t1.tnum
    ,-- 年卡特权支付订单金额置零，金额为负数订单金额置零
    IF(
        t1.ordermode = 18 AND t1.paymode = 13, 
        0,
        IF(t1.tprice < 0, 0, t1.tprice)
    )  AS order_price
    -- 年卡特权支付订单金额置零，金额为负数订单金额置零
    ,IF(
        t1.ordermode = 18 AND t1.paymode = 13, 
        0,
        IF(t1.totalmoney < 0, 0, t1.totalmoney)
    ) AS original_order_amount --订单金额逻辑从dim_order 走
    ,t2.aprice        AS supply_price
    ,t2.lprice        AS retail_price
    ,t2.counter_price AS by_order_retail_price
    ,t2.sale_price    AS actual_selling_price
    ,CAST(t2.refund_num AS BIGINT)    AS refund_num
    ,CAST(t2.verified_num AS BIGINT)   AS verified_num
    ,CAST(t2.origin_num AS BIGINT)     AS origin_num
    ,t2.current_num   AS current_total_num
    ,t2.can_take      AS can_take_num
    ,t2.can_refund    AS can_refund_num

    ,CAST(DATE_FORMAT(now(),'yyyyMMdd') AS INT) AS dwd_update_time

    ,CAST(DATE_FORMAT(t1.ordertime, 'yyyyMMdd') AS INT) AS travel_date
FROM    (
    SELECT /*+ BROADCAST(t2) */ 
        t1.id
        ,t1.member
        ,t1.ordernum
        ,t1.remotenum
        ,t1.lid
        ,t1.tid
        ,t1.pid
        ,t1.aid
        ,t1.salerid
        ,t1.apply_did
        ,t1.ordermode
        ,t1.ordername
        ,t1.ordertel
        ,t1.personid
        ,t1.ordertime
        ,t1.pay_time
        ,t1.status
        ,t1.endtime
        ,t1.update_time
        ,t1.playtime
        ,t1.begintime
        ,t1.ctime
        ,t1.dtime
        ,t1.pay_status
        ,t1.paymode
        ,t1.onsale
        ,t1.code
        ,t1.unionCheck
        ,t1.visitors
        ,t1.product_type
        ,t1.sync_state
        ,t1.trade_order_id
        ,t1.tnum
        ,t1.tprice
        ,t1.totalmoney
        ,t1.order_date
    FROM ods_myuu_uu_ss_order_df t1
    LEFT SEMI JOIN update_order_date t2
    ON t1.order_date = t2.order_date
) t1  
LEFT JOIN (
    SELECT /*+ BROADCAST(t2) */
        t1.orderid
        ,t1.order_date
        ,t1.aprice        
        ,t1.lprice        
        ,t1.counter_price 
        ,t1.sale_price    
        ,t1.refund_num    
        ,t1.verified_num  
        ,t1.origin_num    
        ,t1.current_num   
        ,t1.can_take      
        ,t1.can_refund   
    FROM ods_myuu_uu_order_apply_info_f t1
    LEFT SEMI JOIN update_order_date t2
    ON t1.order_date = t2.order_date
) t2
ON t1.order_date = t2.order_date
and t1.ordernum = t2.orderid
LEFT JOIN dim_ord_enum_order_mode_f t3
ON t1.ordermode = t3.channel_class2_id
LEFT JOIN (
    SELECT user_id,MAX(channel_aggregation_name) AS channel_aggregation_name,MAX(target_id) AS target_id
    FROM (
        SELECT 
            member.user_id as user_id
            ,OTA.channel_aggregation_name
            ,OTA.target_id
        FROM
        (
            -- 商户回调地址
            SELECT user_id, dcode_url
            FROM dim_cus_member_info_df
            WHERE -- 供应商，分销商
            user_type IN (0, 1)
            -- 排除测试
            AND user_group_id != 2
        ) AS member 
        INNER JOIN 
        (
            SELECT loopback_address, channel_aggregation_name, target_id
            FROM dim_trf_ota_channel_f
            -- 通过回调地址确认
            WHERE rule_code = 1
        ) AS OTA 
        ON member.dcode_url RLIKE OTA.loopback_address
        UNION ALL
        SELECT 
            member_id AS user_id
            ,channel_aggregation_name
            ,target_id
        FROM 
        (
            SELECT member_id
                ,channel_aggregation_name
                ,target_id
            FROM dim_trf_ota_channel_f
            -- 通过member_id确认
            WHERE rule_code = 2
        )
    )
    GROUP BY user_id
) t4
ON t1.member = t4.user_id
--关联取票人手机号归属地区
LEFT JOIN dim_common_phone_prefix_area_df t5
ON SUBSTR(t1.ordertel,1,7) = t5.phone_prefix_number
--关联取票人身份证归属地区(目前只是身份证识别国内，其他证件暂无规则)
LEFT JOIN dim_common_idcard_area_df t6
ON SUBSTR(t1.personid,1,6) = t6.identity_code
;




--增量数据分区更新
INSERT OVERWRITE TABLE dim_src_table_increment_info_di PARTITION(table_name,update_date)
SELECT 
    'order_date' AS date_type
    ,order_date AS date_value
    ,'dwd' AS table_type
    ,'dwd_ord_order_details_di' AS table_name
    ,${yesterday} AS update_date
FROM (
    SELECT date_value as order_date FROM dim_src_table_increment_info_di 
    WHERE table_name = 'ods_myuu_uu_ss_order_df' AND update_date = ${yesterday}
    UNION ALL 
    SELECT date_value as order_date FROM dim_src_table_increment_info_di 
    WHERE table_name = 'ods_myuu_uu_order_apply_info_f' AND update_date = ${yesterday}
)
GROUP BY order_date
;








