--Serverless Spark SQL
--********************************************************************--
--author: 韩瑞
--create time: 2026-06-09 00:03:23
--Serverless Spark SQL任务只能运行在独享资源组上
--********************************************************************--

--粒度  order_id+current_distributor_level

-- DROP TABLE if exists dwd_ord_split_order_details_di;
CREATE TABLE IF NOT exists dwd_ord_split_order_details_di
(
    id                         BIGINT COMMENT '自增ID'
    ,order_id                  STRING COMMENT '订单号'
    ,buyer_id                  INT COMMENT '购买用户ID'
    ,buyer_company_type        INT COMMENT '购买者公司类型'
    ,buyer_business_type       INT COMMENT '购买者业态'
    ,buyer_account_group       INT COMMENT '购买者账户分组'
    ,seller_id                 INT COMMENT '售卖用户ID'
    ,seller_company_type       INT COMMENT '销售者公司类型'
    ,seller_business_type      INT COMMENT '销售者业态'
    ,origin_distributor_level  INT COMMENT '本笔分销层级原始字段(level): 1/-1/2/0'
    ,current_distributor_level INT COMMENT '本层具体分销层级: [1-5]'
    ,is_last_distributor_level INT COMMENT '本层是否是分销链最后一级: 1=是, 0=否'
    ,current_level_paymode     INT COMMENT '该级别的支付方式'
    ,cost_money                DECIMAL(12,0) COMMENT '成本价（分为单位）'
    ,sale_money                DECIMAL(12,0) COMMENT '销售价（分为单位）'
    ,member_relationship       INT COMMENT '订单会员关系 0:平台关系,1:资源中心关系'
    ,order_time                INT COMMENT '逻辑下单时间'
    ,update_time               INT COMMENT '订单更新时间'
    ,apply_did                 INT COMMENT '原始供应商ID'
    ,sync_state                INT COMMENT '是否同步标示 1:同步,0:无需同步'
    ,dwd_update_time       INT COMMENT '订单更新时间[写入时间以及后期更新时间]'
)
COMMENT '订单分销链明细表'
PARTITIONED BY 
(
    travel_date                INT COMMENT '下单日期, 格式:YYYYMMDD'
)
STORED AS ORC
;

INSERT OVERWRITE TABLE dwd_ord_split_order_details_di PARTITION(travel_date)
SELECT  order_split.id
        ,order_split.orderid AS order_id
        ,order_split.buyerid AS buyer_id
        ,buyer_member_info.customer_company_type_id AS buyer_company_type
        ,buyer_member_info.business_type AS buyer_business_type
        ,CAST(buyer_member_info.user_group_id AS INT) AS buyer_account_group
        ,order_split.sellerid AS seller_id
        ,seller_member_info.customer_company_type_id AS seller_company_type
        ,seller_member_info.business_type AS seller_business_type
        ,order_split.level AS origin_distributor_level
        ,order_split.detail_split_level AS current_distributor_level
        ,order_split.is_end_level AS is_last_distributor_level
        ,order_split.pmode AS current_level_paymode
        ,order_split.cost_money
        ,order_split.sale_money
        ,order_split.member_relationship
        ,order_split.order_time
        ,order_split.update_time
        ,order_split.apply_did
        ,order_split.sync_state
        ,CAST(DATE_FORMAT(now(),'yyyyMMdd') AS INT) AS dwd_update_time
        ,order_split.order_date AS travel_date
FROM    (
    --基础信息+分销链层级处理
    -- 2025-01-01后数据查询-分销链最高5层
    --目前按照最高5层分销处理
    SELECT  id
            ,orderid
            ,buyerid
            ,sellerid
            ,level
            ,pmode
            ,cost_money
            ,sale_money
            ,member_relationship
            ,order_time
            ,update_time
            ,order_month
            ,apply_did
            ,sync_state
            ,order_date
            ,IF(
                level = 0 OR level = 1
                ,1
                ,IF(
                    level = -1
                    ,order_count_level
                    ,IF(
                        sellerid = level2_sellerid
                        ,2
                        ,IF(
                            order_count_level > 3 AND buyerid = level_2_buyerid
                            ,order_count_level - 1
                            ,3
                        )
                    )
                )
            ) AS detail_split_level
            ,IF(
                level = 0 OR level = -1
                ,1
                ,0
            ) AS is_end_level
    FROM    (
        SELECT  /*+ BROADCAST(t2) */
                t1.id
                ,t1.orderid
                ,t1.buyerid
                ,t1.sellerid
                ,t1.level
                ,t1.pmode
                ,t1.cost_money
                ,t1.sale_money
                ,t1.member_relationship
                ,t1.order_time
                ,t1.update_time
                ,t1.order_month
                ,t1.apply_did
                ,t1.sync_state
                ,t1.order_date
                ,COUNT(1) OVER (PARTITION BY t1.orderid ) AS order_count_level
                ,MAX(IF(level = 1,t1.buyerid,NULL)) OVER (PARTITION BY t1.orderid ) AS level2_sellerid
                ,MAX(IF(level = -1,t1.sellerid,NULL)) OVER (PARTITION BY t1.orderid ) AS level_2_buyerid
        FROM    ods_myuu_order_aids_split_f t1
        LEFT SEMI JOIN (
            SELECT date_value as order_date FROM dim_src_table_increment_info_di 
            WHERE table_name = 'ods_myuu_order_aids_split_f' AND update_date = ${yesterday} AND date_type = 'order_date'
        ) t2
        ON t1.order_date = t2.order_date
    ) 
) order_split
LEFT JOIN dim_cus_member_info_df buyer_member_info
ON      order_split.buyerid = buyer_member_info.user_id
-- 供应商,分销商
AND     buyer_member_info.user_type IN (0,1)
LEFT JOIN dim_cus_member_info_df seller_member_info
ON      order_split.sellerid = seller_member_info.user_id
;


--增量数据分区更新
INSERT OVERWRITE TABLE dim_src_table_increment_info_di PARTITION(table_name,update_date)
SELECT 
    'order_date' AS date_type
    ,order_date AS date_value
    ,'dwd' AS table_type
    ,'dwd_ord_split_order_details_di' AS table_name
    ,${yesterday} AS update_date
FROM (
    SELECT date_value as order_date FROM dim_src_table_increment_info_di 
    WHERE table_name = 'ods_myuu_order_aids_split_f' AND update_date = ${yesterday}
)
GROUP BY order_date
;




-- 使用递归 CTE，要求 Spark ≥ 3.0 目前环境不能执行，可解析不确定层级
-- 样例：5级分销   78071698411305

-- WITH RECURSIVE trade_chain AS (
--   -- 锚点：顶层记录（level=1 或 0），且该记录的 seller_id 不出现在其他记录的 buyer_id 中
--   SELECT 
--     order_id,
--     buyer_id,
--     seller_id,
--     level,
--     1 AS step
--   FROM s_order_split_d_i s1
--   where s1.orderdate > 20250601  
--   AND s1.ordernum = 78071698411305
--   AND (level = 1 OR level = 0)
--     AND NOT EXISTS (
--       SELECT 1 
--       FROM s_order_split_d_i s2
--       WHERE s2.orderdate > 20250601  
--       AND s2.ordernum = 78071698411305
--       AND s2.order_id = s1.order_id
--      AND s2.buyer_id = s1.seller_id   -- 说明当前记录的 seller 还是别人的买家，即不是顶层
--     )
--   UNION ALL
--   -- 递归：当前记录的 buyer_id 等于下层记录的 seller_id
--   SELECT 
--     t.order_id,
--     t.buyer_id,
--     t.seller_id,
--     t.level,
--     c.step + 1 AS step
--   FROM trade_chain c
--   JOIN s_order_split_d_i t 
--     ON c.order_id = t.order_id 
--     AND c.buyer_id = t.seller_id   -- 上层买家 = 下层卖家
--   WHERE t.level IN (2, -1)          -- 中间层或最终买方
--     AND c.step < 10                -- 防止意外循环，可根据实际最大深度调整
--     AND t.orderdate > 20250601  
--       AND t.ordernum = 78071698411305
-- )

-- SELECT * FROM trade_chain
-- ORDER BY order_id, step
-- LIMIT 100
-- ;



