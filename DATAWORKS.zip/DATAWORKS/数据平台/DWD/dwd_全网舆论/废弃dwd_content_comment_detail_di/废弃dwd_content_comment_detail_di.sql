--Serverless Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2026-03-26 11:25:06
--Serverless Spark SQL任务只能运行在独享资源组上
--********************************************************************--

CREATE TABLE IF NOT EXISTS dwd_content_comment_detail_di (
  content_id        STRING COMMENT '内容ID（帖子ID/视频ID/笔记ID）',
  user_id           STRING COMMENT '用户ID',
  nickname          STRING COMMENT '用户昵称',
  avatar            STRING COMMENT '用户头像地址',
  gender            STRING COMMENT '用户性别',
  profile_url       STRING COMMENT '用户主页地址',
  ip_location       STRING COMMENT '发布的地理信息',
  create_date_time  STRING COMMENT '评论日期时间',
  comment_id        STRING COMMENT '评论ID',
  content           STRING COMMENT '评论内容',
  sub_comment_count STRING COMMENT '评论回复数',
  parent_comment_id STRING COMMENT '父评论ID',
  like_count        STRING COMMENT '点赞数',
  sentiment_label   STRING COMMENT '整体情感标签',
  sentiment_score   STRING COMMENT '整体情感得分',
  dimension_tags    STRING COMMENT '维度标签数组',
  entity_tags       STRING COMMENT '实体标签数组',
  keyword_tags      STRING COMMENT '关键词数组'
)
USING orc
PARTITIONED BY (crawl_date INT COMMENT '采集日期')
COMMENT '发布评论明细表';


-- 6. 微博帖子评论数据
INSERT OVERWRITE TABLE dwd_content_comment_detail_di PARTITION(crawl_date)
SELECT 
  note_id           AS content_id,
  user_id,
  nickname,
  avatar,
  gender,
  profile_url,
  ip_location,
  create_date_time,
  comment_id,
  content,
  sub_comment_count,
  parent_comment_id,
  like_count,
  sentiment_label,
  sentiment_score,
  dimension_tags,
  entity_tags,
  keyword_tags,
  crawl_date
FROM src_crawler_weibo_note_comments_di
WHERE crawl_date = ${ds};


-- 7. 抖音视频评论数据
INSERT INTO TABLE dwd_content_comment_detail_di PARTITION(crawl_date)
SELECT 
  aweme_id      AS content_id,
  user_id,
  nickname,
  avatar,
  ''            AS gender,
  ''            AS profile_url,
  ip_location,
  FROM_UNIXTIME(create_time) AS create_date_time,
  comment_id,
  content,
  sub_comment_count,
  parent_comment_id,
  like_count,
  sentiment_label,
  sentiment_score,
  dimension_tags,
  entity_tags,
  keyword_tags,
  crawl_date
FROM src_crawler_douyin_media_comments_di
WHERE crawl_date = ${ds};


-- 8. 快手视频评论数据
INSERT INTO TABLE dwd_content_comment_detail_di PARTITION(crawl_date)
SELECT 
  video_id  AS content_id,
  user_id,
  nickname,
  avatar,
  ''        AS gender,
  ''        AS profile_url,
  ''        AS ip_location,
  FROM_UNIXTIME(create_time) AS create_date_time,
  comment_id,
  content,
  sub_comment_count,
  parent_comment_id,
  like_count,
  sentiment_label,
  sentiment_score,
  dimension_tags,
  entity_tags,
  keyword_tags,
  crawl_date
FROM src_crawler_kuaishou_media_comments_di
WHERE crawl_date = ${ds};


-- 9. 小红书笔记评论数据
INSERT INTO TABLE dwd_content_comment_detail_di PARTITION(crawl_date)
SELECT 
  note_id   AS content_id,
  user_id,
  nickname,
  avatar,
  ''        AS gender,
  ''        AS profile_url,
  ip_location,
  FROM_UNIXTIME(create_time) AS create_date_time,
  comment_id,
  content,
  sub_comment_count,
  parent_comment_id,
  like_count,
  sentiment_label,
  sentiment_score,
  dimension_tags,
  entity_tags,
  keyword_tags,
  crawl_date
FROM src_crawler_xiaohongshu_notes_comments_di
WHERE crawl_date = ${ds};


-- 10. 携程景区评论数据
INSERT INTO TABLE dwd_content_comment_detail_di PARTITION(crawl_date)
SELECT 
  CAST(scenic_id AS STRING)     AS content_id,
  CAST(user_id AS STRING)       AS user_id,
  nickname,
  avatar,
  ''                            AS gender,
  ''                            AS profile_url,
  ip_location,  
  publish_time                  AS create_date_time,
  CAST(comment_id AS STRING)    AS comment_id,
  content,
  ''                            AS sub_comment_count,
  ''                            AS parent_comment_id,
  CAST(like_count AS STRING)    AS like_count,
  sentiment_label,
  sentiment_score,
  dimension_tags,
  entity_tags,
  keyword_tags,
  crawl_date
FROM src_crawler_ctrip_scenic_comment_di
WHERE crawl_date = ${ds};


