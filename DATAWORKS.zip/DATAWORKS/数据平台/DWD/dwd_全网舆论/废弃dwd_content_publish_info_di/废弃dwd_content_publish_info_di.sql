--Serverless Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2026-03-26 11:24:58
--Serverless Spark SQL任务只能运行在独享资源组上
--********************************************************************--

CREATE TABLE IF NOT EXISTS dwd_content_publish_info_di (
  platform          STRING COMMENT '平台类型',
  content_id        STRING COMMENT '内容ID（帖子ID/视频ID/笔记ID）',
  source_keyword    STRING COMMENT '搜索来源关键字',
  user_id           STRING COMMENT '用户ID',
  nickname          STRING COMMENT '用户名称',
  avatar            STRING COMMENT '用户头像URL',
  title             STRING COMMENT '标题',
  content_desc      STRING COMMENT '描述',
  gender            STRING COMMENT '性别标签',
  profile_url       STRING COMMENT '用户主页地址',
  ip_location       STRING COMMENT '发布地区',
  create_date_time  STRING COMMENT '发布日期时间',
  liked_count       STRING COMMENT '点赞数',
  comments_count    STRING COMMENT '评论数量',
  collected_count   STRING COMMENT '收藏数',
  shared_count      STRING COMMENT '转发/分享数量',
  content_url       STRING COMMENT '内容详情URL',
  cover_image_list  STRING COMMENT '封面图片列表/地址',
  video_url         STRING COMMENT '视频地址'
)
USING orc
PARTITIONED BY (crawl_date INT COMMENT '采集日期')
COMMENT '发布的内容信息表';


-- 1. 微博帖子数据
INSERT OVERWRITE TABLE dwd_content_publish_info_di PARTITION(crawl_date)
SELECT 
  'weibo'       AS platform,
  note_id       AS content_id,
  source_keyword,
  user_id,
  nickname,
  avatar,
  content       AS title,
  content       AS content_desc,
  gender,
  profile_url,
  ip_location,
  create_date_time,
  liked_count,
  comments_count,
  ''            AS collected_count,
  shared_count,
  note_url      AS content_url,
  image_list    AS cover_image_list,
  video_url,
  crawl_date
FROM src_crawler_weibo_notes_info_di
WHERE crawl_date = ${ds};


-- 2. 抖音视频数据
INSERT INTO TABLE dwd_content_publish_info_di PARTITION(crawl_date)
SELECT 
  'douyin'      AS platform,
  aweme_id      AS content_id,
  source_keyword,
  user_id,
  nickname,
  avatar,
  title,
  desc          AS content_desc,
  ''            AS gender,
  ''            AS profile_url,
  ip_location,
  FROM_UNIXTIME(create_time)    AS create_date_time,
  liked_count,
  comment_count                 AS comments_count,
  collected_count,
  share_count                   AS shared_count,
  aweme_url                     AS content_url,
  cover_url                     AS cover_image_list,
  video_download_url            AS video_url,
  crawl_date
FROM src_crawler_douyin_media_info_di
WHERE crawl_date = ${ds};


-- 3. 快手视频数据
INSERT INTO TABLE dwd_content_publish_info_di PARTITION(crawl_date)
SELECT 
  'kuaishou'        AS platform,
  video_id          AS content_id,
  source_keyword,
  user_id,
  nickname,
  avatar,
  title,
  desc              AS content_desc,
  ''                AS gender,
  ''                AS profile_url,
  ''                AS ip_location,
  FROM_UNIXTIME(create_time) AS create_date_time,
  liked_count,
  viewd_count       AS comments_count,
  ''                AS collected_count,
  ''                AS shared_count,
  video_url         AS content_url,
  video_cover_url   AS cover_image_list,
  ''                AS video_url,
  crawl_date
FROM src_crawler_kuaishou_media_info_di
WHERE crawl_date = ${ds};


-- 4. 小红书笔记数据
INSERT INTO TABLE dwd_content_publish_info_di PARTITION(crawl_date)
SELECT 
  'xiaohongshu'     AS platform,
  note_id           AS content_id,
  source_keyword,
  user_id,
  nickname,
  avatar,
  title,
  desc              AS content_desc,
  ''                AS gender,
  ''                AS profile_url,
  ip_location,
  FROM_UNIXTIME(time) AS create_date_time,
  liked_count,
  comment_count     AS comments_count,
  collected_count,
  share_count       AS shared_count,
  note_url          AS content_url,
  image_list        AS cover_image_list,
  video_url,
  crawl_date
FROM src_crawler_xiaohongshu_notes_info_di
WHERE crawl_date = ${ds};


-- 5. 携程景区评论数据到内容信息表（特殊处理，视为内容发布）
INSERT INTO TABLE dwd_content_publish_info_di PARTITION(crawl_date)
SELECT 
  'ctrip'           AS platform,
  CAST(scenic_id AS STRING) AS content_id,
  ''                AS source_keyword,
  CAST(user_id AS STRING)   AS user_id,
  nickname,
  avatar,
  scenic_name       AS title,
  content           AS content_desc,
  ''                AS gender,
  ''                AS profile_url,
  ip_location,
  publish_time      AS create_date_time,
  like_count        AS liked_count,
  ''                AS comments_count,
  ''                AS collected_count,
  ''                AS shared_count,
  ''                AS content_url,
  images            AS cover_image_list,
  videos            AS video_url,
  crawl_date
FROM src_crawler_ctrip_scenic_comment_di
WHERE crawl_date = ${ds};

