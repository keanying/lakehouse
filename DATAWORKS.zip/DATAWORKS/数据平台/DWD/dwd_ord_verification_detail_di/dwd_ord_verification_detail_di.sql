--Serverless Spark SQL
--********************************************************************--
--author: 韩瑞
--create time: 2026-06-12 19:29:23
--Serverless Spark SQL任务只能运行在独享资源组上
--********************************************************************--
--action、source 枚举值参考：https://12301-cc.feishu.cn/wiki/KIkuw7WpviPG6qkQPjrc7jH6nLe


-- DROP TABLE if EXISTS dwd_ord_verification_detail_di;
CREATE TABLE IF NOT exists dwd_ord_verification_detail_di
(
    id                     BIGINT COMMENT '自增ID'
    ,order_id              STRING COMMENT '订单号'
    ,ticket_id             BIGINT COMMENT '票类ID'
    ,action                BIGINT COMMENT '变更状态:0=下单,1=修改,2=取消,3=出票,4=支付,5=验证,6=撤销,7=撤改,8=重打印,9=离线订单下载,10=处理退票申请,11=提交退票申请,12=过期,13=同意退票申请,14=拒绝退票申请,15=核销,16=订单加票,17=完结'
    ,source                BIGINT COMMENT '操作来源:0=终端机,1=软终端,2=自助机,3=外部通知更新,4=云票务,5=云闸机,6=PC-支付宝,7=手机支付宝,8=支付宝刷卡,9=支付宝扫码,10=微信支付,11=微信刷卡,12=微信扫码,13=PC-银联,14=手机-银联,15=PC-环迅,16=内部接口,17=外部接口,18=undefined,19=自运行服务,20=安卓智能终端机,21=验证服务器,22=微信商城,23=二级店铺,24=OTA,25=会员购票,26=年卡特权,27=平安银行,28=内部接口,29=民生乐收银,30=一卡通'
    ,change_tnum           BIGINT COMMENT '变更票数'
    ,left_num              BIGINT COMMENT '剩余票数'
    ,terminal              BIGINT COMMENT '共享终端号'
    ,branchterminal        BIGINT COMMENT '分终端号'
    ,id_card               STRING COMMENT '身份证'
    ,insert_time           STRING COMMENT '添加时间'
    ,oper_member           BIGINT COMMENT '操作用户'
    ,msg                   STRING COMMENT '备注信息'
    ,ext_content           STRING COMMENT '验证或是取消过程中的一些数据'
    ,order_time            INT COMMENT '逻辑下单时间'
    ,update_time           INT COMMENT '订单更新时间'
    ,order_month           INT COMMENT '逻辑下单月份'
    ,apply_did             INT COMMENT '原始供应商ID'
    ,sync_state            INT COMMENT '是否同步标示 1:同步,0:无需同步'
)
COMMENT '订单日志表，按日志插入日期分区'
PARTITIONED BY 
(
    verify_date            INT COMMENT '日志插入日期'
)
STORED AS orc
;



INSERT OVERWRITE TABLE dwd_ord_verification_detail_di PARTITION(verify_date)
SELECT 
    t1.id   as id
    ,t1.ordernum AS order_id
    ,t1.tid AS ticket_id
    ,t1.action
    ,t1.source
    ,t1.tnum AS change_tnum
    ,t1.left_num
    ,t1.terminal
    ,t1.branchterminal
    ,t1.id_card
    ,t1.inserttime AS insert_time
    ,t1.oper_member
    ,t1.msg
    ,t1.ext_content
    ,t1.order_time
    ,t1.update_time
    ,t1.order_month
    ,t1.apply_did
    ,t1.sync_state
    ,t1.insert_date AS verify_date
FROM ods_myuu_pft_order_track_f t1
WHERE t1.insert_date = ${yesterday}
AND t1.tnum > 0
;




-- CREATE TABLE dwd_ord_order_track_details_di
-- (
--     id                     BIGINT COMMENT '自增ID'
--     ,order_id              STRING COMMENT '订单号'
--     ,user_id               INT COMMENT '购买者ID'
--     ,scenic_id             INT COMMENT '景区id'
--     ,ticket_id             BIGINT COMMENT '票类ID'
--     ,product_id            INT COMMENT '产品id'
--     ,sup_id                INT COMMENT '供应商ID'
--     ,saler_id              INT COMMENT '商家ID'
--     ,order_tnum            BIGINT COMMENT '门票数量'
--     ,order_price           INT COMMENT '单价'
--     ,order_status_code     INT COMMENT '订单状态：0=未使用,1=已使用,2=已过期,3=被取消,4=待确认(酒店)，待收货(特产),5=被终端修改,6=被终端撤销,7=部分使用,8=订单完结,9=被删除'
--     ,order_pay_status      INT COMMENT '支付方式:0=现场支付,1=已支付,2=未支付'
--     ,pay_funding_type      INT COMMENT '支付方式：0 = 余额支付,1 = 支付宝,2 = 授信支付,3 = 产品自销,4 = 现场支付,5 = 微信支付,6 = 会员卡支付,7 = 银联支付,8 = 环迅支付,9 = 现金支付,10 = 会员卡,11 = 拉卡拉（商户）,12 = 拉卡拉（平台）,13 = 特权支付（年卡）,14 = 微信（聚合）,15 = 平安银行,16 = 支付宝（聚合）,17 = 会员卡支付,18 = 计时卡支付,25 = 招行一网通支付,26 = 银联商务支付,27 = 银联商务POS支付,28 = 威富通支付,29 = 易宝云企付,33 = 博思支付,35 = 积分支付,36 = POS支'
--     ,original_order_amount INT COMMENT '总的支付金额'
--     ,order_channel         INT COMMENT '下单方式:0=正常分销商下单,1=普通用户支付,2=用户手机支付,3=会员卡购票,10=云票务,11=微信商城,12=自助机,13=二级店铺,14=闸机购票,15=智能终端,16=计调下单,17=淘宝码商,18=年卡,19=微信端,20=外部接口OTA下单,22=一卡通,23=套票子票'
--     ,visitors              INT COMMENT '订单客户类型：1=游客,2=分销商'
--     ,product_type          STRING COMMENT '商品类型'
--     ,action                BIGINT COMMENT '变更状态:1=0=下单,1=修改,2=取消,3=出票,4=支付,验证,撤销,7=撤改,8=重打印,9=离线订单下载,10=处理退票申请,11=提交退票申请,12=过期,13=同意退票申请,14=拒绝退票申请,15=核销,16=订单加票,17=完结'
--     ,source                BIGINT COMMENT '操作来源:0=终端机,1=软终端,2=自助机,3=外部通知更新,4=云票务,5=云闸机,6=PC-支付宝,7=手机支付宝,8=支付宝刷卡,9=支付宝扫码,10=微信支付,11=微信刷卡,12=微信扫码,13=PC-银联,14=手机-银联,15=PC-环迅,16=内部接口,17=外部接口,18=undefined,19=自运行服务,20=安卓智能终端机,21=验证服务器,22=微信商城,23=二级店铺,24=OTA,25=会员购票,26=年卡特权,27=平安银行,28=内部接口,29=民生乐收银,30=一卡通'
--     ,change_tnum           BIGINT COMMENT '变更票数'
--     ,left_num              BIGINT COMMENT '剩余票数'
--     ,terminal              BIGINT COMMENT '共享终端号'
--     ,branchterminal        BIGINT COMMENT '分终端号'
--     ,id_card               STRING COMMENT '身份证'
--     ,insert_time           STRING COMMENT '添加时间'
--     ,oper_member           BIGINT COMMENT '操作用户'
--     ,msg                   STRING COMMENT '备注信息'
--     ,ext_content           STRING COMMENT '验证或是取消过程中的一些数据'
--     ,order_time            INT COMMENT '逻辑下单时间'
--     ,update_time           INT COMMENT '订单更新时间'
--     ,order_month           TINYINT COMMENT '逻辑下单月份'
--     ,apply_did             INT COMMENT '原始供应商ID'
--     ,sync_state            TINYINT COMMENT '是否同步标示 1:同步,0:无需同步'
-- )
-- COMMENT '订单日志表，按日志插入日期分区'
-- PARTITIONED BY 
-- (
--     insert_date            INT COMMENT '日志插入日期'
-- )
-- ;

-- --通过订单号查询订单信息，效率低，暂时不关联订单数据
-- SELECT 
--     t1.id   as id
--     ,t1.ordernum AS order_id
--     --=======================订单相关信息==============
--     ,t2.member AS user_id
--     ,t2.lid AS scenic_id
--     ,t1.tid AS ticket_id
--     ,t2.pid AS product_id
--     ,t2.aid AS sup_id
--     ,t2.salerid AS saler_id
--     ,t2.tnum AS order_tnum
--     ,IF(
--         t2.`ordermode` = 18 AND t2.`paymode` = 13, 
--         0,
--         IF(t2.`tprice` < 0, 0, t2.`tprice`)
--     )  AS order_price
--     ,t2.`status`  AS order_status_code
--     ,t2.pay_status AS order_pay_status
--     ,t2.paymode AS pay_funding_type
--     -- 年卡特权支付订单金额置零，金额为负数订单金额置零
--     ,IF(
--         t2.`ordermode` = 18 AND t2.`paymode` = 13, 
--         0,
--         IF(t2.`totalmoney` < 0, 0, t2.`totalmoney`)
--     ) AS original_order_amount
--     ,t2.ordermode AS order_channel
--     ,t2.visitors 
--     ,t2.product_type
--     --================================================
--     ,t1.action
--     ,t1.source
--     ,t1.tnum AS change_tnum
--     ,t1.left_num
--     ,t1.terminal
--     ,t1.branchterminal
--     ,t1.id_card
--     ,t1.inserttime AS insert_time
--     ,t1.oper_member
--     ,t1.msg
--     ,t1.ext_content
--     ,t2.order_time AS order_time
--     ,t1.update_time
--     ,t1.order_month
--     ,t1.apply_did
--     ,t1.sync_state
--     ,t2.order_date
--     ,t1.insertdate AS insert_date
-- FROM s_order_track_d_i t1
-- LEFT JOIN ods_myuu_uu_ss_order_df t2
-- ON t1.ordernum = t2.ordernum
-- AND t2.order_date > 20250101
-- --匹配近2年订单信息
-- -- AND t2.order_date > 20260101
-- WHERE t1.insertdate > 20260101
-- AND t1.tnum > 0
-- LIMIT 1000
-- ;

