--Serverless Spark SQL
--********************************************************************--
--author: 韩瑞
--create time: 2026-06-11 15:22:30
--Serverless Spark SQL任务只能运行在独享资源组上
--********************************************************************--
-- DROP TABLE IF exists dwd_ord_group_sub_order_details_di;
CREATE TABLE IF NOT EXISTS dwd_ord_group_sub_order_details_di
(
    master_id              BIGINT COMMENT '团单自增ID'
    ,sub_id                BIGINT COMMENT '子单自增ID'
    ,master_order_id       STRING COMMENT '团单订单号'
    ,sub_order_id          STRING COMMENT '子订单号'
    ,sub_scenic_id         BIGINT COMMENT '子单景区ID'
    ,sub_ticket_id         BIGINT COMMENT '子单票ID'
    ,master_sup_id         BIGINT COMMENT '团单供应商ID'
    ,master_distributor_id BIGINT COMMENT '团单分销商ID'
    ,master_guide_id       BIGINT COMMENT '团单导游ID'
    ,master_combine_pay_id STRING COMMENT '团单合并付款的ID'
    ,master_group_id       BIGINT COMMENT '团单分销商分组ID'
    ,contact_phone_num     STRING COMMENT '手机号'
    ,ordername             STRING COMMENT '姓名'
    ,master_status         INT COMMENT '团单-订单状态:0未确认;1已确认;2已验证;3已取消'
    ,master_pay_status     INT COMMENT '团单-支付状态:0未支付;1已支付;2部分支付'
    ,master_order_type     INT COMMENT '团单-报团下单方式：1=云票务 ；2=微平台；3=分销商报团预定；4=报团计调'
    ,is_check_in           INT COMMENT '是否住宿 0 否 1 是'
    ,hotel_name            STRING COMMENT '入住酒店名称'
    ,master_province_code  BIGINT COMMENT '客源地省份编码'
    ,master_city_code      BIGINT COMMENT '客源地城市编码'
    ,master_county_code    BIGINT COMMENT '客源地县城编码'
    ,team_qty              BIGINT COMMENT '团队人数'
    ,master_play_time      DATE COMMENT '团单-游玩时间'
    ,master_order_time     STRING COMMENT '团单下单时间'
    ,master_update_time    TIMESTAMP COMMENT '团单更新时间'
    ,team_type_id          STRING COMMENT '团单类（对应pft_team_rules表中limit_type等于2的id）'
    ,ext_content           STRING COMMENT '团单扩展信息'
    ,active_code           STRING COMMENT '团单激活码'
    ,master_active_status  INT COMMENT '团单-激活状态:0无需激活,1未激活,2已激活'
    ,active_time           TIMESTAMP COMMENT '团单-激活时间'
    ,is_sync               BIGINT COMMENT '团单-是否已同步 0：否 1：是'
    ,first_check_time      TIMESTAMP COMMENT '团单首次验证时间'
    ,sub_is_expired        BIGINT COMMENT '子单是否过期'
    ,sub_order_time        TIMESTAMP COMMENT '子单下单时间'
    ,sub_active_status     INT COMMENT '子单-激活状态 0：无需激活 1：未激活  2：已激活'
    ,sub_status            INT COMMENT '子单-订单状态：0=未使用,1=已使用,2=已过期,3=被取消,4=待确认(酒店)，待收货(特产),5=被终端修改,6=被终端撤销,7=部分使用,8=订单完结,9=被删除,10=待预约,11=待出票,80=待发货,81=已发货'
    ,sub_update_time       TIMESTAMP COMMENT '子单更新时间'
    ,sub_play_time         DATE COMMENT '子单游玩时间（同uu_ss_oerder表）'
    ,dwd_update_time          INT COMMENT '订单更新时间[写入时间以及后期更新时间]'
)
COMMENT '团队订单子单明细表'
PARTITIONED BY 
(
    travel_date            INT COMMENT '下单日期[yyyyMMdd]'
)
STORED AS orc
;


-- 存在部分数据，有主单没有子单/无主单有子单 【数据量:12716】

INSERT OVERWRITE TABLE dwd_ord_group_sub_order_details_di PARTITION(travel_date)
SELECT 
    t1.id AS master_id
    ,t2.id AS sub_id
    ,t1.ordernum AS master_order_id
    ,t2.son_ordernum AS sub_order_id
    ,t2.lid AS sub_scenic_id
    ,t2.tid AS sub_ticket_id
    ,t1.aid AS master_sup_id
    ,t1.fid AS master_distributor_id
    ,t1.guide AS master_guide_id
    ,t1.combine_pay_id AS master_combine_pay_id
    ,t1.group_id AS master_group_id
    ,t1.contacttel AS contact_phone_num
    ,t1.ordername
    ,t1.`status` AS master_status
    ,t1.pay_status AS master_pay_status
    ,t1.ordertype AS master_order_type
    ,t1.is_lodging AS is_check_in
    ,t1.hotel as hotel_name
    ,t1.province AS master_province_code
    ,t1.city AS master_city_code
    ,t1.county AS master_county_code
    ,t1.tnum AS team_qty
    ,t1.playtime AS master_play_time
    ,t1.ordertime AS master_order_time
    ,TO_TIMESTAMP(t1.updatetime) AS master_update_time
    ,t1.team_type_id
    ,t1.ext_content
    ,t1.active_code
    ,t1.active_status AS master_active_status
    ,TO_TIMESTAMP(t1.active_time) AS active_time
    ,t1.sync AS is_sync
    ,TO_TIMESTAMP(t1.first_check_time) AS first_check_time
    ,t2.is_expired AS sub_is_expired
    ,TO_TIMESTAMP(t2.order_time)  AS sub_order_time
    ,t2.active_status AS sub_active_status
    ,t2.status AS sub_status
    ,TO_TIMESTAMP(t2.update_time)  AS sub_update_time
    ,t2.playtime AS sub_play_time
    ,CAST(DATE_FORMAT(now(),'yyyyMMdd') AS INT) AS dwd_update_time
    ,CAST(DATE_FORMAT(TO_DATE(t1.ordertime), 'yyyyMMdd') AS INT) AS travel_date
FROM ods_myuu_uu_ss_order_team_df t1
INNER JOIN ods_myuu_uu_ss_order_team_link_df t2
ON t1.ordernum = t2.main_ordernum
-- WHERE (t1.ordernum is NULL AND t2.main_ordernum IS NOT NULL )
-- OR (t1.ordernum is NOT NULL AND t2.main_ordernum IS NULL)
-- LIMIT 1000
WHERE t1.sync_date = ${yesterday}
AND t2.sync_date = ${yesterday}
;




