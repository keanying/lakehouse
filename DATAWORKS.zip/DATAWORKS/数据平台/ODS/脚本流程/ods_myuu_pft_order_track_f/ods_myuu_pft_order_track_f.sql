--Serverless Spark SQL
--********************************************************************--
--author: 韩瑞
--create time: 2026-08-06 19:19:54
--Serverless Spark SQL任务只能运行在独享资源组上
--********************************************************************--


CREATE TABLE IF NOT EXISTS ods_myuu_pft_order_track_f
(
    key_id              STRING COMMENT '库名+自增ID'
    ,id             BIGINT COMMENT '自增ID'
    ,ordernum       STRING COMMENT '订单号'
    ,action         BIGINT COMMENT '变更状态:1=0=下单,1=修改,2=取消,3=出票,4=支付,验证,撤销,7=撤改,8=重打印,9=离线订单下载,10=处理退票申请,11=提交退票申请,12=过期,13=同意退票申请,14=拒绝退票申请,15=核销,16=订单加票,17=完结'
    ,tid            BIGINT COMMENT '票类ID'
    ,tnum           BIGINT COMMENT '变更票数'
    ,left_num       BIGINT COMMENT '剩余票数'
    ,source         BIGINT COMMENT '操作来源:0=终端机,1=软终端,2=自助机,3=外部通知更新,4=云票务,5=云闸机,6=PC-支付宝,7=手机支付宝,8=支付宝刷卡,9=支付宝扫码,10=微信支付,11=微信刷卡,12=微信扫码,13=PC-银联,14=手机-银联,15=PC-环迅,16=内部接口,17=外部接口,18=undefined,19=自运行服务,20=安卓智能终端机,21=验证服务器,22=微信商城,23=二级店铺,24=OTA,25=会员购票,26=年卡特权,27=平安银行,28=内部接口,29=民生乐收银,30=一卡通'
    ,terminal       BIGINT COMMENT '共享终端号'
    ,branchterminal BIGINT COMMENT '分终端号'
    ,salerid        BIGINT COMMENT '现在存储站点ID'
    ,id_card        STRING COMMENT '身份证'
    ,inserttime     STRING COMMENT '添加时间'
    ,oper_member    BIGINT COMMENT '操作用户'
    ,msg            STRING COMMENT '备注信息'
    ,ext_content    STRING COMMENT '验证或是取消过程中的一些数据'
    ,order_time     INT COMMENT '逻辑下单时间'
    ,update_time    INT COMMENT '订单更新时间'
    ,order_month    TINYINT COMMENT '逻辑下单月份'
    ,apply_did      INT COMMENT '原始供应商ID'
    ,sync_state     TINYINT COMMENT '是否同步标示 1:同步,0:无需同步'
)
COMMENT '订单日志表-myuu库表'
PARTITIONED BY 
(
    insert_date       INT COMMENT '日志插入日期'
)
STORED AS ORC
;



INSERT OVERWRITE TABLE ods_myuu_pft_order_track_f PARTITION(insert_date)
SELECT    key_id         
    ,id            
    ,ordernum      
    ,action        
    ,tid           
    ,tnum          
    ,left_num      
    ,source        
    ,terminal      
    ,branchterminal
    ,salerid       
    ,id_card       
    ,inserttime    
    ,oper_member   
    ,msg           
    ,ext_content   
    ,order_time    
    ,update_time   
    ,order_month   
    ,apply_did     
    ,sync_state    
    ,insert_date
FROM (
    SELECT CONCAT('order_201801','-',id) AS key_id,* FROM ods_order_201801_pft_order_track_history_di WHERE insert_date = ${yesterday} UNION ALL
    SELECT CONCAT('order_201802','-',id) AS key_id,* FROM ods_order_201802_pft_order_track_history_di WHERE insert_date = ${yesterday} UNION ALL
    SELECT CONCAT('order_201901','-',id) AS key_id,* FROM ods_order_201901_pft_order_track_history_di WHERE insert_date = ${yesterday} UNION ALL
    SELECT CONCAT('order_201902','-',id) AS key_id,* FROM ods_order_201902_pft_order_track_history_di WHERE insert_date = ${yesterday} UNION ALL
    SELECT CONCAT('order_202001','-',id) AS key_id,* FROM ods_order_202001_pft_order_track_history_di WHERE insert_date = ${yesterday} UNION ALL
    SELECT CONCAT('order_202002','-',id) AS key_id,* FROM ods_order_202002_pft_order_track_history_di WHERE insert_date = ${yesterday} UNION ALL
    SELECT CONCAT('order_202101','-',id) AS key_id,* FROM ods_order_202101_pft_order_track_history_di WHERE insert_date = ${yesterday} UNION ALL
    SELECT CONCAT('order_202102','-',id) AS key_id,* FROM ods_order_202102_pft_order_track_history_di WHERE insert_date = ${yesterday} UNION ALL
    SELECT CONCAT('order_202201','-',id) AS key_id,* FROM ods_order_202201_pft_order_track_history_di WHERE insert_date = ${yesterday} UNION ALL
    SELECT CONCAT('order_202202','-',id) AS key_id,* FROM ods_order_202202_pft_order_track_history_di WHERE insert_date = ${yesterday} UNION ALL
    SELECT CONCAT('order_202301','-',id) AS key_id,* FROM ods_order_202301_pft_order_track_history_di WHERE insert_date = ${yesterday} UNION ALL
    SELECT CONCAT('order_202302','-',id) AS key_id,* FROM ods_order_202302_pft_order_track_history_di WHERE insert_date = ${yesterday} UNION ALL
    SELECT CONCAT('order_202401','-',id) AS key_id,* FROM ods_order_202401_pft_order_track_history_di WHERE insert_date = ${yesterday} UNION ALL
    SELECT CONCAT('order_202402','-',id) AS key_id,* FROM ods_order_202402_pft_order_track_history_di WHERE insert_date = ${yesterday} UNION ALL
    SELECT CONCAT('order_202501','-',id) AS key_id,* FROM ods_order_202501_pft_order_track_history_di WHERE insert_date = ${yesterday} UNION ALL
    SELECT CONCAT('order_202502','-',id) AS key_id,* FROM ods_order_202502_pft_order_track_history_di WHERE insert_date = ${yesterday} UNION ALL

    SELECT CONCAT('myuu','-',id) AS key_id,* FROM ods_myuu_pft_order_track_di where insert_date = ${yesterday}

);


