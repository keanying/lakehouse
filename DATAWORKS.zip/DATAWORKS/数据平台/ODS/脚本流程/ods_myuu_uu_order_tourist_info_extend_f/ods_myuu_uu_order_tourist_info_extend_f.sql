--Serverless Spark SQL
--********************************************************************--
--author: 韩瑞
--create time: 2026-08-05 20:24:01
--Serverless Spark SQL任务只能运行在独享资源组上
--********************************************************************--
-- CREATE TABLE IF NOT EXISTS ods_myuu_uu_order_tourist_info_extend_f
-- (
--     id           BIGINT COMMENT '自增ID'
--     ,orderid     STRING COMMENT '订单号ID'
--     ,idx         STRING COMMENT '订单游客序号'
--     ,end_time    STRING COMMENT '门票订单有效截止时间'
--     ,valid_num   INT COMMENT '剩余可入园次数'
--     ,take_way    INT COMMENT '取票方式:1=凭证号取票,2=手机号取票,3=身份证取票,4=订单号取票,5=团单号取票'
--     ,apply_did   INT COMMENT '原始供应商ID'
--     ,ext_info    STRING COMMENT '拓展信息字段'
--     ,order_time  INT COMMENT '逻辑下单时间'
--     ,update_time INT COMMENT '订单更新时间'
--     ,order_month TINYINT COMMENT '逻辑下单月份'
--     ,sync_state  TINYINT COMMENT '是否同步标示 1:同步,0:无需同步'
-- )
-- COMMENT '游客身份证等信息表-myuu库全量表,订单日期分区'
-- PARTITIONED BY 
-- (
--     order_date    INT COMMENT '逻辑下单日期'
-- )
-- stored as orc
-- ;



INSERT INTO ods_myuu_uu_order_tourist_info_extend_f PARTITION(order_date)
select  
    id          
    ,orderid    
    ,idx        
    ,end_time   
    ,valid_num  
    ,take_way   
    ,apply_did  
    ,ext_info   
    ,order_time 
    ,update_time
    ,order_month
    ,sync_state        
    ,order_date
FROM ods_myuu_uu_order_tourist_info_extend_di 
where update_date = ${yesterday}
;



--去重更新
INSERT OVERWRITE TABLE ods_myuu_uu_order_tourist_info_extend_f PARTITION(order_date)
SELECT 
    id          
    ,orderid    
    ,idx        
    ,end_time   
    ,valid_num  
    ,take_way   
    ,apply_did  
    ,ext_info   
    ,order_time 
    ,update_time
    ,order_month
    ,sync_state        
    ,order_date
FROM (
    select  /*+ BROADCAST(t2) */
        t1.id          
        ,t1.orderid    
        ,t1.idx        
        ,t1.end_time   
        ,t1.valid_num  
        ,t1.take_way   
        ,t1.apply_did  
        ,t1.ext_info   
        ,t1.order_time 
        ,t1.update_time
        ,t1.order_month
        ,t1.sync_state        
        ,t1.order_date
        ,ROW_NUMBER() OVER(PARTITION BY t1.order_date,t1.orderid,t1.idx ORDER BY t1.update_time DESC) AS num
    FROM ods_myuu_uu_order_tourist_info_extend_f t1
    INNER JOIN (
        SELECT DISTINCT order_date
        FROM ods_myuu_uu_order_tourist_info_extend_di 
        where update_date = ${yesterday}
    ) t2
    ON t1.order_date = t2.order_date
)
WHERE num = 1
;

INSERT OVERWRITE TABLE dim_src_table_increment_info_di PARTITION(table_name,update_date)
SELECT 
    'order_date' AS date_type
    ,order_date AS date_value
    ,'ods' AS table_type
    ,'ods_myuu_uu_order_tourist_info_extend_f' AS table_name
    ,${yesterday} AS update_date
FROM ods_myuu_uu_order_tourist_info_extend_di 
where update_date = ${yesterday}
GROUP BY order_date
;

