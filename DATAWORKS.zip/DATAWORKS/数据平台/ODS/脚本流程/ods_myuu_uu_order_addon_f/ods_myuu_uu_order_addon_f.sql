--Serverless Spark SQL
--********************************************************************--
--author: 韩瑞
--create time: 2026-07-28 14:17:23
--Serverless Spark SQL任务只能运行在独享资源组上
--********************************************************************--

CREATE TABLE IF not EXISTS ods_myuu_uu_order_addon_f
(
    id             BIGINT COMMENT '表ID'
    ,orderid       STRING COMMENT '订单号'
    ,dstatus       TINYINT COMMENT '确认订单状态0无需确认 1待确认 2已确认未验证 3已确认已验证 4确认后取消 5确认后修改,6演出套票的订单'
    ,confirm_time  STRING COMMENT '确认时间'
    ,confirm_op    INT COMMENT '分销商ID'
    ,ifpack        INT COMMENT '0非套票订单1套票主订单 >100000套票从订单（2票付通从订单）'
    ,sysorder      TINYINT COMMENT '子票是否已经处理完成:100=处理完,0=没有'
    ,pack_order    STRING COMMENT '套票主票订单号'
    ,pack_process  STRING COMMENT '线下自填的流水号json数据'
    ,ifprint       TINYINT COMMENT '是否被打印 1代表被打印'
    ,vcode         STRING COMMENT '对接第三方系统的凭证码'
    ,tordernum     STRING COMMENT '对接第三方系统的对方订单'
    ,partner_mark  SMALLINT COMMENT '是否对接三方系统标识'
    ,link_ordernum STRING COMMENT '原来uu_order_fx_details->concat_id'
    ,order_time    INT COMMENT '逻辑下单时间'
    ,update_time   INT COMMENT '订单更新时间'
    ,order_month   TINYINT COMMENT '逻辑下单月份'
    ,apply_did     INT COMMENT '原始供应商ID'
    ,sync_state    TINYINT COMMENT '是否同步标示 1:同步,0:无需同步'
)
COMMENT '订单扩展表_全量表每日更新变化数据对应订单日期'
PARTITIONED BY 
(
    order_date      INT COMMENT '逻辑下单日期'
)
STORED AS ORC
;

INSERT INTO ods_myuu_uu_order_addon_f PARTITION(order_date)
SELECT id            
    ,orderid      
    ,dstatus      
    ,confirm_time 
    ,confirm_op   
    ,ifpack       
    ,sysorder     
    ,pack_order   
    ,pack_process 
    ,ifprint      
    ,vcode        
    ,tordernum    
    ,partner_mark 
    ,link_ordernum
    ,order_time   
    ,update_time  
    ,order_month  
    ,apply_did    
    ,sync_state   
    ,CAST(DATE_FORMAT(from_unixtime(order_time),'yyyyMMdd') AS INT)  AS order_date
FROM ods_myuu_uu_order_addon_di
WHERE update_date = ${yesterday}
;


INSERT OVERWRITE TABLE ods_myuu_uu_order_addon_f PARTITION(order_date)
SELECT 
    id            
    ,orderid      
    ,dstatus      
    ,confirm_time 
    ,confirm_op   
    ,ifpack       
    ,sysorder     
    ,pack_order   
    ,pack_process 
    ,ifprint      
    ,vcode        
    ,tordernum    
    ,partner_mark 
    ,link_ordernum
    ,order_time   
    ,update_time  
    ,order_month  
    ,apply_did    
    ,sync_state
    ,order_date
FROM (
    SELECT /*+ BROADCAST(t2) */
        t1.id            
        ,t1.orderid      
        ,t1.dstatus      
        ,t1.confirm_time 
        ,t1.confirm_op   
        ,t1.ifpack       
        ,t1.sysorder     
        ,t1.pack_order   
        ,t1.pack_process 
        ,t1.ifprint      
        ,t1.vcode        
        ,t1.tordernum    
        ,t1.partner_mark 
        ,t1.link_ordernum
        ,t1.order_time   
        ,t1.update_time  
        ,t1.order_month  
        ,t1.apply_did    
        ,t1.sync_state 
        ,t1.order_date
        ,ROW_NUMBER() OVER(PARTITION BY t1.order_date,t1.orderid ORDER BY t1.update_time DESC) AS num 
    FROM ods_myuu_uu_order_addon_f t1
    INNER JOIN (
        select order_date
        from ods_myuu_uu_order_addon_di
        WHERE update_date = ${yesterday}
        GROUP BY order_date
    ) t2
    ON t1.order_date = t2.order_date
)
WHERE num = 1
;


INSERT OVERWRITE TABLE dim_src_table_increment_info_di PARTITION(table_name,update_date)
SELECT 
    'order_date' AS date_type
    ,order_date AS date_value
    ,'ods' AS table_type
    ,'ods_myuu_uu_order_addon_f' AS table_name
    ,${yesterday} AS update_date
FROM ods_myuu_uu_order_addon_di 
where update_date = ${yesterday}
GROUP BY order_date
;


