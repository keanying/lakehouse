--Serverless Spark SQL
--********************************************************************--
--author: 韩瑞
--create time: 2026-08-05 17:42:53
--Serverless Spark SQL任务只能运行在独享资源组上
--********************************************************************--


-- CREATE TABLE IF NOT EXISTS ods_myuu_order_aids_split_f
-- (
--     id                   BIGINT COMMENT ''
--     ,orderid             STRING COMMENT '订单号'
--     ,buyerid             INT COMMENT '购买用户ID'
--     ,sellerid            INT COMMENT '供应商ID'
--     ,level               TINYINT COMMENT '所处的级别：1=第一级，0=既是1级也是末级，-1=最末级，2=中间级别'
--     ,pmode               INT COMMENT '该级别的支付方式'
--     ,cost_money          DECIMAL(12,0) COMMENT '成本价（分为单位）'
--     ,sale_money          DECIMAL(12,0) COMMENT '销售价（分为单位）'
--     ,member_relationship TINYINT COMMENT '订单会员关系 0:平台关系,1:资源中心关系'
--     ,order_time          INT COMMENT '逻辑下单时间'
--     ,update_time         INT COMMENT '订单更新时间'
--     ,order_month         TINYINT COMMENT '逻辑下单月份'
--     ,apply_did           INT COMMENT '原始供应商ID'
--     ,sync_state          TINYINT COMMENT '是否同步标示 1:同步,0:无需同步'
-- )
-- COMMENT '订单分销关系表,全量表订单日期分区'
-- PARTITIONED BY 
-- (
--     order_date      INT COMMENT '下单日期yyyyMMdd'
-- )
-- STORED AS ORC
-- ;


INSERT INTO ods_myuu_order_aids_split_f PARTITION(order_date)
select  id                  
    ,orderid            
    ,buyerid            
    ,sellerid           
    ,level              
    ,pmode              
    ,cost_money         
    ,sale_money         
    ,member_relationship
    ,order_time         
    ,update_time        
    ,order_month        
    ,apply_did          
    ,sync_state         
    ,order_date
FROM ods_myuu_order_aids_split_di 
where update_date = ${yesterday}
;



--去重更新
INSERT OVERWRITE TABLE ods_myuu_order_aids_split_f PARTITION(order_date)
SELECT 
    id                  
    ,orderid            
    ,buyerid            
    ,sellerid           
    ,level              
    ,pmode              
    ,cost_money         
    ,sale_money         
    ,member_relationship
    ,order_time         
    ,update_time        
    ,order_month        
    ,apply_did          
    ,sync_state         
    ,order_date
FROM (
    select  /*+ BROADCAST(t2) */
        t1.id                  
        ,t1.orderid            
        ,t1.buyerid            
        ,t1.sellerid           
        ,t1.level              
        ,t1.pmode              
        ,t1.cost_money         
        ,t1.sale_money         
        ,t1.member_relationship
        ,t1.order_time         
        ,t1.update_time        
        ,t1.order_month        
        ,t1.apply_did          
        ,t1.sync_state         
        ,t1.order_date
        ,ROW_NUMBER() OVER(PARTITION BY t1.order_date,t1.orderid,t1.buyerid,t1.sellerid ORDER BY t1.update_time DESC) AS num
    FROM ods_myuu_order_aids_split_f t1
    INNER JOIN (
        SELECT order_date
        FROM ods_myuu_order_aids_split_di 
        where update_date = ${yesterday}
        GROUP BY order_date
    ) t2
    ON t1.order_date = t2.order_date
)
WHERE num = 1
;

INSERT OVERWRITE TABLE dim_src_table_increment_info_di PARTITION(table_name,update_date)
SELECT 
    'order_date' AS date_type
    ,order_date AS date_value
    ,'ods' AS table_type
    ,'ods_myuu_order_aids_split_f' AS table_name
    ,${yesterday} AS update_date
FROM ods_myuu_order_aids_split_di 
where update_date = ${yesterday}
GROUP BY order_date
;

