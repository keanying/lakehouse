--Serverless Spark SQL
--********************************************************************--
--author: 韩瑞
--create time: 2026-06-25 17:20:40
--Serverless Spark SQL任务只能运行在独享资源组上
--********************************************************************--

CREATE TABLE IF NOT EXISTS ods_myuu_uu_ss_order_df
(
    id              BIGINT COMMENT '表id'
    ,member         INT COMMENT '购买者ID'
    ,ordernum       STRING COMMENT '订单号'
    ,certnum        BIGINT COMMENT '资源ID'
    ,remotenum      STRING COMMENT '远端订单号'
    ,lid            INT COMMENT '景区id'
    ,tid            INT COMMENT '门票id'
    ,pid            INT COMMENT '产品id'
    ,aid            INT COMMENT '供应商ID'
    ,tnum           BIGINT COMMENT '门票数量'
    ,tprice         INT COMMENT '单价'
    ,ordername      STRING COMMENT '取票人姓名'
    ,ordertel       STRING COMMENT '取票人电话'
    ,contacttel     STRING COMMENT '取票人电话'
    ,ordertime      TIMESTAMP COMMENT '下单时间'
    ,playtime       date COMMENT '预计游玩时间'
    ,begintime      date COMMENT '开始时间'
    ,endtime        date COMMENT '结束时间'
    ,ctime          TIMESTAMP COMMENT '取消时间'
    ,dtime          TIMESTAMP COMMENT '验证时间'
    ,`status`       INT COMMENT '订单状态：0=未使用,1=已使用,2=已过期,3=被取消,4=待确认(酒店)，待收货(特产),5=被终端修改,6=被终端撤销,7=部分使用,8=订单完结,9=被删除'
    ,pay_status     INT COMMENT '支付方式:0=现场支付,1=已支付,2=未支付'
    ,salerid        INT COMMENT '商家ID'
    ,remsg          BIGINT COMMENT '短信重发限制次数'
    ,smserror       SMALLINT COMMENT '短信错误信息'
    ,paymode        INT COMMENT '支付方式：0 = 余额支付,1 = 支付宝,2 = 授信支付,3 = 产品自销,4 = 现场支付,5 = 微信支付,6 = 会员卡支付,7 = 银联支付,8 = 环迅支付,9 = 现金支付,10 = 会员卡,11 = 拉卡拉（商户）,12 = 拉卡拉（平台）,13 = 特权支付（年卡）,14 = 微信（聚合）,15 = 平安银行,16 = 支付宝（聚合）,17 = 会员卡支付,18 = 计时卡支付,25 = 招行一网通支付,26 = 银联商务支付,27 = 银联商务POS支付,28 = 威富通支付,29 = 易宝云企付,33 = 博思支付,35 = 积分支付,36 = POS支'
    ,totalmoney     INT COMMENT '总的支付金额'
    ,ordermode      INT COMMENT '下单方式:0=正常分销商下单,1=普通用户支付,2=用户手机支付,3=会员卡购票,10=云票务,11=微信商城,12=自助机,13=二级店铺,14=闸机购票,15=智能终端,16=计调下单,17=淘宝码商,18=年卡,19=微信端,20=外部接口OTA下单,22=一卡通,23=套票子票'
    ,onsale         INT COMMENT '0正常1使用优惠价支付2修改过的订单'
    ,personid       STRING COMMENT '取票人身份信息'
    ,callback       INT COMMENT '是否需要回调0无需1必需'
    ,code           BIGINT COMMENT '凭证码'
    ,unioncheck     INT COMMENT '提现类型：0=正常订单，1=不可退而且可提现的订单，2=独立收款'
    ,visitors       INT COMMENT '订单客户类型：1=游客,2=分销商'
    ,pay_time       BIGINT COMMENT '订单支付时间'
    ,order_time     BIGINT COMMENT '逻辑下单时间'
    ,update_time    INT COMMENT '订单更新时间'
    ,order_month    INT COMMENT '逻辑下单月份'
    ,product_type   STRING COMMENT '商品类型'
    ,apply_did      INT COMMENT '原始供应商ID'
    ,sync_state     INT COMMENT '是否同步标示 1:同步,0:无需同步'
    ,trade_order_id STRING COMMENT '交易订单号'
)
COMMENT '订单状态表-全量表-订单分区-每天更新变动数据对应订单分区'
PARTITIONED BY 
(
    order_date     INT COMMENT '订单日期'
)
STORED AS ORC
;

INSERT INTO ods_myuu_uu_ss_order_df PARTITION(order_date)
SELECT id
    ,member
    ,ordernum
    ,certnum
    ,remotenum
    ,lid
    ,tid
    ,pid
    ,aid
    ,tnum
    ,tprice
    ,ordername
    ,ordertel
    ,contacttel
    ,ordertime
    ,playtime
    ,begintime
    ,endtime
    ,ctime
    ,dtime
    ,`status`
    ,pay_status
    ,salerid
    ,remsg
    ,smserror
    ,paymode
    ,totalmoney
    ,ordermode
    ,onsale
    ,personid
    ,callback
    ,code
    ,unioncheck
    ,visitors
    ,pay_time
    ,order_time
    ,update_time
    ,order_month
    ,product_type
    ,apply_did
    ,sync_state
    ,trade_order_id
    ,order_date
FROM (
    select * from ods_order_201801_uu_ss_order_di where update_date = ${yesterday} union all
    select * from ods_order_201802_uu_ss_order_di where update_date = ${yesterday} union all
    select * from ods_order_201901_uu_ss_order_di where update_date = ${yesterday} union all
    select * from ods_order_201902_uu_ss_order_di where update_date = ${yesterday} union all
    select * from ods_order_202001_uu_ss_order_di where update_date = ${yesterday} union all
    select * from ods_order_202002_uu_ss_order_di where update_date = ${yesterday} union all
    select * from ods_order_202101_uu_ss_order_di where update_date = ${yesterday} union all
    select * from ods_order_202102_uu_ss_order_di where update_date = ${yesterday} union all
    select * from ods_order_202201_uu_ss_order_di where update_date = ${yesterday} union all
    select * from ods_order_202202_uu_ss_order_di where update_date = ${yesterday} union all
    select * from ods_order_202301_uu_ss_order_di where update_date = ${yesterday} union all
    select * from ods_order_202302_uu_ss_order_di where update_date = ${yesterday} union all
    select * from ods_order_202401_uu_ss_order_di where update_date = ${yesterday} union all
    select * from ods_order_202402_uu_ss_order_di where update_date = ${yesterday} union all
    select * from ods_order_202501_uu_ss_order_di where update_date = ${yesterday} union all
    select * from ods_order_202502_uu_ss_order_di where update_date = ${yesterday} union all
    select * from ods_myuu_uu_ss_order_di where update_date = ${yesterday}
);


-- 分区去重取最新
INSERT OVERWRITE ods_myuu_uu_ss_order_df PARTITION(order_date)
SELECT id
    ,member
    ,ordernum
    ,certnum
    ,remotenum
    ,lid
    ,tid
    ,pid
    ,aid
    ,tnum
    ,tprice
    ,ordername
    ,ordertel
    ,contacttel
    ,ordertime
    ,playtime
    ,begintime
    ,endtime
    ,ctime
    ,dtime
    ,`status`
    ,pay_status
    ,salerid
    ,remsg
    ,smserror
    ,paymode
    ,totalmoney
    ,ordermode
    ,onsale
    ,personid
    ,callback
    ,code
    ,unioncheck
    ,visitors
    ,pay_time
    ,order_time
    ,update_time
    ,order_month
    ,product_type
    ,apply_did
    ,sync_state
    ,trade_order_id
    ,order_date
FROM (
    SELECT /*+ BROADCAST(t2) */
        t1.id
        ,t1.member
        ,t1.ordernum
        ,t1.certnum
        ,t1.remotenum
        ,t1.lid
        ,t1.tid
        ,t1.pid
        ,t1.aid
        ,t1.tnum
        ,t1.tprice
        ,t1.ordername
        ,t1.ordertel
        ,t1.contacttel
        ,t1.ordertime
        ,t1.playtime
        ,t1.begintime
        ,t1.endtime
        ,t1.ctime
        ,t1.dtime
        ,t1.`status`
        ,t1.pay_status
        ,t1.salerid
        ,t1.remsg
        ,t1.smserror
        ,t1.paymode
        ,t1.totalmoney
        ,t1.ordermode
        ,t1.onsale
        ,t1.personid
        ,t1.callback
        ,t1.code
        ,t1.unioncheck
        ,t1.visitors
        ,t1.pay_time
        ,t1.order_time
        ,t1.update_time
        ,t1.order_month
        ,t1.product_type
        ,t1.apply_did
        ,t1.sync_state
        ,t1.trade_order_id
        ,t1.order_date
        ,ROW_NUMBER() OVER(PARTITION BY t1.ordernum ORDER BY t1.update_time DESC ) AS num
    FROM ods_myuu_uu_ss_order_df t1
    INNER JOIN 
    (
        SELECT order_date
        FROM (
            --新增+更新数据对应分区
            select order_date from ods_order_201801_uu_ss_order_di where update_date = ${yesterday} union all
            select order_date from ods_order_201802_uu_ss_order_di where update_date = ${yesterday} union all
            select order_date from ods_order_201901_uu_ss_order_di where update_date = ${yesterday} union all
            select order_date from ods_order_201902_uu_ss_order_di where update_date = ${yesterday} union all
            select order_date from ods_order_202001_uu_ss_order_di where update_date = ${yesterday} union all
            select order_date from ods_order_202002_uu_ss_order_di where update_date = ${yesterday} union all
            select order_date from ods_order_202101_uu_ss_order_di where update_date = ${yesterday} union all
            select order_date from ods_order_202102_uu_ss_order_di where update_date = ${yesterday} union all
            select order_date from ods_order_202201_uu_ss_order_di where update_date = ${yesterday} union all
            select order_date from ods_order_202202_uu_ss_order_di where update_date = ${yesterday} union all
            select order_date from ods_order_202301_uu_ss_order_di where update_date = ${yesterday} union all
            select order_date from ods_order_202302_uu_ss_order_di where update_date = ${yesterday} union all
            select order_date from ods_order_202401_uu_ss_order_di where update_date = ${yesterday} union all
            select order_date from ods_order_202402_uu_ss_order_di where update_date = ${yesterday} union all
            select order_date from ods_order_202501_uu_ss_order_di where update_date = ${yesterday} union all
            select order_date from ods_order_202502_uu_ss_order_di where update_date = ${yesterday} union all
            select order_date from ods_myuu_uu_ss_order_di where update_date = ${yesterday}
        )
        GROUP BY order_date
    ) t2
    ON t1.order_date = t2.order_date
)
WHERE num = 1
;



--增量数据分区更新
INSERT OVERWRITE TABLE dim_src_table_increment_info_di PARTITION(table_name,update_date)
SELECT 
    'order_date' AS date_type
    ,order_date AS date_value
    ,'ods' AS table_type
    ,'ods_myuu_uu_ss_order_df' AS table_name
    ,${yesterday} AS update_date
FROM (
    --新增+更新数据对应分区
    select order_date from ods_order_201801_uu_ss_order_di where update_date = ${yesterday} union all
    select order_date from ods_order_201802_uu_ss_order_di where update_date = ${yesterday} union all
    select order_date from ods_order_201901_uu_ss_order_di where update_date = ${yesterday} union all
    select order_date from ods_order_201902_uu_ss_order_di where update_date = ${yesterday} union all
    select order_date from ods_order_202001_uu_ss_order_di where update_date = ${yesterday} union all
    select order_date from ods_order_202002_uu_ss_order_di where update_date = ${yesterday} union all
    select order_date from ods_order_202101_uu_ss_order_di where update_date = ${yesterday} union all
    select order_date from ods_order_202102_uu_ss_order_di where update_date = ${yesterday} union all
    select order_date from ods_order_202201_uu_ss_order_di where update_date = ${yesterday} union all
    select order_date from ods_order_202202_uu_ss_order_di where update_date = ${yesterday} union all
    select order_date from ods_order_202301_uu_ss_order_di where update_date = ${yesterday} union all
    select order_date from ods_order_202302_uu_ss_order_di where update_date = ${yesterday} union all
    select order_date from ods_order_202401_uu_ss_order_di where update_date = ${yesterday} union all
    select order_date from ods_order_202402_uu_ss_order_di where update_date = ${yesterday} union all
    select order_date from ods_order_202501_uu_ss_order_di where update_date = ${yesterday} union all
    select order_date from ods_order_202502_uu_ss_order_di where update_date = ${yesterday} union all
    select order_date from ods_myuu_uu_ss_order_di where update_date = ${yesterday}
)
GROUP BY order_date
;



