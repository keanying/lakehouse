--Serverless Spark SQL
--********************************************************************--
--author: 韩瑞
--create time: 2026-07-28 14:53:08
--Serverless Spark SQL任务只能运行在独享资源组上
--********************************************************************--

-- CREATE TABLE IF NOT EXISTS ods_myuu_uu_order_apply_info_di
-- (
--     id             BIGINT COMMENT '表ID'
--     ,orderid       STRING COMMENT '订单号'
--     ,apply_id      INT COMMENT '顶级供应商ID'
--     ,aprice        BIGINT COMMENT '供应价'
--     ,lprice        BIGINT COMMENT '零售价表'
--     ,counter_price BIGINT COMMENT '下单时的门市价'
--     ,sale_price    INT COMMENT '实际售价'
--     ,pid           INT COMMENT '产品ID'
--     ,refund_num    BIGINT COMMENT '退票数'
--     ,verified_num  BIGINT COMMENT '已验证票数'
--     ,origin_num    BIGINT COMMENT '原始票数'
--     ,playtime      TIMESTAMP COMMENT '游玩时间（弃用）'
--     ,addtime       STRING COMMENT '添加时间'
--     ,flag          INT COMMENT '处理标识：1=已经处理，0=没有'
--     ,current_num   SMALLINT COMMENT '记录当前总的票数'
--     ,order_time    INT COMMENT '逻辑下单时间'
--     ,update_time   INT COMMENT '订单更新时间'
--     ,order_month   INT COMMENT '逻辑下单月份'
--     ,sync_state    INT COMMENT '是否同步标示 1:同步,0:无需同步'
--     ,can_take      SMALLINT COMMENT '可取票数'
--     ,can_refund    SMALLINT COMMENT '可退票数'
--     ,order_date    INT COMMENT '订单日期yyyyMMdd'
-- )
-- COMMENT '订单原始数据表-全量表每日更新变化数据对应订单日期'
-- PARTITIONED BY 
-- (
--     update_date      INT COMMENT '更新日期yyyyMMdd'
-- )
-- STORED AS ORC
-- ;

INSERT INTO ods_myuu_uu_order_apply_info_f PARTITION(order_date)
select  id
    ,orderid
    ,apply_id
    ,aprice
    ,lprice
    ,counter_price
    ,sale_price
    ,pid
    ,refund_num
    ,verified_num
    ,origin_num
    ,playtime
    ,addtime
    ,flag
    ,current_num
    ,order_time
    ,update_time
    ,order_month
    ,sync_state
    ,can_take
    ,can_refund
    ,order_date
FROM ods_myuu_uu_order_apply_info_di 
where update_date = ${yesterday}
;



--去重更新
INSERT OVERWRITE TABLE ods_myuu_uu_order_apply_info_f PARTITION(order_date)
SELECT id
    ,orderid
    ,apply_id
    ,aprice
    ,lprice
    ,counter_price
    ,sale_price
    ,pid
    ,refund_num
    ,verified_num
    ,origin_num
    ,playtime
    ,addtime
    ,flag
    ,current_num
    ,order_time
    ,update_time
    ,order_month
    ,sync_state
    ,can_take
    ,can_refund
    ,order_date
FROM (
    select  /*+ BROADCAST(t2) */
        t1.id
        ,t1.orderid
        ,t1.apply_id
        ,t1.aprice
        ,t1.lprice
        ,t1.counter_price
        ,t1.sale_price
        ,t1.pid
        ,t1.refund_num
        ,t1.verified_num
        ,t1.origin_num
        ,t1.playtime
        ,t1.addtime
        ,t1.flag
        ,t1.current_num
        ,t1.order_time
        ,t1.update_time
        ,t1.order_month
        ,t1.sync_state
        ,t1.can_take
        ,t1.can_refund
        ,t1.order_date
        ,ROW_NUMBER() OVER(PARTITION BY t1.order_date,t1.orderid ORDER BY t1.update_time DESC) AS num
    FROM ods_myuu_uu_order_apply_info_f t1
    INNER JOIN (
        SELECT order_date
        FROM ods_myuu_uu_order_apply_info_di 
        where update_date = ${yesterday}
        GROUP BY order_date
    ) t2
    ON t1.order_date = t2.order_date
)
WHERE num = 1
;

--增量数据分区更新
INSERT OVERWRITE TABLE dim_src_table_increment_info_di PARTITION(table_name,update_date)
SELECT 
    'order_date' AS date_type
    ,order_date AS date_value
    ,'ods' AS table_type
    ,'ods_myuu_uu_order_apply_info_f' AS table_name
    ,${yesterday} AS update_date
FROM ods_myuu_uu_order_apply_info_di 
where update_date = ${yesterday}
GROUP BY order_date
;






