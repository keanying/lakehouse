--Serverless Spark SQL
--********************************************************************--
--author: 韩瑞
--create time: 2026-08-05 20:24:53
--Serverless Spark SQL任务只能运行在独享资源组上
--********************************************************************--



-- CREATE TABLE IF NOT EXISTS ods_myuu_uu_order_tourist_info_f
-- (
    -- id             BIGINT COMMENT '自增ID'
    -- ,orderid       STRING COMMENT '订单号ID'
    -- ,tourist       STRING COMMENT '游客姓名'
    -- ,idcard        STRING COMMENT '游客身份信息'
    -- ,voucher_type  TINYINT COMMENT '身份信息类型:1=身份证,2=护照,3=军官证,4=回乡证,5=台胞证,99=其他'
    -- ,mobile        STRING COMMENT '游客手机号'
    -- ,check_state   TINYINT COMMENT '0未验证1已验证2已取消'
    -- ,idx           BIGINT COMMENT '订单序号'
    -- ,print_state   TINYINT COMMENT '打印状态0未打印1已打印'
    -- ,check_time    INT COMMENT '验证时间'
    -- ,lid           INT COMMENT '景点ID'
    -- ,chk_code      STRING COMMENT '升级过的凭证号'
    -- ,member_id     BIGINT COMMENT '游客ID'
    -- ,is_checked    TINYINT COMMENT '这个门票码是否全部验证'
    -- ,order_time    INT COMMENT '逻辑下单时间'
    -- ,update_time   INT COMMENT '订单更新时间'
    -- ,order_month   TINYINT COMMENT '逻辑下单月份'
    -- ,apply_did     INT COMMENT '原始供应商ID'
    -- ,sync_state    TINYINT COMMENT '是否同步标示 1:同步,0:无需同步'
    -- ,mobile_area   STRING COMMENT '手机区号'
    -- ,mobile_region STRING COMMENT '手机区号的区域代码'
-- )
-- COMMENT '游客身份证等信息表,myuu库表全量表,订单日期分区'
-- PARTITIONED BY 
-- (
--     order_date    INT COMMENT '逻辑下单日期'
-- )
-- stored as orc
-- ;



INSERT INTO ods_myuu_uu_order_tourist_info_f PARTITION(order_date)
select  
    id            
    ,orderid      
    ,tourist      
    ,idcard       
    ,voucher_type 
    ,mobile       
    ,check_state  
    ,idx          
    ,print_state  
    ,check_time   
    ,lid          
    ,chk_code     
    ,member_id    
    ,is_checked   
    ,order_time   
    ,update_time  
    ,order_month  
    ,apply_did    
    ,sync_state   
    ,mobile_area  
    ,mobile_region        
    ,order_date
FROM ods_myuu_uu_order_tourist_info_di 
where update_date = ${yesterday}
;



--去重更新
INSERT OVERWRITE TABLE ods_myuu_uu_order_tourist_info_f PARTITION(order_date)
SELECT 
    id            
    ,orderid      
    ,tourist      
    ,idcard       
    ,voucher_type 
    ,mobile       
    ,check_state  
    ,idx          
    ,print_state  
    ,check_time   
    ,lid          
    ,chk_code     
    ,member_id    
    ,is_checked   
    ,order_time   
    ,update_time  
    ,order_month  
    ,apply_did    
    ,sync_state   
    ,mobile_area  
    ,mobile_region        
    ,order_date
FROM (
    select  /*+ BROADCAST(t2) */
        t1.id            
        ,t1.orderid      
        ,t1.tourist      
        ,t1.idcard       
        ,t1.voucher_type 
        ,t1.mobile       
        ,t1.check_state  
        ,t1.idx          
        ,t1.print_state  
        ,t1.check_time   
        ,t1.lid          
        ,t1.chk_code     
        ,t1.member_id    
        ,t1.is_checked   
        ,t1.order_time   
        ,t1.update_time  
        ,t1.order_month  
        ,t1.apply_did    
        ,t1.sync_state   
        ,t1.mobile_area  
        ,t1.mobile_region        
        ,t1.order_date
        ,ROW_NUMBER() OVER(PARTITION BY t1.order_date,t1.orderid,t1.idx ORDER BY t1.update_time DESC) AS num
    FROM ods_myuu_uu_order_tourist_info_f t1
    INNER JOIN (
        SELECT DISTINCT order_date
        FROM ods_myuu_uu_order_tourist_info_di 
        where update_date = ${yesterday}
    ) t2
    ON t1.order_date = t2.order_date
)
WHERE num = 1
;

INSERT OVERWRITE TABLE dim_src_table_increment_info_di PARTITION(table_name,update_date)
SELECT 
    'order_date' AS date_type
    ,order_date AS date_value
    ,'ods' AS table_type
    ,'ods_myuu_uu_order_tourist_info_f' AS table_name
    ,${yesterday} AS update_date
FROM ods_myuu_uu_order_tourist_info_di 
where update_date = ${yesterday}
GROUP BY order_date
;


