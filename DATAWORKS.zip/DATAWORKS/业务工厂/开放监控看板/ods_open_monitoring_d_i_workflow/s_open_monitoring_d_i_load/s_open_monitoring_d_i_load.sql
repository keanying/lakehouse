CREATE TABLE IF NOT EXISTS s_open_monitoring_d_i(
    `content` string COMMENT'日志内容'
 )comment'开放平台ssl日志表'partitioned by(
    pt INT
 )stored as orc 
;

LOAD DATA INPATH '/w-0c7e263fd09ee50f/spark-warehouse/etl/s_open_monitoring_d_i/${ds}' 
OVERWRITE INTO TABLE s_open_monitoring_d_i partition(pt='${ds}');