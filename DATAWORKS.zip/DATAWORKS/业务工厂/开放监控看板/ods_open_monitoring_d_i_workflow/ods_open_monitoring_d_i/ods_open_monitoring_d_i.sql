CREATE TABLE IF NOT EXISTS ods_open_monitoring_d_i(
    `source` string COMMENT'来源, up：上游,down：下游',
    `business` string COMMENT'业务 create:下单 pay:支付 cancelReq:退票请求 ticket:出票通知 verify:核销通知 cancel:退票结果通知',
    `event` string COMMENT'事件类型 success：成功 fail：业务失败 error：接口失败',
    `systemId` int COMMENT'系统商ID, 下游：分销商户id 上游：pft_con_sys表id',
    `systemName` string COMMENT'系统名称, 下游：分销商户名称 上游：pft_con_sys表name',
    `systemTag` string COMMENT'系统标签, 把同一类系统组合起来, 进队列消息不用填',
    `remark` string COMMENT'备注',
    `pftOrderNo` string COMMENT'票付通订单号',
    `thirdOrderNo` string COMMENT'三方订单号',
    `quantity` int COMMENT'票数量',
    `sid` int COMMENT'供应商id',
    `tid` int COMMENT'票id ',
    `time` string COMMENT'日期时间'
 )comment'开放平台ssl日志表'partitioned by(
    pt INT
 )stored as orc 
;

INSERT INTO ods_open_monitoring_d_i
SELECT 
   `source`, 
   `business`, 
   `event`, 
   CAST(`systemId` AS INT), 
   `systemName`, 
   `systemTag`,
   `remark`, 
   `pftOrderNo`,  
   `thirdOrderNo`, 
   CAST(`quantity` AS INT), 
   CAST(`sid` AS INT), 
   CAST(`tid` AS INT), 
   `time`,
   `pt`
FROM(
   SELECT 
   json_tuple(
      content,
      'source', 'business', 'event', 'systemId', 'systemName', 'systemTag',
      'remark', 'pftOrderNo',  'thirdOrderNo', 'quantity', 'sid', 'tid', 'time'
   ) AS (
      `source`, `business`, `event`, `systemId`, `systemName`, `systemTag`,
      `remark`, `pftOrderNo`,  `thirdOrderNo`, `quantity`, `sid`, `tid`, `time`
   ),
   pt
   FROM s_open_monitoring_d_i
   WHERE pt=${ds}
) tmp;