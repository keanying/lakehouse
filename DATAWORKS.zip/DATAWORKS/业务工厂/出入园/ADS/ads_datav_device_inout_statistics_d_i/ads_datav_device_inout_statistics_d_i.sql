--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-05 15:33:33
--EMR任务只能运行在独享资源组上
--********************************************************************--


CREATE TABLE IF NOT EXISTS ads_datav_device_inout_statistics_d_i (
    `node_id`     INT     COMMENT '所属节点ID',
    `sid`         INT     COMMENT '供应商id',
    `land_id`     INT     COMMENT '景区id',
    `date`        DATE    COMMENT '时间',
    `hour`        INT     COMMENT '小时',
    `year`        INT     COMMENT '年',
    `month`       INT     COMMENT '年+月',
    `week`        INT     COMMENT 'ISOweek',
    `quarter`     INT     COMMENT '年+季节',
    `based_on_order` INT  COMMENT '订单验证为1, 非订单验证为0',
    `in`          INT     COMMENT '入园人数',
    `out`         INT     COMMENT '出园人数'
) COMMENT '出入园人数统计表' PARTITIONED BY (
    pt STRING
)STORED AS ORC;

INSERT OVERWRITE TABLE ads_datav_device_inout_statistics_d_i PARTITION (pt="${ds}")
--订单验证数据
SELECT 
    `node_id`                           AS `node_id`,
    `sid`                               AS `sid`,
    `land_id`                           AS `land_id`,
    DATE(from_unixtime(unix_timestamp(`create_day`,'yyyymmdd'),'yyyy-mm-dd'))                       
                                        AS `date`,
    `hour`                              AS `hour`,
    `year`                              AS `year`,
    `year` * 100 + `month`              AS `month`,
    `week`                              AS `week`,
    `year` * 100 + `quarter`            AS `quarter`,
    1                                   AS `based_on_order`,
    sum(if(roll_type = 0, num, 0) ) AS `in`,
    sum(if(roll_type = 1, num, 0) ) AS `out` 
FROM 
    ods_pft_device_inout_journal_d_i
WHERE 
    pt='${ds}'
AND 
    tid!=0
GROUP BY
    `node_id`,
    `sid`,
    `land_id`,
    `create_day`,
    `hour`,
    `year`,
    `month`,
    `week`,
    `quarter`
    
UNION ALL 

--非订单验证数据
SELECT 
    `node_id`                 AS `node_id`,
    `sid`                     AS `sid`,
    `land_id`                 AS `land_id`,
    DATE(from_unixtime(unix_timestamp(`create_day`,'yyyymmdd'),'yyyy-mm-dd'))                        
                              AS `date`,
    `hour`                    AS `hour`,
    `year`                    AS `year`,
    `year` * 100 + `month`    AS `month`,
    `week`                    AS `week`,
    `year` * 100 + `quarter`  AS `quarter`,
    0                         AS `based_on_order`,
    sum(if(roll_type =0, num, 0) ) AS `in`,
    sum(if(roll_type =1, num, 0) ) AS `out` 
FROM 
    ods_pft_device_inout_journal_d_i
WHERE
    pt='${ds}'
AND 
    tid=0
GROUP BY
    `node_id`,
    `sid`,
    `land_id`,
    `create_day`,
    `hour`,
    `year`,
    `month`,
    `week`,
    `quarter`


