--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-05 15:57:23
--EMR任务只能运行在独享资源组上
--********************************************************************--
-- desc 门票验证数据统计表

CREATE TABLE if not EXISTS `ads_datav_device_ticket_verification_d_i` (
  `node_id`     INT     COMMENT '所属节点ID',
  `sid`         INT     COMMENT '供应商id',
  `land_id`     INT     COMMENT '景区id',
  `date`        DATE    COMMENT '时间',
  `year`        INT     COMMENT '年',
  `month`       INT     COMMENT '年+月',
  `week`        INT     COMMENT 'ISOweek',
  `quarter`     INT     COMMENT '年+季节',
  `tid`         INT     COMMENT '门票id',
  `in`          INT     COMMENT '入园人数',
  `out`         INT     COMMENT '出院人数'
) COMMENT '验证数据统计表' PARTITIONED BY (
    pt STRING
)STORED AS ORC;

INSERT OVERWRITE TABLE ads_datav_device_ticket_verification_d_i PARTITION (pt="${ds}")
SELECT 
  `node_id`                     AS `node_id`,
  `sid`                         AS `sid`,
  `land_id`                     AS `land_id`,
  DATE(from_unixtime(unix_timestamp(`create_day`,'yyyymmdd'),'yyyy-mm-dd'))                       
                                AS `date`,
  `year`                        AS `year`,
  `month`                       AS `month`,
  `week`                        AS `week`,
  `quarter`                     AS `quarter`,
  `tid`                         AS `tid`,
  sum(if(roll_type=0, num, 0 )) AS `in`,
  sum(if(roll_type=1, num, 0 )) AS `out` 
FROM 
  ods_pft_device_inout_journal_d_i
WHERE
  pt='${ds}' 
AND
  tid != 0
GROUP BY
  `node_id`,
  `sid`,
  `land_id`,
  `create_day`,
  `year`,
  `month`,
  `week`,
  `quarter`,
  `tid`