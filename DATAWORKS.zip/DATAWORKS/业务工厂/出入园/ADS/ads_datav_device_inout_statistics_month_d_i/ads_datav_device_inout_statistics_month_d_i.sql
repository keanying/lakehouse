--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-05 19:18:37
--EMR任务只能运行在独享资源组上
--********************************************************************--

CREATE TABLE IF NOT EXISTS ads_datav_device_inout_statistics_month_d_i (
  `node_id`        INT COMMENT '所属节点ID',
  `sid`            INT COMMENT '供应商id',
  `land_id`        INT COMMENT '景区id',
  `year`           INT COMMENT '年',
  `month`          INT COMMENT '年+月',
  `quarter`        INT COMMENT '年+季节',
  `based_on_order` INT COMMENT '订单验证为1, 非订单验证为0',
  `in`             INT COMMENT '入园人数',
  `out`            INT COMMENT '出院人数'
) COMMENT '出入园人数统计表,月底汇总'PARTITIONED BY(
    pt STRING
)STORED AS orc;


INSERT OVERWRITE TABLE ads_datav_device_inout_statistics_month_d_i PARTITION (pt='${ds}')
SELECT 
  `node_id`                           AS `node_id`,
  `sid`                               AS `sid`,
  `land_id`                           AS `land_id`,
  `year`                              AS `year`,
  `month`                             AS `month`,
  `quarter`                           AS `quarter`,
  1                                   AS `based_on_order`,
  sum(`in`)                           AS `in`, 
  sum(`out`)                          AS `out` 
FROM 
  ads_datav_device_inout_statistics_d_i
WHERE 
  `based_on_order`=1
AND
  `month` = 
    year(date_sub(from_unixtime(unix_timestamp(),'yyyy-MM-dd'),1)) * 100 +
    month(date_sub(from_unixtime(unix_timestamp(),'yyyy-MM-dd'),1))
GROUP BY 
  `node_id`,
  `sid`,
  `land_id`,
  `year`,
  `month`,
  `quarter`
UNION 
SELECT 
  `node_id`                           AS `node_id`,
  `sid`                               AS `sid`,
  `land_id`                           AS `land_id`,
  `year`                              AS `year`,
  `month`                             AS `month`,
  `quarter`                           AS `quarter`,
  0                                   AS `based_on_order`,
  sum(`in`)                           AS `in`, 
  sum(`out`)                          AS `out` 
FROM 
  ads_datav_device_inout_statistics_d_i
WHERE 
  `based_on_order`=0
AND
  `month` = 
    year(date_sub(from_unixtime(unix_timestamp(),'yyyy-MM-dd'),1)) * 100 +
    month(date_sub(from_unixtime(unix_timestamp(),'yyyy-MM-dd'),1))
GROUP BY 
  `node_id`,
  `sid`,
  `land_id`,
  `year`,
  `month`,
  `quarter`

