--@exclude_input=5678184977368740211
--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-04 15:29:28
--EMR任务只能运行在独享资源组上
--********************************************************************--
-- desc 设备出入园详细记录表 

CREATE TABLE IF NOT EXISTS ods_pft_device_inout_journal_d_i (
  `id`          INT     COMMENT 'id',
  `sid`         INT     COMMENT '供应商id',
  `land_id`     INT     COMMENT '景区id',
  `site_id`     INT     COMMENT '站点id（预留）',
  `tid`         INT     COMMENT '门票id，订单验证入园的会门票ID;无法记录到门票的为数据为0',
  `num`         INT     COMMENT '单次出入园数量',
  `device_key`  STRING  COMMENT '设备特征码',
  `roll_type`   INT     COMMENT '类型：0 入园 1 离园',
  `create_day`  STRING  COMMENT '年月日',
  `create_time` INT     COMMENT '创建时间',
  `node_id`     INT     COMMENT '所属节点ID',
  `hour`        INT     COMMENT '小时',
  `year`        INT     COMMENT '年',
  `month`       INT     COMMENT '月',
  `week`        INT     COMMENT 'ISOWeek',
  `quarter`     INT     COMMENT '年+季度'
) COMMENT '设备出入园详细记录表' PARTITIONED BY (
    pt STRING
)STORED AS ORC;


INSERT OVERWRITE TABLE ods_pft_device_inout_journal_d_i PARTITION (pt='${ds}')
SELECT 
  `id`                                      AS `id`,
  `sid`                                     AS `sid`,
  `land_id`                                 AS `land_id`,
  `site_id`                                 AS `site_id`,
  `tid`                                     AS `tid`,
  `num`                                     AS `num`,
  `device_key`                              AS `device_key`,
  `roll_type`                               AS `roll_type`,
  FROM_UNIXTIME(`create_time`, 'yyyyMMdd')  AS `create_day`,
  `create_time`                             AS `create_time`,
  `node_id`                                 AS `node_id`,
  hour(from_unixtime(`create_time`))        AS `hour`,
  year(from_unixtime(`create_time`))        AS `year`,
  month(from_unixtime(`create_time`))       AS `month`,
  weekofyear(from_unixtime(`create_time`)) AS `week`,
  quarter(from_unixtime(`create_time`))     AS `quarter`
FROM
  s_pft_device_inout_journal_d_i
WHERE 
  pt='${ds}';