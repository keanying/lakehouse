-- name dws_hourly_report_terminal_pass_full_d_i
-- type Spark SQL
-- author wanghaiyang@12301.cc
-- create time 2024-11-19 16:20:42
-- desc 终端过闸全维度按小时汇总数据

SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;

CREATE TABLE IF NOT EXISTS `dws_hourly_report_terminal_pass_full_d_i` (
    `date_hour`             INT         COMMENT '小时段2016012301',
    `sid`                   INT         COMMENT '用户ID',
    `lid`                   INT         COMMENT '景区ID',
    `tid`                   INT         COMMENT '门票ID',
    `p_type`                STRING      COMMENT '景区类型：A景区B线路C酒店F套票G餐饮H演出I年卡J特产K计时产品Q旅游券',
    `pid`                   INT         COMMENT '产品SPUID',
    `site_id`               INT         COMMENT '站点ID',
    `lvl`                   INT         COMMENT '分销链层级',
    `operate_id`            INT         COMMENT '操作人员ID',
    `reseller_id`           INT         COMMENT '分销商ID',
    `card_type`             INT         COMMENT '卡类型，1=员工卡，2=市民卡，3=年卡，4=一卡通',
    `card_pid`              INT         COMMENT '卡明细（目前只有年卡有，就是具体的卡套餐）',
    `channel`               INT         COMMENT '销售渠道',
    `terminal_type`         INT         COMMENT '终端类型，云票务、手持机、MINI检票机、闸机、PC平台、小程序',
    `verify_num`            BIGINT      COMMENT '验证订单数',
    `verify_ticket`         BIGINT      COMMENT '验证门票数',
    `verify_cost_money`     BIGINT      COMMENT '验证花费金额',
    `verify_sale_money`     BIGINT      COMMENT '验证金额'
) 
COMMENT '终端过闸全维度按小时汇总数据'
PARTITIONED BY (`date` INT COMMENT '日期例如20171010')
STORED AS ORC;


INSERT OVERWRITE TABLE dws_hourly_report_terminal_pass_full_d_i PARTITION(`date`)
SELECT 
    `date_hour`,
    `sid`,
    `lid`,
    `tid`,
    NVL(`p_type`, 'A')         AS `p_type`, 
    NVL(ticketTab.pid, summaryTab.pid),
    `site_id`,
    `lvl`,
    `operate_id`,
    `reseller_id`,
    `card_type`,
    `card_pid`,
    `channel`,
    `terminal_type`,
    SUM(`order_num`)            AS `verify_num`,
    SUM(`ticket_num`)           AS `verify_ticket`,
    SUM(`cost_money`)           AS `verify_cost_money`,
    SUM(`sale_money`)           AS `verify_sale_money`,
    `date`
FROM
(
    SELECT 
        `date_hour`,
        `fid`                       AS `sid`,
        `lid`,
        `tid`,
        `pid`,
        `site_id`,
        `lvl`,
        `operate_id`,
        `reseller_id`,
        `card_type`,
        `card_pid`,
        `channel`,
        `terminal_type`,
        SUM(`order_num`)            AS `order_num`,
        SUM(`ticket_num`)           AS `ticket_num`,
        SUM(`cost_money`)           AS `cost_money`,
        SUM(`sale_money`)           AS `sale_money`,
        `date`
    FROM ods_pft_report_terminal_pass_hour_d_i
    WHERE `date` =${ds}
    GROUP BY 
        `date`,
        `date_hour`,
        `fid`,
        `lid`,
        `tid`,
        `pid`,
        `site_id`,
        `lvl`,
        `operate_id`,
        `reseller_id`,
        `card_type`,
        `card_pid`,
        `channel`,
        `terminal_type`
) summaryTab
LEFT JOIN (
    SELECT id, p_type
    FROM ods_land_d_f
    WHERE pt = DATE_FORMAT(DATE_SUB(CURRENT_DATE(), 1),"yyyyMMdd")
) landTab
ON summaryTab.lid = landTab.id
LEFT JOIN (
    SELECT id, pid
    FROM ods_ticket_d_f
    WHERE pt = DATE_FORMAT(DATE_SUB(CURRENT_DATE(), 1),"yyyyMMdd")
) ticketTab
ON summaryTab.tid = ticketTab.id
GROUP BY
    `date`,
    `date_hour`,
    `sid`,
    `lid`,
    `tid`,
    NVL(`p_type`, 'A'),
    NVL(ticketTab.pid, summaryTab.pid),
    `site_id`,
    `lvl`,
    `operate_id`,
    `reseller_id`,
    `card_type`,
    `card_pid`,
    `channel`,
    `terminal_type`;
