-- name dws_hourly_terminal_pass_summary_d_i
-- type Spark SQL
-- author wanghaiyang@12301.cc
-- create time 2024-11-20 09:55:24
-- desc 

SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;
SET hive.exec.dynamic.partition.mode=nonstrict;

CREATE TABLE IF NOT EXISTS `dws_hourly_terminal_pass_summary_d_i` (
    `sid`                   INT         COMMENT '用户ID',
    `lid`                   INT         COMMENT '景区ID',
    `tid`                   INT         COMMENT '票ID',
    `p_type`                STRING      COMMENT '景区类型：A景区B线路C酒店F套票G餐饮H演出I年卡J特产K计时产品Q旅游券',
    `pid`                   INT         COMMENT '产品SPUID',
    `site_id`               INT         COMMENT '站点ID',
    `terminal_type`         INT         COMMENT '终端类型，云票务、手持机、MINI检票机、闸机、PC平台、小程序',

    `verify_ticket`         BIGINT      COMMENT '验证门票数',
    `verify_sale_money`     BIGINT      COMMENT '验证金额',

    `t0`                    BIGINT      COMMENT '0:00~0:59验证门票数',
    `t1`                    BIGINT      COMMENT '1:00~1:59验证门票数',
    `t2`                    BIGINT      COMMENT '2:00~2:59验证门票数',
    `t3`                    BIGINT      COMMENT '3:00~3:59验证门票数',
    `t4`                    BIGINT      COMMENT '4:00~4:59验证门票数',
    `t5`                    BIGINT      COMMENT '5:00~5:59验证门票数',
    `t6`                    BIGINT      COMMENT '6:00~6:59验证门票数',
    `t7`                    BIGINT      COMMENT '7:00~7:59验证门票数',
    `t8`                    BIGINT      COMMENT '8:00~8:59验证门票数',
    `t9`                    BIGINT      COMMENT '9:00~9:59验证门票数',
    `t10`                   BIGINT      COMMENT '10:00~10:59验证门票数',
    `t11`                   BIGINT      COMMENT '11:00~11:59验证门票数',
    `t12`                   BIGINT      COMMENT '12:00~12:59验证门票数',
    `t13`                   BIGINT      COMMENT '13:00~13:59验证门票数',
    `t14`                   BIGINT      COMMENT '14:00~14:59验证门票数',
    `t15`                   BIGINT      COMMENT '15:00~15:59验证门票数',
    `t16`                   BIGINT      COMMENT '16:00~16:59验证门票数',
    `t17`                   BIGINT      COMMENT '17:00~17:59验证门票数',
    `t18`                   BIGINT      COMMENT '18:00~18:59验证门票数',
    `t19`                   BIGINT      COMMENT '19:00~19:59验证门票数',
    `t20`                   BIGINT      COMMENT '20:00~20:59验证门票数',
    `t21`                   BIGINT      COMMENT '21:00~21:59验证门票数',
    `t22`                   BIGINT      COMMENT '22:00~22:59验证门票数',
    `t23`                   BIGINT      COMMENT '23:00~23:59验证门票数',

    `m0`                    BIGINT      COMMENT '0:00~0:59验证金额',
    `m1`                    BIGINT      COMMENT '1:00~1:59验证金额',
    `m2`                    BIGINT      COMMENT '2:00~2:59验证金额',
    `m3`                    BIGINT      COMMENT '3:00~3:59验证金额',
    `m4`                    BIGINT      COMMENT '4:00~4:59验证金额',
    `m5`                    BIGINT      COMMENT '5:00~5:59验证金额',
    `m6`                    BIGINT      COMMENT '6:00~6:59验证金额',
    `m7`                    BIGINT      COMMENT '7:00~7:59验证金额',
    `m8`                    BIGINT      COMMENT '8:00~8:59验证金额',
    `m9`                    BIGINT      COMMENT '9:00~9:59验证金额',
    `m10`                   BIGINT      COMMENT '10:00~10:59验证金额',
    `m11`                   BIGINT      COMMENT '11:00~11:59验证金额',
    `m12`                   BIGINT      COMMENT '12:00~12:59验证金额',
    `m13`                   BIGINT      COMMENT '13:00~13:59验证金额',
    `m14`                   BIGINT      COMMENT '14:00~14:59验证金额',
    `m15`                   BIGINT      COMMENT '15:00~15:59验证金额',
    `m16`                   BIGINT      COMMENT '16:00~16:59验证金额',
    `m17`                   BIGINT      COMMENT '17:00~17:59验证金额',
    `m18`                   BIGINT      COMMENT '18:00~18:59验证金额',
    `m19`                   BIGINT      COMMENT '19:00~19:59验证金额',
    `m20`                   BIGINT      COMMENT '20:00~20:59验证金额',
    `m21`                   BIGINT      COMMENT '21:00~21:59验证金额',
    `m22`                   BIGINT      COMMENT '22:00~22:59验证金额',
    `m23`                   BIGINT      COMMENT '23:00~23:59验证金额'
) 
COMMENT '每日终端过闸汇总数据'
PARTITIONED BY (`date` INT COMMENT '日期例如20171010');

INSERT OVERWRITE TABLE dws_hourly_terminal_pass_summary_d_i PARTITION(`date`)
SELECT 
    `sid`,
    `lid`,          
    `tid`,       
    `p_type`,
    `pid`,
    `site_id`,
    `terminal_type`,
    SUM(verify_ticket)                      AS verify_ticket,
    SUM(verify_sale_money)                  AS verify_sale_money,
    
    SUM(IF(hour=0, verify_ticket, 0))       AS t0,
    SUM(IF(hour=1, verify_ticket, 0))       AS t1,
    SUM(IF(hour=2, verify_ticket, 0))       AS t2,
    SUM(IF(hour=3, verify_ticket, 0))       AS t3,
    SUM(IF(hour=4, verify_ticket, 0))       AS t4,
    SUM(IF(hour=5, verify_ticket, 0))       AS t5,
    SUM(IF(hour=6, verify_ticket, 0))       AS t6,
    SUM(IF(hour=7, verify_ticket, 0))       AS t7,
    SUM(IF(hour=8, verify_ticket, 0))       AS t8,
    SUM(IF(hour=9, verify_ticket, 0))       AS t9,
    SUM(IF(hour=10, verify_ticket, 0))      AS t10,
    SUM(IF(hour=11, verify_ticket, 0))      AS t11,
    SUM(IF(hour=12, verify_ticket, 0))      AS t12,
    SUM(IF(hour=13, verify_ticket, 0))      AS t13,
    SUM(IF(hour=14, verify_ticket, 0))      AS t14,
    SUM(IF(hour=15, verify_ticket, 0))      AS t15,
    SUM(IF(hour=16, verify_ticket, 0))      AS t16,
    SUM(IF(hour=17, verify_ticket, 0))      AS t17,
    SUM(IF(hour=18, verify_ticket, 0))      AS t18,
    SUM(IF(hour=19, verify_ticket, 0))      AS t19,
    SUM(IF(hour=20, verify_ticket, 0))      AS t20,
    SUM(IF(hour=21, verify_ticket, 0))      AS t21,
    SUM(IF(hour=22, verify_ticket, 0))      AS t22,
    SUM(IF(hour=23, verify_ticket, 0))      AS t23,

    SUM(IF(hour=0, verify_sale_money, 0))   AS m0,
    SUM(IF(hour=1, verify_sale_money, 0))   AS m1,
    SUM(IF(hour=2, verify_sale_money, 0))   AS m2,
    SUM(IF(hour=3, verify_sale_money, 0))   AS m3,
    SUM(IF(hour=4, verify_sale_money, 0))   AS m4,
    SUM(IF(hour=5, verify_sale_money, 0))   AS m5,
    SUM(IF(hour=6, verify_sale_money, 0))   AS m6,
    SUM(IF(hour=7, verify_sale_money, 0))   AS m7,
    SUM(IF(hour=8, verify_sale_money, 0))   AS m8,
    SUM(IF(hour=9, verify_sale_money, 0))   AS m9,
    SUM(IF(hour=10, verify_sale_money, 0))  AS m10,
    SUM(IF(hour=11, verify_sale_money, 0))  AS m11,
    SUM(IF(hour=12, verify_sale_money, 0))  AS m12,
    SUM(IF(hour=13, verify_sale_money, 0))  AS m13,
    SUM(IF(hour=14, verify_sale_money, 0))  AS m14,
    SUM(IF(hour=15, verify_sale_money, 0))  AS m15,
    SUM(IF(hour=16, verify_sale_money, 0))  AS m16,
    SUM(IF(hour=17, verify_sale_money, 0))  AS m17,
    SUM(IF(hour=18, verify_sale_money, 0))  AS m18,
    SUM(IF(hour=19, verify_sale_money, 0))  AS m19,
    SUM(IF(hour=20, verify_sale_money, 0))  AS m20,
    SUM(IF(hour=21, verify_sale_money, 0))  AS m21,
    SUM(IF(hour=22, verify_sale_money, 0))  AS m22,
    SUM(IF(hour=23, verify_sale_money, 0))  AS m23,
    `date`
FROM(
    SELECT
        `date`,
        `sid`, 
        `lid`, 
        `tid`,                                   
        `p_type`,
        `pid`,
        `site_id`,
        `terminal_type`,
        `verify_ticket`,
        `verify_sale_money`,
        cast(substr(`date_hour`, -2) as int)  AS `hour`
    FROM dws_hourly_report_terminal_pass_full_d_i
    WHERE `date`=${ds}
)
GROUP BY 
    `date`,
    `sid`,
    `lid`,
    `tid`,
    `p_type`,
    `pid`,
    `site_id`,
    `terminal_type`
    ;