-- name dws_yearly_terminal_pass_summary_d_i
-- type Spark SQL
-- author wanghaiyang@12301.cc
-- create time 2024-11-20 09:55:24
-- desc 每年终端过闸汇总数据

CREATE TABLE IF NOT EXISTS `dws_yearly_terminal_pass_summary_d_i` (
  `sid`                   INT         COMMENT '用户ID',
    `lid`                   INT         COMMENT '景区ID',
    `tid`                   INT         COMMENT '票ID',
    `p_type`                STRING      COMMENT '景区类型：A景区B线路C酒店F套票G餐饮H演出I年卡J特产K计时产品Q旅游券',
    `pid`                   INT         COMMENT '产品SPUID',
    `site_id`               INT         COMMENT '站点ID',
    `terminal_type`         INT         COMMENT '终端类型，云票务、手持机、MINI检票机、闸机、PC平台、小程序',
    `verify_ticket`         BIGINT      COMMENT '验证门票数',
    `verify_sale_money`     BIGINT      COMMENT '验证金额'
) 
COMMENT '每年终端过闸汇总数据'
PARTITIONED BY (`year` INT COMMENT '年例如2017')
STORED AS ORC;

INSERT OVERWRITE TABLE dws_yearly_terminal_pass_summary_d_i PARTITION(year)
SELECT 
    `sid`,
    `lid`,                 
    `tid`,
    `p_type`,
    `pid`,
    `site_id`,
    `terminal_type`,
    SUM(verify_ticket)              AS verify_ticket,
    SUM(verify_sale_money)          AS verify_sale_money,
    `year`
FROM dws_monthly_terminal_pass_summary_d_i
WHERE SUBSTR(`month`, 0, 4) = SUBSTR('${ds}', 0, 4)
GROUP BY 
    `sid`,
    `lid`,                 
    `tid`,
    `p_type`,
    `pid`,
    `site_id`,
    `terminal_type`,
    `year`;