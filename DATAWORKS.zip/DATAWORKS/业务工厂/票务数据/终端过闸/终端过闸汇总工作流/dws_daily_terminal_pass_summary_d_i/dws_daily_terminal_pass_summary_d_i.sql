-- name dws_daily_terminal_pass_summary_d_i
-- type Spark SQL
-- author wanghaiyang@12301.cc
-- create time 2024-11-20 09:55:24
-- desc 

CREATE TABLE IF NOT EXISTS `dws_daily_terminal_pass_summary_d_i` (
    `sid`                   INT         COMMENT '用户ID',
    `lid`                   INT         COMMENT '景区ID',
    `tid`                   INT         COMMENT '票ID',
    `p_type`                STRING      COMMENT '景区类型：A景区B线路C酒店F套票G餐饮H演出I年卡J特产K计时产品Q旅游券',
    `pid`                   INT         COMMENT '产品SPUID',
    `site_id`               INT         COMMENT '站点ID',
    `terminal_type`         INT         COMMENT '终端类型，云票务、手持机、MINI检票机、闸机、PC平台、小程序',
    `verify_ticket`         BIGINT      COMMENT '验证门票数',
    `verify_sale_money`     BIGINT      COMMENT '验证金额',
    `year`                  INT         COMMENT'年',
    `month`                 INT         COMMENT'年月'
) 
COMMENT '每日终端过闸汇总数据'
PARTITIONED BY (`date` INT COMMENT '日期例如20171010')
STORED AS ORC;

INSERT OVERWRITE TABLE dws_daily_terminal_pass_summary_d_i PARTITION(`date`)
SELECT 
    `sid`,
    `lid`,                 
    `tid`,
    `p_type`,
    `pid`,
    `site_id`,
    `terminal_type`,
    SUM(verify_ticket)                                                              AS verify_ticket,
    SUM(verify_sale_money)                                                          AS verify_sale_money,
    YEAR(TO_DATE(`date`,'yyyyMMdd'))                                                AS `year`,
    YEAR(TO_DATE(`date`,'yyyyMMdd')) * 100 + MONTH(TO_DATE(`date`,'yyyyMMdd'))      AS `month`,
    `date`                                                                          AS `date`
FROM dws_daily_report_terminal_pass_full_d_i
WHERE `date`=${ds}
GROUP BY 
    `date`,
    `sid`,
    `lid`,                 
    `tid`,
    `p_type`,
    `pid`,
    `site_id`,
    `terminal_type`;