-- name dws_monthly_report_ticket_branch_terminal_summary_d_i
-- type Spark SQL
-- author wanghaiyang@12301.cc
-- create time 2024-08-09 18:37:04
-- desc 每月分终端门票维度汇总表

CREATE TABLE IF NOT EXISTS `dws_monthly_report_ticket_branch_terminal_summary_d_i`(
    `year` INT COMMENT'年',
    `sid` BIGINT COMMENT'用户ID',
    `terminal` BIGINT COMMENT'终端ID',
    `lid` BIGINT COMMENT'终端ID',
    `pid` BIGINT COMMENT'产品SPUID',
    `tid` BIGINT COMMENT'门票ID',
    `p_type` STRING COMMENT'景区类型：A景区B线路C酒店F套票G餐饮H演出I年卡套餐',
    `check_orders` BIGINT COMMENT'验证订单数',
    `check_tickets` BIGINT COMMENT'验证票数',
    `check_people` BIGINT COMMENT'验证人次'
 )comment'每月分终端门票维度汇总表'
 PARTITIONED BY (`month`  INT   	COMMENT '年月')
 stored as orc 
;

INSERT OVERWRITE TABLE dws_monthly_report_ticket_branch_terminal_summary_d_i PARTITION(month)
SELECT 
    year                            AS `year`, 
    sid                             AS `sid`,
    terminal                        AS `terminal`, 
    lid                             AS `lid`,
    pid                             AS `pid`, 
    tid                             AS `tid`, 
    p_type                          AS `p_type`, 
    SUM(check_orders)               AS `check_orders`, 
    SUM(check_tickets)              AS `check_tickets`, 
    SUM(check_people )              AS `check_people`,
    month
FROM dws_daily_report_ticket_branch_terminal_summary_d_i
WHERE SUBSTR(`date`, 0, 6) = SUBSTR('${ds}', 0, 6)
GROUP BY 
    sid ,
    terminal, 
    lid,
    pid, 
    tid, 
    p_type, 
    year, 
    month;