-- name dws_yearly_report_branch_terminal_summary_d_i
-- type Spark SQL
-- author wanghaiyang@12301.cc
-- create time 2024-11-11 18:37:04
-- desc 每年分终端汇总表

CREATE TABLE IF NOT EXISTS `dws_yearly_report_branch_terminal_summary_d_i`(
    `sid`           BIGINT  COMMENT'用户ID',
    `terminal`      BIGINT  COMMENT'终端ID',
    `check_orders`  BIGINT  COMMENT'验证订单数',
    `check_tickets` BIGINT  COMMENT'验证票数',
    `check_people`  BIGINT  COMMENT'验证人次'
 )comment'每年分终端汇总表'partitioned by(
    `year` INT COMMENT '年'
 )stored as orc 
;

INSERT OVERWRITE TABLE dws_yearly_report_branch_terminal_summary_d_i PARTITION(year) 
SELECT 
    `sid`,
    `terminal`, 
    SUM(check_orders)   AS  `check_orders`, 
    SUM(check_tickets)  AS  `check_tickets`, 
    SUM(check_people)   AS  `check_people`,
    `year`
FROM dws_monthly_report_branch_terminal_summary_d_i
WHERE SUBSTR(`month`, 0, 4) = SUBSTR('${ds}', 0, 4)
GROUP BY 
    `sid`,
    `terminal`, 
    `year`;