-- name dws_daily_report_branch_terminal_summary_d_i
-- type Spark SQL
-- author wanghaiyang@12301.cc
-- create time 2024-08-09 18:37:04
-- desc 每日分终端汇总表

CREATE TABLE IF NOT EXISTS `dws_daily_report_branch_terminal_summary_d_i`(
    `sid`               BIGINT  COMMENT'用户ID',
    `terminal`          BIGINT  COMMENT'终端ID',
    `year`              INT     COMMENT'年',
    `month`             INT     COMMENT'年月',
    `week`              INT     COMMENT'年周',
    `check_orders`      BIGINT  COMMENT'验证订单数',
    `check_tickets`     BIGINT  COMMENT'验证票数',
    `check_people`      BIGINT  COMMENT'验证人次'
 )comment'每日分终端汇总表'partitioned by(
    `date` INT
 )stored as orc 
;

INSERT OVERWRITE TABLE dws_daily_report_branch_terminal_summary_d_i PARTITION(`date`) 
SELECT 
    `sid`,
    `terminal`, 
    `year`, 
    `month`,
    `week`, 
    SUM(check_orders)   AS  `check_orders`, 
    SUM(check_tickets)  AS  `check_tickets`, 
    SUM(check_people)   AS  `check_people`,
    `date`
FROM dws_daily_report_ticket_branch_terminal_summary_d_i
WHERE `date`='${ds}'
GROUP BY 
    `sid`,
    `terminal`, 
    `year`, 
    `month`,
    `week`,
    `date`;