-- name dws_daily_report_ticket_branch_terminal_summary_d_i
-- type Spark SQL
-- author wanghaiyang@12301.cc
-- create time 2024-08-09 18:37:04
-- desc 每日分终端门票维度汇总表

CREATE TABLE IF NOT EXISTS `dws_daily_report_ticket_branch_terminal_summary_d_i`(
    `sid` BIGINT COMMENT'用户ID',
    `terminal` BIGINT COMMENT'终端ID',
    `lid` BIGINT COMMENT'终端ID',
    `pid` BIGINT COMMENT'产品SPUID',
    `tid` BIGINT COMMENT'门票ID',
    `p_type` STRING COMMENT'景区类型：A景区B线路C酒店F套票G餐饮H演出I年卡套餐',
    `year` INT COMMENT'年',
    `month` INT COMMENT'年月',
    `week` INT COMMENT'年周',
    `check_orders` BIGINT COMMENT'验证订单数',
    `check_tickets` BIGINT COMMENT'验证票数',
    `check_people` BIGINT COMMENT'验证人次'
 )comment'每日分终端门票维度汇总表'partitioned by(
    `date` INT
 )stored as orc 
 ;

INSERT OVERWRITE TABLE dws_daily_report_ticket_branch_terminal_summary_d_i PARTITION(date) 
SELECT 
    terminalTab.sid                                         AS `sid`,
    terminalTab.terminal                                    AS `terminal`, 
    terminalTab.lid                                         AS `lid`,
    ticketTab.pid                                           AS `pid`, 
    terminalTab.tid                                         AS `tid`, 
    landTab.p_type                                          AS `p_type`, 
    YEAR(dim_isoweek.date)                                  AS `year`, 
    YEAR(dim_isoweek.date) * 100 + MONTH(dim_isoweek.date)  AS `month`,
    CAST(dim_isoweek.isoweek AS INT)                        AS `week`, 
    terminalTab.check_orders                                AS `check_orders`, 
    terminalTab.check_tickets                               AS `check_tickets`, 
    terminalTab.check_people                                AS `check_people`,
    INT(terminalTab.`fulldate`)
FROM (
    SELECT 
        fid                     AS  sid, 
        lid                     AS  lid,
        tid                     AS  tid,
        terminal                AS  terminal, 
        date                    AS  fulldate, 
        SUM(check_orders)       AS  check_orders, 
        SUM(check_tickets)      AS  check_tickets, 
        SUM(check_people)       AS  check_people
    FROM ods_terminal_branch_summary_d_i 
    WHERE date = ${ds}
    GROUP BY  
        fid, 
        lid,
        tid, 
        terminal,
        date
) terminalTab
LEFT JOIN (
    SELECT id, pid
    FROM ods_ticket_d_f
    WHERE pt = DATE_FORMAT(DATE_SUB(CURRENT_DATE(), 1),"yyyyMMdd")
) ticketTab
ON terminalTab.tid = ticketTab.id
LEFT JOIN(
    SELECT id, p_type
    FROM ods_land_d_f
    WHERE pt = DATE_FORMAT(DATE_SUB(CURRENT_DATE(), 1),"yyyyMMdd")
) landTab
ON terminalTab.lid = landTab.id
LEFT JOIN dim_date_isoweek_o_f AS dim_isoweek 
ON terminalTab.`fulldate` = dim_isoweek.`fulldate`;