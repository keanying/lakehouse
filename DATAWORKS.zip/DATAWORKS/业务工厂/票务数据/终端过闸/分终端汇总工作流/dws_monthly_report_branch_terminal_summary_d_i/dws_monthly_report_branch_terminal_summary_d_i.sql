-- name dws_monthly_report_branch_terminal_summary_d_i
-- type Spark SQL
-- author wanghaiyang@12301.cc
-- create time 2024-11-11 18:37:04
-- desc 每月分终端汇总表

CREATE TABLE IF NOT EXISTS `dws_monthly_report_branch_terminal_summary_d_i`(
    `sid`               BIGINT  COMMENT'用户ID',
    `terminal`          BIGINT  COMMENT'终端ID',
    `year`              INT     COMMENT'年',
    `check_orders`      BIGINT  COMMENT'验证订单数',
    `check_tickets`     BIGINT  COMMENT'验证票数',
    `check_people`      BIGINT  COMMENT'验证人次'
 )comment'每月分终端汇总表'partitioned by(
    `month`             BIGINT  COMMENT '年月'
 )stored as orc 
;

INSERT OVERWRITE TABLE dws_monthly_report_branch_terminal_summary_d_i PARTITION(month)
SELECT 
    `sid`,
    `terminal`, 
    `year`, 
    SUM(check_orders)   AS  `check_orders`, 
    SUM(check_tickets)  AS  `check_tickets`, 
    SUM(check_people)   AS  `check_people`,
    `month`
FROM dws_monthly_report_ticket_branch_terminal_summary_d_i
WHERE `month` = SUBSTR('${ds}', 0, 6)
GROUP BY 
    `sid`,
    `terminal`, 
    `year`, 
    `month`;