-- name dim_input_group_gate_d_f
-- type Spark SQL
-- author wanghaiyang@12301.cc
-- create time 2024-11-26 17:19:25
-- desc 景区统计组闸机维表

CREATE TABLE IF NOT EXISTS `dim_input_group_gate_d_f` (
  `gid`      INT     COMMENT '统计组ID',
  `sid`      INT     COMMENT '景区ID',
  `gate`     STRING  COMMENT '闸机key值'
) 
COMMENT '景区统计组闸机维表'
PARTITIONED BY (`pt` INT COMMENT '业务日期')
STORED AS ORC;


INSERT OVERWRITE TABLE dim_input_group_gate_d_f PARTITION(`pt`='${ds}')
SELECT 
  id                                                        AS    gid, 
  sid                                                       AS    sid, 
  explode(split(substr(gates, 3, length(gates)-4),'", "'))  AS    gate
FROM ods_scenic_inout_summary_group_d_f
WHERE pt = '${ds}' AND delete_at is null;