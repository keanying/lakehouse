--Serverless Spark SQL
--********************************************************************--
--author: 王海阳
--create time: 2026-08-08 22:41:43
--Serverless Spark SQL任务只能运行在独享资源组上
--********************************************************************--
CREATE TABLE IF NOT EXISTS dwd_minutely_inout_detail_d_i (
  fulltime STRING COMMENT '明细时间(精确到分钟)',
  sid BIGINT COMMENT '供应商id',
  lid BIGINT COMMENT '景区id',
  device_key STRING COMMENT '闸机特征码',
  roll INT COMMENT '0 入园 1 离园',
  num BIGINT COMMENT '单次出入园数量',
  all_num BIGINT COMMENT '当前的出入园总量',
  fulldate INT COMMENT '出入园日期')
USING orc
PARTITIONED BY (fulldate)
COMMENT '景区出入园详细记录表';

INSERT OVERWRITE TABLE dwd_minutely_inout_detail_d_i PARTITION(`fulldate`='${ds}')
select 
    date_format(from_unixtime(create_time), 'yyyy-MM-dd HH:mm:00') AS fulltime, 
    sid, 
    land_id as lid, 
    device_key, 
    roll, 
    sum(num) as num, 
    sum(all_num) as all_num
from ods_pft_dc_daycount_info_d_i
where insertdate = ${ds}
group by 
    date_format(from_unixtime(create_time), 'yyyy-MM-dd HH:mm:00'), 
    sid, 
    land_id, 
    device_key, 
    roll;
