-- name dws_scenic_inout_hour_summary_d_i
-- type Spark SQL
-- author wanghaiyang@12301.cc
-- create time 2024-11-26 17:44:44
-- desc 每日出入园人数汇总
CREATE TABLE IF NOT EXISTS `dws_scenic_inout_hour_summary_d_i` (
    `gid`      INT         COMMENT '统计组id',
	`year`     INT     	   COMMENT '报告年份,年份,例如2022',
    `quarter`  INT     	   COMMENT '报告季度,年+季度,例如:202201',
    `month`    INT     	   COMMENT '报告月份,年+月,例如:202203',
    `week`     INT     	   COMMENT '报告周,年+ISOweek,例如:202211',
    `in`       BIGINT      COMMENT '入园人数',
    `out`      BIGINT      COMMENT '出园人数',
    `i0`       BIGINT      COMMENT '0:00~0:59入园人数',
    `i1`       BIGINT      COMMENT '1:00~1:59入园人数',
    `i2`       BIGINT      COMMENT '2:00~2:59入园人数',
    `i3`       BIGINT      COMMENT '3:00~3:59入园人数',
    `i4`       BIGINT      COMMENT '4:00~4:59入园人数',
    `i5`       BIGINT      COMMENT '5:00~5:59入园人数',
    `i6`       BIGINT      COMMENT '6:00~6:59入园人数',
    `i7`       BIGINT      COMMENT '7:00~7:59入园人数',
    `i8`       BIGINT      COMMENT '8:00~8:59入园人数',
    `i9`       BIGINT      COMMENT '9:00~9:59入园人数',
    `i10`      BIGINT      COMMENT '10:00~10:59入园人数',
    `i11`      BIGINT      COMMENT '11:00~11:59入园人数',
    `i12`      BIGINT      COMMENT '12:00~12:59入园人数',
    `i13`      BIGINT      COMMENT '13:00~13:59入园人数',
    `i14`      BIGINT      COMMENT '14:00~14:59入园人数',
    `i15`      BIGINT      COMMENT '15:00~15:59入园人数',
    `i16`      BIGINT      COMMENT '16:00~16:59入园人数',
    `i17`      BIGINT      COMMENT '17:00~17:59入园人数',
    `i18`      BIGINT      COMMENT '18:00~18:59入园人数',
    `i19`      BIGINT      COMMENT '19:00~19:59入园人数',
    `i20`      BIGINT      COMMENT '20:00~20:59入园人数',
    `i21`      BIGINT      COMMENT '21:00~21:59入园人数',
    `i22`      BIGINT      COMMENT '22:00~22:59入园人数',
    `i23`      BIGINT      COMMENT '23:00~23:59入园人数',

    `o0`   		BIGINT      COMMENT '0:00~0:59出园人数',
    `o1`   		BIGINT      COMMENT '1:00~1:59出园人数',
    `o2`   		BIGINT      COMMENT '2:00~2:59出园人数',
    `o3`   		BIGINT      COMMENT '3:00~3:59出园人数',
    `o4`   		BIGINT      COMMENT '4:00~4:59出园人数',
    `o5`   		BIGINT      COMMENT '5:00~5:59出园人数',
    `o6`   		BIGINT      COMMENT '6:00~6:59出园人数',
    `o7`   		BIGINT      COMMENT '7:00~7:59出园人数',
    `o8`   		BIGINT      COMMENT '8:00~8:59出园人数',
    `o9`   		BIGINT      COMMENT '9:00~9:59出园人数',
    `o10`  		BIGINT      COMMENT '10:00~10:59出园人数',
    `o11`  		BIGINT      COMMENT '11:00~11:59出园人数',
    `o12`  		BIGINT      COMMENT '12:00~12:59出园人数',
    `o13`  		BIGINT      COMMENT '13:00~13:59出园人数',
    `o14`  		BIGINT      COMMENT '14:00~14:59出园人数',
    `o15`  		BIGINT      COMMENT '15:00~15:59出园人数',
    `o16`  		BIGINT      COMMENT '16:00~16:59出园人数',
    `o17`  		BIGINT      COMMENT '17:00~17:59出园人数',
    `o18`  		BIGINT      COMMENT '18:00~18:59出园人数',
    `o19`  		BIGINT      COMMENT '19:00~19:59出园人数',
    `o20`  		BIGINT      COMMENT '20:00~20:59出园人数',
    `o21`  		BIGINT      COMMENT '21:00~21:59出园人数',
    `o22`  		BIGINT      COMMENT '22:00~22:59出园人数',
    `o23`  		BIGINT      COMMENT '23:00~23:59出园人数'
) 
COMMENT '每日出入园人数汇总'
PARTITIONED BY (`date` INT COMMENT '日期例如20171010')
STORED AS ORC;

INSERT OVERWRITE TABLE dws_scenic_inout_hour_summary_d_i PARTITION(`date`='${ds}')
SELECT
    gid                                             AS `gid`, 
    YEAR(`date`)                                    AS `year`,
    YEAR(`date`) * 100 + QUARTER(`date`)            AS `quarter`,
    YEAR(`date`) * 100 + MONTH(`date`)              AS `month`,
    INT(isoweek)                                    AS `week`,
    SUM(IF(roll=0, num, 0))                         AS `in`,
    SUM(IF(roll=1, num, 0))                         AS `out`,
	 SUM(IF(hour=0 AND roll=0, num, 0))             AS i0,
    SUM(IF(hour=1 AND roll=0, num, 0))              AS i1,
    SUM(IF(hour=2 AND roll=0, num, 0))              AS i2,
    SUM(IF(hour=3 AND roll=0, num, 0))              AS i3,
    SUM(IF(hour=4 AND roll=0, num, 0))              AS i4,
    SUM(IF(hour=5 AND roll=0, num, 0))              AS i5,
    SUM(IF(hour=6 AND roll=0, num, 0))              AS i6,
    SUM(IF(hour=7 AND roll=0, num, 0))              AS i7,
    SUM(IF(hour=8 AND roll=0, num, 0))              AS i8,
    SUM(IF(hour=9 AND roll=0, num, 0))              AS i9,
    SUM(IF(hour=10 AND roll=0, num, 0))             AS i10,
    SUM(IF(hour=11 AND roll=0, num, 0))             AS i11,
    SUM(IF(hour=12 AND roll=0, num, 0))             AS i12,
    SUM(IF(hour=13 AND roll=0, num, 0))             AS i13,
    SUM(IF(hour=14 AND roll=0, num, 0))             AS i14,
    SUM(IF(hour=15 AND roll=0, num, 0))             AS i15,
    SUM(IF(hour=16 AND roll=0, num, 0))             AS i16,
    SUM(IF(hour=17 AND roll=0, num, 0))             AS i17,
    SUM(IF(hour=18 AND roll=0, num, 0))             AS i18,
    SUM(IF(hour=19 AND roll=0, num, 0))             AS i19,
    SUM(IF(hour=20 AND roll=0, num, 0))             AS i20,
    SUM(IF(hour=21 AND roll=0, num, 0))             AS i21,
    SUM(IF(hour=22 AND roll=0, num, 0))             AS i22,
    SUM(IF(hour=23 AND roll=0, num, 0))             AS i23,

    SUM(IF(hour=0 AND roll=1, num, 0))              AS o0,
    SUM(IF(hour=1 AND roll=1, num, 0))              AS o1,
    SUM(IF(hour=2 AND roll=1, num, 0))              AS o2,
    SUM(IF(hour=3 AND roll=1, num, 0))              AS o3,
    SUM(IF(hour=4 AND roll=1, num, 0))              AS o4,
    SUM(IF(hour=5 AND roll=1, num, 0))              AS o5,
    SUM(IF(hour=6 AND roll=1, num, 0))              AS o6,
    SUM(IF(hour=7 AND roll=1, num, 0))              AS o7,
    SUM(IF(hour=8 AND roll=1, num, 0))              AS o8,
    SUM(IF(hour=9 AND roll=1, num, 0))              AS o9,
    SUM(IF(hour=10 AND roll=1, num, 0))             AS o10,
    SUM(IF(hour=11 AND roll=1, num, 0))             AS o11,
    SUM(IF(hour=12 AND roll=1, num, 0))             AS o12,
    SUM(IF(hour=13 AND roll=1, num, 0))             AS o13,
    SUM(IF(hour=14 AND roll=1, num, 0))             AS o14,
    SUM(IF(hour=15 AND roll=1, num, 0))             AS o15,
    SUM(IF(hour=16 AND roll=1, num, 0))             AS o16,
    SUM(IF(hour=17 AND roll=1, num, 0))             AS o17,
    SUM(IF(hour=18 AND roll=1, num, 0))             AS o18,
    SUM(IF(hour=19 AND roll=1, num, 0))             AS o19,
    SUM(IF(hour=20 AND roll=1, num, 0))             AS o20,
    SUM(IF(hour=21 AND roll=1, num, 0))             AS o21,
    SUM(IF(hour=22 AND roll=1, num, 0))             AS o22,
    SUM(IF(hour=23 AND roll=1, num, 0))             AS o23
FROM(
    SELECT
        gateTab.`gid`,
        dim_isoweek.`isoweek`,
        dim_isoweek.`date`,
        dcTab.`fulldate`,
        dcTab.`hour`,
        dcTab.`device_key`,
        dcTab.`roll`,
        dcTab.`num`
    FROM (
        SELECT
            sid,  
            insertdate                                      AS `fulldate`, 
            cast(from_unixtime(create_time,'HH') AS int)    AS `hour`,
            device_key, 
            roll, 
            num
        FROM ods_pft_dc_daycount_info_d_i 
        WHERE `insertdate` = '${ds}'
    ) dcTab
    -- 存在设备号的统计组
    JOIN (
        SELECT gid, sid, gate
        FROM dim_input_group_gate_d_f
        WHERE pt = DATE_FORMAT(DATE_SUB(CURRENT_DATE(), 1),"yyyyMMdd") 
            AND gate != ''
    ) gateTab 
    ON dcTab.device_key = gateTab.gate
    LEFT JOIN dim_date_isoweek_o_f dim_isoweek 
    ON dcTab.fulldate = dim_isoweek.fulldate
)
GROUP BY 
    gid, 
    fulldate,
    date,
    isoweek

UNION ALL

SELECT
    gid                                             AS `gid`, 
    YEAR(`date`)                                    AS `year`,
    YEAR(`date`) * 100 + QUARTER(`date`)            AS `quarter`,
    YEAR(`date`) * 100 + MONTH(`date`)              AS `month`,
    INT(isoweek)                                    AS `week`,
    SUM(IF(roll=0, num, 0))                         AS `in`,
    SUM(IF(roll=1, num, 0))                         AS `out`,
	SUM(IF(hour=0 AND roll=0, num, 0))              AS i0,
    SUM(IF(hour=1 AND roll=0, num, 0))              AS i1,
    SUM(IF(hour=2 AND roll=0, num, 0))              AS i2,
    SUM(IF(hour=3 AND roll=0, num, 0))              AS i3,
    SUM(IF(hour=4 AND roll=0, num, 0))              AS i4,
    SUM(IF(hour=5 AND roll=0, num, 0))              AS i5,
    SUM(IF(hour=6 AND roll=0, num, 0))              AS i6,
    SUM(IF(hour=7 AND roll=0, num, 0))              AS i7,
    SUM(IF(hour=8 AND roll=0, num, 0))              AS i8,
    SUM(IF(hour=9 AND roll=0, num, 0))              AS i9,
    SUM(IF(hour=10 AND roll=0, num, 0))             AS i10,
    SUM(IF(hour=11 AND roll=0, num, 0))             AS i11,
    SUM(IF(hour=12 AND roll=0, num, 0))             AS i12,
    SUM(IF(hour=13 AND roll=0, num, 0))             AS i13,
    SUM(IF(hour=14 AND roll=0, num, 0))             AS i14,
    SUM(IF(hour=15 AND roll=0, num, 0))             AS i15,
    SUM(IF(hour=16 AND roll=0, num, 0))             AS i16,
    SUM(IF(hour=17 AND roll=0, num, 0))             AS i17,
    SUM(IF(hour=18 AND roll=0, num, 0))             AS i18,
    SUM(IF(hour=19 AND roll=0, num, 0))             AS i19,
    SUM(IF(hour=20 AND roll=0, num, 0))             AS i20,
    SUM(IF(hour=21 AND roll=0, num, 0))             AS i21,
    SUM(IF(hour=22 AND roll=0, num, 0))             AS i22,
    SUM(IF(hour=23 AND roll=0, num, 0))             AS i23,

    SUM(IF(hour=0 AND roll=1, num, 0))              AS o0,
    SUM(IF(hour=1 AND roll=1, num, 0))              AS o1,
    SUM(IF(hour=2 AND roll=1, num, 0))              AS o2,
    SUM(IF(hour=3 AND roll=1, num, 0))              AS o3,
    SUM(IF(hour=4 AND roll=1, num, 0))              AS o4,
    SUM(IF(hour=5 AND roll=1, num, 0))              AS o5,
    SUM(IF(hour=6 AND roll=1, num, 0))              AS o6,
    SUM(IF(hour=7 AND roll=1, num, 0))              AS o7,
    SUM(IF(hour=8 AND roll=1, num, 0))              AS o8,
    SUM(IF(hour=9 AND roll=1, num, 0))              AS o9,
    SUM(IF(hour=10 AND roll=1, num, 0))             AS o10,
    SUM(IF(hour=11 AND roll=1, num, 0))             AS o11,
    SUM(IF(hour=12 AND roll=1, num, 0))             AS o12,
    SUM(IF(hour=13 AND roll=1, num, 0))             AS o13,
    SUM(IF(hour=14 AND roll=1, num, 0))             AS o14,
    SUM(IF(hour=15 AND roll=1, num, 0))             AS o15,
    SUM(IF(hour=16 AND roll=1, num, 0))             AS o16,
    SUM(IF(hour=17 AND roll=1, num, 0))             AS o17,
    SUM(IF(hour=18 AND roll=1, num, 0))             AS o18,
    SUM(IF(hour=19 AND roll=1, num, 0))             AS o19,
    SUM(IF(hour=20 AND roll=1, num, 0))             AS o20,
    SUM(IF(hour=21 AND roll=1, num, 0))             AS o21,
    SUM(IF(hour=22 AND roll=1, num, 0))             AS o22,
    SUM(IF(hour=23 AND roll=1, num, 0))             AS o23
FROM(
    SELECT
        lackGateTab.gid,
        dim_isoweek.isoweek,
        dcTab.fulldate,
        dim_isoweek.date,
        dcTab.hour,
        dcTab.device_key,
        dcTab.roll,
        dcTab.num
    FROM (
        SELECT
            sid,  
            insertdate                                      AS `fulldate`, 
            cast(from_unixtime(create_time,'HH') AS int)    AS `hour`,
            device_key, 
            roll, 
            num
        FROM ods_pft_dc_daycount_info_d_i 
        WHERE `insertdate` = '${ds}'
    ) dcTab
    -- 不存在设备号的统计组
    JOIN (
        SELECT gid, sid
        FROM dim_input_group_gate_d_f
        WHERE pt = DATE_FORMAT(DATE_SUB(CURRENT_DATE(), 1),"yyyyMMdd") 
            AND gate = ''
    ) lackGateTab 
    ON dcTab.sid = lackGateTab.sid
    LEFT JOIN dim_date_isoweek_o_f dim_isoweek 
    ON dcTab.fulldate = dim_isoweek.`fulldate`
)
GROUP BY 
    gid, 
    fulldate,
    date,
    isoweek;