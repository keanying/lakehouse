-- name dws_scenic_inout_week_summary_d_i
-- type Spark SQL
-- author wanghaiyang@12301.cc
-- create time 2024-11-26 17:44:44
-- desc 每周出入园人数汇总

SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
set hive.exec.dynamic.partition.mode=nonstrict;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;

CREATE TABLE IF NOT EXISTS `dws_scenic_inout_week_summary_d_i` (
    `gid`      	INT         COMMENT '统计组id',
    `in`       	BIGINT      COMMENT '入园人数',
    `out`      	BIGINT      COMMENT '出园人数',
    `employee`  BIGINT      COMMENT '员工卡数'
) 
COMMENT '每周出入园人数汇总'
PARTITIONED BY (`week` INT COMMENT '报告周,年+ISOweek,例如:202211')
STORED AS ORC;


INSERT OVERWRITE TABLE dws_scenic_inout_week_summary_d_i PARTITION(`week`)
SELECT
    `gid`                           AS `gid`, 
    SUM(`in`)                       AS `in`,
    SUM(`out`)                      AS `out`,
    SUM(`employee`)                 AS `employee`,
    INT(dim_isoweek.isoweek)        AS `week`
FROM (
    SELECT 
        `gid`, 
        `date`, 
        `in`, 
        `out`,
        `employee`
    FROM ods_scenic_inout_hour_summary_d_i
) countTab
LEFT JOIN dim_date_isoweek_o_f dim_isoweek 
ON countTab.`date` = dim_isoweek.fulldate
GROUP BY 
    `gid`, 
    dim_isoweek.isoweek;