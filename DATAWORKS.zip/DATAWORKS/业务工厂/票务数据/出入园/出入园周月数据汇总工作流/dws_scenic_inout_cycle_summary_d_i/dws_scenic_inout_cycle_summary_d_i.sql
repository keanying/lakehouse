-- name dws_scenic_inout_cycle_summary_d_i
-- type Spark SQL
-- author wanghaiyang@12301.cc
-- create time 2024-11-26 17:44:44
-- desc 每月出入园人数汇总

SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;

CREATE TABLE IF NOT EXISTS `dws_scenic_inout_cycle_summary_d_i` (
    `gid`      	INT         COMMENT '统计组id',
	`year`     	INT     	COMMENT '报告年份,年份,例如2022',
    `quarter`  	INT     	COMMENT '报告季度,年+季度,例如:202201',
    `in`       	BIGINT      COMMENT '入园人数',
    `out`      	BIGINT      COMMENT '出园人数',
    `employee`  BIGINT      COMMENT '员工卡数'
) 
COMMENT '每月出入园人数汇总'
PARTITIONED BY (`month` INT COMMENT '报告月份,年+月,例如:202203')
STORED AS ORC;

INSERT OVERWRITE TABLE dws_scenic_inout_cycle_summary_d_i PARTITION(`month`)
SELECT
    `gid`                                       AS `gid`, 
    YEAR(fulldate)                              AS  `year`,
	YEAR(fulldate) * 100 + QUARTER(fulldate)    AS  `quarter`,
    SUM(`in`)                                   AS `in`,
    SUM(`out`)                                  AS `out`,
    SUM(`employee`)                             AS `employee`,
    YEAR(fulldate) * 100 + MONTH(fulldate)
FROM (
    SELECT 
        `gid`, 
        `date`, 
        FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(`date`  AS STRING),'yyyymmdd'),'yyyy-mm-dd') 	AS fulldate,
        `in`, 
        `out`,
        `employee`
    FROM ods_scenic_inout_hour_summary_d_i
    WHERE SUBSTR(`date`, 0, 6) = SUBSTR('${ds}', 0, 6)
)
GROUP BY 
    `gid`, 
    YEAR(fulldate),
    YEAR(fulldate) * 100 + QUARTER(fulldate),
    YEAR(fulldate) * 100 + MONTH(fulldate);