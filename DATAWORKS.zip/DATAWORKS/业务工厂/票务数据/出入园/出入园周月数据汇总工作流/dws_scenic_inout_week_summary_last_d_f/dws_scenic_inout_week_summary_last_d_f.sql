-- name dws_scenic_inout_week_summary_last_d_i
-- type Spark SQL
-- author wanghaiyang@12301.cc
-- create time 2025-01-03 20:18:11
-- desc 


SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
set hive.exec.dynamic.partition.mode=nonstrict;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;

CREATE TABLE IF NOT EXISTS `dws_scenic_inout_week_summary_last_d_f` (
    `gid`      	INT         COMMENT '统计组id',
    `week`      INT         COMMENT '报告周,年+ISOweek,例如:202211',
    `in`       	BIGINT      COMMENT '入园人数',
    `out`      	BIGINT      COMMENT '出园人数',
    `employee`  BIGINT      COMMENT '员工卡数'
) COMMENT '每周出入园人数汇总'
STORED AS ORC;

INSERT OVERWRITE TABLE dws_scenic_inout_week_summary_last_d_f 
SELECT 
    `gid`,
    `week`,
    `in`,
    `out`,
    `employee`
FROM dws_scenic_inout_week_summary_d_i
WHERE `week` in(SELECT MAX(`week`) AS `week` FROM dws_scenic_inout_week_summary_d_i);