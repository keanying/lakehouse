-- name dws_monthly_report_annual_card_ticket_summary_d_i
-- type Spark SQL
-- author wanghaiyang@12301.cc
-- create time 2024-11-14 18:14:22
-- desc 每月年卡套餐汇总表


 CREATE TABLE IF NOT EXISTS `dws_monthly_report_annual_card_ticket_summary_d_i`(
    `sid`                               BIGINT  COMMENT'用户ID',
    `card_lid`                          BIGINT  COMMENT'年卡景区ID',
    `card_pid`                          BIGINT  COMMENT'年卡产品SPUID',
    `card_tid`                          BIGINT  COMMENT'年卡门票ID',
    `year`                              INT     COMMENT'年',
    `order_num`                         BIGINT  COMMENT'总预订订单数',
    `order_ticket`                      BIGINT  COMMENT'总预订门票数',
    `order_cost_money`                  BIGINT  COMMENT'总预订花费金额',
    `order_sale_money`                  BIGINT  COMMENT'总预定销售金额',
    `cancel_num`                        BIGINT  COMMENT'总取消订单数',
    `cancel_ticket`                     BIGINT  COMMENT'总取消门票数',
    `cancel_cost_money`                 BIGINT  COMMENT'总取消花费金额',
    `cancel_sale_money`                 BIGINT  COMMENT'总取消销售金额',
    `verify_num`                        BIGINT  COMMENT'总验证订单数',
    `verify_ticket`                     BIGINT  COMMENT'总验证门票数',
    `verify_cost_money`                 BIGINT  COMMENT'总验证花费金额',
    `verify_sale_money`                 BIGINT  COMMENT'总验证销售金额',
    `sale_order_num`                    BIGINT  COMMENT'售卡预订订单数',
    `sale_order_ticket`                 BIGINT  COMMENT'售卡预订门票数',
    `sale_order_cost_money`             BIGINT  COMMENT'售卡预订花费金额',
    `sale_order_sale_money`             BIGINT  COMMENT'售卡预定销售金额',
    `renew_order_num`                   BIGINT  COMMENT'续费预订订单数',
    `renew_order_ticket`                BIGINT  COMMENT'续费预订门票数',
    `renew_order_cost_money`            BIGINT  COMMENT'续费预订花费金额',
    `renew_order_sale_money`            BIGINT  COMMENT'续费预定销售金额',
    `adjust_order_num`                  BIGINT  COMMENT'补卡预订订单数',
    `adjust_order_ticket`               BIGINT  COMMENT'补卡预订门票数',
    `adjust_order_cost_money`           BIGINT  COMMENT'补卡预订花费金额',
    `adjust_order_sale_money`           BIGINT  COMMENT'补卡预定销售金额',
    `activate_order_num`                BIGINT  COMMENT'激活预订订单数',
    `activate_order_ticket`             BIGINT  COMMENT'激活预订门票数',
    `activate_order_cost_money`         BIGINT  COMMENT'激活预订花费金额',
    `activate_order_sale_money`         BIGINT  COMMENT'激活预定销售金额'
 )comment'每月年卡套餐汇总表'partitioned by(
    `month`                             INT     COMMENT'年月'
 )stored as orc 
 ;

INSERT OVERWRITE TABLE dws_monthly_report_annual_card_ticket_summary_d_i PARTITION(month) 
SELECT
    `sid`,
    `card_lid`,
    `card_pid`,
    `card_tid`,
    `year`,
    SUM(`order_num`)                    AS  order_num,
    SUM(`order_ticket`)                 AS  order_ticket,
    SUM(`order_cost_money`)             AS  order_cost_money,
    SUM(`order_sale_money`)             AS  order_sale_money,
    SUM(`cancel_num`)                   AS  cancel_num,
    SUM(`cancel_ticket`)                AS  cancel_ticket,
    SUM(`cancel_cost_money`)            AS  cancel_cost_money,
    SUM(`cancel_sale_money`)            AS  cancel_sale_money,
    SUM(`verify_num`)                   AS  verify_num,
    SUM(`verify_ticket`)                AS  verify_ticket,
    SUM(`verify_cost_money`)            AS  verify_cost_money,
    SUM(`verify_sale_money`)            AS  verify_sale_money,
    SUM(`sale_order_num`)               AS  sale_order_num,
    SUM(`sale_order_ticket`)            AS  sale_order_ticket,
    SUM(`sale_order_cost_money`)        AS  sale_order_cost_money,
    SUM(`sale_order_sale_money`)        AS  sale_order_sale_money,
    SUM(`renew_order_num`)              AS  renew_order_num,
    SUM(`renew_order_ticket`)           AS  renew_order_ticket,
    SUM(`renew_order_cost_money`)       AS  renew_order_cost_money,
    SUM(`renew_order_sale_money`)       AS  renew_order_sale_money,
    SUM(`adjust_order_num`)             AS  adjust_order_num,
    SUM(`adjust_order_ticket`)          AS  adjust_order_ticket,
    SUM(`adjust_order_cost_money`)      AS  adjust_order_cost_money,
    SUM(`adjust_order_sale_money`)      AS  adjust_order_sale_money,
    SUM(`activate_order_num`)           AS  activate_order_num,
    SUM(`activate_order_ticket`)        AS  activate_order_ticket,
    SUM(`activate_order_cost_money`)    AS  activate_order_cost_money,
    SUM(`activate_order_sale_money`)    AS  activate_order_sale_money,
    `month`
FROM dws_daily_report_annual_card_ticket_summary_d_i
WHERE SUBSTR(`fulldate`, 0, 6) = SUBSTR('${ds}', 0, 6)
GROUP BY 
    `sid`,
    `card_lid`,
    `card_pid`,
    `card_tid`,
    `year`,
    `month`;