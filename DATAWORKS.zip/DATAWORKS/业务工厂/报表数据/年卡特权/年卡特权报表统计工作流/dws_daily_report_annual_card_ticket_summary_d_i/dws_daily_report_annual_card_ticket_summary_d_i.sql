-- name dws_daily_report_annual_card_ticket_summary_d_i
-- type Spark SQL
-- author wanghaiyang@12301.cc
-- create time 2024-08-09 18:37:04
-- desc 每日年卡套餐汇总表

 CREATE TABLE IF NOT EXISTS `dws_daily_report_annual_card_ticket_summary_d_i`(
    `sid`                               INT     COMMENT'用户ID',
    `card_lid`                          INT     COMMENT'年卡景区ID',
    `card_pid`                          INT     COMMENT'年卡产品SPUID',
    `card_tid`                          INT     COMMENT'年卡门票ID',
    `year`                              INT     COMMENT'年',
    `month`                             INT     COMMENT'年月',
    `week`                              INT     COMMENT'年周',
    `order_num`                         INT     COMMENT'总预订订单数',
    `order_ticket`                      INT     COMMENT'总预订门票数',
    `order_cost_money`                  BIGINT  COMMENT'总预订花费金额',
    `order_sale_money`                  BIGINT  COMMENT'总预定销售金额',
    `cancel_num`                        INT     COMMENT'总取消订单数',
    `cancel_ticket`                     INT     COMMENT'总取消门票数',
    `cancel_cost_money`                 BIGINT  COMMENT'总取消花费金额',
    `cancel_sale_money`                 BIGINT  COMMENT'总取消销售金额',
    `verify_num`                        INT     COMMENT'总验证订单数',
    `verify_ticket`                     INT     COMMENT'总验证门票数',
    `verify_cost_money`                 BIGINT  COMMENT'总验证花费金额',
    `verify_sale_money`                 BIGINT  COMMENT'总验证销售金额',
    `sale_order_num`                    INT     COMMENT'售卡预订订单数',
    `sale_order_ticket`                 INT     COMMENT'售卡预订门票数',
    `sale_order_cost_money`             BIGINT  COMMENT'售卡预订花费金额',
    `sale_order_sale_money`             BIGINT  COMMENT'售卡预定销售金额',
    `renew_order_num`                   INT     COMMENT'续费预订订单数',
    `renew_order_ticket`                INT     COMMENT'续费预订门票数',
    `renew_order_cost_money`            BIGINT  COMMENT'续费预订花费金额',
    `renew_order_sale_money`            BIGINT  COMMENT'续费预定销售金额',
    `adjust_order_num`                  INT     COMMENT'补卡预订订单数',
    `adjust_order_ticket`               INT     COMMENT'补卡预订门票数',
    `adjust_order_cost_money`           BIGINT  COMMENT'补卡预订花费金额',
    `adjust_order_sale_money`           BIGINT  COMMENT'补卡预定销售金额',
    `activate_order_num`                INT     COMMENT'激活预订订单数',
    `activate_order_ticket`             INT     COMMENT'激活预订门票数',
    `activate_order_cost_money`         BIGINT  COMMENT'激活预订花费金额',
    `activate_order_sale_money`         BIGINT  COMMENT'激活预定销售金额'
 )comment'每日年卡套餐统计表'partitioned by(
    `fulldate` INT
 )stored as orc 
;

INSERT OVERWRITE TABLE dws_daily_report_annual_card_ticket_summary_d_i PARTITION(`fulldate`='${ds}') 
SELECT
    sid                                                         AS  sid,
    card_lid                                                    AS  card_lid,
    card_pid                                                    AS  card_pid,
    card_tid                                                    AS  card_tid,
    YEAR(dim_isoweek.date)                                      AS `year`,
    YEAR(dim_isoweek.date) * 100 + MONTH(dim_isoweek.date)      AS `month`,
    CAST(dim_isoweek.isoweek  AS INT)                           AS `week`,
    SUM(order_num)                                              AS  order_num,
    SUM(order_ticket)                                           AS  order_ticket,
    SUM(order_cost_money)                                       AS  order_cost_money,
    SUM(order_sale_money)                                       AS  order_sale_money,
    SUM(cancel_num)                                             AS  cancel_num,
    SUM(cancel_ticket)                                          AS  cancel_ticket,
    SUM(cancel_cost_money)                                      AS  cancel_cost_money,
    SUM(cancel_sale_money)                                      AS  cancel_sale_money,
    SUM(verify_num)                                             AS  verify_num,
    SUM(verify_ticket)                                          AS  verify_ticket,
    SUM(verify_cost_money)                                      AS  verify_cost_money,
    SUM(verify_sale_money)                                      AS  verify_sale_money,
    SUM(sale_order_num)                                         AS  sale_order_num,
    SUM(sale_order_ticket)                                      AS  sale_order_ticket,
    SUM(sale_order_cost_money)                                  AS  sale_order_cost_money,
    SUM(sale_order_sale_money)                                  AS  sale_order_sale_money,
    SUM(renew_order_num)                                        AS  renew_order_num,
    SUM(renew_order_ticket)                                     AS  renew_order_ticket,
    SUM(renew_order_cost_money)                                 AS  renew_order_cost_money,
    SUM(renew_order_sale_money)                                 AS  renew_order_sale_money,
    SUM(adjust_order_num)                                       AS  adjust_order_num,
    SUM(adjust_order_ticket)                                    AS  adjust_order_ticket,
    SUM(adjust_order_cost_money)                                AS  adjust_order_cost_money,
    SUM(adjust_order_sale_money)                                AS  adjust_order_sale_money,
    SUM(activate_order_num)                                     AS  activate_order_num,
    SUM(activate_order_ticket)                                  AS  activate_order_ticket,
    SUM(activate_order_cost_money)                              AS  activate_order_cost_money,
    SUM(activate_order_sale_money)                              AS  activate_order_sale_money
FROM(
    SELECT
        fid                                         AS  sid, 
        card_lid                                    AS  card_lid,
        card_pid                                    AS  card_pid,
        card_tid                                    AS  card_tid,

        0                                           AS  order_num,
        0                                           AS  order_ticket,
        0                                           AS  order_cost_money,
        0                                           AS  order_sale_money,

        0                                           AS  cancel_num,
        0                                           AS  cancel_ticket,
        0                                           AS  cancel_cost_money,
        0                                           AS  cancel_sale_money,

        SUM(checkTab.order_num)                     AS  verify_num,
        SUM(checkTab.order_ticket)                  AS  verify_ticket,
        SUM(checkTab.cost_money)                    AS  verify_cost_money,
        SUM(checkTab.sale_money)                    AS  verify_sale_money,

        0                                           AS  sale_order_num,
        0                                           AS  sale_order_ticket,
        0                                           AS  sale_order_cost_money,
        0                                           AS  sale_order_sale_money,

        0                                           AS  renew_order_num,
        0                                           AS  renew_order_ticket,
        0                                           AS  renew_order_cost_money,
        0                                           AS  renew_order_sale_money,

        0                                           AS  adjust_order_num,
        0                                           AS  adjust_order_ticket,
        0                                           AS  adjust_order_cost_money,
        0                                           AS  adjust_order_sale_money,

        0                                           AS  activate_order_num,
        0                                           AS  activate_order_ticket,
        0                                           AS  activate_order_cost_money,
        0                                           AS  activate_order_sale_money,
        date                                        AS fulldate
    FROM ods_pft_report_annual_card_checked_d_i checkTab
    LEFT JOIN (
        SELECT id, landid AS card_lid
        FROM ods_ticket_d_f
        WHERE pt = DATE_FORMAT(DATE_SUB(CURRENT_DATE(), 1),"yyyyMMdd")
    ) ticketTab
    ON checkTab.card_tid = ticketTab.id
    WHERE `date` ='${ds}'
    GROUP BY
        fid, 
        card_lid,
        card_pid,
        card_tid,
        date
    UNION ALL
    SELECT
        fid                                         AS  sid, 
        lid                                         AS  card_lid,
        pid                                         AS  card_pid,
        tid                                         AS  card_tid,
        
        SUM(order_num)                              AS  order_num,
        SUM(order_ticket)                           AS  order_ticket,
        SUM(cost_money)                             AS  order_cost_money,
        SUM(sale_money)                             AS  order_sale_money,

        SUM(cancel_num)                             AS  cancel_num,
        SUM(cancel_ticket)                          AS  cancel_ticket,
        0                                           AS  cancel_cost_money,
        SUM(cancel_sale_money)                      AS  cancel_sale_money,

        0                                           AS  verify_num,
        0                                           AS  verify_ticket,
        0                                           AS  verify_cost_money,
        0                                           AS  verify_sale_money,

        SUM(IF(trade_type=0, order_num, 0))         AS  sale_order_num,
        SUM(IF(trade_type=0, order_ticket, 0))      AS  sale_order_ticket,
        SUM(IF(trade_type=0, cost_money, 0))        AS  sale_order_cost_money,
        SUM(IF(trade_type=0, sale_money, 0))        AS  sale_order_sale_money,

        SUM(IF(trade_type=1, order_num, 0))         AS  renew_order_num,
        SUM(IF(trade_type=1, order_ticket, 0))      AS  renew_order_ticket,
        SUM(IF(trade_type=1, cost_money, 0))        AS  renew_order_cost_money,
        SUM(IF(trade_type=1, sale_money, 0))        AS  renew_order_sale_money,

        SUM(IF(trade_type=2, order_num, 0))         AS  adjust_order_num,
        SUM(IF(trade_type=2, order_ticket, 0))      AS  adjust_order_ticket,
        SUM(IF(trade_type=2, cost_money, 0))        AS  adjust_order_cost_money,
        SUM(IF(trade_type=2, sale_money, 0))        AS  adjust_order_sale_money,

        SUM(IF(trade_type=4, order_num, 0))         AS  activate_order_num,
        SUM(IF(trade_type=4, order_ticket, 0))      AS  activate_order_ticket,
        SUM(IF(trade_type=4, cost_money, 0))        AS  activate_order_cost_money,
        SUM(IF(trade_type=4, sale_money, 0))        AS  activate_order_sale_money,                                       
        date                                        AS  fulldate
    FROM ods_pft_report_annual_card_order_d_i checkTab
    WHERE `date` ='${ds}'
    GROUP BY fid, lid, pid, tid, date
) orderTab
LEFT JOIN dim_date_isoweek_o_f AS dim_isoweek 
ON `orderTab`.`fulldate` = dim_isoweek.`fulldate`
GROUP BY
    orderTab.sid,
    orderTab.card_lid,
    orderTab.card_pid,
    orderTab.card_tid,
    orderTab.fulldate,
    dim_isoweek.isoweek,
    dim_isoweek.date;
