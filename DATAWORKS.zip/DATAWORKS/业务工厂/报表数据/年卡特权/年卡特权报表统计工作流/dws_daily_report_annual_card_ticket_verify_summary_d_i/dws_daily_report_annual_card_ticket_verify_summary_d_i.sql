-- name dws_daily_report_annual_card_ticket_verify_summary_d_i
-- type Spark SQL
-- author wanghaiyang@12301.cc
-- create time 2024-08-09 18:37:04
-- desc 每日年卡特权产品汇总表

CREATE TABLE IF NOT EXISTS `dws_daily_report_annual_card_ticket_verify_summary_d_i`(
    `sid`                   BIGINT  COMMENT'用户ID',
    `card_lid`              INT     COMMENT'年卡景区ID',
    `card_pid`              INT     COMMENT'年卡产品SPUID',
    `card_tid`              INT     COMMENT'年卡门票ID',
    `lid`                   iNT     COMMENT'特权产品景区ID',
    `pid`                   INT     COMMENT'特权产品产品SPUID',
    `tid`                   INT     COMMENT'特权产品门票ID',
    `p_type`                STRING  COMMENT'景区类型:A景区B线路C酒店F套票G餐饮H演出I年卡套餐',
	`year`                  INT     COMMENT'年',
    `month`                 INT     COMMENT'年月',
    `week`                  INT     COMMENT'年周',
    `verify_num`            INT     COMMENT'验证订单数',
    `verify_ticket`         INT     COMMENT'验证门票数',
    `verify_cost_money`     BIGINT  COMMENT'验证花费金额',
    `verify_sale_money`     BIGINT  COMMENT'验证销售金额'
 )comment'每日年卡特权产品统计表'partitioned by(
    `fulldate` INT
 )stored as orc 
;
 
INSERT OVERWRITE TABLE dws_daily_report_annual_card_ticket_verify_summary_d_i PARTITION(`fulldate`='${ds}') 
SELECT 
    checkTab.fid                                            AS  sid,
    ticketTab.landid                                        AS  card_lid,
    checkTab.card_pid                                       AS  card_pid,
    checkTab.card_tid                                       AS  card_tid,
    checkTab.lid                                            AS  lid,
    checkTab.pid                                            AS  pid,
    checkTab.tid                                            AS  tid,
    landTab.p_type                                          AS  p_type,
    YEAR(dim_isoweek.date)                                  AS `year`,
    YEAR(dim_isoweek.date) * 100 + MONTH(dim_isoweek.date)  AS `month`,
    CAST(dim_isoweek.isoweek  AS INT)                       AS `week`,
    SUM(checkTab.order_num)                                 AS  verify_num,
    SUM(checkTab.order_ticket)                              AS  verify_ticket,
    SUM(checkTab.cost_money)                                AS  verify_cost_money,
    SUM(checkTab.sale_money)                                AS  verify_sale_money
FROM (
    SELECT 
        fid,
        card_pid,
        card_tid,
        lid,
        pid,
        tid,
        order_num,
        order_ticket,
        cost_money,
        sale_money,
        date        AS fulldate
    FROM ods_pft_report_annual_card_checked_d_i
    WHERE `date` ='${ds}'
) checkTab
LEFT JOIN(
    SELECT id, p_type
    FROM ods_land_d_f
    WHERE pt = DATE_FORMAT(DATE_SUB(CURRENT_DATE(), 1),"yyyyMMdd")
) landTab
ON checkTab.lid = landTab.id
LEFT JOIN (
    SELECT id, landid
    FROM ods_ticket_d_f
    WHERE pt = DATE_FORMAT(DATE_SUB(CURRENT_DATE(), 1),"yyyyMMdd")
) ticketTab
ON checkTab.card_tid = ticketTab.id
LEFT JOIN dim_date_isoweek_o_f AS dim_isoweek 
ON `checkTab`.`fulldate` = dim_isoweek.`fulldate`
GROUP BY 
    checkTab.fid,
    ticketTab.landid,
    checkTab.card_pid,
    checkTab.card_tid,
    checkTab.lid,
    checkTab.pid,
    checkTab.tid,
    landTab.p_type,
    dim_isoweek.isoweek,
    dim_isoweek.fulldate,
    dim_isoweek.date;
