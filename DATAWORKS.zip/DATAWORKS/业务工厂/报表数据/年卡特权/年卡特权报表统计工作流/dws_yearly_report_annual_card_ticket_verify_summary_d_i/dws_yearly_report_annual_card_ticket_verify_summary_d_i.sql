-- name dws_monthly_report_annual_card_ticket_verify_summary_d_i
-- type Spark SQL
-- author wanghaiyang@12301.cc
-- create time 2024-11-14 17:31:27
-- desc 每年年卡特权产品汇总表

CREATE TABLE IF NOT EXISTS `dws_yearly_report_annual_card_ticket_verify_summary_d_i`(
    `sid`               BIGINT      COMMENT'用户ID',
    `card_lid`          INT         COMMENT'年卡景区ID',
    `card_pid`          BIGINT      COMMENT'年卡产品SPUID',
    `card_tid`          BIGINT      COMMENT'年卡门票ID',
    `lid`               BIGINT      COMMENT'特权产品景区ID',
    `pid`               BIGINT      COMMENT'特权产品产品SPUID',
    `tid`               BIGINT      COMMENT'特权产品门票ID',
    `p_type`            STRING      COMMENT'景区类型:A景区B线路C酒店F套票G餐饮H演出I年卡套餐',
    `verify_num`        BIGINT      COMMENT'验证订单数',
    `verify_ticket`     BIGINT      COMMENT'验证门票数',
    `verify_cost_money` BIGINT      COMMENT'验证花费金额',
    `verify_sale_money` BIGINT      COMMENT'验证销售金额'
 )comment'每年年卡特权产品汇总表'partitioned by(
    `year`             BIGINT      COMMENT'年'
 )stored as orc 
;

INSERT OVERWRITE TABLE dws_yearly_report_annual_card_ticket_verify_summary_d_i PARTITION(year) 
SELECT 
    sid,
    card_lid,
    card_pid,
    card_tid,
    lid,
    pid,
    tid,
    p_type,
   SUM(verify_num)          AS verify_num,
   SUM(verify_ticket)       AS verify_ticket,
   SUM(verify_cost_money)   AS verify_cost_money,
   SUM(verify_sale_money)   AS verify_sale_money,
   `year`
FROM dws_monthly_report_annual_card_ticket_verify_summary_d_i
WHERE SUBSTR(`month`, 0, 4) = SUBSTR('${ds}', 0, 4)
GROUP BY 
    sid,
    card_lid,
    card_pid,
    card_tid,
    lid,
    pid,
    tid,
    p_type,
    `year`
;