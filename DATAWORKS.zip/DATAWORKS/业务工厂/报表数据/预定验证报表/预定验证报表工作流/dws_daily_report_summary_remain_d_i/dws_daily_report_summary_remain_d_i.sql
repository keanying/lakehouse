-- name dws_daily_report_summary_d_i
-- type Spark SQL
-- author liangleichen@12301.cc
-- create time 2023-09-13 19:21:39
-- desc 预定/验证报表按日汇总数据

SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;

CREATE TABLE IF NOT EXISTS `dws_daily_report_summary_remain_d_i` (
    `sid`                       INT  COMMENT '用户ID',
    `lid`                       INT  COMMENT '景区ID',
    `p_type`                    STRING  COMMENT '景区类型：A景区B线路C酒店F套票',
  
    `mo_order_num`              BIGINT  COMMENT '主单(mo)预订订单数',
    `mo_order_ticket`           BIGINT  COMMENT '主单(mo)预订门票数',
    `mo_order_cost_money`       BIGINT  COMMENT '主单(mo)预订花费金额',
    `mo_order_sale_money`       BIGINT  COMMENT '主单(mo)预定金额',
  
    `mo_cancel_num`             BIGINT  COMMENT '主单(mo)取消订单数',
    `mo_cancel_ticket`          BIGINT  COMMENT '主单(mo)取消门票数',
    `mo_cancel_cost_money`      BIGINT  COMMENT '主单(mo)取消花费金额',
    `mo_cancel_sale_money`      BIGINT  COMMENT '主单(mo)取消金额',
  
    `mo_verify_num`             BIGINT  COMMENT '主单(mo)验证订单数',
    `mo_verify_ticket`          BIGINT  COMMENT '主单(mo)验证门票数',
    `mo_verify_cost_money`      BIGINT  COMMENT '主单(mo)验证花费金额',
    `mo_verify_sale_money`      BIGINT  COMMENT '主单(mo)验证金额',
  
    `mo_finish_num`             BIGINT  COMMENT '主单(mo)完结订单数',
    `mo_finish_ticket`          BIGINT  COMMENT '主单(mo)完结门票数',
    `mo_finish_cost_money`      BIGINT  COMMENT '主单(mo)完结成本价',
    `mo_finish_sale_money`      BIGINT  COMMENT '主单(mo)完结售价',
  
    `mo_revoke_ticket`          BIGINT  COMMENT '主单(mo)撤销门票数',
    `mo_revoke_num`             BIGINT  COMMENT '主单(mo)撤销订单数',
    `mo_revoke_cost_money`      BIGINT  COMMENT '主单(mo)撤销花费金额',
    `mo_revoke_sale_money`      BIGINT  COMMENT '主单(mo)撤销金额',

    `mo_after_sale_ticket_num`        BIGINT  COMMENT '主单(mo)售后数量',
    `mo_after_sale_refund_money`      BIGINT  COMMENT '主单(mo)售后退回金额',
    `mo_after_sale_income_money`      BIGINT  COMMENT '主单(mo)售后收入金额',
  
    `mo_print_num`              BIGINT  COMMENT '主单(mo)取票数量',
  
  
    `no_mo_order_num`           BIGINT  COMMENT '子单(no_mo)预订订单数',
    `no_mo_order_ticket`        BIGINT  COMMENT '子单(no_mo)预订门票数',
    `no_mo_order_cost_money`    BIGINT  COMMENT '子单(no_mo)预订花费金额',
    `no_mo_order_sale_money`    BIGINT  COMMENT '子单(no_mo)预定金额',
  
    `no_mo_cancel_num`          BIGINT  COMMENT '子单(no_mo)取消订单数',
    `no_mo_cancel_ticket`       BIGINT  COMMENT '子单(no_mo)取消门票数',
    `no_mo_cancel_cost_money`   BIGINT  COMMENT '子单(no_mo)取消花费金额',
    `no_mo_cancel_sale_money`   BIGINT  COMMENT '子单(no_mo)取消金额',
  
    `no_mo_verify_num`          BIGINT  COMMENT '子单(no_mo)验证订单数',
    `no_mo_verify_ticket`       BIGINT  COMMENT '子单(no_mo)验证门票数',
    `no_mo_verify_cost_money`   BIGINT  COMMENT '子单(no_mo)验证花费金额',
    `no_mo_verify_sale_money`   BIGINT  COMMENT '子单(no_mo)验证金额',
   
    `no_mo_finish_num`          BIGINT  COMMENT '子单(no_mo)完结订单数',
    `no_mo_finish_ticket`       BIGINT  COMMENT '子单(no_mo)完结门票数',
    `no_mo_finish_cost_money`   BIGINT  COMMENT '子单(no_mo)完结成本价',
    `no_mo_finish_sale_money`   BIGINT  COMMENT '子单(no_mo)完结售价',
  
    `no_mo_revoke_ticket`       BIGINT  COMMENT '子单(no_mo)撤销门票数',
    `no_mo_revoke_num`          BIGINT  COMMENT '子单(no_mo)撤销订单数',
    `no_mo_revoke_cost_money`   BIGINT  COMMENT '子单(no_mo)撤销花费金额',
    `no_mo_revoke_sale_money`   BIGINT  COMMENT '子单(no_mo)撤销金额',

    `no_mo_after_sale_ticket_num`        BIGINT  COMMENT '子单(no_mo)售后数量',
    `no_mo_after_sale_refund_money`      BIGINT  COMMENT '子单(no_mo)售后退回金额',
    `no_mo_after_sale_income_money`      BIGINT  COMMENT '子单(no_mo)售后收入金额',
  
    `no_mo_print_num`           BIGINT  COMMENT '子单(no_mo)取票数量'
) 
COMMENT '预定/验证报表按日汇总数据'
PARTITIONED BY (`date` INT COMMENT '日期例如 20171010')
STORED AS ORC;


INSERT OVERWRITE TABLE dws_daily_report_summary_remain_d_i PARTITION(`date`)
SELECT 
    summaryTab.sid,
    `lid`,
    `p_type`,
    `mo_order_num`,
    `mo_order_ticket`,    
    `mo_order_cost_money`,        
    `mo_order_sale_money`,        
    `mo_cancel_num`,    
    `mo_cancel_ticket`,    
    `mo_cancel_cost_money`,        
    `mo_cancel_sale_money`,        
    `mo_verify_num`,    
    `mo_verify_ticket`,    
    `mo_verify_cost_money`,        
    `mo_verify_sale_money`,        
    `mo_finish_num`,    
    `mo_finish_ticket`,    
    `mo_finish_cost_money`,        
    `mo_finish_sale_money`,        
    `mo_revoke_ticket`,    
    `mo_revoke_num`,    
    `mo_revoke_cost_money`,        
    `mo_revoke_sale_money`,   
    `mo_after_sale_ticket_num`,          
    `mo_after_sale_refund_money`,       
    `mo_after_sale_income_money`,      
    `mo_print_num`,
    `no_mo_order_num`,    
    `no_mo_order_ticket`,        
    `no_mo_order_cost_money`,            
    `no_mo_order_sale_money`,            
    `no_mo_cancel_num`,    
    `no_mo_cancel_ticket`,        
    `no_mo_cancel_cost_money`,            
    `no_mo_cancel_sale_money`,            
    `no_mo_verify_num`,    
    `no_mo_verify_ticket`,        
    `no_mo_verify_cost_money`,            
    `no_mo_verify_sale_money`,            
    `no_mo_finish_num`,    
    `no_mo_finish_ticket`,        
    `no_mo_finish_cost_money`,            
    `no_mo_finish_sale_money`,            
    `no_mo_revoke_ticket`,        
    `no_mo_revoke_num`,    
    `no_mo_revoke_cost_money`,            
    `no_mo_revoke_sale_money`, 
    `no_mo_after_sale_ticket_num`,          
    `no_mo_after_sale_refund_money`,       
    `no_mo_after_sale_income_money`,                 
    `no_mo_print_num`,
    `date`
FROM dws_daily_report_summary_d_i summaryTab
JOIN (
    SELECT sid
    FROM dim_sid_white_list_d_f 
    WHERE pt = DATE_FORMAT(DATE_SUB(CURRENT_DATE(), 1),"yyyyMMdd")
) whiteTab
ON summaryTab.sid = whiteTab.sid
WHERE `date` = ${ds};