-- name dws_report_order_d_i
-- type Spark SQL
-- author liangleichen@12301.cc
-- create time 2023-09-11 20:25:01
-- desc 预定报表

SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;

CREATE TABLE IF NOT EXISTS `dws_report_order_d_i`(
    `sid`                       INT     COMMENT '用户ID',
    `lid`                       INT     COMMENT '景区ID',
    `pid`                       BIGINT  COMMENT '产品SPUID',
    `tid`                       INT     COMMENT '门票ID',
    `main_tid`                  INT     COMMENT '主单门票ID',
    `is_main_order`             INT     COMMENT '主子单',

    `order_num`                 BIGINT  COMMENT '预订订单数',
    `order_ticket`              BIGINT  COMMENT '预订门票数',
    `order_cost_money`          BIGINT  COMMENT '预订花费金额',
    `order_sale_money`          BIGINT  COMMENT '预定金额',

    `cancel_num`                BIGINT  COMMENT '取消订单数',
    `cancel_ticket`             BIGINT  COMMENT '取消门票数',
    `cancel_cost_money`         BIGINT  COMMENT '取消花费金额',
    `cancel_sale_money`         BIGINT  COMMENT '取消金额',

    `revoke_num`                BIGINT  COMMENT '撤销订单数',
    `revoke_ticket`             BIGINT  COMMENT '撤销门票数',
    `revoke_cost_money`         BIGINT  COMMENT '撤销花费金额',
    `revoke_sale_money`         BIGINT  COMMENT '撤销金额',

    `after_sale_ticket_num`     BIGINT  COMMENT '售后数量',
    `after_sale_refund_money`   BIGINT  COMMENT '售后退回金额',
    `after_sale_income_money`   BIGINT  COMMENT '售后收入金额',

    `print_num`                 BIGINT  COMMENT '取票数量',

    `pay_way`                   BIGINT  COMMENT '支付方式', 
    `channel`                   BIGINT  COMMENT '销售渠道', 
    `reseller_id`               BIGINT  COMMENT '分销商ID', 
    `level`                     TINYINT COMMENT '分销链层级'
)COMMENT ''
PARTITIONED BY (
    `date` INT COMMENT '日期 20171010'
)
STORED AS ORC;


INSERT OVERWRITE TABLE dws_report_order_d_i PARTITION(`date`)
SELECT 
    `fid`                           AS `sid`,
    `lid`                           AS `lid`, 
    `pid`                           AS `pid`, 
    `tid`                           AS `tid`, 
    `main_tid`                      AS `main_tid`, 
    IF(main_tid=0, 1, 0)            AS `is_main_order`,

    SUM(`order_num`)                AS `order_num`,        
    SUM(`order_ticket`)             AS `order_ticket`,     
    SUM(`cost_money`)               AS `order_cost_money`,       
    SUM(`sale_money`)               AS `order_sale_money`,  

    SUM(`cancel_num`)               AS `cancel_num`,       
    SUM(`cancel_ticket`)            AS `cancel_ticket`,    
    SUM(`cancel_cost_money`)        AS `cancel_cost_money`,
    SUM(`cancel_sale_money`)        AS `cancel_sale_money`,

    SUM(`revoke_num`)               AS `revoke_num`,       
    SUM(`revoke_ticket`)            AS `revoke_ticket`,    
    SUM(`revoke_cost_money`)        AS `revoke_cost_money`,
    SUM(`revoke_sale_money`)        AS `revoke_sale_money`,

    SUM(`after_sale_ticket_num`)    AS `after_sale_ticket_num`,
    SUM(`after_sale_refund_money`)  AS `after_sale_refund_money`,
    SUM(`after_sale_income_money`)  AS `after_sale_income_money`,

    SUM(`print_num`)                AS `print_num`,
    
    `pay_way`,    
    `channel`,    
    `reseller_id`,
    `level`,
    `date`
FROM ods_pft_report_order_two_d_i
WHERE `date`=${ds}
GROUP BY `fid`, `lid`, `pid`, `tid`, `main_tid`, IF(main_tid=0, 1, 0), pay_way, channel, reseller_id, level, `date`;