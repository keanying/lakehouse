-- name dws_report_checked_d_i
-- author liangleichen@12301.cc
-- create time 2023-09-12 21:09:56
-- desc 验证报表

SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;

CREATE TABLE IF NOT EXISTS `dws_report_checked_d_i`(
    `sid`                       INT     COMMENT '用户ID',
    `lid`                       INT     COMMENT '景区ID',
    `pid`                       BIGINT  COMMENT '产品SPUID',
    `tid`                       INT     COMMENT '门票ID',
    `main_tid`                  INT     COMMENT '主单门票ID',
    `is_main_order`             INT     COMMENT '是否为主单,1=主单,0=子单',

    `verify_num`                BIGINT  COMMENT '验证订单数',
    `verify_ticket`             BIGINT  COMMENT '验证门票数', 
    `verify_cost_money`         BIGINT  COMMENT '验证花费金额',
    `verify_sale_money`         BIGINT  COMMENT '验证金额',

    `finish_num`                BIGINT  COMMENT '完结订单数',
    `finish_ticket`             BIGINT  COMMENT '完结门票数',
    `finish_cost_money`         BIGINT  COMMENT '完结花费金额',
    `finish_sale_money`         BIGINT  COMMENT '完结金额',

    `revoke_ticket`             BIGINT  COMMENT '撤销门票数',
    `revoke_num`                BIGINT  COMMENT '撤销订单数',
    `revoke_cost_money`         BIGINT  COMMENT '撤销花费金额',
    `revoke_sale_money`         BIGINT  COMMENT '撤销金额',

    `after_sale_ticket_num`     BIGINT  COMMENT '售后数量',
    `after_sale_refund_money`   BIGINT  COMMENT '售后退回金额',
    `after_sale_income_money`   BIGINT  COMMENT '售后收入金额',

    `pay_way`                   BIGINT  COMMENT '支付方式', 
    `channel`                   BIGINT  COMMENT '销售渠道', 
    `reseller_id`               BIGINT  COMMENT '分销商ID', 
    `level`                     TINYINT COMMENT '分销链层级'
)COMMENT ''
PARTITIONED BY (
    `date` int COMMENT '日期例如20201010'
)
STORED AS ORC;


INSERT OVERWRITE TABLE dws_report_checked_d_i PARTITION(`date`)
SELECT 
    `fid`                           AS `sid`,
    `lid`                           AS `lid`, 
    `pid`                           AS `pid`, 
    `tid`                           AS `tid`, 
    `main_tid`                      AS `main_tid`,
    IF(main_tid=0, 1, 0)            AS `is_main_order`,

    SUM(`order_num`)                AS `verify_num`,        
    SUM(`order_ticket`)             AS `verify_ticket`,     
    SUM(`cost_money`)               AS `verify_cost_money`,       
    SUM(`sale_money`)               AS `verify_sale_money`,   

    SUM(`finish_num`)               AS `finish_num`,       
    SUM(`finish_ticket`)            AS `finish_ticket`,    
    SUM(`finish_cost_money`)        AS `finish_cost_money`,
    SUM(`finish_sale_money`)        AS `finish_sale_money`,
    
    SUM(`revoke_ticket`)            AS `revoke_ticket`,
    SUM(`revoke_num`)               AS `revoke_num`,       
    SUM(`revoke_cost_money`)        AS `revoke_cost_money`,
    SUM(`revoke_sale_money`)        AS `revoke_sale_money`,

    SUM(`after_sale_ticket_num`)    AS `after_sale_ticket_num`,
    SUM(`after_sale_refund_money`)  AS `after_sale_refund_money`,
    SUM(`after_sale_income_money`)  AS `after_sale_income_money`,
    
    `pay_way`,    
    `channel`,    
    `reseller_id`,
    `level`,
		`date`
FROM ods_pft_report_checked_two_d_i
WHERE `date`=${ds}
GROUP BY `fid`, `lid`, `pid`, `tid`, `main_tid`, IF(main_tid=0, 1, 0), pay_way, channel, reseller_id, level, `date`;

