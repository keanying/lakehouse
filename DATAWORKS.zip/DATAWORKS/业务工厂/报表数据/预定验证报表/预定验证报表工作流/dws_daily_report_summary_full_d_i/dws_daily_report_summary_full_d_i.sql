-- name dws_daily_report_summary_full_d_i
-- type Spark SQL
-- author wanghaiyang@12301.cc
-- create time 2024-07-22 16:20:42
-- desc 预定/验证报表全维度按日汇总数据

SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;

CREATE TABLE IF NOT EXISTS `dws_daily_report_summary_full_d_i` (
    `sid`                    INT     COMMENT '用户ID',
    `lid`                    INT     COMMENT '景区ID',
    `pid`                    BIGINT  COMMENT '产品SPUID',
    `tid`                    INT     COMMENT '门票ID',
    `p_type`                 STRING  COMMENT '景区类型：A景区B线路C酒店F套票',
    `main_tid`               INT     COMMENT '主订单门票ID',
    `is_main_order`          INT     COMMENT '主子单',
    `reseller_id`            INT     COMMENT '分销商ID',
    `level`                  INT     COMMENT '分销链层级',
    `pay_way`                INT     COMMENT '支付方式',
    `channel`                INT     COMMENT '销售渠道',       
  
    `order_num`              BIGINT  COMMENT '预订订单数',
    `order_ticket`           BIGINT  COMMENT '预订门票数',
    `order_cost_money`       BIGINT  COMMENT '预订花费金额',
    `order_sale_money`       BIGINT  COMMENT '预定金额',
  
    `cancel_num`             BIGINT  COMMENT '取消订单数',
    `cancel_ticket`          BIGINT  COMMENT '取消门票数',
    `cancel_cost_money`      BIGINT  COMMENT '取消花费金额',
    `cancel_sale_money`      BIGINT  COMMENT '取消金额',
  
    `verify_num`             BIGINT  COMMENT '验证订单数',
    `verify_ticket`          BIGINT  COMMENT '验证门票数',
	`verify_cost_money`      BIGINT  COMMENT '验证花费金额',
    `verify_sale_money`      BIGINT  COMMENT '验证金额',  

    `finish_num`             BIGINT  COMMENT '完结订单数',
    `finish_ticket`          BIGINT  COMMENT '完结门票数',
    `finish_cost_money`      BIGINT  COMMENT '成本价',
    `finish_sale_money`      BIGINT  COMMENT '售价',
  
    `revoke_ticket`          BIGINT  COMMENT '撤销门票数',
    `revoke_num`             BIGINT  COMMENT '撤销订单数',
    `revoke_cost_money`      BIGINT  COMMENT '撤销花费金额',
    `revoke_sale_money`      BIGINT  COMMENT '撤销金额',

    `after_sale_ticket_num`        BIGINT  COMMENT '售后数量',
    `after_sale_refund_money`      BIGINT  COMMENT '售后退回金额',
    `after_sale_income_money`      BIGINT  COMMENT '售后收入金额',
  
    `print_num`                    BIGINT  COMMENT '取票数量'
) 
COMMENT '预定/验证报表全维度按日汇总数据'
PARTITIONED BY (`date` INT COMMENT '日期例如20171010')
STORED AS ORC;

INSERT OVERWRITE TABLE dws_daily_report_summary_full_d_i PARTITION(`date`)
SELECT 
    `sid`                        AS `sid`,
    `lid`                        AS `lid`,
    NVL(ticketTab.pid, summaryTab.pid) 
                                 AS `pid`, 
    `tid`                        AS `tid`, 
    NVL(`p_type`, 'A')           AS `p_type`, 
    `main_tid`                   AS `main_tid`, 
    IF(main_tid=0, 1, 0)         AS `is_main_order`,
    `reseller_id`                AS `reseller_id`,
    `level`                      AS `level`,
    `pay_way`                    AS `pay_way`,
    `channel`                    AS `channel`,                  
    SUM(`order_num`)             AS `order_num`,       
    SUM(`order_ticket`)          AS `order_ticket`,        
    SUM(`order_cost_money`)      AS `order_cost_money`,        
    SUM(`order_sale_money`)      AS `order_sale_money`,

    SUM(`cancel_num`)            AS `cancel_num`,          
    SUM(`cancel_ticket`)         AS `cancel_ticket`,       
    SUM(`cancel_cost_money`)     AS `cancel_cost_money`,       
    SUM(`cancel_sale_money`)     AS `cancel_sale_money`,

    SUM(`verify_num`)            AS `verify_num`,          
    SUM(`verify_ticket`)         AS `verify_ticket`,       
    SUM(`verify_cost_money`)     AS `verify_cost_money`,       
    SUM(`verify_sale_money`)     AS `verify_sale_money`,

    SUM(`finish_num`)            AS `finish_num`,          
    SUM(`finish_ticket`)         AS `finish_ticket`,       
    SUM(`finish_cost_money`)     AS `finish_cost_money`,       
    SUM(`finish_sale_money`)     AS `finish_sale_money`,

    SUM(`revoke_ticket`)         AS `revoke_ticket`,       
    SUM(`revoke_num`)            AS `revoke_num`,          
    SUM(`revoke_cost_money`)     AS `revoke_cost_money`,       
    SUM(`revoke_sale_money`)     AS `revoke_sale_money`, 

    SUM(`after_sale_ticket_num`)       AS `after_sale_ticket_num`,          
    SUM(`after_sale_refund_money`)     AS `after_sale_refund_money`,       
    SUM(`after_sale_income_money`)     AS `after_sale_income_money`, 

    SUM(`print_num`)             AS `print_num`,
    `date`
FROM
(
    SELECT 
        `sid`,
        `lid`,
        `pid`,
        `tid`, 
        `main_tid`, 
        `reseller_id`,
        `level`,
        `pay_way`,
        `channel`,

        SUM(order_num)                                  AS `order_num`,   
        SUM(order_ticket)                               AS `order_ticket`,  
        SUM(order_cost_money)                           AS `order_cost_money`,    
        SUM(order_sale_money)                           AS `order_sale_money`, 

        SUM(cancel_num)                                 AS `cancel_num`,    
        SUM(cancel_ticket)                              AS `cancel_ticket`,    
        SUM(cancel_cost_money)                          AS `cancel_cost_money`, 
        SUM(cancel_sale_money)                          AS `cancel_sale_money`, 

        0                                               AS `verify_num`,       
        0                                               AS `verify_ticket`,    
        0                                               AS `verify_cost_money`,
        0                                               AS `verify_sale_money`,

        0                                               AS `finish_num`,       
        0                                               AS `finish_ticket`,    
        0                                               AS `finish_cost_money`,
        0                                               AS `finish_sale_money`,

        0                                               AS `revoke_ticket`,    
        0                                               AS `revoke_num`,       
        0                                               AS `revoke_cost_money`,
        0                                               AS `revoke_sale_money`,

        SUM(after_sale_ticket_num)                      AS `after_sale_ticket_num`,  
        SUM(after_sale_refund_money)                    AS `after_sale_refund_money`,    
        SUM(after_sale_income_money)                    AS `after_sale_income_money`, 

        SUM(print_num)                                  AS `print_num`,
        `date`
    FROM dws_report_order_d_i
    WHERE `date` =${ds}
    GROUP BY sid, lid, pid, tid, main_tid, reseller_id, level, pay_way, channel, `date`

    UNION ALL 

    SELECT   
        `sid`,
        `lid`,
        `pid`,
        `tid`,
        `main_tid`,   
        `reseller_id`,
        `level`,
        `pay_way`,
        `channel`,

        0                                                   AS `order_num`,   
        0                                                   AS `order_ticket`,  
        0                                                   AS `order_cost_money`,    
        0                                                   AS `order_sale_money`, 

        0                                                   AS `cancel_num`,    
        0                                                   AS `cancel_ticket`,    
        0                                                   AS `cancel_cost_money`, 
        0                                                   AS `cancel_sale_money`, 
        
        SUM(`verify_num`)                                   AS `verify_num`,       
        SUM(`verify_ticket`)                                AS `verify_ticket`,    
        SUM(`verify_cost_money`)                            AS `verify_cost_money`,
        SUM(`verify_sale_money`)                            AS `verify_sale_money`,

        SUM(`finish_num`)                                   AS `finish_num`,       
        SUM(`finish_ticket`)                                AS `finish_ticket`,    
        SUM(`finish_cost_money`)                            AS `finish_cost_money`,
        SUM(`finish_sale_money`)                            AS `finish_sale_money`,

        SUM(`revoke_ticket`)                                AS `revoke_ticket`,    
        SUM(`revoke_num`)                                   AS `revoke_num`,       
        SUM(`revoke_cost_money`)                            AS `revoke_cost_money`,
        SUM(`revoke_sale_money`)                            AS `revoke_sale_money`,

        0                                                   AS `after_sale_ticket_num`,  
        0                                                   AS `after_sale_refund_money`,    
        0                                                   AS `after_sale_income_money`, 

        0                                                   AS `print_num`, 

        `date`
    FROM dws_report_checked_d_i
    WHERE `date` =${ds}
    GROUP BY sid, lid, pid, tid, main_tid, reseller_id, level, pay_way, channel, `date`
) summaryTab
LEFT JOIN (
    SELECT id, p_type
    FROM ods_land_d_f
    WHERE pt = DATE_FORMAT(DATE_SUB(CURRENT_DATE(), 1),"yyyyMMdd")
) landTab
ON summaryTab.lid = landTab.id
LEFT JOIN (
    SELECT id, pid
    FROM ods_ticket_d_f
    WHERE pt = DATE_FORMAT(DATE_SUB(CURRENT_DATE(), 1),"yyyyMMdd")
) ticketTab
ON summaryTab.tid = ticketTab.id
GROUP BY sid, lid, NVL(ticketTab.pid, summaryTab.pid), tid, p_type, main_tid, reseller_id, level, pay_way, channel, `date`;
