-- name dws_daily_report_ticket_summary_hour_d_i
-- type Spark SQL
-- author wanghaiyang@12301.cc
-- create time 2024-10-16 16:42:31
-- desc 预定验证报表门票维度按小时汇总数据

CREATE TABLE IF NOT EXISTS `dws_daily_report_ticket_summary_hour_d_i` (
    `sid`                               INT     COMMENT '用户ID',
    `lid`                               INT     COMMENT '景区ID',
    `pid`                               BIGINT  COMMENT '产品SPUID',
    `tid`                               INT     COMMENT '门票ID',
    `hour`                              INT     COMMENT '小时',
    `p_type`                            STRING  COMMENT '景区类型：A景区B线路C酒店F套票',

    `mo_order_num`                      BIGINT  COMMENT '主单(mo)预订订单数',
    `mo_order_ticket`                   BIGINT  COMMENT '主单(mo)预订门票数',
    `mo_order_cost_money`               BIGINT  COMMENT '主单(mo)预订花费金额',
    `mo_order_sale_money`               BIGINT  COMMENT '主单(mo)预定金额',
  
    `mo_cancel_num`                     BIGINT  COMMENT '主单(mo)取消订单数',
    `mo_cancel_ticket`                  BIGINT  COMMENT '主单(mo)取消门票数',
    `mo_cancel_cost_money`              BIGINT  COMMENT '主单(mo)取消花费金额',
    `mo_cancel_sale_money`              BIGINT  COMMENT '主单(mo)取消金额',
  
    `mo_verify_num`                     BIGINT  COMMENT '主单(mo)验证订单数',
    `mo_verify_ticket`                  BIGINT  COMMENT '主单(mo)验证门票数',
	`mo_verify_cost_money`              BIGINT  COMMENT '主单(mo)验证花费金额',
    `mo_verify_sale_money`              BIGINT  COMMENT '主单(mo)验证金额',  

    `mo_finish_num`                     BIGINT  COMMENT '主单(mo)完结订单数',
    `mo_finish_ticket`                  BIGINT  COMMENT '主单(mo)完结门票数',
    `mo_finish_cost_money`              BIGINT  COMMENT '主单(mo)成本价',
    `mo_finish_sale_money`              BIGINT  COMMENT '主单(mo)售价',
  
    `mo_revoke_ticket`                  BIGINT  COMMENT '主单(mo)撤销门票数',
    `mo_revoke_num`                     BIGINT  COMMENT '主单(mo)撤销订单数',
    `mo_revoke_cost_money`              BIGINT  COMMENT '主单(mo)撤销花费金额',
    `mo_revoke_sale_money`              BIGINT  COMMENT '主单(mo)撤销金额',

    `mo_after_sale_ticket_num`          BIGINT  COMMENT '主单(mo)售后数量',
    `mo_after_sale_refund_money`        BIGINT  COMMENT '主单(mo)售后退回金额',
    `mo_after_sale_income_money`        BIGINT  COMMENT '主单(mo)售后收入金额',
  
    `mo_print_num`                      BIGINT  COMMENT '主单(mo)取票数量',
  
  
    `no_mo_order_num`                   BIGINT  COMMENT '子单(no_mo)预订订单数',
    `no_mo_order_ticket`                BIGINT  COMMENT '子单(no_mo)预订门票数',
    `no_mo_order_cost_money`            BIGINT  COMMENT '子单(no_mo)预订花费金额',
    `no_mo_order_sale_money`            BIGINT  COMMENT '子单(no_mo)预定金额',
  
    `no_mo_cancel_num`                  BIGINT  COMMENT '子单(no_mo)取消订单数',
    `no_mo_cancel_ticket`               BIGINT  COMMENT '子单(no_mo)取消门票数',
    `no_mo_cancel_cost_money`           BIGINT  COMMENT '子单(no_mo)取消花费金额',
    `no_mo_cancel_sale_money`           BIGINT  COMMENT '子单(no_mo)取消金额',
  
    `no_mo_verify_num`                  BIGINT  COMMENT '子单(no_mo)验证订单数',
    `no_mo_verify_ticket`               BIGINT  COMMENT '子单(no_mo)验证门票数',
    `no_mo_verify_cost_money`           BIGINT  COMMENT '子单(no_mo)验证花费金额',
    `no_mo_verify_sale_money`           BIGINT  COMMENT '子单(no_mo)验证金额',
  
    `no_mo_finish_num`                  BIGINT  COMMENT '子单(no_mo)完结订单数',
    `no_mo_finish_ticket`               BIGINT  COMMENT '子单(no_mo)完结门票数',
    `no_mo_finish_cost_money`           BIGINT  COMMENT '子单(no_mo)成本价',
    `no_mo_finish_sale_money`           BIGINT  COMMENT '子单(no_mo)售价',
  
    `no_mo_revoke_ticket`               BIGINT  COMMENT '子单(no_mo)撤销门票数',
    `no_mo_revoke_num`                  BIGINT  COMMENT '子单(no_mo)撤销订单数',
    `no_mo_revoke_cost_money`           BIGINT  COMMENT '子单(no_mo)撤销花费金额',
    `no_mo_revoke_sale_money`           BIGINT  COMMENT '子单(no_mo)撤销金额',

    `no_mo_after_sale_ticket_num`       BIGINT  COMMENT '子单(no_mo)售后数量',
    `no_mo_after_sale_refund_money`     BIGINT  COMMENT '子单(no_mo)售后退回金额',
    `no_mo_after_sale_income_money`     BIGINT  COMMENT '子单(no_mo)售后收入金额',
  
    `no_mo_print_num`                   BIGINT  COMMENT '子单(no_mo)取票数量'
) 
COMMENT '预定验证报表门票维度按小时汇总数据'
PARTITIONED BY (`date` INT COMMENT '日期例如20171010')
STORED AS ORC;

INSERT OVERWRITE TABLE dws_daily_report_ticket_summary_hour_d_i PARTITION(`date`=${ds})
SELECT
    `sid`                               AS `sid`,                    
    `lid`                               AS `lid`,   
    `pid`                               AS `pid`,                 
    `tid`                               AS `tid`,
    cast(substr(date_hour, -2) as int)  AS `hour`,
    `p_type`                            AS `p_type`,                     

    SUM(mo_order_num)                   AS `mo_order_num`,       
    SUM(mo_order_ticket)                AS `mo_order_ticket`,        
    SUM(mo_order_cost_money)            AS `mo_order_cost_money`,        
    SUM(mo_order_sale_money)            AS `mo_order_sale_money`,

    SUM(mo_cancel_num)                  AS `mo_cancel_num`,          
    SUM(mo_cancel_ticket)               AS `mo_cancel_ticket`,       
    SUM(mo_cancel_cost_money)           AS `mo_cancel_cost_money`,       
    SUM(mo_cancel_sale_money)           AS `mo_cancel_sale_money`,

    SUM(mo_verify_num)                  AS `mo_verify_num`,          
    SUM(mo_verify_ticket)               AS `mo_verify_ticket`,       
    SUM(mo_verify_cost_money)           AS `mo_verify_cost_money`,       
    SUM(mo_verify_sale_money)           AS `mo_verify_sale_money`,

    SUM(mo_finish_num)                  AS `mo_finish_num`,          
    SUM(mo_finish_ticket)               AS `mo_finish_ticket`,       
    SUM(mo_finish_cost_money)           AS `mo_finish_cost_money`,       
    SUM(mo_finish_sale_money)           AS `mo_finish_sale_money`,

    SUM(mo_revoke_ticket)               AS `mo_revoke_ticket`,       
    SUM(mo_revoke_num)                  AS `mo_revoke_num`,          
    SUM(mo_revoke_cost_money)           AS `mo_revoke_cost_money`,       
    SUM(mo_revoke_sale_money)           AS `mo_revoke_sale_money`, 

    SUM(mo_after_sale_ticket_num)       AS `mo_after_sale_ticket_num`,          
    SUM(mo_after_sale_refund_money)     AS `mo_after_sale_refund_money`,       
    SUM(mo_after_sale_income_money)     AS `mo_after_sale_income_money`, 

    SUM(mo_print_num)                   AS `mo_print_num`,

    SUM(no_mo_order_num)                AS `no_mo_order_num`,        
    SUM(no_mo_order_ticket)             AS `no_mo_order_ticket`,         
    SUM(no_mo_order_cost_money)         AS `no_mo_order_cost_money`,         
    SUM(no_mo_order_sale_money)         AS `no_mo_order_sale_money`,

    SUM(no_mo_cancel_num)               AS `no_mo_cancel_num`,       
    SUM(no_mo_cancel_ticket)            AS `no_mo_cancel_ticket`,        
    SUM(no_mo_cancel_cost_money)        AS `no_mo_cancel_cost_money`,        
    SUM(no_mo_cancel_sale_money)        AS `no_mo_cancel_sale_money`,

    SUM(no_mo_verify_num)               AS `no_mo_verify_num`,       
    SUM(no_mo_verify_ticket)            AS `no_mo_verify_ticket`,        
    SUM(no_mo_verify_cost_money)        AS `no_mo_verify_cost_money`,        
    SUM(no_mo_verify_sale_money)        AS `no_mo_verify_sale_money`,

    SUM(no_mo_finish_num)               AS `no_mo_finish_num`,       
    SUM(no_mo_finish_ticket)            AS `no_mo_finish_ticket`,        
    SUM(no_mo_finish_cost_money)        AS `no_mo_finish_cost_money`,        
    SUM(no_mo_finish_sale_money)        AS `no_mo_finish_sale_money`,

    SUM(no_mo_revoke_ticket)            AS `no_mo_revoke_ticket`,        
    SUM(no_mo_revoke_num)               AS `no_mo_revoke_num`,       
    SUM(no_mo_revoke_cost_money)        AS `no_mo_revoke_cost_money`,        
    SUM(no_mo_revoke_sale_money)        AS `no_mo_revoke_sale_money`,

    SUM(no_mo_after_sale_ticket_num)    AS `no_mo_after_sale_ticket_num`,          
    SUM(no_mo_after_sale_refund_money)  AS `no_mo_after_sale_refund_money`,       
    SUM(no_mo_after_sale_income_money)  AS `no_mo_after_sale_income_money`, 

    SUM(no_mo_print_num)                AS `no_mo_print_num`
FROM(
    SELECT 
        `date_hour`,
        `sid`,                    
        `lid`,   
        `pid`,                 
        `tid`,
        `p_type`,                     

        IF(is_main_order=1, order_num, 0)                   AS `mo_order_num`,       
        IF(is_main_order=1, order_ticket, 0)                AS `mo_order_ticket`,        
        IF(is_main_order=1, order_cost_money, 0)            AS `mo_order_cost_money`,        
        IF(is_main_order=1, order_sale_money, 0)            AS `mo_order_sale_money`,

        IF(is_main_order=1, cancel_num, 0)                  AS `mo_cancel_num`,          
        IF(is_main_order=1, cancel_ticket, 0)               AS `mo_cancel_ticket`,       
        IF(is_main_order=1, cancel_cost_money, 0)           AS `mo_cancel_cost_money`,       
        IF(is_main_order=1, cancel_sale_money, 0)           AS `mo_cancel_sale_money`,

        IF(is_main_order=1, verify_num, 0)                  AS `mo_verify_num`,          
        IF(is_main_order=1, verify_ticket, 0)               AS `mo_verify_ticket`,       
        IF(is_main_order=1, verify_cost_money, 0)           AS `mo_verify_cost_money`,       
        IF(is_main_order=1, verify_sale_money, 0)           AS `mo_verify_sale_money`,

        IF(is_main_order=1, finish_num, 0)                  AS `mo_finish_num`,          
        IF(is_main_order=1, finish_ticket, 0)               AS `mo_finish_ticket`,       
        IF(is_main_order=1, finish_cost_money, 0)           AS `mo_finish_cost_money`,       
        IF(is_main_order=1, finish_sale_money, 0)           AS `mo_finish_sale_money`,

        IF(is_main_order=1, revoke_ticket, 0)               AS `mo_revoke_ticket`,       
        IF(is_main_order=1, revoke_num, 0)                  AS `mo_revoke_num`,          
        IF(is_main_order=1, revoke_cost_money, 0)           AS `mo_revoke_cost_money`,       
        IF(is_main_order=1, revoke_sale_money, 0)           AS `mo_revoke_sale_money`, 

        IF(is_main_order=1, after_sale_ticket_num, 0)       AS `mo_after_sale_ticket_num`,          
        IF(is_main_order=1, after_sale_refund_money, 0)     AS `mo_after_sale_refund_money`,       
        IF(is_main_order=1, after_sale_income_money, 0)     AS `mo_after_sale_income_money`, 

        IF(is_main_order=1, print_num, 0)                   AS `mo_print_num`,

        IF(is_main_order=0, order_num, 0)                   AS `no_mo_order_num`,        
        IF(is_main_order=0, order_ticket, 0)                AS `no_mo_order_ticket`,         
        IF(is_main_order=0, order_cost_money, 0)            AS `no_mo_order_cost_money`,         
        IF(is_main_order=0, order_sale_money, 0)            AS `no_mo_order_sale_money`,

        IF(is_main_order=0, cancel_num, 0)                  AS `no_mo_cancel_num`,       
        IF(is_main_order=0, cancel_ticket, 0)               AS `no_mo_cancel_ticket`,        
        IF(is_main_order=0, cancel_cost_money, 0)           AS `no_mo_cancel_cost_money`,        
        IF(is_main_order=0, cancel_sale_money, 0)           AS `no_mo_cancel_sale_money`,

        IF(is_main_order=0, verify_num, 0)                  AS `no_mo_verify_num`,       
        IF(is_main_order=0, verify_ticket, 0)               AS `no_mo_verify_ticket`,        
        IF(is_main_order=0, verify_cost_money, 0)           AS `no_mo_verify_cost_money`,        
        IF(is_main_order=0, verify_sale_money, 0)           AS `no_mo_verify_sale_money`,

        IF(is_main_order=0, finish_num, 0)                  AS `no_mo_finish_num`,       
        IF(is_main_order=0, finish_ticket, 0)               AS `no_mo_finish_ticket`,        
        IF(is_main_order=0, finish_cost_money, 0)           AS `no_mo_finish_cost_money`,        
        IF(is_main_order=0, finish_sale_money, 0)           AS `no_mo_finish_sale_money`,

        IF(is_main_order=0, revoke_ticket, 0)               AS `no_mo_revoke_ticket`,        
        IF(is_main_order=0, revoke_num, 0)                  AS `no_mo_revoke_num`,       
        IF(is_main_order=0, revoke_cost_money, 0)           AS `no_mo_revoke_cost_money`,        
        IF(is_main_order=0, revoke_sale_money, 0)           AS `no_mo_revoke_sale_money`,

        IF(is_main_order=0, after_sale_ticket_num, 0)       AS `no_mo_after_sale_ticket_num`,          
        IF(is_main_order=0, after_sale_refund_money, 0)     AS `no_mo_after_sale_refund_money`,       
        IF(is_main_order=0, after_sale_income_money, 0)     AS `no_mo_after_sale_income_money`, 

        IF(is_main_order=0, print_num, 0)                   AS `no_mo_print_num`  
    FROM dws_daily_report_summary_hour_full_d_i 
    WHERE `date`=${ds}
) tmp
GROUP BY date_hour, sid, lid, pid, tid, p_type;