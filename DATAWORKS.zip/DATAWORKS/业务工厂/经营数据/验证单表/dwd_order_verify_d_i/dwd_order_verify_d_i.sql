--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-18 15:05:15
--EMR任务只能运行在独享资源组上
--********************************************************************--

CREATE TABLE IF NOT EXISTS `dwd_order_verify_d_i`(
    `order_id`                      STRING  COMMENT '订单id', 
    `sid`                           STRING  COMMENT '商户id', 
    `vertify_datetime`              STRING  COMMENT '验证时间', 
    `vertify_year`                  STRING  COMMENT '验证年,例2021', 
    `vertify_month`                 STRING  COMMENT '验证年份,202101', 
    `vertify_quarter`               STRING  COMMENT '验证季度,202104', 
    `vertify_week`                  STRING  COMMENT '验证周,ISOWeek,例202141', 
    `vertify_hour`                  STRING  COMMENT '验证小时,例08', 
    `land_province`                 STRING  COMMENT '景区所在省', 
    `land_city`                     STRING  COMMENT '景区所在市', 
    `ticket_taker_province_idcard`  STRING  COMMENT '取票人所在省,以身份证划定', 
    `ticket_taker_city_idcard`      STRING  COMMENT '取票人所在市,以身份证划定', 
    `booking_num`                   INT     COMMENT '预订票数量', 
    `booking_ticket_avg_money`      DOUBLE  COMMENT '预订票平均票价', 
    `vertify_num`                   INT     COMMENT '本次验证票数', 
    `vertify_money`                 INT     COMMENT '本次验证金额', 
    `member_kind`                   STRING  COMMENT '商户类型', 
    `member_type`                   STRING  COMMENT '商户业态'
)
PARTITIONED BY (
    `vertify_date` date
)STORED AS ORC;


INSERT OVERWRITE table dwd_order_verify_d_i PARTITION(vertify_date) 
SELECT 
    `order_id`,
    `sid`,
    `vertify_datetime`,
    `vertify_year`,
    `vertify_month`,
    `vertify_quarter`,
    `vertify_week`,
    `vertify_hour`,
    `land_province`,
    `land_city`,
    `ticket_taker_province_idcard`,
    `ticket_taker_city_idcard`,
    `booking_num`,
    `booking_ticket_avg_money`,
    `vertify_num`,
    `vertify_money`,
    `member_kind`,
    `member_type`,
    `vertify_date`
    --`is_test_user`
FROM (  
    SELECT  
        ods_track.order_id                              AS `order_id`,
        ods_track.apply_did                             AS `sid`,
        ods_track.action_time                           AS `vertify_datetime`,
        YEAR(ods_track.action_time)                     AS `vertify_year`,
        YEAR(ods_track.action_time) * 100 + MONTH(ods_track.action_time)        AS `vertify_month`,
        YEAR(ods_track.action_time) * 100 + QUARTER(ods_track.action_time)      AS `vertify_quarter`,
        dim_isoweek.isoweek                             AS `vertify_week`,
        HOUR(ods_track.action_time)                     AS `vertify_hour`,
        dwd_order.land_province                         AS `land_province`,
        dwd_order.land_city                             AS `land_city`,
        dwd_order.ticket_taker_province_idcard          AS `ticket_taker_province_idcard`,
        dwd_order.ticket_taker_city_idcard              AS `ticket_taker_city_idcard`,
        ods_track.booking_ticket_num                    AS `booking_num`,
        dwd_order.booking_ticket_avg_money              AS `booking_ticket_avg_money`,
        ods_track.vertify_ticket_num                                            AS `vertify_num`,
        ods_track.vertify_ticket_num * dwd_order.booking_ticket_avg_money       AS `vertify_money`,
                
        --商户类型
        business_message.corp_kind                      AS `member_kind`,
        --商户业态
        business_message.format_type                    AS `member_type`,
            
        --商户类型, 为2的是测试账户
        member_base.group_id                            AS `is_test_user`,
        TO_DATE(ods_track.action_time)                  AS `vertify_date`
    FROM 
    (
        -- 订单验证信息
        SELECT  
            order_id,
            ticket_id,
            booking_ticket_num,
            apply_did,
            action_time,
            vertify_ticket_num
        FROM ods_pft_order_track_d_f
        WHERE pt='pt'
        --   AND action = 5
          AND vertify_ticket_num > 0
          AND TO_DATE(action_time) = DATE_SUB(FROM_UNIXTIME(UNIX_TIMESTAMP(),'yyyy-MM-dd'),1)
        --   AND TO_DATE(action_time) >= '2022-01-01'
        --   AND TO_DATE(action_time) <= '2022-12-31'
    ) AS ods_track
    LEFT JOIN 
    (   
        SELECT  
            order_id,
            land_province,
            land_city,
            ticket_taker_province_idcard,
            ticket_taker_city_idcard,
            booking_pay_amount / booking_num    AS booking_ticket_avg_money
        FROM dwd_order_d_i
        WHERE booking_date >= '${ds732}'
          AND booking_num > 0
    ) AS dwd_order
    ON ods_track.order_id = dwd_order.order_id
    LEFT JOIN 
    (   --商家类型和业态
        SELECT  
            fid,
            corp_kind,
            format_type
        FROM ods_myuu_pft_member_extinfo_d_f
        WHERE pt = FROM_UNIXTIME(UNIX_TIMESTAMP(DATE_SUB(CURRENT_DATE, 1)), 'yyyyMMdd')
    ) AS business_message
    ON ods_track.apply_did = business_message.fid
    LEFT JOIN 
    (   
        SELECT  
            id,
            group_id 
        FROM s_myuu_pft_member_d_f
        WHERE pt = FROM_UNIXTIME(UNIX_TIMESTAMP(DATE_SUB(CURRENT_DATE, 1)), 'yyyyMMdd')
    ) AS member_base
    ON member_base.id = business_message.fid
    LEFT JOIN dim_date_isoweek_o_f AS dim_isoweek 
    ON TO_DATE(ods_track.action_time) = dim_isoweek.`date`
)
WHERE is_test_user != 2

