--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-18 11:58:07
--EMR任务只能运行在独享资源组上
--********************************************************************--


-- desc 服务商户,每日运行全量数据

--DROP TABLE dwd_service_business_d_f;

CREATE TABLE IF NOT EXISTS dwd_service_business_d_f(
    `member_id`         STRING  COMMENT '商户id',

    `member_kind`       STRING  COMMENT '商户类型',
    `member_type`       STRING  COMMENT '商户业态',

    `province`          STRING  COMMENT '商户所在省',
    `city`              STRING  COMMENT '商户所在市',
    
    `start_time`        DATE    COMMENT '开始服务日期',
    `end_time`          DATE    COMMENT '最后服务日期'
)PARTITIONED BY(
    `pt` STRING  
)STORED AS ORC;
 

INSERT OVERWRITE table dwd_service_business_d_f PARTITION(pt='${ds}') 
SELECT 
    member_id,
    member_kind,
    member_type,
    province,
    city,
    start_time          AS start_time,
    end_time            AS end_time
    -- to_date(FROM_UNIXTIME(start_time, 'yyyy-MM-dd'))    AS start_time,
    -- to_date(FROM_UNIXTIME(end_time, 'yyyy-MM-dd'))      AS end_time
FROM 
(
    SELECT  
        member_id                               AS member_id,
        business_message.corp_kind              AS member_kind,
        business_message.format_type            AS member_type,
        area_info.customer_province             AS province,
        area_info.customer_city                 AS city,
        -- FROM_UNIXTIME(start_time,'yyyy-MM-dd')  AS start_time,
        -- FROM_UNIXTIME(end_time,'yyyy-MM-dd')    AS end_time,
        TO_DATE(FROM_UNIXTIME(start_time,'yyyy-MM-dd')) AS start_time,
        TO_DATE(FROM_UNIXTIME(end_time,'yyyy-MM-dd'))   AS end_time,
        --商户类型, 为2的是测试账户
        member_base.group_id                    AS is_test_user
    FROM (   -- 开通功能模块或套餐应用的用户, 最大开始服务时间, 最晚服务终止时间
        SELECT  
            member_id,
            MIN(service_start_time)     AS start_time,
            MAX(service_real_end_time)  AS end_time
        FROM 
        (   -- 功能模块使用情况
            SELECT  
                member_id,
                GET_JSON_OBJECT(time_details, '$.start_time')       AS service_start_time,
                IF(
                    GET_JSON_OBJECT(time_details, '$.stop_time') == '' or GET_JSON_OBJECT(time_details, '$.stop_time') is null,
                    GET_JSON_OBJECT(time_details, '$.end_time'),
                    GET_JSON_OBJECT(time_details, '$.stop_time')
                )                                                   AS service_real_end_time
            FROM (   -- "用户使用应用扩展记录表" 取出 "用户id", "终止相关时间记录", "模块ID"
                SELECT  
                    member_id,
                    time_details,
                    module_id
                FROM ods_pft_module_used_ext_d_f
                WHERE pt = '${ds}'
            ) AS module_used_ext 
            LEFT JOIN (   -- "功能模块价格配置", 取出"功能模块ID/套餐ID", 条件: "类型为功能模块" 且 "费用非空"
                SELECT target_id
                FROM ods_pft001_pft_module_price_d_f
                WHERE pt = '${ds}'
                  AND type = 1
                  AND fee > 0
            ) AS module_price
            ON module_used_ext.module_id=module_price.target_id 
                        
            UNION ALL

            -- 套餐应用开通情况
            SELECT  
                mpkgl.member_id,
                GET_JSON_OBJECT(mpkgle.time_details, '$.start_time')    AS service_start_time,
                IF(
                    GET_JSON_OBJECT(mpkgle.time_details, '$.stop_time') == '' or GET_JSON_OBJECT(mpkgle.time_details, '$.stop_time') is NULL ,
                    GET_JSON_OBJECT(mpkgle.time_details, '$.end_time'),
                    GET_JSON_OBJECT(mpkgle.time_details, '$.stop_time')
                )                                                       AS service_real_end_time
            FROM 
            (   -- 用户开通套餐情况, "自增id", "套餐id", "用户id"
                SELECT  
                    id,
                    package_id,
                    member_id
                FROM ods_pft001_pft_module_package_log_d_f
                WHERE pt = '${ds}'
            ) AS mpkgl
            LEFT JOIN 
            (   -- 用户开通套餐情况扩展表, "套餐开通日志id", "相关时间记录"
                SELECT  
                    package_log_id,
                    time_details
                FROM ods_pft001_pft_module_package_log_ext_d_f
                WHERE pt = '${ds}'
            ) AS mpkgle 
            ON mpkgl.id=mpkgle.package_log_id
            LEFT JOIN 
            (   -- 功能模块价格配置表, "功能模块ID/套餐ID", "费用". 条件: 类型为"套餐id" and "价格非空"
                SELECT  
                    target_id, 
                    fee
                FROM ods_pft001_pft_module_price_d_f
                WHERE pt='${ds}' 
                  AND type = 2 
                  AND fee > 0
            ) AS mp 
            ON mpkgl.package_id=mp.target_id
        )
        GROUP BY member_id
        HAVING start_time > 0 
          AND end_time > 0
    ) AS server_business
    LEFT JOIN (   
        -- 商家类型和业态
        -- 会员详细资料表, "商户id", "公司类型", "公司业态"
        SELECT  
            fid,
            corp_kind,
            format_type
        FROM ods_myuu_pft_member_extinfo_d_f
        WHERE pt = '${ds}' 
    ) AS business_message
    ON server_business.member_id = business_message.fid
    LEFT JOIN (   
        -- 景区维表, "景区id", "景区所在省", "景区所在城市"
        SELECT  
            user_id,
            customer_province,
            customer_city
        FROM dim_user_d_f
        WHERE pt = '${ds}' 
    ) AS area_info
    ON server_business.member_id = area_info.user_id
    LEFT JOIN (   
        -- 商户分组, 2为测试商户
        SELECT  
            id,
            group_id,
            account 
        FROM s_myuu_pft_member_d_f
        WHERE pt = '${ds}'
        -- 此商户为测试商户, 但group_id为1, 单独过滤!!
          AND account != 70801726
    ) AS member_base
    ON member_base.id = business_message.fid
)
WHERE is_test_user != 2 

