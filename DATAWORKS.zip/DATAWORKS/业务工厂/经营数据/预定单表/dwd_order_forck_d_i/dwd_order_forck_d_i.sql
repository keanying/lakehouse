--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-15 16:48:17
--EMR任务只能运行在独享资源组上
--********************************************************************--


INSERT OVERWRITE TABLE dwd_order_forck_d_i PARTITION (pt="${ds}") 
SELECT 
    '${ds}' AS stat_date,
    current_date()   AS dw_ins_time,
    order_id,
    main_order_id,
    order_type,
    remote_order_id,
    is_team,
    team_order_id,
    order_status_code,
    order_status,
    order_pay_status, 
    booking_time,
    verify_time,
    cancel_time,
    play_time,
    begin_time,
    end_time, 
    pre_booked_days, 
    verify_code,
    cancel_status, 
    seller_id, 
    booker_id, 
    booker_name, 
    booker_type,
    distribute_system_type,
    distribute_system_name,
    booking_channel,
    booking_channel_name,
    distribute_num, 
    distributor_id, 
    distributor_name, 
    distributor_type, 
    distributor_group, 
    distributor_is_OTA,
    distribute_1_type,
    distributor_price, 
    distributor_amount, 
    booking_price,
    ticket_num,
    order_pay_amount,
    use_coupon,
    non_refund_withdraw,
    pay_funding_type, 
    ticket_taker_name, 
    ticket_taker_mobile,
    ticket_taker_idcard, 
    ticket_taker_age,
    ticket_taker_sex, 
    ticket_taker_province,
    ticket_taker_city,
    ticket_taker_country,    
    ticket_zip_code,
    ticket_taker_adcode,
    is_around,
    land_type,
    land_type_name,
    land_topic,
    resource_id,
    resource_name,
    product_id,
    ticket_id,
    ticket_fullname,
    land_id,
    land_name,
    land_publisher_id,
    land_publisher_name,
    land_province,
    land_city,    
    land_country,
    land_zip_code,
    land_adcode,
    order_is_test,
    resource_center_supplier_id,
    resource_center_purchase_id,
    mall_supplier_account_id,
    mall_distinguish,
    purchase_system,
    purchase_system_code,
    booking_num,
    add_ticket_time,
    add_ticket_num,
    booking_pay_amount,
    record_id,
    resource_land_id,
    resource_land_name,
    ticket_taker_province_idcard, 
    ticket_taker_city_idcard, 
    ticket_taker_county_idcard,
    pay_time,
    expiration_time,
    HOUR(booking_time)             AS `booking_hour`,
    YEAR(booking_time)             AS `booking_year`,
    YEAR(booking_time) * 100 + MONTH(booking_time)               AS `booking_month`,
    -- 彻底替换为EXTRACT函数提取周数
    IF(booking_time IS NOT NULL, EXTRACT(WEEK FROM booking_time), NULL)  AS `booking_week`,
    YEAR(booking_time) * 100 + QUARTER(booking_time)             AS `booking_quarter`,
    booking_date,

    HOUR(cancel_time)                                            AS `cancel_hour`,
    YEAR(cancel_time)                                            AS `cancel_year`,
    YEAR(cancel_time) * 100 + MONTH(cancel_time)                 AS `cancel_month`,
    -- 彻底替换为EXTRACT函数提取周数
    IF(cancel_time IS NOT NULL, EXTRACT(WEEK FROM cancel_time), NULL)    AS `cancel_week`,
    YEAR(cancel_time) * 100 + QUARTER(cancel_time)               AS `cancel_quarter`,
    SUBSTR(cancel_time, 0, 10)                                   AS `cancel_date`,

    YEAR(play_time)                                             AS `play_year`,
    YEAR(play_time) * 100 + MONTH(play_time)                    AS `play_month`,
    -- 彻底替换为EXTRACT函数提取周数
    IF(play_time IS NOT NULL, EXTRACT(WEEK FROM play_time), NULL)       AS `play_week`,
    YEAR(play_time) * 100 + QUARTER(play_time)                  AS `play_quarter`,
    SUBSTR(play_time, 0, 10)                                    AS `play_date`,

    HOUR(pay_time)                                              AS `pay_hour`,
    YEAR(pay_time)                                              AS `pay_year`,
    YEAR(pay_time) * 100 + MONTH(pay_time)                      AS `pay_month`,
    -- 彻底替换为EXTRACT函数提取周数
    IF(pay_time IS NOT NULL, EXTRACT(WEEK FROM pay_time), NULL)         AS `pay_week`,
    YEAR(pay_time) * 100 + QUARTER(pay_time)                    AS `pay_quarter`,
    SUBSTR(pay_time, 0, 10)                                     AS `pay_date`,

    YEAR(expiration_time)                                       AS `expiration_year`,
    YEAR(expiration_time) * 100 + MONTH(expiration_time)        AS `expiration_month`,
    -- 彻底替换为EXTRACT函数提取周数
    IF(expiration_time IS NOT NULL, EXTRACT(WEEK FROM expiration_time), NULL)    AS `expiration_week`,
    YEAR(expiration_time) * 100 + QUARTER(expiration_time)      AS `expiration_quarter`,

    member_kind,
    member_type,
    original_order_amount
FROM  dwd_order_d_i
LEFT JOIN 
(
    SELECT  
        id,
        group_id,
        account 
    FROM s_myuu_pft_member_d_f
    WHERE pt = '${ds}'
      AND account != 70801726
) AS member_base
ON seller_id = member_base.id
WHERE booking_date >= '${ds732}'
  AND 
  (
    --昨天下单
    TO_DATE(booking_time) = DATE_SUB(CURRENT_DATE(), 1) 
    --昨天取消             
    OR TO_DATE(cancel_time) = DATE_SUB(CURRENT_DATE(), 1)
    --昨天验证
    OR TO_DATE(verify_time) = DATE_SUB(CURRENT_DATE(), 1)
    --昨天支付    
    OR TO_DATE(pay_time) = DATE_SUB(CURRENT_DATE(), 1)
    --昨天到期
    OR TO_DATE(expiration_time) = DATE_SUB(CURRENT_DATE(), 1)
  ) 
  --过滤测试账户
  AND group_id != 2
  --过滤套票子票
  AND booking_channel != 23

