--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-18 19:18:36
--EMR任务只能运行在独享资源组上
--********************************************************************--

-- desc 景区预约游客数量 - 计算非昨日开通商户增加量数据


INSERT INTO TABLE ads_everyday_land_booking_number_d_i PARTITION(pt=${ds})
SELECT 
    booking.land_publisher_id,
    booking.land_publisher_name,
    booking.land_id,
    booking.land_name,
    -- booking.booking_date,
    TO_DATE(CAST(booking.booking_date AS STRING), 'yyyyMMdd') AS booking_date, 
    SUM(booking_num)                AS booking_number
FROM dwd_order_d_i   AS booking
INNER JOIN
(
    SELECT land_publisher_id
    FROM dim_dataoutput_config_d_i
    -- 非昨天开通的商户
    WHERE pt=${ds}
      AND first_open_service_date != ${ds}
      AND service_end_date >= ${ds}
) AS publisher
ON booking.land_publisher_id = publisher.land_publisher_id
--昨日预定数据

WHERE booking.booking_date = ${ds}
GROUP BY 
    booking.land_publisher_id,
    booking.land_publisher_name,
    booking.land_id,
    booking.land_name,
    booking.booking_date

