--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-19 11:54:22
--EMR任务只能运行在独享资源组上
--********************************************************************--
-- desc 景区实际进入游客，非昨日开通用户，计算增量数据

INSERT INTO TABLE ads_everyday_land_enter_into_number_d_i PARTITION(pt='${ds}')
SELECT
    apply_did           AS member_id,
    insertdate          AS vertify_date,
    SUM(tnum)           AS enter_into_nunber
FROM 
(
    SELECT apply_did, insertdate, tnum
    FROM s_tourist_track_d_i
    WHERE 1=1
      AND track_action IN (1, 4)
      AND insertdate = ${ds}
) AS track 
INNER JOIN 
(
    SELECT land_publisher_id
    FROM dim_dataoutput_config_d_i
    --昨天开通的商户
    WHERE pt=${ds}
      AND first_open_service_date != ${ds}
      AND service_end_date >= ${ds}
) AS publisher
ON track.apply_did = publisher.land_publisher_id
GROUP BY 
    apply_did,
    insertdate
UNION ALL
SELECT 
    0           AS member_id,
    ${ds}       AS vertify_date,
    0           AS enter_into_nunber;

