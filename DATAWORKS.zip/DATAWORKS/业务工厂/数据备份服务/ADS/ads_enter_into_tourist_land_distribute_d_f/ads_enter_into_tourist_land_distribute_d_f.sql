--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-18 18:30:37
--EMR任务只能运行在独享资源组上
--********************************************************************--
-- desc 景区每日入馆游客人数统计 - 每日统计<昨日新开通服务商户>历史全量数据

CREATE TABLE IF NOT EXISTS ads_enter_into_tourist_land_distribute_d_i(
    `member_id`                   INT     COMMENT '景区发布商id',
    `land_id`                     INT     COMMENT '景区id',
    `land_name`                   STRING  COMMENT '景区名',   
    `enter_into_num`              INT     COMMENT '入馆人数',
    `date`                        STRING  COMMENT '入馆日期'  
)COMMENT '入馆游客场馆分布' 
PARTITIONED BY(
    `pt` STRING   
)STORED AS ORC;


INSERT OVERWRITE TABLE ads_enter_into_tourist_land_distribute_d_i PARTITION(pt='${ds}')
SELECT 
    `sid`                   AS member_id,
    `daycount`.land_id      AS land_id, 
    `land_name`             AS land_name,
    SUM(`num`)              AS enter_into_num,
    TO_DATE(FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(`date` AS STRING ),'yyyyMMdd'))) AS `date` 
FROM ods_pft_dc_daycount_two_d_i AS daycount
INNER JOIN 
(
    -- 昨天开通服务的商户，需要计算全量数据
    SELECT land_publisher_id
    FROM dim_dataoutput_config_d_i
    WHERE `pt`='${ds}' 
    -- 首次开通服务时间为昨日，服务终止日期非今日
      AND `first_open_service_date` = '${ds}'
      AND `service_end_date` >= '${ds}'
) AS publisher
ON daycount.`sid` = publisher.`land_publisher_id`
LEFT JOIN 
(
    SELECT 
        land_id,
        land_name
    FROM dim_land_d_f
    WHERE `pt`='${ds}'
) AS dim_land
ON daycount.`land_id` = dim_land.land_id
WHERE `roll` = 0
GROUP BY
    `sid`,
    `daycount`.land_id,
    `land_name`,
    `date`
