--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-19 11:54:36
--EMR任务只能运行在独享资源组上
--********************************************************************--
-- desc 游客画像，取票人地域及年龄 - <昨日新开通服务商户>历史全量数据


CREATE TABLE IF NOT EXISTS ads_tourist_user_persona_d_i (
    member_id           STRING COMMENT '商户id',
    sex                 STRING COMMENT '性别,男/女/未知',
    province            STRING COMMENT '取票人所属省',
    city                STRING COMMENT '取票人所属市',
    country             STRING COMMENT '取票人所属县',
    age_group           STRING COMMENT '取票人年龄范围',
    count_num           INT    COMMENT '统计值',
    booking_date        STRING COMMENT '预定日期'
) COMMENT '游客画像' PARTITIONED BY (
    pt        int COMMENT '预定日期'
);

set hive.exec.dynamic.partition.mode=nonstrict;


INSERT OVERWRITE TABLE ads_tourist_user_persona_d_i PARTITION (pt)
SELECT 
    NVL(land_publisher_id, '')          AS member_id,
    NVL(ticket_taker_sex, '')           AS sex,
    NVL(ticket_taker_province,  '')     AS province,
    NVL(ticket_taker_city,  '')         AS city,
    NVL(ticket_taker_country, '')       AS country,
    NVL(age_group, '')                  AS age_group,
    COUNT(1)                            AS count_num,
    from_unixtime(unix_timestamp(cast(replace(booking_date, '-', '') as string), 'yyyyMMdd'), 'yyyy-MM-dd')   AS booking_date,
    INT(replace(booking_date, '-', '')) AS pt
FROM 
(
    SELECT 
        dwd_order.land_publisher_id,
        booking_date,
        ticket_taker_sex,
        ticket_taker_province, 
        ticket_taker_city, 
        ticket_taker_country,
        CASE 
            WHEN ticket_taker_age>=0  AND ticket_taker_age<=7  THEN "0~7"
            WHEN ticket_taker_age>=8  AND ticket_taker_age<=17 THEN "8~17"
            WHEN ticket_taker_age>=18 AND ticket_taker_age<=27 THEN "18~27"
            WHEN ticket_taker_age>=28 AND ticket_taker_age<=40 THEN "28~40"
            WHEN ticket_taker_age>=41 AND ticket_taker_age<=60 THEN "41~60"
            WHEN ticket_taker_age>=61                          THEN "61+" 
            ELSE                                                    "unknown"
        END AS age_group
    FROM dwd_order_d_i    AS dwd_order
    INNER JOIN
    (
        SELECT land_publisher_id
        FROM dim_dataoutput_config_d_i
        --昨天开通的商户
        WHERE pt='${ds}' 
        --   AND first_open_service_date = '${bdp.system.bizdate2}'
        --   AND service_end_date >= '${bdp.system.bizdate2}'
    ) AS publisher
    ON dwd_order.land_publisher_id = publisher.land_publisher_id
    WHERE booking_date > ${ds} - 732
)
GROUP BY 
    land_publisher_id, 
    booking_date,
    ticket_taker_sex,
    ticket_taker_province, 
    ticket_taker_city, 
    ticket_taker_country,
    age_group
-- GROUPING SETS 
--     (
--         (land_publisher_id, booking_date, ticket_taker_sex),
--         (land_publisher_id, booking_date, ticket_taker_province, ticket_taker_city, ticket_taker_country),
--         (land_publisher_id, booking_date, age_group)
--     )
