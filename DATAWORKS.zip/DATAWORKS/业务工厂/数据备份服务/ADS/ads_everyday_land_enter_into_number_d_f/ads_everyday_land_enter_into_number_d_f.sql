--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-19 11:54:15
--EMR任务只能运行在独享资源组上
--********************************************************************--
-- desc 景区实际进入游客，昨日新开通商户，计算全量数据


CREATE TABLE IF NOT EXISTS ads_everyday_land_enter_into_number_d_i(
    member_id                     INT       COMMENT '景区发布商id',
    vertify_date                  STRING    COMMENT '入馆时间',
    enter_into_nunber             INT       COMMENT '当日入馆游客数量'
)COMMENT '实际进入游客' 
PARTITIONED BY(
    pt INT   
) STORED AS ORC;


INSERT OVERWRITE TABLE ads_everyday_land_enter_into_number_d_i PARTITION(pt)
SELECT
    apply_did                                                                                       AS member_id,
    from_unixtime(unix_timestamp(cast(insertdate as string), 'yyyyMMdd'), 'yyyy-MM-dd')             AS vertify_date,
    SUM(tnum)                                                                                       AS enter_into_nunber,
    insertdate                                                                                      AS pt
FROM 
(
    SELECT apply_did, insertdate, tnum
    FROM s_tourist_track_d_i
    WHERE 1=1
      AND track_action IN (1, 4)
      -- AND insertdate >= CONCAT(YEAR('${bdp.system.bizdate2}') - 2, '-01-01')
      AND insertdate >= CAST(CONCAT(CAST(SUBSTR(CAST(${ds} AS STRING), 1, 4) AS INT) - 2, '0101') AS INT)
) AS track 
INNER JOIN 
(
    SELECT land_publisher_id
    FROM dim_dataoutput_config_d_i
    --昨天开通的商户
    WHERE pt = '${ds}' 
    --   AND first_open_service_date = '${bdp.system.bizdate2}'
    --   AND service_end_date >= '${bdp.system.bizdate2}'
) AS publisher
ON track.apply_did = publisher.land_publisher_id
GROUP BY apply_did, insertdate
ORDER BY apply_did, insertdate

