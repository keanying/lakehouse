--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-19 11:54:29
--EMR任务只能运行在独享资源组上
--********************************************************************--
-- desc 入馆游客频次统计 <3次以上、月、季、年>


CREATE TABLE IF NOT EXISTS ads_tourist_count_d_f (
    stat_date                   STRING  COMMENT '统计日期',
    member_id                   INT     COMMENT '商户ID',
    member_name                 STRING  COMMENT '商户名',

    play_year                   INT     COMMENT '游玩年份',
    play_quarter                INT     COMMENT '统计季度',
    play_month                  INT     COMMENT '游玩月份',

    ticket_taker_name           STRING  COMMENT '游客姓名',
    ticket_taker_mobile         STRING  COMMENT '游客电话',
    ticket_taker_idcard         STRING  COMMENT '身份证',

    play_count                  INT     COMMENT '游览次数'
) COMMENT '入馆游客频次统计' PARTITIONED BY (
    pt INT
) STORED AS ORC;


--------------------------每日统计, 每个商户下每个游客每月浏览次数, 加载为缓冲表--------------------------


DROP VIEW IF EXISTS tourist_month_count_cache;
CACHE TABLE tourist_month_count_cache
AS 
SELECT 
    `order`.land_publisher_id               AS member_id,
    land_publisher_name                     AS member_name,
    YEAR(verify_time)                      AS play_year,
    FLOOR((MONTH(verify_time)-1)/3)+1      AS play_quarter,
    MONTH(verify_time)                     AS play_month,
    ticket_taker_name                       AS ticket_taker_name,
    ticket_taker_mobile                     AS ticket_taker_mobile,
    ticket_taker_idcard                     AS ticket_taker_idcard,
    COUNT(*)                                AS play_count
FROM 
(
    SELECT 
        land_publisher_id,
        land_publisher_name,
        verify_time,
        ticket_taker_name,
        ticket_taker_mobile,
        ticket_taker_idcard 
    FROM dwd_order_d_i 
    WHERE booking_date > ${ds} - 732
      AND verify_time IS NOT NULL 
) AS `order`
INNER JOIN 
(
    SELECT land_publisher_id
    FROM dim_dataoutput_config_d_i
    WHERE pt = ${ds} 
) AS publisher 
ON publisher.land_publisher_id=`order`.land_publisher_id
GROUP BY 
    `order`.land_publisher_id,
    land_publisher_name,
    YEAR(verify_time),
    MONTH(verify_time),
    ticket_taker_name,
    ticket_taker_mobile,
    ticket_taker_idcard;


--------------------------------------------------------------------------------------------


INSERT OVERWRITE TABLE ads_tourist_count_d_f PARTITION(pt = ${ds})
--------------------------月度统计--------------------------
SELECT 
    ${ds}                             AS stat_date,
    member_id                         AS member_id,
    member_name                       AS member_name,
    play_year                         AS play_year,
    play_quarter                      AS play_quarter,
    play_month                        AS play_month,
    ticket_taker_name                 AS ticket_taker_name,
    ticket_taker_mobile               AS ticket_taker_mobile,
    ticket_taker_idcard               AS ticket_taker_idcard,
    play_count                        AS play_count
FROM tourist_month_count_cache
WHERE play_count > ${min_play_count}
--------------------------季度统计--------------------------
UNION ALL 
SELECT 
    ${ds}                           AS stat_date,
    member_id                       AS member_id,
    member_name                     AS member_name,
    play_year                       AS play_year,
    play_quarter                    AS play_quarter,
    0                               AS play_month,
    ticket_taker_name               AS ticket_taker_name,
    ticket_taker_mobile             AS ticket_taker_mobile,
    ticket_taker_idcard             AS ticket_taker_idcard,
    SUM(play_count)                 AS play_count
FROM tourist_month_count_cache
GROUP BY 
    member_id,
    member_name,
    play_year,
    play_quarter,
    ticket_taker_name,
    ticket_taker_mobile,
    ticket_taker_idcard
HAVING play_count > ${min_play_count}
--------------------------年度统计--------------------------
UNION ALL 
SELECT 
    ${ds}                           AS stat_date,
    member_id                       AS member_id,
    member_name                     AS member_name,
    play_year                       AS play_year,
    0                               AS play_quarter,
    0                               AS play_month,
    ticket_taker_name               AS ticket_taker_name,
    ticket_taker_mobile             AS ticket_taker_mobile,
    ticket_taker_idcard             AS ticket_taker_idcard,
    SUM(play_count)                 AS play_count
FROM tourist_month_count_cache
GROUP BY 
    member_id,
    member_name,
    play_year,
    ticket_taker_name,
    ticket_taker_mobile,
    ticket_taker_idcard
HAVING play_count > ${min_play_count};
-------------------------------------------------------------

