--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-18 18:30:45
--EMR任务只能运行在独享资源组上
--********************************************************************--
-- desc 景区每日入馆游客人数统计 - 每日统计<非昨日新开通商户>历史全量数据


INSERT INTO TABLE ads_enter_into_tourist_land_distribute_d_i PARTITION(pt='${ds}')
SELECT 
    `sid`                   AS member_id,
    `daycount`.land_id      AS land_id, 
    `land_name`             AS land_name,
    SUM(`num`)              AS enter_into_num,
    TO_DATE(FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(`date` AS STRING ),'yyyyMMdd'))) AS `date` 
FROM ods_pft_dc_daycount_two_d_i AS daycount
INNER JOIN 
(
    SELECT land_publisher_id
    FROM dim_dataoutput_config_d_i
    --非昨天开通，且在服务期内
    WHERE `pt`='${ds}' 
      AND `first_open_service_date` != '${ds}'
      AND `service_end_date` >= '${ds}'
) AS publisher
ON daycount.`sid` = publisher.`land_publisher_id`
LEFT JOIN 
(
    SELECT 
        land_id,
        land_name
    FROM dim_land_d_f
    WHERE `pt`='${ds}'
) AS dim_land
ON daycount.`land_id` = dim_land.land_id
WHERE `roll` = 0
GROUP BY
    `sid`,
    `daycount`.land_id,
    `land_name`,
    `date`