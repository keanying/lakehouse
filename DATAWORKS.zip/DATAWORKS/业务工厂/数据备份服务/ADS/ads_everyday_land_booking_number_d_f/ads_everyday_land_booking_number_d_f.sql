--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-18 19:17:40
--EMR任务只能运行在独享资源组上
--********************************************************************--

-- desc 景区预约游客数量 - 计算昨日开通商户全量数据

CREATE TABLE IF NOT EXISTS ads_everyday_land_booking_number_d_i(
    member_id           INT     COMMENT '景区发布商id',
    member_name         STRING  COMMENT '景区发布商名称',
    land_id             INT     COMMENT '景区id',    
    land_name           STRING  COMMENT '景区名称',
    booking_date        DATE    COMMENT '预定日期',
    booking_num         INT     COMMENT '预定数'
)COMMENT '预约游客' PARTITIONED BY(
    pt STRING   
)STORED AS ORC;


INSERT OVERWRITE TABLE ads_everyday_land_booking_number_d_i PARTITION(pt='${ds}')
SELECT 
    booking.land_publisher_id,
    booking.land_publisher_name,
    booking.land_id,
    booking.land_name,
    booking.booking_date,
    SUM(booking_num)            AS booking_number
FROM dwd_order_d_i AS booking
INNER JOIN
(
    -- 昨天开通服务的商户，需要运算全量数据
    SELECT land_publisher_id
    FROM dim_dataoutput_config_d_i
    WHERE pt='${ds}' 
      AND first_open_service_date = '${ds}'
      AND service_end_date >= '${ds}'
) AS publisher
ON booking.land_publisher_id = publisher.land_publisher_id
GROUP BY 
    booking.land_publisher_id,
    booking.land_publisher_name,
    booking.land_id,
    booking.land_name,
    booking.booking_date
