--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-18 17:52:39
--EMR任务只能运行在独享资源组上
--********************************************************************--

--将手动抽取的历史全量数据, 动态分区写入以日期字段为分区字段的表中, 需要时shou


CREATE TABLE IF NOT EXISTS `ods_pft_dc_daycount_two_full_temp`(
    `id`            BIGINT  COMMENT '自增ID', 
    `sid`           BIGINT  COMMENT '供应商id', 
    `land_id`       BIGINT  COMMENT '景区ID', 
    `num`           BIGINT  COMMENT '出入园人数', 
    `roll`          TINYINT COMMENT '0 入园 1 离园', 
    `device_key`    STRING  COMMENT '闸机特征码', 
    `createtime`    INT     COMMENT '开始时间', 
    `updatetime`    INT     COMMENT '更新时间', 
    `date`          INT     COMMENT '日期'
)
COMMENT '景区出入园人数统计历史全量数据'
PARTITIONED BY (
    `pt` string
) STORED AS ORC;


CREATE TABLE IF NOT EXISTS `ods_pft_dc_daycount_two_d_i`(
    `id`            BIGINT  COMMENT '自增ID', 
    `sid`           BIGINT  COMMENT '供应商id', 
    `land_id`       BIGINT  COMMENT '景区ID', 
    `num`           BIGINT  COMMENT '出入园人数', 
    `roll`          TINYINT COMMENT '0 入园 1 离园', 
    `device_key`    STRING  COMMENT '闸机特征码', 
    `createtime`    INT     COMMENT '开始时间', 
    `updatetime`    INT     COMMENT '更新时间'
)
COMMENT '景区出入园人数统计,以日期分区'
PARTITIONED BY (
    `date` int COMMENT '日期'
) STORED AS ORC;


INSERT OVERWRITE TABLE ods_pft_dc_daycount_two_d_i PARTITION(`date`)
SELECT 
    `id`,
    `sid`,
    `land_id`,
    `num`,
    `roll`,
    `device_key`,
    `createtime`,
    `updatetime`,
    `date`
FROM ods_pft_dc_daycount_two_full_temp
WHERE pt = '${ds}'

