--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-18 15:41:17
--EMR任务只能运行在独享资源组上
--********************************************************************--


-- 1. 开通服务商户信息表, 数据可来源于多张MySQL表
CREATE TABLE IF NOT EXISTS dim_dataoutput_config_d_i(
    land_publisher_id       INT     COMMENT '景区发布商id',
    first_open_service_date INT     COMMENT '此商家首次开通服务时间',
    service_end_date        INT     COMMENT '服务终止时间'
) COMMENT '数据备份服务开通商家表' 
PARTITIONED BY(
    pt INT 
) STORED AS ORC;


-- 2. 运算此商户服务起止时间
-- 相同商家开通记录, 首次开通时间取最小值, 服务终止时间取最大值
-- 后续指标全量计算任务, 取开通日期为昨日的商户
-- 后续指标增量计算任务, 取全部商户
DROP TABLE IF EXISTS tmp_mid_dim_dataoutput_config;


CREATE TABLE tmp_mid_dim_dataoutput_config (
    land_publisher_id       INT,
    first_open_service_date INT,
    service_end_date        INT
)
USING ORC;


INSERT OVERWRITE TABLE tmp_mid_dim_dataoutput_config
SELECT 
    land_publisher_id,
    MIN(first_open_service_date)    AS first_open_service_date,
    MAX(service_end_date)           AS service_end_date
FROM dim_dataoutput_config_d_i
GROUP BY 
    land_publisher_id
HAVING 
    MAX(service_end_date) >= ${ds};


INSERT OVERWRITE TABLE dim_dataoutput_config_d_i PARTITION(pt='${ds}')
SELECT 
    land_publisher_id,
    first_open_service_date,
    service_end_date
FROM tmp_mid_dim_dataoutput_config;


DROP TABLE tmp_mid_dim_dataoutput_config;

