--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-04 15:13:34
--EMR任务只能运行在独享资源组上
--********************************************************************--
CREATE TABLE IF NOT EXISTS 	dim_sbs_foundation_data_d_f(
    id             INT    COMMENT '自增编号',
    name           STRING COMMENT '名称说明',
    scenic         STRING COMMENT'景区标识',
    scenic_id      INT    COMMENT'景区编号',
    auth_key       STRING COMMENT'鉴权密钥',
    configuration  STRING    COMMENT'区域及摄像头配置',
    flat           STRING COMMENT'配置扁平化数据',
    created_at     STRING    COMMENT'创建时间',
    updated_at     STRING COMMENT'更新时间'
 )COMMENT'景区基础数据表'PARTITIONED BY(
    pt INT 
 )STORED AS ORC;

INSERT OVERWRITE   TABLE dim_sbs_foundation_data_d_f PARTITION(pt=${ds})
SELECT
     id
    ,name
    ,scenic
    ,scenic_id
    ,auth_key
    ,configuration
    ,flat
    ,created_at
    ,updated_at 
from ods_bigscreen_sbs_foundation_data_d_f where pt ="${ds}" 

