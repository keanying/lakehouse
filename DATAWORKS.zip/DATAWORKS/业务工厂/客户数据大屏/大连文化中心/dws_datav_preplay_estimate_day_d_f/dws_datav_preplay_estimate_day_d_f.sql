--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-05 15:22:17
--EMR任务只能运行在独享资源组上
--********************************************************************--
create table if not EXISTS dws_datav_preplay_estimate_day_d_f(
    member_id                   INT COMMENT "会员id",
    member_name                 string COMMENT "名称",
    stat_date                   string COMMENT "统计日期",
    estimate_date               string COMMENT "预测日期",
    preplay_ticket_num          INT COMMENT "预测预约票数",
    estimate_ticket_num          INT COMMENT "预测入园票数"
)COMMENT "景区预测人数信息表" PARTITIONED by(
    pt string
)STORED AS ORC;



INSERT OVERWRITE table dws_datav_preplay_estimate_day_d_f PARTITION (pt="${ds} ")
-- 第1日预测
select 
a.member_id
,a.member_name
,current_date() stat_date
,current_date() estimate_date
,(sum(case when stat_date = date_add(current_date(),-7)  then preplay_ticket_num else null end)+sum(case when stat_date = date_add(current_date(),-14)  then preplay_ticket_num else null end))/2*
(sum(case when stat_date <= date_add(current_date(),-1) and  stat_date >= date_add(current_date(),-7) then preplay_ticket_num else null end )/
 sum(case when stat_date <= date_add(current_date(),-8) and  stat_date >= date_add(current_date(),-14) then preplay_ticket_num else null end ))  as preplay_ticket_num
,(sum(case when stat_date = date_add(current_date(),-7)  then checked_ticket_num else null end)+sum(case when stat_date = date_add(current_date(),-14)  then checked_ticket_num else null end))/2*
(sum(case when stat_date <= date_add(current_date(),-1) and  stat_date >= date_add(current_date(),-7) then checked_ticket_num else null end )/
 sum(case when stat_date <= date_add(current_date(),-8) and  stat_date >= date_add(current_date(),-14) then checked_ticket_num else null end ))  as estimate_ticket_num
from ods_datav_preplay_describe_day_d_f a 
group by a.member_id
,a.member_name
-- 第2日预测
union all 
select 
a.member_id
,a.member_name
,current_date() stat_date
,date_add(current_date(),1) estimate_date
,(sum(case when stat_date = date_add(current_date(),-6)  then preplay_ticket_num else null end)+sum(case when stat_date = date_add(current_date(),-13)  then preplay_ticket_num else null end))/2*
(sum(case when stat_date <= date_add(current_date(),-1) and  stat_date >= date_add(current_date(),-7) then preplay_ticket_num else null end )/
 sum(case when stat_date <= date_add(current_date(),-8) and  stat_date >= date_add(current_date(),-14) then preplay_ticket_num else null end ))  as preplay_ticket_num
,(sum(case when stat_date = date_add(current_date(),-6)  then checked_ticket_num else null end)+sum(case when stat_date = date_add(current_date(),-13)  then checked_ticket_num else null end))/2*
(sum(case when stat_date <= date_add(current_date(),-1) and  stat_date >= date_add(current_date(),-7) then checked_ticket_num else null end )/
 sum(case when stat_date <= date_add(current_date(),-8) and  stat_date >= date_add(current_date(),-14) then checked_ticket_num else null end ))  as estimate_ticket_num
from ods_datav_preplay_describe_day_d_f a 
group by a.member_id
,a.member_name
-- 第3日预测
union all 
select 
a.member_id
,a.member_name
,current_date() stat_date
,date_add(current_date(),2) estimate_date
,(sum(case when stat_date = date_add(current_date(),-5)  then preplay_ticket_num else null end)+sum(case when stat_date = date_add(current_date(),-12)  then preplay_ticket_num else null end))/2*
(sum(case when stat_date <= date_add(current_date(),-1) and  stat_date >= date_add(current_date(),-7) then preplay_ticket_num else null end )/
 sum(case when stat_date <= date_add(current_date(),-8) and  stat_date >= date_add(current_date(),-14) then preplay_ticket_num else null end ))  as preplay_ticket_num
,(sum(case when stat_date = date_add(current_date(),-5)  then checked_ticket_num else null end)+sum(case when stat_date = date_add(current_date(),-12)  then checked_ticket_num else null end))/2*
(sum(case when stat_date <= date_add(current_date(),-1) and  stat_date >= date_add(current_date(),-7) then checked_ticket_num else null end )/
 sum(case when stat_date <= date_add(current_date(),-8) and  stat_date >= date_add(current_date(),-14) then checked_ticket_num else null end ))  as estimate_ticket_num
from ods_datav_preplay_describe_day_d_f a 
group by a.member_id
,a.member_name
-- 第4日预测
union all 
select 
a.member_id
,a.member_name
,current_date() stat_date
,date_add(current_date(),3) estimate_date
,(sum(case when stat_date = date_add(current_date(),-4)  then preplay_ticket_num else null end)+sum(case when stat_date = date_add(current_date(),-11)  then preplay_ticket_num else null end))/2*
(sum(case when stat_date <= date_add(current_date(),-1) and  stat_date >= date_add(current_date(),-7) then preplay_ticket_num else null end )/
 sum(case when stat_date <= date_add(current_date(),-8) and  stat_date >= date_add(current_date(),-14) then preplay_ticket_num else null end ))  as preplay_ticket_num
,(sum(case when stat_date = date_add(current_date(),-4)  then checked_ticket_num else null end)+sum(case when stat_date = date_add(current_date(),-11)  then checked_ticket_num else null end))/2*
(sum(case when stat_date <= date_add(current_date(),-1) and  stat_date >= date_add(current_date(),-7) then checked_ticket_num else null end )/
 sum(case when stat_date <= date_add(current_date(),-8) and  stat_date >= date_add(current_date(),-14) then checked_ticket_num else null end ))  as estimate_ticket_num
from ods_datav_preplay_describe_day_d_f a
group by a.member_id
,a.member_name
-- 第5日预测
union all 
select 
a.member_id
,a.member_name
,current_date() stat_date
,date_add(current_date(),4) estimate_date
,(sum(case when stat_date = date_add(current_date(),-3)  then preplay_ticket_num else null end)+sum(case when stat_date = date_add(current_date(),-10)  then preplay_ticket_num else null end))/2*
(sum(case when stat_date <= date_add(current_date(),-1) and  stat_date >= date_add(current_date(),-7) then preplay_ticket_num else null end )/
 sum(case when stat_date <= date_add(current_date(),-8) and  stat_date >= date_add(current_date(),-14) then preplay_ticket_num else null end ))  as preplay_ticket_num
,(sum(case when stat_date = date_add(current_date(),-3)  then checked_ticket_num else null end)+sum(case when stat_date = date_add(current_date(),-10)  then checked_ticket_num else null end))/2*
(sum(case when stat_date <= date_add(current_date(),-1) and  stat_date >= date_add(current_date(),-7) then checked_ticket_num else null end )/
 sum(case when stat_date <= date_add(current_date(),-8) and  stat_date >= date_add(current_date(),-14) then checked_ticket_num else null end ))  as estimate_ticket_num
from ods_datav_preplay_describe_day_d_f a 
group by a.member_id
,a.member_name
-- 第6日预测
union all 
select 
a.member_id
,a.member_name
,current_date() stat_date
,date_add(current_date(),5) estimate_date
,(sum(case when stat_date = date_add(current_date(),-2)  then preplay_ticket_num else null end)+sum(case when stat_date = date_add(current_date(),-9)  then preplay_ticket_num else null end))/2*
(sum(case when stat_date <= date_add(current_date(),-1) and  stat_date >= date_add(current_date(),-7) then preplay_ticket_num else null end )/
 sum(case when stat_date <= date_add(current_date(),-8) and  stat_date >= date_add(current_date(),-14) then preplay_ticket_num else null end ))  as preplay_ticket_num
,(sum(case when stat_date = date_add(current_date(),-2)  then checked_ticket_num else null end)+sum(case when stat_date = date_add(current_date(),-9)  then checked_ticket_num else null end))/2*
(sum(case when stat_date <= date_add(current_date(),-1) and  stat_date >= date_add(current_date(),-7) then checked_ticket_num else null end )/
 sum(case when stat_date <= date_add(current_date(),-8) and  stat_date >= date_add(current_date(),-14) then checked_ticket_num else null end ))  as estimate_ticket_num
from ods_datav_preplay_describe_day_d_f a 
group by a.member_id
,a.member_name
-- 第7日预测
union all 
select 
a.member_id
,a.member_name
,current_date() stat_date
,date_add(current_date(),6) estimate_date
,(sum(case when stat_date = date_add(current_date(),-1)  then preplay_ticket_num else null end)+sum(case when stat_date = date_add(current_date(),-8)  then preplay_ticket_num else null end))/2*
(sum(case when stat_date <= date_add(current_date(),-1) and  stat_date >= date_add(current_date(),-7) then preplay_ticket_num else null end )/
 sum(case when stat_date <= date_add(current_date(),-8) and  stat_date >= date_add(current_date(),-14) then preplay_ticket_num else null end ))  as preplay_ticket_num
,(sum(case when stat_date = date_add(current_date(),-1)  then checked_ticket_num else null end)+sum(case when stat_date = date_add(current_date(),-8)  then checked_ticket_num else null end))/2*
(sum(case when stat_date <= date_add(current_date(),-1) and  stat_date >= date_add(current_date(),-7) then checked_ticket_num else null end )/
 sum(case when stat_date <= date_add(current_date(),-8) and  stat_date >= date_add(current_date(),-14) then checked_ticket_num else null end ))  as estimate_ticket_num
from ods_datav_preplay_describe_day_d_f a 
group by a.member_id
,a.member_name

-- select 
-- a.member_id
-- ,a.member_name
-- ,a.stat_date
-- ,a.preplay_ticket_num 
-- ,a.checked_ticket_num
-- ,a.booking_order_num
-- ,a.nonchecked_ticket_num
-- ,(nvl(day7,0)+nvl(day14,0))/2*xs  estimate_day1_ticket_num  -- 未来第1日预计票数
-- ,(nvl(day6,0)+nvl(day13,0))/2*xs  estimate_day2_ticket_num  -- 未来第2日预计票数
-- ,(nvl(day5,0)+nvl(day12,0))/2*xs  estimate_day3_ticket_num  -- 未来第3日预计票数
-- ,(nvl(day4,0)+nvl(day11,0))/2*xs  estimate_day4_ticket_num  -- 未来第4日预计票数
-- ,(nvl(day3,0)+nvl(day10,0))/2*xs  estimate_day5_ticket_num  -- 未来第5日预计票数
-- ,(nvl(day2,0)+nvl( day9,0))/2*xs  estimate_day6_ticket_num  -- 未来第6日预计票数
-- ,(nvl(day1,0)+nvl( day8,0))/2*xs  estimate_day7_ticket_num  -- 未来第7日预计票数
-- from 
-- (select * from  ods_datav_preplay_describe_day_d_f  where  pt ="pt"  and  stat_date = date_add(current_date(),-1) ) a
-- left join 
-- (
-- select 
-- a.member_id
-- ,a.member_name
-- ,sum(case when stat_date = date_add(current_date(),-1)  then preplay_ticket_num else null end)   day1    -- 前1日预约票数
-- ,sum(case when stat_date = date_add(current_date(),-2)  then preplay_ticket_num else null end)   day2    -- 前2日预约票数
-- ,sum(case when stat_date = date_add(current_date(),-3)  then preplay_ticket_num else null end)   day3    -- 前3日预约票数
-- ,sum(case when stat_date = date_add(current_date(),-4)  then preplay_ticket_num else null end)   day4    -- 前4日预约票数
-- ,sum(case when stat_date = date_add(current_date(),-5)  then preplay_ticket_num else null end)   day5    -- 前5日预约票数
-- ,sum(case when stat_date = date_add(current_date(),-6)  then preplay_ticket_num else null end)   day6    -- 前6日预约票数
-- ,sum(case when stat_date = date_add(current_date(),-7)  then preplay_ticket_num else null end)   day7    -- 前7日预约票数
-- ,sum(case when stat_date = date_add(current_date(),-8)  then preplay_ticket_num else null end)   day8    -- 前8日预约票数
-- ,sum(case when stat_date = date_add(current_date(),-9)  then preplay_ticket_num else null end)   day9    -- 前9日预约票数
-- ,sum(case when stat_date = date_add(current_date(),-10)  then preplay_ticket_num else null end)  day10   -- 前10日预约票数
-- ,sum(case when stat_date = date_add(current_date(),-11)  then preplay_ticket_num else null end)  day11   -- 前11日预约票数
-- ,sum(case when stat_date = date_add(current_date(),-12)  then preplay_ticket_num else null end)  day12   -- 前12日预约票数
-- ,sum(case when stat_date = date_add(current_date(),-13)  then preplay_ticket_num else null end)  day13   -- 前13日预约票数
-- ,sum(case when stat_date = date_add(current_date(),-14)  then preplay_ticket_num else null end)  day14   -- 前14日预约票数
-- ,sum(case when stat_date <= date_add(current_date(),-1) and  stat_date >= date_add(current_date(),-7) then preplay_ticket_num else null end )/
--  sum(case when stat_date <= date_add(current_date(),-8) and  stat_date >= date_add(current_date(),-14) then preplay_ticket_num else null end )  xs -- 系数
-- from ods_datav_preplay_describe_day_d_f a  where pt ="pt"  
-- group by a.member_id
-- ,a.member_name
-- ) b on a.member_id = b.member_id