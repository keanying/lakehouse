--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-05 16:18:46
--EMR任务只能运行在独享资源组上
--********************************************************************--
-- desc 集团商户

CREATE TABLE IF NOT EXISTS dim_bloc_company_d_f (
    stat_date                   STRING  COMMENT '统计日期',
    dw_ins_time                 STRING  COMMENT '插入时间',

    bloc_account                string  COMMENT '集团账号',
    user_id                     int     COMMENT '下属商户id'

) COMMENT '集团下属商户' PARTITIONED BY (
    pt STRING
) STORED AS ORC;

-- 插入数据
INSERT OVERWRITE TABLE dim_bloc_company_d_f PARTITION (pt='${ds}')
SELECT
        '${ds}'                                    as stat_date,
        current_date()                                             as dw_ins_time,
 
        d2.account                                                 as bloc_account,
        f.scenic_id                                                as user_id

from (
      select d1.account,ltrim(translate(d1.scenic,'"','')) scenic
      from (
            SELECT translate(d.account,'"','')  account,explode(split(d.scenic_list,",")) scenic
            from (
                   SELECT explode(split(substr(account,1,length(account)),",")) account,substr(scenic,2,length(scenic)-2) scenic_list
                   from ods_sbs_account_d_f
                   where pt='${ds}' -- and account='["11778426"]' 
                  ) d
            ) d1
        ) d2
left join (select scenic,scenic_id from dim_sbs_foundation_data_d_f where pt='${ds}') f on f.scenic=d2.scenic


-- select * from dim_bloc_company_d_f where pt='20220417'