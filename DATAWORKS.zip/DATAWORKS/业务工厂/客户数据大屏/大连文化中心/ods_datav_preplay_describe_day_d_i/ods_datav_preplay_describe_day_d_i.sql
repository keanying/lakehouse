--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-04 15:02:04
--EMR任务只能运行在独享资源组上
--********************************************************************--


create table if not EXISTS ods_datav_preplay_describe_day_d_f(
    member_id                   INT     COMMENT "会员id",
    member_name                 STRING  COMMENT "名称",
    stat_date                   STRING  COMMENT "统计日期",
    preplay_ticket_num          INT     COMMENT "预约票数",
    checked_ticket_num          INT     COMMENT "检票票数",
    booking_order_num           INT     COMMENT "预订订单数",
    nonchecked_ticket_num       INT     COMMENT "未检票票数"
)COMMENT "景区人数信息表" PARTITIONED by(
    pt STRING
)STORED AS ORC;

INSERT OVERWRITE TABLE ods_datav_preplay_describe_day_d_f PARTITION (pt="${ds}")
SELECT 
    a.member_id,
    a.member_name,
    a.stat_date,
    a.preplay_ticket_num, 
    a.checked_ticket_num,
    a.booking_order_num,
    a.nonchecked_ticket_num
FROM (
    -- 取昨日数据
    SELECT * 
    FROM ods_bi_datav_preplay_describe_d_i  
    WHERE stat_date ="${ds}"
) AS a 
JOIN (
    -- 昨日数据zui'da
    SELECT member_id, stat_date, MAX(stat_slice) max_stat_slic  
    FROM ods_bi_datav_preplay_describe_d_i  
    WHERE stat_date ="${ds}" 
    GROUP BY member_id, stat_date  
) AS b  
ON a.member_id=b.member_id AND b.stat_date = a.stat_date AND a.stat_slice = b.max_stat_slic; 

-- 历史版本
-- INSERT INTO TABLE ods_datav_preplay_describe_day_d_f PARTITION (pt="pt")
-- -- INSERT OVERWRITE   TABLE ods_datav_preplay_describe_day_d_f PARTITION (pt="pt")
-- SELECT 
--     a.member_id,
--     a.member_name,
--     a.stat_date,
--     a.preplay_ticket_num, 
--     a.checked_ticket_num,
--     a.booking_order_num,
--     a.nonchecked_ticket_num
-- FROM (
--     -- 取昨日数据
--     SELECT * 
--     FROM data_middle_bi.s_bi_datav_preplay_describe_d_f  
--     WHERE pt ="${bdp.system.bizdate}" AND stat_date = "${day}" 
-- ) AS a 
-- JOIN (
--     -- 昨日数据zui'da
--     SELECT member_id, stat_date, MAX(stat_slice) max_stat_slic  
--     FROM data_middle_bi.s_bi_datav_preplay_describe_d_f  
--     WHERE pt ="${bdp.system.bizdate}" 
--     GROUP BY member_id, stat_date  
-- ) AS b  
-- ON a.member_id=b.member_id AND b.stat_date = a.stat_date AND a.stat_slice = b.max_stat_slic
-- WHERE a.stat_date = "${day}"; 


--  -- 补数据用 -------

-- INSERT into   table ods_datav_preplay_describe_day_d_f PARTITION (pt="pt")
-- INSERT OVERWRITE   TABLE ods_datav_preplay_describe_day_d_f PARTITION (pt="pt")
-- select apply_did as member_id,
-- m.dname as member_name,
-- stat_date,
-- sum(preplay_ticket_num) as preplay_ticket_num,
-- sum(checked_ticket_num) as checked_ticket_num,
-- sum(booking_order_num) as booking_order_num,
-- nvl(sum(preplay_ticket_num),0)-nvl(sum(checked_ticket_num),0) as nonchecked_ticket_num
-- from (
-- select  
-- apply_did,
-- substr(playtime,1,10) as stat_date ,
-- sum(tnum) preplay_ticket_num ,
-- '' as checked_ticket_num,
-- '' as booking_order_num
-- from  s_uu_ss_order_d_f
-- where pt='${bdp.system.bizdate}' and apply_did in (select distinct scenic_id from  dim_sbs_foundation_data_d_f where pt='${bdp.system.bizdate}' )
-- and playtime>='2021-07-01' 
-- group by  apply_did,substr(playtime,1,10)
-- UNION ALL 
-- select  
-- apply_did,
-- substr(dtime,1,10) as stat_date ,
-- '' as preplay_ticket_num,
-- sum(tnum) checked_ticket_num ,
-- '' as booking_order_num
-- from  s_uu_ss_order_d_f
-- where pt='${bdp.system.bizdate}' and apply_did in (select distinct scenic_id from  dim_sbs_foundation_data_d_f where pt='${bdp.system.bizdate}' )
-- and dtime>'2021-07-01' 
-- group by apply_did,substr(dtime,1,10)  
-- UNION ALL 
-- select  
-- apply_did, 
-- substr(ordertime,1,10) as stat_date ,
-- '' preplay_ticket_num  ,
-- '' as checked_ticket_num,
-- sum(tnum) as booking_order_num
-- from  s_uu_ss_order_d_f
-- where pt='${bdp.system.bizdate}' and apply_did in (select distinct scenic_id from  dim_sbs_foundation_data_d_f where pt='${bdp.system.bizdate}' )
-- and ordertime>='2021-07-01'
-- group by apply_did,substr(ordertime,1,10) 
-- ) t
-- left JOIN  
-- (select id,dname from   s_myuu_pft_member_d_f where  pt='${bdp.system.bizdate}'  
-- and id in (select distinct scenic_id from  dim_sbs_foundation_data_d_f where pt='${bdp.system.bizdate}') ) m  ON t.apply_did=m.id  
-- group by  apply_did,m.dname,stat_date