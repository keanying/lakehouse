--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-12 18:02:16
--EMR任务只能运行在独享资源组上
--********************************************************************--
-- desc -- 按照供应商计算每个游客近7天/近30天/近09天/近一年/ 游次数，并对频次汇总，

CREATE TABLE IF NOT EXISTS `ods_datav_tourist_frequency_day_d_f`(
    `member_id`     INT         COMMENT '会员id',
    `member_name`   VARCHAR(20) COMMENT '名称',
    `stat_date`     DATE        COMMENT '统计日期',
    `fre1_30d`      INT         COMMENT '近30天来过1次的游客',
    `fre2_30d`      INT         COMMENT '近30天来过2次的游客',
    `fre3_30d`      INT         COMMENT '近30天来过3次的游客',
    `fre4_30d`      INT         COMMENT '近30天来过4次的游客',
    `fre5_30d`      INT         COMMENT '近30天来过5次的游客',
    `fre6_30d`      INT         COMMENT '近30天来过6次以上的游客',
    `fre1_90d`      INT         COMMENT '近90天来过1次的游客',
    `fre2_90d`      INT         COMMENT '近90天来过2次的游客',
    `fre3_90d`      INT         COMMENT '近90天来过3次的游客',
    `fre4_90d`      INT         COMMENT '近90天来过4次的游客',
    `fre5_90d`      INT         COMMENT '近90天来过5次的游客',
    `fre6_90d`      INT         COMMENT '近90天来过6次以上的游客',
    `fre1_180d`     INT         COMMENT '近180天来过1次的游客',
    `fre2_180d`     INT         COMMENT '近180天来过2次的游客',
    `fre3_180d`     INT         COMMENT '近180天来过3次的游客',
    `fre4_180d`     INT         COMMENT '近180天来过4次的游客',
    `fre5_180d`     INT         COMMENT '近180天来过5次的游客',
    `fre6_180d`     INT         COMMENT '近180天来过6次以上的游客',
    `fre1_1year`    INT         COMMENT '近1年来过1次的游客',
    `fre2_1year`    INT         COMMENT '近1年来过2次的游客',
    `fre3_1year`    INT         COMMENT '近1年来过3次的游客',
    `fre4_1year`    INT         COMMENT '近1年来过4次的游客',
    `fre5_1year`    INT         COMMENT '近1年来过5次的游客',
    `fre6_1year`    INT         COMMENT '近1年来过6次以上的游客'
) COMMENT'游客频次表'PARTITIONED BY (
    pt              INT 
) STORED AS ORC;


INSERT OVERWRITE TABLE ods_datav_tourist_frequency_day_d_f PARTITION (pt="${ds}")
SELECT 
    INT(apply_did)                                                      AS member_id    , 
    substr(m.dname, 1, 20)                                              AS member_name  ,
    CURRENT_DATE                                                        AS stat_date    ,
    COUNT(DISTINCT CASE WHEN fre_30d=1 THEN personid ELSE NULL END)     AS fre1_30d     ,   -- 近30天来过1次的游客
    COUNT(DISTINCT CASE WHEN fre_30d=2 THEN personid ELSE NULL END)     AS fre2_30d     ,   -- 近30天来过2次的游客
    COUNT(DISTINCT CASE WHEN fre_30d=3 THEN personid ELSE NULL END)     AS fre3_30d     ,   -- 近30天来过3次的游客
    COUNT(DISTINCT CASE WHEN fre_30d=4 THEN personid ELSE NULL END)     AS fre4_30d     ,   -- 近30天来过4次的游客
    COUNT(DISTINCT CASE WHEN fre_30d=5 THEN personid ELSE NULL END)     AS fre5_30d     ,   -- 近30天来过5次的游客
    COUNT(DISTINCT CASE WHEN fre_30d>=6 THEN personid ELSE NULL END)    AS fre6_30d     ,   -- 近30天来过6次及以上的游客
    COUNT(DISTINCT CASE WHEN fre_90d=1 THEN personid ELSE NULL END)     AS fre1_90d     ,   -- 近90天来过1次的游客
    COUNT(DISTINCT CASE WHEN fre_90d=2 THEN personid ELSE NULL END)     AS fre2_90d     ,   -- 近90天来过2次的游客
    COUNT(DISTINCT CASE WHEN fre_90d=3 THEN personid ELSE NULL END)     AS fre3_90d     ,   -- 近90天来过3次的游客
    COUNT(DISTINCT CASE WHEN fre_90d=4 THEN personid ELSE NULL END)     AS fre4_90d     ,   -- 近90天来过4次的游客
    COUNT(DISTINCT CASE WHEN fre_90d=5 THEN personid ELSE NULL END)     AS FRE5_90D     ,   -- 近90天来过5次的游客
    COUNT(DISTINCT CASE WHEN FRE_90D>=6 THEN PERSONID ELSE NULL END)    AS fre6_90d     ,   -- 近90天来过6次及以上次的游客
    COUNT(DISTINCT CASE WHEN fre_180d=1 THEN personid ELSE NULL END)    AS fre1_180d    ,   -- 近180天来过1次的游客
    COUNT(DISTINCT CASE WHEN fre_180d=2 THEN personid ELSE NULL END)    AS fre2_180d    ,   -- 近180天来过2次的游客
    COUNT(DISTINCT CASE WHEN fre_180d=3 THEN personid ELSE NULL END)    AS fre3_180d    ,   -- 近180天来过3次的游客
    COUNT(DISTINCT CASE WHEN fre_180d=4 THEN personid ELSE NULL END)    AS fre4_180d    ,   -- 近180天来过4次的游客
    COUNT(DISTINCT CASE WHEN fre_180d=5 THEN personid ELSE NULL END)    AS fre5_180d    ,   -- 近180天来过5次的游客
    COUNT(DISTINCT CASE WHEN fre_180d>=6 THEN personid ELSE NULL END)   AS fre6_180d    ,   -- 近180天来过6次及以上次的游客
    COUNT(DISTINCT CASE WHEN fre_1year=1 THEN personid ELSE NULL END)   AS fre1_1year   ,   -- 近1年来过1次的游客
    COUNT(DISTINCT CASE WHEN fre_1year=2 THEN personid ELSE NULL END)   AS fre2_1year   ,   -- 近1年来过2次的游客
    COUNT(DISTINCT CASE WHEN fre_1year=3 THEN personid ELSE NULL END)   AS fre3_1year   ,   -- 近1年来过3次的游客
    COUNT(DISTINCT CASE WHEN fre_1year=4 THEN personid ELSE NULL END)   AS fre4_1year   ,   -- 近1年来过4次的游客
    COUNT(DISTINCT CASE WHEN fre_1year=5 THEN personid ELSE NULL END)   AS fre5_1year   ,   -- 近1年来过5次的游客
    COUNT(DISTINCT CASE WHEN fre_1year>=6 THEN personid ELSE NULL END)  AS fre6_1year       -- 近1年来过6次及以上次的游客
FROM 
(
    SELECT  
        apply_did,
      	personid,
      	COUNT(CASE WHEN check_date >= DATE_ADD(current_date,-30) THEN check_date ELSE NULL END)		AS fre_30d,
      	COUNT(CASE WHEN check_date >= DATE_ADD(current_date,-90) THEN check_date ELSE NULL END)		AS fre_90d,
      	COUNT(CASE WHEN check_date >= DATE_ADD(current_date,-180) THEN check_date ELSE NULL END)    AS fre_180d,
      	COUNT(CASE WHEN check_date >= ADD_MONTHS(current_date,-12) THEN check_date ELSE NULL END)	AS fre_1year
    FROM 
    (
        SELECT  
                apply_did,
                ticket_taker_idcard         AS personid,
                SUBSTR(verify_time, 1, 10) 	AS check_date
        FROM dwd_order_d_i 
        WHERE booking_date > '${ds}' - 732
          AND verify_time <> ''
          AND ticket_taker_idcard <> ''
	) AS a 
    WHERE check_date >= ADD_MONTHS(CURRENT_DATE, -12)
    GROUP BY apply_did,personid
) AS b
LEFT JOIN 
(
    SELECT id, dname 
    FROM s_myuu_pft_member_d_f 
    WHERE pt = '${ds}' 
) AS m 
ON b.apply_did = m.id  
GROUP BY apply_did, m.dname

