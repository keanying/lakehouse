--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-21 16:20:37
--EMR任务只能运行在独享资源组上
--********************************************************************--

-- desc 按天汇总团散客人数


-- 创建表结构
CREATE TABLE IF NOT EXISTS ads_toi_count_d_i (
    stat_date                   STRING  COMMENT '统计日期',
    created_at                  STRING  COMMENT '插入时间',

    member_id                   INT     COMMENT '供应商ID',
    land_id                     INT     COMMENT '景区ID',
    land_name                   STRING  COMMENT '景区名',
    booking_team_orders         INT     COMMENT '预订单团队订单数',
    booking_team_tourists       INT     COMMENT '预订单团队游客数',
    booking_indi_orders         INT     COMMENT '预订单零散订单数',
    booking_indi_tourists       INT     COMMENT '预订单零散游客数',
    verified_team_orders        INT     COMMENT '验证单团队订单数',
    verified_team_tourists      INT     COMMENT '验证单团队游客数',
    verified_indi_orders        INT     COMMENT '验证单零散订单数',
    verified_indi_tourists      INT     COMMENT '验证单零散游客数'
) COMMENT '按天团散客统计汇总' PARTITIONED BY (
    pt STRING
) STORED AS ORC;


-- 插入数据
INSERT OVERWRITE TABLE ads_toi_count_d_i PARTITION (pt='${ds}')
SELECT
    t.stat_date                     AS stat_date,
    t.created_at                    AS created_at,
    t.land_publisher_id             AS member_id,
    t.land_id                       AS land_id,
    t.land_name                     AS land_name,
    SUM(t.booking_team_orders)      AS booking_team_orders,
    SUM(t.booking_team_tourists)    AS booking_team_tourists,
    SUM(t.booking_indi_orders)      AS booking_indi_orders,
    SUM(t.booking_indi_tourists)    AS booking_indi_tourists,
    SUM(t.verified_team_orders)     AS verified_team_orders,
    SUM(t.verified_team_tourists)   AS verified_team_tourists,
    SUM(t.verified_indi_orders)     AS verified_indi_orders,
    SUM(t.verified_indi_tourists)   AS verified_indi_tourists
FROM
(
    (
        SELECT
            '${ds2}'                AS stat_date,
            CURRENT_TIMESTAMP                       AS created_at,
            land_publisher_id,
            land_id,
            land_name,
            SUM(IF(is_team == 1, 1, 0))             AS booking_team_orders,
            SUM(IF(is_team == 0, 1, 0))             AS booking_indi_orders,
            SUM(IF(is_team == 1, ticket_num, 0))    AS booking_team_tourists,
            SUM(IF(is_team == 0, ticket_num, 0))    AS booking_indi_tourists,
            0                                       AS verified_team_orders,
            0                                       AS verified_indi_orders,
            0                                       AS verified_team_tourists,
            0                                       AS verified_indi_tourists
        FROM dwd_order_d_i
        WHERE TO_DATE(booking_time) = DATE_SUB('${ds2}', 1)
        GROUP BY land_publisher_id, land_id, land_name
    )
    UNION ALL
    (
        SELECT
            '${ds2}'                AS stat_date,
            CURRENT_TIMESTAMP                       AS created_at,
            land_publisher_id,
            land_id,
            land_name,
            0                                       AS booking_team_orders,
            0                                       AS booking_indi_orders,
            0                                       AS booking_team_tourists,
            0                                       AS booking_indi_tourists,
            SUM(IF(is_team == 1, 1, 0))             AS verified_team_orders,
            SUM(IF(is_team == 0, 1, 0))             AS verified_indi_orders,
            SUM(IF(is_team == 1, ticket_num, 0))    AS verified_team_tourists,
            SUM(IF(is_team == 0, ticket_num, 0))    AS verified_indi_tourists
        FROM dwd_order_d_i
        WHERE TO_DATE(verify_time) = DATE_SUB('${ds2}', 1)
        GROUP BY land_publisher_id, land_id, land_name
    )
) t GROUP BY t.stat_date, t.created_at, t.land_publisher_id, t.land_id, t.land_name;