--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-21 16:25:13
--EMR任务只能运行在独享资源组上
--********************************************************************--
-- name ads_channel_rank_d_i
-- type Spark SQL
-- author wangbuying@12301.cc
-- create time 2022-09-08 23:15:50
-- desc 景区渠道排行-每日增量

CREATE TABLE IF NOT EXISTS ads_channel_rank_d_i (
    order_date          STRING COMMENT "下单时间",
    seller_id           STRING COMMENT "售卖者",
    channel             STRING COMMENT "渠道id",
    channel_name        STRING COMMENT "渠道名称",
    ticket_num          STRING COMMENT "票数",
    amount              STRING COMMENT "金额（分）"
)COMMENT "景区渠道预订排行" PARTITIONED BY (
    pt           STRING 
)STORED AS ORC;

INSERT OVERWRITE TABLE ads_channel_rank_d_i PARTITION (pt='${bdp.system.bizdate}')
SELECT
    order_date,
    seller_id,
    channel,
    channel_name,
    SUM(ticket_num)     AS ticket_num,
    SUM(order_amount)   AS amount
FROM (
    SELECT
        substr(o.pay_time, 1, 10)       AS order_date,
        a.seller_id                     AS seller_id,
        CASE o.booking_channel
            WHEN 17 THEN a.buyer_id
            WHEN 20 THEN a.buyer_id
            ELSE o.booking_channel
        END                             AS channel,
        CASE o.booking_channel
            WHEN 10 THEN '云票务'
            WHEN 11 THEN '微商城'
            WHEN 12 THEN '自助机'
            WHEN 15 THEN '智能终端'
            WHEN 24 THEN '团队预定'
            WHEN 17 THEN me.com_name
            WHEN 20 THEN me.com_name
            ELSE '其他'
        END                     	    AS channel_name, 
        o.ticket_num                    AS ticket_num,
        o.ticket_num * a.sale_price     AS order_amount
    FROM dwd_order_d_i AS o
    JOIN ods_order_aids_split_d_f AS a ON a.order_id = o.order_id AND a.pt='${bdp.system.bizdate}'
    JOIN s_myuu_pft_member_extinfo_d_f AS me ON me.fid = a.buyer_id AND me.pt = '${bdp.system.bizdate}'

    WHERE
        -- o.pt = '${bdp.system.bizdate}' AND 
        o.pay_time >= '${bdp.system.bizdate2} 00:00:00'
        AND o.pay_time <= '${bdp.system.bizdate2} 23:59:59'
        -- AND a.seller_id IN (567997, 3192946)
        AND o.order_pay_status = 1
        AND o.booking_channel NOT IN (18, 23)
        AND o.order_status_code NOT IN (3, 6, 9)
) AS k
GROUP BY
    order_date,
    seller_id,
    channel,
    channel_name