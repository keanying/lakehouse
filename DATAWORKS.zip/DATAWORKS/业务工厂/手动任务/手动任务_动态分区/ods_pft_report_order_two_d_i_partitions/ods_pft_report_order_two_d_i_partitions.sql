--EMR Spark SQL
--********************************************************************--
--author: 王海阳
--create time: 2025-09-10 17:24:19
--EMR任务只能运行在独享资源组上
--********************************************************************--
INSERT OVERWRITE TABLE ods_pft_report_order_two_d_i PARTITION(`date`)
select
	id,
	fid,
	reseller_id,
	lid,
	tid,
	pid,
	level,
	operate_id,
	order_num,
	order_ticket,
	cancel_num,
	cancel_ticket,
	revoke_num,
	revoke_ticket,
	cost_money,
	sale_money,
	cancel_cost_money,
	cancel_sale_money,
	revoke_cost_money,
	revoke_sale_money,
	service_money,
	orders_info,
	cancel_orders_info,
	revoke_orders_info,
	pay_way,
	channel,
	update_time,
	site_id,
	print_num,
	print_orders_info,
	main_tid,
	sub_merchant_id,
	main_type,
	after_sale_ticket_num,
	after_sale_refund_money,
	after_sale_income_money,
	after_sale_info,
	date
FROM s_pft_report_order_two_o_f
WHERE year = 2022
    AND `date` >= 20220101 
    AND `date` < 20230101
;



INSERT OVERWRITE TABLE ods_pft_report_order_two_d_i PARTITION(`date`)
select
	id,
	fid,
	reseller_id,
	lid,
	tid,
	pid,
	level,
	operate_id,
	order_num,
	order_ticket,
	cancel_num,
	cancel_ticket,
	revoke_num,
	revoke_ticket,
	cost_money,
	sale_money,
	cancel_cost_money,
	cancel_sale_money,
	revoke_cost_money,
	revoke_sale_money,
	service_money,
	orders_info,
	cancel_orders_info,
	revoke_orders_info,
	pay_way,
	channel,
	update_time,
	site_id,
	print_num,
	print_orders_info,
	main_tid,
	sub_merchant_id,
	main_type,
	after_sale_ticket_num,
	after_sale_refund_money,
	after_sale_income_money,
	after_sale_info,
	date
FROM s_pft_report_order_two_o_f
WHERE year = 2023
    AND `date` >= 20230101 
    AND `date` < 20240101
;

INSERT OVERWRITE TABLE ods_pft_report_order_two_d_i PARTITION(`date`)
select
	id,
	fid,
	reseller_id,
	lid,
	tid,
	pid,
	level,
	operate_id,
	order_num,
	order_ticket,
	cancel_num,
	cancel_ticket,
	revoke_num,
	revoke_ticket,
	cost_money,
	sale_money,
	cancel_cost_money,
	cancel_sale_money,
	revoke_cost_money,
	revoke_sale_money,
	service_money,
	orders_info,
	cancel_orders_info,
	revoke_orders_info,
	pay_way,
	channel,
	update_time,
	site_id,
	print_num,
	print_orders_info,
	main_tid,
	sub_merchant_id,
	main_type,
	after_sale_ticket_num,
	after_sale_refund_money,
	after_sale_income_money,
	after_sale_info,
	date
FROM s_pft_report_order_two_o_f
WHERE year = 2024
    AND `date` >= 20240101 
    AND `date` < 20250101
;