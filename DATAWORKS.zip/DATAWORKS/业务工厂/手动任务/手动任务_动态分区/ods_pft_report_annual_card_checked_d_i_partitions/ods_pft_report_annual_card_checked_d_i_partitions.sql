--EMR Spark SQL
--********************************************************************--
--author: 王海阳
--create time: 2025-09-10 11:03:51
--EMR任务只能运行在独享资源组上
--********************************************************************--
INSERT OVERWRITE TABLE ods_pft_report_annual_card_checked_d_i PARTITION(`date`)
select
	id,
	fid,
	reseller_id,
	lid,
	tid,
	pid,
	card_tid,
	card_pid,
	level,
	operate_id,
	order_num,
	order_ticket,
	cost_money,
	sale_money,
	orders_info,
	channel,
	site_id,
	update_time,
	date
FROM s_pft_report_annual_card_checked_o_f
WHERE year = 2022;

INSERT OVERWRITE TABLE ods_pft_report_annual_card_checked_d_i PARTITION(`date`)
select
	id,
	fid,
	reseller_id,
	lid,
	tid,
	pid,
	card_tid,
	card_pid,
	level,
	operate_id,
	order_num,
	order_ticket,
	cost_money,
	sale_money,
	orders_info,
	channel,
	site_id,
	update_time,
	date
FROM s_pft_report_annual_card_checked_o_f
WHERE year = 2023;


INSERT OVERWRITE TABLE ods_pft_report_annual_card_checked_d_i PARTITION(`date`)
select
	id,
	fid,
	reseller_id,
	lid,
	tid,
	pid,
	card_tid,
	card_pid,
	level,
	operate_id,
	order_num,
	order_ticket,
	cost_money,
	sale_money,
	orders_info,
	channel,
	site_id,
	update_time,
	date
FROM s_pft_report_annual_card_checked_o_f
WHERE year = 2024;