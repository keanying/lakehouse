--EMR Spark SQL
--********************************************************************--
--author: 王海阳
--create time: 2025-09-10 17:15:26
--EMR任务只能运行在独享资源组上
--********************************************************************--

INSERT OVERWRITE TABLE ods_terminal_branch_summary_d_i PARTITION(`date`)
select
	id,
	fid,
	operate_id,
	lid,
	tid,
	terminal,
	check_orders,
	check_tickets,
	orders_info,
	check_people,
	source,
	update_time,
	date
FROM s_terminal_branch_summary_o_f
WHERE year = 2022;

INSERT OVERWRITE TABLE ods_terminal_branch_summary_d_i PARTITION(`date`)
select
	id,
	fid,
	operate_id,
	lid,
	tid,
	terminal,
	check_orders,
	check_tickets,
	orders_info,
	check_people,
	source,
	update_time,
	date
FROM s_terminal_branch_summary_o_f
WHERE year = 2023;

INSERT OVERWRITE TABLE ods_terminal_branch_summary_d_i PARTITION(`date`)
select
	id,
	fid,
	operate_id,
	lid,
	tid,
	terminal,
	check_orders,
	check_tickets,
	orders_info,
	check_people,
	source,
	update_time,
	date
FROM s_terminal_branch_summary_o_f
WHERE year = 2024;