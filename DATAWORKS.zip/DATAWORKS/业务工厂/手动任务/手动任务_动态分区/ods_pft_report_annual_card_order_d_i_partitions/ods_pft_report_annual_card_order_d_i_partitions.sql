--EMR Spark SQL
--********************************************************************--
--author: 王海阳
--create time: 2025-09-12 19:20:24
--EMR任务只能运行在独享资源组上
--********************************************************************--
INSERT OVERWRITE TABLE ods_pft_report_annual_card_order_d_i PARTITION(`date`)
select
	id,
	fid,
	reseller_id,
	lid,
	tid,
	pid,
	level,
	operate_id,
	order_num,
	order_ticket,
	cost_money,
	sale_money,
	orders_info,
	trade_type,
	pay_way,
	channel,
	site_id,
	cancel_num,
	cancel_ticket,
	cancel_sale_money,
	cancel_orders_info,
	update_time,
	date
FROM s_pft_report_annual_card_order_o_f
WHERE year = 2022;

INSERT OVERWRITE TABLE ods_pft_report_annual_card_order_d_i PARTITION(`date`)
select
	id,
	fid,
	reseller_id,
	lid,
	tid,
	pid,
	level,
	operate_id,
	order_num,
	order_ticket,
	cost_money,
	sale_money,
	orders_info,
	trade_type,
	pay_way,
	channel,
	site_id,
	cancel_num,
	cancel_ticket,
	cancel_sale_money,
	cancel_orders_info,
	update_time,
	date
FROM s_pft_report_annual_card_order_o_f
WHERE year = 2023;

INSERT OVERWRITE TABLE ods_pft_report_annual_card_order_d_i PARTITION(`date`)
select
	id,
	fid,
	reseller_id,
	lid,
	tid,
	pid,
	level,
	operate_id,
	order_num,
	order_ticket,
	cost_money,
	sale_money,
	orders_info,
	trade_type,
	pay_way,
	channel,
	site_id,
	cancel_num,
	cancel_ticket,
	cancel_sale_money,
	cancel_orders_info,
	update_time,
	date
FROM s_pft_report_annual_card_order_o_f
WHERE year = 2024;

INSERT OVERWRITE TABLE ods_pft_report_annual_card_order_d_i PARTITION(`date`)
select
	id,
	fid,
	reseller_id,
	lid,
	tid,
	pid,
	level,
	operate_id,
	order_num,
	order_ticket,
	cost_money,
	sale_money,
	orders_info,
	trade_type,
	pay_way,
	channel,
	site_id,
	cancel_num,
	cancel_ticket,
	cancel_sale_money,
	cancel_orders_info,
	update_time,
	date
FROM s_pft_report_annual_card_order_o_f
WHERE year = 2025;