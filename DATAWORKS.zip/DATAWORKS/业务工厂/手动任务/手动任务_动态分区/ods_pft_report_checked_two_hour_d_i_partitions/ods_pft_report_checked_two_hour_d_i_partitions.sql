--EMR Spark SQL
--********************************************************************--
--author: 王海阳
--create time: 2025-09-10 09:47:04
--EMR任务只能运行在独享资源组上
--********************************************************************--
INSERT OVERWRITE TABLE ods_pft_report_checked_two_hour_d_i PARTITION(`date`)
select
	id,
	date_hour,
	fid,
	reseller_id,
	lid,
	tid,
	pid,
	lvl,
	operate_id,
	order_num,
	order_ticket,
	finish_num,
	finish_ticket,
	cost_money,
	sale_money,
	finish_cost_money,
	finish_sale_money,
	orders_info,
	finish_orders_info,
	pay_way,
	channel,
	today_check,
	update_time,
	revoke_ticket,
	revoke_num,
	revoke_orders_info,
	revoke_cost_money,
	revoke_sale_money,
	site_id,
	service_money,
	main_tid,
	sub_merchant_id,
	after_sale_ticket_num,
	after_sale_refund_money,
	after_sale_income_money,
	after_sale_info,
	main_type,
	cast(substr(date_hour, 1, 8) as int)  AS `date`
FROM s_pft_report_checked_two_hour_o_f
WHERE date_hour >= 2024010100 AND date_hour < 2025010100;