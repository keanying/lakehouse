--EMR Spark SQL
--********************************************************************--
--author: 王海阳
--create time: 2025-09-10 17:15:26
--EMR任务只能运行在独享资源组上
--********************************************************************--
INSERT OVERWRITE TABLE ods_pft_report_terminal_pass_d_i PARTITION(`date`)
select
	id,
	fid,
	lid,
	tid,
	pid,
	level,
	operate_id,
	reseller_id,
	card_type,
	card_pid,
	channel,
	terminal_type,
	order_num,
	ticket_num,
	cost_money,
	sale_money,
	orders_info,
	update_time,
	site_id,
	ext_content,
	date
FROM s_pft_report_terminal_pass_o_f
WHERE year = 2022
    AND date >= 20220101 
    AND date < 20230101;


INSERT OVERWRITE TABLE ods_pft_report_terminal_pass_d_i PARTITION(`date`)
select
	id,
	fid,
	lid,
	tid,
	pid,
	level,
	operate_id,
	reseller_id,
	card_type,
	card_pid,
	channel,
	terminal_type,
	order_num,
	ticket_num,
	cost_money,
	sale_money,
	orders_info,
	update_time,
	site_id,
	ext_content,
	date
FROM s_pft_report_terminal_pass_o_f
WHERE year = 2023
    AND date >= 20230101 
    AND date < 20240101;



INSERT OVERWRITE TABLE ods_pft_report_terminal_pass_d_i PARTITION(`date`)
select
	id,
	fid,
	lid,
	tid,
	pid,
	level,
	operate_id,
	reseller_id,
	card_type,
	card_pid,
	channel,
	terminal_type,
	order_num,
	ticket_num,
	cost_money,
	sale_money,
	orders_info,
	update_time,
	site_id,
	ext_content,
	date
FROM s_pft_report_terminal_pass_o_f
WHERE year = 2024
    AND date >= 20240101 
    AND date < 20250101;



	INSERT OVERWRITE TABLE ods_pft_report_terminal_pass_d_i PARTITION(`date`)
select
	id,
	fid,
	lid,
	tid,
	pid,
	level,
	operate_id,
	reseller_id,
	card_type,
	card_pid,
	channel,
	terminal_type,
	order_num,
	ticket_num,
	cost_money,
	sale_money,
	orders_info,
	update_time,
	site_id,
	ext_content,
	date
FROM s_pft_report_terminal_pass_o_f
WHERE year = 2022
    AND date >= 20220101 
    AND date < 20230101;


INSERT OVERWRITE TABLE ods_pft_report_terminal_pass_d_i PARTITION(`date`)
select
	id,
	fid,
	lid,
	tid,
	pid,
	level,
	operate_id,
	reseller_id,
	card_type,
	card_pid,
	channel,
	terminal_type,
	order_num,
	ticket_num,
	cost_money,
	sale_money,
	orders_info,
	update_time,
	site_id,
	ext_content,
	date
FROM s_pft_report_terminal_pass_o_f
WHERE year = 2023
    AND date >= 20230101 
    AND date < 20240101;



INSERT OVERWRITE TABLE ods_pft_report_terminal_pass_d_i PARTITION(`date`)
select
	id,
	fid,
	lid,
	tid,
	pid,
	level,
	operate_id,
	reseller_id,
	card_type,
	card_pid,
	channel,
	terminal_type,
	order_num,
	ticket_num,
	cost_money,
	sale_money,
	orders_info,
	update_time,
	site_id,
	ext_content,
	date
FROM s_pft_report_terminal_pass_o_f
WHERE year = 2025
    AND date >= 20250101 
    AND date < 20250918;