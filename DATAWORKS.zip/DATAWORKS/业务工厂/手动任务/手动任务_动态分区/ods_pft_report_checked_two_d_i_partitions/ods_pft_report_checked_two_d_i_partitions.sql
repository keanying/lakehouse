--EMR Spark SQL
--********************************************************************--
--author: 王海阳
--create time: 2025-09-10 17:20:01
--EMR任务只能运行在独享资源组上
--********************************************************************--

INSERT OVERWRITE TABLE ods_pft_report_checked_two_d_i PARTITION(`date`)
select
	id,
	fid,
	reseller_id,
	lid,
	tid,
	pid,
	level,
	operate_id,
	order_num,
	order_ticket,
	finish_num,
	finish_ticket,
	cost_money,
	sale_money,
	finish_cost_money,
	finish_sale_money,
	orders_info,
	finish_orders_info,
	pay_way,
	channel,
	today_check,
	update_time,
	revoke_ticket,
	revoke_num,
	revoke_orders_info,
	revoke_cost_money,
	revoke_sale_money,
	site_id,
	service_money,
	main_tid,
	sub_merchant_id,
	after_sale_ticket_num,
	after_sale_refund_money,
	after_sale_income_money,
	after_sale_info,
	main_type,
	`date`
FROM s_pft_report_checked_two_o_f
WHERE year = 2022
    AND `date` >= 20220101 
    AND `date` < 20230101
;



INSERT OVERWRITE TABLE ods_pft_report_checked_two_d_i PARTITION(`date`)
select
	id,
	fid,
	reseller_id,
	lid,
	tid,
	pid,
	level,
	operate_id,
	order_num,
	order_ticket,
	finish_num,
	finish_ticket,
	cost_money,
	sale_money,
	finish_cost_money,
	finish_sale_money,
	orders_info,
	finish_orders_info,
	pay_way,
	channel,
	today_check,
	update_time,
	revoke_ticket,
	revoke_num,
	revoke_orders_info,
	revoke_cost_money,
	revoke_sale_money,
	site_id,
	service_money,
	main_tid,
	sub_merchant_id,
	after_sale_ticket_num,
	after_sale_refund_money,
	after_sale_income_money,
	after_sale_info,
	main_type,
	`date`
FROM s_pft_report_checked_two_o_f
WHERE year = 2023
    AND `date` >= 20230101 
    AND `date` < 20240101
;




INSERT OVERWRITE TABLE ods_pft_report_checked_two_d_i PARTITION(`date`)
select
	id,
	fid,
	reseller_id,
	lid,
	tid,
	pid,
	level,
	operate_id,
	order_num,
	order_ticket,
	finish_num,
	finish_ticket,
	cost_money,
	sale_money,
	finish_cost_money,
	finish_sale_money,
	orders_info,
	finish_orders_info,
	pay_way,
	channel,
	today_check,
	update_time,
	revoke_ticket,
	revoke_num,
	revoke_orders_info,
	revoke_cost_money,
	revoke_sale_money,
	site_id,
	service_money,
	main_tid,
	sub_merchant_id,
	after_sale_ticket_num,
	after_sale_refund_money,
	after_sale_income_money,
	after_sale_info,
	main_type,
	`date`
FROM s_pft_report_checked_two_o_f
WHERE year = 2024
    AND `date` >= 20240101 
    AND `date` < 20250101
;