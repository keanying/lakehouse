--EMR Spark SQL
--********************************************************************--
--author: 王海阳
--create time: 2025-09-10 09:47:30
--EMR任务只能运行在独享资源组上
--********************************************************************--
INSERT OVERWRITE TABLE ods_pft_report_order_two_hour_d_i PARTITION(`date`)
select
	id,
	date_hour,
	fid,
	reseller_id,
	lid,
	tid,
	pid,
	lvl,
	operate_id,
	order_num,
	order_ticket,
	cancel_num,
	cancel_ticket,
	revoke_num,
	revoke_ticket,
	cost_money,
	sale_money,
	cancel_cost_money,
	cancel_sale_money,
	revoke_cost_money,
	revoke_sale_money,
	service_money,
	orders_info,
	cancel_orders_info,
	revoke_orders_info,
	pay_way,
	channel,
	update_time,
	site_id,
	print_num,
	print_orders_info,
	main_tid,
	sub_merchant_id,
	main_type,
	after_sale_ticket_num,
	after_sale_refund_money,
	after_sale_income_money,
	after_sale_info,
	cast(substr(date_hour, 1, 8) as int)  AS `date`
FROM s_pft_report_order_two_hour_o_f
WHERE date_hour >= 2024010100 AND date_hour < 2025010100;