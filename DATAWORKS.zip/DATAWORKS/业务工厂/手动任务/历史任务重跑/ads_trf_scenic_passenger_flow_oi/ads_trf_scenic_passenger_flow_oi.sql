SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;

CREATE TABLE IF NOT EXISTS ads_trf_scenic_passenger_flow_di(
    scenic_id int COMMENT'景区ID',
    sup_id int COMMENT'供应商ID',
    current_visitors bigint COMMENT'景区当前活跃游客数',
    scenic_cumulative_day bigint COMMENT'景区当日累计游客数',
    avg_stay_minutes int COMMENT'平均停留时长（分钟）'
)comment'景区客流汇总表'
PARTITIONED BY(
    travel_date int COMMENT'业务日期, 格式yyyyMMdd'
)STORED AS ORC ;


INSERT OVERWRITE TABLE ads_trf_scenic_passenger_flow_di PARTITION(travel_date)
SELECT 
    cumulativeTab.lid, 
    cumulativeTab.sid, 
    CASE WHEN currentTab.current_visitors < 0 OR currentTab.current_visitors IS NULL THEN 0
        WHEN currentTab.current_visitors >= cumulativeTab.scenic_cumulative_day THEN cumulativeTab.scenic_cumulative_day
    ELSE currentTab.current_visitors END AS current_visitors,
    cumulativeTab.scenic_cumulative_day,
    NVL(stayTab.avg_stay_minutes, 0) AS avg_stay_minutes,
		cumulativeTab.insertdate
FROM(
    SELECT
        apply_did               AS sid,
        lid                     AS lid,
        SUM(tnum)               AS scenic_cumulative_day,
				insertdate
    FROM(
        SELECT 
            `apply_did`,
            `tid`,
            SUM(`tnum`)         AS  tnum,
						insertdate
        FROM s_tourist_track_d_i
        WHERE 1=1
            AND track_action = 1
            AND ext_content LIKE '%"is_first_used":1%'
						and insertdate >= 20260301
        GROUP BY 
            `apply_did`,
            `tid`,
						insertdate
    ) flowTab
    JOIN (
        SELECT id, landid AS lid
        FROM ods_ticket_d_f
        WHERE pt = DATE_FORMAT(DATE_SUB(CURRENT_DATE(), 1),"yyyyMMdd")
    ) ticketTab
    ON flowTab.tid = ticketTab.id
    GROUP BY apply_did, lid, insertdate
) cumulativeTab
LEFT JOIN (
    SELECT 
        sid, 
        land_id, 
				insertdate,
        SUM(IF(roll=0, num, 0))                             AS `in_visitors`,
        SUM(IF(roll=1, num, 0))                             AS `out_visitors`,
        SUM(IF(roll=0, num, 0))-SUM(IF(roll=1, num, 0))     AS `current_visitors`
    FROM ods_pft_dc_daycount_info_d_i
		WHERE insertdate >= 20260301
    GROUP BY sid, land_id, insertdate
) currentTab
ON cumulativeTab.lid = currentTab.land_id AND cumulativeTab.insertdate = currentTab.insertdate
LEFT JOIN (
    SELECT insertdate, land_id, round(avg(minute)) as avg_stay_minutes
    FROM(
        SELECT insertdate, ordernum, idx, land_id, round(max(insert_time) - min(insert_time))/60 as minute
        FROM (
            SELECT insertdate, ordernum, tid, idx, insert_time
            FROM s_tourist_track_d_i 
            WHERE msg NOT LIKE '%过期%'
						and insertdate >= 20260301
        ) trackTab
        JOIN (
            SELECT id as ticket_id, title as ticket_name, landid as land_id
            FROM ods_ticket_d_f
            WHERE pt = DATE_FORMAT(DATE_SUB(CURRENT_DATE(), 1),"yyyyMMdd")
        ) ticketTab
        ON trackTab.tid = ticketTab.ticket_id
        GROUP BY insertdate, ordernum, land_id, idx
    ) countTab
    WHERE minute >= 30
    GROUP BY insertdate, land_id
) stayTab
ON cumulativeTab.lid = stayTab.land_id AND cumulativeTab.insertdate = stayTab.insertdate