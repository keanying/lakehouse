CREATE TABLE IF NOT EXISTS default.s_pft_report_terminal_pass_hour_o_f ( 
	id BIGINT COMMENT '主键ID', 
	fid INT COMMENT '会员ID', 
	date_hour INT COMMENT '小时段2016012301', 
	lid INT COMMENT '景区ID', 
	tid INT COMMENT '门票ID', 
	pid INT COMMENT '产品ID', 
	lvl INT COMMENT '分销链层级', 
	operate_id INT COMMENT '操作人员ID', 
	reseller_id INT COMMENT '分销商ID', 
	card_type INT COMMENT '卡类型，1=员工卡，2=市民卡，3=年卡，4=一卡通', 
	card_pid INT COMMENT '卡明细（目前只有年卡有，就是具体的卡套餐）', 
	channel INT COMMENT '销售渠道', 
	terminal_type INT COMMENT '终端类型，云票务、手持机、MINI检票机、闸机、PC平台、小程序', 
	order_num BIGINT COMMENT '验证订单数', 
	ticket_num BIGINT COMMENT '验证门票数', 
	cost_money BIGINT COMMENT '验证花费金额', 
	sale_money BIGINT COMMENT '验证金额', 
	orders_info STRING COMMENT '订单信息', 
	update_time BIGINT COMMENT '更新时间', 
	site_id INT COMMENT '站点ID', 
	ext_content STRING COMMENT '扩展信息'
) COMMENT '终端过闸汇总小时报表' 
PARTITIONED BY(
    year INT
)STORED AS ORC;