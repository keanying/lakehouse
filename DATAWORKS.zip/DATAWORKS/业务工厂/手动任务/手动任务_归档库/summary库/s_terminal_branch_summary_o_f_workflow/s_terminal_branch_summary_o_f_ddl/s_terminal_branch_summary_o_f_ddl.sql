CREATE TABLE IF NOT EXISTS default.s_terminal_branch_summary_o_f ( 
	id BIGINT COMMENT '', 
	fid BIGINT COMMENT '用户ID', 
	operate_id BIGINT COMMENT '操作员工ID', 
	lid BIGINT COMMENT '景区ID', 
	tid BIGINT COMMENT '门票ID', 
	terminal BIGINT COMMENT '终端ID', 
	check_orders BIGINT COMMENT '验证订单数', 
	check_tickets BIGINT COMMENT '验证票数', 
	orders_info STRING COMMENT '订单信息', 
	check_people BIGINT COMMENT '验证人次', 
	source TINYINT COMMENT 'pft_order_track 的source', 
	update_time BIGINT COMMENT '更新时间戳', 
	date INT
) COMMENT '分终端汇总表' 
PARTITIONED BY(
    year INT
)STORED AS ORC;