CREATE TABLE IF NOT EXISTS s_pft_report_annual_card_order_o_f ( 
	id BIGINT COMMENT '主键ID', 
	fid BIGINT COMMENT '用户ID', 
	reseller_id BIGINT COMMENT '分销商ID', 
	lid BIGINT COMMENT '景区ID', 
	tid BIGINT COMMENT '年卡票ID', 
	pid BIGINT COMMENT '年卡产品ID', 
	level TINYINT COMMENT '分销链层级', 
	operate_id BIGINT COMMENT '操作人ID', 
	order_num BIGINT COMMENT '预订订单数', 
	order_ticket BIGINT COMMENT '预订门票数', 
	cost_money BIGINT COMMENT '预订花费金额', 
	sale_money BIGINT COMMENT '预定金额', 
	orders_info STRING COMMENT '订单信息', 
	trade_type BIGINT COMMENT '年卡交易类型 0=售卡 1=续费 2=补卡 3=取消 4=激活', 
	pay_way BIGINT COMMENT '支付方式', 
	channel BIGINT COMMENT '销售渠道', 
	site_id BIGINT COMMENT '站点ID', 
	cancel_num BIGINT COMMENT '取消订单数量', 
	cancel_ticket BIGINT COMMENT '取消门票数', 
	cancel_sale_money BIGINT COMMENT '取消金额', 
	cancel_orders_info STRING COMMENT '取消订单信息', 
	update_time BIGINT COMMENT '更新时间', 
	date INT) 
COMMENT '年卡预订报表,记录年卡售卡、续费、补卡、取消、激活操作时的报表数据' 
PARTITIONED BY(
    year INT
)STORED AS ORC;
