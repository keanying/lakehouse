CREATE TABLE s_pft_report_annual_card_checked_o_f ( 
	id BIGINT COMMENT '主键ID', 
	fid BIGINT COMMENT '用户ID', 
	reseller_id BIGINT COMMENT '分销商ID', 
	lid BIGINT COMMENT '景区ID', 
	tid BIGINT COMMENT '票ID', 
	pid BIGINT COMMENT '产品ID', 
	card_tid BIGINT COMMENT '年卡票ID', 
	card_pid BIGINT COMMENT '年卡产品ID', 
	level TINYINT COMMENT '分销链层级', 
	operate_id BIGINT COMMENT '操作人ID', 
	order_num BIGINT COMMENT '验证订单数', 
	order_ticket BIGINT COMMENT '验证门票数', 
	cost_money BIGINT COMMENT '验证花费金额', 
	sale_money BIGINT COMMENT '验证金额', 
	orders_info STRING COMMENT '订单信息', 
	channel BIGINT COMMENT '销售渠道', 
	site_id BIGINT COMMENT '站点ID', 
	update_time BIGINT COMMENT '更新时间', 
	date INT) 
COMMENT '年卡验证报表，使用年卡进行消费的报表数据' 
PARTITIONED BY(
    year INT
)STORED AS ORC;