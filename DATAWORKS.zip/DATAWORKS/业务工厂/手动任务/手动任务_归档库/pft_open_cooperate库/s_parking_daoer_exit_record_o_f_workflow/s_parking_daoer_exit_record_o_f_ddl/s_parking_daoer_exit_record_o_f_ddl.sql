CREATE TABLE s_parking_daoer_exit_record_o_f ( 
	id BIGINT COMMENT '自增ID', 
	con_sys_bind INT COMMENT '绑定ID', 
	member_id INT COMMENT '供应商ID', 
	sync_create_time STRING COMMENT '首次同步时间', 
	sync_update_time STRING COMMENT '最后同步时间', 
	car_no STRING COMMENT '车牌号', 
	card_no STRING COMMENT '卡编号', 
	card_id STRING COMMENT '卡号', 
	owner_name STRING COMMENT '车主姓名', 
	card_type_name STRING COMMENT '卡类型', 
	entry_name STRING COMMENT '入口名称', 
	entry_time STRING COMMENT '入场时间', 
	entry_opt_name STRING COMMENT '入口操作员', 
	exit_name STRING COMMENT '出口名称', 
	exit_time STRING COMMENT '出场时间', 
	exit_opt_name STRING COMMENT '出口操作员', 
	payment_info STRING COMMENT '费用信息，JSON数组保存', 
	account_charge DECIMAL(10,2) COMMENT '应收金额，单位：元（支付信息汇总）', 
	pay_charge DECIMAL(10,2) COMMENT '实收金额，单位：元（支付信息汇总）', 
	dis_amount DECIMAL(10,2) COMMENT '折扣金额，单位：元（支付信息汇总）', 
	payment_type STRING COMMENT '支付类型，（支付信息汇总）', 
	payment_type_name STRING COMMENT '支付类型名称', 
	payment_tnx STRING COMMENT '交易编号，唯一值，（支付信息汇总）', 
	exit_date INT COMMENT '出场时间'
) 
COMMENT '道尔停车车辆出场记录（车牌，出场时间合并）'
PARTITIONED BY(
    year INT
)STORED AS ORC;