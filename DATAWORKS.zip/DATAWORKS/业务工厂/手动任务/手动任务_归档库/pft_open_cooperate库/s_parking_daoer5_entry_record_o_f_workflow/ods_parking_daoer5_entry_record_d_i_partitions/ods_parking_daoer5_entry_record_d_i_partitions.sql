SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;
INSERT OVERWRITE TABLE ods_parking_daoer5_entry_record_d_i PARTITION(`entry_date`)
select
	id,
	con_sys_bind,
	member_id,
	sync_create_time,
	sync_update_time,
	object_id,
	car_in_id,
	entrance_id,
	entrance_name,
	card_id,
	car_no,
	next_car_no,
	correct_car_no,
	card_no,
	contact_name,
	card_type_name,
	car_no_type,
	card_type_id,
	in_time,
	entrance_user_name,
	in_pic,
	in_way,
	in_way_name,
	small,
	controlip,
	description,
	parking_no,
	parking_name,
	box_id,
	box_name,
	operator_name,
	park_owner,
	phone,
	data_origin,
	sync_status,
	delete_code,
	is_load,
	save_time,
	create_time,
	cflag,
	INT(date_format(in_time, 'yyyyMMdd')) AS entry_date
FROM s_parking_daoer5_entry_record_o_f;