SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;
INSERT OVERWRITE TABLE ods_parking_zhihui_exit_record_d_i PARTITION(`exit_date`)
select
	id,
	con_sys_bind,
	member_id,
	sync_create_time,
	sync_update_time,
	index_id,
	park_key,
	car_no,
	order_no,
	car_type_no,
	car_type_name,
	enter_time,
	enter_gate_name,
	out_operator_name,
	out_time,
	out_gate_name,
	lock_car,
	lock_car_name,
	out_img_path,
	total_amount,
	free_reason,
	INT(date_format(out_time, 'yyyyMMdd')) AS exit_date
FROM s_parking_zhihui_exit_record_o_f;