CREATE TABLE s_parking_ketuo_exit_record_o_f ( 
	id BIGINT COMMENT '自增ID', 
	con_sys_bind INT COMMENT '绑定ID', 
	member_id INT COMMENT '供应商ID', 
	sync_create_time STRING COMMENT '首次同步时间', 
	sync_update_time STRING COMMENT '最后同步时间', 
	traffic_id STRING COMMENT '出场唯一记录ID', 
	plate_no STRING COMMENT '车牌号', 
	cap_time STRING COMMENT '出场时间', 
	img_name STRING COMMENT '车辆进出场图片名称', 
	img_type INT COMMENT '图片信息类型：1：base64位图片信息；2=图片URL', 
	img_info STRING COMMENT '图片信息', 
	cap_place STRING COMMENT '车辆进出场地点', 
	car_type_code INT COMMENT '固定车类型编码', 
	car_type_name STRING COMMENT '固定车类型名称', 
	car_color STRING COMMENT '车身颜色黑、白、蓝、红等', 
	car_style_code STRING COMMENT '车辆类型编码', 
	car_style_name STRING COMMENT '车辆类型名称', 
	card_no STRING COMMENT '入场取票号/无牌车入场的卡号', 
	pass_type_code INT COMMENT '放行类型编码', 
	pass_type_name STRING COMMENT '放行类型名称', 
	pass_remark STRING COMMENT '放行说明', 
	car_serial STRING COMMENT '流水号', 
	node_id INT COMMENT '通道id', 
	car_owner_name STRING COMMENT '车主名称', 
	operator STRING COMMENT '放行渠道', 
	oper_name STRING COMMENT '操作人员', 
	serial_type STRING COMMENT '凭据类型', 
	exit_date INT COMMENT '出场时间') 
COMMENT '科拓停车车辆出场记录'
PARTITIONED BY(
    year INT
)STORED AS ORC;