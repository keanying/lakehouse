CREATE TABLE s_retail_sixun_order_sale_detail_o_f ( 
	id BIGINT COMMENT '主键', 
	con_sys_bind INT COMMENT '绑定ID', 
	member_id INT COMMENT '供应商ID', 
	sync_create_time STRING COMMENT '创建时间', 
	sync_update_time STRING COMMENT '更新时间', 
	shop_code STRING COMMENT '店铺编码', 
	order_no STRING COMMENT '销售单据号', 
	seq_no STRING COMMENT '销售单据序号', 
	product_name STRING COMMENT '销售商品名称', 
	sale_num INT COMMENT '销售数量', 
	sale_money DECIMAL(10,2) COMMENT '销售金额', 
	operator STRING COMMENT '操作人员', 
	sale_time STRING COMMENT '销售时间', 
	saledate INT) 
COMMENT '思迅销售明细表'
PARTITIONED BY(
    year INT
)STORED AS ORC;