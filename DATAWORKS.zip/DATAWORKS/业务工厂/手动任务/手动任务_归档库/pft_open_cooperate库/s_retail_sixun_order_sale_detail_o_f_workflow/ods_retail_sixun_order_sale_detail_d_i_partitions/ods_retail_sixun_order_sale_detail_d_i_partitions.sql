INSERT OVERWRITE TABLE ods_retail_sixun_order_sale_detail_d_i PARTITION(`saledate`)
select
	id,
	con_sys_bind,
	member_id,
	sync_create_time,
	sync_update_time,
	shop_code,
	order_no,
	seq_no,
	product_name,
	sale_num,
	sale_money,
	operator,
	sale_time,
	INT(date_format(sale_time, 'yyyyMMdd')) AS saledate
FROM s_retail_sixun_order_sale_detail_o_f;
