CREATE TABLE s_parking_daoer5_exit_record_o_f ( 
	id BIGINT COMMENT '自增ID', 
	con_sys_bind INT COMMENT '绑定ID', 
	member_id INT COMMENT '供应商ID', 
	sync_create_time STRING COMMENT '首次同步时间', 
	sync_update_time STRING COMMENT '最后同步时间', 
	car_no STRING COMMENT '车牌号', 
	card_type_id INT COMMENT '车类型ID', 
	card_type_name STRING COMMENT '车类型名称', 
	in_time STRING COMMENT '入场时间', 
	in_pic STRING COMMENT '入场图片路径', 
	out_time STRING COMMENT '出场时间', 
	out_pic STRING COMMENT '出场图片路径', 
	in_way_name STRING COMMENT '入场方式，手工入场、校正入场', 
	out_way_name STRING COMMENT '出场方式，手工入场、校正入场', 
	entrance_name STRING COMMENT '入场通道名称', 
	entrance_user_name STRING COMMENT '入场操作员', 
	appearances_name STRING COMMENT '出场通道名称', 
	appearances_user_name STRING COMMENT '出场操作员', 
	payment_info STRING COMMENT '支付信息，JSON数组保存', 
	pay_charge DECIMAL(10,2) COMMENT '实收金额，单位：元（支付信息汇总）', 
	account_charge DECIMAL(10,2) COMMENT '应收金额，单位：元（支付信息汇总）', 
	dis_amount DECIMAL(10,2) COMMENT '优惠金额，单位：元（支付信息汇总）', 
	in_id STRING COMMENT '入场编号', 
	contact_name STRING COMMENT '联系人姓名', 
	small INT COMMENT '是否小车场 0 否 1是', 
	exit_date INT COMMENT '出场时间') 
	COMMENT '道尔5.0停车车辆出场记录（车牌，出场时间合并）' 
PARTITIONED BY(
    year INT
)STORED AS ORC;