SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;
INSERT OVERWRITE TABLE ods_parking_daoer5_exit_record_d_i PARTITION(`exit_date`)
select
	id,
	con_sys_bind,
	member_id,
	sync_create_time,
	sync_update_time,
	car_no,
	card_type_id,
	card_type_name,
	in_time,
	in_pic,
	out_time,
	out_pic,
	in_way_name,
	out_way_name,
	entrance_name,
	entrance_user_name,
	appearances_name,
	appearances_user_name,
	payment_info,
	pay_charge,
	account_charge,
	dis_amount,
	in_id,
	contact_name,
	small,
	INT(date_format(out_time, 'yyyyMMdd')) AS exit_date
FROM s_parking_daoer5_exit_record_o_f;