CREATE TABLE s_parking_zhihui_entry_record_o_f ( 
	id BIGINT COMMENT '自增ID', 
	con_sys_bind INT COMMENT '绑定ID', 
	member_id INT COMMENT '供应商ID', 
	sync_create_time STRING COMMENT '首次同步时间', 
	sync_update_time STRING COMMENT '最后同步时间', 
	index_id STRING COMMENT '唯一索引', 
	park_key STRING COMMENT '停车场唯一编号', 
	car_no STRING COMMENT '车牌号', 
	order_no STRING COMMENT '订单号', 
	car_type_no STRING COMMENT '车辆类型编号', 
	car_type_name STRING COMMENT '车辆类型名称', 
	enter_time STRING COMMENT '入场时间', 
	enter_gate_name STRING COMMENT '入口名称', 
	enter_operator_name STRING COMMENT '入口操作员', 
	lock_car STRING COMMENT '车辆状态，0-未锁，1-锁定', 
	lock_car_name STRING COMMENT '车辆状态名称', 
	enter_img_path STRING COMMENT '入口照片', 
	entry_date INT COMMENT '入场时间') 
COMMENT '智慧停车车辆入场记录（车牌入场时间合并）'
PARTITIONED BY(
    year INT
)STORED AS ORC;