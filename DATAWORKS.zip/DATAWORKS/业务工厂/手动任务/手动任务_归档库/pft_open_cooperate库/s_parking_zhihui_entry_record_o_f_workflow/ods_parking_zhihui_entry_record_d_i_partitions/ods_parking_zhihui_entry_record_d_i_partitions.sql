SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;
INSERT OVERWRITE TABLE ods_parking_zhihui_entry_record_d_i PARTITION(`entry_date`)
select
	id,
	con_sys_bind,
	member_id,
	sync_create_time,
	sync_update_time,
	index_id,
	park_key,
	car_no,
	order_no,
	car_type_no,
	car_type_name,
	enter_time,
	enter_gate_name,
	enter_operator_name,
	lock_car,
	lock_car_name,
	enter_img_path,
	INT(date_format(enter_time, 'yyyyMMdd')) AS entry_date
FROM s_parking_zhihui_entry_record_o_f;