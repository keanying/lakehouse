CREATE TABLE s_retail_sixun_order_o_f ( 
	id BIGINT COMMENT '主键', 
	con_sys_bind INT COMMENT '绑定ID', 
	member_id INT COMMENT '供应商ID', 
	sync_create_time STRING COMMENT '创建时间', 
	sync_update_time STRING COMMENT '更新时间', 
	shop_code STRING COMMENT '销售门店号', 
	order_no STRING COMMENT '销售订单号', 
	status STRING COMMENT '是否有效', 
	sale_money DECIMAL(10,2) COMMENT '销售金额', 
	payment_money DECIMAL(10,2) COMMENT '支付金额', 
	settlement_money DECIMAL(10,2) COMMENT '实收金额', 
	table_number STRING COMMENT '座号', 
	number_of_people INT COMMENT '人数', 
	pos_name STRING COMMENT 'POS机名称', 
	operator STRING COMMENT '操作人员', 
	create_time STRING COMMENT '创建时间', 
orderdate INT)
COMMENT '思迅订单表' 
 PARTITIONED BY(
    year INT
)STORED AS ORC;