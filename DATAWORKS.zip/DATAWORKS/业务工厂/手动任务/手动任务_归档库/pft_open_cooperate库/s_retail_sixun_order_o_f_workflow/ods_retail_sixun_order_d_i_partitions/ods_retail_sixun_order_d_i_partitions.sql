INSERT OVERWRITE TABLE ods_retail_sixun_order_d_i PARTITION(`orderdate`)
select
	id,
	con_sys_bind,
	member_id,
	sync_create_time,
	sync_update_time,
	shop_code,
	order_no,
	status,
	sale_money,
	payment_money,
	settlement_money,
	table_number,
	number_of_people,
	pos_name,
	operator,
  	create_time,
	INT(date_format(create_time, 'yyyyMMdd')) AS orderdate
FROM s_retail_sixun_order_o_f;