SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;
INSERT OVERWRITE TABLE ods_parking_ketuo_entry_record_d_i PARTITION(`entry_date`)
select
	id,
	con_sys_bind,
	member_id,
	sync_create_time,
	sync_update_time,
	traffic_id,
	plate_no,
	cap_time,
	img_name,
	img_type,
	img_info,
	cap_place,
	car_type_code,
	car_type_name,
	car_color,
	car_style_code,
	car_style_name,
	card_no,
	pass_type_code,
	pass_type_name,
	pass_remark,
	car_serial,
	node_id,
	car_owner_name,
	operator,
	oper_name,
	serial_type,
	INT(date_format(cap_time, 'yyyyMMdd')) AS entry_date
FROM s_parking_ketuo_entry_record_o_f;