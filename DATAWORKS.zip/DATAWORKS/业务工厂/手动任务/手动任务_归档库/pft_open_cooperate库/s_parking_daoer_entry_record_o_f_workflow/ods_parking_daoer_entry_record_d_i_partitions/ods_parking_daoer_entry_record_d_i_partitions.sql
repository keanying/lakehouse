SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;
INSERT OVERWRITE TABLE ods_parking_daoer_entry_record_d_i PARTITION(`entry_date`)
select
	id,
	con_sys_bind,
	member_id,
	sync_create_time,
	sync_update_time,
	car_no,
	card_no,
	card_id,
	owner_name,
	card_type_name,
	entry_name,
	entry_time,
	entry_opt_name,
	payment_info,
	account_charge,
	pay_charge,
	dis_amount,
	payment_type,
	payment_type_name,
	payment_tnx,
	INT(date_format(entry_time, 'yyyyMMdd')) AS entry_date
FROM s_parking_daoer_entry_record_o_f
;