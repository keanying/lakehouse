-- name ads_yearly_scenic_ticket_taker_order_draw_d_i
-- type Spark SQL
-- author wanghaiyang@12301.cc
-- create time 2025-05-18 15:01:27
-- desc 每年取票人画像汇总表

SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET hive.exec.dynamic.partition.mode=nonstrict;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;
SET hive.exec.dynamic.partition.mode=nonstrict;

REFRESH TABLE ads_monthly_scenic_ticket_taker_order_draw_d_i;
CREATE TABLE IF NOT EXISTS ads_yearly_scenic_ticket_taker_order_draw_d_i(
    `sid`		                INT		COMMENT '原始供应商id',
    `lid`		                INT		COMMENT '景区ID',
    `tid`                       INT     COMMENT '票ID',
    `p_type`                    STRING  COMMENT '景区类型：A景区B线路C酒店F套票',
    `pid`                       INT     COMMENT '产品id',

    `pay_channel_id`            INT     COMMENT '票支付渠道', 
    `pay_channel_name`          STRING  COMMENT '票支付渠道名称', 

    `channel_class1_id`         INT     COMMENT '一级渠道ID',
    `channel_class1_name`       STRING  COMMENT '一级渠道名称',
    `channel_class2_id`         INT     COMMENT '二级渠道ID',
    `channel_class2_name`       STRING  COMMENT '二级渠道名称',

    `country`                   STRING  COMMENT '统计国家(境内/境外/未知)',
    `province`                  STRING  COMMENT '统计省',
    `city`                      STRING  COMMENT '统计市',
    `district`                  STRING  COMMENT '统计区县',

    `mo_group_1`                BIGINT  COMMENT '主单同行人数1人', 
    `mo_group_2`                BIGINT  COMMENT '主单同行人数2到5', 
    `mo_group_3`                BIGINT  COMMENT '主单同行人数6到9', 
    `mo_group_4`                BIGINT  COMMENT '主单同行人数10人及以上', 

    `no_mo_group_1`             BIGINT  COMMENT '子单同行人数1人', 
    `no_mo_group_2`             BIGINT  COMMENT '子单同行人数2到5', 
    `no_mo_group_3`             BIGINT  COMMENT '子单同行人数6到9', 
    `no_mo_group_4`             BIGINT  COMMENT '子单同行人数10人及以上', 

    `mo_male_age_0to7`          BIGINT  COMMENT '主单男性且年龄范围0-7',
    `mo_male_age_8to17`         BIGINT  COMMENT '主单男性且年龄范围8-17',
    `mo_male_age_18to27`        BIGINT  COMMENT '主单男性且年龄范围18-27',
    `mo_male_age_28to40`        BIGINT  COMMENT '主单男性且年龄范围28-40',
    `mo_male_age_41to60`        BIGINT  COMMENT '主单男性且年龄范围41-60', 
    `mo_male_age_61plus`        BIGINT  COMMENT '主单男性且年龄范围>60', 
    `mo_female_age_0to7`        BIGINT  COMMENT '主单女性且年龄范围0-7',
    `mo_female_age_8to17`       BIGINT  COMMENT '主单女性且年龄范围8-17',
    `mo_female_age_18to27`      BIGINT  COMMENT '主单女性且年龄范围18-27', 
    `mo_female_age_28to40`      BIGINT  COMMENT '主单女性且年龄范围28-40',
    `mo_female_age_41to60`      BIGINT  COMMENT '主单女性且年龄范围41-60',
    `mo_female_age_61plus`      BIGINT  COMMENT '主单女性且年龄范围>60',
    `mo_unknown`                BIGINT  COMMENT '主单性别年龄未知',
    `mo_total`                  BIGINT  COMMENT '主单总人数',

    `no_mo_male_age_0to7`       BIGINT  COMMENT '子单男性且年龄范围0-7',
    `no_mo_male_age_8to17`      BIGINT  COMMENT '子单男性且年龄范围8-17',
    `no_mo_male_age_18to27`     BIGINT  COMMENT '子单男性且年龄范围18-27',
    `no_mo_male_age_28to40`     BIGINT  COMMENT '子单男性且年龄范围28-40',
    `no_mo_male_age_41to60`     BIGINT  COMMENT '子单男性且年龄范围41-60', 
    `no_mo_male_age_61plus`     BIGINT  COMMENT '子单男性且年龄范围>60', 
    `no_mo_female_age_0to7`     BIGINT  COMMENT '子单女性且年龄范围0-7',
    `no_mo_female_age_8to17`    BIGINT  COMMENT '子单女性且年龄范围8-17',
    `no_mo_female_age_18to27`   BIGINT  COMMENT '子单女性且年龄范围18-27', 
    `no_mo_female_age_28to40`   BIGINT  COMMENT '子单女性且年龄范围28-40',
    `no_mo_female_age_41to60`   BIGINT  COMMENT '子单女性且年龄范围41-60',
    `no_mo_female_age_61plus`   BIGINT  COMMENT '子单女性且年龄范围>60',
    `no_mo_unknown`             BIGINT  COMMENT '子单性别年龄未知',
    `no_mo_total`               BIGINT  COMMENT '子单总人数'
)COMMENT '每年取票人画像汇总表'
PARTITIONED BY (`year`  INT   	COMMENT '年');


INSERT OVERWRITE TABLE ads_yearly_scenic_ticket_taker_order_draw_d_i PARTITION(`year`)
SELECT
    `sid`                           AS `sid`,
	`lid`                           AS `lid`,
	`tid`                           AS `tid`,
    `p_type`                        AS `p_type`,
    `pid`                           AS `pid`,
 
   `pay_channel_id`                 AS `pay_channel_id`,
    MAX(`pay_channel_name`)         AS `pay_channel_name`,

    `channel_class1_id`             AS `channel_class1_id`,
    MAX(`channel_class1_name`)      AS `channel_class1_name`,
    `channel_class2_id`             AS `channel_class2_id`,
    MAX(`channel_class2_name`)      AS `channel_class2_name`,

    `country`                       AS `country`,
    `province`                      AS `province`,
    `city`                          AS `city`,
    `district`                      AS `district`,
    
    SUM(`mo_group_1`)               AS `mo_group_1`, 
    SUM(`mo_group_2`)               AS `mo_group_2`, 
    SUM(`mo_group_3`)               AS `mo_group_3`, 
    SUM(`mo_group_4`)               AS `mo_group_4`, 

    SUM(`no_mo_group_1`)            AS `no_mo_group_1`, 
    SUM(`no_mo_group_2`)            AS `no_mo_group_2`, 
    SUM(`no_mo_group_3`)            AS `no_mo_group_3`, 
    SUM(`no_mo_group_4`)            AS `no_mo_group_4`, 

    SUM(`mo_male_age_0to7`)         AS `mo_male_age_0to7`,    
    SUM(`mo_male_age_8to17`)        AS `mo_male_age_8to17`,   
    SUM(`mo_male_age_18to27`)       AS `mo_male_age_18to27`,  
    SUM(`mo_male_age_28to40`)       AS `mo_male_age_28to40`,  
    SUM(`mo_male_age_41to60`)       AS `mo_male_age_41to60`,  
    SUM(`mo_male_age_61plus`)       AS `mo_male_age_61plus`,  
    SUM(`mo_female_age_0to7`)       AS `mo_female_age_0to7`,  
    SUM(`mo_female_age_8to17`)      AS `mo_female_age_8to17`, 
    SUM(`mo_female_age_18to27`)     AS `mo_female_age_18to27`,
    SUM(`mo_female_age_28to40`)     AS `mo_female_age_28to40`,
    SUM(`mo_female_age_41to60`)     AS `mo_female_age_41to60`,
    SUM(`mo_female_age_61plus`)     AS `mo_female_age_61plus`,
    SUM(`mo_unknown`)               AS `mo_unknown`,          
    SUM(`mo_total`)                 AS `mo_total`, 

    SUM(`no_mo_male_age_0to7`)      AS `no_mo_male_age_0to7`,    
    SUM(`no_mo_male_age_8to17`)     AS `no_mo_male_age_8to17`,   
    SUM(`no_mo_male_age_18to27`)    AS `no_mo_male_age_18to27`,  
    SUM(`no_mo_male_age_28to40`)    AS `no_mo_male_age_28to40`,  
    SUM(`no_mo_male_age_41to60`)    AS `no_mo_male_age_41to60`,  
    SUM(`no_mo_male_age_61plus`)    AS `no_mo_male_age_61plus`,  
    SUM(`no_mo_female_age_0to7`)    AS `no_mo_female_age_0to7`,  
    SUM(`no_mo_female_age_8to17`)   AS `no_mo_female_age_8to17`, 
    SUM(`no_mo_female_age_18to27`)  AS `no_mo_female_age_18to27`,
    SUM(`no_mo_female_age_28to40`)  AS `no_mo_female_age_28to40`,
    SUM(`no_mo_female_age_41to60`)  AS `no_mo_female_age_41to60`,
    SUM(`no_mo_female_age_61plus`)  AS `no_mo_female_age_61plus`,
    SUM(`no_mo_unknown`)            AS `no_mo_unknown`,          
    SUM(`no_mo_total`)              AS `no_mo_total`, 

    `year`                          AS `year`
FROM ads_monthly_scenic_ticket_taker_order_draw_d_i
WHERE SUBSTR(`month`, 0, 4) = SUBSTR('${ds}', 0, 4)
GROUP BY
    `sid`,
    `lid`,
    `tid`,
    `p_type`,
    `pid`,
    `channel_class1_id`,
    `channel_class2_id`,
    `pay_channel_id`,
    `country`,
    `province`,
    `city`,
    `district`,
    `year`;