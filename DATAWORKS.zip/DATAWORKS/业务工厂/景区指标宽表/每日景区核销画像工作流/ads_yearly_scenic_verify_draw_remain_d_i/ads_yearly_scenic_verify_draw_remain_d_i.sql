-- name ads_yearly_scenic_verify_draw_remain_d_i
-- type Spark SQL
-- author wanghaiyang@12301.cc
-- create time 2025-01-09 17:30:58
-- desc 每年核销画像指标表(白名单过滤)

SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;

CREATE TABLE IF NOT EXISTS ads_yearly_scenic_verify_draw_remain_d_i(
    `sid`                           INT         COMMENT '原始供应商id',
    `lid`		                    INT	        COMMENT '景区ID',
    `tid`                           INT         COMMENT '票ID',
    `p_type`                        STRING      COMMENT '景区类型：A景区B线路C酒店F套票',
    `pid`                           INT         COMMENT '产品id',

    `country`                       STRING      COMMENT '统计国家',
    `province`			            STRING	    COMMENT '统计省',
    `city`			                STRING	    COMMENT '统计市',
    `district`			            STRING	    COMMENT '统计区/县',

    `mo_male_age_0to7`              BIGINT     COMMENT '主单男性且年龄范围0-7,只包含首次核销',
    `mo_male_age_8to17`             BIGINT     COMMENT '主单男性且年龄范围8-17,只包含首次核销',
    `mo_male_age_18to27`            BIGINT     COMMENT '主单男性且年龄范围18-27,只包含首次核销',
    `mo_male_age_28to40`            BIGINT     COMMENT '主单男性且年龄范围28-40,只包含首次核销',
    `mo_male_age_41to60`            BIGINT     COMMENT '主单男性且年龄范围41-60,只包含首次核销', 
    `mo_male_age_61plus`            BIGINT     COMMENT '主单男性且年龄范围>60,只包含首次核销', 
    `mo_female_age_0to7`            BIGINT     COMMENT '主单女性且年龄范围0-7,只包含首次核销',
    `mo_female_age_8to17`           BIGINT     COMMENT '主单女性且年龄范围8-17,只包含首次核销',
    `mo_female_age_18to27`          BIGINT     COMMENT '主单女性且年龄范围18-27,只包含首次核销', 
    `mo_female_age_28to40`          BIGINT     COMMENT '主单女性且年龄范围28-40,只包含首次核销',
    `mo_female_age_41to60`          BIGINT     COMMENT '主单女性且年龄范围41-60,只包含首次核销',
    `mo_female_age_61plus`          BIGINT     COMMENT '主单女性且年龄范围>60,只包含首次核销',
    `mo_unknown`                    BIGINT     COMMENT '主单性别年龄未知,只包含首次核销',
    `mo_total`                      BIGINT     COMMENT '主单总人数,只包含首次核销',
    `mo_male_age_0to7_all`          BIGINT     COMMENT '主单男性且年龄范围0-7,包含首次核销和重复入园',   
    `mo_male_age_8to17_all`         BIGINT     COMMENT '主单男性且年龄范围8-17,包含首次核销和重复入园', 
    `mo_male_age_18to27_all`        BIGINT     COMMENT '主单男性且年龄范围18-27,包含首次核销和重复入园', 
    `mo_male_age_28to40_all`        BIGINT     COMMENT '主单男性且年龄范围28-40,包含首次核销和重复入园', 
    `mo_male_age_41to60_all`        BIGINT     COMMENT '主单男性且年龄范围41-60,包含首次核销和重复入园', 
    `mo_male_age_61plus_all`        BIGINT     COMMENT '主单男性且年龄范围>60,包含首次核销和重复入园',  
    `mo_female_age_0to7_all`        BIGINT     COMMENT '主单女性且年龄范围0-7,包含首次核销和重复入园', 
    `mo_female_age_8to17_all`       BIGINT     COMMENT '主单女性且年龄范围8-17,包含首次核销和重复入园', 
    `mo_female_age_18to27_all`      BIGINT     COMMENT '主单女性且年龄范围18-27,包含首次核销和重复入园', 
    `mo_female_age_28to40_all`      BIGINT     COMMENT '主单女性且年龄范围28-40,包含首次核销和重复入园', 
    `mo_female_age_41to60_all`      BIGINT     COMMENT '主单女性且年龄范围41-60,包含首次核销和重复入园', 
    `mo_female_age_61plus_all`      BIGINT     COMMENT '主单女性且年龄范围>60,包含首次核销和重复入园', 
    `mo_unknown_all`                BIGINT     COMMENT '主单性别年龄未知,包含首次核销和重复入园',
    `mo_total_all`                  BIGINT     COMMENT '主单总人数,包含首次核销和重复入园',

    `no_mo_male_age_0to7`           BIGINT     COMMENT '子单男性且年龄范围0-7,只包含首次核销',
    `no_mo_male_age_8to17`          BIGINT     COMMENT '子单男性且年龄范围8-17,只包含首次核销',
    `no_mo_male_age_18to27`         BIGINT     COMMENT '子单男性且年龄范围18-27,只包含首次核销',
    `no_mo_male_age_28to40`         BIGINT     COMMENT '子单男性且年龄范围28-40,只包含首次核销',
    `no_mo_male_age_41to60`         BIGINT     COMMENT '子单男性且年龄范围41-60,只包含首次核销', 
    `no_mo_male_age_61plus`         BIGINT     COMMENT '子单男性且年龄范围>60,只包含首次核销', 
    `no_mo_female_age_0to7`         BIGINT     COMMENT '子单女性且年龄范围0-7,只包含首次核销',
    `no_mo_female_age_8to17`        BIGINT     COMMENT '子单女性且年龄范围8-17,只包含首次核销',
    `no_mo_female_age_18to27`       BIGINT     COMMENT '子单女性且年龄范围18-27,只包含首次核销', 
    `no_mo_female_age_28to40`       BIGINT     COMMENT '子单女性且年龄范围28-40,只包含首次核销',
    `no_mo_female_age_41to60`       BIGINT     COMMENT '子单女性且年龄范围41-60,只包含首次核销',
    `no_mo_female_age_61plus`       BIGINT     COMMENT '子单女性且年龄范围>60,只包含首次核销',
    `no_mo_unknown`                 BIGINT     COMMENT '子单性别年龄未知,只包含首次核销',
    `no_mo_total`                   BIGINT     COMMENT '子单总人数,只包含首次核销',
    `no_mo_male_age_0to7_all`       BIGINT     COMMENT '子单男性且年龄范围0-7,包含首次核销和重复入园',   
    `no_mo_male_age_8to17_all`      BIGINT     COMMENT '子单男性且年龄范围8-17,包含首次核销和重复入园', 
    `no_mo_male_age_18to27_all`     BIGINT     COMMENT '子单男性且年龄范围18-27,包含首次核销和重复入园', 
    `no_mo_male_age_28to40_all`     BIGINT     COMMENT '子单男性且年龄范围28-40,包含首次核销和重复入园', 
    `no_mo_male_age_41to60_all`     BIGINT     COMMENT '子单男性且年龄范围41-60,包含首次核销和重复入园', 
    `no_mo_male_age_61plus_all`     BIGINT     COMMENT '子单男性且年龄范围>60,包含首次核销和重复入园',  
    `no_mo_female_age_0to7_all`     BIGINT     COMMENT '子单女性且年龄范围0-7,包含首次核销和重复入园', 
    `no_mo_female_age_8to17_all`    BIGINT     COMMENT '子单女性且年龄范围8-17,包含首次核销和重复入园', 
    `no_mo_female_age_18to27_all`   BIGINT     COMMENT '子单女性且年龄范围18-27,包含首次核销和重复入园', 
    `no_mo_female_age_28to40_all`   BIGINT     COMMENT '子单女性且年龄范围28-40,包含首次核销和重复入园', 
    `no_mo_female_age_41to60_all`   BIGINT     COMMENT '子单女性且年龄范围41-60,包含首次核销和重复入园', 
    `no_mo_female_age_61plus_all`   BIGINT     COMMENT '子单女性且年龄范围>60,包含首次核销和重复入园', 
    `no_mo_unknown_all`             BIGINT     COMMENT '子单性别年龄未知,包含首次核销和重复入园',
    `no_mo_total_all`               BIGINT     COMMENT '子单总人数,包含首次核销和重复入园'

)COMMENT '每核销画像指标表(白名单过滤)'
PARTITIONED BY (`year`          INT   	COMMENT '年')
STORED AS ORC;


INSERT OVERWRITE TABLE ads_yearly_scenic_verify_draw_remain_d_i PARTITION(year)
SELECT 
     drawTab.`sid`,
    `lid`,
    `tid`,
    `p_type`,
    `pid`,

    `country`,
    `province`,
    `city`,
    `district`,

    `mo_male_age_0to7`,
    `mo_male_age_8to17`,
    `mo_male_age_18to27`,
    `mo_male_age_28to40`,
    `mo_male_age_41to60`, 
    `mo_male_age_61plus`, 
    `mo_female_age_0to7`,
    `mo_female_age_8to17`,
    `mo_female_age_18to27`, 
    `mo_female_age_28to40`,
    `mo_female_age_41to60`,
    `mo_female_age_61plus`,
    `mo_unknown`,
    `mo_total`,
    `mo_male_age_0to7_all`,   
    `mo_male_age_8to17_all`, 
    `mo_male_age_18to27_all`, 
    `mo_male_age_28to40_all`, 
    `mo_male_age_41to60_all`, 
    `mo_male_age_61plus_all`,  
    `mo_female_age_0to7_all`, 
    `mo_female_age_8to17_all`, 
    `mo_female_age_18to27_all`, 
    `mo_female_age_28to40_all`, 
    `mo_female_age_41to60_all`, 
    `mo_female_age_61plus_all`, 
    `mo_unknown_all`,
    `mo_total_all`,

    `no_mo_male_age_0to7`,
    `no_mo_male_age_8to17`,
    `no_mo_male_age_18to27`,
    `no_mo_male_age_28to40`,
    `no_mo_male_age_41to60`, 
    `no_mo_male_age_61plus`, 
    `no_mo_female_age_0to7`,
    `no_mo_female_age_8to17`,
    `no_mo_female_age_18to27`, 
    `no_mo_female_age_28to40`,
    `no_mo_female_age_41to60`,
    `no_mo_female_age_61plus`,
    `no_mo_unknown`,
    `no_mo_total`,
    `no_mo_male_age_0to7_all`,   
    `no_mo_male_age_8to17_all`, 
    `no_mo_male_age_18to27_all`, 
    `no_mo_male_age_28to40_all`, 
    `no_mo_male_age_41to60_all`, 
    `no_mo_male_age_61plus_all`,  
    `no_mo_female_age_0to7_all`, 
    `no_mo_female_age_8to17_all`, 
    `no_mo_female_age_18to27_all`, 
    `no_mo_female_age_28to40_all`, 
    `no_mo_female_age_41to60_all`, 
    `no_mo_female_age_61plus_all`, 
    `no_mo_unknown_all`,
    `no_mo_total_all`,
    
    `year`
FROM ads_yearly_scenic_verify_draw_d_i drawTab
JOIN (
    SELECT sid
    FROM data_middle_bi.dim_sid_white_list_d_f 
    WHERE pt = DATE_FORMAT(DATE_SUB(CURRENT_DATE(), 1),"yyyyMMdd")
) whiteTab
ON drawTab.sid = whiteTab.sid
WHERE year = SUBSTR('${ds}', 0, 4);