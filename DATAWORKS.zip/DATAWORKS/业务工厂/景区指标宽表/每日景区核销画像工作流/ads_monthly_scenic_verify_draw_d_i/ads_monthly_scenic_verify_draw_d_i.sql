-- name ads_daily_scenic_verify_draw_d_i
-- type Spark SQL
-- author wanghaiyang@12301.cc
-- create time 2025-01-09 17:30:58
-- desc 每月核销画像指标表

SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;

CREATE TABLE IF NOT EXISTS ads_monthly_scenic_verify_draw_d_i(
    `sid`                           INT         COMMENT '原始供应商id',
    `lid`		                    INT	        COMMENT '景区ID',
    `tid`                           INT         COMMENT '票ID',
    `p_type`                        STRING      COMMENT '景区类型：A景区B线路C酒店F套票',
    `pid`                           INT         COMMENT '产品id',

    `country`                       STRING      COMMENT '统计国家',
    `province`			            STRING	    COMMENT '统计省',
    `city`			                STRING	    COMMENT '统计市',
    `district`			            STRING	    COMMENT '统计区/县',

    `mo_male_age_0to7`              BIGINT     COMMENT '主单男性且年龄范围0-7,只包含首次核销',
    `mo_male_age_8to17`             BIGINT     COMMENT '主单男性且年龄范围8-17,只包含首次核销',
    `mo_male_age_18to27`            BIGINT     COMMENT '主单男性且年龄范围18-27,只包含首次核销',
    `mo_male_age_28to40`            BIGINT     COMMENT '主单男性且年龄范围28-40,只包含首次核销',
    `mo_male_age_41to60`            BIGINT     COMMENT '主单男性且年龄范围41-60,只包含首次核销', 
    `mo_male_age_61plus`            BIGINT     COMMENT '主单男性且年龄范围>60,只包含首次核销', 
    `mo_female_age_0to7`            BIGINT     COMMENT '主单女性且年龄范围0-7,只包含首次核销',
    `mo_female_age_8to17`           BIGINT     COMMENT '主单女性且年龄范围8-17,只包含首次核销',
    `mo_female_age_18to27`          BIGINT     COMMENT '主单女性且年龄范围18-27,只包含首次核销', 
    `mo_female_age_28to40`          BIGINT     COMMENT '主单女性且年龄范围28-40,只包含首次核销',
    `mo_female_age_41to60`          BIGINT     COMMENT '主单女性且年龄范围41-60,只包含首次核销',
    `mo_female_age_61plus`          BIGINT     COMMENT '主单女性且年龄范围>60,只包含首次核销',
    `mo_unknown`                    BIGINT     COMMENT '主单性别年龄未知,只包含首次核销',
    `mo_total`                      BIGINT     COMMENT '主单总人数,只包含首次核销',
    `mo_male_age_0to7_all`          BIGINT     COMMENT '主单男性且年龄范围0-7,包含首次核销和重复入园',   
    `mo_male_age_8to17_all`         BIGINT     COMMENT '主单男性且年龄范围8-17,包含首次核销和重复入园', 
    `mo_male_age_18to27_all`        BIGINT     COMMENT '主单男性且年龄范围18-27,包含首次核销和重复入园', 
    `mo_male_age_28to40_all`        BIGINT     COMMENT '主单男性且年龄范围28-40,包含首次核销和重复入园', 
    `mo_male_age_41to60_all`        BIGINT     COMMENT '主单男性且年龄范围41-60,包含首次核销和重复入园', 
    `mo_male_age_61plus_all`        BIGINT     COMMENT '主单男性且年龄范围>60,包含首次核销和重复入园',  
    `mo_female_age_0to7_all`        BIGINT     COMMENT '主单女性且年龄范围0-7,包含首次核销和重复入园', 
    `mo_female_age_8to17_all`       BIGINT     COMMENT '主单女性且年龄范围8-17,包含首次核销和重复入园', 
    `mo_female_age_18to27_all`      BIGINT     COMMENT '主单女性且年龄范围18-27,包含首次核销和重复入园', 
    `mo_female_age_28to40_all`      BIGINT     COMMENT '主单女性且年龄范围28-40,包含首次核销和重复入园', 
    `mo_female_age_41to60_all`      BIGINT     COMMENT '主单女性且年龄范围41-60,包含首次核销和重复入园', 
    `mo_female_age_61plus_all`      BIGINT     COMMENT '主单女性且年龄范围>60,包含首次核销和重复入园', 
    `mo_unknown_all`                BIGINT     COMMENT '主单性别年龄未知,包含首次核销和重复入园',
    `mo_total_all`                  BIGINT     COMMENT '主单总人数,包含首次核销和重复入园',

    `no_mo_male_age_0to7`           BIGINT     COMMENT '子单男性且年龄范围0-7,只包含首次核销',
    `no_mo_male_age_8to17`          BIGINT     COMMENT '子单男性且年龄范围8-17,只包含首次核销',
    `no_mo_male_age_18to27`         BIGINT     COMMENT '子单男性且年龄范围18-27,只包含首次核销',
    `no_mo_male_age_28to40`         BIGINT     COMMENT '子单男性且年龄范围28-40,只包含首次核销',
    `no_mo_male_age_41to60`         BIGINT     COMMENT '子单男性且年龄范围41-60,只包含首次核销', 
    `no_mo_male_age_61plus`         BIGINT     COMMENT '子单男性且年龄范围>60,只包含首次核销', 
    `no_mo_female_age_0to7`         BIGINT     COMMENT '子单女性且年龄范围0-7,只包含首次核销',
    `no_mo_female_age_8to17`        BIGINT     COMMENT '子单女性且年龄范围8-17,只包含首次核销',
    `no_mo_female_age_18to27`       BIGINT     COMMENT '子单女性且年龄范围18-27,只包含首次核销', 
    `no_mo_female_age_28to40`       BIGINT     COMMENT '子单女性且年龄范围28-40,只包含首次核销',
    `no_mo_female_age_41to60`       BIGINT     COMMENT '子单女性且年龄范围41-60,只包含首次核销',
    `no_mo_female_age_61plus`       BIGINT     COMMENT '子单女性且年龄范围>60,只包含首次核销',
    `no_mo_unknown`                 BIGINT     COMMENT '子单性别年龄未知,只包含首次核销',
    `no_mo_total`                   BIGINT     COMMENT '子单总人数,只包含首次核销',
    `no_mo_male_age_0to7_all`       BIGINT     COMMENT '子单男性且年龄范围0-7,包含首次核销和重复入园',   
    `no_mo_male_age_8to17_all`      BIGINT     COMMENT '子单男性且年龄范围8-17,包含首次核销和重复入园', 
    `no_mo_male_age_18to27_all`     BIGINT     COMMENT '子单男性且年龄范围18-27,包含首次核销和重复入园', 
    `no_mo_male_age_28to40_all`     BIGINT     COMMENT '子单男性且年龄范围28-40,包含首次核销和重复入园', 
    `no_mo_male_age_41to60_all`     BIGINT     COMMENT '子单男性且年龄范围41-60,包含首次核销和重复入园', 
    `no_mo_male_age_61plus_all`     BIGINT     COMMENT '子单男性且年龄范围>60,包含首次核销和重复入园',  
    `no_mo_female_age_0to7_all`     BIGINT     COMMENT '子单女性且年龄范围0-7,包含首次核销和重复入园', 
    `no_mo_female_age_8to17_all`    BIGINT     COMMENT '子单女性且年龄范围8-17,包含首次核销和重复入园', 
    `no_mo_female_age_18to27_all`   BIGINT     COMMENT '子单女性且年龄范围18-27,包含首次核销和重复入园', 
    `no_mo_female_age_28to40_all`   BIGINT     COMMENT '子单女性且年龄范围28-40,包含首次核销和重复入园', 
    `no_mo_female_age_41to60_all`   BIGINT     COMMENT '子单女性且年龄范围41-60,包含首次核销和重复入园', 
    `no_mo_female_age_61plus_all`   BIGINT     COMMENT '子单女性且年龄范围>60,包含首次核销和重复入园', 
    `no_mo_unknown_all`             BIGINT     COMMENT '子单性别年龄未知,包含首次核销和重复入园',
    `no_mo_total_all`               BIGINT     COMMENT '子单总人数,包含首次核销和重复入园',

  	`year` 	                        INT	       COMMENT '年'
)COMMENT '每月核销画像指标表'
PARTITIONED BY (`month` STRING COMMENT '汇总年月例如202010')
STORED AS ORC;


INSERT OVERWRITE TABLE ads_monthly_scenic_verify_draw_d_i PARTITION(`month`)
SELECT 
    drawTab.`sid`                   AS  `sid`,
    `lid`                           AS  `lid`,   
    `tid`                           AS  `tid`,
    `p_type`                        AS  `p_type`,
    `pid`                           AS  `pid`,
    
    `country`                       AS  `country`,
    `province`                      AS  `province`,
    `city`                          AS  `city`,
    `district`                      AS  `district`,

    SUM(`mo_male_age_0to7`)            AS  `mo_male_age_0to7`,
    SUM(`mo_male_age_8to17`)           AS  `mo_male_age_8to17`,
    SUM(`mo_male_age_18to27`)          AS  `mo_male_age_18to27`,
    SUM(`mo_male_age_28to40`)          AS  `mo_male_age_28to40`,
    SUM(`mo_male_age_41to60`)          AS  `mo_male_age_41to60`, 
    SUM(`mo_male_age_61plus`)          AS  `mo_male_age_61plus`,
    SUM(`mo_female_age_0to7`)          AS  `mo_female_age_0to7`,
    SUM(`mo_female_age_8to17`)         AS  `mo_female_age_8to17`,
    SUM(`mo_female_age_18to27`)        AS  `mo_female_age_18to27`, 
    SUM(`mo_female_age_28to40`)        AS  `mo_female_age_28to40`,
    SUM(`mo_female_age_41to60`)        AS  `mo_female_age_41to60`,
    SUM(`mo_female_age_61plus`)        AS  `mo_female_age_61plus`,
    SUM(`mo_unknown`)                  AS  `mo_unknown`,
    SUM(`mo_total`)                    AS  `mo_total`,
    SUM(`mo_male_age_0to7_all`)        AS  `mo_male_age_0to7_all`,   
    SUM(`mo_male_age_8to17_all`)       AS  `mo_male_age_8to17_all`,
    SUM(`mo_male_age_18to27_all`)      AS  `mo_male_age_18to27_all`, 
    SUM(`mo_male_age_28to40_all`)      AS  `mo_male_age_28to40_all`, 
    SUM(`mo_male_age_41to60_all`)      AS  `mo_male_age_41to60_all`, 
    SUM(`mo_male_age_61plus_all`)      AS  `mo_male_age_61plus_all`,  
    SUM(`mo_female_age_0to7_all`)      AS  `mo_female_age_0to7_all`, 
    SUM(`mo_female_age_8to17_all`)     AS  `mo_female_age_8to17_all`, 
    SUM(`mo_female_age_18to27_all`)    AS  `mo_female_age_18to27_all`, 
    SUM(`mo_female_age_28to40_all`)    AS  `mo_female_age_28to40_all`, 
    SUM(`mo_female_age_41to60_all`)    AS  `mo_female_age_41to60_all`, 
    SUM(`mo_female_age_61plus_all`)    AS  `mo_female_age_61plus_all`, 
    SUM(`mo_unknown_all`)              AS  `mo_unknown_all`,
    SUM(`mo_total_all`)                AS  `mo_total_all`,

    SUM(`no_mo_male_age_0to7`)            AS  `no_mo_male_age_0to7`,
    SUM(`no_mo_male_age_8to17`)           AS  `no_mo_male_age_8to17`,
    SUM(`no_mo_male_age_18to27`)          AS  `no_mo_male_age_18to27`,
    SUM(`no_mo_male_age_28to40`)          AS  `no_mo_male_age_28to40`,
    SUM(`no_mo_male_age_41to60`)          AS  `no_mo_male_age_41to60`, 
    SUM(`no_mo_male_age_61plus`)          AS  `no_mo_male_age_61plus`,
    SUM(`no_mo_female_age_0to7`)          AS  `no_mo_female_age_0to7`,
    SUM(`no_mo_female_age_8to17`)         AS  `no_mo_female_age_8to17`,
    SUM(`no_mo_female_age_18to27`)        AS  `no_mo_female_age_18to27`, 
    SUM(`no_mo_female_age_28to40`)        AS  `no_mo_female_age_28to40`,
    SUM(`no_mo_female_age_41to60`)        AS  `no_mo_female_age_41to60`,
    SUM(`no_mo_female_age_61plus`)        AS  `no_mo_female_age_61plus`,
    SUM(`no_mo_unknown`)                  AS  `no_mo_unknown`,
    SUM(`no_mo_total`)                    AS  `no_mo_total`,
    SUM(`no_mo_male_age_0to7_all`)        AS  `no_mo_male_age_0to7_all`,   
    SUM(`no_mo_male_age_8to17_all`)       AS  `no_mo_male_age_8to17_all`,
    SUM(`no_mo_male_age_18to27_all`)      AS  `no_mo_male_age_18to27_all`, 
    SUM(`no_mo_male_age_28to40_all`)      AS  `no_mo_male_age_28to40_all`, 
    SUM(`no_mo_male_age_41to60_all`)      AS  `no_mo_male_age_41to60_all`, 
    SUM(`no_mo_male_age_61plus_all`)      AS  `no_mo_male_age_61plus_all`,  
    SUM(`no_mo_female_age_0to7_all`)      AS  `no_mo_female_age_0to7_all`, 
    SUM(`no_mo_female_age_8to17_all`)     AS  `no_mo_female_age_8to17_all`, 
    SUM(`no_mo_female_age_18to27_all`)    AS  `no_mo_female_age_18to27_all`, 
    SUM(`no_mo_female_age_28to40_all`)    AS  `no_mo_female_age_28to40_all`, 
    SUM(`no_mo_female_age_41to60_all`)    AS  `no_mo_female_age_41to60_all`, 
    SUM(`no_mo_female_age_61plus_all`)    AS  `no_mo_female_age_61plus_all`, 
    SUM(`no_mo_unknown_all`)              AS  `no_mo_unknown_all`,
    SUM(`no_mo_total_all`)                AS  `no_mo_total_all`,

  	`year`,
    `month`
FROM ads_daily_scenic_verify_draw_d_i drawTab
WHERE SUBSTR(`fulldate`, 0, 6) = SUBSTR('${ds}', 0, 6)
GROUP BY 
    `lid`,   
    drawTab.`sid`,
    `pid`,
    `tid`,
    `p_type`,
    `country`,
    `province`,
    `city`,
    `district`,
    `year`,
    `month`;