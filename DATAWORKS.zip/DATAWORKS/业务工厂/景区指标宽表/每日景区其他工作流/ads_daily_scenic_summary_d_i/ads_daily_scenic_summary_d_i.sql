--********************************************************************--
--author: 王海阳
--create time: 2026-09-10 15:12:11
--Serverless Spark SQL任务只能运行在独享资源组上
--********************************************************************--
-- name ads_daily_scenic_summary_d_i
-- type Spark SQL
-- author wanghaiyang@12301.cc
-- create time 2024-12-12 18:00:17
-- desc 每日景区汇总表

SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;

CREATE TABLE IF NOT EXISTS ads_daily_scenic_summary_d_i (
    `year`                    INT         COMMENT '年',
    `month`                   INT         COMMENT '月',
    `week`                    INT         COMMENT '年周',
    sid                       INT         COMMENT '原始供应商id',
    lid                       INT         COMMENT '景区ID',
    tid                       INT         COMMENT '门票id',
    p_type                    STRING      COMMENT '景区类型：A景区B线路C酒店F套票',
    pid                       INT         COMMENT '产品SPUID',
    pay_channel_id            INT         COMMENT '票支付方式ID',
    pay_channel_name          STRING      COMMENT '票支付方式名称',
    channel_class1_id         INT         COMMENT '一级渠道ID',
    channel_class1_name       STRING      COMMENT '一级渠道名称',
    channel_class2_id         INT         COMMENT '二级渠道ID',
    channel_class2_name       STRING      COMMENT '二级渠道名称',
    mo_pay_count              INT         COMMENT '主单_支付订单数',
    mo_pay_ticket             INT         COMMENT '主单_支付票数',
    mo_pay_amount             BIGINT      COMMENT '主单_支付金额',
    mo_verify_ticket          INT         COMMENT '主单_验证票数',
    mo_verify_amount          BIGINT      COMMENT '主单_验证金额',
    mo_cancel_ticket          INT         COMMENT '主单_退票数',
    mo_cancel_amount          BIGINT      COMMENT '主单_退票金额',
    mo_revoke_ticket          INT         COMMENT '主单_撤改/撤销票数',
    mo_revoke_amount          BIGINT      COMMENT '主单_撤改/撤销金额',
    mo_after_sale_ticket      INT         COMMENT '主单_售后票数',
    mo_after_sale_amount      BIGINT      COMMENT '主单_售后金额',
    mo_finish_ticket          INT         COMMENT '主单_完结票数',
    mo_finish_amount          BIGINT      COMMENT '主单_完结金额',
    mo_take_ticket            INT         COMMENT '主单_取票票数',
    mo_take_amount            BIGINT      COMMENT '主单_取票金额',
    no_mo_pay_count           INT         COMMENT '子单_支付订单数',
    no_mo_pay_ticket          INT         COMMENT '子单_支付票数',
    no_mo_pay_amount          BIGINT      COMMENT '子单_支付金额',
    no_mo_verify_ticket       INT         COMMENT '子单_验证票数',
    no_mo_verify_amount       BIGINT      COMMENT '子单_验证金额',
    no_mo_cancel_ticket       INT         COMMENT '子单_退票数',
    no_mo_cancel_amount       BIGINT      COMMENT '子单_退票金额',
    no_mo_revoke_ticket       INT         COMMENT '子单_撤改/撤销票数',
    no_mo_revoke_amount       BIGINT      COMMENT '子单_撤改/撤销金额',
    no_mo_after_sale_ticket   INT         COMMENT '子单_售后票数',
    no_mo_after_sale_amount   BIGINT      COMMENT '子单_售后金额',
    no_mo_finish_ticket       INT         COMMENT '子单_完结票数',
    no_mo_finish_amount       BIGINT      COMMENT '子单_完结金额',
    no_mo_take_ticket         INT         COMMENT '子单_取票票数',
    no_mo_take_amount         BIGINT      COMMENT '子单_取票金额',
    team_pay_count            INT         COMMENT '团单支付订单量',
    team_pay_ticket           INT         COMMENT '团单支付票量',
    team_pay_amount           BIGINT      COMMENT '团单支付金额',
    team_verify_ticket        INT         COMMENT '团单验证票量',
    team_verify_amount        BIGINT      COMMENT '团单验证金额',
    individual_pay_count      INT         COMMENT '散单订单量',
    individual_pay_ticket     INT         COMMENT '散单票量',
    individual_pay_amount     BIGINT      COMMENT '散单金额',
    individual_verify_ticket  INT         COMMENT '散单验证票量',
    individual_verify_amount  BIGINT      COMMENT '散单验证金额'
)
COMMENT '每日景区汇总表'
PARTITIONED BY (fulldate INT COMMENT '全日期 yyyyMMdd')
STORED AS ORC;



INSERT OVERWRITE TABLE ads_daily_scenic_summary_d_i PARTITION(fulldate) 
SELECT 
      YEAR(dim_isoweek.`date`)                            	        AS `year`,
      YEAR(dim_isoweek.`date`) * 100 + MONTH(`date`)      	        AS `month`,	   
      INT(dim_isoweek.`isoweek`)                          	        AS `week`,
      `sid`                                               	        AS `sid`,
      `lid`                                           	            AS `lid`,    
      `tid`                                         	            AS `tid`,
      `p_type`                                            	        AS `p_type`,
      `pid`                                               	        AS `pid`,
      `countTab`.pay_channel_id                                     AS `pay_channel_id`,
      COALESCE(pay_dict.pay_channel_mapping_name, CONCAT('其他(', CAST(countTab.pay_channel_id AS STRING), ')')) 
                                                                    AS `pay_channel_name`,
      `channel_class1_id`                                           AS `channel_class1_id`,
      `channel_class1_name`                                         AS `channel_class1_name`,
      `channel_class2_id`                                           AS `channel_class2_id`,
      `channel_class2_name`                                         AS `channel_class2_name`,
      `mo_pay_count`                                                AS `mo_pay_count`,
      `mo_pay_ticket`                                               AS `mo_pay_ticket`,
      `mo_pay_amount`                                               AS `mo_pay_amount`,
      `mo_verify_ticket`                                            AS `mo_verify_ticket`,
      `mo_verify_amount`                                            AS `mo_verify_amount`,
      `mo_cancel_ticket`                                            AS `mo_cancel_ticket`,
      `mo_cancel_amount`                                            AS `mo_cancel_amount`,
      `mo_revoke_ticket`                                            AS `mo_revoke_ticket`,
      `mo_revoke_amount`                                            AS `mo_revoke_amount`,
      `mo_after_sale_ticket`                                        AS `mo_after_sale_ticket`,
      `mo_after_sale_amount`                                        AS `mo_after_sale_amount`,
      `mo_finish_ticket`                                            AS `mo_finish_ticket`,
      `mo_finish_amount`                                            AS `mo_finish_amount`,
      `mo_take_ticket`                                              AS `mo_take_ticket`,
      `mo_take_amount`                                              AS `mo_take_amount`,
      `no_mo_pay_count`                                             AS `no_mo_pay_count`,
      `no_mo_pay_ticket`                                            AS `no_mo_pay_ticket`,
      `no_mo_pay_amount`                                            AS `no_mo_pay_amount`,
      `no_mo_verify_ticket`                                         AS `no_mo_verify_ticket`,
      `no_mo_verify_amount`                                         AS `no_mo_verify_amount`,
      `no_mo_cancel_ticket`                                         AS `no_mo_cancel_ticket`,
      `no_mo_cancel_amount`                                         AS `no_mo_cancel_amount`,
      `no_mo_revoke_ticket`                                         AS `no_mo_revoke_ticket`,
      `no_mo_revoke_amount`                                         AS `no_mo_revoke_amount`,
      `no_mo_after_sale_ticket`                                     AS `no_mo_after_sale_ticket`,
      `no_mo_after_sale_amount`                                     AS `no_mo_after_sale_amount`,
      `no_mo_finish_ticket`                                         AS `no_mo_finish_ticket`,
      `no_mo_finish_amount`                                         AS `no_mo_finish_amount`,
      `no_mo_take_ticket`                                           AS `no_mo_take_ticket`,
      `no_mo_take_amount`                                           AS `no_mo_take_amount`,
      `team_pay_count`                          		            AS `team_pay_count`,
      `team_pay_ticket`                         		            AS `team_pay_ticket`,
      `team_pay_amount`                         		            AS `team_pay_amount`,
      `team_verify_ticket`                			                AS `team_verify_ticket`,
      `team_verify_amount`               				            AS `team_verify_amount`,
      `individual_pay_count`                    		            AS `individual_pay_count`,
      `individual_pay_ticket`                   		            AS `individual_pay_ticket`,
      `individual_pay_amount`                   		            AS `individual_pay_amount`,
      `individual_verify_ticket`          			                AS `individual_verify_ticket`,
	  `individual_verify_amount`          			                AS `individual_verify_amount`,
      INT(countTab.`fulldate`)
FROM (
    SELECT 
      apply_did                                                                           					                 AS sid,
      lid                                                                                 					                 AS lid,
      tid                                                                                 					                 AS tid,
      product_type                                                                        					                 AS p_type,
      pid                                                                                 					                 AS pid,
      COALESCE(paymode, 255)                                                                                                 AS pay_channel_id,
      channel_class1_id															                                             AS channel_class1_id,
      MAX(channel_class1_name)													                                             AS channel_class1_name,
      channel_class2_id															                                             AS channel_class2_id,
      MAX(channel_class2_name)													                                             AS channel_class2_name,
      COUNT(DISTINCT IF(order_type != '套票子票' AND pay_ticket_num > 0, ordernum, NULL))                                     AS mo_pay_count,
      SUM(IF(order_type != '套票子票', pay_ticket_num, 0))                                                                    AS mo_pay_ticket,
      SUM(IF(order_type != '套票子票', pay_ticket_moner, 0))                                                                  AS mo_pay_amount,
      SUM(IF(order_type != '套票子票', verify_ticket_num, 0))                                                                 AS mo_verify_ticket,
      SUM(IF(order_type != '套票子票', verify_ticket_moner, 0))                                                               AS mo_verify_amount,
      SUM(IF(order_type != '套票子票', cancel_ticket_num, 0))                                                                 AS mo_cancel_ticket,
      SUM(IF(order_type != '套票子票', cancel_ticket_moner, 0))                                                               AS mo_cancel_amount,
      SUM(IF(order_type != '套票子票', revoke_ticket_num, 0))                                                                 AS mo_revoke_ticket,
      SUM(IF(order_type != '套票子票', revoke_ticket_moner, 0))                                                               AS mo_revoke_amount,
      SUM(IF(order_type != '套票子票', after_sale_ticket_num, 0))                                                             AS mo_after_sale_ticket,
      SUM(IF(order_type != '套票子票', after_sale_ticket_moner, 0))                                                           AS mo_after_sale_amount,
      SUM(IF(order_type != '套票子票', finish_ticket_num, 0))                                                                 AS mo_finish_ticket,
      SUM(IF(order_type != '套票子票', finish_ticket_moner, 0))                                                               AS mo_finish_amount,
      SUM(IF(order_type != '套票子票', take_ticket_num, 0))                                                                   AS mo_take_ticket,
      SUM(IF(order_type != '套票子票', take_ticket_moner, 0))                                                                 AS mo_take_amount,
      COUNT(DISTINCT IF(order_type = '套票子票' AND pay_ticket_num > 0, ordernum, NULL))                                      AS no_mo_pay_count,
      SUM(IF(order_type = '套票子票', pay_ticket_num, 0))                                                                     AS no_mo_pay_ticket,
      SUM(IF(order_type = '套票子票', pay_ticket_moner, 0))                                                                   AS no_mo_pay_amount,
      SUM(IF(order_type = '套票子票', verify_ticket_num, 0))                                                                  AS no_mo_verify_ticket,
      SUM(IF(order_type = '套票子票', verify_ticket_moner, 0))                                                                AS no_mo_verify_amount,
      SUM(IF(order_type = '套票子票', cancel_ticket_num, 0))                                                                  AS no_mo_cancel_ticket,
      SUM(IF(order_type = '套票子票', cancel_ticket_moner, 0))                                                                AS no_mo_cancel_amount,
      SUM(IF(order_type = '套票子票', revoke_ticket_num, 0))                                                                  AS no_mo_revoke_ticket,
      SUM(IF(order_type = '套票子票', revoke_ticket_moner, 0))                                                                AS no_mo_revoke_amount,
      SUM(IF(order_type = '套票子票', after_sale_ticket_num, 0))                                                              AS no_mo_after_sale_ticket,
      SUM(IF(order_type = '套票子票', after_sale_ticket_moner, 0))                                                            AS no_mo_after_sale_amount,
      SUM(IF(order_type = '套票子票', finish_ticket_num, 0))                                                                  AS no_mo_finish_ticket,
      SUM(IF(order_type = '套票子票', finish_ticket_moner, 0))                                                                AS no_mo_finish_amount,
      SUM(IF(order_type = '套票子票', take_ticket_num, 0))                                                                    AS no_mo_take_ticket,
      SUM(IF(order_type = '套票子票', take_ticket_moner, 0))                                                                  AS no_mo_take_amount,
      COUNT(DISTINCT IF(order_type != '套票子票' AND main_ordernum IS NOT NULL AND pay_ticket_num > 0, ordernum, NULL))       AS team_pay_count,
      SUM(IF(order_type != '套票子票' AND main_ordernum IS NOT NULL, pay_ticket_num, 0))                                      AS team_pay_ticket,
      SUM(IF(order_type != '套票子票' AND main_ordernum IS NOT NULL, pay_ticket_moner, 0))                                    AS team_pay_amount,
      SUM(IF(order_type != '套票子票' AND main_ordernum IS NOT NULL, verify_ticket_num, 0))                                   AS team_verify_ticket,
      SUM(IF(order_type != '套票子票' AND main_ordernum IS NOT NULL, verify_ticket_moner, 0))                                 AS team_verify_amount,
      COUNT(DISTINCT IF(order_type != '套票子票' AND main_ordernum IS NULL AND pay_ticket_num > 0, ordernum, NULL))           AS individual_pay_count,
      SUM(IF(order_type != '套票子票' AND main_ordernum IS NULL, pay_ticket_num, 0))                                          AS individual_pay_ticket,
      SUM(IF(order_type != '套票子票' AND main_ordernum IS NULL, pay_ticket_moner, 0))                                        AS individual_pay_amount,
      SUM(IF(order_type != '套票子票' AND main_ordernum IS NULL, verify_ticket_num, 0))                                       AS individual_verify_ticket,
      SUM(IF(order_type != '套票子票' AND main_ordernum IS NULL, verify_ticket_moner, 0))                                     AS individual_verify_amount,
      insertdate                                                                                                              AS fulldate
    FROM dwd_order_track_d_i trackTab
    LEFT JOIN (
      SELECT main_ordernum, son_ordernum
      FROM ods_uu_ss_order_team_link_d_f
      WHERE pt = DATE_FORMAT(DATE_SUB(CURRENT_DATE(), 1),"yyyyMMdd")
    ) teamTab 
    ON trackTab.ordernum = teamTab.son_ordernum
    WHERE insertdate = '${ds}'
        AND lid is not null
        AND apply_did!=0
    GROUP BY 
        apply_did,
        lid,
        tid,
        product_type,
        pid,
	    COALESCE(paymode, 255),
	    channel_class1_id,
	    channel_class2_id,
        insertdate
) countTab
LEFT JOIN dim_date_isoweek_o_f dim_isoweek 
ON countTab.fulldate = dim_isoweek.fulldate
LEFT JOIN dim_pay_channel_o_f pay_dict
ON countTab.pay_channel_id = pay_dict.pay_channel_id;



