-- name ads_daily_scenic_ticket_toi_d_i
-- type Spark SQL
-- author wanghaiyang@12301.cc
-- create time 2024-12-12 18:00:17
-- desc 景区每日门票团散单指标表

SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;

CREATE TABLE IF NOT EXISTS ads_daily_scenic_toi_d_i(
    `year`				                                INT     COMMENT '年',
    `month`				                                INT     COMMENT '月',
    `week`				                                INT     COMMENT '年周',

    `sid`				                                INT     COMMENT '原始供应商id',
    `lid`				                                INT     COMMENT '景区ID',    
    `tid`                                               INT     COMMENT '票ID',
    `p_type`                                            STRING  COMMENT '景区类型：A景区B线路C酒店F套票',
    `pid`                                               INT     COMMENT '产品SPUID',
    
    `team_order_count`                                  BIGINT	COMMENT '团单支付订单量',
	`team_ticket_count`                                 BIGINT	COMMENT '团单支付票数统计',
	`team_order_amount`                                 BIGINT	COMMENT '团单支付金额统计',
	`team_ticket_avg_price`                             INT     COMMENT '团单支付平均票价',

	`verified_team_ticket_count`                        BIGINT	COMMENT '团单验证票数统计',
	`verified_team_order_amount`                        BIGINT	COMMENT '团单验证金额统计',
	`verified_team_ticket_avg_price`                    INT     COMMENT '团单验证平均票价',

	`individual_order_count`    	                    BIGINT	COMMENT '散客订单量',
	`individual_ticket_count`   	                    BIGINT	COMMENT '散客票量统计',
	`individual_order_amount`   	                    BIGINT	COMMENT '散客金额统计',
	`individual_ticket_avg_price`                       INT	    COMMENT '散客平均票价',

    `verified_individual_ticket_count`                  BIGINT	COMMENT '散客验证票数统计',
	`verified_individual_order_amount`                  BIGINT	COMMENT '散客验证金额统计',
	`verified_individual_ticket_avg_price`              INT     COMMENT '散客验证平均票价'
)COMMENT '景区每日门票团散单指标表'
PARTITIONED BY (fulldate INT COMMENT '全日期')
STORED AS ORC;


INSERT OVERWRITE TABLE ads_daily_scenic_toi_d_i PARTITION(fulldate) 
SELECT 

  YEAR(dim_isoweek.`date`)                            AS `year`,
  YEAR(dim_isoweek.`date`) * 100 + MONTH(`date`)      AS `month`,	   
  INT(dim_isoweek.`isoweek`)                          AS `week`,

  `sid`                                               AS `sid`,
  `lid`                                               AS `lid`,    
  `tid`                                               AS `tid`,
  `p_type`                                            AS `p_type`,
  `pid`                                               AS `pid`,
    
  NVL(`team_order_count`,0)                           AS `team_order_count`,
  NVL(`team_ticket_count`,0)                          AS `team_ticket_count`,
  NVL(`team_order_amount`,0)                          AS `team_order_amount`,
  NVL(`team_ticket_avg_price`,0)                      AS `team_ticket_avg_price`,

  NVL(`verified_team_ticket_count`,0)                 AS `verified_team_ticket_count`,
  NVL(`verified_team_order_amount`,0)                 AS `verified_team_order_amount`,
  NVL(`verified_team_ticket_avg_price`,0)             AS `verified_team_ticket_avg_price`,

  NVL(`individual_order_count`,0)                     AS `individual_order_count`,
  NVL(`individual_ticket_count`,0)                    AS `individual_ticket_count`,
  NVL(`individual_order_amount`,0)                    AS `individual_order_amount`,
  NVL(`individual_ticket_avg_price`,0)                AS `individual_ticket_avg_price`,   

  NVL(`verified_individual_ticket_count`,0)           AS `verified_individual_ticket_count`,
  NVL(`verified_individual_order_amount`,0)           AS `verified_individual_order_amount`,
  NVL(`verified_individual_ticket_avg_price`,0)       AS `verified_individual_ticket_avg_price`,
  INT(dim_isoweek.`fulldate`)
FROM (
    SELECT 
        insertdate                                                                          AS fulldate,
        apply_did                                                                           AS sid,
        lid                                                                                 AS lid,
        tid                                                                                 AS tid,
        product_type                                                                        AS p_type,
        pid                                                                                 AS pid,
        
        COUNT(DISTINCT IF(order_type != '套票子票' AND main_ordernum IS NOT NULL AND pay_ticket_num > 0, ordernum, NULL))     AS team_order_count,
        SUM(IF(order_type != '套票子票' AND main_ordernum IS NOT NULL, pay_ticket_num, 0))                                    AS team_ticket_count,
        SUM(IF(order_type != '套票子票' AND main_ordernum IS NOT NULL, pay_ticket_moner, 0))                                  AS team_order_amount,
        ROUND(SUM(IF(order_type != '套票子票' AND main_ordernum IS NOT NULL, pay_ticket_moner, 0))
        / NULLIF(SUM(IF(order_type != '套票子票' AND main_ordernum IS NOT NULL, pay_ticket_num, 0)), 0))                      AS team_ticket_avg_price,

        SUM(IF(order_type != '套票子票' AND main_ordernum IS NOT NULL, verify_ticket_num, 0))                                 AS verified_team_ticket_count,
        SUM(IF(order_type != '套票子票' AND main_ordernum IS NOT NULL, verify_ticket_moner, 0))                               AS verified_team_order_amount,
        ROUND(SUM(IF(order_type != '套票子票' AND main_ordernum IS NOT NULL, verify_ticket_moner, 0))
        / NULLIF(SUM(IF(order_type != '套票子票' AND main_ordernum IS NOT NULL, verify_ticket_num, 0)), 0))                   AS verified_team_ticket_avg_price,  

        COUNT(DISTINCT IF(order_type != '套票子票' AND main_ordernum IS NULL AND pay_ticket_num > 0, ordernum, NULL))         AS individual_order_count,
        SUM(IF(order_type != '套票子票' AND main_ordernum IS NULL, pay_ticket_num, 0))                                        AS individual_ticket_count,
        SUM(IF(order_type != '套票子票' AND main_ordernum IS NULL, pay_ticket_moner, 0))                                      AS individual_order_amount,
        ROUND(SUM(IF(order_type != '套票子票' AND main_ordernum IS NULL, pay_ticket_moner, 0))
        / NULLIF(SUM(IF(order_type != '套票子票' AND main_ordernum IS NULL, pay_ticket_num, 0)), 0))                          AS individual_ticket_avg_price,

        SUM(IF(order_type != '套票子票' AND main_ordernum IS NULL, verify_ticket_num, 0))                                     AS verified_individual_ticket_count,
        SUM(IF(order_type != '套票子票' AND main_ordernum IS NULL, verify_ticket_moner, 0))                                   AS verified_individual_order_amount,
        ROUND(SUM(IF(order_type != '套票子票' AND main_ordernum IS NULL, verify_ticket_moner, 0))
        / NULLIF(SUM(IF(order_type != '套票子票' AND main_ordernum IS NULL, verify_ticket_num, 0)), 0))                       AS verified_individual_ticket_avg_price
		
     FROM dwd_order_track_d_i trackTab
    LEFT JOIN (
      SELECT main_ordernum, son_ordernum
      FROM ods_uu_ss_order_team_link_d_f
      WHERE pt = DATE_FORMAT(DATE_SUB(CURRENT_DATE(), 1),"yyyyMMdd")
    ) teamTab 
    ON trackTab.ordernum = teamTab.son_ordernum
    WHERE insertdate = ${ds}
        AND lid is not null
        AND apply_did!=0
    GROUP BY 
        apply_did,
        lid,
        tid,
        product_type,
        pid,
        insertdate
) countTab
LEFT JOIN dim_date_isoweek_o_f AS dim_isoweek 
ON `countTab`.fulldate = dim_isoweek.`fulldate`;