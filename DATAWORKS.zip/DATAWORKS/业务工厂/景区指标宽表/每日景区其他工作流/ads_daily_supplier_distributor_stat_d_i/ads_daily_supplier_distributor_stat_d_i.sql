--Serverless Spark SQL
--********************************************************************--
--author: 王海阳
--create time: 2026-03-12 15:28:43
--Serverless Spark SQL任务只能运行在独享资源组上
--********************************************************************--
SET spark.sql.mergeSmallFiles.enabled=true;
SET hive.exec.dynamic.partition.mode=nonstrict;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;

CREATE TABLE IF NOT EXISTS ads_daily_supplier_distributor_stat_d_i(
    `sid`                   INT     COMMENT '商户ID',
    `sname`                 STRING  COMMENT '商户名称',
    `year`                  INT 	COMMENT '报告年份,年份,例如2022',
    `quarter`               INT 	COMMENT '报告季度,年+季度,例如:202201',
    `month`                 INT 	COMMENT '报告月份,年+月,例如:202203',
    `week`                  INT 	COMMENT '报告周,年+ISOweek,例如:202211',
    `distributor_id`        INT     COMMENT '分销商ID',
    `distributor_name`      STRING  COMMENT '分销商名称',
    `paid_ticket_count`     BIGINT  COMMENT '支付票数',
    `paid_amount`           BIGINT  COMMENT '支付金额(分)',
    `verify_ticket_count`   BIGINT  COMMENT '验证票数',
    `verify_amount`         BIGINT  COMMENT '验证金额(分)',
    `cancel_ticket_count`   BIGINT  COMMENT '取消票数',
    `cancel_amount`         BIGINT  COMMENT '取消金额(分)'
)COMMENT '供应商每日分销商统计表'
PARTITIONED BY(
   `fulldate`               INT  COMMENT '日期,例如20220101'
)STORED AS ORC;

INSERT OVERWRITE TABLE ads_daily_supplier_distributor_stat_d_i PARTITION(fulldate)
SELECT   
        countTab.sid                                    AS  `sid`, 
        userTab.sname                                   AS  `sname`, 
        YEAR(date)                                      AS  `year`,
        YEAR(date) * 100 + QUARTER(date)                AS  `quarter`,
        YEAR(date) * 100 + MONTH(date)                  AS  `month`,
        INT(dim_isoweek.isoweek)						AS 	`week`,
        countTab.distributor_id                         AS  `distributor_id`, 
        distributorTab.distributor_name                 AS  `distributor_name`,
        NVL(countTab.paid_ticket_count,0)               AS  `paid_ticket_count`,
        NVL(countTab.paid_amount,0)                     AS  `paid_amount`,
        NVL(countTab.verify_ticket_count,0)             AS  `verify_ticket_count`,
        NVL(countTab.verify_amount,0)                   AS  `verify_amount`,
        NVL(countTab.cancel_ticket_count,0)             AS  `cancel_ticket_count`,
        NVL(countTab.cancel_amount,0)                   AS  `cancel_amount`,
        countTab.fulldate                               AS  `fulldate`
FROM(
   SELECT 
        sid, 
        reseller_id AS  distributor_id,
        date as fulldate,
        SUM(order_ticket) AS paid_ticket_count,
        SUM(order_sale_money) AS paid_amount,
        SUM(verify_ticket + finish_ticket) AS verify_ticket_count,
        SUM(verify_sale_money + finish_sale_money) AS verify_amount,
        SUM(cancel_ticket + revoke_ticket) AS cancel_ticket_count,
        SUM(cancel_sale_money + revoke_sale_money) AS cancel_amount
    FROM dws_daily_report_summary_full_d_i
    WHERE date='${ds}'
        AND level in(0, 1)
        AND sid != reseller_id
        AND order_ticket + verify_ticket + cancel_ticket + finish_ticket + revoke_ticket> 0
    GROUP BY sid, reseller_id, date
) countTab
JOIN (
	SELECT user_id, user_name as sname
	FROM ods_pft_member_d_f
	WHERE pt = DATE_FORMAT(DATE_SUB(CURRENT_DATE(), 1),"yyyyMMdd")
	    AND (group_id != 2 or user_id = 3385 or user_id = 6970) 
) userTab
ON countTab.sid = userTab.user_id
JOIN (
    SELECT user_id, user_name as distributor_name
	FROM ods_pft_member_d_f
	WHERE pt = DATE_FORMAT(DATE_SUB(CURRENT_DATE(), 1),"yyyyMMdd")
		AND user_type_code != 5
		AND user_name != ''
        AND group_id != 2
) distributorTab
ON countTab.distributor_id = distributorTab.user_id
LEFT JOIN dim_date_isoweek_o_f dim_isoweek 
ON countTab.fulldate = dim_isoweek.fulldate
;