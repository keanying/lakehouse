-- name ads_yearly_scenic_toi_d_i
-- type Spark SQL
-- author wanghaiyang@12301.cc
-- create time 2024-12-12 18:00:17
-- desc 景区每年团散单指标表

SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;

CREATE TABLE IF NOT EXISTS ads_yearly_scenic_toi_d_i(
    `sid`				                        INT     COMMENT '原始供应商id', 
    `lid`				                                INT     COMMENT '景区ID',    
    `tid`                                       INT     COMMENT '票ID',
    `p_type`                                    STRING  COMMENT '景区类型：A景区B线路C酒店F套票',
    `pid`                                       INT     COMMENT '产品SPUID',
    
    `team_order_count`                          BIGINT	COMMENT '团单支付订单量',
	`team_ticket_count`                         BIGINT	COMMENT '团单支付票量统计',
	`team_order_amount`                         BIGINT	COMMENT '团单支付金额统计',
	`team_ticket_avg_price`                     INT     COMMENT '团单支付平均票价',

	`verified_team_ticket_count`                BIGINT	COMMENT '团单验证票量统计',
	`verified_team_order_amount`                BIGINT	COMMENT '团单验证金额统计',
	`verified_team_ticket_avg_price`            INT     COMMENT '团单验证平均票价',

	`individual_order_count`    	            BIGINT	COMMENT '散客订单量',
	`individual_ticket_count`   	            BIGINT	COMMENT '散客票量统计',
	`individual_order_amount`   	            BIGINT	COMMENT '散客金额统计',
	`individual_ticket_avg_price`               INT	    COMMENT '散客平均票价',

    `verified_individual_ticket_count`          BIGINT	COMMENT '散客验证票量统计',
	`verified_individual_order_amount`          BIGINT	COMMENT '散客验证金额统计',
	`verified_individual_ticket_avg_price`      INT     COMMENT '散客验证平均票价'
)COMMENT '景区每年团散单指标表'
PARTITIONED BY (`year` INT COMMENT '年')
STORED AS ORC;


INSERT OVERWRITE TABLE ads_yearly_scenic_toi_d_i PARTITION(year)
SELECT 
    `sid`,
    `lid`,  
    `tid`,      
    `p_type`,
    `pid`,
    NVL(SUM(`team_order_count`),0)                   										AS 	`team_order_count`,
	NVL(SUM(`team_ticket_count`),0)															AS 	`team_ticket_count`,
	NVL(SUM(`team_order_amount`),0)															AS 	`team_order_amount`,
	NVL(ROUND(SUM(`team_order_amount`)/SUM(team_ticket_count)),0)							AS 	`team_ticket_avg_price`,

	NVL(SUM(`verified_team_ticket_count`),0)												AS 	`verified_team_ticket_count`,
	NVL(SUM(`verified_team_order_amount`),0)												AS 	`verified_team_order_amount`,
	NVL(ROUND(SUM(`verified_team_order_amount`)/SUM(verified_team_ticket_count)),0)			AS 	`verified_team_ticket_avg_price`,

	NVL(SUM(`individual_order_count`),0)													AS 	`individual_order_count`,
	NVL(SUM(`individual_ticket_count`),0)													AS 	`individual_ticket_count`,
	NVL(SUM(`individual_order_amount`),0)													AS 	`individual_order_amount`,
	NVL(ROUND(SUM(`individual_order_amount`)/SUM(`individual_ticket_count`)),0)				AS 	`individual_ticket_avg_price`,

    NVL(SUM(`verified_individual_ticket_count`),0)											AS 	`verified_individual_ticket_count`,
	NVL(SUM(`verified_individual_order_amount`),0)											AS 	`verified_individual_order_amount`,
	NVL(ROUND(SUM(`verified_individual_order_amount`)/SUM(`verified_individual_ticket_count`)),0)			
																							AS 	`verified_individual_ticket_avg_price`,
	`year`
FROM ads_monthly_scenic_toi_d_i
WHERE SUBSTR(`month`, 0, 4) = SUBSTR('${ds}', 0, 4)
GROUP BY 
  `year`,
  `sid`,
  `lid`,    
  `tid`,
  `p_type`,
  `pid`;