-- name ads_daily_ticket_refund_ratio_d_i
-- type Spark SQL
-- author liangleichen@12301.cc
-- create time 2024-10-08 15:48:23
-- desc 

SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;

CREATE TABLE IF NOT EXISTS ads_daily_ticket_refund_ratio_d_i(
    sid                         INT     COMMENT '原始供应商ID',
    lid                         INT     COMMENT '景区id',

    channel_class1_id           INT     COMMENT '渠道一级分类id',
    channel_class1_name         STRING  COMMENT '渠道一级分类名称',
    channel_class2_id           INT     COMMENT '渠道二级分类id',
    channel_class2_name         STRING  COMMENT '渠道二级分类名称',

    mo_pay_ticket_num           INT     COMMENT '主单_支付票数',
    mo_cancel_ticket_num        INT     COMMENT '主单_退票数',
    mo_revoke_ticket_num        INT     COMMENT '主单_撤改/撤销票数',
    mo_after_sale_ticket_num    INT     COMMENT '主单_售后票数',

    no_mo_pay_ticket_num        INT     COMMENT '子单_支付票数',
    no_mo_cancel_ticket_num     INT     COMMENT '子单_退票数',
    no_mo_revoke_ticket_num     INT     COMMENT '子单_撤改/撤销票数',
    no_mo_after_sale_ticket_num INT     COMMENT '子单_售后票数',

    year                        INT     COMMENT '年',
    month                       INT     COMMENT '月',
    week                        INT     COMMENT '年周'
)COMMENT '退票率指标表' PARTITIONED by(
    fulldate                INT  COMMENT '全日期'
)STORED AS ORC;


INSERT OVERWRITE TABLE ads_daily_ticket_refund_ratio_d_i PARTITION(fulldate)
SELECT 
    apply_did       AS sid,
    lid,

    channel_class1_id,
    MAX(channel_class1_name),
    channel_class2_id,
    MAX(channel_class2_name),

    SUM(IF(order_type IN ('套票主票', '单票'), pay_ticket_num, 0))          AS mo_pay_ticket_num,
    SUM(IF(order_type IN ('套票主票', '单票'), cancel_ticket_num, 0))       AS mo_cancel_ticket_num,
    SUM(IF(order_type IN ('套票主票', '单票'), revoke_ticket_num, 0))       AS mo_revoke_ticket_num,
    SUM(IF(order_type IN ('套票主票', '单票'), after_sale_ticket_num, 0))   AS mo_after_sale_ticket_num,

    SUM(IF(order_type IN ('套票子票'), pay_ticket_num, 0))                  AS no_mo_pay_ticket_num,
    SUM(IF(order_type IN ('套票子票'), cancel_ticket_num, 0))               AS no_mo_cancel_ticket_num,
    SUM(IF(order_type IN ('套票子票'), revoke_ticket_num, 0))               AS no_mo_revoke_ticket_num,
    SUM(IF(order_type IN ('套票子票'), after_sale_ticket_num, 0))           AS no_mo_after_sale_ticket_num,

    YEAR(dim_week.`date`)                                                  AS `year`,
    YEAR(dim_week.`date`) * 100 + MONTH(`date`)                            AS `month`,	   
    INT(dim_week.`isoweek`)                                                AS `week`,
    INT(dim_week.`fulldate`)                                               AS `fulldate`
FROM dwd_order_track_d_i AS track
LEFT JOIN dim_date_isoweek_o_f AS dim_week
ON track.insertdate = dim_week.`fulldate`
WHERE insertdate = '${ds}'
    AND lid IS NOT NULL
GROUP BY apply_did, lid, channel_class1_id, channel_class2_id, dim_week.isoweek, dim_week.fulldate, dim_week.date


