-- name ads_monthly_supplier_distributor_stat_d_i
-- type Spark SQL
-- author wanghaiyang@12301.cc
-- create time 2024-11-11 19:11:53
-- desc 供应商每月分销商统计表(只统计一级分销商且不包含自供自销)

SET spark.sql.mergeSmallFiles.enabled=true;
SET hive.exec.dynamic.partition.mode=nonstrict;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;

CREATE TABLE IF NOT EXISTS ads_monthly_supplier_distributor_stat_d_i(
    `sid`                   INT     COMMENT '商户ID',
    `sname`                 STRING  COMMENT '商户名称',
    `year`                  INT 	COMMENT '报告年份,年份,例如2022',
    `quarter`               INT 	COMMENT '报告季度,年+季度,例如:202201',
    `distributor_id`        INT     COMMENT '分销商ID',
    `distributor_name`      STRING  COMMENT '分销商名称',
    `paid_ticket_count`     BIGINT  COMMENT '支付票数',
    `paid_amount`           BIGINT  COMMENT '支付金额(分)',
    `verify_ticket_count`   BIGINT  COMMENT '验证票数',
    `verify_amount`         BIGINT  COMMENT '验证金额(分)',
    `cancel_ticket_count`   BIGINT  COMMENT '取消票数',
    `cancel_amount`         BIGINT  COMMENT '取消金额(分)'
)COMMENT '供应商每月分销商统计表'
PARTITIONED BY(
   `month`               STRING  COMMENT '年月'
)STORED AS ORC;

INSERT OVERWRITE TABLE ads_monthly_supplier_distributor_stat_d_i PARTITION(month)
SELECT   
        sid                                             AS  `sid`, 
        MAX(sname)                                      AS  `sname`, 
        `year`                                          AS  `year`,
        `quarter`                                       AS  `quarter`,
        distributor_id                                  AS  `distributor_id`, 
        MAX(distributor_name)                           AS  `distributor_name`,
        SUM(paid_ticket_count)                          AS  `paid_ticket_count`,
        SUM(paid_amount)                                AS  `paid_amount`,
        SUM(verify_ticket_count)                        AS  `verify_ticket_count`,
        SUM(verify_amount)                              AS  `verify_amount`,
        SUM(cancel_ticket_count)                        AS  `cancel_ticket_count`,
        SUM(cancel_amount)                              AS  `cancel_amount`,
        month
FROM ads_daily_supplier_distributor_stat_d_i
WHERE SUBSTR(`fulldate`, 0, 6) = SUBSTR('${ds}', 0, 6)
GROUP BY 
    sid,
    `year`,
    `quarter`,
    `month`,
    `distributor_id`;