-- name ads_daily_scenic_estimate_o_f
-- type Spark SQL
-- author liangleichen@12301.cc
-- create time 2023-05-30 17:10:03
-- desc 景区客流预测指标表

SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;

CREATE TABLE IF NOT EXISTS `ads_daily_scenic_estimate_d_f` (
	`land_id` 	            INT     COMMENT '景区ID',
	`land_name`             STRING  COMMENT '景区名称',
    `p_type`                STRING  COMMENT '景区类型：A景区B线路C酒店F套票',
    `sid`                   INT     COMMENT '原始供应商id',
	`estimate_fulldate`     INT     COMMENT '预测日期',
    `tourist_count`         BIGINT  COMMENT '预测游客数',
	`mo_tourist_count`      BIGINT  COMMENT '主单预测游客数',
    `no_mo_tourist_count`   BIGINT  COMMENT '子单预测游客数'
) COMMENT '景区每日客流预测指标表'
STORED AS ORC;


DROP VIEW IF EXISTS CACHE_biZhi_table;
-- 1. 全司放大用系数，今年最近一个除以去年最近一个月的比值
CACHE TABLE CACHE_biZhi_table
AS 
SELECT 
(
    -- 今年最近三十天总游客数量<不含今天>
    SELECT SUM(IF(order_type!='套票子票', ticket_num, 0))  AS mo_current_month_sum_ticket
    FROM dwd_order_d_i 
    WHERE 1=1
      AND booking_date <= DATE_FORMAT(DATE_SUB(CURRENT_DATE(), 1), 'yyyyMMdd')
      AND booking_date >= DATE_FORMAT(DATE_SUB(CURRENT_DATE(), 31), 'yyyyMMdd')
) 
    /
(
    -- 去年同期最近三十天总游客数量<不含当天>
    SELECT SUM(IF(order_type!='套票子票', ticket_num, 0)) 	AS mo_last_month_sum_ticket
    FROM dwd_order_d_i 
    WHERE 1=1
      AND booking_date <= DATE_FORMAT(DATE_SUB(ADD_MONTHS(CURRENT_DATE(), -12), 1), 'yyyyMMdd')
      AND booking_date >= DATE_FORMAT(DATE_SUB(ADD_MONTHS(CURRENT_DATE(), -12), 31), 'yyyyMMdd')
) AS mo_bizhi,
(
    -- 今年最近三十天总游客数量<不含今天>
    SELECT SUM(IF(order_type='套票子票', ticket_num, 0))  AS no_mo_current_month_sum_ticket
    FROM dwd_order_d_i 
    WHERE 1=1
      AND booking_date <= DATE_FORMAT(DATE_SUB(CURRENT_DATE(), 1), 'yyyyMMdd')
      AND booking_date >= DATE_FORMAT(DATE_SUB(CURRENT_DATE(), 31), 'yyyyMMdd')
) 
    /
(
    -- 去年同期最近三十天总游客数量<不含当天>
    SELECT SUM(IF(order_type='套票子票', ticket_num, 0)) 	AS no_mo_last_month_sum_ticket
    FROM dwd_order_d_i 
    WHERE 1=1
      AND booking_date <= DATE_FORMAT(DATE_SUB(ADD_MONTHS(CURRENT_DATE(), -12), 1), 'yyyyMMdd')
      AND booking_date >= DATE_FORMAT(DATE_SUB(ADD_MONTHS(CURRENT_DATE(), -12), 31), 'yyyyMMdd')
) AS no_mo_bizhi
;

DROP VIEW IF EXISTS CACHE_future_table;
-- 2. 公司未来一个月每日的总数据（含今日）
CACHE TABLE CACHE_future_table
AS 
SELECT 
    CASE 
        -- 今年是闰年，且预测二月数据，由于ADD_MONTHS函数对于闰年前一年的2月28日结果为今年29日，需要特殊处理
        WHEN 
        (
            (
                YEAR(CURRENT_DATE()) % 4 = 0 AND YEAR(CURRENT_DATE()) % 100 != 0
            ) 
            OR YEAR(CURRENT_DATE()) % 400 = 0
        ) AND MONTH(CURRENT_DATE()) = 2 
        THEN DATE_ADD(to_date(booking_date, 'yyyyMMdd'), 365)
        -- 普通年份
        ELSE ADD_MONTHS(to_date(booking_date, 'yyyyMMdd'), 12)
    END                                                 AS `booking_date`,    
    mo_tourist_count * mo_sum_bizhi                     AS `mo_tourist_count_sum`,
    no_mo_tourist_count * no_mo_sum_bizhi               AS `no_mo_tourist_count_sum`
FROM 
(
    SELECT 
        booking_date                                    AS `booking_date`, 
        SUM(IF(order_type!='套票子票', ticket_num, 0))  AS `mo_tourist_count`,
        SUM(IF(order_type='套票子票', ticket_num, 0))   AS `no_mo_tourist_count`
    FROM dwd_order_d_i 
    WHERE 1=1
      --AND booking_date >= ADD_MONTHS(CURRENT_DATE(), -12)
      --AND booking_date <= DATE_ADD(ADD_MONTHS(CURRENT_DATE(), -12), 30)
      AND booking_date >= DATE_FORMAT(ADD_MONTHS(CURRENT_DATE(), -12), 'yyyyMMdd')
      AND booking_date <= DATE_FORMAT(DATE_ADD(ADD_MONTHS(CURRENT_DATE(), -12), 30), 'yyyyMMdd')      
    GROUP BY booking_date
)
LEFT JOIN 
(
    SELECT SUM(mo_bizhi)   AS `mo_sum_bizhi`, SUM(no_mo_bizhi)   AS `no_mo_sum_bizhi`
    FROM CACHE_biZhi_table
) AS tab
ON 1=1;

DROP VIEW IF EXISTS CACHE_biZhi2_table;
-- 3. 过去一个月，每个商户总人数占全司的比重
CACHE TABLE CACHE_biZhi2_table
AS
SELECT 
    land_id,
    p_type,
    apply_did,
    mo_land_tourist_count / mo_tourist_count                AS mo_biZhi2,
    no_mo_land_tourist_count / no_mo_tourist_count          AS no_mo_biZhi2  
FROM 
(
    SELECT 
        land_id                                             AS land_id,
        land_type                                           AS p_type,
        apply_did                                           AS apply_did,
        SUM(IF(order_type!='套票子票', ticket_num, 0))      AS `mo_land_tourist_count`,
        SUM(IF(order_type='套票子票', ticket_num, 0))       AS `no_mo_land_tourist_count`
    FROM dwd_order_d_i 
    WHERE 1=1
      AND booking_date >= DATE_FORMAT(DATE_SUB(CURRENT_DATE(), 31), 'yyyyMMdd')
      AND booking_date <= DATE_FORMAT(DATE_SUB(CURRENT_DATE(), 1), 'yyyyMMdd')
    GROUP BY land_id, land_type, apply_did
) AS land_sum_num
LEFT JOIN 
(
    SELECT 
        SUM(IF(order_type!='套票子票', ticket_num, 0))       AS `mo_tourist_count`,
        SUM(IF(order_type='套票子票', ticket_num, 0))        AS `no_mo_tourist_count`
    FROM dwd_order_d_i 
    WHERE 1=1
      AND booking_date >= DATE_FORMAT(DATE_SUB(CURRENT_DATE(), 31), 'yyyyMMdd')
      AND booking_date <= DATE_FORMAT(DATE_SUB(CURRENT_DATE(), 1), 'yyyyMMdd')
) AS company_sum_num
ON 1 = 1;


INSERT OVERWRITE TABLE ads_daily_scenic_estimate_d_f
SELECT 
    land_id                                             AS land_id,
    landTab.title                                       AS land_name,
    p_type                                              AS p_type,
    INT(apply_did)                                      AS sid,
    INT(DATE_FORMAT(booking_date, 'yyyyMMdd'))          AS estimate_fulldate,
    ROUND(mo_biZhi2 * mo_tourist_count_sum + no_mo_biZhi2 * no_mo_tourist_count_sum, 0)          
                                                        AS tourist_count,
    ROUND(mo_biZhi2 * mo_tourist_count_sum, 0)          AS mo_tourist_count,
    ROUND(no_mo_biZhi2 * no_mo_tourist_count_sum, 0)    AS no_mo_tourist_count
FROM CACHE_biZhi2_table
LEFT JOIN (
    SELECT id, title
    FROM ods_land_d_f
    WHERE pt = FROM_UNIXTIME(UNIX_TIMESTAMP(DATE_SUB(CURRENT_DATE, 1)), 'yyyyMMdd')
) landTab
ON CACHE_biZhi2_table.land_id = landTab.id
LEFT JOIN CACHE_future_table
ON 1=1
;
