-- name ads_monthly_ticket_refund_ratio_d_i
-- type Spark SQL
-- author wanghaiyang@12301.cc
-- create time 2024-11-11 15:48:23
-- desc 每月退票率指标表

SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;

CREATE TABLE IF NOT EXISTS ads_monthly_ticket_refund_ratio_d_i(
    sid                         INT     COMMENT '原始供应商ID',
    lid                         INT     COMMENT '景区id',

    channel_class1_id           INT     COMMENT '渠道一级分类id',
    channel_class1_name         STRING  COMMENT '渠道一级分类名称',
    channel_class2_id           INT     COMMENT '渠道二级分类id',
    channel_class2_name         STRING  COMMENT '渠道二级分类名称',

    mo_pay_ticket_num           INT     COMMENT '主单_支付票数',
    mo_cancel_ticket_num        INT     COMMENT '主单_退票数',
    mo_revoke_ticket_num        INT     COMMENT '主单_撤改/撤销票数',
    mo_after_sale_ticket_num    INT     COMMENT '主单_售后票数',

    no_mo_pay_ticket_num        INT     COMMENT '子单_支付票数',
    no_mo_cancel_ticket_num     INT     COMMENT '子单_退票数',
    no_mo_revoke_ticket_num     INT     COMMENT '子单_撤改/撤销票数',
    no_mo_after_sale_ticket_num INT     COMMENT '子单_售后票数',

    year                        INT     COMMENT '年'
)COMMENT '每月退票率指标表' PARTITIONED by(
    month                INT  COMMENT '年月'
)STORED AS ORC;


INSERT OVERWRITE TABLE ads_monthly_ticket_refund_ratio_d_i PARTITION(month)
SELECT 
    sid                                 AS sid,
    lid                                 AS lid,

    channel_class1_id                   AS channel_class1_id,
    MAX(channel_class1_name)            AS channel_class1_name,
    channel_class2_id                   AS channel_class2_id,
    MAX(channel_class2_name)            AS channel_class2_name,

    SUM(mo_pay_ticket_num)              AS mo_pay_ticket_num,
    SUM(mo_cancel_ticket_num)           AS mo_cancel_ticket_num,
    SUM(mo_revoke_ticket_num)           AS mo_revoke_ticket_num,
    SUM(mo_after_sale_ticket_num)       AS mo_after_sale_ticket_num,

    SUM(no_mo_pay_ticket_num)           AS no_mo_pay_ticket_num,
    SUM(no_mo_cancel_ticket_num)        AS no_mo_cancel_ticket_num,
    SUM(no_mo_revoke_ticket_num)        AS no_mo_revoke_ticket_num,
    SUM(no_mo_after_sale_ticket_num)    AS no_mo_after_sale_ticket_num,

    `year`                              AS `year`,
    `month`                             AS `month`
FROM ads_daily_ticket_refund_ratio_d_i
WHERE SUBSTR(`fulldate`, 0, 6) = SUBSTR('${ds}', 0, 6)
    AND lid is not null
GROUP BY 
    sid, 
    lid, 
    channel_class1_id, 
    channel_class2_id, 
    `year`, 
    `month`;


