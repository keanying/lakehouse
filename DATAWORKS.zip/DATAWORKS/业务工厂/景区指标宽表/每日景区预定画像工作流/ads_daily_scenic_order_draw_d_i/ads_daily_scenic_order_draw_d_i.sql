-- name ads_daily_scenic_order_draw_d_i
-- type Spark SQL
-- author wanghaiyang@12301.cc
-- create time 2024-11-05 17:26:50
-- desc 每日预定画像汇总表

SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;

CREATE TABLE IF NOT EXISTS ads_daily_scenic_order_draw_d_i(
    `sid`                           INT     COMMENT '原始供应商id',
    `lid`		                    INT		COMMENT '景区ID',
    `tid`                           INT     COMMENT '票ID',
    `p_type`                        STRING  COMMENT '景区类型：A景区B线路C酒店F套票',
    `pid`                           INT     COMMENT '产品id',
   
    `pay_channel_id`                INT     COMMENT '票支付渠道', 
    `pay_channel_name`              STRING  COMMENT '票支付渠道名称', 

    `channel_class1_id`             INT     COMMENT '一级渠道ID', 
    `channel_class1_name`           STRING  COMMENT '一级渠道名称', 
    `channel_class2_id`             INT     COMMENT '二级渠道ID', 
    `channel_class2_name`           STRING  COMMENT '二级渠道名称', 

    `country`			            STRING	COMMENT '统计国家(境内/境外/未知)',
    `province`			            STRING	COMMENT '统计省',
    `city`			                STRING	COMMENT '统计市',
    `district`			            STRING	COMMENT '统计区/县',
    
    `mo_male_age_0to7`              BIGINT  COMMENT '主单男性且年龄范围0-7',   
    `mo_male_age_8to17`             BIGINT  COMMENT '主单男性且年龄范围8-17', 
    `mo_male_age_18to27`            BIGINT  COMMENT '主单男性且年龄范围18-27', 
    `mo_male_age_28to40`            BIGINT  COMMENT '主单男性且年龄范围28-40', 
    `mo_male_age_41to60`            BIGINT  COMMENT '主单男性且年龄范围41-60', 
    `mo_male_age_61plus`            BIGINT  COMMENT '主单男性且年龄范围>60',  
    `mo_female_age_0to7`            BIGINT  COMMENT '主单女性且年龄范围0-7', 
    `mo_female_age_8to17`           BIGINT  COMMENT '主单女性且年龄范围8-17', 
    `mo_female_age_18to27`          BIGINT  COMMENT '主单女性且年龄范围18-27', 
    `mo_female_age_28to40`          BIGINT  COMMENT '主单女性且年龄范围28-40', 
    `mo_female_age_41to60`          BIGINT  COMMENT '主单女性且年龄范围41-60', 
    `mo_female_age_61plus`          BIGINT  COMMENT '主单女性且年龄范围>60', 
    `mo_unknown`                    BIGINT  COMMENT '主单性别年龄未知',
    `mo_total`                      BIGINT  COMMENT '主单总人数',
    
    `no_mo_male_age_0to7`           BIGINT  COMMENT '子单男性且年龄范围0-7',   
    `no_mo_male_age_8to17`          BIGINT  COMMENT '子单男性且年龄范围8-17', 
    `no_mo_male_age_18to27`         BIGINT  COMMENT '子单男性且年龄范围18-27', 
    `no_mo_male_age_28to40`         BIGINT  COMMENT '子单男性且年龄范围28-40', 
    `no_mo_male_age_41to60`         BIGINT  COMMENT '子单男性且年龄范围41-60', 
    `no_mo_male_age_61plus`         BIGINT  COMMENT '子单男性且年龄范围>60',  
    `no_mo_female_age_0to7`         BIGINT  COMMENT '子单女性且年龄范围0-7', 
    `no_mo_female_age_8to17`        BIGINT  COMMENT '子单女性且年龄范围8-17', 
    `no_mo_female_age_18to27`       BIGINT  COMMENT '子单女性且年龄范围18-27', 
    `no_mo_female_age_28to40`       BIGINT  COMMENT '子单女性且年龄范围28-40', 
    `no_mo_female_age_41to60`       BIGINT  COMMENT '子单女性且年龄范围41-60', 
    `no_mo_female_age_61plus`       BIGINT  COMMENT '子单女性且年龄范围>60', 
    `no_mo_unknown`                 BIGINT  COMMENT '子单性别年龄未知',
    `no_mo_total`                   BIGINT  COMMENT '子单总人数',

  	`year` 				            INT	    COMMENT '年',
  	`month` 			            INT	    COMMENT '月',
  	`week` 				            INT	    COMMENT '年周'
)COMMENT '每日预定画像汇总表'
PARTITIONED BY (`fulldate`  INT   	COMMENT '全日期')
STORED AS ORC;


INSERT OVERWRITE TABLE ads_daily_scenic_order_draw_d_i PARTITION(fulldate)
SELECT	
    sid                                     AS `sid`,
    lid 			                        AS `lid`,
    tid                                     AS `tid`,
    p_type                                  AS `p_type`,
    pid                                     AS `pid`,
    pay_channel_id                          AS `pay_channel_id`, 
    MAX(pay_channel_name)                   AS `pay_channel_name`, 

    channel_class1_id                       AS `channel_class1_id`, 
    MAX(channel_class1_name)                AS `channel_class1_name`,              
    channel_class2_id                       AS `channel_class2_id`, 
    MAX(channel_class2_name)                AS `channel_class2_name`,  

    NVL(country, '未知')                    AS `country`,
    NVL(province, '未知')                   AS `province`,
    NVL(city, '未知')                       AS `city`,
    NVL(district, '未知')                   AS `district`,
    
    SUM(IF(order_type!='套票子票' AND age_range='0-7'   AND sex='男', multiple, 0))                         AS `mo_male_age_0to7`,    
    SUM(IF(order_type!='套票子票' AND age_range='8-17'  AND sex='男', multiple, 0))                         AS `mo_male_age_8to17`,   
    SUM(IF(order_type!='套票子票' AND age_range='18-27' AND sex='男', multiple, 0))                         AS `mo_male_age_18to27`,  
    SUM(IF(order_type!='套票子票' AND age_range='28-40' AND sex='男', multiple, 0))                         AS `mo_male_age_28to40`,  
    SUM(IF(order_type!='套票子票' AND age_range='41-60' AND sex='男', multiple, 0))                         AS `mo_male_age_41to60`,  
    SUM(IF(order_type!='套票子票' AND age_range='61+'   AND sex='男', multiple, 0))                         AS `mo_male_age_61plus`,  
    SUM(IF(order_type!='套票子票' AND age_range='0-7'   AND sex='女', multiple, 0))                         AS `mo_female_age_0to7`,  
    SUM(IF(order_type!='套票子票' AND age_range='8-17'  AND sex='女', multiple, 0))                         AS `mo_female_age_8to17`, 
    SUM(IF(order_type!='套票子票' AND age_range='18-27' AND sex='女', multiple, 0))                         AS `mo_female_age_18to27`,
    SUM(IF(order_type!='套票子票' AND age_range='28-40' AND sex='女', multiple, 0))                         AS `mo_female_age_28to40`,
    SUM(IF(order_type!='套票子票' AND age_range='41-60' AND sex='女', multiple, 0))                         AS `mo_female_age_41to60`,
    SUM(IF(order_type!='套票子票' AND age_range='61+'   AND sex='女', multiple, 0))                         AS `mo_female_age_61plus`,
    SUM(IF(order_type!='套票子票' AND (age_range='-1' OR age_range IS NULL OR age_range=''), multiple, 0))  AS `mo_unknown`,          
    SUM(IF(order_type!='套票子票', multiple, 0))                                                            AS `mo_total`, 

    SUM(IF(order_type='套票子票' AND age_range='0-7'   AND sex='男', multiple, 0))                          AS `no_mo_male_age_0to7`,    
    SUM(IF(order_type='套票子票' AND age_range='8-17'  AND sex='男', multiple, 0))                          AS `no_mo_male_age_8to17`,   
    SUM(IF(order_type='套票子票' AND age_range='18-27' AND sex='男', multiple, 0))                          AS `no_mo_male_age_18to27`,  
    SUM(IF(order_type='套票子票' AND age_range='28-40' AND sex='男', multiple, 0))                          AS `no_mo_male_age_28to40`,  
    SUM(IF(order_type='套票子票' AND age_range='41-60' AND sex='男', multiple, 0))                          AS `no_mo_male_age_41to60`,  
    SUM(IF(order_type='套票子票' AND age_range='61+'   AND sex='男', multiple, 0))                          AS `no_mo_male_age_61plus`,  
    SUM(IF(order_type='套票子票' AND age_range='0-7'   AND sex='女', multiple, 0))                          AS `no_mo_female_age_0to7`,  
    SUM(IF(order_type='套票子票' AND age_range='8-17'  AND sex='女', multiple, 0))                          AS `no_mo_female_age_8to17`, 
    SUM(IF(order_type='套票子票' AND age_range='18-27' AND sex='女', multiple, 0))                          AS `no_mo_female_age_18to27`,
    SUM(IF(order_type='套票子票' AND age_range='28-40' AND sex='女', multiple, 0))                          AS `no_mo_female_age_28to40`,
    SUM(IF(order_type='套票子票' AND age_range='41-60' AND sex='女', multiple, 0))                          AS `no_mo_female_age_41to60`,
    SUM(IF(order_type='套票子票' AND age_range='61+'   AND sex='女', multiple, 0))                          AS `no_mo_female_age_61plus`,
    SUM(IF(order_type='套票子票' AND (age_range='-1' OR age_range IS NULL OR age_range=''), multiple, 0))   AS `no_mo_unknown`,          
    SUM(IF(order_type='套票子票', multiple, 0))                                                             AS `no_mo_total`, 

    YEAR(`date`)                                                                                            AS `year`,
    YEAR(`date`) * 100 + MONTH(`date`)                                                                      AS `month`,
    INT(`isoweek`)                                                                                          AS `week`,
    INT(`orderdate`)                                                                                        AS `fulldate`																			 
FROM 
(
    SELECT 
        lid,
        sid,    
        NVL(`dict`.pay_channel_mapping_id, -1)                                                              AS `pay_channel_id`,
        NVL(`dict`.pay_channel_mapping_name, '其他')                                                        AS `pay_channel_name`, 
        channel_class1_id,
        channel_class1_name,
        channel_class2_id,
        channel_class2_name,  
        p_type,
        pid,
        tid,
        sex,
        -- 年龄范围
        CASE
            WHEN age BETWEEN 0 AND 7
            THEN '0-7'
            WHEN age BETWEEN 8 AND 17
            THEN '8-17'
            WHEN age BETWEEN 18 AND 27
            THEN '18-27'
            WHEN age BETWEEN 28 AND 40
            THEN '28-40'
            WHEN age BETWEEN 41 AND 60
            THEN '41-60'
			WHEN age BETWEEN 61 AND 122 
            THEN '61+'
            ELSE '-1'
        END 	AS age_range,
        orderdate,
        dim_isoweek.date,
        dim_isoweek.isoweek,
        country,
        province,
        city,
        district,
        multiple,
        order_type
    FROM 
    (
        SELECT 
            apply_did               AS sid, 
            orderid,
            sex, 
            age, 
            orderdate, 
            country_name            AS country,
            province_name           AS province,
            city_name               AS city,
            district_name           AS district,
            lid, 
            pid, 
            tid, 
            product_type            AS p_type, 
            channel_class1_id,
            channel_class1_name,
            channel_class2_id,
            channel_class2_name,
            multiple,
            order_type,
            NVL(`paymode`, -1)      AS pay_channel_id
        FROM dwd_tourist_info_d_i 
        WHERE orderdate = "${ds}"
            AND tid != -1
    ) AS order_tourist
    LEFT JOIN dim_pay_channel_o_f `dict`
    ON `order_tourist`.pay_channel_id = `dict`.pay_channel_id
    LEFT JOIN dim_date_isoweek_o_f AS dim_isoweek 
    ON order_tourist.orderdate = dim_isoweek.`fulldate`
)
GROUP BY
    lid,
    sid,
    p_type,
    pid,
    tid,
    channel_class1_id,
    channel_class2_id,
    pay_channel_id,
    country,
    province,
    city,
    district,
	orderdate,
    date,				 
    isoweek;