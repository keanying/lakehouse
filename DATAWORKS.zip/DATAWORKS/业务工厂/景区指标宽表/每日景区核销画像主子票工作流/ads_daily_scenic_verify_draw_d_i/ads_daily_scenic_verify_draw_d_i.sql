-- name ads_daily_scenic_verify_draw_d_i
-- type Spark SQL
-- author wanghaiyang@12301.cc
-- create time 2025-01-09 17:30:58
-- desc 每日核销画像指标表

SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;


CREATE TABLE IF NOT EXISTS ads_daily_scenic_verify_draw_d_i(
    sid                 INT     COMMENT '原始供应商id',
    lid                 INT     COMMENT '景区ID',
    tid                 INT     COMMENT '票ID',
    p_type              STRING  COMMENT '景区类型：A景区B线路C酒店F套票',
    pid                 INT     COMMENT '产品id',
    sub_sid             INT     COMMENT '子票原始供应商id',
    sub_lid             INT     COMMENT '子票景区ID',
    sub_tid             INT     COMMENT '子票票ID',
    sub_p_type          STRING  COMMENT '子票景区类型：A景区B线路C酒店F套票',
    sub_pid             INT     COMMENT '子票产品id',
    pack_type           INT     COMMENT '套票规则，0单票 1是套票主票 2是套票子票',
    pay_channel_id      INT     COMMENT '票支付渠道',
    pay_channel_name    STRING  COMMENT '票支付渠道名称',
    channel_class1_id   INT     COMMENT '一级渠道ID',
    channel_class1_name STRING  COMMENT '一级渠道名称',
    channel_class2_id   INT     COMMENT '二级渠道ID',
    channel_class2_name STRING  COMMENT '二级渠道名称',
    country             STRING  COMMENT '统计国家(境内/境外/未知)',
    province            STRING  COMMENT '统计省',
    city                STRING  COMMENT '统计市',
    district            STRING  COMMENT '统计区/县',
    sex                 INT     COMMENT '性别, 0女性;1男性;-1未知',
    age                 INT     COMMENT '年龄',
  	verify_ticket 		BIGINT 	COMMENT '核销票数(首次入园)',
  	verify_amount 		BIGINT 	COMMENT '核销金额(首次入园)',
	verify_ticket_all 	BIGINT 	COMMENT '核销票数(含重复入园)',
  	verify_amount_all 	BIGINT 	COMMENT '核销金额(含重复入园)',

  	year 	            INT	 	COMMENT '年',
  	month               INT	 	COMMENT '年月',
  	week 	            INT	 	COMMENT '年周'
)COMMENT '每日核销画像指标表'
PARTITIONED BY (`fulldate`      INT   	COMMENT '全日期')
STORED AS ORC;


INSERT OVERWRITE TABLE ads_daily_scenic_verify_draw_d_i PARTITION(fulldate)
SELECT 
    INT(verify.sid)                                                                 AS `sid`,
    INT(verify.lid)                                                                 AS `lid`,    
    INT(verify.tid)                                                                 AS `tid`,
    verify.p_type                                                                   AS `p_type`,
    INT(verify.pid)                                                                 AS `pid`,

    INT(verify.sub_sid)                                                             AS `sub_sid`,
    INT(verify.sub_lid)                                                             AS `sub_lid`,    
    INT(verify.sub_tid)                                                             AS `sub_tid`,
    verify.sub_p_type                                                               AS `sub_p_type`,
    INT(verify.sub_pid)                                                             AS `sub_pid`,

    verify.pack_type                                                                AS `pack_type`,
    NVL(`dict`.pay_channel_mapping_id, -1)                                          AS `pay_channel_id`,
    MAX(NVL(`dict`.pay_channel_mapping_name, '其他'))                               AS `pay_channel_name`, 
    verify.channel_class1_id                                                        AS `channel_class1_id`,
    MAX(verify.channel_class1_name)                                                 AS `channel_class1_name`,
    verify.channel_class2_id                                                        AS `channel_class2_id`,
    MAX(verify.channel_class2_name)                                                 AS `channel_class2_name`,

    verify.country                                                                  AS `country`, 
    verify.province                                                                 AS `province`, 
    verify.city                                                                     AS `city`, 
    verify.district                                                                 AS `district`, 
  
    sex                                                                             AS `sex`,
	INT(age)                                                                        AS `age`,
    SUM(IF(is_first_used = 1, verify_num, 0))  										AS `verify_ticket`, 
    SUM(IF(is_first_used = 1, verify_money, 0))                                     AS `verify_amount`, 

	SUM(verify_num)  																AS `verify_ticket_all`,
    SUM(verify_money)                           							        AS `verify_amount_all`, 

    YEAR(`date`)                                                                    AS `year`,
    YEAR(`date`) * 100 + MONTH(`date`)                                              AS `month`,
    INT(`isoweek`)                                                                  AS `week`,
    INT(insertdate)                                                                 AS `fulldate`
FROM 
(
    SELECT 
        apply_did                                         AS    sub_sid,    
        lid                                               AS    sub_lid,
        tid                                               AS    sub_tid,
        product_type                                      AS    sub_p_type,
        pid                                               AS    sub_pid,
        main_sid                                          AS    sid,
        main_lid                                          AS    lid,  
        main_tid                                          AS    tid,    
        main_product_type                                 AS    p_type,
        main_pid                                          AS    pid,
        insertdate, 
        orderid, 
        verify_num,
        verify_money,
        is_first_used,
        CASE WHEN order_type='单票' THEN 0 WHEN order_type='套票主票' THEN 1 WHEN order_type = '套票子票' THEN 2 END AS pack_type,
        CASE WHEN sex = '男' THEN 1 WHEN sex ='女' THEN 0 ELSE -1 END AS sex, 
        age, 
        CASE WHEN country_name = '境内' THEN '中国' ELSE country_name END AS country,
        province_name           AS `province`,
        city_name               AS `city`,
        district_name           AS `district`,
        paymode                 AS `paymode`,
        channel_class1_id       AS `channel_class1_id`,
        channel_class1_name     AS `channel_class1_name`,
        channel_class2_id       AS `channel_class2_id`,
        channel_class2_name     AS `channel_class2_name`
    FROM dwd_tourist_verify_d_i
    WHERE insertdate = ${ds}
        AND tid != -1 
        AND main_tid != 0
) verify
LEFT JOIN dim_date_isoweek_o_f dim_isoweek  
ON verify.insertdate = dim_isoweek.`fulldate`
LEFT JOIN dim_pay_channel_o_f `dict`
ON verify.paymode = `dict`.pay_channel_id
GROUP BY  
    verify.sid,
    verify.lid,
    verify.tid,
    verify.pid,
    verify.p_type,
    verify.sub_sid,
    verify.sub_lid,
    verify.sub_tid,
    verify.sub_pid,
    verify.sub_p_type,
    verify.insertdate,
    verify.country,
    verify.province,
    verify.city,
    verify.district,
	verify.pack_type,
    NVL(`dict`.pay_channel_mapping_id, -1),
    channel_class1_id,
    channel_class2_id,
	verify.sex,
	verify.age,
    dim_isoweek.`date`,
    dim_isoweek.`isoweek`;         