-- name ads_daily_scenic_ticket_pre_booking_d_i
-- type Spark SQL
-- author wanghaiyang@12301.cc
-- create time 2024-08-26 18:35:07
-- desc 景区每日门票提前预定统计表


SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;

CREATE TABLE IF NOT EXISTS ads_daily_scenic_ticket_pre_booking_d_i_new(
    `sid`                           INT     COMMENT '原始供应商id',
    `lid`                           INT     COMMENT '景区ID',
    `tid`                           INT     COMMENT '票ID',
    `p_type`                        STRING  COMMENT '景区类型：A景区B线路C酒店F套票',
    `pid`                           INT     COMMENT '产品id',

    `sub_sid`                       INT     COMMENT '子票原始供应商id',
    `sub_lid`                       INT     COMMENT '子票景区ID',
    `sub_tid`                       INT     COMMENT '子票票ID',
    `sub_p_type`                    STRING  COMMENT '子票景区类型：A景区B线路C酒店F套票',
    `sub_pid`                       INT     COMMENT '子票产品id',

    `pack_type`                     INT     COMMENT '套票规则，0单票 1是套票主票 2是套票子票',

    `year`                          INT     COMMENT '年',
    `month`                         INT     COMMENT '月',
    `week`                          INT     COMMENT '年周',
    `order_num`                     BIGINT  COMMENT '预定订单数',
    `order_ticket`                  BIGINT  COMMENT '预定票数',
    `order_amount`                  BIGINT  COMMENT '预定订单金额',
    `order_num_0`                   BIGINT  COMMENT '当天预定订单数', 
    `order_num_1`                   BIGINT  COMMENT '昨天预定订单数', 
    `order_num_2to3`                BIGINT  COMMENT '提前预定1-3天订单数', 
    `order_num_4to7`                BIGINT  COMMENT '提前预定4-7天订单数', 
    `order_num_7plus`               BIGINT  COMMENT '提前预定7天以上订单数', 
    `order_ticket_0`                BIGINT  COMMENT '当天预定票数', 
    `order_ticket_1`                BIGINT  COMMENT '昨天预定票数', 
    `order_ticket_2to3`             BIGINT  COMMENT '提前预定2-3天票数', 
    `order_ticket_4to7`             BIGINT  COMMENT '提前预定4-7天票数', 
    `order_ticket_7plus`            BIGINT  COMMENT '提前预定7天以上票数', 
    `order_amount_0`                BIGINT  COMMENT '当天预定订单金额', 
    `order_amount_1`                BIGINT  COMMENT '昨天预定订单金额', 
    `order_amount_2to3`             BIGINT  COMMENT '提前预定1-3天订单金额', 
    `order_amount_4to7`             BIGINT  COMMENT '提前预定4-7天订单金额', 
    `order_amount_7plus`            BIGINT  COMMENT '提前预定7天以上订单金额'
)COMMENT '景区每日门票提前预定统计表'
PARTITIONED BY (`fulldate`  INT     COMMENT '游玩日期')
STORED AS ORC;

INSERT OVERWRITE TABLE ads_daily_scenic_ticket_pre_booking_d_i_new PARTITION(fulldate)
SELECT 
    INT(sid)                                                      AS `sid`,
    INT(lid)                                                      AS `lid`,
    INT(tid)                                                      AS `tid`,
    p_type                                                        AS `p_type`,
    INT(pid)                                                      AS `pid`,
   
    INT(sub_sid)                                                  AS `sub_sid`,
    INT(sub_lid)                                                  AS `sub_lid`,
    INT(sub_tid)                                                  AS `sub_tid`,
    sub_p_type                                                    AS `sub_p_type`,
    INT(sub_pid)                                                  AS `sub_pid`,
    pack_type                                                     AS `pack_type`,
   
    YEAR(playdate)                                                AS `year`,
    YEAR(playdate) * 100 + MONTH(playdate)                        AS `month`,
    INT(dim_isoweek.isoweek)                                      AS `week`,
    SUM(order_num)                                                AS `order_num`,
    SUM(order_ticket)                                             AS `order_ticket`,
    SUM(order_amount)                                             AS `order_amount`,
    SUM(IF(diff_days=0, order_num, 0))                            AS `order_num_0`,
    SUM(IF(diff_days=1, order_num, 0))                            AS `order_num_1`, 
    SUM(IF(diff_days>=2 AND diff_days<=3, order_num, 0))          AS `order_num_2to3`, 
    SUM(IF(diff_days>=4 AND diff_days<=7, order_num, 0))          AS `order_num_4to7`,
    SUM(IF(diff_days>7, order_num, 0))                            AS `order_num_7plus`,
    SUM(IF(diff_days=0, order_ticket, 0))                         AS `order_ticket_0`,
    SUM(IF(diff_days=1, order_ticket, 0))                         AS `order_ticket_1`, 
    SUM(IF(diff_days>=2 AND diff_days<=3, order_ticket, 0))       AS `order_ticket_2to3`, 
    SUM(IF(diff_days>=4 AND diff_days<=7, order_ticket, 0))       AS `order_ticket_4to7`,
    SUM(IF(diff_days>7, order_ticket, 0))                         AS `order_ticket_7plus`,
    SUM(IF(diff_days=0, order_amount, 0))                         AS `order_amount_0`,
    SUM(IF(diff_days=1, order_amount, 0))                         AS `order_amount_1`, 
    SUM(IF(diff_days>=2 AND diff_days<=3, order_amount, 0))       AS `order_amount_2to3`, 
    SUM(IF(diff_days>=4 AND diff_days<=7, order_amount, 0))       AS `order_amount_4to7`,
    SUM(IF(diff_days>7, order_amount, 0))                         AS `order_amount_7plus`,
    INT(dim_isoweek.fulldate)
FROM(
    SELECT 
        CASE WHEN order_type='单票' THEN 0 WHEN order_type='套票主票' THEN 1 WHEN order_type = '套票子票' THEN 2 END AS pack_type,
        main_sid                                    AS  sid, 
        main_lid                                    AS  lid,
        main_tid                                    AS  tid,
        main_product_type                           AS  p_type,
        main_pid                                    AS  pid,
        apply_did                                   AS  sub_sid, 
        lid                                         AS  sub_lid,
        tid                                         AS  sub_tid,
        product_type                                AS  sub_p_type,
        pid                                         AS  sub_pid,
        TO_DATE(playdate)                           AS  playdate, 
        DATEDIFF(TO_DATE(playdate), to_date(from_unixtime(unix_timestamp(CAST(orderdate AS STRING), 'yyyyMMdd'))))  
                                                    AS  diff_days,
        1                                           AS  order_num,
        pay_num                                     AS  order_ticket,
        pay_num*sale_price                          AS  order_amount
    FROM dim_order_d_i
    -- 属于已支付订单
    WHERE order_pay_status != 2 
    -- 订单状态不属于取消/撤销/删除状态
    AND order_status not in(3, 6, 9)
    -- 近80天订单
    AND orderdate >= regexp_replace(date_sub(to_date(from_unixtime(unix_timestamp('${ds}', 'yyyyMMdd'))), 80), '-', '')
    -- 只修复游玩日期等于昨日的分区
    AND TO_DATE(playdate) >= TO_DATE(FROM_UNIXTIME(UNIX_TIMESTAMP('${ds}', 'yyyyMMdd')))
    AND TO_DATE(playdate) <= DATE_ADD(TO_DATE(FROM_UNIXTIME(UNIX_TIMESTAMP('${ds}', 'yyyyMMdd'))), 10)
) AS orderTab
LEFT JOIN dim_date_isoweek_o_f AS dim_isoweek 
ON `orderTab`.playdate = dim_isoweek.`date`
GROUP BY 
    sid,
    lid,
    pid,
    p_type,
    tid,
    sub_sid,
    sub_lid,
    sub_pid,
    sub_p_type,
    sub_tid,
    playdate,
    pack_type,
    dim_isoweek.isoweek,
    dim_isoweek.fulldate;