--Serverless Spark SQL
--********************************************************************--
--author: 王海阳
--create time: 2026-05-10 18:10:14
--Serverless Spark SQL任务只能运行在独享资源组上
--********************************************************************--

SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;


CREATE TABLE IF NOT EXISTS ads_daily_scenic_sub_order_draw_d_i (
  sid                   INT     COMMENT '原始供应商id',
  lid                   INT     COMMENT '景区ID',
  tid                   INT     COMMENT '票ID',
  sub_sid               INT     COMMENT '子票原始供应商id',
  sub_lid               INT     COMMENT '子票景区ID',
  sub_tid               INT     COMMENT '子票票ID',
  p_type                STRING  COMMENT '景区类型：A景区B线路C酒店F套票',
  pid                   INT     COMMENT '产品id',
  sub_p_type            STRING  COMMENT '子票景区类型：A景区B线路C酒店F套票',
  sub_pid               INT     COMMENT '子票产品id',
  pack_type             INT     COMMENT '套票规则，0单票 1是套票主票 2是套票子票',
  pay_channel_id        INT     COMMENT '票支付渠道',
  pay_channel_name      STRING  COMMENT '票支付渠道名称',
  channel_class1_id     INT     COMMENT '一级渠道ID',
  channel_class1_name   STRING  COMMENT '一级渠道名称',
  channel_class2_id     INT     COMMENT '二级渠道ID',
  channel_class2_name   STRING  COMMENT '二级渠道名称',
  country               STRING  COMMENT '统计国家(境内/境外/未知)',
  province              STRING  COMMENT '统计省',
  city                  STRING  COMMENT '统计市',
  district              STRING  COMMENT '统计区/县',
  sex                   INT     COMMENT '性别, 0女性;1男性;-1未知',
  age                   INT     COMMENT '年龄',
  pay_ticket            BIGINT  COMMENT '支付票数',
  pay_amount            BIGINT  COMMENT '支付金额',
  year                  INT     COMMENT '年',
  month                 INT     COMMENT '月',
  week                  INT     COMMENT '年周',
  fulldate              INT     COMMENT '全日期')
USING orc
PARTITIONED BY (fulldate)
COMMENT '每日预定画像汇总表';



INSERT OVERWRITE TABLE ads_daily_scenic_sub_order_draw_d_i PARTITION(fulldate)
 SELECT	
     INT(sid)                                AS `sid`,
     INT(lid) 			                     AS `lid`,
     INT(tid)                                AS `tid`,
     INT(sub_sid) 			                 AS `sub_sid`,
     INT(sub_lid) 			                 AS `sub_lid`,
     INT(sub_tid)                            AS `sub_tid`,
     p_type                                  AS `p_type`,
     INT(pid)                                AS `pid`,
    
     sub_p_type                              AS `sub_p_type`,
     INT(sub_pid)                            AS `sub_pid`,
     pack_type                               AS `pack_type`,
     pay_channel_id                          AS `pay_channel_id`, 
     MAX(pay_channel_name)                   AS `pay_channel_name`, 
 
     channel_class1_id                       AS `channel_class1_id`, 
     MAX(channel_class1_name)                AS `channel_class1_name`,              
     channel_class2_id                       AS `channel_class2_id`, 
     MAX(channel_class2_name)                AS `channel_class2_name`,  
 
     NVL(country, '未知')                    AS `country`,
     NVL(province, '未知')                   AS `province`,
     NVL(city, '未知')                       AS `city`,
     NVL(district, '未知')                   AS `district`,
     
     sex, 
 	 INT(age),
 
     SUM(pay_ticket)                         AS `pay_ticket`, 
     SUM(pay_amount)                         AS `pay_amount`, 
 
     YEAR(`date`)                            AS `year`,
     YEAR(`date`) * 100 + MONTH(`date`)      AS `month`,
     INT(`isoweek`)                          AS `week`,
     INT(`orderdate`)                        AS `fulldate`																			 
 FROM 
 (
     SELECT 
         sid,
         lid,  
         tid,    
         p_type,
         pid,
         sub_sid,    
         sub_lid,
         sub_tid,
         sub_p_type,
         sub_pid,
         pack_type,
         sex, 
         age,
         NVL(`dict`.pay_channel_mapping_id, -1)                         AS    `pay_channel_id`,
         NVL(`dict`.pay_channel_mapping_name, '其他')                   AS    `pay_channel_name`, 
         channel_class1_id,
         channel_class1_name,
         channel_class2_id,
         channel_class2_name,  
         orderdate,
         dim_isoweek.date,
         dim_isoweek.isoweek,
         country,
         province,
         city,
         district,
         pay_ticket,
         pay_amount,
         pack_type
     FROM 
     (
         SELECT 
            apply_did               AS    sub_sid,    
            lid                     AS    sub_lid,
            tid                     AS    sub_tid,
            product_type            AS    sub_p_type,
            pid                     AS    sub_pid,
            main_sid                AS    sid,
            main_lid                AS    lid,  
            main_tid                AS    tid,    
            main_product_type       AS    p_type,
            main_pid                AS    pid,
            orderid,
            CASE WHEN order_type='单票' THEN 0 WHEN order_type='套票主票' THEN 1 WHEN order_type = '套票子票' THEN 2 END AS pack_type,
            CASE WHEN sex = '男' THEN 1 WHEN sex ='女' THEN 0 ELSE -1 END  AS sex, 
            age, 
            orderdate, 
            country_name            AS country,
            province_name           AS province,
            city_name               AS city,
            district_name           AS district,
            channel_class1_id,
            channel_class1_name,
            channel_class2_id,
            channel_class2_name,
            multiple               AS pay_ticket,
            multiple*sale_price    AS pay_amount,
            NVL(`paymode`, -1)      AS pay_channel_id
         FROM dwd_tourist_info_d_i 
         WHERE orderdate = ${ds}
             AND tid != -1
             AND main_tid !=0
             AND main_tid IS NOT NULL
     ) AS order_tourist
     LEFT JOIN dim_pay_channel_o_f `dict`
     ON `order_tourist`.pay_channel_id = `dict`.pay_channel_id
     LEFT JOIN dim_date_isoweek_o_f AS dim_isoweek 
     ON order_tourist.orderdate = dim_isoweek.`fulldate`
 )
 GROUP BY
     sid,
     lid,
     tid,
     p_type,
     pid,
     pack_type,
     sub_sid,
     sub_lid,
     sub_tid,
     sub_p_type,
     sub_pid,
     channel_class1_id,
     channel_class2_id,
     pay_channel_id,
     country,
     province,
     city,
     district,
 	 orderdate,
     date,
     isoweek,
 	 sex,
 	 age;
