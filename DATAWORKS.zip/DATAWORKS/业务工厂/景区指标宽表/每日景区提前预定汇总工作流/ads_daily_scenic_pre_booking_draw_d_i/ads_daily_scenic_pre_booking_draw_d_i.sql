-- name ads_daily_scenic_pre_booking_draw_d_i
-- type Spark SQL
-- author wanghaiyang@12301.cc
-- create time 2025-03-10 14:31:05
-- desc 景区每日提前预定画像统计表

SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;

CREATE TABLE IF NOT EXISTS `ads_daily_scenic_pre_booking_draw_d_i`(
    `year`              INT     COMMENT'年',
    `month`             INT     COMMENT'月',
    `week`              INT     COMMENT'年周',
    `sid`               INT     COMMENT'原始供应商id',
    `land_id`           INT     COMMENT'景区ID',
    `p_type`            STRING  COMMENT'景区类型：A景区B线路C酒店F套票',
    `country`           STRING  COMMENT'统计国家(境内/境外/未知)',
    `province`          STRING  COMMENT'统计省',
    `city`              STRING  COMMENT'统计市',
    `district`          STRING  COMMENT'统计区县',
    `male_age_0to7`     BIGINT  COMMENT'男性且年龄范围0-7',
    `male_age_8to17`    BIGINT  COMMENT'男性且年龄范围8-17',
    `male_age_18to27`   BIGINT  COMMENT'男性且年龄范围18-27',
    `male_age_28to40`   BIGINT  COMMENT'男性且年龄范围28-40',
    `male_age_41to60`   BIGINT  COMMENT'男性且年龄范围41-60',
    `male_age_61plus`   BIGINT  COMMENT'男性且年龄范围>60',
    `female_age_0to7`   BIGINT  COMMENT'女性且年龄范围0-7',
    `female_age_8to17`  BIGINT  COMMENT'女性且年龄范围8-17',
    `female_age_18to27` BIGINT  COMMENT'女性且年龄范围18-27',
    `female_age_28to40` BIGINT  COMMENT'女性且年龄范围28-40',
    `female_age_41to60` BIGINT  COMMENT'女性且年龄范围41-60',
    `female_age_61plus` BIGINT  COMMENT'女性且年龄范围>60',
    `unknown`           BIGINT  COMMENT'性别年龄未知',
    `total`             BIGINT  COMMENT'总人数'
 )comment'景区每日提前预定画像统计表'partitioned by(
    fulldate INT COMMENT'全日期'
 )STORED AS ORC;


INSERT OVERWRITE TABLE ads_daily_scenic_pre_booking_draw_d_i PARTITION(fulldate)
SELECT	
    year                                                            AS `year`,
    month                                                           AS `month`,
    week                                                            AS `week`,
    sid                                                             AS `sid`,
    land_id                                                         AS `land_id`,
    p_type                                                          AS `p_type`,
    country                                                         AS `country`,
    province                                                        AS `province`,
    city                                                            AS `city`,
    district                                                        AS `district`,
    SUM(male_age_0to7)                                              AS `male_age_0to7`,    
    SUM(male_age_8to17)                                             AS `male_age_8to17`,   
    SUM(male_age_18to27)                                            AS `male_age_18to27`,  
    SUM(male_age_28to40)                                            AS `male_age_28to40`,  
    SUM(male_age_41to60)                                            AS `male_age_41to60`,  
    SUM(male_age_61plus)                                            AS `male_age_61plus`,  
    SUM(female_age_0to7)                                            AS `female_age_0to7`,  
    SUM(female_age_8to17)                                           AS `female_age_8to17`, 
    SUM(female_age_18to27)                                          AS `female_age_18to27`,
    SUM(female_age_28to40)                                          AS `female_age_28to40`,
    SUM(female_age_41to60)                                          AS `female_age_41to60`,
    SUM(female_age_61plus)                                          AS `female_age_61plus`,
    SUM(`unknown`)                                                  AS `unknown`,          
    SUM(total)                                                      AS `total`,
    fulldate                                                        AS `fulldate`
FROM ads_daily_scenic_ticket_pre_booking_draw_d_i
WHERE fulldate = ${ds}
GROUP BY 
    year,
    month,
    week,
    sid,
    land_id,
    p_type,
    country,
    province,
    city,
    district,
    fulldate;
