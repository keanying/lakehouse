-- name ads_monthly_scenic_pre_booking_d_i
-- type Spark SQL
-- author wanghaiyang@12301.cc
-- create time 2024-08-26 18:35:07
-- desc 景区每月提前预定统计表

SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;

CREATE TABLE IF NOT EXISTS ads_monthly_scenic_pre_booking_d_i(
    `sid`                           INT     COMMENT '原始供应商id',
    `land_id`                       INT     COMMENT '景区ID',
    `p_type`                        STRING  COMMENT '景区类型：A景区B线路C酒店F套票',
    `year`                          INT     COMMENT '年',
    `mo_order_num`                  BIGINT  COMMENT '主单预定订单数',
    `mo_order_ticket`               BIGINT  COMMENT '主单预定票数',
    `mo_order_amount`               BIGINT  COMMENT '主单预定订单金额',
    `mo_order_num_0`                BIGINT  COMMENT '主单当天预定订单数', 
    `mo_order_num_1`                BIGINT  COMMENT '主单昨天预定订单数', 
    `mo_order_num_2to3`             BIGINT  COMMENT '主单提前预定1-3天订单数', 
    `mo_order_num_4to7`             BIGINT  COMMENT '主单提前预定4-7天订单数', 
    `mo_order_num_7plus`            BIGINT  COMMENT '主单提前预定7天以上订单数', 
    `mo_order_ticket_0`             BIGINT  COMMENT '主单当天预定票数', 
    `mo_order_ticket_1`             BIGINT  COMMENT '主单昨天预定票数', 
    `mo_order_ticket_2to3`          BIGINT  COMMENT '主单提前预定2-3天票数', 
    `mo_order_ticket_4to7`          BIGINT  COMMENT '主单提前预定4-7天票数', 
    `mo_order_ticket_7plus`         BIGINT  COMMENT '主单提前预定7天以上票数', 
    `mo_order_amount_0`             BIGINT  COMMENT '主单当天预定订单金额', 
    `mo_order_amount_1`             BIGINT  COMMENT '主单昨天预定订单金额', 
    `mo_order_amount_2to3`          BIGINT  COMMENT '主单提前预定1-3天订单金额', 
    `mo_order_amount_4to7`          BIGINT  COMMENT '主单提前预定4-7天订单金额', 
    `mo_order_amount_7plus`         BIGINT  COMMENT '主单提前预定7天以上订单金额',
    `no_mo_order_num`               BIGINT  COMMENT '子单预定订单数',
    `no_mo_order_ticket`            BIGINT  COMMENT '子单预定票数',
    `no_mo_order_amount`            BIGINT  COMMENT '子单预定订单金额',
    `no_mo_order_num_0`             BIGINT  COMMENT '子单当天预定订单数', 
    `no_mo_order_num_1`             BIGINT  COMMENT '子单昨天预定订单数', 
    `no_mo_order_num_2to3`          BIGINT  COMMENT '子单提前预定1-3天订单数', 
    `no_mo_order_num_4to7`          BIGINT  COMMENT '子单提前预定4-7天订单数', 
    `no_mo_order_num_7plus`         BIGINT  COMMENT '子单提前预定7天以上订单数', 
    `no_mo_order_ticket_0`          BIGINT  COMMENT '子单当天预定票数', 
    `no_mo_order_ticket_1`          BIGINT  COMMENT '子单昨天预定票数', 
    `no_mo_order_ticket_2to3`       BIGINT  COMMENT '子单提前预定2-3天票数', 
    `no_mo_order_ticket_4to7`       BIGINT  COMMENT '子单提前预定4-7天票数', 
    `no_mo_order_ticket_7plus`      BIGINT  COMMENT '子单提前预定7天以上票数', 
    `no_mo_order_amount_0`          BIGINT  COMMENT '子单当天预定订单金额', 
    `no_mo_order_amount_1`          BIGINT  COMMENT '子单昨天预定订单金额', 
    `no_mo_order_amount_2to3`       BIGINT  COMMENT '子单提前预定1-3天订单金额', 
    `no_mo_order_amount_4to7`       BIGINT  COMMENT '子单提前预定4-7天订单金额', 
    `no_mo_order_amount_7plus`      BIGINT  COMMENT '子单提前预定7天以上订单金额'
)COMMENT '景区每月提前预定统计表'
PARTITIONED BY (`month`  INT     COMMENT '游玩年月')
STORED AS ORC;

INSERT OVERWRITE TABLE ads_monthly_scenic_pre_booking_d_i PARTITION(month)
SELECT 
    sid                                                             AS `sid`,
    land_id                                                         AS `land_id`,
    p_type                                                          AS `p_type`,
    year                                                            AS `year`,
    SUM(mo_order_num)                                               AS `mo_order_num`,
    SUM(mo_order_ticket)                                            AS `mo_order_ticket`,
    SUM(mo_order_amount)                                            AS `mo_order_amount`,
    SUM(mo_order_num_0)                                             AS `mo_order_num_0`,
    SUM(mo_order_num_1)                                             AS `mo_order_num_1`, 
    SUM(mo_order_num_2to3)                                          AS `mo_order_num_2to3`, 
    SUM(mo_order_num_4to7)                                          AS `mo_order_num_4to7`,
    SUM(mo_order_num_7plus)                                         AS `mo_order_num_7plus`,
    SUM(mo_order_ticket_0)                                          AS `mo_order_ticket_0`,
    SUM(mo_order_ticket_1)                                          AS `mo_order_ticket_1`, 
    SUM(mo_order_ticket_2to3)                                       AS `mo_order_ticket_2to3`, 
    SUM(mo_order_ticket_4to7)                                       AS `mo_order_ticket_4to7`,
    SUM(mo_order_ticket_7plus)                                      AS `mo_order_ticket_7plus`,
    SUM(mo_order_amount_0)                                          AS `mo_order_amount_0`,
    SUM(mo_order_amount_1)                                          AS `mo_order_amount_1`, 
    SUM(mo_order_amount_2to3)                                       AS `mo_order_amount_2to3`, 
    SUM(mo_order_amount_4to7)                                       AS `mo_order_amount_4to7`,
    SUM(mo_order_amount_7plus)                                      AS `mo_order_amount_7plus`,
    SUM(no_mo_order_num)                                            AS `no_mo_order_num`,
    SUM(no_mo_order_ticket)                                         AS `no_mo_order_ticket`,
    SUM(no_mo_order_amount)                                         AS `no_mo_order_amount`,
    SUM(no_mo_order_num_0)                                          AS `no_mo_order_num_0`,
    SUM(no_mo_order_num_1)                                          AS `no_mo_order_num_1`, 
    SUM(no_mo_order_num_2to3)                                       AS `no_mo_order_num_2to3`, 
    SUM(no_mo_order_num_4to7)                                       AS `no_mo_order_num_4to7`,
    SUM(no_mo_order_num_7plus)                                      AS `no_mo_order_num_7plus`,
    SUM(no_mo_order_ticket_0)                                       AS `no_mo_order_ticket_0`,
    SUM(no_mo_order_ticket_1)                                       AS `no_mo_order_ticket_1`, 
    SUM(no_mo_order_ticket_2to3)                                    AS `no_mo_order_ticket_2to3`, 
    SUM(no_mo_order_ticket_4to7)                                    AS `no_mo_order_ticket_4to7`,
    SUM(no_mo_order_ticket_7plus)                                   AS `no_mo_order_ticket_7plus`,
    SUM(no_mo_order_amount_0)                                       AS `no_mo_order_amount_0`,
    SUM(no_mo_order_amount_1)                                       AS `no_mo_order_amount_1`, 
    SUM(no_mo_order_amount_2to3)                                    AS `no_mo_order_amount_2to3`, 
    SUM(no_mo_order_amount_4to7)                                    AS `no_mo_order_amount_4to7`,
    SUM(no_mo_order_amount_7plus)                                   AS `no_mo_order_amount_7plus`,
    month
FROM ads_daily_scenic_pre_booking_d_i
WHERE SUBSTR(`fulldate`, 0, 6) = SUBSTR('${ds}', 0, 6)
GROUP BY 
    sid,
    land_id,
    p_type,
    year,
    month;