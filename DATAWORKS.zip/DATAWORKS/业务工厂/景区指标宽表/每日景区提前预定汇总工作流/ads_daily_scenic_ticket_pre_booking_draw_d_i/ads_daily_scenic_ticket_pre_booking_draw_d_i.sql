-- name ads_daily_scenic_pre_booking_draw_d_i
-- type Spark SQL
-- author wanghaiyang@12301.cc
-- create time 2025-03-10 14:31:05
-- desc 景区每日提前预定画像统计表

SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;

CREATE TABLE IF NOT EXISTS `ads_daily_scenic_ticket_pre_booking_draw_d_i`(
    `year`              INT     COMMENT'年',
    `month`             INT     COMMENT'月',
    `week`              INT     COMMENT'年周',
    `sid`               INT     COMMENT'原始供应商id',
    `land_id`           INT     COMMENT'景区ID',
    `ticket_id`         INT     COMMENT'票ID',
    `p_type`            STRING  COMMENT'景区类型：A景区B线路C酒店F套票',
    `country`           STRING  COMMENT'统计国家(境内/境外/未知)',
    `province`          STRING  COMMENT'统计省',
    `city`              STRING  COMMENT'统计市',
    `district`          STRING  COMMENT'统计区县',
    `male_age_0to7`     BIGINT  COMMENT'男性且年龄范围0-7',
    `male_age_8to17`    BIGINT  COMMENT'男性且年龄范围8-17',
    `male_age_18to27`   BIGINT  COMMENT'男性且年龄范围18-27',
    `male_age_28to40`   BIGINT  COMMENT'男性且年龄范围28-40',
    `male_age_41to60`   BIGINT  COMMENT'男性且年龄范围41-60',
    `male_age_61plus`   BIGINT  COMMENT'男性且年龄范围>60',
    `female_age_0to7`   BIGINT  COMMENT'女性且年龄范围0-7',
    `female_age_8to17`  BIGINT  COMMENT'女性且年龄范围8-17',
    `female_age_18to27` BIGINT  COMMENT'女性且年龄范围18-27',
    `female_age_28to40` BIGINT  COMMENT'女性且年龄范围28-40',
    `female_age_41to60` BIGINT  COMMENT'女性且年龄范围41-60',
    `female_age_61plus` BIGINT  COMMENT'女性且年龄范围>60',
    `unknown`           BIGINT  COMMENT'性别年龄未知',
    `total`             BIGINT  COMMENT'总人数'
 )comment'景区每日提前预定画像统计表'partitioned by(
    fulldate INT COMMENT'全日期'
 )STORED AS ORC;


INSERT OVERWRITE TABLE ads_daily_scenic_ticket_pre_booking_draw_d_i PARTITION(fulldate)
SELECT	
    YEAR(play_date)                                                 AS `year`,
    YEAR(play_date) * 100 + MONTH(play_date)                        AS `month`,
    INT(dim_isoweek.isoweek)                                        AS `week`,
    INT(apply_did)                                                  AS `sid`,
    land_id                                                         AS `land_id`,
    ticket_id                                                       AS `ticket_id`,
    p_type                                                          AS `p_type`,
    country                                                         AS `country`,
    province                                                        AS `province`,
    city                                                            AS `city`,
    district                                                        AS `district`,
    male_age_0to7                                                   AS `male_age_0to7`,    
    male_age_8to17                                                  AS `male_age_8to17`,   
    male_age_18to27                                                 AS `male_age_18to27`,  
    male_age_28to40                                                 AS `male_age_28to40`,  
    male_age_41to60                                                 AS `male_age_41to60`,  
    male_age_61plus                                                 AS `male_age_61plus`,  
    female_age_0to7                                                 AS `female_age_0to7`,  
    female_age_8to17                                                AS `female_age_8to17`, 
    female_age_18to27                                               AS `female_age_18to27`,
    female_age_28to40                                               AS `female_age_28to40`,
    female_age_41to60                                               AS `female_age_41to60`,
    female_age_61plus                                               AS `female_age_61plus`,
    `unknown`                                                       AS `unknown`,          
    total                                                           AS `total`,
    INT(regexp_replace(play_date, '-', ''))                         AS `fulldate`
FROM(
    SELECT 
        apply_did,
        land_id,
        ticket_id,
        p_type,
        country_name                                                                AS `country`,
        province_name                                                               AS `province`,
        city_name                                                                   AS `city`,
        district_name                                                               AS `district`,
        -- 主单
        SUM(IF(age_range='0-7'   AND sex='男', multiple, 0))                        AS `male_age_0to7`,    
        SUM(IF(age_range='8-17'  AND sex='男', multiple, 0))                        AS `male_age_8to17`,   
        SUM(IF(age_range='18-27' AND sex='男', multiple, 0))                        AS `male_age_18to27`,  
        SUM(IF(age_range='28-40' AND sex='男', multiple, 0))                        AS `male_age_28to40`,  
        SUM(IF(age_range='41-60' AND sex='男', multiple, 0))                        AS `male_age_41to60`,  
        SUM(IF(age_range='61+'   AND sex='男', multiple, 0))                        AS `male_age_61plus`,  
        SUM(IF(age_range='0-7'   AND sex='女', multiple, 0))                        AS `female_age_0to7`,  
        SUM(IF(age_range='8-17'  AND sex='女', multiple, 0))                        AS `female_age_8to17`, 
        SUM(IF(age_range='18-27' AND sex='女', multiple, 0))                        AS `female_age_18to27`,
        SUM(IF(age_range='28-40' AND sex='女', multiple, 0))                        AS `female_age_28to40`,
        SUM(IF(age_range='41-60' AND sex='女', multiple, 0))                        AS `female_age_41to60`,
        SUM(IF(age_range='61+'   AND sex='女', multiple, 0))                        AS `female_age_61plus`,

        SUM(IF(age_range='-1' OR age_range IS NULL OR age_range='', multiple, 0))   AS `unknown`,          
        SUM(multiple)                                                               AS `total`,
        play_date                                                                   AS `play_date`
    FROM(
        SELECT
            apply_did,
            land_id, 
            ticket_id                                   AS `ticket_id`,
            order_id,
            land_type                                   AS  `p_type`,
            TO_DATE(play_time)                          AS  `play_date`
        FROM dwd_order_d_i
        -- 属于已支付订单
        WHERE order_pay_status != 2 
        -- 订单状态不属于取消/撤销/删除状态
        AND order_status_code not in(3, 6, 9)
        -- 近40天订单
        AND booking_date >= regexp_replace(date_sub(to_date(from_unixtime(unix_timestamp('${ds}', 'yyyyMMdd'))), 40), '-', '')
        -- 只修复游玩日期等于昨日的分区
        AND TO_DATE(play_time) = to_date(from_unixtime(unix_timestamp('${ds}', 'yyyyMMdd')))
    ) orderTab
    JOIN (
        SELECT 
            orderid, 
            multiple,
            CASE WHEN country_name = '境内' THEN '中国' ELSE country_name END AS country_name,
            province_name,
            city_name,
            district_name,
            sex,
            -- 年龄范围
            CASE
                WHEN age BETWEEN 0 AND 7
                THEN '0-7'
                WHEN age BETWEEN 8 AND 17
                THEN '8-17'
                WHEN age BETWEEN 18 AND 27
                THEN '18-27'
                WHEN age BETWEEN 28 AND 40
                THEN '28-40'
                WHEN age BETWEEN 41 AND 60
                THEN '41-60'
                WHEN age BETWEEN 61 AND 122 
                THEN '61+'
                ELSE '-1'
            END 	AS age_range
        FROM ods_tourist_info_d_i
        WHERE orderdate >= regexp_replace(date_sub(to_date(from_unixtime(unix_timestamp('${ds}', 'yyyyMMdd'))), 40), '-', '')
    ) touristTab
    ON orderTab.order_id = touristTab.orderid
    GROUP BY 
        apply_did,
        land_id,
        ticket_id,
        p_type,
        country_name,
        province_name,
        city_name,
        district_name,
        play_date
) countTab
LEFT JOIN dim_date_isoweek_o_f AS dim_isoweek 
ON countTab.play_date = dim_isoweek.`date`
