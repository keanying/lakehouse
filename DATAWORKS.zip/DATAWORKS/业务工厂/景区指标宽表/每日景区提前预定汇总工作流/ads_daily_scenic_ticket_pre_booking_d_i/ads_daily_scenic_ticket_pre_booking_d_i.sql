-- name ads_daily_scenic_ticket_pre_booking_d_i
-- type Spark SQL
-- author wanghaiyang@12301.cc
-- create time 2024-08-26 18:35:07
-- desc 景区每日门票提前预定统计表

SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;

CREATE TABLE IF NOT EXISTS ads_daily_scenic_ticket_pre_booking_d_i(
    `sid`                           INT     COMMENT '原始供应商id',
    `land_id`                       INT     COMMENT '景区ID',
    `pid`                           INT     COMMENT '产品id',
    `ticket_id`                     INT     COMMENT '票ID',
    `p_type`                        STRING  COMMENT '景区类型：A景区B线路C酒店F套票',
    `year`                          INT     COMMENT '年',
    `month`                         INT     COMMENT '月',
    `week`                          INT     COMMENT '年周',
    `mo_order_num`                  BIGINT  COMMENT '主单预定订单数',
    `mo_order_ticket`               BIGINT  COMMENT '主单预定票数',
    `mo_order_amount`               BIGINT  COMMENT '主单预定订单金额',
    `mo_order_num_0`                BIGINT  COMMENT '主单当天预定订单数', 
    `mo_order_num_1`                BIGINT  COMMENT '主单昨天预定订单数', 
    `mo_order_num_2to3`             BIGINT  COMMENT '主单提前预定1-3天订单数', 
    `mo_order_num_4to7`             BIGINT  COMMENT '主单提前预定4-7天订单数', 
    `mo_order_num_7plus`            BIGINT  COMMENT '主单提前预定7天以上订单数', 
    `mo_order_ticket_0`             BIGINT  COMMENT '主单当天预定票数', 
    `mo_order_ticket_1`             BIGINT  COMMENT '主单昨天预定票数', 
    `mo_order_ticket_2to3`          BIGINT  COMMENT '主单提前预定2-3天票数', 
    `mo_order_ticket_4to7`          BIGINT  COMMENT '主单提前预定4-7天票数', 
    `mo_order_ticket_7plus`         BIGINT  COMMENT '主单提前预定7天以上票数', 
    `mo_order_amount_0`             BIGINT  COMMENT '主单当天预定订单金额', 
    `mo_order_amount_1`             BIGINT  COMMENT '主单昨天预定订单金额', 
    `mo_order_amount_2to3`          BIGINT  COMMENT '主单提前预定1-3天订单金额', 
    `mo_order_amount_4to7`          BIGINT  COMMENT '主单提前预定4-7天订单金额', 
    `mo_order_amount_7plus`         BIGINT  COMMENT '主单提前预定7天以上订单金额',
    `no_mo_order_num`               BIGINT  COMMENT '子单预定订单数',
    `no_mo_order_ticket`            BIGINT  COMMENT '子单预定票数',
    `no_mo_order_amount`            BIGINT  COMMENT '子单预定订单金额',
    `no_mo_order_num_0`             BIGINT  COMMENT '子单当天预定订单数', 
    `no_mo_order_num_1`             BIGINT  COMMENT '子单昨天预定订单数', 
    `no_mo_order_num_2to3`          BIGINT  COMMENT '子单提前预定1-3天订单数', 
    `no_mo_order_num_4to7`          BIGINT  COMMENT '子单提前预定4-7天订单数', 
    `no_mo_order_num_7plus`         BIGINT  COMMENT '子单提前预定7天以上订单数', 
    `no_mo_order_ticket_0`          BIGINT  COMMENT '子单当天预定票数', 
    `no_mo_order_ticket_1`          BIGINT  COMMENT '子单昨天预定票数', 
    `no_mo_order_ticket_2to3`       BIGINT  COMMENT '子单提前预定2-3天票数', 
    `no_mo_order_ticket_4to7`       BIGINT  COMMENT '子单提前预定4-7天票数', 
    `no_mo_order_ticket_7plus`      BIGINT  COMMENT '子单提前预定7天以上票数', 
    `no_mo_order_amount_0`          BIGINT  COMMENT '子单当天预定订单金额', 
    `no_mo_order_amount_1`          BIGINT  COMMENT '子单昨天预定订单金额', 
    `no_mo_order_amount_2to3`       BIGINT  COMMENT '子单提前预定1-3天订单金额', 
    `no_mo_order_amount_4to7`       BIGINT  COMMENT '子单提前预定4-7天订单金额', 
    `no_mo_order_amount_7plus`      BIGINT  COMMENT '子单提前预定7天以上订单金额'
)COMMENT '景区每日门票提前预定统计表'
PARTITIONED BY (`fulldate`  INT     COMMENT '游玩日期')
STORED AS ORC;

INSERT OVERWRITE TABLE ads_daily_scenic_ticket_pre_booking_d_i PARTITION(fulldate)
SELECT 
    INT(sid)                                                                              AS `sid`,
    land_id                                                                               AS `land_id`,
    pid                                                                                   AS `pid`,
    ticket_id                                                                             AS `ticket_id`,
    p_type                                                                                AS `p_type`,
    YEAR(play_date)                                                                       AS `year`,
    YEAR(play_date) * 100 + MONTH(play_date)                                              AS `month`,
    INT(dim_isoweek.isoweek)                                                              AS `week`,
    SUM(IF(order_type!='套票子票', order_num, 0))                                         AS `mo_order_num`,
    SUM(IF(order_type!='套票子票', order_ticket, 0))                                      AS `mo_order_ticket`,
    SUM(IF(order_type!='套票子票', order_amount, 0))                                      AS `mo_order_amount`,
    SUM(IF(diff_days=0 AND order_type!='套票子票', order_num, 0))                         AS `mo_order_num_0`,
    SUM(IF(diff_days=1 AND order_type!='套票子票', order_num, 0))                         AS `mo_order_num_1`, 
    SUM(IF(diff_days>=2 AND diff_days<=3 AND order_type!='套票子票', order_num, 0))       AS `mo_order_num_2to3`, 
    SUM(IF(diff_days>=4 AND diff_days<=7 AND order_type!='套票子票', order_num, 0))       AS `mo_order_num_4to7`,
    SUM(IF(diff_days>7 AND order_type!='套票子票', order_num, 0))                         AS `mo_order_num_7plus`,
    SUM(IF(diff_days=0 AND order_type!='套票子票', order_ticket, 0))                      AS `mo_order_ticket_0`,
    SUM(IF(diff_days=1 AND order_type!='套票子票', order_ticket, 0))                      AS `mo_order_ticket_1`, 
    SUM(IF(diff_days>=2 AND diff_days<=3 AND order_type!='套票子票', order_ticket, 0))    AS `mo_order_ticket_2to3`, 
    SUM(IF(diff_days>=4 AND diff_days<=7 AND order_type!='套票子票', order_ticket, 0))    AS `mo_order_ticket_4to7`,
    SUM(IF(diff_days>7 AND order_type!='套票子票', order_ticket, 0))                      AS `mo_order_ticket_7plus`,
    SUM(IF(diff_days=0 AND order_type!='套票子票', order_amount, 0))                      AS `mo_order_amount_0`,
    SUM(IF(diff_days=1 AND order_type!='套票子票', order_amount, 0))                      AS `mo_order_amount_1`, 
    SUM(IF(diff_days>=2 AND diff_days<=3 AND order_type!='套票子票', order_amount, 0))    AS `mo_order_amount_2to3`, 
    SUM(IF(diff_days>=4 AND diff_days<=7 AND order_type!='套票子票', order_amount, 0))    AS `mo_order_amount_4to7`,
    SUM(IF(diff_days>7 AND order_type!='套票子票', order_amount, 0))                      AS `mo_order_amount_7plus`,

    SUM(IF(order_type='套票子票', order_num, 0))                                          AS `no_mo_order_num`,
    SUM(IF(order_type='套票子票', order_ticket, 0))                                       AS `no_mo_order_ticket`,
    SUM(IF(order_type='套票子票', order_amount, 0))                                       AS `no_mo_order_amount`,
    SUM(IF(diff_days=0 AND order_type='套票子票', order_num, 0))                          AS `no_mo_order_num_0`,
    SUM(IF(diff_days=1 AND order_type='套票子票', order_num, 0))                          AS `no_mo_order_num_1`, 
    SUM(IF(diff_days>=2 AND diff_days<=3 AND order_type='套票子票', order_num, 0))        AS `no_mo_order_num_2to3`, 
    SUM(IF(diff_days>=4 AND diff_days<=7 AND order_type='套票子票', order_num, 0))        AS `no_mo_order_num_4to7`,
    SUM(IF(diff_days>7 AND order_type='套票子票', order_num, 0))                          AS `no_mo_order_num_7plus`,
    SUM(IF(diff_days=0 AND order_type='套票子票', order_ticket, 0))                       AS `no_mo_order_ticket_0`,
    SUM(IF(diff_days=1 AND order_type='套票子票', order_ticket, 0))                       AS `no_mo_order_ticket_1`, 
    SUM(IF(diff_days>=2 AND diff_days<=3 AND order_type='套票子票', order_ticket, 0))     AS `no_mo_order_ticket_2to3`, 
    SUM(IF(diff_days>=4 AND diff_days<=7 AND order_type='套票子票', order_ticket, 0))     AS `no_mo_order_ticket_4to7`,
    SUM(IF(diff_days>7 AND order_type='套票子票', order_ticket, 0))                       AS `no_mo_order_ticket_7plus`,
    SUM(IF(diff_days=0 AND order_type='套票子票', order_amount, 0))                       AS `no_mo_order_amount_0`,
    SUM(IF(diff_days=1 AND order_type='套票子票', order_amount, 0))                       AS `no_mo_order_amount_1`, 
    SUM(IF(diff_days>=2 AND diff_days<=3 AND order_type='套票子票', order_amount, 0))     AS `no_mo_order_amount_2to3`, 
    SUM(IF(diff_days>=4 AND diff_days<=7 AND order_type='套票子票', order_amount, 0))     AS `no_mo_order_amount_4to7`,
    SUM(IF(diff_days>7 AND order_type='套票子票', order_amount, 0))                       AS `no_mo_order_amount_7plus`,
    INT(dim_isoweek.fulldate)
FROM(
    SELECT 
        order_type                                  AS  order_type,
        apply_did                                   AS  sid, 
        land_id                                     AS  land_id,
        product_id                                  AS  pid,
        ticket_id                                   AS  ticket_id,
        land_type                                   AS  p_type,
        TO_DATE(play_time)                          AS  play_date, 
        DATEDIFF(TO_DATE(play_time), to_date(from_unixtime(unix_timestamp(CAST(booking_date AS STRING), 'yyyyMMdd'))))  
                                                    AS  diff_days,
        1                                           AS  order_num,
        ticket_num                                  AS  order_ticket,
        order_pay_amount                            AS  order_amount
    FROM dwd_order_d_i
    -- 属于已支付订单
    WHERE order_pay_status != 2 
    -- 订单状态不属于取消/撤销/删除状态
    AND order_status_code not in(3, 6, 9)
    -- 近40天订单
    AND booking_date >= regexp_replace(date_sub(to_date(from_unixtime(unix_timestamp('${ds}', 'yyyyMMdd'))), 40), '-', '')
    -- 只修复游玩日期等于昨日的分区
    AND TO_DATE(play_time) = to_date(from_unixtime(unix_timestamp('${ds}', 'yyyyMMdd')))
) AS orderTab
LEFT JOIN dim_date_isoweek_o_f AS dim_isoweek 
ON `orderTab`.play_date = dim_isoweek.`date`
GROUP BY 
    sid,
    land_id,
    pid,
    ticket_id,
    p_type,
    play_date,
    dim_isoweek.isoweek,
    dim_isoweek.fulldate;