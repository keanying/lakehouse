SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;

CREATE TABLE IF NOT EXISTS ads_daily_account_trans_item_summary_d_i
(
    `account_id`             INT    COMMENT '账户ID',
    `trade_account_id`       INT    COMMENT '交易对方账户ID',
    `account_book_id`        BIGINT COMMENT '当前账户账本ID',
    `subject_code`           INT    COMMENT '账本科目编码',
    `template_item_code`     INT    COMMENT '费用项编码',
    `income`                 BIGINT COMMENT '收入',
    `expense`                BIGINT COMMENT '支出',
    `frozen_income`          BIGINT COMMENT '收入(冻结)',
    `frozen_expense`         BIGINT COMMENT '支出(解冻)',
    `available_income`       BIGINT COMMENT '可用收入',
    `available_expense`      BIGINT COMMENT '可用支出',
    `operate_time`           INT    COMMENT '数据插入时间'       
) COMMENT'交易记录账本费用项汇总表' 
PARTITIONED BY(
    fulldate INT COMMENT '交易记录的时间yyyyMMdd'
) STORED AS ORC;

INSERT OVERWRITE table ads_daily_account_trans_item_summary_d_i PARTITION (fulldate='${ds}')
SELECT
    INT(`account_id`)                                                       AS      `account_id`,
    INT(CASE WHEN subject_code = 2601 THEN 0 ELSE trade_account_id END)     AS      `trade_account_id`,
    0                                                                       AS      `account_book_id`,
    `subject_code`                                                          AS      `subject_code`,   
    `template_item_code`                                                    AS      `template_item_code`,
    SUM(IF(daction = 0, dmoney, 0))                                         AS      `income`,
    SUM(IF(daction = 1, dmoney, 0))                                         AS      `expense`,
    SUM(IF(frozen_trade_type = 0, frozen_money, 0))                         AS      `frozen_income`,
    SUM(IF(frozen_trade_type = 1, frozen_money, 0))                         AS      `frozen_expense`,   
    SUM(IF(available_trade_type = 0, available_money, 0))                   AS      `available_income`,
    SUM(IF(available_trade_type = 1, available_money, 0))                   AS      `available_expense`,
    unix_timestamp()                                                        AS      `operate_time`
FROM ods_pft_trade_journal_d_i
WHERE recdate = '${ds}'
    AND subject_code in (2601, 2101)
GROUP BY 
    `account_id`,
    CASE WHEN subject_code = 2601 THEN 0 ELSE trade_account_id END,
    `subject_code`, 
    `template_item_code`;