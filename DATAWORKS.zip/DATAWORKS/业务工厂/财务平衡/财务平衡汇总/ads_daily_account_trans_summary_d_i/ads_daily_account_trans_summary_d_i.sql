-- name ads_daily_account_trans_summary_d_i
-- type Spark SQL
-- author wanghaiyang@12301.cc
-- create time 2025-04-15 17:19:23
-- desc 每日用户账本汇总表

CREATE TABLE IF NOT EXISTS ads_daily_account_trans_summary_d_i
(
    `account_id`             INT    COMMENT '账户ID',
    `trade_account_id`       INT    COMMENT '交易对方账户ID',
    `account_book_id`        BIGINT COMMENT '当前账户账本ID',
    `subject_code`           INT    COMMENT '账本科目编码',
    `income`                 BIGINT COMMENT '收入',
    `expense`                BIGINT COMMENT '支出',
    `begin_money`            BIGINT COMMENT '期初余额',
    `end_money`              BIGINT COMMENT '期末余额',
    `frozen_income`          BIGINT COMMENT '收入(冻结)',
    `frozen_expense`         BIGINT COMMENT '支出(解冻)',
    `frozen_begin_money`     BIGINT COMMENT '冻结期初余额',
    `frozen_end_money`       BIGINT COMMENT '冻结期末余额',
    `available_income`       BIGINT COMMENT '可用收入',
    `available_expense`      BIGINT COMMENT '可用支出',
    `available_begin_money`  BIGINT COMMENT '可用期初余额',
    `available_end_money`    BIGINT COMMENT '可用期末余额',
    `operate_time`           INT    COMMENT '数据插入时间'  
) COMMENT'每日用户账本汇总表' 
PARTITIONED BY(
    fulldate INT COMMENT '交易记录的时间yyyyMMdd'
)
STORED AS ORC;

DROP TABLE IF EXISTS ads_daily_account_trans_summary_yeasterday;
CREATE TABLE ads_daily_account_trans_summary_yeasterday AS 
SELECT 
    account_id,
    trade_account_id,
    subject_code,
    0                   AS  `income`,
    0                   AS  `expense`,
    end_money           AS  `begin_money`,
    end_money           AS  `end_money`,
    0                   AS  `frozen_income`,
    0                   AS  `frozen_expense`,
    frozen_end_money    AS  `frozen_begin_money`,
    frozen_end_money    AS  `frozen_end_money`,
    0                   AS  `available_income`,
    0                   AS  `available_expense`,
    available_end_money AS  `available_begin_money`,
    available_end_money
FROM ads_daily_account_trans_summary_d_i
WHERE fulldate = DATE_FORMAT(DATE_SUB(to_date('${ds}', 'yyyyMMdd'), 1),"yyyyMMdd");

-- 交易流水数据
WITH tradeTab AS (
    SELECT
        recdate,
        sequence,
        id,
        rectime,
        INT(`account_id`)                                       AS `account_id`,
        CASE WHEN subject_code = 2601 THEN 0 ELSE trade_account_id END  AS `trade_account_id`,
        `subject_code`,   
        IF(daction = 0, dmoney, 0)                              AS      income,
        IF(daction = 1, dmoney, 0)                              AS      expense,
        IF(daction = 0, lmoney-dmoney, lmoney+dmoney)           AS      begin_money,
        lmoney                                                  AS      end_money,
        IF(frozen_trade_type = 0, frozen_money, 0)              AS      frozen_income,
        IF(frozen_trade_type = 1, frozen_money, 0)              AS      frozen_expense,
        IF(frozen_trade_type = 0, frozen_remain_money-frozen_money, frozen_remain_money+frozen_money)           
                                                                AS      frozen_begin_money,
        frozen_remain_money                                     AS      frozen_end_money,
        IF(available_trade_type = 0, available_money, 0)        AS      available_income,
        IF(available_trade_type = 1, available_money, 0)        AS      available_expense,
        IF(available_trade_type = 0, available_remain_money-available_money, available_remain_money+available_money)    
                                                                AS      available_begin_money,
        available_remain_money                                  AS      available_end_money

    FROM ods_pft_trade_journal_d_i
    WHERE recdate = '${ds}'
        AND subject_code in (2601, 2101)
),
-- 汇总数据
sumTab AS (
    SELECT
        account_id,
        trade_account_id,
        subject_code,
        SUM(income) AS income,
        SUM(expense) AS expense,
        SUM(frozen_income) AS frozen_income,
        SUM(frozen_expense) AS frozen_expense,
        SUM(available_income) AS available_income,
        SUM(available_expense) AS available_expense
    FROM tradeTab
    GROUP BY account_id, trade_account_id, subject_code
),
-- 期初数据
firstTab AS (
    SELECT
        account_id,
        trade_account_id,
        subject_code,
        begin_money,
        frozen_begin_money,
        available_begin_money
    FROM (
        SELECT
            `account_id`,
            `trade_account_id`,
            `subject_code`, 
            begin_money,
            frozen_begin_money,
            available_begin_money,
            ROW_NUMBER() OVER (PARTITION BY `account_id`, `trade_account_id`, `subject_code` ORDER BY rectime, sequence, id) AS rn
        FROM tradeTab
    ) t 
    WHERE rn = 1
),
lastTab AS (
    SELECT
        account_id,
        trade_account_id,
        subject_code,
        end_money,
        frozen_end_money,
        available_end_money
    FROM (
        SELECT
            `account_id`,
            `trade_account_id`,
            `subject_code`, 
            end_money,
            frozen_end_money,
            available_end_money,
            ROW_NUMBER() OVER (PARTITION BY `account_id`, `trade_account_id`, `subject_code` ORDER BY rectime desc, sequence desc, id desc) AS rn
        FROM tradeTab
    ) t 
    WHERE rn = 1
)


INSERT OVERWRITE table ads_daily_account_trans_summary_d_i PARTITION (fulldate='${ds}')
SELECT 
    INT(COALESCE(todayTab.account_id, hisTab.account_id))                       AS  `account_id`,
    INT(COALESCE(todayTab.trade_account_id, hisTab.trade_account_id))           AS  `trade_account_id`,
    0                                                                           AS  `account_book_id`,
    COALESCE(todayTab.subject_code, hisTab.subject_code)                        AS  `subject_code`,
    -- 若今日有数据, 取今日数据, 否则取昨日数据
    COALESCE(todayTab.income, hisTab.income)                                    AS  `income`,
    COALESCE(todayTab.expense, hisTab.expense)                                  AS  `expense`,

    COALESCE(todayTab.begin_money, hisTab.begin_money)                          AS  `begin_money`,
    COALESCE(todayTab.end_money, hisTab.end_money)                              AS  `end_money`,
    
    COALESCE(todayTab.frozen_income, hisTab.frozen_income)                      AS  `frozen_income`,
    COALESCE(todayTab.frozen_expense, hisTab.frozen_expense)                    AS  `frozen_expense`,
    COALESCE(todayTab.frozen_begin_money, hisTab.frozen_begin_money)            AS  `frozen_begin_money`,
    COALESCE(todayTab.frozen_end_money, hisTab.frozen_end_money)                AS  `frozen_end_money`,
    COALESCE(todayTab.available_income, hisTab.available_income)                AS  `available_income`,

    COALESCE(todayTab.available_expense, hisTab.available_expense)              AS  `available_expense`,
    COALESCE(todayTab.available_begin_money, hisTab.available_begin_money)      AS  `available_begin_money`,
    COALESCE(todayTab.available_end_money, hisTab.available_end_money)          AS  `available_end_money`,
    unix_timestamp()                                                            AS  `operate_time`
FROM ads_daily_account_trans_summary_yeasterday hisTab
FULL JOIN(
    -- 今日数据
    SELECT 
        sumTab.account_id,
        sumTab.trade_account_id,
        sumTab.subject_code,
        sumTab.income,
        sumTab.expense,
        firstTab.begin_money,
        lastTab.end_money,
        sumTab.frozen_income,
        sumTab.frozen_expense,
        firstTab.frozen_begin_money,
        lastTab.frozen_end_money,
        sumTab.available_income,
        sumTab.available_expense,
        firstTab.available_begin_money,
        lastTab.available_end_money
    FROM sumTab
    JOIN firstTab
        ON sumTab.account_id = firstTab.account_id
        AND sumTab.trade_account_id = firstTab.trade_account_id
        AND sumTab.subject_code = firstTab.subject_code
    JOIN lastTab
        ON sumTab.account_id = lastTab.account_id
        AND sumTab.trade_account_id = lastTab.trade_account_id
        AND sumTab.subject_code = lastTab.subject_code
) todayTab
ON hisTab.account_id = todayTab.account_id
    AND hisTab.trade_account_id = todayTab.trade_account_id
    AND hisTab.subject_code = todayTab.subject_code;