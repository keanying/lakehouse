-- name ads_daily_trade_account_trans_summary_d_i
-- type Spark SQL
-- author wanghaiyang@12301.cc
-- create time 2025-04-15 17:19:23
-- desc 每日授信账户汇总表
SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;

CREATE TABLE IF NOT EXISTS ads_daily_trade_account_trans_summary_d_i
(
    `trade_account_id`       INT    COMMENT '交易对方账户ID',
    `account_book_id`        BIGINT COMMENT '当前账户账本ID',
    `subject_code`           INT    COMMENT '账本科目编码',
    `income`                 BIGINT COMMENT '收入',
    `expense`                BIGINT COMMENT '支出',
    `begin_money`            BIGINT COMMENT '期初余额',
    `end_money`              BIGINT COMMENT '期末余额',
    `frozen_income`          BIGINT COMMENT '收入(冻结)',
    `frozen_expense`         BIGINT COMMENT '支出(解冻)',
    `frozen_begin_money`     BIGINT COMMENT '冻结期初余额',
    `frozen_end_money`       BIGINT COMMENT '冻结期末余额',
    `available_income`       BIGINT COMMENT '可用收入',
    `available_expense`      BIGINT COMMENT '可用支出',
    `available_begin_money`  BIGINT COMMENT '可用期初余额',
    `available_end_money`    BIGINT COMMENT '可用期末余额',
    `operate_time`           INT    COMMENT '数据插入时间'  
) COMMENT'每日授信账户汇总表' 
PARTITIONED BY(
    fulldate INT COMMENT '交易记录的时间yyyyMMdd'
)
STORED AS ORC;


INSERT OVERWRITE table ads_daily_trade_account_trans_summary_d_i PARTITION (fulldate='${ds}')
SELECT 
    `trade_account_id`                          AS  `trade_account_id`,
    0                                           AS  `account_book_id`,
    `subject_code`                              AS  `subject_code`,
    SUM(income)                                 AS  `income`,
    SUM(expense)                                AS  `expense`,

    SUM(`begin_money`)                          AS  `begin_money`,
    SUM(`end_money`)                            AS  `end_money`,
    
    SUM(`frozen_income`)                        AS  `frozen_income`,
    SUM(`frozen_expense`)                       AS  `frozen_expense`,
    SUM(`frozen_begin_money`)                   AS  `frozen_begin_money`,
    SUM(`frozen_end_money`)                     AS  `frozen_end_money`,
    SUM(`available_income`)                     AS  `available_income`,

    SUM(`available_expense`)                    AS  `available_expense`,
    SUM(`available_begin_money`)                AS  `available_begin_money`,
    SUM(`available_end_money`)                  AS  `available_end_money`,
    unix_timestamp()                            AS  `operate_time`
FROM ads_daily_account_trans_summary_d_i t
WHERE fulldate = '${ds}'
    AND subject_code = 2101
GROUP BY  
    `trade_account_id`,
    `subject_code`;