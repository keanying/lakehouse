DROP TABLE IF EXISTS init_account_trans_lastdate_o_f;
DROP TABLE IF EXISTS init_account_trans_last_end_money_o_f;

-- 获取2025年前的最后一次交易流水的日期
CREATE TABLE init_account_trans_lastdate_o_f AS 
SELECT
    MAX(recdate)      AS      lastdate,
    `account_id`,
    CASE WHEN subject_code = 2601 THEN 0 ELSE trade_account_id END  AS `trade_account_id`,
    `subject_code`
FROM ods_pft_trade_journal_d_i
WHERE recdate < '20250101'
AND subject_code IN (2601, 2101) 
GROUP BY 
    `account_id`,
    CASE WHEN subject_code = 2601 THEN 0 ELSE trade_account_id END,
    `subject_code`;


-- 获取2025年前最后一次流水的所有期末金额(可能报错,注意检查,正常情况下大概跑15分钟)
CREATE TABLE init_account_trans_last_end_money_o_f AS 
SELECT 
    tradeTab.recdate as lastdate,
    tradeTab.account_id,
    tradeTab.trade_account_id,
    tradeTab.subject_code,
    tradeTab.end_money,
    tradeTab.frozen_end_money,
    tradeTab.available_end_money
FROM(
    SELECT 
        recdate,
        sequence,
        id, 
        rectime,
        `account_id`,
        CASE WHEN subject_code = 2601 THEN 0 ELSE trade_account_id END  AS `trade_account_id`,
        `subject_code`,   
        lmoney                                                          AS      end_money,
        frozen_remain_money                                             AS      frozen_end_money,
        available_remain_money                                          AS      available_end_money,
        ROW_NUMBER() OVER (
            PARTITION BY
                `account_id`, 
                CASE WHEN subject_code = 2601 THEN 0 ELSE trade_account_id END,
                `subject_code` 
            ORDER BY
                rectime desc, 
                sequence desc,
                id desc
            ) as rank
    FROM ods_pft_trade_journal_d_i
    WHERE recdate < '20250101'
    AND subject_code IN (2601, 2101)
) tradeTab
JOIN init_account_trans_lastdate_o_f lastTab
ON tradeTab.`account_id` = lastTab.`account_id`
    AND tradeTab.`trade_account_id` = lastTab.`trade_account_id`
    AND tradeTab.`subject_code`= lastTab.`subject_code`
    AND tradeTab.`recdate` = lastTab.lastdate
WHERE rank = 1 AND (end_money !=0 OR frozen_end_money!=0 OR available_end_money != 0);

-- 基础交易流水数据
WITH tradeTab AS (
    SELECT
        recdate,
        sequence,
        id,
        rectime,
        `account_id`,
        CASE WHEN subject_code = 2601 THEN 0 ELSE trade_account_id END  AS `trade_account_id`,
        `subject_code`,   
        IF(daction = 0, dmoney, 0)                              AS      income,
        IF(daction = 1, dmoney, 0)                              AS      expense,
        IF(daction = 0, lmoney-dmoney, lmoney+dmoney)           AS      begin_money,
        lmoney                                                  AS      end_money,
        IF(frozen_trade_type = 0, frozen_money, 0)              AS      frozen_income,
        IF(frozen_trade_type = 1, frozen_money, 0)              AS      frozen_expense,
        IF(frozen_trade_type = 0, frozen_remain_money-frozen_money, frozen_remain_money+frozen_money)           
                                                                AS      frozen_begin_money,
        frozen_remain_money                                     AS      frozen_end_money,
        IF(available_trade_type = 0, available_money, 0)        AS      available_income,
        IF(available_trade_type = 1, available_money, 0)        AS      available_expense,
        IF(available_trade_type = 0, available_remain_money-available_money, available_remain_money+available_money)    
                                                                AS      available_begin_money,
        available_remain_money                                  AS      available_end_money

    FROM ods_pft_trade_journal_d_i
    WHERE recdate = '20250101'
        AND subject_code in (2601, 2101)
),
-- 汇总数据
sumTab AS (
    SELECT
        account_id,
        trade_account_id,
        subject_code,
        SUM(income) AS income,
        SUM(expense) AS expense,
        SUM(frozen_income) AS frozen_income,
        SUM(frozen_expense) AS frozen_expense,
        SUM(available_income) AS available_income,
        SUM(available_expense) AS available_expense
    FROM tradeTab
    GROUP BY account_id, trade_account_id, subject_code
),
-- 期初数据
firstTab AS (
    SELECT
        account_id,
        trade_account_id,
        subject_code,
        begin_money,
        frozen_begin_money,
        available_begin_money
    FROM (
        SELECT
            `account_id`,
            `trade_account_id`,
            `subject_code`, 
            begin_money,
            frozen_begin_money,
            available_begin_money,
            ROW_NUMBER() OVER (PARTITION BY `account_id`, `trade_account_id`, `subject_code` ORDER BY rectime, sequence, id) AS rn
        FROM tradeTab
    ) t 
    WHERE rn = 1
),
lastTab AS (
    SELECT
        account_id,
        trade_account_id,
        subject_code,
        end_money,
        frozen_end_money,
        available_end_money
    FROM (
        SELECT
            `account_id`,
            `trade_account_id`,
            `subject_code`, 
            end_money,
            frozen_end_money,
            available_end_money,
            ROW_NUMBER() OVER (PARTITION BY `account_id`, `trade_account_id`, `subject_code` ORDER BY rectime desc, sequence desc, id desc) AS rn
        FROM tradeTab
    ) t 
    WHERE rn = 1
)

INSERT OVERWRITE table ads_daily_account_trans_summary_d_i PARTITION (fulldate='20250101')
SELECT 
    INT(COALESCE(todayTab.account_id, hisTab.account_id))                       AS  `account_id`,
    INT(COALESCE(todayTab.trade_account_id, hisTab.trade_account_id))           AS  `trade_account_id`,
    0                                                                           AS  `account_book_id`,
    COALESCE(todayTab.subject_code, hisTab.subject_code)                        AS  `subject_code`,
    COALESCE(todayTab.income, hisTab.income)                                    AS  `income`,
    COALESCE(todayTab.expense, hisTab.expense)                                  AS  `expense`,

    COALESCE(todayTab.begin_money, hisTab.begin_money)                          AS  `begin_money`,
    COALESCE(todayTab.end_money, hisTab.end_money)                              AS  `end_money`,
    
    COALESCE(todayTab.frozen_income, hisTab.frozen_income)                      AS  `frozen_income`,
    COALESCE(todayTab.frozen_expense, hisTab.frozen_expense)                    AS  `frozen_expense`,
    COALESCE(todayTab.frozen_begin_money, hisTab.frozen_begin_money)            AS  `frozen_begin_money`,
    COALESCE(todayTab.frozen_end_money, hisTab.frozen_end_money)                AS  `frozen_end_money`,
    COALESCE(todayTab.available_income, hisTab.available_income)                AS  `available_income`,

    COALESCE(todayTab.available_expense, hisTab.available_expense)              AS  `available_expense`,
    COALESCE(todayTab.available_begin_money, hisTab.available_begin_money)      AS  `available_begin_money`,
    COALESCE(todayTab.available_end_money, hisTab.available_end_money)          AS  `available_end_money`,
    unix_timestamp()                                                            AS  `operate_time`
FROM (
    SELECT 
        account_id,
        trade_account_id,
        subject_code,
        0                   AS  `income`,
        0                   AS  `expense`,
        end_money           AS  `begin_money`,
        end_money           AS  `end_money`,
        0                   AS  `frozen_income`,
        0                   AS  `frozen_expense`,
        frozen_end_money    AS  `frozen_begin_money`,
        frozen_end_money    AS  `frozen_end_money`,
        0                   AS  `available_income`,
        0                   AS  `available_expense`,
        available_end_money AS  `available_begin_money`,
        available_end_money
    FROM init_account_trans_last_end_money_o_f 
) hisTab
FULL JOIN(
    SELECT 
        sumTab.account_id,
        sumTab.trade_account_id,
        sumTab.subject_code,
        sumTab.income,
        sumTab.expense,
        firstTab.begin_money,
        lastTab.end_money,
        sumTab.frozen_income,
        sumTab.frozen_expense,
        firstTab.frozen_begin_money,
        lastTab.frozen_end_money,
        sumTab.available_income,
        sumTab.available_expense,
        firstTab.available_begin_money,
        lastTab.available_end_money
    FROM sumTab
    JOIN firstTab
        ON sumTab.account_id = firstTab.account_id
        AND sumTab.trade_account_id = firstTab.trade_account_id
        AND sumTab.subject_code = firstTab.subject_code
    JOIN lastTab
        ON sumTab.account_id = lastTab.account_id
        AND sumTab.trade_account_id = lastTab.trade_account_id
        AND sumTab.subject_code = lastTab.subject_code
) todayTab
ON hisTab.account_id = todayTab.account_id
    AND hisTab.trade_account_id = todayTab.trade_account_id
    AND hisTab.subject_code = todayTab.subject_code
;