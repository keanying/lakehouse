-- name ads_yearly_fellow_group_d_i
-- type Spark SQL
-- author wanghaiyang@12301.cc
-- create time 2023-05-18 15:01:27
-- desc 景区每日门票归属地_支付渠道_同行人数指标表(按取票人)

SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;

CREATE TABLE IF NOT EXISTS ads_yearly_fellow_group_d_i(
    `land_id`		        INT		COMMENT '景区ID',
    `sid`		            INT		COMMENT '原始供应商id',
    `p_type`                STRING  COMMENT '景区类型：A景区B线路C酒店F套票',
    `pid`                   INT     COMMENT '产品id',
    `ticket_id`             INT     COMMENT '票ID',

    `province`			    STRING	COMMENT '统计省',
    `pay_channel_id`        INT     COMMENT '票支付渠道', 
    `pay_channel_name`      STRING  COMMENT '票支付渠道名称', 

    `mo_ticket_count`       BIGINT  COMMENT '主单已支付票量',   
    `mo_amount`             BIGINT  COMMENT '主单已支付订单金额', 

    `no_mo_ticket_count`    BIGINT  COMMENT '子单已支付票量',   
    `no_mo_amount`          BIGINT  COMMENT '子单已支付订单金额',   

    `mo_group_1`            BIGINT  COMMENT '主单同行人数1人', 
    `mo_group_2`            BIGINT  COMMENT '主单同行人数2到4', 
    `mo_group_3`            BIGINT  COMMENT '主单同行人数5到9', 
    `mo_group_4`            BIGINT  COMMENT '主单同行人数10人及以上', 

    `no_mo_group_1`         BIGINT  COMMENT '子单同行人数1人', 
    `no_mo_group_2`         BIGINT  COMMENT '子单同行人数2到4', 
    `no_mo_group_3`         BIGINT  COMMENT '子单同行人数5到9', 
    `no_mo_group_4`         BIGINT  COMMENT '子单同行人数10人及以上'

)COMMENT '景区每年门票归属地_支付渠道_同行人数指标表(按取票人)'
PARTITIONED BY (`year` INT COMMENT '汇总年例如2020')
STORED AS ORC;


INSERT OVERWRITE TABLE ads_yearly_fellow_group_d_i PARTITION(`year`)
SELECT
	`land_id`,
	`sid`,
    `p_type`,
    `pid`,
    `ticket_id`,

    `province`,
    `pay_channel_id`,
    MAX(`pay_channel_name`)     AS `pay_channel_name`,

    SUM(`mo_ticket_count`)      AS `mo_ticket_count`,
    SUM(`mo_amount`)            AS `mo_amount`,

    SUM(`no_mo_ticket_count`)   AS `no_mo_ticket_count`,
    SUM(`no_mo_amount`)         AS `no_mo_amount`,
    
    SUM(`mo_group_1`)           AS `mo_group_1`, 
    SUM(`mo_group_2`)           AS `mo_group_2`, 
    SUM(`mo_group_3`)           AS `mo_group_3`, 
    SUM(`mo_group_4`)           AS `mo_group_4`, 

    SUM(`no_mo_group_1`)        AS `no_mo_group_1`, 
    SUM(`no_mo_group_2`)        AS `no_mo_group_2`, 
    SUM(`no_mo_group_3`)        AS `no_mo_group_3`, 
    SUM(`no_mo_group_4`)        AS `no_mo_group_4`,
    `year`
FROM ads_monthly_fellow_group_d_i
WHERE SUBSTR(`month`, 0, 4) = SUBSTR('${ds}', 0, 4)
GROUP BY
    `land_id`,
    `sid`,
    `p_type`,
    `pid`,
    `ticket_id`,				 
    `province`,
    `pay_channel_id`,
    `year`
    ;