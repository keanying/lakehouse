-- name ads_daily_fellow_group_d_i
-- type Spark SQL
-- author wanghaiyang@12301.cc
-- create time 2023-05-18 15:01:27
-- desc 景区每日门票归属地_支付渠道_同行人数指标表(按取票人)

SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;

CREATE TABLE IF NOT EXISTS ads_daily_fellow_group_d_i(
    `land_id`		        INT		COMMENT '景区ID',
    `sid`		            INT		COMMENT '原始供应商id',
    `p_type`                STRING  COMMENT '景区类型：A景区B线路C酒店F套票',
    `pid`                   INT     COMMENT '产品id',
    `ticket_id`             INT     COMMENT '票ID',

    `province`			    STRING	COMMENT '统计省',
    `pay_channel_id`        INT     COMMENT '票支付渠道', 
    `pay_channel_name`      STRING  COMMENT '票支付渠道名称', 

    `mo_ticket_count`       BIGINT  COMMENT '主单已支付票量',   
    `mo_amount`             BIGINT  COMMENT '主单已支付订单金额', 

    `no_mo_ticket_count`    BIGINT  COMMENT '子单已支付票量',   
    `no_mo_amount`          BIGINT  COMMENT '子单已支付订单金额',   

    `mo_group_1`            BIGINT  COMMENT '主单同行人数1人', 
    `mo_group_2`            BIGINT  COMMENT '主单同行人数2到4', 
    `mo_group_3`            BIGINT  COMMENT '主单同行人数5到9', 
    `mo_group_4`            BIGINT  COMMENT '主单同行人数10人及以上', 

    `no_mo_group_1`         BIGINT  COMMENT '子单同行人数1人', 
    `no_mo_group_2`         BIGINT  COMMENT '子单同行人数2到4', 
    `no_mo_group_3`         BIGINT  COMMENT '子单同行人数5到9', 
    `no_mo_group_4`         BIGINT  COMMENT '子单同行人数10人及以上', 

  	`year` 				    INT	    COMMENT '年',
  	`month` 			    INT	    COMMENT '月',
  	`week` 				    INT	    COMMENT '年周'
)COMMENT '景区每日门票归属地_支付渠道_同行人数指标表(按取票人)'
PARTITIONED BY (`fulldate`  INT   	COMMENT '全日期')
STORED AS ORC;


INSERT OVERWRITE TABLE ads_daily_fellow_group_d_i PARTITION(fulldate)
SELECT
	`order`.lid                                                             AS `land_id`,
	`order`.sid                                                             AS `sid`,
    `order`.p_type                                                          AS `p_type`,
    `order`.pid                                                             AS `pid`,
    `order`.tid                                                             AS `ticket_id`,

    `province`                                                              AS `province`,
    NVL(`dict`.pay_channel_mapping_id, -1)                                  AS `pay_channel_id`,
    NVL(`dict`.pay_channel_mapping_name, '其他')                            AS `pay_channel_name`,

    SUM(IF(order_type!='套票子票', pay_num, 0))                             AS `mo_ticket_count`,
    SUM(IF(order_type!='套票子票', amount, 0))                              AS `mo_amount`,

    SUM(IF(order_type='套票子票', pay_num, 0))                              AS `no_mo_ticket_count`,
    SUM(IF(order_type='套票子票', amount, 0))                               AS `no_mo_amount`,
    
    SUM(IF(order_type!='套票子票' and person_num_range="1人", 1, 0))        AS `mo_group_1`, 
    SUM(IF(order_type!='套票子票' and person_num_range="2~4人", 1, 0))      AS `mo_group_2`, 
    SUM(IF(order_type!='套票子票' and person_num_range="5~9人", 1, 0))      AS `mo_group_3`, 
    SUM(IF(order_type!='套票子票' and person_num_range="10人及以上", 1, 0))  AS `mo_group_4`, 

    SUM(IF(order_type='套票子票' and person_num_range="1人", 1, 0))         AS `no_mo_group_1`, 
    SUM(IF(order_type='套票子票' and person_num_range="2~4人", 1, 0))       AS `no_mo_group_2`, 
    SUM(IF(order_type='套票子票' and person_num_range="5~9人", 1, 0))       AS `no_mo_group_3`, 
    SUM(IF(order_type='套票子票' and person_num_range="10人及以上", 1, 0))   AS `no_mo_group_4`, 

    YEAR(`date`)                                                            AS `year`,
    YEAR(`date`) * 100 + MONTH(`date`)                                      AS `month`,
    INT(dim_isoweek.isoweek)                                                AS `week`,
    INT(`order`.orderdate)                                                  AS `fulldate`
FROM 
(
    SELECT
        orderdate,
        lid,
        sellerid                                                    AS `sid`,
        NVL(product_type,'A')                                       AS `p_type`,
        pid                                                         AS `pid`,
        tid,
        NVL(ticket_taker_province,'未知')                           AS `province`,
        order_type,
        CASE
            WHEN pay_num > 0 AND pay_num <= 1 THEN "1人" 
            WHEN pay_num > 1 AND pay_num <= 4 THEN "2~4人"
            WHEN pay_num > 4 AND pay_num <= 9 THEN "5~9人" 
            WHEN pay_num > 9 THEN "10人及以上" 
        END                                                         AS `person_num_range`,
        NVL(`paymode`, -1)                                          AS `pay_channel_id`,
        `pay_num`                                                   AS `pay_num`,
        sale_price * pay_num                                        AS `amount`
    FROM dwd_split_d_i splitTab
    WHERE orderdate = "${ds}" 
      AND apply_did = sellerid
      AND pay_num > 0
      AND tid != -1
) AS `order`
LEFT JOIN dim_pay_channel_o_f `dict`
ON `order`.pay_channel_id = `dict`.pay_channel_id
LEFT JOIN dim_date_isoweek_o_f AS dim_isoweek 
ON `order`.orderdate = dim_isoweek.`fulldate`
GROUP BY
    `order`.lid,
    `order`.sid,
    `order`.p_type,
    `order`.pid,
    `order`.tid,
	`order`.orderdate,					 
    dim_isoweek.isoweek,
    dim_isoweek.date,
    `province`,
    NVL(`dict`.pay_channel_mapping_id, -1),
    NVL(`dict`.pay_channel_mapping_name, '其他');