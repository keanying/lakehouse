-- name ads_monthly_scenic_province_fellow_group_d_i
-- type Spark SQL
-- author wanghaiyang@12301.cc
-- create time 2024-10-09 19:33:30
-- desc 景区每月省份同行人数指标表(按取票人)

SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;

CREATE TABLE IF NOT EXISTS ads_monthly_scenic_province_fellow_group_remain_d_i(
    `land_id`		    INT		COMMENT '景区ID',
    `land_name`			STRING	COMMENT '景区名称',
    `sid`		        INT		COMMENT '原始供应商id',
    `p_type`            STRING  COMMENT '景区类型：A景区B线路C酒店F套票',
    `province`			STRING	COMMENT '统计省',
   
    `mo_group_1`        BIGINT  COMMENT '主单同行人数1人', 
    `mo_group_2`        BIGINT  COMMENT '主单同行人数2到4', 
    `mo_group_3`        BIGINT  COMMENT '主单同行人数5到9', 
    `mo_group_4`        BIGINT  COMMENT '主单同行人数10人及以上', 

    `no_mo_group_1`     BIGINT  COMMENT '子单同行人数1人', 
    `no_mo_group_2`     BIGINT  COMMENT '子单同行人数2到4', 
    `no_mo_group_3`     BIGINT  COMMENT '子单同行人数5到9', 
    `no_mo_group_4`     BIGINT  COMMENT '子单同行人数10人及以上', 

  	`year` 				INT	    COMMENT '年'
)COMMENT '景区每月省份同行人数指标表(按取票人)'
PARTITIONED BY (`month`  INT   	COMMENT '年月')
STORED AS ORC;


INSERT OVERWRITE TABLE ads_monthly_scenic_province_fellow_group_remain_d_i PARTITION(month)
SELECT
	land_id                 AS `land_id`,
	land_name               AS `land_name`,
	sourceTab.sid           AS `sid`,
    p_type                  AS `p_type`,
    province                AS `province`,
    mo_group_1              AS `mo_group_1`, 
    mo_group_2              AS `mo_group_2`, 
    mo_group_3              AS `mo_group_3`, 
    mo_group_4              AS `mo_group_4`, 

    no_mo_group_1           AS `no_mo_group_1`, 
    no_mo_group_2           AS `no_mo_group_2`, 
    no_mo_group_3           AS `no_mo_group_3`, 
    no_mo_group_4           AS `no_mo_group_4`, 
    `year`                  AS `year`,
    `month`                 AS `month`
FROM ads_monthly_scenic_province_fellow_group_d_i sourceTab
JOIN (
    SELECT sid
    FROM dim_sid_white_list_d_f 
    WHERE pt = DATE_FORMAT(DATE_SUB(CURRENT_DATE(), 1),"yyyyMMdd")
) whiteTab
ON sourceTab.sid = whiteTab.sid
WHERE month = SUBSTR('${ds}', 0, 6);