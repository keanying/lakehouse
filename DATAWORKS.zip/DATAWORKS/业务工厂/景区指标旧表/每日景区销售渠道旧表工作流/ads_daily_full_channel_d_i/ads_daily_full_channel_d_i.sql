-- name ads_daily_full_channel_d_i
-- type Spark SQL
-- author liangleichen@12301.cc
-- create time 2023-09-12 19:40:14
-- desc 全销售渠道指标表

SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;

CREATE TABLE IF NOT EXISTS `ads_daily_full_channel_d_i`(
    `year`                      int     COMMENT '年',
    `month`                     int     COMMENT '月',
    `week`                      int     COMMENT '年周',

    `sid`                       int     COMMENT '原始供应商id',
    `land_id`                   int     COMMENT '景区ID',
    `land_name`                 string  COMMENT '景区名称',
    `p_type`                    string  COMMENT '景区类型：A景区B线路C酒店F套票',
    `pid`                       int     COMMENT '产品id',
    `ticket_id`                 int     COMMENT '票ID',
    `ticket_fullname`           string  COMMENT '票名称',
    `channel_class1_id`         int     COMMENT '一级渠道ID',
    `channel_class1_name`       string  COMMENT '一级渠道名称',
    `channel_class2_id`         int     COMMENT '二级渠道ID',
    `channel_class2_name`       string  COMMENT '二级渠道名称',

    `order_count`               bigint  COMMENT '已支付订单量',
    `ticket_count`              bigint  COMMENT '已支付票量',
    `amount`                    bigint  COMMENT '已支付订单金额',

    `mo_order_count`            bigint  COMMENT '主单已支付订单量',
    `mo_ticket_count`           bigint  COMMENT '主单已支付票量',
    `mo_amount`                 bigint  COMMENT '主单已支付订单金额',

    `no_mo_order_count`         bigint  COMMENT '子单已支付订单量',
    `no_mo_ticket_count`        bigint  COMMENT '子单已支付票量',
    `no_mo_amount`              bigint  COMMENT '子单已支付订单金额'
 )comment'全销售渠道指标表'partitioned by(
    fulldate int COMMENT '全日期'
 )STORED AS ORC;

INSERT OVERWRITE TABLE ads_daily_full_channel_d_i PARTITION(fulldate)
SELECT 
    `year`                                              AS  `year`,
    `month`                                             AS  `month`,
    `week`                                              AS  `week`,

    sid                                                 AS  sid,
    land_id                                             AS  land_id,
    MAX(land_name)                                      AS  land_name,
    p_type                                              AS  p_type,
    pid                                                 AS  pid,
    ticket_id                                           AS  ticket_id,
    MAX(ticket_fullname)                                AS  ticket_fullname,
    channel_class1_id                                   AS  channel_class1_id,
    MAX(channel_class1_name)                            AS  channel_class1_name,
    channel_class2_id                                   AS  channel_class2_id,
    MAX(channel_class2_name)                            AS  channel_class2_name,

    SUM(order_count)                                    AS  order_count,       
    SUM(ticket_count)                                   AS  ticket_count,
    SUM(amount)                                         AS  amount,

    SUM(mo_order_count)                                 AS  mo_order_count,       
    SUM(mo_ticket_count)                                AS  mo_ticket_count,
    SUM(mo_amount)                                      AS  mo_amount,

    SUM(no_mo_order_count)                              AS  no_mo_order_num,       
    SUM(no_mo_ticket_count)                             AS  no_mo_order_ticket,
    SUM(no_mo_amount)                                   AS  no_mo_amount,
    fulldate

FROM ads_daily_ticket_full_channel_d_i
WHERE fulldate = '${ds}'
GROUP BY 
    sid,
    land_id,
    p_type,
    pid,
    ticket_id,
    channel_class1_id,
    channel_class2_id,
    `year`,
    `month`,
    `week`,
    `fulldate`;