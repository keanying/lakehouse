-- name ads_yearly_scenic_ticket_channel_d_i
-- type Spark SQL
-- author wanghaiyang@12301.cc
-- create time 2024-10-09 19:36:35
-- desc 景区每年门票渠道统计指标表

SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;

CREATE TABLE IF NOT EXISTS ads_yearly_scenic_ticket_channel_d_i(
	`land_id` 			        INT 		COMMENT '景区ID',
	`land_name` 		        STRING 		COMMENT '景区名称',
    `p_type`                    STRING      COMMENT '景区类型：A景区B线路C酒店F套票',
    `pid`                       INT         COMMENT '产品id',
    `ticket_id`                 INT         COMMENT '票ID',
    `sid`                       INT         COMMENT '原始供应商id',

    `channel_id`                INT         COMMENT '一级渠道ID',
    `channel_name`              STRING      COMMENT '一级渠道名称',

	`mo_order_count`            BIGINT		COMMENT '主单订单数',
	`mo_ticket_count`           BIGINT	    COMMENT '主单票数',
	`mo_amount`                 BIGINT 		COMMENT '主单金额',
	`mo_ticket_avg_price`       BIGINT 		COMMENT '主单客单价',

    `no_mo_order_count`         BIGINT		COMMENT '子单订单数',
	`no_mo_ticket_count`        BIGINT	    COMMENT '子单票数',
	`no_mo_amount`              BIGINT 		COMMENT '子单金额',
	`no_mo_ticket_avg_price`    BIGINT 		COMMENT '子单客单价'
)COMMENT '景区每年门票渠道统计指标表'
PARTITIONED BY (`year`  INT   	COMMENT '年')
STORED AS ORC;


INSERT OVERWRITE TABLE ads_yearly_scenic_ticket_channel_d_i PARTITION(year)
SELECT
    `land_id`                                               AS `land_id`,
	MAX(`land_name`)                                        AS `land_name`,
    `p_type`                                                AS `p_type`,
    `pid`                                                   AS `pid`,
    `ticket_id`                                             AS `ticket_id`,
    `sid`                                                   AS `sid`,
    `channel_id`                                            AS `channel_id`,
    MAX(`channel_name`)                                     AS `channel_name`,
	SUM(mo_order_count)			                            AS `mo_order_count`,
    SUM(mo_ticket_count)                                    AS `mo_ticket_count`,
    SUM(mo_amount)                                          AS `mo_amount`,
    ROUND(NVL(SUM(mo_amount) / SUM(mo_ticket_count) , 0))   AS `mo_ticket_avg_price`,

    SUM(no_mo_order_count)			                        AS `no_mo_order_count`,
    SUM(no_mo_ticket_count)                                 AS `no_mo_ticket_count`,
    SUM(no_mo_amount)                                       AS `no_mo_amount`,
    ROUND(NVL(SUM(no_mo_amount) / SUM(no_mo_ticket_count) , 0))       
                                                            AS `no_mo_ticket_avg_price`,
    `year`
FROM ads_monthly_scenic_ticket_channel_d_i
WHERE SUBSTR(`month`, 0, 4) = SUBSTR('${ds}', 0, 4)
GROUP BY 
    `land_id`,
    `p_type`,
    `pid`,
    `ticket_id`,
    `sid`,
    `channel_id`,
    `year`;
