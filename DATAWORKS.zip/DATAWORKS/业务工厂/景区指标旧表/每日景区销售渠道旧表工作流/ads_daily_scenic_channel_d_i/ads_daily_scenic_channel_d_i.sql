-- name ads_daily_scenic_channel_d_i
-- type Spark SQL
-- author liangleichen@12301.cc
-- create time 2023-05-17 17:24:50
-- desc 景区每日渠道统计

SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;

CREATE TABLE IF NOT EXISTS ads_daily_scenic_channel_d_i(
    `year` 				        INT 		COMMENT '年',
	`month` 			        INT		    COMMENT '月',
	`week` 				        INT 		COMMENT '年周',

	`land_id` 			        INT 		COMMENT '景区ID',
	`land_name` 		        STRING 		COMMENT '景区名称',
    `p_type`                    STRING      COMMENT '景区类型：A景区B线路C酒店F套票',
    `sid`                       INT         COMMENT '原始供应商id',

    `channel_id`                INT         COMMENT '一级渠道ID',
    `channel_name`              STRING      COMMENT '一级渠道名称',

    `order_count`               INT			COMMENT '订单数',
	`ticket_count`              BIGINT	    COMMENT '票数',
	`amount`                    BIGINT 		COMMENT '金额',
	`ticket_avg_price`          BIGINT 		COMMENT '客单价',

	`mo_order_count`            INT			COMMENT '主单订单数',
	`mo_ticket_count`           BIGINT	    COMMENT '主单票数',
	`mo_amount`                 BIGINT 		COMMENT '主单金额',
	`mo_ticket_avg_price`       BIGINT 		COMMENT '主单客单价',

    `no_mo_order_count`         INT			COMMENT '子单订单数',
	`no_mo_ticket_count`        BIGINT	    COMMENT '子单票数',
	`no_mo_amount`              BIGINT 		COMMENT '子单金额',
	`no_mo_ticket_avg_price`    BIGINT 		COMMENT '子单客单价'

)COMMENT '景区每日渠道统计'
PARTITIONED BY (`fulldate`	INT		COMMENT '全日期')
STORED AS ORC;


INSERT OVERWRITE TABLE ads_daily_scenic_channel_d_i PARTITION(fulldate)
SELECT
    `year`                          AS `year`,
    `month`                         AS `month`,
    `week`                          AS `week`,

    land_id	                        AS `land_id`,
    MAX(land_name)                  AS `land_name`,
    p_type                          AS `p_type`,
    sid	                            AS `sid`,

    channel_id                      AS `channel_id`,
    MAX(channel_name)               AS `channel_name`,

    SUM(mo_order_count + no_mo_order_count)		        
                                    AS `order_count`,
    SUM(mo_ticket_count + no_mo_ticket_count)            
                                    AS `ticket_count`,
    SUM(mo_amount  + no_mo_amount)  AS `amount`,
    ROUND(NVL(SUM(mo_amount  + no_mo_amount) / SUM(mo_ticket_count + no_mo_ticket_count) , 0))       
                                    AS `ticket_avg_price`,

	SUM(mo_order_count)		        AS `mo_order_count`,
    SUM(mo_ticket_count)            AS `mo_ticket_count`,
    SUM(mo_amount)                  AS `mo_amount`,
    ROUND(NVL(SUM(mo_amount) / SUM(mo_ticket_count) , 0))       
                                    AS `mo_ticket_avg_price`,

    SUM(no_mo_order_count)		    AS `no_mo_order_count`,
    SUM(no_mo_ticket_count)         AS `no_mo_ticket_count`,
    SUM(no_mo_amount)               AS `no_mo_amount`,
    ROUND(NVL(SUM(no_mo_amount) / SUM(no_mo_ticket_count) , 0))       
                                    AS `no_mo_ticket_avg_price`,
    fulldate
FROM ads_daily_scenic_ticket_channel_d_i
WHERE `fulldate`='${ds}'
GROUP BY
    land_id,
    p_type,
    sid,
    `year`,
    `month`,
    `week`,
    fulldate,
    channel_id;

