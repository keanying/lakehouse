-- name ads_daily_ticket_full_channel_d_i
-- type Spark SQL
-- author wanghaiyang@12301.cc
-- create time 2025-03-03 10:40:14
-- desc 一二级渠道全维度指标表

SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;

CREATE TABLE IF NOT EXISTS `ads_daily_ticket_full_channel_d_i`(
    `year`                      int     COMMENT '年',
    `month`                     int     COMMENT '月',
    `week`                      int     COMMENT '年周',

    `sid`                       int     COMMENT '原始供应商id',
    `land_id`                   int     COMMENT '景区ID',
    `land_name`                 string  COMMENT '景区名称',
    `p_type`                    string  COMMENT '景区类型：A景区B线路C酒店F套票',
    `pid`                       int     COMMENT '产品id',
    `ticket_id`                 int     COMMENT '票ID',
    `ticket_fullname`           string  COMMENT '票名称',
    `channel_class1_id`         int     COMMENT '一级渠道ID',
    `channel_class1_name`       string  COMMENT '一级渠道名称',
    `channel_class2_id`         int     COMMENT '二级渠道ID',
    `channel_class2_name`       string  COMMENT '二级渠道名称',

    `province`                  string  COMMENT '统计省',

    `order_count`               bigint  COMMENT '已支付订单量',
    `ticket_count`              bigint  COMMENT '已支付票量',
    `amount`                    bigint  COMMENT '已支付订单金额',

    `mo_order_count`            bigint  COMMENT '主单已支付订单量',
    `mo_ticket_count`           bigint  COMMENT '主单已支付票量',
    `mo_amount`                 bigint  COMMENT '主单已支付订单金额',

    `no_mo_order_count`         bigint  COMMENT '子单已支付订单量',
    `no_mo_ticket_count`        bigint  COMMENT '子单已支付票量',
    `no_mo_amount`              bigint  COMMENT '子单已支付订单金额'
 )comment'全销售渠道指标表'partitioned by(
    fulldate int COMMENT '全日期'
 )STORED AS ORC;

INSERT OVERWRITE TABLE ads_daily_ticket_full_channel_d_i PARTITION(fulldate)
SELECT
    YEAR(`date`)                                                    AS `year`,
    YEAR(`date`) * 100 + MONTH(`date`)                              AS `month`,
    INT(dim_isoweek.isoweek)                                        AS `week`,
    sid                                                             AS  sid,
    land_id                                                         AS  land_id,
    land_name                                                       AS  land_name,
    p_type                                                          AS  p_type,
    pid                                                             AS  pid,
    ticket_id                                                       AS  ticket_id,
    ticket_fullname                                                 AS  ticket_fullname,
    channel_class1_id                                               AS  channel_class1_id,
    channel_class1_name                                             AS  channel_class1_name,
    channel_class2_id                                               AS  channel_class2_id,
    channel_class2_name                                             AS  channel_class2_name,
    province                                                        AS  province,
    order_count                                                     AS  order_count,       
    ticket_count                                                    AS  ticket_count,
    amount                                                          AS  amount,

    mo_order_count                                                  AS  mo_order_count,       
    mo_ticket_count                                                 AS  mo_ticket_count,
    mo_amount                                                       AS  mo_amount,

    no_mo_order_count                                               AS  no_mo_order_count,       
    no_mo_ticket_count                                              AS  no_mo_ticket_count,
    no_mo_amount                                                    AS  no_mo_amount,
    INT(dim_isoweek.fulldate)                                       AS  fulldate

FROM(
    SELECT 
        orderdate,
        sellerid                                                        AS  sid,
        lid                                                             AS  land_id,
        NVL(product_type,'A')                                           AS  p_type,
        pid                                                             AS  pid,
        tid                                                             AS  ticket_id,
        channel_class1_id                                               AS  channel_class1_id,
        MAX(channel_class1_name)                                        AS  channel_class1_name,
        channel_class2_id                                               AS  channel_class2_id,
        MAX(channel_class2_name)                                        AS  channel_class2_name,
        ticket_taker_province                                           AS  province,
        COUNT(1)                                                        AS `order_count`,
        SUM(pay_num)                                                    AS `ticket_count`,
        SUM(sale_price * pay_num)                                       AS `amount`,

        SUM(IF(order_type!='套票子票', 1, 0))                           AS `mo_order_count`,
        SUM(IF(order_type!='套票子票', pay_num, 0))                     AS `mo_ticket_count`,
        SUM(IF(order_type!='套票子票', sale_price * pay_num, 0))        AS `mo_amount`,

        SUM(IF(order_type='套票子票', 1, 0))                            AS `no_mo_order_count`,
        SUM(IF(order_type='套票子票', pay_num, 0))                      AS `no_mo_ticket_count`,
        SUM(IF(order_type='套票子票', sale_price * pay_num, 0))         AS `no_mo_amount`

    FROM dwd_split_d_i
    WHERE orderdate = '${ds}'
        AND pay_num > 0
        AND tid != -1
        AND apply_did = sellerid
    GROUP BY 
        orderdate,
        sellerid,
        lid,
        NVL(product_type,'A'),
        pid,
        tid,
        channel_class1_id,
        channel_class2_id,
        ticket_taker_province
) `order`
JOIN(
    SELECT id, title as land_name
    FROM ods_land_d_f
    WHERE pt = FROM_UNIXTIME(UNIX_TIMESTAMP(DATE_SUB(CURRENT_DATE, 1)), 'yyyyMMdd')
) `land`
ON `order`.land_id = `land`.id
JOIN(
    SELECT id, title as ticket_fullname
    FROM ods_ticket_d_f
    WHERE pt = FROM_UNIXTIME(UNIX_TIMESTAMP(DATE_SUB(CURRENT_DATE, 1)), 'yyyyMMdd')
) `ticket`
ON `order`.ticket_id = `ticket`.id
LEFT JOIN dim_date_isoweek_o_f AS dim_isoweek 
ON `order`.orderdate = dim_isoweek.`fulldate`;