-- name ads_month_scenic_province_channel_d_i
-- type Spark SQL
-- author wanghaiyang@12301.cc
-- create time 2024-09-26 11:29:18
-- desc 景区每月省份支付渠道统计表

SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;

CREATE TABLE IF NOT EXISTS ads_monthly_scenic_province_channel_d_i(
    `land_id`		    INT		COMMENT '景区ID',
    `land_name`			STRING	COMMENT '景区名称',
    `sid`		        INT		COMMENT '原始供应商id',
    `p_type`            STRING  COMMENT '景区类型：A景区B线路C酒店F套票',

    `province`			STRING	COMMENT '统计省',
    `pay_channel_id`    INT     COMMENT '票支付渠道', 
    `pay_channel_name`  STRING  COMMENT '票支付渠道名称', 

    `mo_ticket_count`       BIGINT  COMMENT '主单已支付票量',   
    `mo_amount`             BIGINT  COMMENT '主单已支付订单金额',   

    `no_mo_ticket_count`    BIGINT  COMMENT '子单已支付票量',   
    `no_mo_amount`          BIGINT  COMMENT '子单已支付订单金额',   

  	`year` 				INT	    COMMENT '年'
)COMMENT '景区每月省份支付渠道统计表'
PARTITIONED BY (`month`  INT   	COMMENT '年月')
STORED AS ORC;


INSERT OVERWRITE TABLE ads_monthly_scenic_province_channel_d_i PARTITION(`month`)
SELECT
    land_id                 AS  land_id,
    MAX(land_name)          AS  land_name,
    sid                     AS  sid,
    p_type                  AS  p_type,
    province                AS  province,
    pay_channel_id          AS  pay_channel_id,
    MAX(pay_channel_name)   AS  pay_channel_name,
    SUM(mo_ticket_count)    AS `mo_ticket_count`,
    SUM(mo_amount)          AS `mo_amount`,
    SUM(no_mo_ticket_count) AS `no_mo_ticket_count`,
    SUM(no_mo_amount)       AS `no_mo_amount`,
    year                    AS  year,
    `month`
FROM ads_daily_scenic_province_channel_d_i
WHERE SUBSTR(`fulldate`, 0, 6) = SUBSTR('${ds}', 0, 6)
GROUP BY 
    land_id,
    sid,
    p_type,
    province,
    pay_channel_id,
    year,
    month;