-- name ads_daily_scenic_ticket_province_channel_d_i
-- type Spark SQL
-- author liangleichen@12301.cc
-- create time 2023-05-17 18:58:01
-- desc 景区每日门票省份支付渠道统计指标表(按取票人)

SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;

CREATE TABLE IF NOT EXISTS ads_daily_scenic_ticket_province_channel_d_i(
    `land_id`		        INT		COMMENT '景区ID',
    `land_name`			    STRING	COMMENT '景区名称',
    `sid`		            INT		COMMENT '原始供应商id',
    `p_type`                STRING  COMMENT '景区类型：A景区B线路C酒店F套票',
    `pid`                   INT     COMMENT '产品id',
    `ticket_id`             INT     COMMENT '票ID',

    `province`			    STRING	COMMENT '统计省',
    `pay_channel_id`        INT     COMMENT '票支付渠道', 
    `pay_channel_name`      STRING  COMMENT '票支付渠道名称', 

    `mo_ticket_count`       BIGINT  COMMENT '主单已支付票量',   
    `mo_amount`             BIGINT  COMMENT '主单已支付订单金额', 

    `no_mo_ticket_count`    BIGINT  COMMENT '子单已支付票量',   
    `no_mo_amount`          BIGINT  COMMENT '子单已支付订单金额',   

  	`year`                  INT	    COMMENT '年',
  	`month` 			    INT	    COMMENT '月',
  	`week` 				    INT	    COMMENT '年周'
)COMMENT '景区每日门票省份支付渠道统计指标表(按取票人)'
PARTITIONED BY (`fulldate`  INT   	COMMENT '全日期')
STORED AS ORC;


INSERT OVERWRITE TABLE ads_daily_scenic_ticket_province_channel_d_i PARTITION(fulldate)
SELECT
    `order`.lid	                                                        AS `land_id`,
    MAX(landTab.land_name)                                              AS `land_name`,
    `order`.apply_did                                                   AS `sid`,
    `order`.p_type                                                      AS `p_type`,
    `order`.pid                                                         AS `pid`,
    `order`.tid                                                         AS `ticket_id`,

    province                                                            AS `province`,
    NVL(`dict`.pay_channel_mapping_id, -1)                              AS `pay_channel_id`,
    NVL(`dict`.pay_channel_mapping_name, '其他')                        AS `pay_channel_name`,

    SUM(IF(order_type!='套票子票', pay_num, 0))                         AS `mo_ticket_count`,
    SUM(IF(order_type!='套票子票', order_pay_amount, 0))                AS `mo_amount`,

    SUM(IF(order_type='套票子票', pay_num, 0))                          AS `no_mo_ticket_count`,
    SUM(IF(order_type='套票子票', order_pay_amount, 0))                 AS `no_mo_amount`,

    YEAR(TO_DATE(`date`))                                               AS `year`,
    YEAR(TO_DATE(`date`)) * 100 + MONTH(TO_DATE(`date`))                AS `month`,
    INT(dim_isoweek.isoweek)                                            AS `week`,
    INT(orderdate)                                                      AS `fulldate`
FROM 
(
    SELECT 
        lid,
        apply_did,
        product_type                                AS  p_type,
        pid,
        tid,
        orderdate,
        pay_num,
        sale_price * pay_num                        AS  order_pay_amount,
        NVL(`paymode`, -1)                          AS  pay_channel_id,
        order_type,
        NVL(ticket_taker_province, '未知')          AS  province
    FROM dwd_split_d_i
    WHERE orderdate = '${ds}'
        AND pay_num > 0
        AND tid != -1
        AND apply_did = sellerid
) AS `order`
LEFT JOIN dim_pay_channel_o_f `dict`
ON `order`.pay_channel_id = `dict`.pay_channel_id
LEFT JOIN dim_date_isoweek_o_f AS dim_isoweek 
ON `order`.orderdate = dim_isoweek.`fulldate`
LEFT JOIN (
    SELECT id, title as land_name
    FROM ods_land_d_f
    WHERE pt = FROM_UNIXTIME(UNIX_TIMESTAMP(DATE_SUB(CURRENT_DATE, 1)), 'yyyyMMdd')
)landTab
ON `order`.lid = landTab.id
GROUP BY
    `order`.lid,
    `order`.apply_did,
    `order`.p_type,
    `order`.pid,
    `order`.tid,
    dim_isoweek.isoweek,
    dim_isoweek.`date`,
	`order`.orderdate,			
    NVL(`dict`.pay_channel_mapping_id, -1),
    NVL(`dict`.pay_channel_mapping_name, '其他'),
    province
    ;