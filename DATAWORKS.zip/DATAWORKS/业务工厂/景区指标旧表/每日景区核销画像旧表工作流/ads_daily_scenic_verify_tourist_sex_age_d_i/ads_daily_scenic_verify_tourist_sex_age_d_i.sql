-- name ads_daily_scenic_verify_tourist_sex_age_i
-- type Spark SQL
-- author liangleichen@12301.cc
-- create time 2024-11-14 10:06:11
-- desc 每日-核销-性别年龄-主子单人数指标表

SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;

CREATE TABLE IF NOT EXISTS ads_daily_scenic_verify_tourist_sex_age_d_i(
    `land_id`		                INT	    COMMENT '景区ID',
    `land_name`		                STRING	COMMENT '景区名称',
    `sid`                           INT     COMMENT '原始供应商id',
    `p_type`                        STRING  COMMENT '景区类型：A景区B线路C酒店F套票',

    `mo_male_age_0to7`              INT     COMMENT '主单,男性且年龄范围0-7,只包含首次核销',
    `mo_male_age_8to17`             INT     COMMENT '主单,男性且年龄范围8-17,只包含首次核销',
    `mo_male_age_18to27`            INT     COMMENT '主单,男性且年龄范围18-27,只包含首次核销',
    `mo_male_age_28to40`            INT     COMMENT '主单,男性且年龄范围28-40,只包含首次核销',
    `mo_male_age_41to60`            INT     COMMENT '主单,男性且年龄范围41-60,只包含首次核销', 
    `mo_male_age_61plus`            INT     COMMENT '主单,男性且年龄范围>60,只包含首次核销', 
    `mo_female_age_0to7`            INT     COMMENT '主单,女性且年龄范围0-7,只包含首次核销',
    `mo_female_age_8to17`           INT     COMMENT '主单,女性且年龄范围8-17,只包含首次核销',
    `mo_female_age_18to27`          INT     COMMENT '主单,女性且年龄范围18-27,只包含首次核销', 
    `mo_female_age_28to40`          INT     COMMENT '主单,女性且年龄范围28-40,只包含首次核销',
    `mo_female_age_41to60`          INT     COMMENT '主单,女性且年龄范围41-60,只包含首次核销',
    `mo_female_age_61plus`          INT     COMMENT '主单,女性且年龄范围>60,只包含首次核销',
    `mo_unknown`                    INT     COMMENT '主单,性别年龄未知,只包含首次核销',
    `mo_total`                      INT     COMMENT '主单,总人数,只包含首次核销',

    `mo_male_age_0to7_all`          INT     COMMENT '主单,男性且年龄范围0-7,包含首次核销和重复入园',   
    `mo_male_age_8to17_all`         INT     COMMENT '主单,男性且年龄范围8-17,包含首次核销和重复入园', 
    `mo_male_age_18to27_all`        INT     COMMENT '主单,男性且年龄范围18-27,包含首次核销和重复入园', 
    `mo_male_age_28to40_all`        INT     COMMENT '主单,男性且年龄范围28-40,包含首次核销和重复入园', 
    `mo_male_age_41to60_all`        INT     COMMENT '主单,男性且年龄范围41-60,包含首次核销和重复入园', 
    `mo_male_age_61plus_all`        INT     COMMENT '主单,男性且年龄范围>60,包含首次核销和重复入园',  
    `mo_female_age_0to7_all`        INT     COMMENT '主单,女性且年龄范围0-7,包含首次核销和重复入园', 
    `mo_female_age_8to17_all`       INT     COMMENT '主单,女性且年龄范围8-17,包含首次核销和重复入园', 
    `mo_female_age_18to27_all`      INT     COMMENT '主单,女性且年龄范围18-27,包含首次核销和重复入园', 
    `mo_female_age_28to40_all`      INT     COMMENT '主单,女性且年龄范围28-40,包含首次核销和重复入园', 
    `mo_female_age_41to60_all`      INT     COMMENT '主单,女性且年龄范围41-60,包含首次核销和重复入园', 
    `mo_female_age_61plus_all`      INT     COMMENT '主单,女性且年龄范围>60,包含首次核销和重复入园', 
    `mo_unknown_all`                INT     COMMENT '主单,性别年龄未知,包含首次核销和重复入园',
    `mo_total_all`                  INT     COMMENT '主单,总人数,包含首次核销和重复入园',

    `no_mo_male_age_0to7`           INT     COMMENT '子单,男性且年龄范围0-7,只包含首次核销',
    `no_mo_male_age_8to17`          INT     COMMENT '子单,男性且年龄范围8-17,只包含首次核销',
    `no_mo_male_age_18to27`         INT     COMMENT '子单,男性且年龄范围18-27,只包含首次核销',
    `no_mo_male_age_28to40`         INT     COMMENT '子单,男性且年龄范围28-40,只包含首次核销',
    `no_mo_male_age_41to60`         INT     COMMENT '子单,男性且年龄范围41-60,只包含首次核销', 
    `no_mo_male_age_61plus`         INT     COMMENT '子单,男性且年龄范围>60,只包含首次核销', 
    `no_mo_female_age_0to7`         INT     COMMENT '子单,女性且年龄范围0-7,只包含首次核销',
    `no_mo_female_age_8to17`        INT     COMMENT '子单,女性且年龄范围8-17,只包含首次核销',
    `no_mo_female_age_18to27`       INT     COMMENT '子单,女性且年龄范围18-27,只包含首次核销', 
    `no_mo_female_age_28to40`       INT     COMMENT '子单,女性且年龄范围28-40,只包含首次核销',
    `no_mo_female_age_41to60`       INT     COMMENT '子单,女性且年龄范围41-60,只包含首次核销',
    `no_mo_female_age_61plus`       INT     COMMENT '子单,女性且年龄范围>60,只包含首次核销',
    `no_mo_unknown`                 INT     COMMENT '子单,性别年龄未知,只包含首次核销',
    `no_mo_total`                   INT     COMMENT '子单,总人数,只包含首次核销',

    `no_mo_male_age_0to7_all`       INT     COMMENT '子单,男性且年龄范围0-7,包含首次核销和重复入园',   
    `no_mo_male_age_8to17_all`      INT     COMMENT '子单,男性且年龄范围8-17,包含首次核销和重复入园', 
    `no_mo_male_age_18to27_all`     INT     COMMENT '子单,男性且年龄范围18-27,包含首次核销和重复入园', 
    `no_mo_male_age_28to40_all`     INT     COMMENT '子单,男性且年龄范围28-40,包含首次核销和重复入园', 
    `no_mo_male_age_41to60_all`     INT     COMMENT '子单,男性且年龄范围41-60,包含首次核销和重复入园', 
    `no_mo_male_age_61plus_all`     INT     COMMENT '子单,男性且年龄范围>60,包含首次核销和重复入园',  
    `no_mo_female_age_0to7_all`     INT     COMMENT '子单,女性且年龄范围0-7,包含首次核销和重复入园', 
    `no_mo_female_age_8to17_all`    INT     COMMENT '子单,女性且年龄范围8-17,包含首次核销和重复入园', 
    `no_mo_female_age_18to27_all`   INT     COMMENT '子单,女性且年龄范围18-27,包含首次核销和重复入园', 
    `no_mo_female_age_28to40_all`   INT     COMMENT '子单,女性且年龄范围28-40,包含首次核销和重复入园', 
    `no_mo_female_age_41to60_all`   INT     COMMENT '子单,女性且年龄范围41-60,包含首次核销和重复入园', 
    `no_mo_female_age_61plus_all`   INT     COMMENT '子单,女性且年龄范围>60,包含首次核销和重复入园', 
    `no_mo_unknown_all`             INT     COMMENT '子单,性别年龄未知,包含首次核销和重复入园',
    `no_mo_total_all`               INT     COMMENT '子单,总人数,包含首次核销和重复入园',

  	`year` 	                        INT     COMMENT '年',
  	`month`                         INT     COMMENT '年月',
  	`week` 	                        INT     COMMENT '年周'
)COMMENT '每日-核销-性别年龄-主子单人数指标表'
PARTITIONED BY (`fulldate`          INT     COMMENT '全日期')
STORED AS ORC;


INSERT OVERWRITE TABLE ads_daily_scenic_verify_tourist_sex_age_d_i PARTITION(fulldate)
SELECT 
    `land_id`,	
    `land_name`,
    `sid`,      
    `p_type`,   
    SUM(`mo_male_age_0to7`)             AS `mo_male_age_0to7`,     
    SUM(`mo_male_age_8to17`)            AS `mo_male_age_8to17`,    
    SUM(`mo_male_age_18to27`)           AS `mo_male_age_18to27`,   
    SUM(`mo_male_age_28to40`)           AS `mo_male_age_28to40`,   
    SUM(`mo_male_age_41to60`)           AS `mo_male_age_41to60`,   
    SUM(`mo_male_age_61plus`)           AS `mo_male_age_61plus`,   
    SUM(`mo_female_age_0to7`)           AS `mo_female_age_0to7`,   
    SUM(`mo_female_age_8to17`)          AS `mo_female_age_8to17`,  
    SUM(`mo_female_age_18to27`)         AS `mo_female_age_18to27`, 
    SUM(`mo_female_age_28to40`)         AS `mo_female_age_28to40`, 
    SUM(`mo_female_age_41to60`)         AS `mo_female_age_41to60`, 
    SUM(`mo_female_age_61plus`)         AS `mo_female_age_61plus`, 
    SUM(`mo_unknown`)                   AS `mo_unknown`,           
    SUM(`mo_total`)                     AS `mo_total`,             

    SUM(`mo_male_age_0to7_all`)         AS `mo_male_age_0to7_all`,     
    SUM(`mo_male_age_8to17_all`)        AS `mo_male_age_8to17_all`,    
    SUM(`mo_male_age_18to27_all`)       AS `mo_male_age_18to27_all`,   
    SUM(`mo_male_age_28to40_all`)       AS `mo_male_age_28to40_all`,   
    SUM(`mo_male_age_41to60_all`)       AS `mo_male_age_41to60_all`,   
    SUM(`mo_male_age_61plus_all`)       AS `mo_male_age_61plus_all`,   
    SUM(`mo_female_age_0to7_all`)       AS `mo_female_age_0to7_all`,   
    SUM(`mo_female_age_8to17_all`)      AS `mo_female_age_8to17_all`,  
    SUM(`mo_female_age_18to27_all`)     AS `mo_female_age_18to27_all`, 
    SUM(`mo_female_age_28to40_all`)     AS `mo_female_age_28to40_all`, 
    SUM(`mo_female_age_41to60_all`)     AS `mo_female_age_41to60_all`, 
    SUM(`mo_female_age_61plus_all`)     AS `mo_female_age_61plus_all`, 
    SUM(`mo_unknown_all`)               AS `mo_unknown_all`,           
    SUM(`mo_total_all`)                 AS `mo_total_all`,             

    SUM(`no_mo_male_age_0to7`)          AS `no_mo_male_age_0to7`,     
    SUM(`no_mo_male_age_8to17`)         AS `no_mo_male_age_8to17`,    
    SUM(`no_mo_male_age_18to27`)        AS `no_mo_male_age_18to27`,   
    SUM(`no_mo_male_age_28to40`)        AS `no_mo_male_age_28to40`,   
    SUM(`no_mo_male_age_41to60`)        AS `no_mo_male_age_41to60`,   
    SUM(`no_mo_male_age_61plus`)        AS `no_mo_male_age_61plus`,   
    SUM(`no_mo_female_age_0to7`)        AS `no_mo_female_age_0to7`,   
    SUM(`no_mo_female_age_8to17`)       AS `no_mo_female_age_8to17`,  
    SUM(`no_mo_female_age_18to27`)      AS `no_mo_female_age_18to27`, 
    SUM(`no_mo_female_age_28to40`)      AS `no_mo_female_age_28to40`, 
    SUM(`no_mo_female_age_41to60`)      AS `no_mo_female_age_41to60`, 
    SUM(`no_mo_female_age_61plus`)      AS `no_mo_female_age_61plus`, 
    SUM(`no_mo_unknown`)                AS `no_mo_unknown`,           
    SUM(`no_mo_total`)                  AS `no_mo_total`,             

    SUM(`no_mo_male_age_0to7_all`)      AS `no_mo_male_age_0to7_all`,     
    SUM(`no_mo_male_age_8to17_all`)     AS `no_mo_male_age_8to17_all`,    
    SUM(`no_mo_male_age_18to27_all`)    AS `no_mo_male_age_18to27_all`,   
    SUM(`no_mo_male_age_28to40_all`)    AS `no_mo_male_age_28to40_all`,   
    SUM(`no_mo_male_age_41to60_all`)    AS `no_mo_male_age_41to60_all`,   
    SUM(`no_mo_male_age_61plus_all`)    AS `no_mo_male_age_61plus_all`,   
    SUM(`no_mo_female_age_0to7_all`)    AS `no_mo_female_age_0to7_all`,   
    SUM(`no_mo_female_age_8to17_all`)   AS `no_mo_female_age_8to17_all`,  
    SUM(`no_mo_female_age_18to27_all`)  AS `no_mo_female_age_18to27_all`, 
    SUM(`no_mo_female_age_28to40_all`)  AS `no_mo_female_age_28to40_all`, 
    SUM(`no_mo_female_age_41to60_all`)  AS `no_mo_female_age_41to60_all`, 
    SUM(`no_mo_female_age_61plus_all`)  AS `no_mo_female_age_61plus_all`, 
    SUM(`no_mo_unknown_all`)            AS `no_mo_unknown_all`,           
    SUM(`no_mo_total_all`)              AS `no_mo_total_all`,             

    `year`, 
    `month`,
    `week`, 
    `fulldate`
FROM ads_daily_scenic_verify_tourist_province_sex_age_d_i
WHERE fulldate = '${ds}'
GROUP BY land_id, land_name, sid, p_type, year, month, week, fulldate;
