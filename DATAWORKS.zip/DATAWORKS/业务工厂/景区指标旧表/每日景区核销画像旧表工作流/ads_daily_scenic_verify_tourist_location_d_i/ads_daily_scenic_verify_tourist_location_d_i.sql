-- name ads_daily_scenic_verify_tourist_location_d_i
-- type Spark SQL
-- author liangleichen@12301.cc
-- create time 2024-11-13 09:28:05
-- desc 每日-核销-票-省市-主子单人数指标表

SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;

CREATE TABLE IF NOT EXISTS `ads_daily_scenic_verify_tourist_location_d_i`(
    `land_id`		            INT	    COMMENT '景区ID',
    `land_name`			        STRING	COMMENT '景区名称',
    `sid`		                INT	    COMMENT '原始供应商id',

    `p_type`                    STRING  COMMENT '景区类型：A景区B线路C酒店F套票',
    `country`                   STRING  COMMENT '统计国家',
    `province`			        STRING	COMMENT '统计省',
    `city`			            STRING	COMMENT '统计市',
    
    `mo_tourist_count`          INT	    COMMENT '今日主单游客数,只包含首次核销',
    `mo_tourist_count_all`      INT	    COMMENT '今日主单游客数,包含首次核销和重复入园',

    `no_mo_tourist_count`       INT	    COMMENT '今日子单游客数,只包含首次核销',
    `no_mo_tourist_count_all`   INT	    COMMENT '今日子单游客数,包含首次核销和重复入园',

  	`year` 			            INT	    COMMENT '年',
  	`month` 		            INT	    COMMENT '年月',
  	`week` 			            INT	    COMMENT '年周'
)COMMENT '每日-核销-省市-主子单人数指标表'
PARTITIONED BY (`fulldate`      INT   	COMMENT '全日期')
STORED AS ORC;


INSERT OVERWRITE TABLE ads_daily_scenic_verify_tourist_location_d_i PARTITION(`fulldate`)
SELECT 
    land_id, 
    land_name, 
    sid, 

    p_type, 
    country,
    province, 
    city, 

    SUM(mo_tourist_count)           AS `mo_tourist_count`,
    SUM(mo_tourist_count_all)       AS `mo_tourist_count_all`,
    SUM(no_mo_tourist_count)        AS `no_mo_tourist_count`,
    SUM(no_mo_tourist_count_all)    AS `no_mo_tourist_count_all`,

    year, 
    month, 
    week, 
    fulldate
FROM ads_daily_scenic_ticket_verify_tourist_location_d_i
WHERE fulldate = '${ds}'
GROUP BY land_id, land_name, sid, p_type, country, province, city, year, month, week, fulldate;

