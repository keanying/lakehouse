-- name ads_daily_scenic_ticket_verify_tourist_location_d_i
-- type Spark SQL
-- author liangleichen@12301.cc
-- create time 2024-11-11 18:50:37
-- desc 每日-核销-票-省市-主子单人数指标表

SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;

CREATE TABLE IF NOT EXISTS `ads_daily_scenic_ticket_verify_tourist_location_d_i`(
    `land_id`		            INT	    COMMENT '景区ID',
    `land_name`			        STRING	COMMENT '景区名称',
    `sid`		                INT	    COMMENT '原始供应商id',
    `pid`                       INT     COMMENT '产品id',
    `ticket_id`                 INT     COMMENT '票ID',
    `p_type`                    STRING  COMMENT '景区类型：A景区B线路C酒店F套票',
    `country`                   STRING  COMMENT '统计国家',
    `province`			        STRING	COMMENT '统计省',
    `city`			            STRING	COMMENT '统计市',

    `mo_tourist_count`          INT	    COMMENT '今日主单游客数,只包含首次核销',
    `mo_tourist_count_all`      INT	    COMMENT '今日主单游客数,包含首次核销和重复入园',

    `no_mo_tourist_count`       INT	    COMMENT '今日子单游客数,只包含首次核销',
    `no_mo_tourist_count_all`   INT	    COMMENT '今日子单游客数,包含首次核销和重复入园',

  	`year` 			            INT	    COMMENT '年',
  	`month` 		            INT	    COMMENT '年月',
  	`week` 			            INT	    COMMENT '年周'
)COMMENT '每日-核销-票-省市-主子单人数指标表'
PARTITIONED BY (`fulldate`      INT   	COMMENT '全日期')
STORED AS ORC;


INSERT OVERWRITE TABLE ads_daily_scenic_ticket_verify_tourist_location_d_i PARTITION(`fulldate`)
SELECT 
    verify.lid                                                                                      AS `land_id`, 
    land.land_name                                                                                  AS `land_name`, 
    verify.apply_did                                                                                AS `sid`, 
    verify.pid                                                                                      AS `pid`, 
    verify.tid                                                                                      AS `ticket_id`, 

    verify.product_type                                                                             AS `p_type`,
    verify.country                                                                                  AS `country`,
    verify.province                                                                                 AS `province`, 
    verify.city                                                                                     AS `city`,

    SUM(IF(order_type IN ('单票', '套票主票') AND verify.is_first_used = 1, verify.verify_num, 0))   AS `mo_tourist_count`,
    SUM(IF(order_type IN ('单票', '套票主票'), verify.verify_num, 0))                                AS `mo_tourist_count_all`,

    SUM(IF(order_type IN ('套票子票') AND verify.is_first_used = 1, verify.verify_num, 0))           AS `no_mo_tourist_count`,
    SUM(IF(order_type IN ('套票子票'), verify.verify_num, 0))                                        AS `no_mo_tourist_count_all`,

    YEAR(`date`)                                                                                    AS `year`,
    YEAR(`date`) * 100 + MONTH(`date`)                                                              AS `month`,
    INT(isoweek)                                                                                    AS `week`,
    INT(verify.insertdate)                                                                          AS `fulldate`
FROM  
(
     SELECT 
        apply_did,
        insertdate, 
        orderid, 
        lid,
        verify_num,
        sex,
        is_first_used,
        tid,
        pid,
        order_type,
        product_type,
        IF (`phone_country_name` != '未知', `phone_country_name`, `idcard_country_name`)        AS `country`,
        IF (`phone_country_name` != '未知', `phone_province_name`, `idcard_province_name`)      AS `province`,
        IF (`phone_country_name` != '未知', `phone_city_name`, `idcard_city_name`)              AS `city`
    FROM dwd_tourist_verify_d_i
    WHERE insertdate = '${ds}'
        AND lid != -1
        AND order_type != '-1'
        AND pid != -1
        AND product_type != '-1'
) AS verify
LEFT JOIN dim_date_isoweek_o_f AS dim_isoweek 
ON verify.insertdate = dim_isoweek.`fulldate`
LEFT JOIN 
(
    SELECT land_id, land_name, land_type_code
    FROM dim_land_d_f 
    WHERE pt = FROM_UNIXTIME(UNIX_TIMESTAMP(DATE_SUB(CURRENT_DATE, 1)), 'yyyyMMdd')
) AS land
ON verify.lid = land.land_id
GROUP BY 
    verify.lid, 
    verify.tid, 
    verify.pid, 
    land.land_name, 
    verify.apply_did, 
    verify.product_type, 
    verify.country,
    verify.province,
    verify.city,
    verify.insertdate,
    dim_isoweek.isoweek,
    dim_isoweek.date;