-- name ads_daily_ticket_verify_draw_remain_d_i
-- type Spark SQL
-- author wanghaiyang@12301.cc
-- create time 2025-01-09 17:30:58
-- desc 每日门票核销画像指标表(只保留白名单供应商)

SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;

CREATE TABLE IF NOT EXISTS ads_daily_ticket_verify_draw_remain_d_i(
    `land_id`		             INT	 COMMENT '景区ID',
    `sid`                        INT     COMMENT '原始供应商id',
    `pid`                        INT     COMMENT '产品id',
    `ticket_id`                  INT     COMMENT '票ID',
    `p_type`                     STRING  COMMENT '景区类型：A景区B线路C酒店F套票',

    `country`                    STRING  COMMENT '统计国家',
    `province`			         STRING	 COMMENT '统计省',
    `city`			             STRING	 COMMENT '统计市',
    `district`			         STRING	 COMMENT '统计区/县',

    `male_age_0to7`              INT     COMMENT '男性且年龄范围0-7,只包含首次核销',
    `male_age_8to17`             INT     COMMENT '男性且年龄范围8-17,只包含首次核销',
    `male_age_18to27`            INT     COMMENT '男性且年龄范围18-27,只包含首次核销',
    `male_age_28to40`            INT     COMMENT '男性且年龄范围28-40,只包含首次核销',
    `male_age_41to60`            INT     COMMENT '男性且年龄范围41-60,只包含首次核销', 
    `male_age_61plus`            INT     COMMENT '男性且年龄范围>60,只包含首次核销', 
    `female_age_0to7`            INT     COMMENT '女性且年龄范围0-7,只包含首次核销',
    `female_age_8to17`           INT     COMMENT '女性且年龄范围8-17,只包含首次核销',
    `female_age_18to27`          INT     COMMENT '女性且年龄范围18-27,只包含首次核销', 
    `female_age_28to40`          INT     COMMENT '女性且年龄范围28-40,只包含首次核销',
    `female_age_41to60`          INT     COMMENT '女性且年龄范围41-60,只包含首次核销',
    `female_age_61plus`          INT     COMMENT '女性且年龄范围>60,只包含首次核销',
    `unknown`                    INT     COMMENT '性别年龄未知,只包含首次核销',
    `total`                      INT     COMMENT '总人数,只包含首次核销',

    `male_age_0to7_all`          INT     COMMENT '男性且年龄范围0-7,包含首次核销和重复入园',   
    `male_age_8to17_all`         INT     COMMENT '男性且年龄范围8-17,包含首次核销和重复入园', 
    `male_age_18to27_all`        INT     COMMENT '男性且年龄范围18-27,包含首次核销和重复入园', 
    `male_age_28to40_all`        INT     COMMENT '男性且年龄范围28-40,包含首次核销和重复入园', 
    `male_age_41to60_all`        INT     COMMENT '男性且年龄范围41-60,包含首次核销和重复入园', 
    `male_age_61plus_all`        INT     COMMENT '男性且年龄范围>60,包含首次核销和重复入园',  
    `female_age_0to7_all`        INT     COMMENT '女性且年龄范围0-7,包含首次核销和重复入园', 
    `female_age_8to17_all`       INT     COMMENT '女性且年龄范围8-17,包含首次核销和重复入园', 
    `female_age_18to27_all`      INT     COMMENT '女性且年龄范围18-27,包含首次核销和重复入园', 
    `female_age_28to40_all`      INT     COMMENT '女性且年龄范围28-40,包含首次核销和重复入园', 
    `female_age_41to60_all`      INT     COMMENT '女性且年龄范围41-60,包含首次核销和重复入园', 
    `female_age_61plus_all`      INT     COMMENT '女性且年龄范围>60,包含首次核销和重复入园', 
    `unknown_all`                INT     COMMENT '性别年龄未知,包含首次核销和重复入园',
    `total_all`                  INT     COMMENT '总人数,包含首次核销和重复入园',

  	`year` 	                     INT	 COMMENT '年',
  	`month`                      INT	 COMMENT '年月',
  	`week` 	                     INT	 COMMENT '年周'
)COMMENT '每日门票核销画像指标表(只保留白名单供应商)'
PARTITIONED BY (`fulldate`          INT   	COMMENT '全日期')
STORED AS ORC;


INSERT OVERWRITE TABLE ads_daily_ticket_verify_draw_remain_d_i PARTITION(fulldate)
SELECT 
    `land_id`,
    drawTab.`sid`,
    `pid`,
    `ticket_id`,
    `p_type`,

    `country`,
    `province`,
    `city`,
    `district`,

    `male_age_0to7`,
    `male_age_8to17`,
    `male_age_18to27`,
    `male_age_28to40`,
    `male_age_41to60`, 
    `male_age_61plus`, 
    `female_age_0to7`,
    `female_age_8to17`,
    `female_age_18to27`, 
    `female_age_28to40`,
    `female_age_41to60`,
    `female_age_61plus`,
    `unknown`,
    `total`,

    `male_age_0to7_all`,   
    `male_age_8to17_all`, 
    `male_age_18to27_all`, 
    `male_age_28to40_all`, 
    `male_age_41to60_all`, 
    `male_age_61plus_all`,  
    `female_age_0to7_all`, 
    `female_age_8to17_all`, 
    `female_age_18to27_all`, 
    `female_age_28to40_all`, 
    `female_age_41to60_all`, 
    `female_age_61plus_all`, 
    `unknown_all`,
    `total_all`,

  	`year`,
  	`month`,
  	`week`,
    `fulldate`
FROM ads_daily_ticket_verify_draw_d_i drawTab
JOIN (
    SELECT sid
    FROM dim_sid_white_list_d_f 
    WHERE pt = DATE_FORMAT(DATE_SUB(CURRENT_DATE(), 1),"yyyyMMdd")
) whiteTab
ON drawTab.sid = whiteTab.sid
WHERE fulldate = '${ds}';