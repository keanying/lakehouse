-- name ads_daily_scenic_ticket_verify_tourist_province_sex_age_d_i
-- type Spark SQL
-- author liangleichen@12301.cc
-- create time 2024-11-26 17:30:58
-- desc 每日-核销-票-省-性别年龄-主子单人数指标表

SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;

CREATE TABLE IF NOT EXISTS ads_daily_scenic_ticket_verify_tourist_province_sex_age_d_i(
    `land_id`		                INT		COMMENT '景区ID',
    `land_name`		                STRING	COMMENT '景区名称',
    `sid`                           INT     COMMENT '原始供应商id',
    `pid`                           INT     COMMENT '产品id',
    `ticket_id`                     INT     COMMENT '票ID',
    `p_type`                        STRING  COMMENT '景区类型：A景区B线路C酒店F套票',
    `country`                       STRING  COMMENT '统计国家',
    `province`			            STRING	COMMENT '统计省',

    `mo_male_age_0to7`              INT     COMMENT '主单,男性且年龄范围0-7,只包含首次核销',
    `mo_male_age_8to17`             INT     COMMENT '主单,男性且年龄范围8-17,只包含首次核销',
    `mo_male_age_18to27`            INT     COMMENT '主单,男性且年龄范围18-27,只包含首次核销',
    `mo_male_age_28to40`            INT     COMMENT '主单,男性且年龄范围28-40,只包含首次核销',
    `mo_male_age_41to60`            INT     COMMENT '主单,男性且年龄范围41-60,只包含首次核销', 
    `mo_male_age_61plus`            INT     COMMENT '主单,男性且年龄范围>60,只包含首次核销', 
    `mo_female_age_0to7`            INT     COMMENT '主单,女性且年龄范围0-7,只包含首次核销',
    `mo_female_age_8to17`           INT     COMMENT '主单,女性且年龄范围8-17,只包含首次核销',
    `mo_female_age_18to27`          INT     COMMENT '主单,女性且年龄范围18-27,只包含首次核销', 
    `mo_female_age_28to40`          INT     COMMENT '主单,女性且年龄范围28-40,只包含首次核销',
    `mo_female_age_41to60`          INT     COMMENT '主单,女性且年龄范围41-60,只包含首次核销',
    `mo_female_age_61plus`          INT     COMMENT '主单,女性且年龄范围>60,只包含首次核销',
    `mo_unknown`                    INT     COMMENT '主单,性别年龄未知,只包含首次核销',
    `mo_total`                      INT     COMMENT '主单,总人数,只包含首次核销',

    `mo_male_age_0to7_all`          INT     COMMENT '主单,男性且年龄范围0-7,包含首次核销和重复入园',   
    `mo_male_age_8to17_all`         INT     COMMENT '主单,男性且年龄范围8-17,包含首次核销和重复入园', 
    `mo_male_age_18to27_all`        INT     COMMENT '主单,男性且年龄范围18-27,包含首次核销和重复入园', 
    `mo_male_age_28to40_all`        INT     COMMENT '主单,男性且年龄范围28-40,包含首次核销和重复入园', 
    `mo_male_age_41to60_all`        INT     COMMENT '主单,男性且年龄范围41-60,包含首次核销和重复入园', 
    `mo_male_age_61plus_all`        INT     COMMENT '主单,男性且年龄范围>60,包含首次核销和重复入园',  
    `mo_female_age_0to7_all`        INT     COMMENT '主单,女性且年龄范围0-7,包含首次核销和重复入园', 
    `mo_female_age_8to17_all`       INT     COMMENT '主单,女性且年龄范围8-17,包含首次核销和重复入园', 
    `mo_female_age_18to27_all`      INT     COMMENT '主单,女性且年龄范围18-27,包含首次核销和重复入园', 
    `mo_female_age_28to40_all`      INT     COMMENT '主单,女性且年龄范围28-40,包含首次核销和重复入园', 
    `mo_female_age_41to60_all`      INT     COMMENT '主单,女性且年龄范围41-60,包含首次核销和重复入园', 
    `mo_female_age_61plus_all`      INT     COMMENT '主单,女性且年龄范围>60,包含首次核销和重复入园', 
    `mo_unknown_all`                INT     COMMENT '主单,性别年龄未知,包含首次核销和重复入园',
    `mo_total_all`                  INT     COMMENT '主单,总人数,包含首次核销和重复入园',

    `no_mo_male_age_0to7`           INT     COMMENT '子单,男性且年龄范围0-7,只包含首次核销',
    `no_mo_male_age_8to17`          INT     COMMENT '子单,男性且年龄范围8-17,只包含首次核销',
    `no_mo_male_age_18to27`         INT     COMMENT '子单,男性且年龄范围18-27,只包含首次核销',
    `no_mo_male_age_28to40`         INT     COMMENT '子单,男性且年龄范围28-40,只包含首次核销',
    `no_mo_male_age_41to60`         INT     COMMENT '子单,男性且年龄范围41-60,只包含首次核销', 
    `no_mo_male_age_61plus`         INT     COMMENT '子单,男性且年龄范围>60,只包含首次核销', 
    `no_mo_female_age_0to7`         INT     COMMENT '子单,女性且年龄范围0-7,只包含首次核销',
    `no_mo_female_age_8to17`        INT     COMMENT '子单,女性且年龄范围8-17,只包含首次核销',
    `no_mo_female_age_18to27`       INT     COMMENT '子单,女性且年龄范围18-27,只包含首次核销', 
    `no_mo_female_age_28to40`       INT     COMMENT '子单,女性且年龄范围28-40,只包含首次核销',
    `no_mo_female_age_41to60`       INT     COMMENT '子单,女性且年龄范围41-60,只包含首次核销',
    `no_mo_female_age_61plus`       INT     COMMENT '子单,女性且年龄范围>60,只包含首次核销',
    `no_mo_unknown`                 INT     COMMENT '子单,性别年龄未知,只包含首次核销',
    `no_mo_total`                   INT     COMMENT '子单,总人数,只包含首次核销',

    `no_mo_male_age_0to7_all`       INT     COMMENT '子单,男性且年龄范围0-7,包含首次核销和重复入园',   
    `no_mo_male_age_8to17_all`      INT     COMMENT '子单,男性且年龄范围8-17,包含首次核销和重复入园', 
    `no_mo_male_age_18to27_all`     INT     COMMENT '子单,男性且年龄范围18-27,包含首次核销和重复入园', 
    `no_mo_male_age_28to40_all`     INT     COMMENT '子单,男性且年龄范围28-40,包含首次核销和重复入园', 
    `no_mo_male_age_41to60_all`     INT     COMMENT '子单,男性且年龄范围41-60,包含首次核销和重复入园', 
    `no_mo_male_age_61plus_all`     INT     COMMENT '子单,男性且年龄范围>60,包含首次核销和重复入园',  
    `no_mo_female_age_0to7_all`     INT     COMMENT '子单,女性且年龄范围0-7,包含首次核销和重复入园', 
    `no_mo_female_age_8to17_all`    INT     COMMENT '子单,女性且年龄范围8-17,包含首次核销和重复入园', 
    `no_mo_female_age_18to27_all`   INT     COMMENT '子单,女性且年龄范围18-27,包含首次核销和重复入园', 
    `no_mo_female_age_28to40_all`   INT     COMMENT '子单,女性且年龄范围28-40,包含首次核销和重复入园', 
    `no_mo_female_age_41to60_all`   INT     COMMENT '子单,女性且年龄范围41-60,包含首次核销和重复入园', 
    `no_mo_female_age_61plus_all`   INT     COMMENT '子单,女性且年龄范围>60,包含首次核销和重复入园', 
    `no_mo_unknown_all`             INT     COMMENT '子单,性别年龄未知,包含首次核销和重复入园',
    `no_mo_total_all`               INT     COMMENT '子单,总人数,包含首次核销和重复入园',

  	`year` 	                        INT	    COMMENT '年',
  	`month`                         INT	    COMMENT '年月',
  	`week` 	                        INT	    COMMENT '年周'
)COMMENT '每日-核销-票-省-性别年龄-主子单人数指标表'
PARTITIONED BY (`fulldate`          INT   	COMMENT '全日期')
STORED AS ORC;


INSERT OVERWRITE TABLE ads_daily_scenic_ticket_verify_tourist_province_sex_age_d_i PARTITION(fulldate)
SELECT 
    verify.lid                  AS `land_id`,       
    land.land_name              AS `land_name`,  
    verify.apply_did            AS `sid`,
    verify.pid                  AS `pid`,
    verify.tid                  AS `ticket_id`,
    verify.product_type         AS `p_type`,

    verify.country              AS `country`, 
    verify.province             AS `province`, 

    -- 主票，首次
    SUM(IF(order_type IN ('单票', '套票主票') AND age_range='0-7'   AND sex='男'   AND is_first_used = 1, verify_num, 0))  AS `mo_male_age_0to7`,    
    SUM(IF(order_type IN ('单票', '套票主票') AND age_range='8-17'  AND sex='男'   AND is_first_used = 1, verify_num, 0))  AS `mo_male_age_8to17`,   
    SUM(IF(order_type IN ('单票', '套票主票') AND age_range='18-27' AND sex='男'   AND is_first_used = 1, verify_num, 0))  AS `mo_male_age_18to27`,  
    SUM(IF(order_type IN ('单票', '套票主票') AND age_range='28-40' AND sex='男'   AND is_first_used = 1, verify_num, 0))  AS `mo_male_age_28to40`,  
    SUM(IF(order_type IN ('单票', '套票主票') AND age_range='41-60' AND sex='男'   AND is_first_used = 1, verify_num, 0))  AS `mo_male_age_41to60`,  
    SUM(IF(order_type IN ('单票', '套票主票') AND age_range='61+'   AND sex='男'   AND is_first_used = 1, verify_num, 0))  AS `mo_male_age_61plus`,  
    SUM(IF(order_type IN ('单票', '套票主票') AND age_range='0-7'   AND sex='女'   AND is_first_used = 1, verify_num, 0))  AS `mo_female_age_0to7`,  
    SUM(IF(order_type IN ('单票', '套票主票') AND age_range='8-17'  AND sex='女'   AND is_first_used = 1, verify_num, 0))  AS `mo_female_age_8to17`, 
    SUM(IF(order_type IN ('单票', '套票主票') AND age_range='18-27' AND sex='女'   AND is_first_used = 1, verify_num, 0))  AS `mo_female_age_18to27`,
    SUM(IF(order_type IN ('单票', '套票主票') AND age_range='28-40' AND sex='女'   AND is_first_used = 1, verify_num, 0))  AS `mo_female_age_28to40`,
    SUM(IF(order_type IN ('单票', '套票主票') AND age_range='41-60' AND sex='女'   AND is_first_used = 1, verify_num, 0))  AS `mo_female_age_41to60`,
    SUM(IF(order_type IN ('单票', '套票主票') AND age_range='61+'   AND sex='女'   AND is_first_used = 1, verify_num, 0))  AS `mo_female_age_61plus`,
    SUM(IF(order_type IN ('单票', '套票主票') AND age_range='-1'    AND sex='未知' AND is_first_used = 1, verify_num, 0))  AS `mo_unknown`, 
    SUM(IF(order_type IN ('单票', '套票主票') AND is_first_used = 1, verify_num, 0))                                       AS `mo_total`, 

    -- 主票，每次
    SUM(IF(order_type IN ('单票', '套票主票') AND age_range='0-7'   AND sex='男', verify_num, 0))  AS `mo_male_age_0to7_all`,    
    SUM(IF(order_type IN ('单票', '套票主票') AND age_range='8-17'  AND sex='男', verify_num, 0))  AS `mo_male_age_8to17_all`,  
    SUM(IF(order_type IN ('单票', '套票主票') AND age_range='18-27' AND sex='男', verify_num, 0))  AS `mo_male_age_18to27_all`,  
    SUM(IF(order_type IN ('单票', '套票主票') AND age_range='28-40' AND sex='男', verify_num, 0))  AS `mo_male_age_28to40_all`,  
    SUM(IF(order_type IN ('单票', '套票主票') AND age_range='41-60' AND sex='男', verify_num, 0))  AS `mo_male_age_41to60_all`,
    SUM(IF(order_type IN ('单票', '套票主票') AND age_range='61+'   AND sex='男', verify_num, 0))  AS `mo_male_age_61plus_all`,  
    SUM(IF(order_type IN ('单票', '套票主票') AND age_range='0-7'   AND sex='女', verify_num, 0))  AS `mo_female_age_0to7_all`,  
    SUM(IF(order_type IN ('单票', '套票主票') AND age_range='8-17'  AND sex='女', verify_num, 0))  AS `mo_female_age_8to17_all`,
    SUM(IF(order_type IN ('单票', '套票主票') AND age_range='18-27' AND sex='女', verify_num, 0))  AS `mo_female_age_18to27_all`,
    SUM(IF(order_type IN ('单票', '套票主票') AND age_range='28-40' AND sex='女', verify_num, 0))  AS `mo_female_age_28to40_all`,
    SUM(IF(order_type IN ('单票', '套票主票') AND age_range='41-60' AND sex='女', verify_num, 0))  AS `mo_female_age_41to60_all`,
    SUM(IF(order_type IN ('单票', '套票主票') AND age_range='61+'   AND sex='女', verify_num, 0))  AS `mo_female_age_61plus_all`,
    SUM(IF(order_type IN ('单票', '套票主票') AND age_range='-1'    AND sex='未知', verify_num, 0)) AS `mo_unknown_all`, 
    SUM(IF(order_type IN ('单票', '套票主票'), verify_num, 0))                                     AS `mo_total_all`,

    -- 子票，首次
    SUM(IF(order_type IN ('套票子票') AND age_range='0-7'   AND sex='男'   AND is_first_used = 1, verify_num, 0))  AS `no_mo_male_age_0to7`,    
    SUM(IF(order_type IN ('套票子票') AND age_range='8-17'  AND sex='男'   AND is_first_used = 1, verify_num, 0))  AS `no_mo_male_age_8to17`,   
    SUM(IF(order_type IN ('套票子票') AND age_range='18-27' AND sex='男'   AND is_first_used = 1, verify_num, 0))  AS `no_mo_male_age_18to27`,  
    SUM(IF(order_type IN ('套票子票') AND age_range='28-40' AND sex='男'   AND is_first_used = 1, verify_num, 0))  AS `no_mo_male_age_28to40`,  
    SUM(IF(order_type IN ('套票子票') AND age_range='41-60' AND sex='男'   AND is_first_used = 1, verify_num, 0))  AS `no_mo_male_age_41to60`,  
    SUM(IF(order_type IN ('套票子票') AND age_range='61+'   AND sex='男'   AND is_first_used = 1, verify_num, 0))  AS `no_mo_male_age_61plus`,  
    SUM(IF(order_type IN ('套票子票') AND age_range='0-7'   AND sex='女'   AND is_first_used = 1, verify_num, 0))  AS `no_mo_female_age_0to7`,  
    SUM(IF(order_type IN ('套票子票') AND age_range='8-17'  AND sex='女'   AND is_first_used = 1, verify_num, 0))  AS `no_mo_female_age_8to17`, 
    SUM(IF(order_type IN ('套票子票') AND age_range='18-27' AND sex='女'   AND is_first_used = 1, verify_num, 0))  AS `no_mo_female_age_18to27`,
    SUM(IF(order_type IN ('套票子票') AND age_range='28-40' AND sex='女'   AND is_first_used = 1, verify_num, 0))  AS `no_mo_female_age_28to40`,
    SUM(IF(order_type IN ('套票子票') AND age_range='41-60' AND sex='女'   AND is_first_used = 1, verify_num, 0))  AS `no_mo_female_age_41to60`,
    SUM(IF(order_type IN ('套票子票') AND age_range='61+'   AND sex='女'   AND is_first_used = 1, verify_num, 0))  AS `no_mo_female_age_61plus`,
    SUM(IF(order_type IN ('套票子票') AND age_range='-1'    AND sex='未知' AND is_first_used = 1, verify_num, 0))   AS `no_mo_unknown`, 
    SUM(IF(order_type IN ('套票子票') AND is_first_used = 1, verify_num, 0))                                       AS `no_mo_total`, 

    -- 子票，每次
    SUM(IF(order_type IN ('套票子票') AND age_range='0-7'   AND sex='男', verify_num, 0))  AS `no_mo_male_age_0to7_all`,    
    SUM(IF(order_type IN ('套票子票') AND age_range='8-17'  AND sex='男', verify_num, 0))  AS `no_mo_male_age_8to17_all`,  
    SUM(IF(order_type IN ('套票子票') AND age_range='18-27' AND sex='男', verify_num, 0))  AS `no_mo_male_age_18to27_all`,  
    SUM(IF(order_type IN ('套票子票') AND age_range='28-40' AND sex='男', verify_num, 0))  AS `no_mo_male_age_28to40_all`,  
    SUM(IF(order_type IN ('套票子票') AND age_range='41-60' AND sex='男', verify_num, 0))  AS `no_mo_male_age_41to60_all`,
    SUM(IF(order_type IN ('套票子票') AND age_range='61+'   AND sex='男', verify_num, 0))  AS `no_mo_male_age_61plus_all`,  
    SUM(IF(order_type IN ('套票子票') AND age_range='0-7'   AND sex='女', verify_num, 0))  AS `no_mo_female_age_0to7_all`,  
    SUM(IF(order_type IN ('套票子票') AND age_range='8-17'  AND sex='女', verify_num, 0))  AS `no_mo_female_age_8to17_all`,
    SUM(IF(order_type IN ('套票子票') AND age_range='18-27' AND sex='女', verify_num, 0))  AS `no_mo_female_age_18to27_all`,
    SUM(IF(order_type IN ('套票子票') AND age_range='28-40' AND sex='女', verify_num, 0))  AS `no_mo_female_age_28to40_all`,
    SUM(IF(order_type IN ('套票子票') AND age_range='41-60' AND sex='女', verify_num, 0))  AS `no_mo_female_age_41to60_all`,
    SUM(IF(order_type IN ('套票子票') AND age_range='61+'   AND sex='女', verify_num, 0))  AS `no_mo_female_age_61plus_all`,
    SUM(IF(order_type IN ('套票子票') AND age_range='-1'    AND sex='未知', verify_num, 0)) AS `no_mo_unknown_all`, 
    SUM(IF(order_type IN ('套票子票'), verify_num, 0))                                      AS `no_mo_total_all`,

    YEAR(`date`)                                                                            AS `year`,
    YEAR(`date`) * 100 + MONTH(`date`)                                                      AS `month`,
    INT(dim_isoweek.isoweek)                                                                AS `week`,
    INT(verify.insertdate)                                                                  AS `fulldate`
FROM 
(
    SELECT 
        apply_did,
        insertdate, 
        orderid, 
        lid,
        verify_num,
        product_type,
        sex,
        is_first_used,
        tid,
        pid,
        order_type,
        -- 年龄范围
        CASE
            WHEN age BETWEEN 0 AND 7
            THEN '0-7'
            WHEN age BETWEEN 8 AND 17
            THEN '8-17'
            WHEN age BETWEEN 18 AND 27
            THEN '18-27'
            WHEN age BETWEEN 28 AND 40
            THEN '28-40'
            WHEN age BETWEEN 41 AND 60
            THEN '41-60'
			WHEN age BETWEEN 61 AND 122 
            THEN '61+'
            ELSE '-1'
        END 	            AS age_range,
        IF (`phone_country_name` != '未知', `phone_country_name`, `idcard_country_name`)        AS `country`,
        IF (`phone_country_name` != '未知', `phone_province_name`, `idcard_province_name`)      AS `province`
    FROM dwd_tourist_verify_d_i
    WHERE insertdate = '${ds}'
        AND lid != -1
        AND order_type != '-1'
        AND pid != -1
        AND product_type != '-1'
) AS verify
LEFT JOIN dim_date_isoweek_o_f AS dim_isoweek  
ON verify.insertdate = dim_isoweek.`fulldate`
LEFT JOIN 
(
    SELECT land_id, land_name
    FROM dim_land_d_f
    WHERE pt = FROM_UNIXTIME(UNIX_TIMESTAMP(DATE_SUB(CURRENT_DATE, 1)), 'yyyyMMdd')
) AS land
ON verify.lid = land.land_id
GROUP BY  
    verify.apply_did,
    verify.insertdate,
    verify.age_range,
    verify.sex,
    verify.lid,
    verify.product_type,
    verify.pid,
    verify.tid,
    verify.country,
    verify.province,
    land.land_name,
    dim_isoweek.isoweek,
    dim_isoweek.date;       