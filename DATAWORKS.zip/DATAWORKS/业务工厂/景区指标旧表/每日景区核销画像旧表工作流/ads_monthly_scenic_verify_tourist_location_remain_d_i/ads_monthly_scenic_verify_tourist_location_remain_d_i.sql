-- name ads_monthly_scenic_verify_tourist_location_d_i
-- type Spark SQL
-- author liangleichen@12301.cc
-- create time 2024-11-13 14:30:07
-- desc 每日-核销-票-省市-主子单人数指标表

SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;

CREATE TABLE IF NOT EXISTS `ads_monthly_scenic_verify_tourist_location_remain_d_i`(
    `land_id`		            INT	    COMMENT '景区ID',
    `land_name`			        STRING	COMMENT '景区名称',
    `sid`		                INT	    COMMENT '原始供应商id',

    `p_type`                    STRING  COMMENT '景区类型：A景区B线路C酒店F套票',
    `country`   			    STRING	COMMENT '统计国家',
    `province`			        STRING	COMMENT '统计省',
    `city`			            STRING	COMMENT '统计市',

    `mo_tourist_count`          INT	    COMMENT '今日主单游客数,只包含首次核销',
    `mo_tourist_count_all`      INT	    COMMENT '今日主单游客数,包含首次核销和重复入园',

    `no_mo_tourist_count`       INT	    COMMENT '今日子单游客数,只包含首次核销',
    `no_mo_tourist_count_all`   INT	    COMMENT '今日子单游客数,包含首次核销和重复入园',

  	`year` 			            INT	    COMMENT '年'
)COMMENT '每月-核销-票-省市-主子单人数指标表'
PARTITIONED BY (`month`         INT	    COMMENT '月')
STORED AS ORC;


INSERT OVERWRITE TABLE ads_monthly_scenic_verify_tourist_location_remain_d_i PARTITION(`month`)
SELECT 
    land_id, 
    `land_name`, 
    sourceTab.`sid`, 

    p_type, 
    country,
    province, 
    city, 

    `mo_tourist_count`,
    `mo_tourist_count_all`,
    `no_mo_tourist_count`,
    `no_mo_tourist_count_all`,

    year, 
    month
FROM ads_monthly_scenic_verify_tourist_location_d_i sourceTab
JOIN (
    SELECT sid
    FROM dim_sid_white_list_d_f 
    WHERE pt = DATE_FORMAT(DATE_SUB(CURRENT_DATE(), 1),"yyyyMMdd")
) whiteTab
ON sourceTab.sid = whiteTab.sid
WHERE month = SUBSTR('${ds}', 0, 6)
;