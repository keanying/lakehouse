-- name ads_daily_ticket_verify_draw_d_i
-- type Spark SQL
-- author wanghaiyang@12301.cc
-- create time 2025-01-09 17:30:58
-- desc 每日门票核销画像指标表

SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;

CREATE TABLE IF NOT EXISTS ads_yearly_ticket_verify_draw_d_i(
    `land_id`		             INT     COMMENT '景区ID',
    `sid`                        INT     COMMENT '原始供应商id',
    `pid`                        INT     COMMENT '产品id',
    `ticket_id`                  INT     COMMENT '票ID',
    `p_type`                     STRING  COMMENT '景区类型：A景区B线路C酒店F套票',

    `country`                    STRING  COMMENT '统计国家',
    `province`			         STRING	 COMMENT '统计省',
    `city`			             STRING	 COMMENT '统计市',
    `district`			         STRING	 COMMENT '统计区/县',

    `male_age_0to7`              INT     COMMENT '男性且年龄范围0-7,只包含首次核销',
    `male_age_8to17`             INT     COMMENT '男性且年龄范围8-17,只包含首次核销',
    `male_age_18to27`            INT     COMMENT '男性且年龄范围18-27,只包含首次核销',
    `male_age_28to40`            INT     COMMENT '男性且年龄范围28-40,只包含首次核销',
    `male_age_41to60`            INT     COMMENT '男性且年龄范围41-60,只包含首次核销', 
    `male_age_61plus`            INT     COMMENT '男性且年龄范围>60,只包含首次核销', 
    `female_age_0to7`            INT     COMMENT '女性且年龄范围0-7,只包含首次核销',
    `female_age_8to17`           INT     COMMENT '女性且年龄范围8-17,只包含首次核销',
    `female_age_18to27`          INT     COMMENT '女性且年龄范围18-27,只包含首次核销', 
    `female_age_28to40`          INT     COMMENT '女性且年龄范围28-40,只包含首次核销',
    `female_age_41to60`          INT     COMMENT '女性且年龄范围41-60,只包含首次核销',
    `female_age_61plus`          INT     COMMENT '女性且年龄范围>60,只包含首次核销',
    `unknown`                    INT     COMMENT '性别年龄未知,只包含首次核销',
    `total`                      INT     COMMENT '总人数,只包含首次核销',

    `male_age_0to7_all`          INT     COMMENT '男性且年龄范围0-7,包含首次核销和重复入园',   
    `male_age_8to17_all`         INT     COMMENT '男性且年龄范围8-17,包含首次核销和重复入园', 
    `male_age_18to27_all`        INT     COMMENT '男性且年龄范围18-27,包含首次核销和重复入园', 
    `male_age_28to40_all`        INT     COMMENT '男性且年龄范围28-40,包含首次核销和重复入园', 
    `male_age_41to60_all`        INT     COMMENT '男性且年龄范围41-60,包含首次核销和重复入园', 
    `male_age_61plus_all`        INT     COMMENT '男性且年龄范围>60,包含首次核销和重复入园',  
    `female_age_0to7_all`        INT     COMMENT '女性且年龄范围0-7,包含首次核销和重复入园', 
    `female_age_8to17_all`       INT     COMMENT '女性且年龄范围8-17,包含首次核销和重复入园', 
    `female_age_18to27_all`      INT     COMMENT '女性且年龄范围18-27,包含首次核销和重复入园', 
    `female_age_28to40_all`      INT     COMMENT '女性且年龄范围28-40,包含首次核销和重复入园', 
    `female_age_41to60_all`      INT     COMMENT '女性且年龄范围41-60,包含首次核销和重复入园', 
    `female_age_61plus_all`      INT     COMMENT '女性且年龄范围>60,包含首次核销和重复入园', 
    `unknown_all`                INT     COMMENT '性别年龄未知,包含首次核销和重复入园',
    `total_all`                  INT     COMMENT '总人数,包含首次核销和重复入园'
)COMMENT '每日门票核销画像指标表'
PARTITIONED BY (`year` INT COMMENT '年')
STORED AS ORC;


INSERT OVERWRITE TABLE ads_yearly_ticket_verify_draw_d_i PARTITION(`year`)
SELECT 
    `land_id`                       AS  `land_id`,   
    drawTab.`sid`                   AS  `sid`,
    `pid`                           AS  `pid`,
    `ticket_id`                     AS  `ticket_id`,
    `p_type`                        AS  `p_type`,

    `country`                       AS  `country`,
    `province`                      AS  `province`,
    `city`                          AS  `city`,
    `district`                      AS  `district`,

    SUM(`male_age_0to7`)            AS  `male_age_0to7`,
    SUM(`male_age_8to17`)           AS  `male_age_8to17`,
    SUM(`male_age_18to27`)          AS  `male_age_18to27`,
    SUM(`male_age_28to40`)          AS  `male_age_28to40`,
    SUM(`male_age_41to60`)          AS  `male_age_41to60`, 
    SUM(`male_age_61plus`)          AS  `male_age_61plus`,
    SUM(`female_age_0to7`)          AS  `female_age_0to7`,
    SUM(`female_age_8to17`)         AS  `female_age_8to17`,
    SUM(`female_age_18to27`)        AS  `female_age_18to27`, 
    SUM(`female_age_28to40`)        AS  `female_age_28to40`,
    SUM(`female_age_41to60`)        AS  `female_age_41to60`,
    SUM(`female_age_61plus`)        AS  `female_age_61plus`,
    SUM(`unknown`)                  AS  `unknown`,
    SUM(`total`)                    AS  `total`,

    SUM(`male_age_0to7_all`)        AS  `male_age_0to7_all`,   
    SUM(`male_age_8to17_all`)       AS  `male_age_8to17_all`,
    SUM(`male_age_18to27_all`)      AS  `male_age_18to27_all`, 
    SUM(`male_age_28to40_all`)      AS  `male_age_28to40_all`, 
    SUM(`male_age_41to60_all`)      AS  `male_age_41to60_all`, 
    SUM(`male_age_61plus_all`)      AS  `male_age_61plus_all`,  
    SUM(`female_age_0to7_all`)      AS  `female_age_0to7_all`, 
    SUM(`female_age_8to17_all`)     AS  `female_age_8to17_all`, 
    SUM(`female_age_18to27_all`)    AS  `female_age_18to27_all`, 
    SUM(`female_age_28to40_all`)    AS  `female_age_28to40_all`, 
    SUM(`female_age_41to60_all`)    AS  `female_age_41to60_all`, 
    SUM(`female_age_61plus_all`)    AS  `female_age_61plus_all`, 
    SUM(`unknown_all`)              AS  `unknown_all`,
    SUM(`total_all`)                AS  `total_all`,
    `year`
FROM ads_monthly_ticket_verify_draw_d_i drawTab
WHERE SUBSTR(`month`, 0, 4) = SUBSTR('${ds}', 0, 4)
GROUP BY 
    `land_id`,   
    drawTab.`sid`,
    `pid`,
    `ticket_id`,
    `p_type`,
    `country`,
    `province`,
    `city`,
    `district`,
    `year`;