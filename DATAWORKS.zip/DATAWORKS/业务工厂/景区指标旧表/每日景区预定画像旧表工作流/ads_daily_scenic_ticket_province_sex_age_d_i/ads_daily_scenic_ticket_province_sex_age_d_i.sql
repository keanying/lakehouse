-- name ads_daily_scenic_ticket_province_sex_age_d_i
-- type Spark SQL
-- author liangleichen@12301.cc
-- create time 2024-11-05 17:26:50
-- desc 每日-预定-票-省-性别年龄-主子单人数指标表

SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;

CREATE TABLE IF NOT EXISTS ads_daily_scenic_ticket_province_sex_age_d_i(
    `land_id`		            INT		COMMENT '景区ID',
    `land_name`			        STRING	COMMENT '景区名称',
    `sid`                       INT     COMMENT '原始供应商id',
    `p_type`                    STRING  COMMENT '景区类型：A景区B线路C酒店F套票',
    `pid`                       INT     COMMENT '产品id',
    `ticket_id`                 INT     COMMENT '票ID',

    `country`			        STRING	COMMENT '统计国家',
    `province`			        STRING	COMMENT '统计省',

    `mo_male_age_0to7`          INT     COMMENT '主单男性且年龄范围0-7',   
    `mo_male_age_8to17`         INT     COMMENT '主单男性且年龄范围8-17', 
    `mo_male_age_18to27`        INT     COMMENT '主单男性且年龄范围18-27', 
    `mo_male_age_28to40`        INT     COMMENT '主单男性且年龄范围28-40', 
    `mo_male_age_41to60`        INT     COMMENT '主单男性且年龄范围41-60', 
    `mo_male_age_61plus`        INT     COMMENT '主单男性且年龄范围>60',  
    `mo_female_age_0to7`        INT     COMMENT '主单女性且年龄范围0-7', 
    `mo_female_age_8to17`       INT     COMMENT '主单女性且年龄范围8-17', 
    `mo_female_age_18to27`      INT     COMMENT '主单女性且年龄范围18-27', 
    `mo_female_age_28to40`      INT     COMMENT '主单女性且年龄范围28-40', 
    `mo_female_age_41to60`      INT     COMMENT '主单女性且年龄范围41-60', 
    `mo_female_age_61plus`      INT     COMMENT '主单女性且年龄范围>60', 
    `mo_unknown`                INT     COMMENT '主单性别年龄未知',
    `mo_total`                  INT     COMMENT '主单总人数',

    `no_mo_male_age_0to7`       INT     COMMENT '子单男性且年龄范围0-7',   
    `no_mo_male_age_8to17`      INT     COMMENT '子单男性且年龄范围8-17', 
    `no_mo_male_age_18to27`     INT     COMMENT '子单男性且年龄范围18-27', 
    `no_mo_male_age_28to40`     INT     COMMENT '子单男性且年龄范围28-40', 
    `no_mo_male_age_41to60`     INT     COMMENT '子单男性且年龄范围41-60', 
    `no_mo_male_age_61plus`     INT     COMMENT '子单男性且年龄范围>60',  
    `no_mo_female_age_0to7`     INT     COMMENT '子单女性且年龄范围0-7', 
    `no_mo_female_age_8to17`    INT     COMMENT '子单女性且年龄范围8-17', 
    `no_mo_female_age_18to27`   INT     COMMENT '子单女性且年龄范围18-27', 
    `no_mo_female_age_28to40`   INT     COMMENT '子单女性且年龄范围28-40', 
    `no_mo_female_age_41to60`   INT     COMMENT '子单女性且年龄范围41-60', 
    `no_mo_female_age_61plus`   INT     COMMENT '子单女性且年龄范围>60', 
    `no_mo_unknown`             INT     COMMENT '子单性别年龄未知',
    `no_mo_total`               INT     COMMENT '子单总人数',    

  	`year` 				        INT	    COMMENT '年',
  	`month` 			        INT	    COMMENT '月',
  	`week` 				        INT	    COMMENT '年周'
)COMMENT '每日-预定-票-省-性别年龄-主子单人数指标表'
PARTITIONED BY (`fulldate`  INT   	COMMENT '全日期')
STORED AS ORC;


INSERT OVERWRITE TABLE ads_daily_scenic_ticket_province_sex_age_d_i PARTITION(fulldate)
SELECT	
    lid 			                        AS `land_id`,
    title		                            AS `land_name`,
    apply_did                               AS `sid`,
    p_type                                  AS `p_type`,
    pid                                     AS `pid`,
    tid                                     AS `ticket_id`,
    country                                 AS `country`,
    NVL(province, '未知')                   AS `province`,
    -- 主单
    SUM(IF(order_type IN ('单票', '套票主票') AND age_range='0-7'   AND sex='男', multiple, 0))     AS `mo_male_age_0to7`,    
    SUM(IF(order_type IN ('单票', '套票主票') AND age_range='8-17'  AND sex='男', multiple, 0))     AS `mo_male_age_8to17`,   
    SUM(IF(order_type IN ('单票', '套票主票') AND age_range='18-27' AND sex='男', multiple, 0))     AS `mo_male_age_18to27`,  
    SUM(IF(order_type IN ('单票', '套票主票') AND age_range='28-40' AND sex='男', multiple, 0))     AS `mo_male_age_28to40`,  
    SUM(IF(order_type IN ('单票', '套票主票') AND age_range='41-60' AND sex='男', multiple, 0))     AS `mo_male_age_41to60`,  
    SUM(IF(order_type IN ('单票', '套票主票') AND age_range='61+'   AND sex='男', multiple, 0))     AS `mo_male_age_61plus`,  
    SUM(IF(order_type IN ('单票', '套票主票') AND age_range='0-7'   AND sex='女', multiple, 0))     AS `mo_female_age_0to7`,  
    SUM(IF(order_type IN ('单票', '套票主票') AND age_range='8-17'  AND sex='女', multiple, 0))     AS `mo_female_age_8to17`, 
    SUM(IF(order_type IN ('单票', '套票主票') AND age_range='18-27' AND sex='女', multiple, 0))     AS `mo_female_age_18to27`,
    SUM(IF(order_type IN ('单票', '套票主票') AND age_range='28-40' AND sex='女', multiple, 0))     AS `mo_female_age_28to40`,
    SUM(IF(order_type IN ('单票', '套票主票') AND age_range='41-60' AND sex='女', multiple, 0))     AS `mo_female_age_41to60`,
    SUM(IF(order_type IN ('单票', '套票主票') AND age_range='61+'   AND sex='女', multiple, 0))     AS `mo_female_age_61plus`,

    SUM(IF(order_type IN ('单票', '套票主票') AND age_range='-1' OR age_range IS NULL OR age_range='', multiple, 0))                        
                                                                                                  AS `mo_unknown`,          
    SUM(IF(order_type IN ('单票', '套票主票'), multiple, 0))                                        AS `mo_total`, 

    -- 子单
    SUM(IF(order_type='套票子票' AND age_range='0-7'   AND sex='男', multiple, 0))                  AS `no_mo_male_age_0to7`,    
    SUM(IF(order_type='套票子票' AND age_range='8-17'  AND sex='男', multiple, 0))                  AS `no_mo_male_age_8to17`,   
    SUM(IF(order_type='套票子票' AND age_range='18-27' AND sex='男', multiple, 0))                  AS `no_mo_male_age_18to27`,  
    SUM(IF(order_type='套票子票' AND age_range='28-40' AND sex='男', multiple, 0))                  AS `no_mo_male_age_28to40`,  
    SUM(IF(order_type='套票子票' AND age_range='41-60' AND sex='男', multiple, 0))                  AS `no_mo_male_age_41to60`,  
    SUM(IF(order_type='套票子票' AND age_range='61+'   AND sex='男', multiple, 0))                  AS `no_mo_male_age_61plus`,  
    SUM(IF(order_type='套票子票' AND age_range='0-7'   AND sex='女', multiple, 0))                  AS `no_mo_female_age_0to7`,  
    SUM(IF(order_type='套票子票' AND age_range='8-17'  AND sex='女', multiple, 0))                  AS `no_mo_female_age_8to17`, 
    SUM(IF(order_type='套票子票' AND age_range='18-27' AND sex='女', multiple, 0))                  AS `no_mo_female_age_18to27`,
    SUM(IF(order_type='套票子票' AND age_range='28-40' AND sex='女', multiple, 0))                  AS `no_mo_female_age_28to40`,
    SUM(IF(order_type='套票子票' AND age_range='41-60' AND sex='女', multiple, 0))                  AS `no_mo_female_age_41to60`,
    SUM(IF(order_type='套票子票' AND age_range='61+'   AND sex='女', multiple, 0))                  AS `no_mo_female_age_61plus`,

    SUM(IF(order_type='套票子票' AND (age_range='-1' OR age_range IS NULL OR age_range=''), multiple, 0))                        
                                                                                                   AS `no_mo_unknown`,          
    SUM(IF(order_type='套票子票', multiple, 0))                                                     AS `no_mo_total`, 

    YEAR(`date`)                                                                                    AS `year`,
    YEAR(`date`) * 100 + MONTH(`date`)                                                              AS `month`,
    INT(isoweek)                                                                                    AS `week`,
    INT(orderdate)                                                                                  AS `fulldate`															 
FROM 
(
    SELECT 
        lid,
        title, 
        apply_did,       
        p_type,
        pid,
        tid,
        sex,
        -- 年龄范围
        CASE
            WHEN age BETWEEN 0 AND 7
            THEN '0-7'
            WHEN age BETWEEN 8 AND 17
            THEN '8-17'
            WHEN age BETWEEN 18 AND 27
            THEN '18-27'
            WHEN age BETWEEN 28 AND 40
            THEN '28-40'
            WHEN age BETWEEN 41 AND 60
            THEN '41-60'
			WHEN age BETWEEN 61 AND 122 
            THEN '61+'
            ELSE '-1'
        END 	AS age_range,
        orderdate,
        dim_isoweek.isoweek,
        dim_isoweek.date,
        country,
        province,
        multiple,
        order_type
    FROM 
    (
        SELECT 
            apply_did, 
            sex, 
            age, 
            orderdate, 
            country_name        AS country,
            province_name       AS province,
            lid, 
            pid, 
            tid, 
            multiple,
            order_type
        FROM dwd_tourist_info_d_i
        WHERE orderdate = "${ds}"
    ) AS order_tourist
    LEFT JOIN 
    (
        SELECT id, title, p_type
        FROM ods_land_d_f
        WHERE pt = DATE_FORMAT(DATE_SUB(CURRENT_DATE(), 1),"yyyyMMdd")
    ) AS landTab 
    ON order_tourist.lid = landTab.id
    LEFT JOIN dim_date_isoweek_o_f AS dim_isoweek 
    ON order_tourist.orderdate = dim_isoweek.`fulldate`
)
GROUP BY  
    lid, 
    title,
    apply_did,
    p_type,
    pid,
    tid,
    isoweek,
    date,
    country,
    province,
    orderdate;