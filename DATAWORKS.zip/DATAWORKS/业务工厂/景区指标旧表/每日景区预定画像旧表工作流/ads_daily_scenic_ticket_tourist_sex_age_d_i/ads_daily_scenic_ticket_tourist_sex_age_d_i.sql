-- name ads_daily_scenic_ticket_tourist_sex_age_d_i
-- type Spark SQL
-- author liangleichen@12301.cc
-- create time 2024-11-08 10:13:50
-- desc 每日-预定-票-性别年龄-主子单人数指标表

SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;

CREATE TABLE IF NOT EXISTS ads_daily_scenic_ticket_tourist_sex_age_d_i(
    `land_id`		                INT		COMMENT '景区ID',
    `land_name`			            STRING	COMMENT '景区名称',
    `sid`                       INT     COMMENT '原始供应商id',
    `p_type`                    STRING  COMMENT '景区类型：A景区B线路C酒店F套票',
    `pid`                       INT     COMMENT '产品id',
    `ticket_id`                 INT     COMMENT '票ID',

    `mo_male_age_0to7`          INT     COMMENT '主单男性且年龄范围0-7',   
    `mo_male_age_8to17`         INT     COMMENT '主单男性且年龄范围8-17', 
    `mo_male_age_18to27`        INT     COMMENT '主单男性且年龄范围18-27', 
    `mo_male_age_28to40`        INT     COMMENT '主单男性且年龄范围28-40', 
    `mo_male_age_41to60`        INT     COMMENT '主单男性且年龄范围41-60', 
    `mo_male_age_61plus`        INT     COMMENT '主单男性且年龄范围>60',  
    `mo_female_age_0to7`        INT     COMMENT '主单女性且年龄范围0-7', 
    `mo_female_age_8to17`       INT     COMMENT '主单女性且年龄范围8-17', 
    `mo_female_age_18to27`      INT     COMMENT '主单女性且年龄范围18-27', 
    `mo_female_age_28to40`      INT     COMMENT '主单女性且年龄范围28-40', 
    `mo_female_age_41to60`      INT     COMMENT '主单女性且年龄范围41-60', 
    `mo_female_age_61plus`      INT     COMMENT '主单女性且年龄范围>60', 
    `mo_unknown`                INT     COMMENT '主单性别年龄未知',
    `mo_total`                  INT     COMMENT '主单总人数',

    `no_mo_male_age_0to7`       INT     COMMENT '子单男性且年龄范围0-7',   
    `no_mo_male_age_8to17`      INT     COMMENT '子单男性且年龄范围8-17', 
    `no_mo_male_age_18to27`     INT     COMMENT '子单男性且年龄范围18-27', 
    `no_mo_male_age_28to40`     INT     COMMENT '子单男性且年龄范围28-40', 
    `no_mo_male_age_41to60`     INT     COMMENT '子单男性且年龄范围41-60', 
    `no_mo_male_age_61plus`     INT     COMMENT '子单男性且年龄范围>60',  
    `no_mo_female_age_0to7`     INT     COMMENT '子单女性且年龄范围0-7', 
    `no_mo_female_age_8to17`    INT     COMMENT '子单女性且年龄范围8-17', 
    `no_mo_female_age_18to27`   INT     COMMENT '子单女性且年龄范围18-27', 
    `no_mo_female_age_28to40`   INT     COMMENT '子单女性且年龄范围28-40', 
    `no_mo_female_age_41to60`   INT     COMMENT '子单女性且年龄范围41-60', 
    `no_mo_female_age_61plus`   INT     COMMENT '子单女性且年龄范围>60', 
    `no_mo_unknown`             INT     COMMENT '子单性别年龄未知',
    `no_mo_total`               INT     COMMENT '子单总人数',    

  	`year` 				              INT	    COMMENT '年',
  	`month` 			              INT	    COMMENT '月',
  	`week` 				              INT	    COMMENT '年周'
)COMMENT '每日-预定-票-性别年龄-主子单人数指标表'
PARTITIONED BY (`fulldate`  INT   	COMMENT '全日期')
STORED AS ORC;


INSERT OVERWRITE TABLE ads_daily_scenic_ticket_tourist_sex_age_d_i PARTITION(fulldate)
SELECT	
    `land_id`,
    `land_name`,
    `sid`,
    `p_type`,
    `pid`,
    `ticket_id`,

    SUM(`mo_male_age_0to7`)         AS `mo_male_age_0to7`,
    SUM(`mo_male_age_8to17`)        AS `mo_male_age_8to17`,
    SUM(`mo_male_age_18to27`)       AS `mo_male_age_18to27`,
    SUM(`mo_male_age_28to40`)       AS `mo_male_age_28to40`,
    SUM(`mo_male_age_41to60`)       AS `mo_male_age_41to60`,
    SUM(`mo_male_age_61plus`)       AS `mo_male_age_61plus`,
    SUM(`mo_female_age_0to7`)       AS `mo_female_age_0to7`,
    SUM(`mo_female_age_8to17`)      AS `mo_female_age_8to17`,
    SUM(`mo_female_age_18to27`)     AS `mo_female_age_18to27`,
    SUM(`mo_female_age_28to40`)     AS `mo_female_age_28to40`,
    SUM(`mo_female_age_41to60`)     AS `mo_female_age_41to60`,
    SUM(`mo_female_age_61plus`)     AS `mo_female_age_61plus`,
    SUM(`mo_unknown`)               AS `mo_unknown`,
    SUM(`mo_total`)                 AS `mo_total`,

    SUM(`no_mo_male_age_0to7`)      AS `no_mo_male_age_0to7`,
    SUM(`no_mo_male_age_8to17`)     AS `no_mo_male_age_8to17`,
    SUM(`no_mo_male_age_18to27`)    AS `no_mo_male_age_18to27`,
    SUM(`no_mo_male_age_28to40`)    AS `no_mo_male_age_28to40`,
    SUM(`no_mo_male_age_41to60`)    AS `no_mo_male_age_41to60`,
    SUM(`no_mo_male_age_61plus`)    AS `no_mo_male_age_61plus`,
    SUM(`no_mo_female_age_0to7`)    AS `no_mo_female_age_0to7`,
    SUM(`no_mo_female_age_8to17`)   AS `no_mo_female_age_8to17`,
    SUM(`no_mo_female_age_18to27`)  AS `no_mo_female_age_18to27`,
    SUM(`no_mo_female_age_28to40`)  AS `no_mo_female_age_28to40`,
    SUM(`no_mo_female_age_41to60`)  AS `no_mo_female_age_41to60`,
    SUM(`no_mo_female_age_61plus`)  AS `no_mo_female_age_61plus`,
    SUM(`no_mo_unknown`)            AS `no_mo_unknown`,
    SUM(`no_mo_total`)              AS `no_mo_total`,

  	`year`,
  	`month`,
  	`week`,
    `fulldate`
FROM ads_daily_scenic_ticket_province_sex_age_d_i
WHERE fulldate = "${ds}"
GROUP BY 
    `land_id`,		 
    `land_name`,	
    `sid`,        
    `p_type`,     
    `pid`,        
    `ticket_id`,  
    `year`, 
    `month`,
    `week`, 
    `fulldate`;

