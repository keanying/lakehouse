-- name ads_daily_scenic_ticket_tourist_location_d_i
-- type Spark SQL
-- author liangleichen@12301.cc
-- create time 2024-11-07 10:19:53
-- desc 每日-预定-票-省市-主子单人数指标表

SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;

CREATE TABLE IF NOT EXISTS ads_daily_scenic_ticket_tourist_location_d_i(
    `land_id`		        INT		COMMENT '景区ID',
    `land_name`			    STRING	COMMENT '景区名称',
    `sid`		            INT		COMMENT '原始供应商id',
    `p_type`                STRING  COMMENT '景区类型：A景区B线路C酒店F套票',
    `pid`                   INT     COMMENT '产品id',
    `ticket_id`             INT     COMMENT '票ID',

    `country`			    STRING	COMMENT '统计国家',
    `province`			    STRING	COMMENT '统计省',
    `city`			        STRING	COMMENT '统计市',

    `mo_tourist_count`      INT	    COMMENT '主单今日游客数',
    `no_mo_tourist_count`   INT	    COMMENT '子单今日游客数',

  	`year` 				    INT	    COMMENT '年',
  	`month` 			    INT	    COMMENT '月',
  	`week` 				    INT	    COMMENT '年周'
)COMMENT '每日-预定-票-省市-主子单人数指标表'
PARTITIONED BY (`fulldate`  INT   	COMMENT '全日期')
STORED AS ORC;


INSERT OVERWRITE TABLE ads_daily_scenic_ticket_tourist_location_d_i PARTITION(fulldate)
SELECT	
    lid 			                    AS `land_id`,
    land_name		                    AS `land_name`,
    apply_did                           AS `sid`,
    p_type                              AS `p_type`,
    pid                                 AS `pid`,
    ticket_id                           AS `ticket_id`,
    country                             AS `country`,
    province                            AS `province`,
    city                                AS `city`,
    -- 主单        
    SUM(IF(order_type IN ('单票', '套票主票'), multiple, 0))        AS `mo_tourist_count`, 
    -- 子单     
    SUM(IF(order_type='套票子票', multiple, 0))                     AS `no_mo_tourist_count`, 
    YEAR(`date`)                                                   AS `year`,
    YEAR(`date`) * 100 + MONTH(`date`)                             AS `month`,
    INT(isoweek)                                                   AS `week`,
    INT(orderdate)                                                 AS `fulldate`																		 
FROM 
(
    SELECT 
        lid,
        land_name, 
        apply_did,       
        p_type,
        pid,
        ticket_id ,
        orderdate,
        isoweek,
        date,
        country,
        province,
        city,
        multiple,
        order_type
    FROM 
    (
        SELECT 
            apply_did, 
            orderdate, 
            country_name    AS country,
            province_name   AS province,
            city_name       AS city,
            lid, 
            pid, 
            tid             AS ticket_id, 
            multiple,
            order_type
        FROM dwd_tourist_info_d_i
        WHERE orderdate = "${ds}"
    ) AS order_tourist
    LEFT JOIN 
    (
        SELECT id, title AS land_name, p_type
        FROM ods_land_d_f
        WHERE pt = DATE_FORMAT(DATE_SUB(CURRENT_DATE(), 1),"yyyyMMdd")
    ) AS land_tab 
    ON order_tourist.lid = land_tab.id
    LEFT JOIN dim_date_isoweek_o_f AS dim_isoweek 
    ON order_tourist.orderdate = dim_isoweek.`fulldate`
)
GROUP BY  
    lid, 
    land_name,
    apply_did,
    p_type,
    pid,
    ticket_id,
    isoweek,
    date,
    country,
    province,
    city,
    orderdate;

