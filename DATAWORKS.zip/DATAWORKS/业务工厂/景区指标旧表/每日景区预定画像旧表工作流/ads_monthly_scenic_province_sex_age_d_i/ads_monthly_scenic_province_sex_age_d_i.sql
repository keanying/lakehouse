-- name ads_monthly_scenic_province_sex_age_d_i
-- type Spark SQL
-- author liangleichen@12301.cc
-- create time 2024-11-06 14:56:06
-- desc 每月-预定-省-性别年龄-主子单人数指标表

SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;

CREATE TABLE IF NOT EXISTS ads_monthly_scenic_province_sex_age_d_i(
    `land_id`		            INT		COMMENT '景区ID',
    `land_name`			        STRING	COMMENT '景区名称',
    `sid`                       INT     COMMENT '原始供应商id',
    `p_type`                    STRING  COMMENT '景区类型：A景区B线路C酒店F套票',
    `country`			        STRING	COMMENT '统计国家',
    `province`			        STRING	COMMENT '统计省',

    `male_age_0to7`             INT     COMMENT '男性且年龄范围0-7',   
    `male_age_8to17`            INT     COMMENT '男性且年龄范围8-17', 
    `male_age_18to27`           INT     COMMENT '男性且年龄范围18-27', 
    `male_age_28to40`           INT     COMMENT '男性且年龄范围28-40', 
    `male_age_41to60`           INT     COMMENT '男性且年龄范围41-60', 
    `male_age_61plus`           INT     COMMENT '男性且年龄范围>60',  
    `female_age_0to7`           INT     COMMENT '女性且年龄范围0-7', 
    `female_age_8to17`          INT     COMMENT '女性且年龄范围8-17', 
    `female_age_18to27`         INT     COMMENT '女性且年龄范围18-27', 
    `female_age_28to40`         INT     COMMENT '女性且年龄范围28-40', 
    `female_age_41to60`         INT     COMMENT '女性且年龄范围41-60', 
    `female_age_61plus`         INT     COMMENT '女性且年龄范围>60', 
    `unknown`                   INT     COMMENT '性别年龄未知',
    `total`                     INT     COMMENT '总人数',    

    `mo_male_age_0to7`          INT     COMMENT '主单男性且年龄范围0-7',   
    `mo_male_age_8to17`         INT     COMMENT '主单男性且年龄范围8-17', 
    `mo_male_age_18to27`        INT     COMMENT '主单男性且年龄范围18-27', 
    `mo_male_age_28to40`        INT     COMMENT '主单男性且年龄范围28-40', 
    `mo_male_age_41to60`        INT     COMMENT '主单男性且年龄范围41-60', 
    `mo_male_age_61plus`        INT     COMMENT '主单男性且年龄范围>60',  
    `mo_female_age_0to7`        INT     COMMENT '主单女性且年龄范围0-7', 
    `mo_female_age_8to17`       INT     COMMENT '主单女性且年龄范围8-17', 
    `mo_female_age_18to27`      INT     COMMENT '主单女性且年龄范围18-27', 
    `mo_female_age_28to40`      INT     COMMENT '主单女性且年龄范围28-40', 
    `mo_female_age_41to60`      INT     COMMENT '主单女性且年龄范围41-60', 
    `mo_female_age_61plus`      INT     COMMENT '主单女性且年龄范围>60', 
    `mo_unknown`                INT     COMMENT '主单性别年龄未知',
    `mo_total`                  INT     COMMENT '主单总人数',

    `no_mo_male_age_0to7`       INT     COMMENT '子单男性且年龄范围0-7',   
    `no_mo_male_age_8to17`      INT     COMMENT '子单男性且年龄范围8-17', 
    `no_mo_male_age_18to27`     INT     COMMENT '子单男性且年龄范围18-27', 
    `no_mo_male_age_28to40`     INT     COMMENT '子单男性且年龄范围28-40', 
    `no_mo_male_age_41to60`     INT     COMMENT '子单男性且年龄范围41-60', 
    `no_mo_male_age_61plus`     INT     COMMENT '子单男性且年龄范围>60',  
    `no_mo_female_age_0to7`     INT     COMMENT '子单女性且年龄范围0-7', 
    `no_mo_female_age_8to17`    INT     COMMENT '子单女性且年龄范围8-17', 
    `no_mo_female_age_18to27`   INT     COMMENT '子单女性且年龄范围18-27', 
    `no_mo_female_age_28to40`   INT     COMMENT '子单女性且年龄范围28-40', 
    `no_mo_female_age_41to60`   INT     COMMENT '子单女性且年龄范围41-60', 
    `no_mo_female_age_61plus`   INT     COMMENT '子单女性且年龄范围>60', 
    `no_mo_unknown`             INT     COMMENT '子单性别年龄未知',
    `no_mo_total`               INT     COMMENT '子单总人数',    

  	`year` 				        INT	    COMMENT '年'
)COMMENT '每月-预定-省-性别年龄-主子单人数指标表'
PARTITIONED BY (`month`         INT	    COMMENT '月')
STORED AS ORC;


INSERT OVERWRITE TABLE ads_monthly_scenic_province_sex_age_d_i PARTITION(`month`)
SELECT	
    `land_id`,
    MAX(`land_name`)                AS `land_name`,
    `sid`,
    `p_type`,
    `country`,
    `province`,
    
    SUM(`male_age_0to7`)            AS `male_age_0to7`,    
    SUM(`male_age_8to17`)           AS `male_age_8to17`,   
    SUM(`male_age_18to27`)          AS `male_age_18to27`,  
    SUM(`male_age_28to40`)          AS `male_age_28to40`,  
    SUM(`male_age_41to60`)          AS `male_age_41to60`,  
    SUM(`male_age_61plus`)          AS `male_age_61plus`,  
    SUM(`female_age_0to7`)          AS `female_age_0to7`,  
    SUM(`female_age_8to17`)         AS `female_age_8to17`, 
    SUM(`female_age_18to27`)        AS `female_age_18to27`,
    SUM(`female_age_28to40`)        AS `female_age_28to40`,
    SUM(`female_age_41to60`)        AS `female_age_41to60`,
    SUM(`female_age_61plus`)        AS `female_age_61plus`,
    SUM(`unknown`)                  AS `unknown`,          
    SUM(`total`)                    AS `total`, 

    -- 主单
    SUM(`mo_male_age_0to7`)         AS `mo_male_age_0to7`,    
    SUM(`mo_male_age_8to17`)        AS `mo_male_age_8to17`,   
    SUM(`mo_male_age_18to27`)       AS `mo_male_age_18to27`,  
    SUM(`mo_male_age_28to40`)       AS `mo_male_age_28to40`,  
    SUM(`mo_male_age_41to60`)       AS `mo_male_age_41to60`,  
    SUM(`mo_male_age_61plus`)       AS `mo_male_age_61plus`,  
    SUM(`mo_female_age_0to7`)       AS `mo_female_age_0to7`,  
    SUM(`mo_female_age_8to17`)      AS `mo_female_age_8to17`, 
    SUM(`mo_female_age_18to27`)     AS `mo_female_age_18to27`,
    SUM(`mo_female_age_28to40`)     AS `mo_female_age_28to40`,
    SUM(`mo_female_age_41to60`)     AS `mo_female_age_41to60`,
    SUM(`mo_female_age_61plus`)     AS `mo_female_age_61plus`,
    SUM(`mo_unknown`)               AS `mo_unknown`,          
    SUM(`mo_total`)                 AS `mo_total`, 

    -- 子单
    SUM(`no_mo_male_age_0to7`)      AS `no_mo_male_age_0to7`,    
    SUM(`no_mo_male_age_8to17`)     AS `no_mo_male_age_8to17`,   
    SUM(`no_mo_male_age_18to27`)    AS `no_mo_male_age_18to27`,  
    SUM(`no_mo_male_age_28to40`)    AS `no_mo_male_age_28to40`,  
    SUM(`no_mo_male_age_41to60`)    AS `no_mo_male_age_41to60`,  
    SUM(`no_mo_male_age_61plus`)    AS `no_mo_male_age_61plus`,  
    SUM(`no_mo_female_age_0to7`)    AS `no_mo_female_age_0to7`,  
    SUM(`no_mo_female_age_8to17`)   AS `no_mo_female_age_8to17`, 
    SUM(`no_mo_female_age_18to27`)  AS `no_mo_female_age_18to27`,
    SUM(`no_mo_female_age_28to40`)  AS `no_mo_female_age_28to40`,
    SUM(`no_mo_female_age_41to60`)  AS `no_mo_female_age_41to60`,
    SUM(`no_mo_female_age_61plus`)  AS `no_mo_female_age_61plus`,
    SUM(`no_mo_unknown`)            AS `no_mo_unknown`,          
    SUM(`no_mo_total`)              AS `no_mo_total`, 

    `year`,
    `month`
FROM ads_daily_scenic_province_sex_age_d_i
WHERE SUBSTR(`fulldate`, 0, 6) = SUBSTR('${ds}', 0, 6)
GROUP BY 
    `land_id`,
    `sid`,
    `p_type`,
    `country`,
    `province`,
    `year`,
    `month`;

