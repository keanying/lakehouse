--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-21 14:57:06
--EMR任务只能运行在独享资源组上
--********************************************************************--
-- name ads_two_s_company_day_stat_d_i_f
-- type Spark SQL
-- author liangleichen@12301.cc
-- create time 2022-11-09 17:14:03
-- desc 商户_各种维度下_订单量/金额统计
-- 营销订单量       all_dis_order_paid_count
-- 营销订单金额     all_dis_order_paid_amount
-- 直接订单量       all_dis_direct_order_paid_count
-- 直接订单金额     all_dis_direct_order_paid_amount
-- 自购订单量       all_dis_self_purchase_order_paid_count
-- 自购订单金额     all_dis_self_purchase_order_paid_amount
-- 产品营销订单数   paid_count
-- 营销员营销订单数 paid_amount


--------------------------------------------------------------------------------------------------


CREATE TABLE IF NOT EXISTS ads_two_s_company_day_stat_d_i(
    `sid`               INT     COMMENT '商户ID',
    `year`              INT     COMMENT '年',
    `month`             INT     COMMENT '月',
    `week`              STRING  COMMENT '周',
    `day`               INT     COMMENT '日',
    `date`              STRING  COMMENT '全日期',
    `dimension_type`    STRING  COMMENT '维度类型',
    `dimension_value`   STRING  COMMENT '维度值',
    `key`               STRING  COMMENT '键',
    `value`             INT     COMMENT '值',
    `payload`           STRING  COMMENT '扩展字段'
)PARTITIONED BY(
    pt                  STRING  COMMENT  '更新数据截止时间'
)STORED AS ORC;



-------------------------------------------------fullDose-------------------------------------------------


-- 商户维度
INSERT OVERWRITE TABLE ads_two_s_company_day_stat_d_i PARTITION(pt = ${ds} )
-- 营销订单量
SELECT 
    tmp_table.sid                   AS `sid`,
    YEAR(tmp_table.`date`)          AS `year`,
    MONTH(tmp_table.`date`)         AS `month`,
    dim_isoweek.isoweek   			AS `week`,
    DAY(tmp_table.`date`)           AS `day`,
    tmp_table.`date`                AS `date`,
    'default'                       AS `dimension_type`,
    ''                              AS `dimension_value`,
    'all_dis_order_paid_count'      AS `key`,
    COUNT(*)                        AS `value`,
    '{}'                            AS `payload`   
FROM 
(
    SELECT
        sid,
        from_unixtime(create_time, 'yyyy-MM-dd') AS `date`
    FROM ods_pft002_pft_all_dis_orders_d_f AS orders_table
    INNER JOIN 
	(
        SELECT member_id
        FROM ods_c_member_authorize_d_f
        WHERE pt = ${ds} 
			AND run_fullDose_or_increment = 'fullDose'
    ) AS need_member_table
    ON orders_table.sid = need_member_table.member_id
    WHERE orders_table.pt = ${ds}  
		AND orders_table.order_pay_status = 1 
) AS tmp_table
LEFT JOIN dim_date_isoweek_o_f AS dim_isoweek
ON tmp_table.`date` = dim_isoweek.`date`
WHERE tmp_table.`date` >= '2021-01-01'
GROUP BY tmp_table.sid, tmp_table.`date`, dim_isoweek.isoweek

--营销订单金额    
UNION ALL
SELECT 
    tmp_table.sid                	AS `sid`,
    YEAR(tmp_table.`date`)       	AS `year`,
    MONTH(tmp_table.`date`)      	AS `month`,
    dim_isoweek.isoweek   			AS `week`,
    DAY(tmp_table.`date`)        	AS `day`,
    tmp_table.`date`             	AS `date`,
    'default'                    	AS `dimension_type`,
    ''                           	AS `dimension_value`,
    'all_dis_order_paid_amount'  	AS `key`,
    SUM(total_money)             	AS `value`,
    '{}'                         	AS `payload`   
FROM 
(
    SELECT
        sid,
        total_money,
        FROM_UNIXTIME(create_time, 'yyyy-MM-dd') AS `date`
    FROM ods_pft002_pft_all_dis_orders_d_f AS orders_table
    INNER JOIN 
	(
        SELECT member_id
        FROM ods_c_member_authorize_d_f
        WHERE pt = ${ds}
			AND run_fullDose_or_increment='fullDose'
    ) AS need_member_table
    ON orders_table.sid = need_member_table.member_id
    WHERE pt = ${ds} 
		AND order_pay_status = 1 
) AS tmp_table
LEFT JOIN dim_date_isoweek_o_f AS dim_isoweek
ON tmp_table.`date` = dim_isoweek.`date`
WHERE tmp_table.`date` >= '2021-01-01'
GROUP BY tmp_table.sid, tmp_table.`date`, dim_isoweek.isoweek

UNION ALL 

--直接订单量
SELECT 
    tmp_table.sid                       AS `sid`,
    YEAR(tmp_table.`date`)              AS `year`,
    MONTH(tmp_table.`date`)             AS `month`,
    dim_isoweek.isoweek   				AS `week`,
    DAY(tmp_table.`date`)               AS `day`,
    tmp_table.`date`                    AS `date`,
    'default'                           AS `dimension_type`,
    ''                                  AS `dimension_value`,
    'all_dis_direct_order_paid_count'   AS `key`,
    COUNT(*)                            AS `value`,
    '{}'                                AS `payload`   
FROM 
(
    SELECT
        sid,
        FROM_UNIXTIME(create_time, 'yyyy-MM-dd') AS `date`
    FROM ods_pft002_pft_all_dis_orders_d_f AS orders_table
    INNER JOIN 
	(
        SELECT member_id
        FROM ods_c_member_authorize_d_f
        WHERE pt = ${ds} 
			AND run_fullDose_or_increment='fullDose'
    ) AS need_member_table
    ON orders_table.sid = need_member_table.member_id
    WHERE pt = ${ds}
		AND is_self = 0 
		AND order_pay_status = 1
) AS tmp_table
LEFT JOIN dim_date_isoweek_o_f AS dim_isoweek
ON tmp_table.`date` = dim_isoweek.`date`
WHERE tmp_table.`date` >= '2021-01-01'
GROUP BY tmp_table.sid, tmp_table.`date`, dim_isoweek.isoweek

--直接订单金额
UNION ALL 
SELECT 
    tmp_table.sid                       AS `sid`,
    YEAR(tmp_table.`date`)              AS `year`,
    MONTH(tmp_table.`date`)             AS `month`,
    dim_isoweek.isoweek   				AS `week`,
    DAY(tmp_table.`date`)               AS `day`,
    tmp_table.`date`                    AS `date`,
    'default'                           AS `dimension_type`,
    ''                                  AS `dimension_value`,
    'all_dis_direct_order_paid_amount'  AS `key`,
    SUM(total_money)                    AS `value`,
    '{}'                                AS `payload`   
FROM 
(
    SELECT
        sid,
        total_money,
        FROM_UNIXTIME(create_time, 'yyyy-MM-dd') AS `date`
    FROM ods_pft002_pft_all_dis_orders_d_f AS orders_table
    INNER JOIN 
	(
        SELECT member_id
        FROM ods_c_member_authorize_d_f
        WHERE pt = ${ds} 
			AND run_fullDose_or_increment='fullDose'
    ) AS need_member_table
    ON orders_table.sid = need_member_table.member_id
    WHERE pt = ${ds} 
		AND is_self = 0 
		AND order_pay_status = 1
)   AS  tmp_table
LEFT JOIN dim_date_isoweek_o_f AS dim_isoweek
ON tmp_table.`date` = dim_isoweek.`date`
WHERE tmp_table.`date` >= '2021-01-01'
GROUP BY tmp_table.sid, tmp_table.`date`, dim_isoweek.isoweek

--自购订单数
UNION ALL 
SELECT 
    tmp_table.sid                               AS `sid`,
    YEAR(tmp_table.`date`)                      AS `year`,
    MONTH(tmp_table.`date`)                     AS `month`,
    dim_isoweek.isoweek   						AS `week`,
    DAY(tmp_table.`date`)                       AS `day`,
    tmp_table.`date`                            AS `date`,
    'default'                                   AS `dimension_type`,
    ''                                          AS `dimension_value`,
    'all_dis_self_purchase_order_paid_count'    AS `key`,
    COUNT(*)                                    AS `value`,
    '{}'                                        AS `payload`   
FROM 
(
    SELECT
        sid,
        FROM_UNIXTIME(create_time, 'yyyy-MM-dd') AS `date`
    FROM ods_pft002_pft_all_dis_orders_d_f AS orders_table
    INNER JOIN 
	(
        SELECT member_id
        FROM ods_c_member_authorize_d_f
        WHERE pt = ${ds} 
			AND run_fullDose_or_increment='fullDose'
    ) AS need_member_table
    ON orders_table.sid = need_member_table.member_id
    WHERE pt = ${ds}  
		AND is_self = 1 
		AND order_pay_status = 1
) AS tmp_table
LEFT JOIN dim_date_isoweek_o_f AS dim_isoweek
ON tmp_table.`date` = dim_isoweek.`date`
WHERE tmp_table.`date` >= '2021-01-01'
GROUP BY tmp_table.sid, tmp_table.`date`, dim_isoweek.isoweek

--自购订单金额
UNION ALL 
SELECT 
    tmp_table.sid                               AS `sid`,
    YEAR(tmp_table.`date`)                      AS `year`,
    MONTH(tmp_table.`date`)                     AS `month`,
    dim_isoweek.isoweek   						AS `week`,
    DAY(tmp_table.`date`)                       AS `day`,
    tmp_table.`date`                            AS `date`,
    'default'                                   AS `dimension_type`,
    ''                                          AS `dimension_value`,
    'all_dis_self_purchase_order_paid_amount'   AS `key`,
    SUM(total_money)                            AS `value`,
    '{}'                                        AS `payload`   
FROM 
(
    SELECT
        sid,
        total_money,
        FROM_UNIXTIME(create_time, 'yyyy-MM-dd') AS `date`
    FROM ods_pft002_pft_all_dis_orders_d_f AS orders_table
    INNER JOIN 
	(
        SELECT member_id
        FROM ods_c_member_authorize_d_f
        WHERE pt = ${ds} 
			AND run_fullDose_or_increment='fullDose'
    ) AS need_member_table
    ON orders_table.sid = need_member_table.member_id
    WHERE pt = ${ds} 
		AND is_self = 1 
		AND order_pay_status = 1
) AS tmp_table
LEFT JOIN dim_date_isoweek_o_f AS dim_isoweek
ON tmp_table.`date` = dim_isoweek.`date`
WHERE tmp_table.`date` >= '2021-01-01'
GROUP BY tmp_table.sid, tmp_table.`date`, dim_isoweek.isoweek

--产品营销订单数
UNION ALL 
SELECT 
    tmp_table.sid                   AS `sid`,
    YEAR(tmp_table.`date`)          AS `year`,
    MONTH(tmp_table.`date`)         AS `month`,
    dim_isoweek.isoweek   			AS `week`,
    DAY(tmp_table.`date`)           AS `day`,
    tmp_table.`date`                AS `date`,
    'all_dis_product_order'         AS `dimension_type`,
    tmp_table.lid                   AS `dimension_value`,
    'paid_count'                    AS `key`,
    COUNT(*)                        AS `value`,
    tmp_table.`payload`             AS `payload`  
FROM 
(
    SELECT
        sid,
        lid,
        FROM_UNIXTIME(create_time, 'yyyy-MM-dd') AS `date`,
        NVL(CONCAT('{"product_id":', lid, ',"product_name":"', title, '"}'), '{}')  AS `payload` 
    FROM dwd_all_dis_orders_d_f AS orders_table
    INNER JOIN 
	(
        SELECT member_id
        FROM ods_c_member_authorize_d_f
        WHERE pt=${ds} 
			AND run_fullDose_or_increment='fullDose'
    ) AS need_member_table
    ON orders_table.sid = need_member_table.member_id
    WHERE pt = ${ds}
		AND order_pay_status = 1  
) AS tmp_table
LEFT JOIN dim_date_isoweek_o_f AS dim_isoweek
ON tmp_table.`date` = dim_isoweek.`date`
WHERE tmp_table.`date`  >= '2021-01-01'
GROUP BY 
    tmp_table.sid,
    tmp_table.lid,
    tmp_table.`date`,
    tmp_table.`payload`,
	dim_isoweek.isoweek

--营销员营销订单数
UNION ALL 
SELECT 
    tmp_table.sid                   AS `sid`,
    YEAR(tmp_table.`date`)          AS `year`,
    MONTH(tmp_table.`date`)         AS `month`,
    dim_isoweek.isoweek   			AS `week`,
    DAY(tmp_table.`date`)           AS `day`,
    tmp_table.`date`                AS `date`,
    'all_dis_member_order'          AS `dimension_type`,
    tmp_table.member_id             AS `dimension_value`,
    'paid_amount'                   AS `key`,
    COUNT(*)                        AS `value`,
    '{}'                            AS `payload`  
FROM 
(
    SELECT
        sid,
        dis_id,
        grand_id,
        parent_id,
        orders_table.member_id,
        FROM_UNIXTIME(create_time, 'yyyy-MM-dd') AS `date`
    FROM ods_pft002_pft_all_dis_orders_d_f AS orders_table
    INNER JOIN 
	(
        SELECT member_id
        FROM ods_c_member_authorize_d_f
        WHERE pt = ${ds} 
			AND run_fullDose_or_increment='fullDose'
    ) AS need_member_table
    ON orders_table.sid = need_member_table.member_id
    WHERE pt = ${ds} 
		AND order_pay_status = 1  
) AS tmp_table
LEFT JOIN dim_date_isoweek_o_f AS dim_isoweek
ON tmp_table.`date` = dim_isoweek.`date`
WHERE tmp_table.`date` >= '2021-01-01'
GROUP BY 
    tmp_table.sid,
    tmp_table.dis_id,
    tmp_table.grand_id,
    tmp_table.parent_id,
    tmp_table.member_id,
    tmp_table.`date`,
	dim_isoweek.isoweek;


-------------------------------------------------increment-------------------------------------------------


-- 商户维度
INSERT INTO TABLE ads_two_s_company_day_stat_d_i PARTITION(pt = ${ds})
-- 营销订单量
SELECT 
    tmp_table.sid                   AS `sid`,
    YEAR(tmp_table.`date`)          AS `year`,
    MONTH(tmp_table.`date`)         AS `month`,
    dim_isoweek.isoweek   			AS `week`,
    DAY(tmp_table.`date`)           AS `day`,
    tmp_table.`date`                AS `date`,
    'default'                       AS `dimension_type`,
    ''                              AS `dimension_value`,
    'all_dis_order_paid_count'      AS `key`,
    COUNT(*)                        AS `value`,
    '{}'                            AS `payload`   
FROM 
(
    SELECT
        sid,
        from_unixtime(create_time, 'yyyy-MM-dd') AS `date`
    FROM ods_pft002_pft_all_dis_orders_d_f AS orders_table
    INNER JOIN (
        SELECT member_id
        FROM ods_c_member_authorize_d_f
        WHERE pt = ${ds} 
			AND run_fullDose_or_increment='increment'
    ) AS need_member_table
    ON orders_table.sid = need_member_table.member_id
    WHERE orders_table.pt = ${ds} 
		AND orders_table.order_pay_status = 1 
) AS tmp_table
LEFT JOIN dim_date_isoweek_o_f AS dim_isoweek
ON tmp_table.`date` = dim_isoweek.`date`
WHERE tmp_table.`date` = FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd')
GROUP BY tmp_table.sid, tmp_table.`date`, dim_isoweek.isoweek

--营销订单金额    
UNION ALL
SELECT 
    tmp_table.sid                       AS `sid`,
    YEAR(tmp_table.`date`)              AS `year`,
    MONTH(tmp_table.`date`)             AS `month`,
    dim_isoweek.isoweek   				AS `week`,
    DAY(tmp_table.`date`)               AS `day`,
    tmp_table.`date`                    AS `date`,
    'default'                           AS `dimension_type`,
    ''                                  AS `dimension_value`,
    'all_dis_order_paid_amount'         AS `key`,
    SUM(total_money)                    AS `value`,
    '{}'                                AS `payload`   
FROM 
(
    SELECT
        sid,
        total_money,
        FROM_UNIXTIME(create_time, 'yyyy-MM-dd') AS `date`
    FROM ods_pft002_pft_all_dis_orders_d_f AS orders_table
    INNER JOIN 
	(
        SELECT member_id
        FROM ods_c_member_authorize_d_f
        WHERE pt = ${ds} 
			AND run_fullDose_or_increment='increment'
    ) AS need_member_table
    ON orders_table.sid = need_member_table.member_id
    WHERE pt = ${ds}
		AND order_pay_status = 1 
) AS tmp_table
LEFT JOIN dim_date_isoweek_o_f AS dim_isoweek
ON tmp_table.`date` = dim_isoweek.`date`
WHERE tmp_table.`date` = FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd')
GROUP BY tmp_table.sid, tmp_table.`date`, dim_isoweek.isoweek

UNION ALL 

--直接订单量
SELECT 
    tmp_table.sid                       AS `sid`,
    YEAR(tmp_table.`date`)              AS `year`,
    MONTH(tmp_table.`date`)             AS `month`,
    dim_isoweek.isoweek   				AS `week`,
    DAY(tmp_table.`date`)               AS `day`,
    tmp_table.`date`                    AS `date`,
    'default'                           AS `dimension_type`,
    ''                                  AS `dimension_value`,
    'all_dis_direct_order_paid_count'   AS `key`,
    COUNT(*)                            AS `value`,
    '{}'                                AS `payload`   
FROM 
(
    SELECT
        sid,
        FROM_UNIXTIME(create_time, 'yyyy-MM-dd') AS `date`
    FROM ods_pft002_pft_all_dis_orders_d_f AS orders_table
    INNER JOIN 
	(
        SELECT member_id
        FROM ods_c_member_authorize_d_f
        WHERE pt = ${ds} 
			AND run_fullDose_or_increment='increment'
    ) AS need_member_table
    ON orders_table.sid = need_member_table.member_id
    WHERE pt = ${ds} 
		AND is_self = 0 
		AND order_pay_status = 1
) AS tmp_table
LEFT JOIN dim_date_isoweek_o_f AS dim_isoweek
ON tmp_table.`date` = dim_isoweek.`date`
WHERE tmp_table.`date` = FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd')
GROUP BY tmp_table.sid, tmp_table.`date`, dim_isoweek.isoweek

--直接订单金额
UNION ALL 
SELECT 
    tmp_table.sid                       AS `sid`,
    YEAR(tmp_table.`date`)              AS `year`,
    MONTH(tmp_table.`date`)             AS `month`,
    dim_isoweek.isoweek   				AS `week`,
    DAY(tmp_table.`date`)               AS `day`,
    tmp_table.`date`                    AS `date`,
    'default'                           AS `dimension_type`,
    ''                                  AS `dimension_value`,
    'all_dis_direct_order_paid_amount'  AS `key`,
    SUM(total_money)                    AS `value`,
    '{}'                                AS `payload`   
FROM 
(
    SELECT
        sid,
        total_money,
        FROM_UNIXTIME(create_time, 'yyyy-MM-dd') AS `date`
    FROM ods_pft002_pft_all_dis_orders_d_f AS orders_table
    INNER JOIN 
	(
        SELECT member_id
        FROM ods_c_member_authorize_d_f
        WHERE pt = ${ds} 
			AND run_fullDose_or_increment='increment'
    ) AS need_member_table
    ON orders_table.sid = need_member_table.member_id
    WHERE pt = ${ds} 
		AND is_self = 0 
		AND order_pay_status = 1
)   AS  tmp_table
LEFT JOIN dim_date_isoweek_o_f AS dim_isoweek
ON tmp_table.`date` = dim_isoweek.`date`
WHERE tmp_table.`date` = FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd')
GROUP BY tmp_table.sid, tmp_table.`date`, dim_isoweek.isoweek

--自购订单数
UNION ALL 
SELECT 
    tmp_table.sid                               AS `sid`,
    YEAR(tmp_table.`date`)                      AS `year`,
    MONTH(tmp_table.`date`)                     AS `month`,
    dim_isoweek.isoweek   						AS `week`,
    DAY(tmp_table.`date`)                       AS `day`,
    tmp_table.`date`                            AS `date`,
    'default'                                   AS `dimension_type`,
    ''                                          AS `dimension_value`,
    'all_dis_self_purchase_order_paid_count'    AS `key`,
    COUNT(*)                                    AS `value`,
    '{}'                                        AS `payload`   
FROM 
(
    SELECT
        sid,
        FROM_UNIXTIME(create_time, 'yyyy-MM-dd') AS `date`
    FROM ods_pft002_pft_all_dis_orders_d_f AS orders_table
    INNER JOIN 
	(
        SELECT member_id
        FROM ods_c_member_authorize_d_f
        WHERE pt = ${ds} 
			AND run_fullDose_or_increment='increment'
    ) AS need_member_table
    ON orders_table.sid = need_member_table.member_id
    WHERE pt = ${ds}  
		AND is_self = 1 
		AND order_pay_status = 1
) AS tmp_table
LEFT JOIN dim_date_isoweek_o_f AS dim_isoweek
ON tmp_table.`date` = dim_isoweek.`date`
WHERE tmp_table.`date` = FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd')
GROUP BY tmp_table.sid, tmp_table.`date`, dim_isoweek.isoweek

--自购订单金额
UNION ALL 
SELECT 
    tmp_table.sid                               AS `sid`,
    YEAR(tmp_table.`date`)                      AS `year`,
    MONTH(tmp_table.`date`)                     AS `month`,
    dim_isoweek.isoweek   						AS `week`,
    DAY(tmp_table.`date`)                       AS `day`,
    tmp_table.`date`                            AS `date`,
    'default'                                   AS `dimension_type`,
    ''                                          AS `dimension_value`,
    'all_dis_self_purchase_order_paid_amount'   AS `key`,
    SUM(total_money)                            AS `value`,
    '{}'                                        AS `payload`   
FROM 
(
    SELECT
        sid,
        total_money,
        FROM_UNIXTIME(create_time, 'yyyy-MM-dd') AS `date`
    FROM ods_pft002_pft_all_dis_orders_d_f AS orders_table
    INNER JOIN 
	(
        SELECT member_id
        FROM ods_c_member_authorize_d_f
        WHERE pt = ${ds} 
			AND run_fullDose_or_increment='increment'
    ) AS need_member_table
    ON orders_table.sid = need_member_table.member_id
    WHERE pt = ${ds} 
		AND is_self = 1 
		AND order_pay_status = 1
) AS tmp_table
LEFT JOIN dim_date_isoweek_o_f AS dim_isoweek
ON tmp_table.`date` = dim_isoweek.`date`
WHERE tmp_table.`date` = FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd')
GROUP BY tmp_table.sid, tmp_table.`date`, dim_isoweek.isoweek

--产品营销订单数
UNION ALL 
SELECT 
    tmp_table.sid                   AS `sid`,
    YEAR(tmp_table.`date`)          AS `year`,
    MONTH(tmp_table.`date`)         AS `month`,
    dim_isoweek.isoweek   			AS `week`,
    DAY(tmp_table.`date`)           AS `day`,
    tmp_table.`date`                AS `date`,
    'all_dis_product_order'         AS `dimension_type`,
    tmp_table.lid                   AS `dimension_value`,
    'paid_count'                    AS `key`,
    COUNT(*)                        AS `value`,
    tmp_table.`payload`             AS `payload`  
FROM 
(
    SELECT
        sid,
        lid,
        FROM_UNIXTIME(create_time, 'yyyy-MM-dd') AS `date`,
        NVL(CONCAT('{"product_id":', lid, ',"product_name":"', title, '"}'), '{}')  AS `payload` 
    FROM dwd_all_dis_orders_d_f AS orders_table
    INNER JOIN 
	(
        SELECT member_id
        FROM ods_c_member_authorize_d_f
        WHERE pt=${ds} 
			AND run_fullDose_or_increment='increment'
    ) AS need_member_table
    ON orders_table.sid = need_member_table.member_id
    WHERE pt = ${ds} 
		AND order_pay_status = 1  
) AS tmp_table
LEFT JOIN dim_date_isoweek_o_f AS dim_isoweek
ON tmp_table.`date` = dim_isoweek.`date`
WHERE tmp_table.`date` = FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd')
GROUP BY 
    tmp_table.sid,
    tmp_table.lid,
    tmp_table.`date`,
    tmp_table.`payload`, 
	dim_isoweek.isoweek

--营销员营销订单数
UNION ALL 
SELECT 
    tmp_table.sid                   AS `sid`,
    YEAR(tmp_table.`date`)          AS `year`,
    MONTH(tmp_table.`date`)         AS `month`,
    dim_isoweek.isoweek   			AS `week`,
    DAY(tmp_table.`date`)           AS `day`,
    tmp_table.`date`                AS `date`,
    'all_dis_member_order'          AS `dimension_type`,
    tmp_table.member_id             AS `dimension_value`,
    'paid_amount'                   AS `key`,
    COUNT(*)                        AS `value`,
    '{}'                            AS `payload`  
FROM 
(
    SELECT
        sid,
        dis_id,
        grand_id,
        parent_id,
        orders_table.member_id,
        FROM_UNIXTIME(create_time, 'yyyy-MM-dd') AS `date`
    FROM ods_pft002_pft_all_dis_orders_d_f AS orders_table
    INNER JOIN 
	(
        SELECT member_id
        FROM ods_c_member_authorize_d_f
        WHERE pt=${ds} 
			AND run_fullDose_or_increment='increment'
    ) AS need_member_table
    ON orders_table.sid = need_member_table.member_id
    WHERE pt = ${ds} 
		AND order_pay_status = 1  
) AS tmp_table
LEFT JOIN dim_date_isoweek_o_f AS dim_isoweek
ON tmp_table.`date` = dim_isoweek.`date`
WHERE tmp_table.`date` = FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd')
GROUP BY 
    tmp_table.sid,
    tmp_table.dis_id,
    tmp_table.grand_id,
    tmp_table.parent_id,
    tmp_table.member_id,
    tmp_table.`date`,
	dim_isoweek.isoweek;

