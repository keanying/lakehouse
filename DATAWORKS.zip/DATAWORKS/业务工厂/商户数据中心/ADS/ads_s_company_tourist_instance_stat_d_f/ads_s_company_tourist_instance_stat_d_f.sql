--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-21 14:54:44
--EMR任务只能运行在独享资源组上
--********************************************************************--
-- 指标内容：商户数据中心v1.12_商户/景区_预订游客性别年龄分布
-- 时间key：昨日/yesterday、本周/thisweek/、上周/lastweek、本年/thisyear、去年/lastyear
-- 必须计算全量数据

-- 1. 以预定游客信息宽表统计出的数据（性别+年龄）的人数
-- 2. 以分销宽表，计算（商户+时间范围）的票数总和
-- 3. 性别未知 + 年龄为-1 的结果，应该为第二步结果减去第一步各个结果

CREATE TABLE IF NOT EXISTS ads_s_company_tourist_instance_stat_d_f(
    `sid`           STRING	COMMENT '商户ID',
    `deadline`      STRING  COMMENT '统计日期',
    `time_range`    STRING  COMMENT '统计时间范围',
    `sex`           STRING  COMMENT '性别',
    `age`           INT     COMMENT '年龄',
    `count`         INT     COMMENT '人数'
)STORED AS ORC;

---------------------------------------------------------------------------------------------------------------------

-- 1. 缓存表, 开通服务的商户的游客数据
DROP VIEW IF EXISTS need_sid_tourist_base_info;
CACHE TABLE need_sid_tourist_base_info
AS
-- 分销商角度，每笔订单数据
SELECT sid, idcard_sex, idcard_age, pay_date
FROM 
(
    SELECT sid, idcard_sex, idcard_age, pay_date
    FROM dwd_order_tourist_info_d_i
) AS tourist_table
INNER JOIN 
(
    -- 需要计算的商户
    SELECT member_id
    FROM ods_c_member_authorize_d_f
    WHERE pt = ${ds}
      AND land_id IS NULL 
) AS need_member_table
ON tourist_table.sid = need_member_table.member_id

UNION ALL 

-- 景区角度，每笔订单数据
SELECT 
    need_member_table.member_id AS sid, 
    idcard_sex, 
    idcard_age, 
    pay_date
FROM 
(
    SELECT idcard_sex, idcard_age, pay_date, orderid
    FROM dwd_order_tourist_info_d_i
) AS tourist_table
INNER JOIN 
(
    SELECT land_id, order_id
    FROM dwd_order_d_i          
    WHERE booking_date >= CAST(DATE_FORMAT(DATE_SUB(TO_DATE(CAST(${ds} AS STRING), 'yyyyMMdd'), 540), 'yyyyMMdd') AS INT) 
) AS orderTable
ON tourist_table.orderid = orderTable.order_id
INNER JOIN 
(
    -- 需要计算的景区
    SELECT member_id, land_id
    FROM ods_c_member_authorize_d_f
    WHERE pt = ${ds}
      AND land_id IS NOT NULL 
) AS need_member_table
ON orderTable.land_id = need_member_table.land_id;

---------------------------------------------------------------------------------------------------------------------

-- 2. 缓存表, 结果数据已知的部分
-- 性别和年龄未知的排除, 需要重新计算
DROP VIEW IF EXISTS need_sid_tourist_result;
CACHE TABLE need_sid_tourist_result
AS 
SELECT 
	`sid`,
	`deadline`,
	`time_range`,
	`sex`,
	`age`,
	`count`
FROM 
(
	--昨日
	SELECT	
		`sid` 			            AS `sid`,
		FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd')	AS `deadline`,
		'yesterday'                 AS `time_range`,
		`idcard_sex` 			    AS `sex`,
		`idcard_age` 			    AS `age`,
		COUNT(1)  					AS `count`
	FROM 
    (
		SELECT 	
			`sid`,
			`idcard_sex`,
			CASE
				WHEN `idcard_age` BETWEEN 0 AND 7
                THEN 7
				WHEN `idcard_age` BETWEEN 8 AND 17
				THEN 17
				WHEN `idcard_age` BETWEEN 18 AND 27
				THEN 27
				WHEN `idcard_age` BETWEEN 28 AND 40
				THEN 40
				WHEN `idcard_age` BETWEEN 41 AND 60
				THEN 60
                WHEN `idcard_age` BETWEEN 61 AND 136
				THEN 61
				ELSE -1
			END 	AS `idcard_age`
		FROM need_sid_tourist_base_info
		WHERE `pay_date` = FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd')
	)
	GROUP BY `sid`, `idcard_sex`, `idcard_age`

	--本周
	UNION ALL 
	SELECT	
		`sid` 			            AS `sid`,
		FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd')	AS `deadline`,
		'currentWeek'               AS `time_range`,
		`idcard_sex` 			    AS `sex`,
		`idcard_age` 			    AS `age`,
		COUNT(1)  					AS `count`
	FROM 
    (
		SELECT 	
			`sid`,
			`idcard_sex`,
			CASE
				WHEN `idcard_age` BETWEEN 0 AND 7
				THEN 7
				WHEN `idcard_age` BETWEEN 8 AND 17
				THEN 17
				WHEN `idcard_age` BETWEEN 18 AND 27
				THEN 27
				WHEN `idcard_age` BETWEEN 28 AND 40
				THEN 40
				WHEN `idcard_age` BETWEEN 41 AND 60
				THEN 60
                WHEN `idcard_age` BETWEEN 61 AND 136
				THEN 61
				ELSE -1
			END 	AS `idcard_age`
		FROM need_sid_tourist_base_info
		WHERE `pay_date` >= DATE_SUB(SUBSTR(FROM_UNIXTIME(UNIX_TIMESTAMP(FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd'), 'yyyy-MM-dd')),1,10),PMOD(DATEDIFF(SUBSTR(FROM_UNIXTIME(UNIX_TIMESTAMP(FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd'), 'yyyy-MM-dd')),1,10),'1900-01-08'),7))
          AND `pay_date` <= DATE_SUB(SUBSTR(FROM_UNIXTIME(UNIX_TIMESTAMP(FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd'), 'yyyy-MM-dd')),1,10),PMOD(DATEDIFF(SUBSTR(FROM_UNIXTIME(UNIX_TIMESTAMP(FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd'), 'yyyy-MM-dd')),1,10),'1900-01-08'),7)-6)
	)
	GROUP BY  `sid`, `idcard_sex`, `idcard_age`

	--上周
	UNION ALL 
	SELECT	
		`sid` 			            AS `sid`,
		FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd')	AS `deadline`,
		'lastWeek'                  AS `time_range`,
		`idcard_sex` 			    AS `sex`,
		`idcard_age` 			    AS `age`,
		COUNT(1)  					AS `count`
	FROM 
    (
		SELECT 	
			`sid`,
			`idcard_sex`,
			CASE
				WHEN `idcard_age` BETWEEN 0 AND 7
				THEN 7
				WHEN `idcard_age` BETWEEN 8 AND 17
				THEN 17
				WHEN `idcard_age` BETWEEN 18 AND 27
				THEN 27
				WHEN `idcard_age` BETWEEN 28 AND 40
				THEN 40
				WHEN `idcard_age` BETWEEN 41 AND 60
				THEN 60
                WHEN `idcard_age` BETWEEN 61 AND 136
				THEN 61
				ELSE -1
			END 	AS `idcard_age`
		FROM need_sid_tourist_base_info
		WHERE `pay_date` >= DATE_SUB(SUBSTR(FROM_UNIXTIME(UNIX_TIMESTAMP(FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd'), 'yyyy-MM-dd')),1,10),PMOD(DATEDIFF(SUBSTR(FROM_UNIXTIME(UNIX_TIMESTAMP(FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd'), 'yyyy-MM-dd')),1,10),'1900-01-08'),7)+7)
          AND `pay_date` <= DATE_SUB(SUBSTR(FROM_UNIXTIME(UNIX_TIMESTAMP(FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd'), 'yyyy-MM-dd')),1,10),PMOD(DATEDIFF(SUBSTR(FROM_UNIXTIME(UNIX_TIMESTAMP(FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd'), 'yyyy-MM-dd')),1,10),'1900-01-08'),7)+1)
	)
	GROUP BY  `sid`, `idcard_sex`, `idcard_age`

	--本年
	UNION ALL 
	SELECT	
		`sid` 			            AS `sid`,
		FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd')	AS `deadline`,
		'currentYear'               AS `time_range`,
		`idcard_sex` 			    AS `sex`,
		`idcard_age` 			    AS `age`,
		COUNT(1)  					AS `count`
	FROM 
    (
		SELECT 	
			`sid`,
			`idcard_sex`,
			CASE
				WHEN `idcard_age` BETWEEN 0 AND 7
				THEN 7
				WHEN `idcard_age` BETWEEN 8 AND 17
				THEN 17
				WHEN `idcard_age` BETWEEN 18 AND 27
				THEN 27
				WHEN `idcard_age` BETWEEN 28 AND 40
				THEN 40
				WHEN `idcard_age` BETWEEN 41 AND 60
				THEN 60
                WHEN `idcard_age` BETWEEN 61 AND 136
				THEN 61
				ELSE -1
			END 	AS `idcard_age`
		FROM need_sid_tourist_base_info
		WHERE YEAR(`pay_date`) = DATE_FORMAT(FROM_UNIXTIME(UNIX_TIMESTAMP(FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd'), 'yyyy-MM-dd'), 'yyyy-MM-dd'),'yyyy')
	)
	GROUP BY `sid`, `idcard_sex`, `idcard_age`

	--去年
	UNION ALL 
	SELECT	
		`sid` 			            AS `sid`,
		FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd')	AS `deadline`,
		'lastYear'                  AS `time_range`,
		`idcard_sex` 			    AS `sex`,
		`idcard_age` 			    AS `age`,
		COUNT(1)  					AS `count`
	FROM 
    (
		SELECT 	
			`sid`,
			`idcard_sex`,
			CASE
				WHEN `idcard_age` BETWEEN 0 AND 7
				THEN 7
				WHEN `idcard_age` BETWEEN 8 AND 17
				THEN 17
				WHEN `idcard_age` BETWEEN 18 AND 27
				THEN 27
				WHEN `idcard_age` BETWEEN 28 AND 40
				THEN 40
				WHEN `idcard_age` BETWEEN 41 AND 60
				THEN 60
                WHEN `idcard_age` BETWEEN 61 AND 136
				THEN 61
				ELSE -1
			END 	AS `idcard_age`
		FROM need_sid_tourist_base_info
		WHERE YEAR(`pay_date`) = DATE_FORMAT(ADD_MONTHS(FROM_UNIXTIME(UNIX_TIMESTAMP(FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd'), 'yyyy-MM-dd'), 'yyyy-MM-dd'),-12),'yyyy')
	)
	GROUP BY `sid`, `idcard_sex`, `idcard_age`
)
WHERE NOT(`sex` = '未知' AND `age` = -1);

---------------------------------------------------------------------------------------------------------------------

-- 3. 缓存表, 存储分销链表上当日预定票数
DROP VIEW IF EXISTS need_sid_order_aids_range_result;
CACHE TABLE need_sid_order_aids_range_result
AS
-- 商户维度
SELECT aids_seller_id, ticket_num, pay_date
FROM 
(
    SELECT 
		aids_seller_id, 
		ticket_num, 
		-- orderdate AS pay_date
		TO_DATE(CAST(orderdate AS STRING), 'yyyyMMdd') AS pay_date
    FROM dwd_order_split_d_i
    WHERE orderdate >=  CAST(DATE_FORMAT(DATE_SUB(TO_DATE(CAST(${ds} AS STRING), 'yyyyMMdd'), 540), 'yyyyMMdd') AS INT)
        AND ISNOTNULL(`aids_seller_id`)
) AS order_aids_table
INNER JOIN 
(
    SELECT member_id
    FROM ods_c_member_authorize_d_f
    WHERE pt=${ds}
      AND land_id IS NULL
) AS need_member_table
ON order_aids_table.aids_seller_id = need_member_table.member_id

UNION ALL 
-- 景区维度
SELECT need_member_table.member_id AS aids_seller_id, ticket_num, pay_date
FROM 
(
    SELECT land_id, ticket_num, TO_DATE(pay_time) AS pay_date
    FROM dwd_order_d_i          
    WHERE booking_date >= CAST(DATE_FORMAT(DATE_SUB(TO_DATE(CAST(${ds} AS STRING), 'yyyyMMdd'), 540), 'yyyyMMdd') AS INT)
) AS order_table
INNER JOIN 
(
    SELECT member_id, land_id
    FROM ods_c_member_authorize_d_f
    WHERE pt=${ds}
      AND land_id IS NOT NULL
) AS need_member_table
ON order_table.land_id = need_member_table.land_id;


---------------------------------------------------------------------------------------------------------------------


-- 4. 插入
INSERT OVERWRITE TABLE ads_s_company_tourist_instance_stat_d_f
SELECT 
	`sid`,
	`deadline`,
	`time_range`,
	`sex`,
	`age`,
	`count`
FROM 
(
	SELECT 
		tmp1.`sid`                              AS `sid`,
		FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd')				AS `deadline`,
		tmp1.`time_range`                       AS `time_range`,
		'未知'								    AS `sex`,
		-1										AS `age`,
		IF(
			(tmp1.`sum_ticket_num` - tmp2.`count`) >0,
			(tmp1.`sum_ticket_num` - tmp2.`count`),
			0
		)										AS `count`
	FROM 
    (
		--昨日
		SELECT 
			`aids_seller_id`  AS `sid`,
			'yesterday'       AS `time_range`,
			SUM(ticket_num)   AS `sum_ticket_num`
		FROM need_sid_order_aids_range_result
		WHERE `pay_date` = FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd')
		GROUP BY `aids_seller_id`

		--本周
		UNION ALL
		SELECT 
			`aids_seller_id`  AS `sid`,
			'currentWeek'     AS `time_range`,
			SUM(ticket_num)   AS `sum_ticket_num`
		FROM need_sid_order_aids_range_result
		WHERE `pay_date` >= DATE_SUB(SUBSTR(FROM_UNIXTIME(UNIX_TIMESTAMP(FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd'), 'yyyy-MM-dd')),1,10),PMOD(DATEDIFF(SUBSTR(FROM_UNIXTIME(UNIX_TIMESTAMP(FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd'), 'yyyy-MM-dd')),1,10),'1900-01-08'),7))
          AND `pay_date` <= DATE_SUB(SUBSTR(FROM_UNIXTIME(UNIX_TIMESTAMP(FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd'), 'yyyy-MM-dd')),1,10),PMOD(DATEDIFF(SUBSTR(FROM_UNIXTIME(UNIX_TIMESTAMP(FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd'), 'yyyy-MM-dd')),1,10),'1900-01-08'),7)-6)
		GROUP BY `aids_seller_id`

		--上周
		UNION ALL
		SELECT 
			`aids_seller_id`  AS `sid`,
			'lastWeek'        AS `time_range`,
			SUM(ticket_num)   AS `sum_ticket_num`
		FROM need_sid_order_aids_range_result
		WHERE `pay_date` >= DATE_SUB(SUBSTR(FROM_UNIXTIME(UNIX_TIMESTAMP(FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd'), 'yyyy-MM-dd')),1,10),PMOD(DATEDIFF(SUBSTR(FROM_UNIXTIME(UNIX_TIMESTAMP(FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd'), 'yyyy-MM-dd')),1,10),'1900-01-08'),7)+7)
          AND `pay_date` <= DATE_SUB(SUBSTR(FROM_UNIXTIME(UNIX_TIMESTAMP(FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd'), 'yyyy-MM-dd')),1,10),PMOD(DATEDIFF(SUBSTR(FROM_UNIXTIME(UNIX_TIMESTAMP(FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd'), 'yyyy-MM-dd')),1,10),'1900-01-08'),7)+1)
		GROUP BY `aids_seller_id`

		--本年
		UNION ALL
		SELECT 
			`aids_seller_id`  AS `sid`,
			'currentYear'     AS `time_range`,
			SUM(ticket_num)   AS `sum_ticket_num`
		FROM need_sid_order_aids_range_result
		WHERE YEAR(`pay_date`) = DATE_FORMAT(FROM_UNIXTIME(UNIX_TIMESTAMP(FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd'), 'yyyy-MM-dd'), 'yyyy-MM-dd'),'yyyy')
		GROUP BY `aids_seller_id`

		UNION ALL 
		--去年
		SELECT 
			`aids_seller_id`  AS `sid`,
			'lastYear'        AS `time_range`,
			SUM(ticket_num)   AS `sum_ticket_num`
		FROM need_sid_order_aids_range_result
		WHERE YEAR(`pay_date`) = DATE_FORMAT(ADD_MONTHS(FROM_UNIXTIME(UNIX_TIMESTAMP(FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd'), 'yyyy-MM-dd'), 'yyyy-MM-dd'),-12),'yyyy')
		GROUP BY `aids_seller_id`
	) AS tmp1
	LEFT JOIN 
    (
		--提取有数据的行，需要总值相减，求双未知的数据
		SELECT 
			`sid`,
			`deadline`,
			`time_range`,
			SUM(`count`) 	AS `count`
		FROM need_sid_tourist_result
		GROUP BY `sid`, `deadline`, `time_range`
	) AS tmp2
	ON tmp1.`sid` = tmp2.`sid` 
    AND tmp1.`time_range` = tmp2.`time_range`

    UNION ALL 

	SELECT `sid`, `deadline`, `time_range`, `sex`, `age`, `count`
	FROM need_sid_tourist_result
);

---------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------
