--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-20 17:52:35
--EMR任务只能运行在独享资源组上
--********************************************************************--
-- name ads_s_company_supplier_distributor_stat_d_f
-- type Spark SQL
-- author liangleichen@12301.cc
-- create time 2022-11-16 14:26:00
-- desc 有订单分销商统计
-- 目前仅计算`distributor_order_count`这一个


--------------------------------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS ads_s_company_product_stat_d_f(
    `sid`               INT     COMMENT '商户ID',
    `year`              INT     COMMENT '年',
    `month`             INT     COMMENT '月',
    `week`              INT     COMMENT '周',
    `date`              INT     COMMENT '日',
    `fulldate`          STRING  COMMENT '全日期',
    `product_type_id`   STRING  COMMENT '产品类型Id',
    `product_type_name` STRING  COMMENT '产品类型名称',
    `product_id`        INT     COMMENT '产品Id',
    `product_name`      STRING  COMMENT '产品名称',
    `paid_count`        BIGINT  COMMENT '已支付订单量',
    `paid_ticket_count` BIGINT  COMMENT '已支付票量',
    `paid_amount`       BIGINT  COMMENT '已支付订单金额',
    `is_sid`            INT     COMMENT '为1则sid列为商户id,为0则sid列为景区id'
)PARTITIONED BY(
    pt                  STRING  COMMENT '更新数据截止时间'
)STORED AS ORC;

--------------------------------------------------------------------------------------------------

-- 商户角度
INSERT OVERWRITE TABLE ads_s_company_product_stat_d_f PARTITION(pt=${ds})
SELECT
    CAST(member_id AS INT)              AS `sid`,
    YEAR(TO_DATE(pay_time))             AS `year`,
    MONTH(TO_DATE(pay_time))            AS `month`,
    CAST(dim_isoweek.isoweek AS INT)    AS `week`,
    DAY(TO_DATE(pay_time))              AS `date`,
    TO_DATE(pay_time)                   AS `fulldate`,
    land_type                           AS `product_type_id`,
    land_type_name                      AS `product_type_name`,
    land_id                             AS `product_id`,
    land_name                           AS `product_name`,
    COUNT(1)                            AS `paid_count`,
    SUM(ticket_num)                     AS `paid_ticket_count`,
    SUM(order_pay_amount)               AS `paid_amount`,
    1                                   AS `is_sid`
FROM 
(
    SELECT aids_seller_id, pay_time, land_type, land_type_name, land_id, land_name, order_pay_amount, ticket_num
    FROM dwd_order_split_d_i
    WHERE orderdate >= CAST(DATE_FORMAT(DATE_SUB(TO_DATE(CAST(${ds} AS STRING), 'yyyyMMdd'), 540), 'yyyyMMdd') AS INT)
      AND pay_time IS NOT NULL
      -- AND pay_time >= '2013-01-01 00:00:00'
) AS aids_table
INNER JOIN 
(
	SELECT member_id
    FROM ods_c_member_authorize_d_f
	WHERE pt=${ds}
      AND land_id IS NULL
) AS need_member_table
ON aids_seller_id = need_member_table.member_id
LEFT JOIN dim_date_isoweek_o_f AS dim_isoweek ON TO_DATE(pay_time) = dim_isoweek.`date`                        
GROUP BY
    member_id,
    TO_DATE(pay_time),
    dim_isoweek.isoweek,
    land_type, 
    land_type_name,
    land_id,
    land_name;

--------------------------------------------------------------------------------------------------

-- 景区角度
INSERT INTO TABLE ads_s_company_product_stat_d_f PARTITION(pt=${ds})
SELECT
    CAST(member_id AS INT)              AS `sid`,
    YEAR(TO_DATE(pay_time))             AS `year`,
    MONTH(TO_DATE(pay_time))            AS `month`,
    CAST(dim_isoweek.isoweek AS INT)    AS `week`,
    DAY(TO_DATE(pay_time))              AS `date`,
    TO_DATE(pay_time)                   AS `fulldate`,
    land_type                           AS `product_type_id`,
    land_type_name                      AS `product_type_name`,
    order.land_id                       AS `product_id`,
    land_name                           AS `product_name`,
    COUNT(1)                            AS `paid_count`,
    SUM(ticket_num)                     AS `paid_ticket_count`,
    SUM(order_pay_amount)               AS `paid_amount`,
    0                                   AS `is_sid`
FROM 
(
    SELECT pay_time, land_type, land_type_name, land_id, land_name, order_pay_amount, ticket_num
    FROM dwd_order_d_i          
    WHERE booking_date >= CAST(DATE_FORMAT(DATE_SUB(TO_DATE(CAST(${ds} AS STRING), 'yyyyMMdd'), 540), 'yyyyMMdd') AS INT)
    -- AND pay_time >= '2013-01-01 00:00:00'
) AS order
INNER JOIN 
(
	SELECT land_id, member_id
	FROM ods_c_member_authorize_d_f
	WHERE pt=${ds}
      AND land_id IS NOT NULL
) AS need_member_table
ON order.land_id = need_member_table.land_id
LEFT JOIN dim_date_isoweek_o_f AS dim_isoweek ON TO_DATE(pay_time) = dim_isoweek.`date`                    
GROUP BY
    need_member_table.member_id,
    dim_isoweek.isoweek,
    TO_DATE(pay_time),
    order.land_id,
    land_type, 
    land_type_name,
    land_name;
