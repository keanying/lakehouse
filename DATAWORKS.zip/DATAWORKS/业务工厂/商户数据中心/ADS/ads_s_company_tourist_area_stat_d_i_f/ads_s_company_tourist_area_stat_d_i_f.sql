--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-21 14:37:39
--EMR任务只能运行在独享资源组上
--********************************************************************--
-- name ads_s_company_tourist_area_stat_d_i_f
-- type Spark SQL
-- author liangleichen@12301.cc
-- create time 2022-11-11 16:09:56
-- 指标内容：商户/景区_订单游客地区

--------------------------------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS ads_s_company_tourist_area_stat_d_i(
    `sid`         	INT   	COMMENT '商户ID',
    `year`        	INT   	COMMENT '年',
    `month`       	INT   	COMMENT '月',
    `week`        	INT   	COMMENT '周',
    `day`         	INT   	COMMENT '日',
    `date`        	STRING	COMMENT '全日期',
    `province`    	STRING	COMMENT '省份',
    `city`        	STRING	COMMENT '城市',
    `actual_count`	INT   	COMMENT '实入人数'
)PARTITIONED BY(
    pt				INT     COMMENT '更新数据截止时间'
)STORED AS ORC;

-------------------------------------------------CACHE TABLE-------------------------------------------------

DROP VIEW IF EXISTS CACHE_TRACK_TABLE;
CACHE TABLE CACHE_TRACK_TABLE
AS 
SELECT order_id, vertify_ticket_num, action_time
FROM ods_pft_order_track_d_f
WHERE vertify_ticket_num IS NOT NULL;


DROP VIEW IF EXISTS CACHE_TABLE;
CACHE TABLE CACHE_TABLE
AS
-- 商户角度
SELECT
    aidsTable.land_publisher_id                 AS `sid`,
    TO_DATE(CACHE_TRACK_TABLE.action_time)      AS `date`,
    aidsTable.province                          AS `province`,
    aidsTable.city                              AS `city`,
    SUM(CACHE_TRACK_TABLE.vertify_ticket_num)   AS `actual_count`
FROM CACHE_TRACK_TABLE    
INNER JOIN 
(
    SELECT
        land_publisher_id	  AS land_publisher_id,
        order_id        	  AS order_id,
        IF(ticket_taker_province IS NULL, "未知", ticket_taker_province)    AS province,
        IF(ticket_taker_city IS NULL, "未知", ticket_taker_city)            AS city
    FROM dwd_order_split_d_i
    WHERE orderdate >= CAST(DATE_FORMAT(DATE_SUB(TO_DATE(CAST(${ds} AS STRING), 'yyyyMMdd'), 732), 'yyyyMMdd') AS INT)  
    GROUP BY
        order_id,
        land_publisher_id,
        ticket_taker_province,
        ticket_taker_city
) AS aidsTable
INNER JOIN 
(
	SELECT member_id
	FROM ods_c_member_authorize_d_f
	WHERE pt = ${ds}
      AND land_id IS NULL 
) AS memberTable          
ON CACHE_TRACK_TABLE.order_id = aidsTable.order_id 
AND aidsTable.land_publisher_id = memberTable.member_id
GROUP BY
    aidsTable.land_publisher_id,
    TO_DATE(CACHE_TRACK_TABLE.action_time),
    aidsTable.province,
    aidsTable.city

-- 景区角度

UNION ALL 
SELECT
    memberTable.member_id                       AS `sid`,
    TO_DATE(CACHE_TRACK_TABLE.action_time)      AS `date`,
    orderTable.province                         AS `province`,
    orderTable.city                             AS `city`,
    SUM(CACHE_TRACK_TABLE.vertify_ticket_num)   AS `actual_count`
FROM CACHE_TRACK_TABLE    
INNER JOIN 
(
    SELECT
        land_id             AS land_id,
        order_id        	  AS order_id,
        IF(ticket_taker_province IS NULL, "未知", ticket_taker_province)	  AS province,
        IF(ticket_taker_city IS NULL, "未知", ticket_taker_city)            AS city
    FROM dwd_order_d_i          
    WHERE booking_date >= CAST(DATE_FORMAT(DATE_SUB(TO_DATE(CAST(${ds} AS STRING), 'yyyyMMdd'), 732), 'yyyyMMdd') AS INT)
    GROUP BY
        land_id,
        order_id,
        ticket_taker_province,
        ticket_taker_city
) AS orderTable
INNER JOIN 
(
	SELECT member_id, land_id
	FROM ods_c_member_authorize_d_f
	WHERE pt = ${ds}
      AND land_id IS NOT NULL 
) AS memberTable          
ON CACHE_TRACK_TABLE.order_id = orderTable.order_id 
AND orderTable.land_id = memberTable.land_id
GROUP BY
    memberTable.member_id,
    TO_DATE(CACHE_TRACK_TABLE.action_time),
    orderTable.province,
    orderTable.city;

-------------------------------------------------fullDose-------------------------------------------------

INSERT OVERWRITE TABLE ads_s_company_tourist_area_stat_d_i PARTITION(pt = ${ds})
SELECT 
	CAST(sid AS INT)            AS `sid`,
	YEAR(CACHE_TABLE.`date`)    AS `year`,
	MONTH(CACHE_TABLE.`date`)   AS `month`,
    -- dim_isoweek.isoweek         AS `week`,
    CAST(dim_isoweek.isoweek AS INT) AS `week`,
	DAY(CACHE_TABLE.`date`)	    AS `day`,
	TO_DATE(CACHE_TABLE.`date`)	AS `date`,
	CACHE_TABLE.province 	    AS `province`,
    CACHE_TABLE.city         	AS `city`,
    CACHE_TABLE.actual_count	AS `actual_count`
FROM CACHE_TABLE
INNER JOIN 
(
	SELECT member_id
	FROM ods_c_member_authorize_d_f
	WHERE pt = ${ds}
	  AND run_fullDose_or_increment = 'fullDose'
) AS need_member_table
ON CACHE_TABLE.sid = need_member_table.member_id
LEFT JOIN dim_date_isoweek_o_f AS dim_isoweek ON CACHE_TABLE.`date` = dim_isoweek.`date`;

-------------------------------------------------increment-------------------------------------------------

INSERT INTO TABLE ads_s_company_tourist_area_stat_d_i PARTITION(pt = ${ds})
SELECT 
	CAST(sid AS INT)            AS `sid`,
	YEAR(CACHE_TABLE.`date`)	AS `year`,
	MONTH(CACHE_TABLE.`date`)	AS `month`,
    -- dim_isoweek.isoweek         AS `week`,
    CAST(dim_isoweek.isoweek AS INT) AS `week`,
	DAY(CACHE_TABLE.`date`)		AS `day`,
	TO_DATE(CACHE_TABLE.`date`)	AS `date`,
	CACHE_TABLE.province 		AS `province`,
    CACHE_TABLE.city         	AS `city`,
    CACHE_TABLE.actual_count	AS `actual_count`
FROM CACHE_TABLE
INNER JOIN 
(
	SELECT member_id
	FROM ods_c_member_authorize_d_f
	WHERE pt = ${ds}
  	  AND run_fullDose_or_increment='increment'
) AS need_member_table
ON CACHE_TABLE.sid = need_member_table.member_id
LEFT JOIN dim_date_isoweek_o_f AS dim_isoweek ON CACHE_TABLE.`date` = dim_isoweek.`date`
WHERE CACHE_TABLE.`date` = TO_DATE(${ds}, 'yyyyMMdd'); 



