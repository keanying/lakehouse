--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-19 17:14:26
--EMR任务只能运行在独享资源组上
--********************************************************************--

-- 计算指标：商户至今累计营销员数量
-- 时间范围：2022年元旦至今
-- 注意：只计算商户维度，不计算景区维度


--------------------------------------------------------------------------------------------------


CREATE TABLE IF NOT EXISTS ads_all_dis_member_count_d_f(
    `sid`               INT     COMMENT  '商户ID',
    `year`              INT     COMMENT  '年',
    `month`             INT     COMMENT  '月',
    `week`              INT     COMMENT  '周',
    `day`               INT     COMMENT  '日',
    `date`              STRING  COMMENT  '全日期',
    `dimension_type`    STRING  COMMENT  '维度类型',
    `dimension_value`   STRING  COMMENT  '维度值',
    `key`               STRING  COMMENT  '键',
    `value`             INT     COMMENT  'value'
)STORED AS ORC;


--------------------------------------------------------------------------------------------------


INSERT OVERWRITE TABLE ads_all_dis_member_count_d_f
SELECT 
	INT(result_table.sid)		    AS `sid`, 
	YEAR(result_table.`date`)		AS `year`,
	MONTH(result_table.`date`)		AS `month`,
	INT(result_table.`week`)	    AS `week`,
	DAY(result_table.`date`)		AS `day`,
	result_table.`date`     		AS `date`,
	'default'               		AS `dimension_type`,
    ''                      		AS `dimension_value`,
    'all_dis_member_count'  		AS `key`,
	NVL(result_table.`value`, 0)	AS `value`
FROM 
(
	SELECT 
		result_full_date_and_sid.`sid`      AS `sid`,
		result_full_date_and_sid.`date`     AS `date`,
        dim_isoweek.isoweek	                AS `week`,
		MAX(result_deficiency_date_and_sid.`value`) OVER (PARTITION BY result_full_date_and_sid.`sid` ORDER BY result_full_date_and_sid.`date`)
											AS `value`
	FROM 
	(
        -- 开通服务商户id和时间，用于填充数据
		SELECT 
			need_member_table.member_id 	AS `sid`,
			need_date_table.need_date		AS `date`
		FROM 
		(
			SELECT member_id
			FROM ods_c_member_authorize_d_f
			WHERE pt = ${ds}
			  AND is_sid = 1
		) AS need_member_table
		FULL OUTER JOIN 
		(
			--使用date_add()以及posexplode()生成目标日期范围数据
			SELECT DATE_ADD("2016-01-01", a.pos) AS need_date
			FROM 
			(
				SELECT POSEXPLODE(SPLIT(REPEAT("@", DATEDIFF(FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd'), "2016-01-01")), "@"))
			) AS a
		) AS need_date_table
	) AS result_full_date_and_sid
	LEFT JOIN 
	(
		-- 商户每日累计营销员数量, 由于某日可能无新增营销员，因此在时间上不连续
		SELECT 
			sid         AS `sid`,
			`date`      AS `date`,
			SUM(tmp.`value`) OVER (PARTITION BY tmp.sid ORDER BY tmp.`date`) 
						AS `value`
		FROM 
		(
			--由全民营销推荐关系表, 计算出商户每日新增营销员,
			SELECT
				belong_id                               AS `sid`,
				FROM_UNIXTIME(bind_time, 'yyyy-MM-dd')  AS `date`,
				COUNT(*)                                AS `value`
			FROM ods_pft_all_dis_recommend_d_f 
			WHERE pt = ${ds}
              AND `level` > 0
              AND `is_del` = 0 
              AND `rec_status` = 0 
			GROUP BY belong_id, FROM_UNIXTIME(bind_time, 'yyyy-MM-dd')
		) AS tmp
	) AS result_deficiency_date_and_sid
	ON result_full_date_and_sid.`sid` = result_deficiency_date_and_sid.`sid` 
    AND result_full_date_and_sid.`date` = result_deficiency_date_and_sid.`date`
    LEFT JOIN dim_date_isoweek_o_f AS dim_isoweek 
    ON result_full_date_and_sid.`date` = dim_isoweek.`date`
	ORDER BY result_full_date_and_sid.sid, result_full_date_and_sid.`date`
) AS result_table
-- 结果及只取 2022 至今
WHERE result_table.`date` >= '2022-01-01';

