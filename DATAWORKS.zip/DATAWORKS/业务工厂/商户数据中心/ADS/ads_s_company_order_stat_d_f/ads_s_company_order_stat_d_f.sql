--EMR Spark SQL
--****--
--author: 梁雷晨 (Optimized)
--create time: 2025-08-20 16:37:56
--EMR任务只能运行在独享资源组上
--****--
-- name ads_s_company_order_stat_d_f
-- type Spark SQL
-- 计算指标：商户/景区 每日支付/验证/取消/过期的订单量/订单金额统计

--------------------------------------------------------------------------------------------------
-- 1. 创建目标表（保持不变）
--------------------------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS ads_s_company_order_stat_d_f(
    `sid`               STRING  COMMENT '商户ID',
    `year`              INT     COMMENT '年',
    `month`             INT     COMMENT '月',
    `week`              INT     COMMENT '周',
    `day`               INT     COMMENT '日',
    `fulldate`          STRING  COMMENT '全日期',
    `paid_count`        BIGINT  COMMENT '已支付订单量',
    `paid_amount`       BIGINT  COMMENT '已支付订单金额',
    `verify_count`      BIGINT  COMMENT '验证订单量',
    `verify_amount`     BIGINT  COMMENT '验证订单金额',
    `cancel_count`      BIGINT  COMMENT '取消订单量',
    `cancel_amount`     BIGINT  COMMENT '取消订单金额',
    `expiration_count`  BIGINT  COMMENT '过期订单量',
    `expiration_amount` BIGINT  COMMENT '过期订单金额'
) STORED AS ORC;

--------------------------------------------------------------------------------------------------
-- 2. 核心插入逻辑
--------------------------------------------------------------------------------------------------
INSERT OVERWRITE TABLE ads_s_company_order_stat_d_f
WITH base_data AS (
    -- 【合并原 cacheTable 逻辑：取商户与景区的并集】
    -- 商户角度
    SELECT 
        order_aids.aids_seller_id   AS member_id,
        order_aids.order_pay_amount,
        order_aids.pay_time,
        order_aids.verify_time,
        order_aids.cancel_time,
        order_aids.expiration_time
    FROM (
        SELECT aids_seller_id, order_pay_amount, pay_time, verify_time, cancel_time, expiration_time
        FROM dwd_order_split_d_i
        WHERE orderdate >= CAST(DATE_FORMAT(DATE_SUB(TO_DATE(CAST(${ds} AS STRING), 'yyyyMMdd'), 540), 'yyyyMMdd') AS INT)
          AND pay_time IS NOT NULL
    ) AS order_aids
    INNER JOIN (
        SELECT member_id
        FROM ods_c_member_authorize_d_f
        WHERE pt = ${ds} AND is_sid = 1
    ) AS need_member_table
    ON order_aids.aids_seller_id = need_member_table.member_id

    UNION ALL 
    
    -- 景区角度
    SELECT 
        memberTab.member_id     AS member_id,
        orderTab.order_pay_amount,
        orderTab.pay_time,
        orderTab.verify_time,
        orderTab.cancel_time,
        orderTab.expiration_time
    FROM (
        SELECT land_id, order_pay_amount, pay_time, verify_time, cancel_time, expiration_time
        FROM dwd_order_d_i          
        WHERE booking_date >= CAST(DATE_FORMAT(DATE_SUB(TO_DATE(CAST(${ds} AS STRING), 'yyyyMMdd'), 540), 'yyyyMMdd') AS INT)
          AND pay_time IS NOT NULL
    ) AS orderTab
    INNER JOIN (
        SELECT member_id, land_id
        FROM ods_c_member_authorize_d_f
        WHERE pt = ${ds} AND is_sid = 0
    ) AS memberTab
    ON orderTab.land_id = memberTab.land_id
),

-- 【核心优化：将一条记录的4个时间点列转行，过滤掉未发生的事件】
expanded_data AS (
    SELECT 
        member_id AS sid,
        order_pay_amount,
        event_type,
        TO_DATE(event_time) AS fulldate
    FROM base_data
    LATERAL VIEW EXPLODE(MAP(
        'pay', pay_time,
        'verify', verify_time,
        'cancel', cancel_time,
        'expiration', expiration_time
    )) event_map AS event_type, event_time
    -- 过滤掉没有发生的时间（例如未核销时 verify_time 为 null）
    WHERE event_time IS NOT NULL 
)

-- 【一次 Join，条件聚合计算出结果】
SELECT
    e.sid,
    YEAR(e.fulldate)                                                AS `year`,
    MONTH(e.fulldate)                                               AS `month`,
    CAST(d.isoweek AS INT)                                          AS `week`,
    DAY(e.fulldate)                                                 AS `day`,
    e.fulldate                                                      AS `fulldate`,
    
    -- 支付聚合
    SUM(IF(e.event_type = 'pay', 1, 0))                             AS paid_count, 
    SUM(IF(e.event_type = 'pay', e.order_pay_amount, 0))            AS paid_amount,
    
    -- 核销/验证聚合
    SUM(IF(e.event_type = 'verify', 1, 0))                          AS verify_count,
    SUM(IF(e.event_type = 'verify', e.order_pay_amount, 0))         AS verify_amount,
    
    -- 取消聚合
    SUM(IF(e.event_type = 'cancel', 1, 0))                          AS cancel_count,
    SUM(IF(e.event_type = 'cancel', e.order_pay_amount, 0))         AS cancel_amount,
    
    -- 过期聚合
    SUM(IF(e.event_type = 'expiration', 1, 0))                      AS expiration_count,
    SUM(IF(e.event_type = 'expiration', e.order_pay_amount, 0))     AS expiration_amount 
    
FROM expanded_data e
-- 仅需进行一次关联，极大降低计算量
LEFT JOIN dim_date_isoweek_o_f AS d 
       ON e.fulldate = d.`date`
GROUP BY 
    e.sid,
    e.fulldate,
    YEAR(e.fulldate),
    MONTH(e.fulldate),
    CAST(d.isoweek AS INT),
    DAY(e.fulldate);