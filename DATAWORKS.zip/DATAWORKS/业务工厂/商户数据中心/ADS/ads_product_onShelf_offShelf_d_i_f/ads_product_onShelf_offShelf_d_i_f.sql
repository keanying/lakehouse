--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-20 11:56:19
--EMR任务只能运行在独享资源组上
--********************************************************************--
-- 计算指标：商户商品上下过架数量统计
-- 计算范围：2021年元旦至今
-- 注意：只计算商户维度

--------------------------------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS ads_product_onShelf_offShelf_d_i(
    `sid`               STRING  COMMENT '商户ID',
    `year`              INT     COMMENT '年',
    `month`             INT     COMMENT '月',
    `week`              STRING  COMMENT '周',
    `day`               INT     COMMENT '日',
    `date`              STRING  COMMENT '全日期',
    `dimension_type`    STRING  COMMENT '维度类型',
    `dimension_value`   STRING  COMMENT '维度值',
    `key`               STRING  COMMENT '键',
    `value`             INT     COMMENT '值'
)PARTITIONED BY(
    pt                  STRING  COMMENT  '更新数据截止时间'
)STORED AS ORC;

-------------------------------------------------CACHE TABLE-------------------------------------------------
-- 计算所有2021年元旦至今，所有开通商户数据中心服务商户的上架商品数量，载入缓冲表中

DROP VIEW IF EXISTS CACHE_TABLE_ON_SHELF;
CACHE TABLE CACHE_TABLE_ON_SHELF
AS
SELECT 
    result_table.sid                    AS `sid`,
    result_table.`date`                 AS `date`,
    NVL(result_table.value, 0)          AS `value`
FROM 
(
	SELECT 
		result_full_date_and_sid.`sid`      AS `sid`,
		result_full_date_and_sid.`date`     AS `date`,
		MAX(result_deficiency_date_and_sid.`value`) OVER (PARTITION BY result_full_date_and_sid.`sid` ORDER BY result_full_date_and_sid.`date`)
											AS `value`
	FROM 
    (
		SELECT 
			need_member_table.member_id 	AS `sid`,
			need_date_table.need_date		AS `date`
		FROM (
			SELECT member_id
			FROM ods_c_member_authorize_d_f
			WHERE pt = ${ds}
			  AND land_id IS NULL
		) AS need_member_table
		FULL OUTER JOIN 
        (
			--使用date_add()以及posexplode()生成目标日期范围数据
			SELECT date_add("2021-01-01", a.pos) AS need_date
			FROM 
            (
				SELECT posexplode(SPLIT(REPEAT("@", DATEDIFF(FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd'), "2021-01-01")), "@"))
			) AS a
		) AS need_date_table
	) AS result_full_date_and_sid
	LEFT JOIN 
    (
        -- 以下由原始数据计算得出, 由于原始数据中某日没有上下架操作, 则此日统计结果也没有当天操作
        SELECT 
            everyday_apply_count.sid        AS `sid`,
            everyday_apply_count.`date`     AS `date`,
            --至今累加值
            SUM(everyday_apply_count.everyday_count) OVER(PARTITION BY everyday_apply_count.sid ORDER BY everyday_apply_count.`date`)                           
											AS `value`
        FROM 
        (
            --每天上架产品
            SELECT
                apply_did           AS sid,
                COUNT(*)            AS everyday_count,
                TO_DATE(addtime)    AS `date`
            FROM ods_uu_land_d_f  
            WHERE pt = ${ds} 
			  AND status = 1
            GROUP BY apply_did, TO_DATE(addtime)
            ORDER BY TO_DATE(addtime)
        ) AS everyday_apply_count
	) AS result_deficiency_date_and_sid
	ON result_full_date_and_sid.`sid` = result_deficiency_date_and_sid.`sid` AND result_full_date_and_sid.`date` = result_deficiency_date_and_sid.`date`
	ORDER BY result_full_date_and_sid.sid, result_full_date_and_sid.date
) AS result_table;

-------------------------------------------------------------------------------------------------
-- 计算所有2021年元旦至今，所有开通商户数据中心服务商户的下架商品数量，载入缓冲表中

DROP VIEW IF EXISTS CACHE_TABLE_OFF_SHELF;
CACHE TABLE CACHE_TABLE_OFF_SHELF
AS
SELECT 
    result_table.sid                    AS `sid`,
    result_table.`date`                 AS `date`,
    NVL(result_table.value, 0)          AS `value`
FROM 
(
	SELECT 
		result_full_date_and_sid.`sid`      AS `sid`,
		result_full_date_and_sid.`date`     AS `date`,
		MAX(result_deficiency_date_and_sid.`value`) OVER (PARTITION BY result_full_date_and_sid.`sid` ORDER BY result_full_date_and_sid.`date`)
											AS `value`
	FROM 
	(
		SELECT 
			need_member_table.member_id 	AS `sid`,
			need_date_table.need_date		AS `date`
		FROM 
		(
			SELECT member_id
			FROM ods_c_member_authorize_d_f
			WHERE pt = ${ds}
			  AND land_id IS NULL
		) AS need_member_table
		FULL OUTER JOIN 
		(
			--使用date_add()以及posexplode()生成目标日期范围数据
			SELECT date_add("2021-01-01", a.pos) AS need_date
			FROM 
			(
				SELECT posexplode(SPLIT(REPEAT("@", DATEDIFF(FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd'), "2021-01-01")), "@"))
			) AS a
		) AS need_date_table
	) AS result_full_date_and_sid
	LEFT JOIN (
        -- 以下由原始数据计算得出, 由于原始数据中某日没有上下架操作, 因此统计结果也没有当天操作
        SELECT 
            everyday_apply_count.sid        AS `sid`,
            everyday_apply_count.`date`     AS `date`,
            --至今累加值
            SUM(everyday_apply_count.everyday_count) OVER(PARTITION BY everyday_apply_count.sid ORDER BY everyday_apply_count.`date`)                           
											AS `value`
        FROM
		(
            --每天上架产品
            SELECT
                apply_did           AS sid,
                COUNT(*)            AS everyday_count,
                TO_DATE(addtime)    AS `date`
            FROM ods_uu_land_d_f  
            WHERE pt = ${ds} 
			  AND status = 2
            GROUP BY apply_did, TO_DATE(addtime)
            ORDER BY TO_DATE(addtime)
        ) AS everyday_apply_count
	) AS result_deficiency_date_and_sid
	ON result_full_date_and_sid.`sid` = result_deficiency_date_and_sid.`sid` AND result_full_date_and_sid.`date` = result_deficiency_date_and_sid.`date`
	ORDER BY result_full_date_and_sid.sid, result_full_date_and_sid.date
) AS result_table;

-------------------------------------------------fullDose-------------------------------------------------

INSERT OVERWRITE TABLE ads_product_onShelf_offShelf_d_i PARTITION(pt = ${ds})
SELECT 
	sid, 
	YEAR(CACHE_TABLE_ON_SHELF.`date`)	AS `year`,
	MONTH(CACHE_TABLE_ON_SHELF.`date`)	AS `month`,
	dim_isoweek.isoweek			        AS `week`,
	DAY(CACHE_TABLE_ON_SHELF.`date`)	AS `day`,
	CACHE_TABLE_ON_SHELF.`date`			AS `date`,
	'default'             				AS `dimension_type`,
    ''                    				AS `dimension_value`,
    'on_shelf_product_count'    		AS `key`,
	`value`								AS `value`
FROM CACHE_TABLE_ON_SHELF
INNER JOIN 
(
	SELECT member_id
	FROM ods_c_member_authorize_d_f
	WHERE pt = ${ds}
	  AND run_fullDose_or_increment='fullDose'
	  AND land_id IS NULL
) AS need_member_table
ON CACHE_TABLE_ON_SHELF.sid = need_member_table.member_id
LEFT JOIN dim_date_isoweek_o_f AS dim_isoweek ON CACHE_TABLE_ON_SHELF.`date` = dim_isoweek.`date`

UNION ALL

SELECT 
	sid, 
	YEAR(CACHE_TABLE_OFF_SHELF.`date`)	AS `year`,
	MONTH(CACHE_TABLE_OFF_SHELF.`date`)	AS `month`,
	dim_isoweek.isoweek				    AS `week`,
	DAY(CACHE_TABLE_OFF_SHELF.`date`)   AS `day`,
	CACHE_TABLE_OFF_SHELF.`date`		AS `date`,
	'default'             				AS `dimension_type`,
    ''                    				AS `dimension_value`,
    'off_shelf_product_count'   		AS `key`,
	`value`								AS `value`
FROM CACHE_TABLE_OFF_SHELF
INNER JOIN 
(
	SELECT member_id
	FROM ods_c_member_authorize_d_f
	WHERE pt = ${ds}
	  AND run_fullDose_or_increment='fullDose'
	  AND land_id IS NULL
) AS need_member_table
ON CACHE_TABLE_OFF_SHELF.sid = need_member_table.member_id
LEFT JOIN dim_date_isoweek_o_f AS dim_isoweek ON CACHE_TABLE_OFF_SHELF.`date` = dim_isoweek.`date`;

-------------------------------------------------increment-------------------------------------------------

INSERT INTO TABLE ads_product_onShelf_offShelf_d_i PARTITION(pt = ${ds})
SELECT 
	sid, 
	YEAR(CACHE_TABLE_ON_SHELF.`date`)	AS `year`,
	MONTH(CACHE_TABLE_ON_SHELF.`date`)	AS `month`,
	dim_isoweek.isoweek				    AS `week`,
	DAY(CACHE_TABLE_ON_SHELF.`date`)	AS `day`,
	CACHE_TABLE_ON_SHELF.`date`			AS `date`,
	'default'             				AS `dimension_type`,
    ''                    				AS `dimension_value`,
    'on_shelf_product_count'    		AS `key`,
	`value`								AS `value`
FROM CACHE_TABLE_ON_SHELF
INNER JOIN 
(
	SELECT member_id
	FROM ods_c_member_authorize_d_f
	WHERE pt = ${ds}
	  AND run_fullDose_or_increment='increment'
  	  AND land_id IS NULL
) AS need_member_table
ON CACHE_TABLE_ON_SHELF.sid = need_member_table.member_id AND CACHE_TABLE_ON_SHELF.`date` = FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd')
LEFT JOIN dim_date_isoweek_o_f AS dim_isoweek ON CACHE_TABLE_ON_SHELF.`date` = dim_isoweek.`date`

UNION ALL

SELECT 
	sid, 
	YEAR(CACHE_TABLE_OFF_SHELF.`date`)	AS `year`,
	MONTH(CACHE_TABLE_OFF_SHELF.`date`)	AS `month`,
	dim_isoweek.isoweek			        AS `week`,
	DAY(CACHE_TABLE_OFF_SHELF.`date`)   AS `day`,
	CACHE_TABLE_OFF_SHELF.`date`		AS `date`,
	'default'             				AS `dimension_type`,
    ''                    				AS `dimension_value`,
    'off_shelf_product_count'   		AS `key`,
	`value`								AS `value`
FROM CACHE_TABLE_OFF_SHELF
INNER JOIN 
(
	SELECT member_id
	FROM ods_c_member_authorize_d_f
	WHERE pt = ${ds}
	  AND run_fullDose_or_increment='increment'
	  AND land_id IS NULL
) AS need_member_table
ON CACHE_TABLE_OFF_SHELF.sid = need_member_table.member_id AND CACHE_TABLE_OFF_SHELF.`date` = FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd')
LEFT JOIN dim_date_isoweek_o_f AS dim_isoweek ON CACHE_TABLE_OFF_SHELF.`date` = dim_isoweek.`date`;

-------------------------------------------------------------------------------------------------
