--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨 (Optimized)
--create time: 2025-08-20 17:53:46
--EMR任务只能运行在独享资源组上
--********************************************************************--
-- name ads_s_company_product_stat_d_f
-- type Spark SQL
-- author liangleichen@12301.cc
-- desc 计算指标：商户/景区 每日每个产品订单量及订单金额统计

--------------------------------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS ads_s_company_product_stat_d_f(
    `sid`               INT     COMMENT '商户ID/景区ID',
    `year`              INT     COMMENT '年',
    `month`             INT     COMMENT '月',
    `week`              INT     COMMENT '周',
    `date`              INT     COMMENT '日',
    `fulldate`          STRING  COMMENT '全日期',
    `product_type_id`   STRING  COMMENT '产品类型Id',
    `product_type_name` STRING  COMMENT '产品类型名称',
    `product_id`        INT     COMMENT '产品Id',
    `product_name`      STRING  COMMENT '产品名称',
    `paid_count`        BIGINT  COMMENT '已支付订单量',
    `paid_ticket_count` BIGINT  COMMENT '已支付票量',
    `paid_amount`       BIGINT  COMMENT '已支付订单金额',
    `is_sid`            INT     COMMENT '为1则sid列为商户id,为0则sid列为景区id'
) PARTITIONED BY (
    pt                  INT     COMMENT '更新数据截止时间'
) STORED AS ORC;

--------------------------------------------------------------------------------------------------

-- 开启 CBO 和 自适应查询执行 (如果 Spark 版本 >= 3.0，通常 EMR 默认开启)
SET spark.sql.adaptive.enabled=true;

INSERT OVERWRITE TABLE ads_s_company_product_stat_d_f PARTITION(pt = ${ds})
WITH 
-- 1. 抽取通用的日期过滤条件 (利用 Spark 常量折叠，只计算一次)
date_filter AS (
    SELECT CAST(DATE_FORMAT(DATE_SUB(TO_DATE(CAST(${ds} AS STRING), 'yyyyMMdd'), 540), 'yyyyMMdd') AS INT) AS min_date
),

-- 2. 预处理商户授权表 (按需过滤，减少下游 Join 数据量)
auth_member AS (
    SELECT member_id
    FROM ods_c_member_authorize_d_f
    WHERE pt = ${ds} AND land_id IS NULL
    GROUP BY member_id -- 去重，防止 Join 发散
),
auth_land AS (
    SELECT land_id, member_id
    FROM ods_c_member_authorize_d_f
    WHERE pt = ${ds} AND land_id IS NOT NULL
    GROUP BY land_id, member_id -- 去重，防止 Join 发散
),

-- 3. 计算：商户角度聚合 (is_sid = 1)
-- 注意：将时间维度表的 Join 移到 Group By 之后
merchant_agg AS (
    SELECT
        CAST(m.member_id AS INT) AS sid,
        TO_DATE(o.pay_time)      AS fulldate,
        o.land_type              AS product_type_id,
        o.land_type_name         AS product_type_name,
        o.land_id                AS product_id,
        o.land_name              AS product_name,
        COUNT(1)                 AS paid_count,
        SUM(o.ticket_num)        AS paid_ticket_count,
        SUM(o.order_pay_amount)  AS paid_amount,
        1                        AS is_sid
    FROM dwd_order_split_d_i o
    CROSS JOIN date_filter df
    INNER JOIN auth_member m ON o.aids_seller_id = m.member_id
    WHERE o.orderdate >= df.min_date
      AND o.pay_time >= '2013-01-01 00:00:00'
    GROUP BY
        m.member_id,
        TO_DATE(o.pay_time),
        o.land_type, 
        o.land_type_name,
        o.land_id,
        o.land_name
),

-- 4. 计算：景区角度聚合 (is_sid = 0)
scenic_agg AS (
    SELECT
        CAST(m.member_id AS INT) AS sid,
        TO_DATE(o.pay_time)      AS fulldate,
        o.land_type              AS product_type_id,
        o.land_type_name         AS product_type_name,
        o.land_id                AS product_id,
        o.land_name              AS product_name,
        COUNT(1)                 AS paid_count,
        SUM(o.ticket_num)        AS paid_ticket_count,
        SUM(o.order_pay_amount)  AS paid_amount,
        0                        AS is_sid
    FROM dwd_order_d_i o
    CROSS JOIN date_filter df
    INNER JOIN auth_land m ON o.land_id = m.land_id
    WHERE o.booking_date >= df.min_date
      AND o.pay_time >= '2013-01-01 00:00:00'
    GROUP BY
        m.member_id,
        TO_DATE(o.pay_time),
        o.land_type, 
        o.land_type_name,
        o.land_id,
        o.land_name
),

-- 5. 合并商户和景区数据
combined_agg AS (
    SELECT * FROM merchant_agg
    UNION ALL
    SELECT * FROM scenic_agg
)

-- 6. 最终补全日期维度信息写入目标表 (Late Join)
SELECT
    c.sid,
    YEAR(c.fulldate)                 AS `year`,
    MONTH(c.fulldate)                AS `month`,
    CAST(dim_isoweek.isoweek AS INT) AS `week`,
    DAY(c.fulldate)                  AS `date`,
    c.fulldate,
    c.product_type_id,
    c.product_type_name,
    c.product_id,
    c.product_name,
    c.paid_count,
    c.paid_ticket_count,
    c.paid_amount,
    c.is_sid
FROM combined_agg c
LEFT JOIN dim_date_isoweek_o_f dim_isoweek 
  ON c.fulldate = dim_isoweek.`date`;