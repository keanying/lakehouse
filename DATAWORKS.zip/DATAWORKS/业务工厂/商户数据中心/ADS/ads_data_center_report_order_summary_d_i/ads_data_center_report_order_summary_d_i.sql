--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-19 17:14:39
--EMR任务只能运行在独享资源组上
--********************************************************************--
-- desc summary库报表, 商户数据中心使用版本


CREATE TABLE IF NOT EXISTS ads_data_center_report_order_summary_d_i(
    user_id                     STRING  COMMENT "商家id/婺源景区memberid",

    order_ticket                STRING  COMMENT "预定票数",
    cancel_ticket               STRING  COMMENT "取消票数",
    revoke_ticket               STRING  COMMENT "撤销票数",
    sale_money                  STRING  COMMENT "预定金额",
    cancel_sale_money           STRING  COMMENT "取消金额",
    revoke_sale_money           STRING  COMMENT "撤销金额",
    vertify_order_ticket        STRING  COMMENT "验证预定票数",
    vertify_finish_ticket       STRING  COMMENT "验证结束订单",
    vertify_revoke_ticket       STRING  COMMENT "验证撤销票数",
    vertify_sale_money          STRING  COMMENT "验证预定金额",
    vertify_finish_sale_money   STRING  COMMENT "验证结束金额",
    vertify_revoke_sale_money   STRING  COMMENT "验证撤销金额"
) COMMENT "报表数据汇总,数据中心使用版本" PARTITIONED by(
    oper_date                   INT     COMMENT "插入日期"
) STORED AS ORC;


DROP VIEW IF EXISTS CACHE_TABLE;
CACHE TABLE CACHE_TABLE
AS 
SELECT 
    sid, 
    lid,
    SUM(mo_order_ticket)            AS order_ticket,
    SUM(mo_cancel_ticket)           AS cancel_ticket,
    SUM(mo_revoke_ticket)           AS revoke_ticket,
    SUM(mo_order_sale_money)        AS sale_money,   
    SUM(mo_cancel_sale_money)       AS cancel_sale_money,   
    SUM(mo_revoke_sale_money)       AS revoke_sale_money,   
    SUM(mo_verify_ticket)           AS vertify_order_ticket,
    SUM(mo_finish_ticket)           AS vertify_finish_ticket,
    SUM(mo_revoke_ticket)           AS vertify_revoke_ticket,
    SUM(mo_verify_sale_money)       AS vertify_sale_money,   
    SUM(mo_finish_sale_money)       AS vertify_finish_sale_money,   
    SUM(mo_revoke_sale_money)       AS vertify_revoke_sale_money  
FROM dws_daily_report_summary_d_i
WHERE `date` = ${ds}
GROUP BY sid, lid;


-- 商户维度，计算开通商户数据中心的商户信息
INSERT OVERWRITE TABLE ads_data_center_report_order_summary_d_i PARTITION(oper_date = ${ds})
SELECT 
    sid                             AS  user_id, 
    SUM(order_ticket)               AS  order_ticket,
    SUM(cancel_ticket)              AS  cancel_ticket,
    SUM(revoke_ticket)              AS  revoke_ticket,
    SUM(sale_money)                 AS  sale_money,   
    SUM(cancel_sale_money)          AS  cancel_sale_money,         
    SUM(revoke_sale_money)          AS  revoke_sale_money,         
    SUM(vertify_order_ticket)       AS  vertify_order_ticket,       
    SUM(vertify_finish_ticket)      AS  vertify_finish_ticket,       
    SUM(vertify_revoke_ticket)      AS  vertify_revoke_ticket,       
    SUM(vertify_sale_money)         AS  vertify_sale_money,         
    SUM(vertify_finish_sale_money)  AS  vertify_finish_sale_money,              
    SUM(vertify_revoke_sale_money)  AS  vertify_revoke_sale_money           
FROM CACHE_TABLE
INNER JOIN 
(
	SELECT member_id
    FROM ods_c_member_authorize_d_f
	WHERE pt = ${ds}
      AND land_id IS NULL
) AS need_member_table
ON CACHE_TABLE.sid = need_member_table.member_id
GROUP BY sid;


--------------------------------------------------------------------------------------------------

-- 景区角度, 计算婺源的十个景区
INSERT INTO TABLE ads_data_center_report_order_summary_d_i PARTITION(oper_date = ${ds})
SELECT 
    member_id                       AS  user_id, 
    SUM(order_ticket)               AS  order_ticket,
    SUM(cancel_ticket)              AS  cancel_ticket,
    SUM(revoke_ticket)              AS  revoke_ticket,
    SUM(sale_money)                 AS  sale_money,   
    SUM(cancel_sale_money)          AS  cancel_sale_money,         
    SUM(revoke_sale_money)          AS  revoke_sale_money,         
    SUM(vertify_order_ticket)       AS  vertify_order_ticket,       
    SUM(vertify_finish_ticket)      AS  vertify_finish_ticket,       
    SUM(vertify_revoke_ticket)      AS  vertify_revoke_ticket,       
    SUM(vertify_sale_money)         AS  vertify_sale_money,         
    SUM(vertify_finish_sale_money)  AS  vertify_finish_sale_money,              
    SUM(vertify_revoke_sale_money)  AS  vertify_revoke_sale_money           
FROM CACHE_TABLE
INNER JOIN 
(
	SELECT land_id, member_id
	FROM ods_c_member_authorize_d_f
	WHERE pt = ${ds}
      AND land_id IS NOT NULL
) AS need_member_table
ON CACHE_TABLE.lid = need_member_table.land_id
GROUP BY member_id;

