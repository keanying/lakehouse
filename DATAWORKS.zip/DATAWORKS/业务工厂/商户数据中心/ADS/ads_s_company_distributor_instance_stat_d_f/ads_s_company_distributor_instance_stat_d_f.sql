--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-20 11:56:56
--EMR任务只能运行在独享资源组上
--********************************************************************--
-- 计算指标：商户数据中心v1.12 商户预订单分销商分布
-- 时间key：昨日/yesterday、本周/currentWeek/、上周/lastWeek、本年/currentYear、去年/lastYear

CREATE TABLE IF NOT EXISTS ads_s_company_distributor_instance_stat_d_f(
    `sid`               INT     COMMENT '商户ID',
    `deadline`          STRING  COMMENT '统计日期',
    `time_range`        STRING  COMMENT '统计时间范围',
    `distributor_id`    INT     COMMENT '分销商id',
    `distributor_name`  STRING  COMMENT '分销商名称',
    `paid_count`        BIGINT  COMMENT '已支付订单量',
    `paid_amount`       BIGINT  COMMENT '已支付订单金额'
) STORED AS ORC;

----------------------------------------------------------------------------------------
DROP VIEW IF EXISTS cacheTable;
CACHE TABLE cacheTable
AS
SELECT 
    order_aids.aids_seller_id,
    order_aids.aids_buyer_id,
    order_aids.aids_buyername,
    order_aids.pay_date
FROM 
(
    SELECT aids_seller_id, aids_buyer_id, aids_buyername, pay_date
    FROM dwd_order_split_d_i
    WHERE orderdate >= CAST(DATE_FORMAT(DATE_SUB(TO_DATE(CAST(${ds} AS STRING), 'yyyyMMdd'), 365), 'yyyyMMdd') AS INT)
      AND ISNOTNULL(pay_date) 
) AS order_aids
INNER JOIN 
(
    SELECT member_id
    FROM ods_c_member_authorize_d_f
    WHERE pt = ${ds}
      AND land_id IS NULL
) AS need_member_table
ON order_aids.aids_seller_id = need_member_table.member_id;

----------------------------------------------------------------------------------------

INSERT OVERWRITE TABLE ads_s_company_distributor_instance_stat_d_f
--昨日
SELECT	
    `aids_seller_id` 			AS `sid`,
    from_unixtime(unix_timestamp(cast(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd')                    AS `deadline`,
    'yesterday'                 AS `time_range`,
    `aids_buyer_id` 			AS `distributor_id`,
    FIRST(`aids_buyername`) 	AS `distributor_name`,
    COUNT(1) 					AS `paid_count`,
    0 							AS `paid_amount`
FROM cacheTable
WHERE `pay_date` = from_unixtime(unix_timestamp(cast(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd')
GROUP BY	
    `aids_seller_id`,
    `aids_buyer_id`

--本周
UNION ALL
SELECT	
    `aids_seller_id` 			AS `sid`,
    from_unixtime(unix_timestamp(cast(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd')    AS `deadline`,
    'currentWeek'               AS `time_range`,
    `aids_buyer_id` 			AS `distributor_id`,
    FIRST(`aids_buyername`) 	AS `distributor_name`,
    COUNT(1) 					AS `paid_count`,
    0 							AS `paid_amount`
FROM cacheTable
WHERE `pay_date` >= DATE_SUB(SUBSTR(FROM_UNIXTIME(UNIX_TIMESTAMP(from_unixtime(unix_timestamp(cast(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd'), 'yyyy-MM-dd')),1,10),PMOD(DATEDIFF(SUBSTR(FROM_UNIXTIME(UNIX_TIMESTAMP(from_unixtime(unix_timestamp(cast(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd'), 'yyyy-MM-dd')),1,10),'1900-01-08'),7))
  AND `pay_date` <= DATE_SUB(SUBSTR(FROM_UNIXTIME(UNIX_TIMESTAMP(from_unixtime(unix_timestamp(cast(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd'), 'yyyy-MM-dd')),1,10),PMOD(DATEDIFF(SUBSTR(FROM_UNIXTIME(UNIX_TIMESTAMP(from_unixtime(unix_timestamp(cast(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd'), 'yyyy-MM-dd')),1,10),'1900-01-08'),7)-6)
GROUP BY	
    `aids_seller_id`,
    `aids_buyer_id`

--上周
UNION ALL
SELECT	
    `aids_seller_id` 			AS `sid`,
    from_unixtime(unix_timestamp(cast(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd')    AS `deadline`,
    'lastWeek'                  AS `time_range`,
    `aids_buyer_id` 			AS `distributor_id`,
    FIRST(`aids_buyername`) 	AS `distributor_name`,
    COUNT(1) 					AS `paid_count`,
    0 							AS `paid_amount`
FROM cacheTable
WHERE `pay_date` >= DATE_SUB(SUBSTR(FROM_UNIXTIME(UNIX_TIMESTAMP(from_unixtime(unix_timestamp(cast(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd'), 'yyyy-MM-dd')),1,10),PMOD(DATEDIFF(SUBSTR(FROM_UNIXTIME(UNIX_TIMESTAMP(from_unixtime(unix_timestamp(cast(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd'), 'yyyy-MM-dd')),1,10),'1900-01-08'),7)+7)
  AND `pay_date` <= DATE_SUB(SUBSTR(FROM_UNIXTIME(UNIX_TIMESTAMP(from_unixtime(unix_timestamp(cast(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd'), 'yyyy-MM-dd')),1,10),PMOD(DATEDIFF(SUBSTR(FROM_UNIXTIME(UNIX_TIMESTAMP(from_unixtime(unix_timestamp(cast(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd'), 'yyyy-MM-dd')),1,10),'1900-01-08'),7)+1)
GROUP BY	
    `aids_seller_id`,
    `aids_buyer_id`

--本年
UNION ALL
SELECT	
    `aids_seller_id` 			AS `sid`,
    from_unixtime(unix_timestamp(cast(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd')    AS `deadline`,
    'currentYear'               AS `time_range`,
    `aids_buyer_id` 			AS `distributor_id`,
    FIRST(`aids_buyername`) 	AS `distributor_name`,
    COUNT(1) 					AS `paid_count`,
    0 							AS `paid_amount`
FROM cacheTable
WHERE year(`pay_date`) = DATE_FORMAT(FROM_UNIXTIME(UNIX_TIMESTAMP(from_unixtime(unix_timestamp(cast(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd'), 'yyyy-MM-dd'), 'yyyy-MM-dd'),'yyyy')
GROUP BY	
    `aids_seller_id`,
    `aids_buyer_id`

--去年
UNION ALL
SELECT	
    `aids_seller_id` 			AS `sid`,
    from_unixtime(unix_timestamp(cast(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd')    AS `deadline`,
    'lastYear'                  AS `time_range`,
    `aids_buyer_id` 			AS `distributor_id`,
    FIRST(`aids_buyername`) 	AS `distributor_name`,
    COUNT(1) 					AS `paid_count`,
    0 							AS `paid_amount`
FROM cacheTable
WHERE year(`pay_date`) = DATE_FORMAT(ADD_MONTHS(FROM_UNIXTIME(UNIX_TIMESTAMP(from_unixtime(unix_timestamp(cast(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd'), 'yyyy-MM-dd'), 'yyyy-MM-dd'),-12),'yyyy')
GROUP BY	
    `aids_seller_id`,
    `aids_buyer_id`;
