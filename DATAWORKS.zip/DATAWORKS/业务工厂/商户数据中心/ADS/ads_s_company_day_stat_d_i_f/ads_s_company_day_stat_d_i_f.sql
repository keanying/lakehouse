--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-20 11:56:46
--EMR任务只能运行在独享资源组上
--********************************************************************--
-- 计算指标：商户/景区 至今有过订单渠道统计维度
-- 注意：本表依赖"ads_s_company_channel_stat_d_f"数据, 此表包含所有日期下每笔订单的下单渠道信息

CREATE TABLE IF NOT EXISTS ads_s_company_day_stat_d_f(
    `sid`               STRING  COMMENT '商户ID',
    `year`              INT     COMMENT '年',
    `month`             INT     COMMENT '月',
    `week`              STRING  COMMENT '周',
    `day`               INT     COMMENT '日',
    `date`              STRING  COMMENT '全日期',
    `dimension_type`    STRING  COMMENT '维度类型',
    `dimension_value`   STRING  COMMENT '维度值',
    `key`               STRING  COMMENT '键',
    `value`             INT     COMMENT '值',
    `payload`           STRING  COMMENT '扩展字段'
)PARTITIONED BY(
    pt                  STRING  COMMENT  '更新数据截止时间'
)STORED AS ORC;

--------------------------------------------------------------------------------------------------------------------

--商户角度计算
DROP VIEW IF EXISTS CACHE_TABLE;
CACHE TABLE CACHE_TABLE
AS
SELECT 
    temp_table.sid                      AS `sid`,
    temp_table.fulldate                 AS `date`,
    NVL(temp_table.value, 0)            AS `value`
FROM 
(
    SELECT 
        full_date_and_sid.`sid`             AS sid,
        full_date_and_sid.`fulldate`        AS `fulldate`,
        MAX(base_table.`channel_count`) OVER (PARTITION BY full_date_and_sid.`sid` ORDER BY full_date_and_sid.`fulldate`)   
                                            AS `value`
    FROM 
    (
        SELECT 
			need_member_table.member_id 	AS `sid`,
			need_date_table.need_date		AS `fulldate`
		FROM 
        (
			SELECT member_id
			FROM ods_c_member_authorize_d_f
			WHERE pt = ${ds}
		) AS need_member_table
		FULL OUTER JOIN 
        (
			--使用date_add()以及posexplode()生成目标日期范围数据
			SELECT date_add(FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd'), a.pos) AS need_date
			FROM 
            (
				SELECT posexplode(SPLIT(REPEAT("@", DATEDIFF(FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd'), "2021-01-01")), "@"))
			) AS a
		) AS need_date_table
    ) AS full_date_and_sid
    LEFT JOIN 
    (
        --每天的至今成交渠道数量
        SELECT 
            repetition_table.sid            AS `sid`,
            repetition_table.fulldate       AS `fulldate`,
            repetition_table.channel_count  AS `channel_count`
        FROM 
        (
            SELECT
                sid             AS `sid`,
                fulldate        AS `fulldate`,
                SIZE(COLLECT_SET(channel_id) OVER(PARTITION by sid ORDER BY fulldate))  AS `channel_count`
            FROM ads_s_company_channel_stat_d_f
        ) AS repetition_table
        GROUP BY 
            repetition_table.sid,
            repetition_table.fulldate,
            repetition_table.channel_count 
    ) AS base_table
    ON full_date_and_sid.`fulldate` = base_table.`fulldate` AND full_date_and_sid.`sid` = base_table.`sid`
    ORDER BY full_date_and_sid.`sid`, full_date_and_sid.`fulldate`
) AS temp_table;

---------------------------------------fullDose-----------------------------------------------

INSERT OVERWRITE TABLE ads_s_company_day_stat_d_f PARTITION(pt = ${ds})
SELECT 
	sid                         AS `sid`, 
	YEAR(CACHE_TABLE.`date`)	AS `year`,
	MONTH(CACHE_TABLE.`date`)	AS `month`,
	dim_isoweek.isoweek		    AS `week`,
	DAY(CACHE_TABLE.`date`)		AS `day`,
	CACHE_TABLE.`date`          AS `date`,
	'default'             		AS `dimension_type`,
	''                    		AS `dimension_value`,
    'channel_count'             AS `key`,
    `value`                     AS `value`,
    '{}'                        AS `payload`
FROM CACHE_TABLE
INNER JOIN 
(
	SELECT member_id
	FROM ods_c_member_authorize_d_f
	WHERE pt = ${ds}
	  AND run_fullDose_or_increment='fullDose'
) AS need_member_table ON CACHE_TABLE.sid = need_member_table.member_id
LEFT JOIN dim_date_isoweek_o_f AS dim_isoweek ON CACHE_TABLE.`date` = dim_isoweek.`date`;

---------------------------------------increment-----------------------------------------------

INSERT INTO TABLE ads_s_company_day_stat_d_f PARTITION(pt = ${ds})
SELECT 
	sid                         AS `sid`, 
	YEAR(CACHE_TABLE.`date`)	AS `year`,
	MONTH(CACHE_TABLE.`date`)	AS `month`,
	dim_isoweek.isoweek		    AS `week`,
	DAY(CACHE_TABLE.`date`)		AS `day`,
	CACHE_TABLE.`date`          AS `date`,
	'default'             		AS `dimension_type`,
	''                    		AS `dimension_value`,
    'channel_count'             AS `key`,
    `value`                     AS `value`,
    '{}'                        AS `payload`
FROM CACHE_TABLE
INNER JOIN 
(
	SELECT member_id
	FROM ods_c_member_authorize_d_f
	WHERE pt = ${ds}
	  AND run_fullDose_or_increment='increment'
) AS need_member_table ON CACHE_TABLE.sid = need_member_table.member_id
LEFT JOIN dim_date_isoweek_o_f AS dim_isoweek ON CACHE_TABLE.`date` = dim_isoweek.`date`
WHERE CACHE_TABLE.`date` = FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd');