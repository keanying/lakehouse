--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-21 14:56:48
--EMR任务只能运行在独享资源组上
--********************************************************************--
-- name ads_s_company_tourist_sex_age_stat_d_f
-- type Spark SQL
-- author liangleichen@12301.cc
-- create time 2022-11-14 17:29:05
-- desc 商户/景区 订单游客性别统计 - 每日运行全量数据


--------------------------------------------------------------------------------------------------


CREATE TABLE IF NOT EXISTS ads_s_company_tourist_sex_age_stat_d_f(
    `sid`         	INT   	COMMENT '商户ID',
    `year`        	INT   	COMMENT '年',
    `month`       	INT   	COMMENT '月',
    `week`        	INT   	COMMENT '周',
    `day`         	INT   	COMMENT '日',
    `date`        	STRING	COMMENT '全日期',
    `sex`         	STRING	COMMENT '性别',
    `age`         	INT   	COMMENT '年龄',
    `actual_count`	INT   	COMMENT '人数'
)PARTITIONED BY(
    pt        		INT     COMMENT	'更新数据截止时间'
)STORED AS ORC;


--------------------------------------------------------------------------------------------------

-- 商户角度
INSERT OVERWRITE TABLE ads_s_company_tourist_sex_age_stat_d_f PARTITION(pt = ${ds})
SELECT 
    tmp.`aids_seller_id`                    AS `sid`,
    YEAR(TO_DATE(tmp.`pay_date`))           AS `year`, 
    MONTH(TO_DATE(tmp.`pay_date`))          AS `month`,
    CAST(dim_isoweek.isoweek AS INT)        AS `week`,
    -- dim_isoweek.isoweek                     AS `week`,
    DAY(TO_DATE(tmp.`pay_date`))            AS `day`,
    tmp.`pay_date`                          AS `date`,
    tmp.`ticket_taker_sex`                  AS `sex`,
    tmp.`ticket_taker_age`                  AS `age`,
    COUNT(1)                                AS `actual_count`
FROM (
    SELECT 	
        `aids_seller_id`,
        `ticket_taker_sex`,
        `pay_date`,
        CASE
            WHEN `ticket_taker_age` BETWEEN 0 AND 7
            THEN 7
            WHEN `ticket_taker_age` BETWEEN 8 AND 17
            THEN 17
            WHEN `ticket_taker_age` BETWEEN 18 AND 27
            THEN 27
            WHEN `ticket_taker_age` BETWEEN 28 AND 40
            THEN 40
            WHEN `ticket_taker_age` BETWEEN 41 AND 60
            THEN 60
            ELSE -1
        END 	AS `ticket_taker_age`
    FROM dwd_order_split_d_i
    WHERE orderdate >= CAST(DATE_FORMAT(DATE_SUB(TO_DATE(CAST(${ds} AS STRING), 'yyyyMMdd'), 540), 'yyyyMMdd') AS INT)
        AND isnotnull(`aids_seller_id`) 
        AND isnotnull(`pay_date`)
) AS tmp
INNER JOIN (
	SELECT member_id
	FROM ods_c_member_authorize_d_f
	WHERE pt = ${ds}
) AS need_member_table
ON tmp.aids_seller_id = need_member_table.member_id
LEFT JOIN dim_date_isoweek_o_f AS dim_isoweek
ON tmp.`pay_date` = dim_isoweek.`date`
GROUP BY 
    tmp.`aids_seller_id`, 
    tmp.`ticket_taker_sex`, 
    tmp.`pay_date`, 
    dim_isoweek.isoweek,
    tmp.`ticket_taker_age`;


--------------------------------------------------------------------------------------------------


-- 景区角度
INSERT INTO TABLE ads_s_company_tourist_sex_age_stat_d_f PARTITION(pt = ${ds})
SELECT 
    tmp.`land_id`                           AS `sid`,
    YEAR(TO_DATE(tmp.`pay_date`))           AS `year`, 
    MONTH(TO_DATE(tmp.`pay_date`))          AS `month`,
    CAST(dim_isoweek.isoweek AS INT)        AS `week`,
    -- dim_isoweek.isoweek                     AS `week`,
    DAY(TO_DATE(tmp.`pay_date`))            AS `day`,
    tmp.`pay_date`                          AS `date`,
    tmp.`ticket_taker_sex`                  AS `sex`,
    tmp.`ticket_taker_age`                  AS `age`,
    COUNT(1)                                AS `actual_count`
FROM (
    SELECT 	
        `land_id`,
        `ticket_taker_sex`,
        TO_DATE(pay_time) AS `pay_date`,
        CASE
            WHEN `ticket_taker_age` BETWEEN 0 AND 7
            THEN 7
            WHEN `ticket_taker_age` BETWEEN 8 AND 17
            THEN 17
            WHEN `ticket_taker_age` BETWEEN 18 AND 27
            THEN 27
            WHEN `ticket_taker_age` BETWEEN 28 AND 40
            THEN 40
            WHEN `ticket_taker_age` BETWEEN 41 AND 60
            THEN 60
            ELSE -1
        END 	AS `ticket_taker_age`
    FROM dwd_order_d_i          
    WHERE booking_date >= CAST(DATE_FORMAT(DATE_SUB(TO_DATE(CAST(${ds} AS STRING), 'yyyyMMdd'), 540), 'yyyyMMdd') AS INT)
      AND isnotnull(`land_id`) 
      AND isnotnull(`pay_time`)
) AS tmp
INNER JOIN (
	SELECT land_id
	FROM ods_c_land_authorize_d_f
	WHERE pt = ${ds}
) AS need_land_table
ON tmp.land_id = need_land_table.land_id
LEFT JOIN dim_date_isoweek_o_f AS dim_isoweek
ON tmp.`pay_date` = dim_isoweek.`date` 
GROUP BY 
    tmp.`land_id`, 
    tmp.`ticket_taker_sex`, 
    tmp.`pay_date`, 
    dim_isoweek.isoweek,
    tmp.`ticket_taker_age`;

