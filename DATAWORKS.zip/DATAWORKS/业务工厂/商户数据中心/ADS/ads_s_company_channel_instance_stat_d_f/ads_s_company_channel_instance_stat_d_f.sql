--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-20 11:56:30
--EMR任务只能运行在独享资源组上
--********************************************************************--
-- 计算指标：分销商/景区， 渠道订单量金额
-- 时间维度key：昨日/yesterday、本周/currentWeek/、上周/lastWeek、本年/currentYear、去年/lastYear


CREATE TABLE IF NOT EXISTS ads_s_company_channel_instance_stat_d_f(
    `sid`           STRING  COMMENT '商户ID',
    `deadline`      STRING  COMMENT '统计日期',
    `time_range`    STRING  COMMENT '统计时间范围',
    `channel_id`    STRING  COMMENT '渠道id',
    `channel_name`  STRING  COMMENT '渠道名称',
    `paid_count`    BIGINT  COMMENT '已支付订单量',
    `paid_amount`   BIGINT  COMMENT '已支付订单金额'
) STORED AS ORC;


-------------------------------------------------------------------------------------------------------


DROP VIEW IF EXISTS cacheTable;
CACHE TABLE cacheTable
AS
SELECT 
    --商户id
    order_aids.aids_seller_id,
    --渠道id
    order_aids.booking_channel,
    --渠道名称
    order_aids.booking_channel_name,
    pay_date           
FROM 
(
    SELECT aids_seller_id, booking_channel, booking_channel_name, pay_date
    FROM dwd_order_split_d_i
    WHERE orderdate > CAST(DATE_FORMAT(DATE_SUB(TO_DATE(CAST(${ds} AS STRING), 'yyyyMMdd'), 365), 'yyyyMMdd') AS INT)
) AS order_aids
INNER JOIN 
(
    SELECT member_id
    FROM ods_c_member_authorize_d_f
    WHERE pt = ${ds}
      AND land_id IS NULL
) AS need_member_table
ON order_aids.aids_seller_id = need_member_table.member_id;


-------------------------------------------------------------------------------------------------------


-- 商户维度
INSERT OVERWRITE TABLE ads_s_company_channel_instance_stat_d_f
-- 昨日
SELECT  
    `aids_seller_id`                AS `sid`,
    from_unixtime(unix_timestamp(cast(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd')        AS `deadline`,
    'yesterday'                     AS `time_range`,
    `booking_channel`               AS `channel_id`,
    first(`booking_channel_name`)   AS `channel_name`,
    COUNT(1)                        AS `paid_count`,
    0                               AS `paid_amount`
FROM 
(
    SELECT  
        `aids_seller_id`,
        `booking_channel`,
        `booking_channel_name`
    FROM cacheTable
    WHERE pay_date = from_unixtime(unix_timestamp(cast(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd')
)
GROUP BY    
    `aids_seller_id`,
    `booking_channel`   

--本周
UNION ALL
SELECT  
    `aids_seller_id`                AS `sid`,
    from_unixtime(unix_timestamp(cast(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd')        AS `deadline`,
    'currentWeek'                   AS `time_range`,
    `booking_channel`               AS `channel_id`,
    FIRST(`booking_channel_name`)   AS `channel_name`,
    COUNT(1)                        AS `paid_count`,
    0                               AS `paid_amount`
FROM 
(
    SELECT  
        `aids_seller_id`,
        `booking_channel`,
        `booking_channel_name`
    FROM cacheTable
    WHERE `pay_date` >= DATE_SUB(SUBSTR(FROM_UNIXTIME(UNIX_TIMESTAMP(from_unixtime(unix_timestamp(cast(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd'), 'yyyy-MM-dd')),1,10),PMOD(DATEDIFF(SUBSTR(FROM_UNIXTIME(UNIX_TIMESTAMP(from_unixtime(unix_timestamp(cast(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd'), 'yyyy-MM-dd')),1,10),'1900-01-08'),7))
	  AND `pay_date` <= DATE_SUB(SUBSTR(FROM_UNIXTIME(UNIX_TIMESTAMP(from_unixtime(unix_timestamp(cast(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd'), 'yyyy-MM-dd')),1,10),PMOD(DATEDIFF(SUBSTR(FROM_UNIXTIME(UNIX_TIMESTAMP(from_unixtime(unix_timestamp(cast(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd'), 'yyyy-MM-dd')),1,10),'1900-01-08'),7)-6)
)
GROUP BY    
    `aids_seller_id`,
    `booking_channel` 

--上周
UNION ALL
SELECT  
    `aids_seller_id`                AS `sid`,
    from_unixtime(unix_timestamp(cast(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd')        AS `deadline`,
    'lastWeek'                      AS `time_range`,
    `booking_channel`               AS `channel_id`,
    FIRST(`booking_channel_name`)   AS `channel_name`,
    COUNT(1)                        AS `paid_count`,
    0                               AS `paid_amount`
FROM 
(
    SELECT  
        `aids_seller_id`,
        `booking_channel`,
        `booking_channel_name`
    FROM cacheTable
    WHERE `pay_date` >= DATE_SUB(SUBSTR(FROM_UNIXTIME(UNIX_TIMESTAMP(from_unixtime(unix_timestamp(cast(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd'), 'yyyy-MM-dd')),1,10),PMOD(DATEDIFF(SUBSTR(FROM_UNIXTIME(UNIX_TIMESTAMP(from_unixtime(unix_timestamp(cast(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd'), 'yyyy-MM-dd')),1,10),'1900-01-08'),7)+7)
	  AND `pay_date` <= DATE_SUB(SUBSTR(FROM_UNIXTIME(UNIX_TIMESTAMP(from_unixtime(unix_timestamp(cast(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd'), 'yyyy-MM-dd')),1,10),PMOD(DATEDIFF(SUBSTR(FROM_UNIXTIME(UNIX_TIMESTAMP(from_unixtime(unix_timestamp(cast(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd'), 'yyyy-MM-dd')),1,10),'1900-01-08'),7)+1)
)
GROUP BY    
    `aids_seller_id`,
    `booking_channel` 

--本年
UNION ALL
SELECT  
    `aids_seller_id`                AS `sid`,
    from_unixtime(unix_timestamp(cast(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd')        AS `deadline`,
    'currentYear'                   AS `time_range`,
    `booking_channel`               AS `channel_id`,
    FIRST(`booking_channel_name`)   AS `channel_name`,
    COUNT(1)                        AS `paid_count`,
    0                               AS `paid_amount`
FROM 
(
    SELECT  
        `aids_seller_id`,
        `booking_channel`,
        `booking_channel_name`
    FROM cacheTable
    WHERE YEAR(`pay_date`) = DATE_FORMAT(FROM_UNIXTIME(UNIX_TIMESTAMP(from_unixtime(unix_timestamp(cast(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd'), 'yyyy-MM-dd'), 'yyyy-MM-dd'),'yyyy')
)
GROUP BY    
    `aids_seller_id`,
    `booking_channel` 

--去年
UNION ALL
SELECT  
    `aids_seller_id`                AS `sid`,
    from_unixtime(unix_timestamp(cast(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd')        AS `deadline`,
    'lastYear'                      AS `time_range`,
    `booking_channel`               AS `channel_id`,
    FIRST(`booking_channel_name`)   AS `channel_name`,
    COUNT(1)                        AS `paid_count`,
    0                               AS `paid_amount`
FROM 
(
    SELECT  
        `aids_seller_id`,
        `booking_channel`,
        `booking_channel_name`
    FROM cacheTable
    WHERE YEAR(`pay_date`) = DATE_FORMAT(ADD_MONTHS(FROM_UNIXTIME(UNIX_TIMESTAMP(from_unixtime(unix_timestamp(cast(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd'), 'yyyy-MM-dd'), 'yyyy-MM-dd'),-12),'yyyy')
)
GROUP BY    
    `aids_seller_id`,
    `booking_channel`;


-------------------------------------------------------------------------------------------------------------------------------------------------- 
--------------------------------------------------------------------------------------------------------------------------------------------------


-- 基于景区id的统计使用缓存表
DROP VIEW IF EXISTS cacheTableLand;
CACHE TABLE cacheTableLand
AS
SELECT 
    --景区id
    memberTab.member_id     AS member_id,
    --渠道id
    orderTab.booking_channel,
    --渠道名称
    orderTab.booking_channel_name,
	-- 支付时间
	pay_date
FROM 
(
    SELECT land_id, booking_channel, booking_channel_name, TO_DATE(pay_time) AS pay_date
    FROM dwd_order_d_i
    WHERE booking_date >= CAST(DATE_FORMAT(DATE_SUB(TO_DATE(CAST(${ds} AS STRING), 'yyyyMMdd'), 365), 'yyyyMMdd') AS INT)
      AND ISNOTNULL(`land_id`)
) AS orderTab
INNER JOIN 
(
    SELECT member_id, land_id
    FROM ods_c_member_authorize_d_f
    WHERE pt = ${ds}
      AND land_id IS NOT NULL
) AS memberTab
ON orderTab.land_id = memberTab.land_id;


--------------------------------------------------------------------------------------------------------------------------------------------------


-- 景区维度
INSERT INTO TABLE ads_s_company_channel_instance_stat_d_f
-- 昨日
SELECT  
    `member_id`                		AS `sid`,
    from_unixtime(unix_timestamp(cast(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd')        AS `deadline`,
    'yesterday'                     AS `time_range`,
    `booking_channel`               AS `channel_id`,
    FIRST(`booking_channel_name`)   AS `channel_name`,
    COUNT(1)                        AS `paid_count`,
    0                               AS `paid_amount`
FROM 
(
    SELECT  
        `member_id`,
        `booking_channel`,
        `booking_channel_name`
    FROM cacheTableLand
    WHERE `pay_date` = from_unixtime(unix_timestamp(cast(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd')
)
GROUP BY    
    `member_id`,
    `booking_channel`   

--本周
UNION ALL
SELECT  
    `member_id`                		AS `sid`,
    from_unixtime(unix_timestamp(cast(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd')        AS `deadline`,
    'currentWeek'                   AS `time_range`,
    `booking_channel`               AS `channel_id`,
    FIRST(`booking_channel_name`)   AS `channel_name`,
    COUNT(1)                        AS `paid_count`,
    0                               AS `paid_amount`
FROM 
(
    SELECT  
        `member_id`,
        `booking_channel`,
        `booking_channel_name`
    FROM cacheTableLand
    WHERE `pay_date` >= DATE_SUB(SUBSTR(FROM_UNIXTIME(UNIX_TIMESTAMP(from_unixtime(unix_timestamp(cast(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd'), 'yyyy-MM-dd')),1,10),PMOD(DATEDIFF(SUBSTR(FROM_UNIXTIME(UNIX_TIMESTAMP(from_unixtime(unix_timestamp(cast(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd'), 'yyyy-MM-dd')),1,10),'1900-01-08'),7))
	  AND `pay_date` <= DATE_SUB(SUBSTR(FROM_UNIXTIME(UNIX_TIMESTAMP(from_unixtime(unix_timestamp(cast(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd'), 'yyyy-MM-dd')),1,10),PMOD(DATEDIFF(SUBSTR(FROM_UNIXTIME(UNIX_TIMESTAMP(from_unixtime(unix_timestamp(cast(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd'), 'yyyy-MM-dd')),1,10),'1900-01-08'),7)-6)
)
GROUP BY    
    `member_id`,
    `booking_channel` 

--上周
UNION ALL
SELECT  
    `member_id`                		AS `sid`,
    from_unixtime(unix_timestamp(cast(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd')        AS `deadline`,
    'lastWeek'                      AS `time_range`,
    `booking_channel`               AS `channel_id`,
    FIRST(`booking_channel_name`)   AS `channel_name`,
    COUNT(1)                        AS `paid_count`,
    0                               AS `paid_amount`
FROM 
(
    SELECT  
        `member_id`,
        `booking_channel`,
        `booking_channel_name`
    FROM cacheTableLand
    WHERE `pay_date` >= DATE_SUB(SUBSTR(FROM_UNIXTIME(UNIX_TIMESTAMP(from_unixtime(unix_timestamp(cast(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd'), 'yyyy-MM-dd')),1,10),PMOD(DATEDIFF(SUBSTR(FROM_UNIXTIME(UNIX_TIMESTAMP(from_unixtime(unix_timestamp(cast(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd'), 'yyyy-MM-dd')),1,10),'1900-01-08'),7)+7)
	  AND `pay_date` <= DATE_SUB(SUBSTR(FROM_UNIXTIME(UNIX_TIMESTAMP(from_unixtime(unix_timestamp(cast(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd'), 'yyyy-MM-dd')),1,10),PMOD(DATEDIFF(SUBSTR(FROM_UNIXTIME(UNIX_TIMESTAMP(from_unixtime(unix_timestamp(cast(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd'), 'yyyy-MM-dd')),1,10),'1900-01-08'),7)+1)
)  
GROUP BY    
    `member_id`,
    `booking_channel` 

--本年
UNION ALL
SELECT  
    `member_id`                		AS `sid`,
    from_unixtime(unix_timestamp(cast(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd')        AS `deadline`,
    'currentYear'                   AS `time_range`,
    `booking_channel`               AS `channel_id`,
    FIRST(`booking_channel_name`)   AS `channel_name`,
    COUNT(1)                        AS `paid_count`,
    0                               AS `paid_amount`
FROM 
(
    SELECT  
        `member_id`,
        `booking_channel`,
        `booking_channel_name`
    FROM cacheTableLand
    WHERE YEAR(`pay_date`) = DATE_FORMAT(FROM_UNIXTIME(UNIX_TIMESTAMP(from_unixtime(unix_timestamp(cast(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd'), 'yyyy-MM-dd'), 'yyyy-MM-dd'),'yyyy')
)
GROUP BY    
    `member_id`,
    `booking_channel` 

--去年
UNION ALL
SELECT  
    `member_id`                		AS `sid`,
    from_unixtime(unix_timestamp(cast(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd')        AS `deadline`,
    'lastYear'                      AS `time_range`,
    `booking_channel`               AS `channel_id`,
    FIRST(`booking_channel_name`)   AS `channel_name`,
    COUNT(1)                        AS `paid_count`,
    0                               AS `paid_amount`
FROM 
(
    SELECT  
        `member_id`,
        `booking_channel`,
        `booking_channel_name`
    FROM cacheTableLand
    WHERE YEAR(`pay_date`) = DATE_FORMAT(ADD_MONTHS(FROM_UNIXTIME(UNIX_TIMESTAMP(from_unixtime(unix_timestamp(cast(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd'), 'yyyy-MM-dd'), 'yyyy-MM-dd'),-12),'yyyy')
)
GROUP BY    
    `member_id`,
    `booking_channel`;

