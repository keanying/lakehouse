--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-19 17:16:42
--EMR任务只能运行在独享资源组上
--********************************************************************--

-- 计算指标：供应商每日新增分销商数

--------------------------------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS ads_distributor_add_count_d_f(
    `sid`                   INT     COMMENT  '商户ID',
    `year`                  INT     COMMENT  '年',
    `month`                 INT     COMMENT  '月',
    `week`                  INT     COMMENT  '周',
    `date`                  INT     COMMENT  '日',
    `fulldate`              STRING  COMMENT  '全日期',
    `distributor_add_count` INT     COMMENT  '新增分销商数'
) STORED AS ORC;

--------------------------------------------------------------------------------------------------
-- 数据写入自动转换
-- SET spark.sql.legacy.typeCoercion.mode = LEGACY;
-- SET spark.sql.mode = PERMISSIVE;
-- SET spark.sql.caseSensitive = false;
-- 大小写不敏感
SET spark.sql.caseSensitive = false;

INSERT OVERWRITE TABLE ads_distributor_add_count_d_f
--供应商每日新增分销商数
SELECT 
	r.parent_id         		AS `sid`,
	YEAR(TO_DATE(r.rectime))	AS `year`,
	MONTH(TO_DATE(r.rectime))	AS `month`,
	CAST(dim_isoweek.isoweek AS INT) `AS week`,
	-- dim_isoweek.isoweek			AS `week`,
	DAY(TO_DATE(r.rectime))		AS `date`,
    TO_DATE(r.rectime)  		AS `fulldate`,
	NVL(COUNT(1), 0)   			AS `distributor_add_count`
FROM 
(
	SELECT son_id, parent_id, STATUS, rectime, ship_type
	FROM ods_myuu_pft_member_relationship_d_f
	WHERE pt = ${ds}
	  -- 0为供销关系
	  AND ship_type = 0 
	  -- 0为正常
	  AND STATUS = 0
) AS r
INNER JOIN 
(
	SELECT member_id
	FROM ods_c_member_authorize_d_f
	WHERE pt = ${ds}
	  AND is_sid = 1
) AS need_member_table
ON r.parent_id = need_member_table.member_id
LEFT JOIN 
(
	SELECT id, STATUS
	FROM s_myuu_pft_member_d_f
	WHERE pt = ${ds}
	  -- 0为正常 3为未审核
	  AND STATUS IN (0, 3)
) AS m
ON r.son_id = m.id 
LEFT JOIN dim_date_isoweek_o_f AS dim_isoweek 
ON TO_DATE(r.rectime) = dim_isoweek.`date`
GROUP BY r.parent_id, TO_DATE(r.rectime), dim_isoweek.isoweek;

--------------------------------------------------------------------------------------------------

