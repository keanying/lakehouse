--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-19 17:14:32
--EMR任务只能运行在独享资源组上
--********************************************************************--
-- 计算指标：渠道复购次数
-- 维度值：时间维度（近30/90/180/365天）+ 渠道维度（全部渠道/每个渠道）+ 商户维度
-- 注意：每日计算全量数据


CREATE TABLE IF NOT EXISTS ads_channel_commodity_repurchase_d_f(
    sid                         STRING  COMMENT '商户ID',
    channel_id                  STRING  COMMENT '渠道id',
    channel_name                STRING  COMMENT '渠道名称',
    time_key                    INT     COMMENT '时间键值',
    paid_user_count             INT     COMMENT '购买人数',
    purchase_1_user_count       INT     COMMENT '购买1次人数',
    purchase_2_user_count       INT     COMMENT '购买2次人数',
    purchase_3_user_count       INT     COMMENT '购买3次人数',
    purchase_4_more_user_count  INT     COMMENT '购买3次以上人数',
    is_sid                      INT     COMMENT '为1则sid列为商户id,为0则sid列为景区id'
) STORED AS ORC;

----------------------------------------------------------------------------------------------------

DROP VIEW IF EXISTS cacheTable;
CACHE TABLE cacheTable
AS
SELECT 
    order_aids.aids_seller_id,          --商户id
    INT(order_aids.booking_channel),    --渠道id
    order_aids.booking_channel_name,    --渠道名称
    order_aids.aids_buyer_id,           --购买者id
    order_aids.orderdate                --购买时间            
FROM 
(
    SELECT aids_seller_id, booking_channel, booking_channel_name, aids_buyer_id, orderdate
    FROM dwd_order_split_d_i
    WHERE orderdate >= CAST(DATE_FORMAT(DATE_SUB(TO_DATE(CAST(${ds} AS STRING), 'yyyyMMdd'), 365), 'yyyyMMdd') AS INT)
) AS order_aids
INNER JOIN 
(
    SELECT member_id
    FROM ods_c_member_authorize_d_f
    WHERE pt = ${ds}
      AND is_sid = 1
) AS need_member_table
ON order_aids.aids_seller_id = need_member_table.member_id;

--------------------------------------------------------------------------------------------------

INSERT OVERWRITE TABLE ads_channel_commodity_repurchase_d_f
--近"30"天, "每个"商户, "全部"渠道
SELECT 
    30day_table_all_channel.sid,
    30day_table_all_channel.channel_id,
    30day_table_all_channel.channel_name,
    30day_table_all_channel.time_key,
    COUNT(30day_table_all_channel.buyer_id),
    SUM(IF(con = 1, 1, 0))      AS purchase_1_user_count,			--购买一次的
    SUM(IF(con = 2, 1, 0))      AS purchase_2_user_count,			--购买两次的
    SUM(IF(con = 3, 1, 0))      AS purchase_3_user_count,			--购买三次的
    SUM(IF(con >= 4, 1, 0))     AS purchase_4_more_user_count,	    --购买超过三次的
    1                           AS is_sid
FROM 
(
    SELECT
        --商户id
        aids_seller_id      AS  sid,
        --渠道id
        -1                  AS  channel_id,
        --渠道名称
        ''                  AS  channel_name,
        --标记本次计算30天内的数据
        30                  AS  time_key,
        --购买者id
        aids_buyer_id       AS  buyer_id,
        --购买者在此商户, 此渠道下, 本周期内, 购买了多少次
        COUNT(*)            AS  con
    FROM cacheTable
    --选择时间在30天内的订单
    WHERE orderdate >= CAST(DATE_FORMAT(DATE_SUB(TO_DATE(CAST(${ds} AS STRING), 'yyyyMMdd'), 30), 'yyyyMMdd') AS INT)
    GROUP BY aids_seller_id, aids_buyer_id
  ) AS 30day_table_all_channel
GROUP BY 
    sid, 
    channel_id, 
    channel_name, 
    time_key

--近"30"天, "每个"商户, "每个"渠道
UNION ALL
SELECT 
    30day_table_each_channel.sid,
    30day_table_each_channel.channel_id,
    30day_table_each_channel.channel_name,
    30day_table_each_channel.time_key,
    COUNT(30day_table_each_channel.buyer_id),
    SUM(IF(con = 1, 1, 0))  AS purchase_1_user_count,			--购买一次的
    SUM(IF(con = 2, 1, 0))  AS purchase_2_user_count,			--购买两次的
    SUM(IF(con = 3, 1, 0))  AS purchase_3_user_count,			--购买三次的
    SUM(IF(con >= 4, 1, 0)) AS purchase_4_more_user_count,	    --购买超过三次的
    1                       AS is_sid
FROM 
(
    SELECT
        --商户id
        aids_seller_id          AS  sid,
        --渠道id
        booking_channel         AS  channel_id,
        --渠道名称
        booking_channel_name    AS  channel_name,
        --标记本次计算30天内的数据
        30                      AS  time_key,
        --购买者id
        aids_buyer_id           AS  buyer_id,
        --购买者在此商户, 此渠道下, 本周期内, 购买了多少次
        COUNT(*)                AS  con
    FROM cacheTable
    --选择时间在30天内的订单
    WHERE orderdate >= CAST(DATE_FORMAT(DATE_SUB(TO_DATE(CAST(${ds} AS STRING), 'yyyyMMdd'), 30), 'yyyyMMdd') AS INT)
    GROUP BY   
        aids_seller_id, 
        booking_channel, 
        booking_channel_name, 
        aids_buyer_id
) AS 30day_table_each_channel
GROUP BY 
    sid, 
    channel_id, 
    channel_name, 
    time_key

--近"90"天, "每个"商户, "全部"渠道
UNION ALL
SELECT 
    90day_table_all_channel.sid,
    90day_table_all_channel.channel_id,
    90day_table_all_channel.channel_name,
    90day_table_all_channel.time_key,
    COUNT(90day_table_all_channel.buyer_id),
    SUM(IF(con = 1, 1, 0))  AS purchase_1_user_count,       --购买一次的
    SUM(IF(con = 2, 1, 0))  AS purchase_2_user_count,       --购买两次的
    SUM(IF(con = 3, 1, 0))  AS purchase_3_user_count,       --购买三次的
    SUM(IF(con >= 4, 1, 0)) AS purchase_4_more_user_count,	--购买超过三次的
    1                       AS is_sid
FROM 
(
    SELECT
        --商户id
        aids_seller_id    AS  sid,
        --渠道id
        -1                AS  channel_id,
        --渠道名称
        ''                AS  channel_name,
        --标记本次计算90天内的数据
        90                AS  time_key,
        --购买者id
        aids_buyer_id     AS  buyer_id,
        --购买者在此商户, 此渠道下, 本周期内, 购买了多少次
        COUNT(*)          AS  con
    FROM cacheTable
    --选择时间在90天内的订单
    WHERE orderdate >= CAST(DATE_FORMAT(DATE_SUB(TO_DATE(CAST(${ds} AS STRING), 'yyyyMMdd'), 90), 'yyyyMMdd') AS INT)
    GROUP BY aids_seller_id, aids_buyer_id
) AS 90day_table_all_channel
GROUP BY 
    sid, 
    channel_id, 
    channel_name, 
    time_key

--近"90"天, "每个"商户, "每个"渠道
UNION ALL
SELECT 
    90day_table_each_channel.sid,
    90day_table_each_channel.channel_id,
    90day_table_each_channel.channel_name,
    90day_table_each_channel.time_key,
    COUNT(90day_table_each_channel.buyer_id),
    SUM(IF(con = 1, 1, 0))  AS purchase_1_user_count,       --购买一次的
    SUM(IF(con = 2, 1, 0))  AS purchase_2_user_count,       --购买两次的
    SUM(IF(con = 3, 1, 0))  AS purchase_3_user_count,       --购买三次的
    SUM(IF(con >= 4, 1, 0)) AS purchase_4_more_user_count,  --购买超过三次的
    1                       AS is_sid
FROM 
(
    SELECT
        --商户id
        aids_seller_id          AS  sid,
        --渠道id
        booking_channel         AS  channel_id,
        --渠道名称
        booking_channel_name    AS  channel_name,
        --标记本次计算90天内的数据
        90                      AS  time_key,
        --购买者id
        aids_buyer_id           AS  buyer_id,
        --购买者在此商户, 此渠道下, 本周期内, 购买了多少次
        COUNT(*)                AS  con
    FROM cacheTable
    --选择时间在90天内的订单
    WHERE orderdate >= CAST(DATE_FORMAT(DATE_SUB(TO_DATE(CAST(${ds} AS STRING), 'yyyyMMdd'), 90), 'yyyyMMdd') AS INT)
    GROUP BY 
        aids_seller_id, 
        booking_channel, 
        booking_channel_name, 
        aids_buyer_id
) AS 90day_table_each_channel
GROUP BY 
    sid, 
    channel_id, 
    channel_name, 
    time_key

--近"180"天, "每个"商户, "全部"渠道
UNION ALL
SELECT 
    180day_table_all_channel.sid,
    180day_table_all_channel.channel_id,
    180day_table_all_channel.channel_name,
    180day_table_all_channel.time_key,
    COUNT(180day_table_all_channel.buyer_id),
    SUM(IF(con = 1, 1, 0))  AS purchase_1_user_count,       --购买一次的
    SUM(IF(con = 2, 1, 0))  AS purchase_2_user_count,       --购买两次的
    SUM(IF(con = 3, 1, 0))  AS purchase_3_user_count,       --购买三次的
    SUM(IF(con >= 4, 1, 0)) AS purchase_4_more_user_count,	--购买超过三次的
    1                       AS is_sid
FROM 
(
    SELECT
      --商户id
      aids_seller_id    AS  sid,
      --渠道id
      -1                AS  channel_id,
      --渠道名称
      ''                AS  channel_name,
      --标记本次计算180天内的数据
      180               AS  time_key,
      --购买者id
      aids_buyer_id     AS  buyer_id,
      --购买者在此商户, 此渠道下, 本周期内, 购买了多少次
      COUNT(*)          AS  con
    FROM cacheTable
    --选择时间在180天内的订单
    WHERE orderdate >= CAST(DATE_FORMAT(DATE_SUB(TO_DATE(CAST(${ds} AS STRING), 'yyyyMMdd'), 180), 'yyyyMMdd') AS INT)
    GROUP BY aids_seller_id, aids_buyer_id
) AS 180day_table_all_channel
GROUP BY 
    sid, 
    channel_id, 
    channel_name, 
    time_key

--近"180"天, "每个"商户, "每个"渠道
UNION ALL
SELECT 
    180day_table_each_channel.sid,
    180day_table_each_channel.channel_id,
    180day_table_each_channel.channel_name,
    180day_table_each_channel.time_key,
    COUNT(180day_table_each_channel.buyer_id),
    SUM(IF(con = 1, 1, 0))  AS purchase_1_user_count,       --购买一次的
    SUM(IF(con = 2, 1, 0))  AS purchase_2_user_count,       --购买两次的
    SUM(IF(con = 3, 1, 0))  AS purchase_3_user_count,       --购买三次的
    SUM(IF(con >= 4, 1, 0)) AS purchase_4_more_user_count,  --购买超过三次的
    1                       AS is_sid
FROM 
(
    SELECT
      --商户id
      aids_seller_id        AS  sid,
      --渠道id
      booking_channel       AS  channel_id,
      --渠道名称
      booking_channel_name  AS  channel_name,
      --标记本次计算180天内的数据
      180                   AS  time_key,
      --购买者id
      aids_buyer_id         AS  buyer_id,
      --购买者在此商户, 此渠道下, 本周期内, 购买了多少次
      COUNT(*)              AS  con
    FROM cacheTable
    --选择时间在180天内的订单
    WHERE orderdate >= CAST(DATE_FORMAT(DATE_SUB(TO_DATE(CAST(${ds} AS STRING), 'yyyyMMdd'), 180), 'yyyyMMdd') AS INT)
    GROUP BY
        aids_seller_id, 
        booking_channel, 
        booking_channel_name, 
        aids_buyer_id
) AS 180day_table_each_channel
GROUP BY 
    sid, 
    channel_id, 
    channel_name, 
    time_key

--近"365"天, "每个"商户, "全部"渠道
UNION ALL
SELECT 
    365day_table_all_channel.sid,
    365day_table_all_channel.channel_id,
    365day_table_all_channel.channel_name,
    365day_table_all_channel.time_key,
    COUNT(365day_table_all_channel.buyer_id),
    SUM(IF(con = 1, 1, 0))  AS purchase_1_user_count,       --购买一次的
    SUM(IF(con = 2, 1, 0))  AS purchase_2_user_count,       --购买两次的
    SUM(IF(con = 3, 1, 0))  AS purchase_3_user_count,       --购买三次的
    SUM(IF(con >= 4, 1, 0)) AS purchase_4_more_user_count,	--购买超过三次的
    1                       AS is_sid
FROM 
(
    SELECT
      --商户id
      aids_seller_id    AS  sid,
      --渠道id
      -1                AS  channel_id,
      --渠道名称
      ''                AS  channel_name,
      --标记本次计算365天内的数据
      365               AS  time_key,
      --购买者id
      aids_buyer_id     AS  buyer_id,
      --购买者在此商户, 此渠道下, 本周期内, 购买了多少次
      COUNT(*)          AS  con
    --选择时间在365天内的订单
    FROM cacheTable
    WHERE orderdate >= CAST(DATE_FORMAT(DATE_SUB(TO_DATE(CAST(${ds} AS STRING), 'yyyyMMdd'), 365), 'yyyyMMdd') AS INT)
    GROUP BY aids_seller_id, aids_buyer_id
) AS 365day_table_all_channel
GROUP BY 
    sid, 
    channel_id, 
    channel_name, 
    time_key

--近"365"天, "每个"商户, "每个"渠道
UNION ALL
SELECT 
    365day_table_each_channel.sid,
    365day_table_each_channel.channel_id,
    365day_table_each_channel.channel_name,
    365day_table_each_channel.time_key,
    COUNT(365day_table_each_channel.buyer_id),
    SUM(IF(con = 1, 1, 0))      AS purchase_1_user_count,       --购买一次的
    SUM(IF(con = 2, 1, 0))      AS purchase_2_user_count,       --购买两次的
    SUM(IF(con = 3, 1, 0))      AS purchase_3_user_count,       --购买三次的
    SUM(IF(con >= 4, 1, 0))     AS purchase_4_more_user_count,	--购买超过三次的
    1                           AS is_sid
FROM 
(
    SELECT
        --商户id
        aids_seller_id          AS sid,
        --渠道id
        booking_channel         AS channel_id,
        --渠道名称
        booking_channel_name    AS channel_name,
        --标记本次计算365天内的数据
        365                     AS time_key,
        --购买者id
        aids_buyer_id           AS buyer_id,
        --购买者在此商户, 此渠道下, 本周期内, 购买了多少次
        COUNT(*)                AS con
    FROM cacheTable
    --选择时间在365天内的订单
    WHERE orderdate >= CAST(DATE_FORMAT(DATE_SUB(TO_DATE(CAST(${ds} AS STRING), 'yyyyMMdd'), 365), 'yyyyMMdd') AS INT)
    GROUP BY
        aids_seller_id, 
        booking_channel, 
        booking_channel_name, 
        aids_buyer_id
) AS 365day_table_each_channel
GROUP BY 
    sid, 
    channel_id, 
    channel_name, 
    time_key;

-----------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------

-- 基于景区id的统计使用缓存表
DROP VIEW IF EXISTS cacheTableLand;
CACHE TABLE cacheTableLand
AS
SELECT  
    memberTab.member_id     AS aids_seller_id,      --景区维度的商户id
    orderTab.booking_channel,                       --渠道id
    orderTab.booking_channel_name,                  --渠道名称
    orderTab.booker_id      AS aids_buyer_id,       --购买者id
    orderTab.booking_date                           --购买时间       
FROM 
(
    SELECT land_id, booking_channel, booking_channel_name, booker_id, booking_date
    FROM dwd_order_d_i          
    WHERE booking_date >= CAST(DATE_FORMAT(DATE_SUB(TO_DATE(CAST(${ds} AS STRING), 'yyyyMMdd'), 540), 'yyyyMMdd') AS INT)
) AS orderTab
INNER JOIN 
(
    SELECT member_id, land_id
    FROM ods_c_member_authorize_d_f
    WHERE pt = ${ds}
      AND is_sid = 0
) AS memberTab
ON orderTab.land_id = memberTab.land_id;

----------------------------------------------------------------------------------------------

INSERT INTO TABLE ads_channel_commodity_repurchase_d_f
--近"30"天, "每个"商户, "全部"渠道
SELECT 
    30day_table_all_channel.sid,
    30day_table_all_channel.channel_id,
    30day_table_all_channel.channel_name,
    30day_table_all_channel.time_key,
    COUNT(30day_table_all_channel.buyer_id),
    SUM(IF(con = 1, 1, 0))      AS purchase_1_user_count,			--购买一次的
    SUM(IF(con = 2, 1, 0))      AS purchase_2_user_count,			--购买两次的
    SUM(IF(con = 3, 1, 0))      AS purchase_3_user_count,			--购买三次的
    SUM(IF(con >= 4, 1, 0))     AS purchase_4_more_user_count,	    --购买超过三次的
    0                           AS is_sid
FROM 
(
    SELECT
        --商户id
        aids_seller_id      AS  sid,
        --渠道id
        -1                  AS  channel_id,
        --渠道名称
        ''                  AS  channel_name,
        --标记本次计算30天内的数据
        30                  AS  time_key,
        --购买者id
        aids_buyer_id       AS  buyer_id,
        --购买者在此商户, 此渠道下, 本周期内, 购买了多少次
        COUNT(*)            AS  con
    FROM cacheTableLand
    --选择时间在30天内的订单
    WHERE booking_date >= CAST(DATE_FORMAT(DATE_SUB(TO_DATE(CAST(${ds} AS STRING), 'yyyyMMdd'), 30), 'yyyyMMdd') AS INT)
    GROUP BY aids_seller_id, aids_buyer_id
) AS 30day_table_all_channel
GROUP BY 
    sid, 
    channel_id, 
    channel_name, 
    time_key

--近"30"天, "每个"商户, "每个"渠道
UNION ALL
SELECT 
    30day_table_each_channel.sid,
    30day_table_each_channel.channel_id,
    30day_table_each_channel.channel_name,
    30day_table_each_channel.time_key,
    COUNT(30day_table_each_channel.buyer_id),
    SUM(IF(con = 1, 1, 0))      AS purchase_1_user_count,			--购买一次的
    SUM(IF(con = 2, 1, 0))      AS purchase_2_user_count,			--购买两次的
    SUM(IF(con = 3, 1, 0))      AS purchase_3_user_count,			--购买三次的
    SUM(IF(con >= 4, 1, 0))     AS purchase_4_more_user_count,	    --购买超过三次的
    0                           AS is_sid
FROM 
(
    SELECT
        --商户id
        aids_seller_id          AS  sid,
        --渠道id
        booking_channel         AS  channel_id,
        --渠道名称
        booking_channel_name    AS  channel_name,
        --标记本次计算30天内的数据
        30                      AS  time_key,
        --购买者id
        aids_buyer_id           AS  buyer_id,
        --购买者在此商户, 此渠道下, 本周期内, 购买了多少次
        COUNT(*)                AS  con
    FROM cacheTableLand
    --选择时间在30天内的订单
    WHERE booking_date >= CAST(DATE_FORMAT(DATE_SUB(TO_DATE(CAST(${ds} AS STRING), 'yyyyMMdd'), 30), 'yyyyMMdd') AS INT)
    GROUP BY   
        aids_seller_id, 
        booking_channel, 
        booking_channel_name, 
        aids_buyer_id
) AS 30day_table_each_channel
GROUP BY 
    sid, 
    channel_id, 
    channel_name, 
    time_key

--近"90"天, "每个"商户, "全部"渠道
UNION ALL
SELECT 
    90day_table_all_channel.sid,
    90day_table_all_channel.channel_id,
    90day_table_all_channel.channel_name,
    90day_table_all_channel.time_key,
    COUNT(90day_table_all_channel.buyer_id),
    SUM(IF(con = 1, 1, 0))      AS purchase_1_user_count,       --购买一次的
    SUM(IF(con = 2, 1, 0))      AS purchase_2_user_count,       --购买两次的
    SUM(IF(con = 3, 1, 0))      AS purchase_3_user_count,       --购买三次的
    SUM(IF(con >= 4, 1, 0))     AS purchase_4_more_user_count,	--购买超过三次的
    0                           AS is_sid
FROM 
(
    SELECT
        --商户id
        aids_seller_id    AS  sid,
        --渠道id
        -1                AS  channel_id,
        --渠道名称
        ''                AS  channel_name,
        --标记本次计算90天内的数据
        90                AS  time_key,
        --购买者id
        aids_buyer_id     AS  buyer_id,
        --购买者在此商户, 此渠道下, 本周期内, 购买了多少次
        COUNT(*)          AS  con
    FROM cacheTableLand
    --选择时间在90天内的订单
    WHERE booking_date >= CAST(DATE_FORMAT(DATE_SUB(TO_DATE(CAST(${ds} AS STRING), 'yyyyMMdd'), 90), 'yyyyMMdd') AS INT)
    GROUP BY aids_seller_id, aids_buyer_id
) AS 90day_table_all_channel
GROUP BY 
    sid, 
    channel_id, 
    channel_name, 
    time_key

--近"90"天, "每个"商户, "每个"渠道
UNION ALL
SELECT 
    90day_table_each_channel.sid,
    90day_table_each_channel.channel_id,
    90day_table_each_channel.channel_name,
    90day_table_each_channel.time_key,
    COUNT(90day_table_each_channel.buyer_id),
    SUM(IF(con = 1, 1, 0))      AS purchase_1_user_count,       --购买一次的
    SUM(IF(con = 2, 1, 0))      AS purchase_2_user_count,       --购买两次的
    SUM(IF(con = 3, 1, 0))      AS purchase_3_user_count,       --购买三次的
    SUM(IF(con >= 4, 1, 0))     AS purchase_4_more_user_count,  --购买超过三次的
    0                           AS is_sid
FROM 
(
    SELECT
        --商户id
        aids_seller_id          AS  sid,
        --渠道id
        booking_channel         AS  channel_id,
        --渠道名称
        booking_channel_name    AS  channel_name,
        --标记本次计算90天内的数据
        90                      AS  time_key,
        --购买者id
        aids_buyer_id           AS  buyer_id,
        --购买者在此商户, 此渠道下, 本周期内, 购买了多少次
        COUNT(*)                AS  con
    FROM cacheTableLand
    --选择时间在90天内的订单
    WHERE booking_date >= CAST(DATE_FORMAT(DATE_SUB(TO_DATE(CAST(${ds} AS STRING), 'yyyyMMdd'), 90), 'yyyyMMdd') AS INT)
    GROUP BY 
        aids_seller_id, 
        booking_channel, 
        booking_channel_name, 
        aids_buyer_id
) AS 90day_table_each_channel
GROUP BY 
    sid, 
    channel_id, 
    channel_name, 
    time_key

--近"180"天, "每个"商户, "全部"渠道
UNION ALL
SELECT 
    180day_table_all_channel.sid,
    180day_table_all_channel.channel_id,
    180day_table_all_channel.channel_name,
    180day_table_all_channel.time_key,
    COUNT(180day_table_all_channel.buyer_id),
    SUM(IF(con = 1, 1, 0))      AS purchase_1_user_count,       --购买一次的
    SUM(IF(con = 2, 1, 0))      AS purchase_2_user_count,       --购买两次的
    SUM(IF(con = 3, 1, 0))      AS purchase_3_user_count,       --购买三次的
    SUM(IF(con >= 4, 1, 0))     AS purchase_4_more_user_count,	--购买超过三次的
    0                           AS is_sid
FROM 
(
    SELECT
      --商户id
      aids_seller_id    AS  sid,
      --渠道id
      -1                AS  channel_id,
      --渠道名称
      ''                AS  channel_name,
      --标记本次计算180天内的数据
      180               AS  time_key,
      --购买者id
      aids_buyer_id     AS  buyer_id,
      --购买者在此商户, 此渠道下, 本周期内, 购买了多少次
      COUNT(*)          AS  con
    FROM cacheTableLand
    --选择时间在180天内的订单
    WHERE booking_date >= CAST(DATE_FORMAT(DATE_SUB(TO_DATE(CAST(${ds} AS STRING), 'yyyyMMdd'), 180), 'yyyyMMdd') AS INT)
    GROUP BY aids_seller_id, aids_buyer_id
) AS 180day_table_all_channel
GROUP BY 
    sid, 
    channel_id, 
    channel_name, 
    time_key

--近"180"天, "每个"商户, "每个"渠道
UNION ALL
SELECT 
    180day_table_each_channel.sid,
    180day_table_each_channel.channel_id,
    180day_table_each_channel.channel_name,
    180day_table_each_channel.time_key,
    COUNT(180day_table_each_channel.buyer_id),
    SUM(IF(con = 1, 1, 0))      AS purchase_1_user_count,       --购买一次的
    SUM(IF(con = 2, 1, 0))      AS purchase_2_user_count,       --购买两次的
    SUM(IF(con = 3, 1, 0))      AS purchase_3_user_count,       --购买三次的
    SUM(IF(con >= 4, 1, 0))     AS purchase_4_more_user_count,  --购买超过三次的
    0                           AS is_sid
FROM 
(
    SELECT
      --商户id
      aids_seller_id        AS  sid,
      --渠道id
      booking_channel       AS  channel_id,
      --渠道名称
      booking_channel_name  AS  channel_name,
      --标记本次计算180天内的数据
      180                   AS  time_key,
      --购买者id
      aids_buyer_id         AS  buyer_id,
      --购买者在此商户, 此渠道下, 本周期内, 购买了多少次
      COUNT(*)              AS  con
    FROM cacheTableLand
    --选择时间在180天内的订单
    WHERE booking_date >= CAST(DATE_FORMAT(DATE_SUB(TO_DATE(CAST(${ds} AS STRING), 'yyyyMMdd'), 180), 'yyyyMMdd') AS INT)
    GROUP BY
        aids_seller_id, 
        booking_channel, 
        booking_channel_name, 
        aids_buyer_id
) AS 180day_table_each_channel
GROUP BY 
    sid, 
    channel_id, 
    channel_name, 
    time_key

--近"365"天, "每个"商户, "全部"渠道
UNION ALL
SELECT 
    365day_table_all_channel.sid,
    365day_table_all_channel.channel_id,
    365day_table_all_channel.channel_name,
    365day_table_all_channel.time_key,
    COUNT(365day_table_all_channel.buyer_id),
    SUM(IF(con = 1, 1, 0))      AS purchase_1_user_count,       --购买一次的
    SUM(IF(con = 2, 1, 0))      AS purchase_2_user_count,       --购买两次的
    SUM(IF(con = 3, 1, 0))      AS purchase_3_user_count,       --购买三次的
    SUM(IF(con >= 4, 1, 0))     AS purchase_4_more_user_count,	--购买超过三次的
    0                           AS is_sid
FROM 
(
    SELECT
      --商户id
      aids_seller_id    AS  sid,
      --渠道id
      -1                AS  channel_id,
      --渠道名称
      ''                AS  channel_name,
      --标记本次计算365天内的数据
      365               AS  time_key,
      --购买者id
      aids_buyer_id     AS  buyer_id,
      --购买者在此商户, 此渠道下, 本周期内, 购买了多少次
      COUNT(*)          AS  con
    --选择时间在365天内的订单
    FROM cacheTableLand
    WHERE booking_date >= CAST(DATE_FORMAT(DATE_SUB(TO_DATE(CAST(${ds} AS STRING), 'yyyyMMdd'), 365), 'yyyyMMdd') AS INT)
    GROUP BY aids_seller_id, aids_buyer_id
) AS 365day_table_all_channel
GROUP BY 
    sid, 
    channel_id, 
    channel_name, 
    time_key

--近"365"天, "每个"商户, "每个"渠道
UNION ALL
SELECT 
    365day_table_each_channel.sid,
    365day_table_each_channel.channel_id,
    365day_table_each_channel.channel_name,
    365day_table_each_channel.time_key,
    COUNT(365day_table_each_channel.buyer_id),
    SUM(IF(con = 1, 1, 0))      AS purchase_1_user_count,       --购买一次的
    SUM(IF(con = 2, 1, 0))      AS purchase_2_user_count,       --购买两次的
    SUM(IF(con = 3, 1, 0))      AS purchase_3_user_count,       --购买三次的
    SUM(IF(con >= 4, 1, 0))     AS purchase_4_more_user_count,	--购买超过三次的
    0                           AS is_sid
FROM 
(
    SELECT
        --商户id
        aids_seller_id          AS sid,
        --渠道id
        booking_channel         AS channel_id,
        --渠道名称
        booking_channel_name    AS channel_name,
        --标记本次计算365天内的数据
        365                     AS time_key,
        --购买者id
        aids_buyer_id           AS buyer_id,
        --购买者在此商户, 此渠道下, 本周期内, 购买了多少次
        COUNT(*)                AS con
    FROM cacheTableLand
    --选择时间在365天内的订单
    WHERE booking_date >= CAST(DATE_FORMAT(DATE_SUB(TO_DATE(CAST(${ds} AS STRING), 'yyyyMMdd'), 365), 'yyyyMMdd') AS INT)
    GROUP BY
        aids_seller_id, 
        booking_channel, 
        booking_channel_name, 
        aids_buyer_id
) AS 365day_table_each_channel
GROUP BY 
    sid, 
    channel_id, 
    channel_name, 
    time_key;

