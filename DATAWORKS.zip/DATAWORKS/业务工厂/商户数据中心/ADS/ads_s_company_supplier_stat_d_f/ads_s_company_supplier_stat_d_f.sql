--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-20 17:53:40
--EMR任务只能运行在独享资源组上
--********************************************************************--
-- name ads_s_company_supplier_stat_d_f
-- type Spark SQL
-- author liangleichen@12301.cc
-- create time 2022-11-15 15:59:23
-- desc 供应商产品支付情况每日统计


--------------------------------------------------------------------------------------------------


CREATE TABLE IF NOT EXISTS ads_s_company_supplier_stat_d_f(
    `sid`               INT     COMMENT '商户ID',
    `year`              INT     COMMENT '年',
    `month`             INT     COMMENT '月',
    `week`              INT     COMMENT '周',
    `date`              INT     COMMENT '日',
    `fulldate`          STRING  COMMENT '全日期',
    `supplier_id`       INT     COMMENT '供应商Id',
    `supplier_name`     STRING  COMMENT '供应商名称',
    `product_type_id`   STRING  COMMENT '产品类型Id',
    `product_type_name` STRING  COMMENT '产品类型名称',
    `product_id`        INT     COMMENT '产品Id',
    `product_name`      STRING  COMMENT '产品名称',
    `paid_count`        BIGINT  COMMENT '已支付订单量',
    `paid_amount`       BIGINT  COMMENT '已支付订单金额'
)PARTITIONED BY(
    pt                  INT     COMMENT  '更新数据截止时间'
)STORED AS ORC;

--------------------------------------------------------------------------------------------------


INSERT OVERWRITE TABLE ads_s_company_supplier_stat_d_f PARTITION(pt = ${ds})
SELECT  
    aids_buyer_id                 AS `sid`,
    YEAR(TO_DATE(pay_time))       AS `year`,
    MONTH(TO_DATE(pay_time))      AS `month`,
    -- dim_isoweek.isoweek           AS `week`,
    CAST(dim_isoweek.isoweek AS INT) AS `week`,
    DAY(TO_DATE(pay_time))        AS `date`,
    TO_DATE(pay_time)             AS `fulldate`,
    aids_seller_id                AS `supplier_id`,
    aids_sellername               AS `supplier_name`,
    land_type                     AS `product_type_id`,
    land_type_name                AS `product_type_name`,
    land_id                       AS `product_id`,
    land_name                     AS `product_name`,
    COUNT(1)                      AS `paid_count`,
    SUM(order_pay_amount)         AS `paid_amount`
FROM 
(
    SELECT aids_buyer_id, aids_seller_id, aids_sellername, land_type, land_type_name, land_id, land_name, pay_time, order_pay_amount
    FROM dwd_order_split_d_i
    WHERE orderdate >= CAST(DATE_FORMAT(DATE_SUB(TO_DATE(CAST(${ds} AS STRING), 'yyyyMMdd'), 540), 'yyyyMMdd') AS INT)
      AND ISNOTNULL(aids_seller_id)
      AND pay_time IS NOT NULL
      --过滤分销末级
      --AND aids_level NOT IN (0, -1)
) AS split
INNER JOIN 
(
    SELECT member_id
    FROM ods_c_member_authorize_d_f
    WHERE pt = ${ds}
) AS need_member_table
ON aids_buyer_id = need_member_table.member_id
LEFT JOIN dim_date_isoweek_o_f AS dim_isoweek
ON TO_DATE(pay_time) = dim_isoweek.`date`        
GROUP BY    
    aids_buyer_id,
    TO_DATE(pay_time),
    aids_seller_id,
    aids_sellername,
    dim_isoweek.isoweek,
    land_type,
    land_type_name,
    land_id,
    land_name;


--------------------------------------------------------------------------------------------------

