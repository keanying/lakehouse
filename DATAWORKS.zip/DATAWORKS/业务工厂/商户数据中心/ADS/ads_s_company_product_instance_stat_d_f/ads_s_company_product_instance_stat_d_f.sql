--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-20 17:52:26
--EMR任务只能运行在独享资源组上
--********************************************************************--
-- name ads_s_company_product_instance_stat_d_f
-- type Spark SQL
-- author liangleichen@12301.cc
-- create time 2022-08-31 17:16:38
-- 计算指标：商户数据中心v1.12 预定产品热度
-- 时间key：昨日/yesterday、本周/thisweek/、上周/lastweek、本年/thisyear、去年/lastyear


CREATE TABLE IF NOT EXISTS ads_s_company_product_instance_stat_d_f(
    `sid`             INT       COMMENT '商户ID',
    `deadline`        STRING    COMMENT '统计日期',
    `time_range`      STRING    COMMENT '统计时间范围',
    `product_id`      INT       COMMENT '产品ID',
    `product_name`    STRING    COMMENT '产品名称',
    `paid_count`      BIGINT    COMMENT '已支付订单量',
    `paid_amount`     BIGINT    COMMENT '已支付订单金额'
) STORED AS ORC;

-----------------------------------------------------------------------------

DROP VIEW IF EXISTS cacheTable;
CACHE TABLE cacheTable
AS
-- 商户角度
SELECT 
    order_aids.aids_seller_id,
    order_aids.land_id,
    order_aids.land_name,
    order_aids.pay_date
FROM 
(    
    SELECT aids_seller_id, land_id, land_name, pay_date
    FROM dwd_order_split_d_i
    WHERE orderdate >= CAST(CONCAT(YEAR(TO_DATE(${ds}, 'yyyyMMdd')) - 1, '0101') AS INT)
      AND ISNOTNULL(aids_seller_id)
) AS order_aids
INNER JOIN 
(
    SELECT member_id
    FROM ods_c_member_authorize_d_f
    WHERE pt = ${ds}
      AND land_id IS NULL
) AS need_member_table
ON order_aids.aids_seller_id = need_member_table.member_id;

-----------------------------------------------------------------------------

INSERT OVERWRITE TABLE ads_s_company_product_instance_stat_d_f
-- 昨日
SELECT  
    `aids_seller_id`            AS `sid`,
    FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd')    AS `deadline`,
    'yesterday'                 AS `time_range`,
    `land_id`                   AS `product_id`,
    FIRST(`land_name`)          AS `product_name`,
    COUNT(1)                    AS `paid_count`,
    0                           AS `paid_amount`
FROM 
(
    SELECT  
        `aids_seller_id`,
        `land_id`,
        `land_name`
    FROM cacheTable
    WHERE `pay_date` = FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd')
)
GROUP BY `aids_seller_id`, `land_id`

-- 本周
UNION ALL
SELECT  
    `aids_seller_id`            AS `sid`,
    FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd')    AS `deadline`,
    'currentWeek'               AS `time_range`,
    `land_id`                   AS `product_id`,
    FIRST(`land_name`)          AS `product_name`,
    COUNT(1)                    AS `paid_count`,
    0                           AS `paid_amount`
FROM 
(
    SELECT  
        `aids_seller_id`,
        `land_id`,
        `land_name`
    FROM cacheTable
    WHERE `pay_date` >= DATE_SUB(SUBSTR(FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd')),1,10),PMOD(DATEDIFF(SUBSTR(FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd')),1,10),'1900-01-08'),7))
      AND `pay_date` <= DATE_SUB(SUBSTR(FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd')),1,10),PMOD(DATEDIFF(SUBSTR(FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd')),1,10),'1900-01-08'),7)-6)
)
GROUP BY `aids_seller_id`, `land_id`

-- 上周
UNION ALL 
SELECT  
    `aids_seller_id`            AS `sid`,
    FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd')    AS `deadline`,
    'lastWeek'                  AS `time_range`,
    `land_id`                   AS `product_id`,
    FIRST(`land_name`)          AS `product_name`,
    COUNT(1)                    AS `paid_count`,
    0                           AS `paid_amount`
FROM 
(
    SELECT  
        `aids_seller_id`,
        `land_id`,
        `land_name`
    FROM cacheTable
    WHERE `pay_date` >= DATE_SUB(SUBSTR(FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd')),1,10),PMOD(DATEDIFF(SUBSTR(FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd')),1,10),'1900-01-08'),7)+7)
      AND `pay_date` <= DATE_SUB(SUBSTR(FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd')),1,10),PMOD(DATEDIFF(SUBSTR(FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd')),1,10),'1900-01-08'),7)+1)
)
GROUP BY `aids_seller_id`, `land_id`

UNION ALL 
-- 本年
SELECT  
    `aids_seller_id`            AS `sid`,
    FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd')    AS `deadline`,
    'currentYear'               AS `time_range`,
    `land_id`                   AS `product_id`,
    first(`land_name`)          AS `product_name`,
    COUNT(1)                    AS `paid_count`,
    0                           AS `paid_amount`
FROM 
(
    SELECT  
        `aids_seller_id`,
        `land_id`,
        `land_name`
    FROM cacheTable
    WHERE YEAR(`pay_date`) = DATE_FORMAT(FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd'),'yyyy')
)
GROUP BY `aids_seller_id`, `land_id`

-- 去年
UNION ALL
SELECT  
    `aids_seller_id`            AS `sid`,
    FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd')    AS `deadline`,
    'lastYear'                  AS `time_range`,
    `land_id`                   AS `product_id`,
    FIRST(`land_name`)          AS `product_name`,
    COUNT(1)                    AS `paid_count`,
    0                           AS `paid_amount`
FROM 
(
    SELECT  
        `aids_seller_id`,
        `land_id`,
        `land_name`
    FROM cacheTable
    WHERE YEAR(`pay_date`) = DATE_FORMAT(ADD_MONTHS(FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd'),-12),'yyyy')
)
GROUP BY `aids_seller_id`, `land_id`;

