--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-19 17:16:56
--EMR任务只能运行在独享资源组上
--********************************************************************--
-- 计算指标：供应商建立合作的分销商数
-- 结果范围：2022年元旦至今

--------------------------------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS ads_distributor_total_count_d_f(
    `sid`                       INT     COMMENT '商户ID',
    `year`                      INT     COMMENT '年',
    `month`                     INT     COMMENT '月',
    `week`                      INT     COMMENT '周',
    `date`                      INT     COMMENT '日',
    `fulldate`                  STRING  COMMENT '全日期',
    `distributor_total_count`   INT     COMMENT '分销商数'
)STORED AS ORC;

--------------------------------------------------------------------------------------------------

INSERT OVERWRITE TABLE ads_distributor_total_count_d_f
SELECT
    CAST(temp_table.parent_id AS INT)   AS `sid`,
    YEAR(temp_table.`date`)             AS `year`,
    MONTH(temp_table.`date`)            AS `month`,
    -- dim_isoweek.isoweek                 AS `week`,
    CAST(dim_isoweek.isoweek AS INT)    AS `week`,
    DAY(temp_table.`date`)              AS `day`,
    temp_table.`date`                   AS `fulldate`,
    NVL(temp_table.`value`,0)           AS `distributor_total_count`
FROM 
(
    SELECT
        result_full_date_and_sid.sid        AS `parent_id`,
        result_full_date_and_sid.full_date  AS `date`,
        MAX(base_table.`value`) OVER (PARTITION BY result_full_date_and_sid.sid ORDER BY result_full_date_and_sid.full_date)                               
                                            AS `value`
    FROM 
    (
        SELECT 
			need_member_table.member_id 	AS `sid`,
			need_date_table.need_date		AS `full_date`
		FROM 
        (
			SELECT member_id
			FROM ods_c_member_authorize_d_f
			WHERE pt= ${ds}
			  AND is_sid = 1
		) AS need_member_table
		FULL OUTER JOIN 
        (
			--使用date_add()以及posexplode()生成目标日期范围数据
			SELECT date_add("2013-01-01", a.pos) AS need_date
			FROM 
            (
				SELECT posexplode(SPLIT(REPEAT("@", DATEDIFF(FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd'), "2013-01-01")), "@"))
			) AS a
		) AS need_date_table
    ) AS result_full_date_and_sid
    LEFT JOIN 
    (
        -- 以下由原始数据计算得出, 由于原始数据缺失, 导致部分日期将缺失
        SELECT 
            everyday_supplier_count.parent_id       AS base_applyDid,
            everyday_supplier_count.base_date       AS base_date,
            -- 历史至今累加值
            SUM(everyday_supplier_count.everyday_count) OVER(PARTITION BY everyday_supplier_count.parent_id ORDER BY everyday_supplier_count.base_date)                                   
                                                    AS `value`
        FROM 
        (
            SELECT 
                r.parent_id         AS parent_id,
                TO_DATE(r.rectime)  AS base_date,
                count(1)            AS everyday_count
            FROM 
            (
                SELECT son_id, parent_id, STATUS, rectime, ship_type
                FROM ods_myuu_pft_member_relationship_d_f
                WHERE pt = ${ds}
				  -- 0为供销关系
				  AND ship_type = 0 
				  -- 0为正常
				  AND STATUS = 0
            ) AS r
            LEFT JOIN 
            (
                SELECT id, STATUS
                FROM s_myuu_pft_member_d_f
                WHERE pt = ${ds}
				  -- 0为正常 3为未审核
				  AND STATUS IN (0, 3)
            ) AS m
            ON r.son_id = m.id 
            GROUP BY r.parent_id, TO_DATE(r.rectime)
        ) AS everyday_supplier_count
    ) AS base_table
    ON result_full_date_and_sid.full_date = base_table.base_date 
    AND result_full_date_and_sid.sid = base_table.base_applyDid
    ORDER BY `parent_id`, `date`
) AS temp_table
LEFT JOIN dim_date_isoweek_o_f AS dim_isoweek 
ON TO_DATE(temp_table.`date`) = dim_isoweek.`date`
WHERE temp_table.`date` >= '2022-01-01';