--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-20 11:56:38
--EMR任务只能运行在独享资源组上
--********************************************************************--
-- 计算指标：商户/景区 渠道每日支付订单量及支付订单金额 
-- 注意：每日运行全量数据。后续任务"ads_s_company_day_stat_d_f" 需要基于此表全量数据

--------------------------------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS ads_s_company_channel_stat_d_f(
    `sid`               INT     COMMENT  '商户ID',
    `year`              INT     COMMENT  '年',
    `month`             INT     COMMENT  '月',
    `week`              INT     COMMENT  '周',
    `date`              INT     COMMENT  '日',
    `fulldate`          STRING  COMMENT  '全日期',
    `channel_id`        INT     COMMENT  '渠道Id',
    `channel_name`      STRING  COMMENT  '渠道名称',
    `paid_count`        BIGINT  COMMENT  '已支付订单量',
    `paid_ticket_count` BIGINT  COMMENT  '已支付票量',
    `paid_amount`       BIGINT  COMMENT  '已支付订单金额',
    `is_sid`            INT     COMMENT  '为1则sid列为商户id,为0则sid列为景区id'
) STORED AS ORC;


--------------------------------------------------------------------------------------------------


-- 商户角度计算
INSERT OVERWRITE TABLE ads_s_company_channel_stat_d_f
SELECT
    orderTab.aids_seller_id AS `sid`,
    YEAR(orderTab.pay_date) AS `year`,
    MONTH(orderTab.pay_date) AS `month`,
    CAST(dim_isoweek.isoweek AS INT) AS `week`,
    DAY(orderTab.pay_date) AS `date`,
    orderTab.pay_date AS `fulldate`,
    CAST(orderTab.booking_channel AS INT) AS `channel_id`,
    NVL(orderTab.booking_channel_name, '其他') AS `product_type_name`,
    COUNT(1) AS `paid_count`,
    SUM(origin_num) AS `paid_ticket_count`,
    SUM(orderTab.order_pay_amount) AS `paid_amount`,
    1 AS `is_sid`
FROM (
    SELECT 
        aids_seller_id, 
        booking_channel, 
        booking_channel_name, 
        order_pay_amount, 
        origin_num,
        TO_DATE(pay_time) AS pay_date
    FROM dwd_order_split_d_i
    WHERE 
        orderdate >= CAST(DATE_FORMAT(DATE_SUB(TO_DATE(CAST(${ds} AS STRING), 'yyyyMMdd'), 732), 'yyyyMMdd') AS INT)
        AND pay_time IS NOT NULL
) AS orderTab 
INNER JOIN (
    SELECT member_id
    FROM ods_c_member_authorize_d_f
    WHERE pt = ${ds}
        AND is_sid = 1
) AS memberTab ON orderTab.aids_seller_id = memberTab.member_id
LEFT JOIN dim_date_isoweek_o_f AS dim_isoweek 
    ON orderTab.pay_date = dim_isoweek.`date`
GROUP BY
    orderTab.pay_date,
    orderTab.aids_seller_id,
    orderTab.booking_channel,
    orderTab.booking_channel_name,
    dim_isoweek.isoweek;


--------------------------------------------------------------------------------------------------


-- 景区角度计算
INSERT INTO TABLE ads_s_company_channel_stat_d_f
SELECT
    CAST(memberTab.member_id AS INT) AS `sid`,
    YEAR(orderTab.pay_date) AS `year`,
    MONTH(orderTab.pay_date) AS `month`,
    CAST(dim_isoweek.isoweek AS INT) AS `week`,
    DAY(orderTab.pay_date) AS `date`,
    orderTab.pay_date AS `fulldate`,
    CAST(orderTab.booking_channel AS INT) AS `channel_id`,
    NVL(orderTab.booking_channel_name, '其他') AS `product_type_name`,
    COUNT(1) AS `paid_count`,
    SUM(origin_num) AS `paid_ticket_count`,
    SUM(orderTab.order_pay_amount) AS `paid_amount`,
    0 AS `is_sid`
FROM (
    SELECT 
        land_id, 
        booking_channel, 
        booking_channel_name, 
        order_pay_amount, 
        origin_num,
        TO_DATE(pay_time) AS pay_date
    FROM dwd_order_d_i          
    WHERE 
        booking_date >= CAST(DATE_FORMAT(DATE_SUB(TO_DATE(CAST(${ds} AS STRING), 'yyyyMMdd'), 732), 'yyyyMMdd') AS INT)
        AND pay_time IS NOT NULL
) AS orderTab 
INNER JOIN (
    SELECT member_id, land_id
    FROM ods_c_member_authorize_d_f
    WHERE pt = ${ds}
        AND is_sid = 0
) AS memberTab ON orderTab.land_id = memberTab.land_id
LEFT JOIN dim_date_isoweek_o_f AS dim_isoweek 
    ON orderTab.pay_date = dim_isoweek.`date`
GROUP BY
    memberTab.member_id,
    orderTab.pay_date,
    orderTab.booking_channel,
    orderTab.booking_channel_name,
    dim_isoweek.isoweek;


--------------------------------------------------------------------------------------------------