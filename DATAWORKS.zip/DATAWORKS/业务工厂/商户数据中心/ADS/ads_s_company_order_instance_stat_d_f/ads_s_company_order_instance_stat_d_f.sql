--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-20 16:37:47
--EMR任务只能运行在独享资源组上
--********************************************************************--
-- name ads_s_company_order_instance_stat_d_f
-- type Spark SQL
-- author liangleichen@12301.cc
-- create time 2022-08-31 15:37:04
-- 计算指标：商户数据中心v1.12 预订/验证/取消 + 单量/金额 + 昨日/本周/上周/本年/去年维度 
-- 时间key：昨日/yesterday、本周/currentWeek/、上周/lastWeek、本年/currentYear、去年/lastYear


CREATE TABLE IF NOT EXISTS ads_s_company_order_instance_stat_d_f(
    `sid`             STRING    COMMENT '商户ID',
    `deadline`        STRING    COMMENT '统计日期',
    `time_range`      STRING    COMMENT '统计时间范围',
    `paid_count`      BIGINT    COMMENT '已支付订单量',
    `paid_amount`     BIGINT    COMMENT '已支付订单金额',
    `verify_count`    BIGINT    COMMENT '验证订单量',
    `verify_amount`   BIGINT    COMMENT '验证订单金额',
    `cancel_count`    BIGINT    COMMENT '取消订单量',
    `cancel_amount`   BIGINT    COMMENT '取消订单金额'
) STORED AS ORC;

-- 优化的CTE定义，减少重复计算
WITH date_calculations AS (
  SELECT 
    FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd') AS target_date,
    -- 计算本周开始日期（周一）
    DATE_SUB(FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd'), 
             CAST(PMOD(UNIX_TIMESTAMP(FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd')) / (24*3600) - 1, 7) AS INT)) AS week_start,
    -- 计算上周开始日期
    DATE_SUB(DATE_SUB(FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd'), 
                      CAST(PMOD(UNIX_TIMESTAMP(FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd')) / (24*3600) - 1, 7) AS INT)), 7) AS last_week_start,
    -- 今年和去年
    YEAR(FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd')) AS current_year,
    YEAR(ADD_MONTHS(FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd'), -12)) AS last_year
),
-- 商户维度数据预处理
merchant_orders AS (
  SELECT 
    orderTable.aids_seller_id,
    orderTable.order_pay_amount,
    orderTable.pay_date,
    orderTable.verify_time,
    orderTable.cancel_date,
    dc.target_date,
    dc.week_start,
    dc.last_week_start,
    dc.current_year,
    dc.last_year
  FROM 
  (
    SELECT 
      aids_seller_id, 
      order_pay_amount, 
      TO_DATE(pay_time) AS pay_date, 
      TO_DATE(verify_time) AS verify_time, 
      TO_DATE(cancel_time) AS cancel_date
    FROM dwd_order_split_d_i
    WHERE orderdate >= CAST(DATE_FORMAT(DATE_SUB(TO_DATE(CAST(${ds} AS STRING), 'yyyyMMdd'), 540), 'yyyyMMdd') AS INT)
      AND ISNOTNULL(aids_seller_id)
  ) AS orderTable
  INNER JOIN 
  (
    SELECT member_id
    FROM ods_c_member_authorize_d_f
    WHERE pt = ${ds}
      AND land_id IS NULL
  ) AS need_member_table
  ON orderTable.aids_seller_id = need_member_table.member_id
  CROSS JOIN date_calculations dc
),
-- 景区维度数据预处理
land_orders AS (
  SELECT 
    memberTab.member_id AS sid,
    orderTab.order_pay_amount,
    orderTab.pay_date,
    orderTab.verify_time,
    orderTab.cancel_date,
    dc.target_date,
    dc.week_start,
    dc.last_week_start,
    dc.current_year,
    dc.last_year
  FROM 
  (
    SELECT 
      land_id, 
      order_pay_amount, 
      TO_DATE(pay_time) AS pay_date, 
      TO_DATE(verify_time) AS verify_time, 
      TO_DATE(cancel_time) AS cancel_date
    FROM dwd_order_d_i
    WHERE booking_date >= CAST(DATE_FORMAT(DATE_SUB(TO_DATE(CAST(${ds} AS STRING), 'yyyyMMdd'), 540), 'yyyyMMdd') AS INT)
  ) AS orderTab
  INNER JOIN 
  (
    SELECT member_id, land_id
    FROM ods_c_member_authorize_d_f
    WHERE pt = ${ds}
      AND land_id IS NOT NULL
  ) AS memberTab
  ON orderTab.land_id = memberTab.land_id
  CROSS JOIN date_calculations dc
),
-- 合并所有订单数据
all_orders AS (
  SELECT aids_seller_id as sid, order_pay_amount, pay_date, verify_time, cancel_date, target_date, week_start, last_week_start, current_year, last_year
  FROM merchant_orders
  UNION ALL
  SELECT sid, order_pay_amount, pay_date, verify_time, cancel_date, target_date, week_start, last_week_start, current_year, last_year
  FROM land_orders
),
-- 将订单转换为按不同时间范围统计的格式
order_metrics AS (
  -- 支付指标
  SELECT 
    sid,
    target_date AS deadline,
    CASE 
      WHEN pay_date = target_date THEN 'yesterday'
      WHEN pay_date >= week_start AND pay_date < DATE_ADD(week_start, 7) THEN 'currentWeek'
      WHEN pay_date >= last_week_start AND pay_date < week_start THEN 'lastWeek'
      WHEN YEAR(pay_date) = current_year THEN 'currentYear'
      WHEN YEAR(pay_date) = last_year THEN 'lastYear'
      ELSE NULL
    END AS time_range,
    1 AS paid_count,
    order_pay_amount AS paid_amount,
    0 AS verify_count,
    0 AS verify_amount,
    0 AS cancel_count,
    0 AS cancel_amount
  FROM all_orders
  WHERE pay_date IS NOT NULL
  UNION ALL
  -- 验证指标
  SELECT 
    sid,
    target_date AS deadline,
    CASE 
      WHEN verify_time = target_date THEN 'yesterday'
      WHEN verify_time >= week_start AND verify_time < DATE_ADD(week_start, 7) THEN 'currentWeek'
      WHEN verify_time >= last_week_start AND verify_time < week_start THEN 'lastWeek'
      WHEN YEAR(verify_time) = current_year THEN 'currentYear'
      WHEN YEAR(verify_time) = last_year THEN 'lastYear'
      ELSE NULL
    END AS time_range,
    0 AS paid_count,
    0 AS paid_amount,
    1 AS verify_count,
    order_pay_amount AS verify_amount,
    0 AS cancel_count,
    0 AS cancel_amount
  FROM all_orders
  WHERE verify_time IS NOT NULL
  UNION ALL
  -- 取消指标
  SELECT 
    sid,
    target_date AS deadline,
    CASE 
      WHEN cancel_date = target_date THEN 'yesterday'
      WHEN cancel_date >= last_week_start AND cancel_date < week_start THEN 'lastWeek'
      WHEN cancel_date >= week_start AND cancel_date < DATE_ADD(week_start, 7) THEN 'currentWeek'
      WHEN YEAR(cancel_date) = current_year THEN 'currentYear'
      WHEN YEAR(cancel_date) = last_year THEN 'lastYear'
      ELSE NULL
    END AS time_range,
    0 AS paid_count,
    0 AS paid_amount,
    0 AS verify_count,
    0 AS verify_amount,
    1 AS cancel_count,
    order_pay_amount AS cancel_amount
  FROM all_orders
  WHERE cancel_date IS NOT NULL
)

INSERT OVERWRITE TABLE ads_s_company_order_instance_stat_d_f
SELECT 
  sid,
  deadline,
  time_range,
  SUM(paid_count) AS paid_count,
  SUM(paid_amount) AS paid_amount,
  SUM(verify_count) AS verify_count,
  SUM(verify_amount) AS verify_amount,
  SUM(cancel_count) AS cancel_count,
  SUM(cancel_amount) AS cancel_amount
FROM order_metrics
WHERE time_range IS NOT NULL
GROUP BY sid, deadline, time_range;
