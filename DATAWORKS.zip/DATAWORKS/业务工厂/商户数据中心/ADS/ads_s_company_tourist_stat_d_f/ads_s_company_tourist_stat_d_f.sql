--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-21 14:56:54
--EMR任务只能运行在独享资源组上
--********************************************************************--
-- name ads_s_company_tourist_stat_d_f
-- type Spark SQL
-- author liangleichen@12301.cc
-- create time 2022-11-14 17:51:38
-- 指标内容：商户/景区_预定人数与实入人数 <每日运行全量数据>

--------------------------------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS ads_s_company_tourist_stat_d_f (
    `sid`           INT     COMMENT '商户ID',
    `year`          INT     COMMENT '年',
    `month`         INT     COMMENT '月',
    `week`          INT     COMMENT '周',
    `day`           INT     COMMENT '日',
    `date`          STRING  COMMENT '全日期',
    `advance_count` INT     COMMENT '预定人数',
    `actual_count`  INT     COMMENT '实入人数'
)PARTITIONED BY(
    pt       		INT     COMMENT	'更新数据截止时间'
)STORED AS ORC;

--------------------------------------------------------------------------------------------------

-- 商户维度
INSERT OVERWRITE TABLE ads_s_company_tourist_stat_d_f PARTITION (pt = ${ds})
SELECT
    CAST(`sid` AS INT)                  AS `sid`,
    YEAR(TO_DATE(tmp.`fulldate`))       AS `year`,
    MONTH(TO_DATE(tmp.`fulldate`))      AS `month`,
    CAST(dim_isoweek.isoweek AS INT)    AS `week`,
    DAY(TO_DATE(tmp.`fulldate`))        AS `day`,
    tmp.`fulldate`                      AS `date`,
    SUM(advance_count)                  AS `advance_count`,
    SUM(actual_count)                   AS `actual_count` 
FROM (      
    -- 验证人数
    SELECT
        aidsTable.land_publisher_id         AS `sid`,
        TO_DATE(trackTable.action_time)     AS `fulldate`,
        0                                   AS `advance_count`,
        SUM(trackTable.vertify_ticket_num)  AS `actual_count`
    FROM 
    (
        SELECT
            land_publisher_id   AS `land_publisher_id`,
            order_id            AS `order_id`
        FROM dwd_order_split_d_i
        -- WHERE orderdate >= DATE_SUB('${bdp.system.bizdate2}', 540)
        WHERE orderdate >= CAST(DATE_FORMAT(DATE_SUB(TO_DATE(CAST(${ds} AS STRING), 'yyyyMMdd'), 540), 'yyyyMMdd') AS INT)
          AND pay_time IS NOT NULL
    ) AS aidsTable              
    INNER JOIN 
    (
        SELECT order_id, action_time, vertify_ticket_num
        FROM ods_pft_order_track_d_f
        WHERE vertify_ticket_num IS NOT NULL
    ) AS trackTable          
    ON aidsTable.order_id = trackTable.order_id
	INNER JOIN 
    (
		SELECT member_id
		FROM ods_c_member_authorize_d_f
		WHERE pt = ${ds}
		  AND land_id IS NULL 
	) AS memberTable
	ON aidsTable.land_publisher_id = memberTable.member_id
    GROUP BY aidsTable.land_publisher_id, TO_DATE(trackTable.action_time)

    UNION ALL
    -- 预定人数
    SELECT
        land_publisher_id	AS `sid`,
        TO_DATE(pay_time)	AS `fulldate`,
        SUM(ticket_num)	    AS `advance_count`,
        0                	AS `actual_count`
    FROM 
    (
        SELECT
            order_id            AS `order_id`,
            land_publisher_id   AS `land_publisher_id`,
            pay_time            AS `pay_time`,
            ticket_num          AS `ticket_num`
        FROM dwd_order_split_d_i
        WHERE orderdate >= CAST(DATE_FORMAT(DATE_SUB(TO_DATE(CAST(${ds} AS STRING), 'yyyyMMdd'), 540), 'yyyyMMdd') AS INT)
          AND pay_time IS NOT NULL
    ) AS aidsTable 
	INNER JOIN 
    (
		SELECT member_id
		FROM ods_c_member_authorize_d_f
		WHERE pt = ${ds}
		  AND land_id IS NULL 
	) AS memberTable
	ON aidsTable.land_publisher_id = memberTable.member_id
    GROUP BY land_publisher_id, TO_DATE(pay_time)
) AS tmp
LEFT JOIN dim_date_isoweek_o_f AS dim_isoweek ON tmp.`fulldate` = dim_isoweek.`date`
GROUP BY sid, tmp.`fulldate`, dim_isoweek.isoweek;

--------------------------------------------------------------------------------------------------

-- 景区维度
INSERT INTO TABLE ads_s_company_tourist_stat_d_f PARTITION (pt = ${ds})
SELECT
    CAST(`member_id` AS INT)            AS `sid`,
    YEAR(TO_DATE(tmp.`fulldate`))       AS `year`,
    MONTH(TO_DATE(tmp.`fulldate`))      AS `month`,
    CAST(dim_isoweek.isoweek AS INT)    AS `week`,
    DAY(TO_DATE(tmp.`fulldate`))        AS `day`,
    tmp.`fulldate`                      AS `date`,
    SUM(advance_count)                  AS `advance_count`,
    SUM(actual_count)                   AS `actual_count` 
FROM 
(   
    -- 验证   
    SELECT
        memberTable.member_id               AS `member_id`,
        TO_DATE(trackTable.action_time)     AS `fulldate`,
        0                                   AS `advance_count`,
        SUM(trackTable.vertify_ticket_num)  AS `actual_count`
    FROM 
    (
        SELECT
            land_id     AS `land_id`,
            order_id    AS `order_id`
        FROM dwd_order_d_i          
        WHERE booking_date >= CAST(DATE_FORMAT(DATE_SUB(TO_DATE(CAST(${ds} AS STRING), 'yyyyMMdd'), 540), 'yyyyMMdd') AS INT)
            AND pay_time IS NOT NULL
        GROUP BY order_id, land_id
    ) AS orderTable             
    INNER JOIN 
    (
        SELECT order_id, action_time, vertify_ticket_num
        FROM ods_pft_order_track_d_f
        WHERE vertify_ticket_num IS NOT NULL
    ) AS trackTable              
    ON orderTable.order_id = trackTable.order_id 
	INNER JOIN 
    (
        SELECT land_id, member_id
        FROM ods_c_member_authorize_d_f
        WHERE pt = ${ds}
          AND land_id IS NOT NULL 
	) AS memberTable
	ON orderTable.land_id = memberTable.land_id
    GROUP BY memberTable.member_id, TO_DATE(trackTable.action_time)

    UNION ALL 
    -- 验证
    SELECT
        memberTable.member_id           AS `member_id`,
        TO_DATE(orderTable.pay_time)    AS `fulldate`,
        SUM(orderTable.ticket_num)	    AS `advance_count`,
        0                	            AS `actual_count`
    FROM 
    (
        SELECT
            order_id    AS `order_id`,
            land_id     AS `land_id`,
            pay_time    AS `pay_time`,
            ticket_num  AS `ticket_num`
        FROM dwd_order_d_i          
        WHERE booking_date >= CAST(DATE_FORMAT(DATE_SUB(TO_DATE(CAST(${ds} AS STRING), 'yyyyMMdd'), 540), 'yyyyMMdd') AS INT)
        AND pay_time IS NOT NULL
    ) AS orderTable
	INNER JOIN 
    (
        SELECT land_id, member_id
        FROM ods_c_member_authorize_d_f
        WHERE pt= ${ds}
          AND land_id IS NOT NULL 
	) AS memberTable
	ON orderTable.land_id = memberTable.land_id
    GROUP BY memberTable.member_id, TO_DATE(orderTable.pay_time)
) AS tmp
LEFT JOIN dim_date_isoweek_o_f AS dim_isoweek ON tmp.`fulldate` = dim_isoweek.`date`
GROUP BY member_id, tmp.`fulldate`, dim_isoweek.isoweek;

