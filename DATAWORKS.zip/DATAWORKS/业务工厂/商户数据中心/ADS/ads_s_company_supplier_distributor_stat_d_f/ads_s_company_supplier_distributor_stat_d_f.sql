--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-20 17:53:32
--EMR任务只能运行在独享资源组上
--********************************************************************--
-- name ads_s_company_supplier_distributor_stat_d_f
-- type Spark SQL
-- author liangleichen@12301.cc
-- create time 2022-11-16 14:26:00
-- desc 有订单分销商统计
-- 目前仅计算`distributor_order_count`这一个


--------------------------------------------------------------------------------------------------


CREATE TABLE IF NOT EXISTS ads_s_company_supplier_distributor_stat_d_f(
    `sid`                                   INT     COMMENT '商户ID',
    `year`                                  INT     COMMENT '年',
    `month`                                 INT     COMMENT '月',
    `week`                                  INT     COMMENT '周',
    `date`                                  INT     COMMENT '日',
    `fulldate`                              STRING  COMMENT '全日期',
    `distributor_total_count`               INT     COMMENT '分销商总数',
    `distributor_order_count`               INT     COMMENT '有单分销商数',
    `supplier_total_count`                  INT     COMMENT '供应商总数',
    `distributor_add_count`                 INT     COMMENT '分销商新增数',
    `distributor_order_new_count`           INT     COMMENT '有单分销商新增数',
    `supplier_distribution_product_count`   INT     COMMENT '供应商转分销产品总数',
    `supplier_supply_self_count`            INT     COMMENT '供应商供应我的产品数'
)PARTITIONED BY(
    pt       		                        INT     COMMENT	'更新数据截止时间'
)STORED AS ORC;


--------------------------------------------------------------------------------------------------


INSERT OVERWRITE TABLE ads_s_company_supplier_distributor_stat_d_f PARTITION(pt = ${ds})
SELECT
    sid                                 AS `sid`,
    YEAR(company.fulldate)              AS `year`,
    MONTH(company.fulldate)             AS `month`,
    CAST(dim_isoweek.isoweek AS INT)    AS `week`,
    DAY(company.fulldate)               AS `date`,
    company.fulldate                    AS `fulldate`,
    0                                   AS `distributor_total_count`,
    NVL(COUNT(DISTINCT distributor_id), 0)  AS `distributor_order_count`,
    0                                   AS `supplier_total_count`,
    0                                   AS `distributor_add_count`,
    0                                   AS `distributor_order_new_count`,
    0                                   AS `supplier_distribution_product_count`,
    0                                   AS `supplier_supply_self_count`
FROM ads_s_company_distributor_stat_d_f AS company
LEFT JOIN dim_date_isoweek_o_f AS dim_isoweek
ON company.fulldate = dim_isoweek.`date` 
-- WHERE pt='${bdp.system.bizdate}'
GROUP BY sid, company.fulldate, dim_isoweek.isoweek;


--------------------------------------------------------------------------------------------------


