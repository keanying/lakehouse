--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-21 14:57:00
--EMR任务只能运行在独享资源组上
--********************************************************************--
-- name ads_supplier_total_count_d_i_f
-- type Spark SQL
-- author liangleichen@12301.cc
-- create time 2022-11-09 19:15:44
-- desc 商户至今分销商数


--------------------------------------------------------------------------------------------------


CREATE TABLE IF NOT EXISTS ads_supplier_total_count_d_i(
    `sid`     				STRING	COMMENT '商户ID',
    `year`    				INT     COMMENT '年',
    `month`   				INT     COMMENT '月',
    `week`    				STRING 	COMMENT '周',
    `date`    				INT     COMMENT '日',
    `fulldate`				STRING  COMMENT '全日期',
    `supplier_total_count`  INT     COMMENT '分销商数'
)PARTITIONED BY(
    pt STRING  COMMENT  '更新数据截止时间'
)STORED AS ORC;


-------------------------------------------------CACHE TBALE-------------------------------------------------
-- 计算所有2021年元旦至今，所有开通商户数据中心服务商户的商户至今分销商数，载入缓冲表中

DROP VIEW IF EXISTS CACHE_TABLE;
CACHE TABLE CACHE_TABLE
AS
SELECT 
    result_table.sid                    AS `sid`,
    --YEAR(result_table.`date`)           AS `year`,
    --MONTH(result_table.`date`)          AS `month`,
    --ISOWEEK_UDF(result_table.`date`)    AS `week`,
    --DAY(result_table.`date`)            AS `day`,
    result_table.`date`                 AS `date`,
    --'default'                           AS `dimension_type`,
    --''                                  AS `dimension_value`,
    --'all_dis_member_count'              AS `key`,
    NVL(result_table.value, 0)          AS `value`
FROM 
(
	SELECT 
		result_full_date_and_sid.`sid`      AS `sid`,
		result_full_date_and_sid.`date`     AS `date`,
		MAX(result_deficiency_date_and_sid.`value`) OVER (PARTITION BY result_full_date_and_sid.`sid` ORDER BY result_full_date_and_sid.`date`)
											AS `value`
	FROM 
	(
		SELECT 
			need_member_table.member_id 	AS `sid`,
			need_date_table.need_date		AS `date`
		FROM 
		(
			SELECT member_id
			FROM ods_c_member_authorize_d_f
			WHERE pt = ${ds}
			--AND run_fullDose_or_increment='fullDose'
		) AS need_member_table
		FULL OUTER JOIN 
		(
			--使用date_add()以及posexplode()生成目标日期范围数据
			SELECT date_add("2021-01-01", a.pos) AS need_date
			FROM 
			(
				SELECT posexplode(SPLIT(REPEAT("@", DATEDIFF("2023-12-31", "2021-01-01")), "@"))
			) AS a
		) AS need_date_table
		WHERE need_date_table.need_date <= FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd')
	) AS result_full_date_and_sid
	LEFT JOIN 
	(
		-- 以下由原始数据计算得出, 由于原始数据缺失, 导致部分日期将缺失
        SELECT 
            everyday_supplier_count.son_id          AS `sid`,
            everyday_supplier_count.base_date       AS `date`,
            -- 历史至今累加值
            SUM(everyday_supplier_count.everyday_count) OVER(PARTITION BY everyday_supplier_count.son_id ORDER BY everyday_supplier_count.base_date)                                   
                                                    AS `value`
        FROM 
		(
            SELECT 
                r.son_id            AS `son_id`,
                TO_DATE(r.rectime)  AS `base_date`,
                COUNT(1)            AS `everyday_count`
            FROM 
			(
                SELECT son_id, parent_id, STATUS, rectime, ship_type
                FROM ods_myuu_pft_member_relationship_d_f
                WHERE pt = ${ds}
            ) AS r
            LEFT JOIN 
			(
                SELECT id, STATUS
                FROM s_myuu_pft_member_d_f
                WHERE pt = ${ds}
            ) AS m
            ON r.son_id = m.id 
            WHERE r.ship_type = 0 
				AND r.STATUS = 0 
				AND m.STATUS IN (0, 3) 
            GROUP BY r.son_id, TO_DATE(r.rectime)
        ) AS everyday_supplier_count
	) AS result_deficiency_date_and_sid
	ON result_full_date_and_sid.`sid` = result_deficiency_date_and_sid.`sid` 
		AND result_full_date_and_sid.`date` = result_deficiency_date_and_sid.`date`
	ORDER BY result_full_date_and_sid.sid, result_full_date_and_sid.date
) AS result_table;


-------------------------------------------------fullDose-------------------------------------------------


INSERT OVERWRITE TABLE ads_supplier_total_count_d_i PARTITION(pt = ${ds})
SELECT 
	sid, 
	YEAR(CACHE_TABLE.`date`)	AS `year`,
	MONTH(CACHE_TABLE.`date`)	AS `month`,
	dim_isoweek.isoweek      	AS `week`,
	DAY(CACHE_TABLE.`date`)		AS `date`,
	CACHE_TABLE.`date`			AS `fulldate`,
	`value`						AS `supplier_total_count`
FROM CACHE_TABLE
INNER JOIN 
(
	SELECT member_id
	FROM ods_c_member_authorize_d_f
	WHERE pt = ${ds}
		AND run_fullDose_or_increment='fullDose'
) AS need_member_table
ON CACHE_TABLE.sid = need_member_table.member_id
LEFT JOIN dim_date_isoweek_o_f AS dim_isoweek
ON CACHE_TABLE.`date` = dim_isoweek.`date`;


-------------------------------------------------increment-------------------------------------------------


INSERT INTO TABLE ads_supplier_total_count_d_i PARTITION(pt = ${ds})
SELECT 
	sid, 
	YEAR(CACHE_TABLE.`date`)	AS `year`,
	MONTH(CACHE_TABLE.`date`)	AS `month`,
	dim_isoweek.isoweek      	AS `week`,
	DAY(CACHE_TABLE.`date`)		AS `date`,
	CACHE_TABLE.`date`			AS `fulldate`,
	`value`						AS `supplier_total_count`
FROM CACHE_TABLE
INNER JOIN 
(
	SELECT member_id
	FROM ods_c_member_authorize_d_f
	WHERE pt = ${ds}
	  AND run_fullDose_or_increment='increment'
) AS need_member_table
ON CACHE_TABLE.sid = need_member_table.member_id
LEFT JOIN dim_date_isoweek_o_f AS dim_isoweek
ON CACHE_TABLE.`date` = dim_isoweek.`date`
WHERE CACHE_TABLE.`date` = FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd');


-------------------------------------------------------------------------------------------

