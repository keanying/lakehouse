--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-20 16:37:24
--EMR任务只能运行在独享资源组上
--********************************************************************--
-- name ads_s_company_distributor_stat_d_f
-- type Spark SQL
-- author liangleichen@12301.cc
-- create time 2022-11-15 18:06:20
-- desc 分销商/景区 每日销售产品订单量及金额统计
-- "ads_s_company_supplier_distributor_stat" 需要依赖此表全量数据


--------------------------------------------------------------------------------------------------


CREATE TABLE IF NOT EXISTS ads_s_company_distributor_stat_d_f(
    `sid`               INT     COMMENT '商户ID',
    `year`              INT     COMMENT '年',
    `month`             INT     COMMENT '月',
    `week`              INT     COMMENT '周',
    `date`              INT     COMMENT '日',
    `fulldate`          STRING  COMMENT '全日期',
    `distributor_id`    INT     COMMENT '分销商Id',
    `distributor_name`  STRING  COMMENT '分销商名称',
    `product_type_id`   STRING  COMMENT '产品类型Id',
    `product_type_name` STRING  COMMENT '产品类型名称',
    `product_id`        INT     COMMENT '产品Id',
    `product_name`      STRING  COMMENT '产品名称',
    `paid_count`        BIGINT  COMMENT '已支付订单量',
    `paid_ticket_count` BIGINT  COMMENT '已支付票量',
    `paid_amount`       BIGINT  COMMENT '已支付订单金额',
    `is_sid`            INT     COMMENT '为1则sid列为商户id,为0则sid列为景区id'
) STORED AS ORC;


--------------------------------------------------------------------------------------------------


-- 商户角度的统计结果
INSERT OVERWRITE TABLE ads_s_company_distributor_stat_d_f
SELECT  
    split_tab.aids_seller_id            AS `sid`,
    YEAR(TO_DATE(split_tab.pay_time))   AS `year`,
    MONTH(TO_DATE(split_tab.pay_time))  AS `month`,
    CAST(dim_isoweek.isoweek AS INT)    AS `week`,
    DAY(TO_DATE(split_tab.pay_time))    AS `date`,
    TO_DATE(split_tab.pay_time)         AS `fulldate`,
    split_tab.aids_buyer_id             AS `distributor_id`,
    NVL(split_tab.aids_buyername, '')   AS `distributor_name`,
    split_tab.land_type                 AS `product_type_id`,
    split_tab.land_type_name            AS `product_type_name`,
    split_tab.land_id                   AS `product_id`,
    split_tab.land_name                 AS `product_name`,
    COUNT(1)                            AS `paid_count`,
    SUM(split_tab.origin_num)           AS `paid_ticket_count`,
    SUM(split_tab.order_pay_amount)     AS `paid_amount`,
    1                                   AS `is_sid`
FROM 
(
    SELECT pay_time, aids_seller_id, pay_time, aids_buyer_id, aids_buyername, land_type, land_type_name, land_id, land_name, origin_num, order_pay_amount
    FROM dwd_order_split_d_i          
    WHERE orderdate >= CAST(DATE_FORMAT(DATE_SUB(TO_DATE(CAST(${ds} AS STRING), 'yyyyMMdd'), 732), 'yyyyMMdd') AS INT)
      AND pay_time IS NOT NULL
      -- 数据中1.1.10迭代加入不计算分销末级
      -- 2023/05/06修订中, 加入排除分销末级是游客的情况
      AND NOT(aids_level IN (0, -1) AND visitors = 1)
) AS split_tab
INNER JOIN 
(
	SELECT member_id
	FROM ods_c_member_authorize_d_f
	WHERE pt = ${ds}
      AND is_sid = 1
) AS need_member_table
ON split_tab.aids_seller_id = need_member_table.member_id
LEFT JOIN dim_date_isoweek_o_f AS dim_isoweek 
ON TO_DATE(split_tab.pay_time) = dim_isoweek.`date`
GROUP BY    
    split_tab.aids_seller_id,
    TO_DATE(split_tab.pay_time),
    dim_isoweek.isoweek,
    split_tab.aids_buyer_id,
    split_tab.aids_buyername,
    split_tab.land_type,
    split_tab.land_type_name,
    split_tab.land_id,
    split_tab.land_name;

--------------------------------------------------------------------------------------------------

-- 景区角度的统计结果
INSERT INTO TABLE ads_s_company_distributor_stat_d_f
SELECT  
    orderTab.land_id                    AS `sid`,
    YEAR(TO_DATE(pay_time))             AS `year`,
    MONTH(TO_DATE(pay_time))            AS `month`,
    CAST(dim_isoweek.isoweek AS INT)    AS `week`,
    DAY(TO_DATE(pay_time))              AS `date`,
    TO_DATE(pay_time)                   AS `fulldate`,
    orderTab.land_id                    AS `distributor_id`,
    NVL(ods_member.user_name, '')       AS `distributor_name`,
    orderTab.land_type                  AS `product_type_id`,
    orderTab.land_type_name             AS `product_type_name`,
    orderTab.land_id                    AS `product_id`,
    orderTab.land_name                  AS `product_name`,
    COUNT(1)                            AS `paid_count`,
    SUM(origin_num)                     AS `paid_ticket_count`,
    SUM(orderTab.order_pay_amount)      AS `paid_amount`,
    0                                   AS `is_sid`
FROM 
(
    SELECT land_id, pay_time, order_pay_amount, origin_num, land_type, land_type_name, land_id, land_name
    FROM dwd_order_d_i          
    WHERE booking_date >= CAST(DATE_FORMAT(DATE_SUB(TO_DATE(CAST(${ds} AS STRING), 'yyyyMMdd'), 732), 'yyyyMMdd') AS INT)
      AND pay_time IS NOT NULL
) AS orderTab 
INNER JOIN 
(
	SELECT land_id
	FROM ods_c_land_authorize_d_f
	WHERE pt = ${ds}
    --   AND is_sid = 0
) AS need_member_table
ON orderTab.land_id = need_member_table.land_id
LEFT JOIN dim_date_isoweek_o_f AS dim_isoweek 
ON TO_DATE(orderTab.pay_time) = dim_isoweek.`date`
LEFT JOIN 
(
    SELECT user_id, user_name
    FROM ods_pft_member_d_f
    WHERE pt = '${ds}'
) AS ods_member 
ON orderTab.land_id = ods_member.user_id
GROUP BY    
    orderTab.land_id,
    TO_DATE(pay_time),
    ods_member.user_name,
    dim_isoweek.isoweek,
    orderTab.land_type,
    orderTab.land_type_name,
    orderTab.land_id,
    orderTab.land_name;

