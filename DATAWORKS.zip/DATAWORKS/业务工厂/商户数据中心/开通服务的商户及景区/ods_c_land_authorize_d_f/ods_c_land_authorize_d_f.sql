--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-06 16:20:37
--EMR任务只能运行在独享资源组上
--********************************************************************--
-- 开通服务的景区id, 用于商户数据中心指标任务计算中, 以景区维度进行计算的任务使用. 
-- 目前仅有婺源集团下属的景区, 因此仅跑此一家公司的, 此后若有更多景区开通此项功能, 则此任务需要进行修改.


-- 开通商户数据中心服务的景区名单
CREATE TABLE IF NOT EXISTS ods_c_land_authorize_d_f(
    land_id                     STRING  COMMENT '商户ID',
    first_open_serve_date       STRING  COMMENT '商户首次开通服务时间',
    run_fullDose_or_increment   STRING  COMMENT '此商户本次运行全量指标结果or增量结果'
)PARTITIONED BY(
    pt                          STRING  COMMENT '更新数据截止时间'
)STORED AS ORC;


-- 婺源集团下属的景区id
INSERT INTO TABLE ods_c_land_authorize_d_f PARTITION(pt='${ds}') VALUES
(225340, '${ds}', 'fullDose'),
(225341, '${ds}', 'fullDose'),
(231776, '${ds}', 'fullDose'),
(231788, '${ds}', 'fullDose'),
(231792, '${ds}', 'fullDose'),
(231796, '${ds}', 'fullDose'),
(231798, '${ds}', 'fullDose'),
(231800, '${ds}', 'fullDose'),
(231803, '${ds}', 'fullDose'),
(231806, '${ds}', 'fullDose');


-- 由于后台暂时未给出数据源, 因此数仓手动添加数据, 后期后台添加数据源后, 需要进行修改
-- INSERT OVERWRITE TABLE ods_c_land_authorize_d_f PARTITION (pt='${ds}')
-- SELECT
--     land_id,                  
--     first_open_serve_date,    
--     run_fullDose_or_increment
-- FROM 
--     ods_c_land_authorize_d_f
-- WHERE pt='${ds}'-1;

