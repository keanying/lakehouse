--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2025-08-06 16:38:25
--EMR任务只能运行在独享资源组上
--********************************************************************--
-- 商户数据中心项目，每日需要计算的商户列表
-- 抽取RDS.bi_datav.c_member_authorize表的，每笔开通记录，计算出商户的最早开通时间和服务最晚结束时间


CREATE TABLE IF NOT EXISTS ods_c_member_authorize_d_f(
    member_id                   STRING  COMMENT '商户ID',
    land_id                     STRING  COMMENT '景区ID-非综管项目为null',
    first_open_serve_date       STRING  COMMENT '商户首次开通服务时间',
    last_expire_server_date     STRING  COMMENT '商户最晚结束服务时间',
    run_fullDose_or_increment   STRING  COMMENT '此商户本日运行全量指标结果or增量结果',
    is_fulldose                 INT     COMMENT '为1则为计算全量,为0则为计算增量',
    is_sid                      INT     COMMENT '为1则sid列为商户id,为0则sid列为景区id'
)PARTITIONED BY(
    pt                          INT     COMMENT '更新数据截止时间'
)STORED AS ORC;


INSERT OVERWRITE TABLE ods_c_member_authorize_d_f PARTITION (pt=${ds})
-- 开通的商户
SELECT 
    member_id, 
    NULL                        AS land_id,
    MIN(TO_DATE(begin_time))    AS first_open_serve_date, 
    MAX(TO_DATE(expire_time))   AS last_expire_server_date,
    IF(MIN(TO_DATE(begin_time)) = TO_DATE(${ds}, 'yyyyMMdd'), 'fullDose', 'increment') AS run_fullDose_or_increment,
    -- 'fullDose'  AS `run_fullDose_or_increment`
    IF(MIN(TO_DATE(begin_time)) = TO_DATE(${ds}, 'yyyyMMdd'), 1, 0) AS is_fulldose,
    1                           AS is_sid
FROM s_c_member_authorize_d_f
WHERE pt = ${ds} 
GROUP BY member_id
HAVING last_expire_server_date > TO_DATE(${ds}, 'yyyyMMdd') 

UNION ALL 

-- 需要计算的景区
SELECT 
    memberTab.id                AS member_id,
    landTab.id                  AS land_id,
    '2023-08-23'                AS first_open_serve_date, 
    '2099-01-01'                AS last_expire_server_date,
    'increment'                 AS run_fullDose_or_increment,
    0                           AS is_fulldose,
    0                           AS is_sid
FROM 
(
    SELECT id, salerid
    FROM ods_uu_land_d_f
    WHERE pt=${ds}
    -- 婺源集团下属十个景区lid
    AND id IN (225340, 225341, 231776, 231788, 231792, 231796, 231798, 231800, 231803, 231806)
) AS landTab
INNER JOIN 
(
    SELECT id, account
    FROM s_myuu_pft_member_d_f
    WHERE pt=${ds}
      AND dtype=2
) AS memberTab
ON memberTab.account = landTab.salerid;


-- 重置全部商户为计算全量数据使用
-- INSERT OVERWRITE TABLE ods_c_member_authorize_d_f PARTITION(pt='${ds}')
-- SELECT member_id, first_open_serve_date, last_expire_server_date, 'fullDose' 
-- FROM ods_c_member_authorize_d_f 
-- WHERE pt='${ds}';

