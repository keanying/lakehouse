--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨 (Optimized)
--create time: 2025-08-12 19:00:17
--EMR任务只能运行在独享资源组上
--********************************************************************--
-- desc 全民营销使用宽表

CREATE TABLE IF NOT EXISTS dwd_all_dis_orders_d_f(
    id                  BIGINT,
    order_id            STRING,
    member_id           BIGINT,
    sid                 BIGINT,
    pid                 BIGINT,
    aid                 BIGINT,
    tnum                INT,
    parent_id           BIGINT,
    grand_id            BIGINT,
    total_money         BIGINT,
    develop_money       BIGINT,
    recommend_money     BIGINT,
    return_money        BIGINT,
    update_time         BIGINT,
    status              TINYINT,
    order_status        BIGINT,
    order_pay_status    BIGINT,
    create_time         BIGINT,
    all_dis_type        TINYINT,
    dis_id              BIGINT,
    remain_money        BIGINT,
    money_config        STRING,
    is_new              TINYINT,
    is_issue            TINYINT,
    is_self             TINYINT,
    rec_id              BIGINT,
    pay_time            STRING,
    lid                 INT,
    title               STRING,
    parent_name         STRING,
    grand_name          STRING,
    dis_name            STRING
) PARTITIONED BY (
    pt                  INT
) STORED AS ORC;


-- =====================================================================
-- 使用 CTE (WITH) 统一管理子查询，提升可读性与执行计划复用度
-- =====================================================================
WITH 
-- 1. 会员维度表（被多次复用，提取出来让 Spark 优化器统一处理）
dim_member AS (
    SELECT id, dname 
    FROM s_myuu_pft_member_d_f 
    WHERE pt = ${ds}
),

-- 2. 景区维度表
dim_land AS (
    SELECT id, title 
    FROM ods_uu_land_d_f  
    WHERE pt = ${ds}
),

-- 3. 订单基础表
fact_order AS (
    SELECT  
        SUBSTR(pay_time, 1, 10)  AS pay_time, -- 规范化索引从 1 开始
        land_id                  AS lid, 
        product_id               AS pid, 
        order_id                 AS ordernum
    FROM dwd_order_d_i 
    WHERE booking_date > CAST(DATE_FORMAT(DATE_SUB(TO_DATE(CAST(${ds} AS STRING), 'yyyyMMdd'), 30), 'yyyyMMdd') AS INT)
),

-- 4. 全民营销主表（进行列裁剪与谓词下推优化）
fact_all_dis_orders AS (
    SELECT 
        id, order_id, member_id, sid, pid, aid, tnum, parent_id, grand_id,
        total_money, develop_money, recommend_money, return_money, update_time,
        status, order_status, order_pay_status, create_time, all_dis_type,
        dis_id, remain_money, money_config, is_new, is_issue, is_self, rec_id
    FROM ods_pft002_pft_all_dis_orders_d_f 
    WHERE pt = ${ds}
      -- 【性能核心优化】：将日期转换为时间戳常量进行对比，让底层 ORC 文件可以直接使用 create_time 索引过滤数据
      AND create_time >= UNIX_TIMESTAMP(CAST(DATE_SUB(TO_DATE(CAST(${ds} AS STRING), 'yyyyMMdd'), 732) AS STRING), 'yyyy-MM-dd')
)

-- =====================================================================
-- 数据组装与写入
-- =====================================================================
INSERT OVERWRITE TABLE dwd_all_dis_orders_d_f PARTITION (pt = ${ds})  
SELECT  
    a.id,
    a.order_id,
    a.member_id,
    a.sid,
    a.pid,
    a.aid,
    a.tnum,
    a.parent_id,
    a.grand_id,
    a.total_money,
    a.develop_money,
    a.recommend_money,
    a.return_money,
    a.update_time,
    a.status,
    a.order_status,
    a.order_pay_status,
    a.create_time,
    a.all_dis_type,
    a.dis_id,
    a.remain_money,
    a.money_config,
    a.is_new,
    a.is_issue,
    a.is_self,
    a.rec_id,
    
    o.pay_time,
    o.lid,
    
    l.title,
    
    p1.dname AS parent_name,
    p2.dname AS grand_name,
    p3.dname AS dis_name
    
FROM fact_all_dis_orders AS a
LEFT JOIN fact_order AS o 
    ON a.order_id = o.ordernum
LEFT JOIN dim_land AS l 
    ON o.lid = l.id
-- 连续 JOIN 三次相同 CTE，Spark 若发现表较小会自动执行 BroadcastHashJoin
LEFT JOIN dim_member AS p1 
    ON a.parent_id = p1.id
LEFT JOIN dim_member AS p2 
    ON a.grand_id = p2.id
LEFT JOIN dim_member AS p3 
    ON a.dis_id = p3.id;