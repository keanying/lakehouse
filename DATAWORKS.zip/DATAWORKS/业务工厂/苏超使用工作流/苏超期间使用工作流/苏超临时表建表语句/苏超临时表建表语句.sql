--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2026-04-10 15:02:39
--EMR任务只能运行在独享资源组上
--********************************************************************--


-- ------- 建表语句 
-- CREATE TABLE IF NOT EXISTS `s_tourist_info_d_i_temp`(
--     `id`            bigint  COMMENT '自增ID', 
--     `orderid`       string  COMMENT '订单号ID', 
--     `tourist`       string  COMMENT '游客姓名', 
--     `idcard`        string  COMMENT '游客身份信息', 
--     `voucher_type`  tinyint COMMENT '身份信息类型:1=身份证,2=护照,3=军官证,4=回乡证,5=台胞证,99=其他', 
--     `order_time`    int     COMMENT '逻辑下单时间', 
--     `update_time`   int     COMMENT '订单更新时间', 
--     `order_month`   tinyint COMMENT '逻辑下单月份', 
--     `mobile`        string  COMMENT '游客手机号', 
--     `check_state`   tinyint COMMENT '0未验证1已验证2已取消', 
--     `idx`           bigint  COMMENT '订单序号', 
--     `print_state`   tinyint COMMENT '打印状态0未打印1已打印', 
--     `check_time`    int     COMMENT '验证时间', 
--     `lid`           int     COMMENT '景点ID', 
--     `chk_code`      string  COMMENT '升级过的凭证号', 
--     `member_id`     bigint  COMMENT '游客ID', 
--     `is_checked`    tinyint COMMENT '这个门票码是否全部验证', 
--     `apply_did`     int     COMMENT '原始供应商ID', 
--     `sync_state`    tinyint COMMENT '是否同步标示 1:同步,0:无需同步', 
--     `mobile_area`   string  COMMENT '手机区号', 
--     `mobile_region` string  COMMENT '手机区号的区域代码'
-- )
-- COMMENT '游客身份证等信息表, 苏超用临时表';


-- CREATE TABLE IF NOT EXISTS `s_tourist_info_extend_d_i_temp`
-- (
--     `id`            string  COMMENT '自增ID', 
--     `orderid`       string  COMMENT '订单号ID', 
--     `idx`           string  COMMENT '订单游客序号', 
--     `end_time`      string  COMMENT '门票订单有效截止时间', 
--     `valid_num`     int     COMMENT '剩余可入园次数', 
--     `take_way`      int     COMMENT '取票方式:1=凭证号取票,2=手机号取票,3=身份证取票,4=订单号取票,5=团单号取票', 
--     `apply_did`     int     COMMENT '原始供应商ID', 
--     `ext_info`      string  COMMENT '拓展信息字段', 
--     `order_time`    int     COMMENT '逻辑下单时间', 
--     `update_time`   int     COMMENT '订单更新时间', 
--     `order_month`   tinyint COMMENT '逻辑下单月份', 
--     `sync_state`    tinyint COMMENT '是否同步标示 1:同步,0:无需同步'
-- )
-- COMMENT '游客身份证等信息表, 苏超用临时表';


-- CREATE TABLE IF NOT EXISTS `s_order_apply_d_i_temp`
-- (
--     `orderid`       string COMMENT '订单号', 
--     `origin_num`    bigint COMMENT '原始票数'
-- )
-- COMMENT '订单原始数据表, 苏超用临时表';


-- CREATE TABLE IF NOT EXISTS `s_tourist_track_d_i_temp`(
--     `id`              bigint    COMMENT '表ID', 
--     `ordernum`        string    COMMENT '订单号', 
--     `idx`             bigint    COMMENT '订单游客表序号', 
--     `track_action`    bigint    COMMENT '变更状态:1=入园,2=取消,3=过期,4=验证', 
--     `tid`             bigint    COMMENT '票类ID', 
--     `tnum`            bigint    COMMENT '变更次数', 
--     `left_num`        bigint    COMMENT '剩余可用次数', 
--     `source`          bigint    COMMENT '操作来源:0=终端机,1=软终端,2=自助机,3=外部通知更新,4=云票务,5=云闸机,6=PC-支付宝,7=手机支付宝,8=支付宝刷卡,9=支付宝扫码,10=微信支付,11=微信刷卡,12=微信扫码,13=PC-银联,14=手机-银联,15=PC-环迅,16=内部接口,17=外部接口,18=undefined,19=自运行服务,20=安卓智能终端机,21=验证服务器,22=微信商城,23=二级店铺,24=OTA,25=会员购票,26=年卡特权,27=平安银行,28=内部接口,29=民生乐收银,30=一卡通', 
--     `terminal`        bigint    COMMENT '终端号', 
--     `branch_terminal` bigint    COMMENT '分终端号', 
--     `saler_id`        bigint    COMMENT '现在存储站点ID', 
--     `insert_time`     int       COMMENT '添加时间', 
--     `oper_member`     bigint    COMMENT '操作用户', 
--     `msg`             string    COMMENT '备注信息', 
--     `ext_content`     string    COMMENT '验证或是取消过程中的一些数据', 
--     `order_time`      int       COMMENT '逻辑下单时间', 
--     `update_time`     int       COMMENT '订单更新时间', 
--     `order_month`     tinyint   COMMENT '逻辑下单月份', 
--     `apply_did`       int       COMMENT '原始供应商ID', 
--     `sync_state`      tinyint   COMMENT '是否同步标示 1:同步,0:无需同步'
-- )
-- COMMENT '门票订单变更追踪表-苏超临时表';

