--EMR Spark SQL
--********************************************************************--
--author: 梁雷晨
--create time: 2026-04-10 16:07:04
--EMR任务只能运行在独享资源组上
--********************************************************************--


CREATE TABLE IF NOT EXISTS `ods_tourist_info_d_i_temp`
(
    `apply_did`             INT     COMMENT '原始供应商ID', 
    `orderid`               STRING  COMMENT '订单号ID', 
    `multiple`              INT     COMMENT '放大倍数(本条预定游客数)',

    `age`                   STRING  COMMENT '年龄-来自身份证', 
    `sex`                   STRING  COMMENT '性别-来自身份证', 

    `country_name`          STRING  COMMENT '国家-优先使用字段', 
    `province_name`         STRING  COMMENT '省-优先使用字段', 
    `city_name`             STRING  COMMENT '市-优先使用字段', 
    `district_name`         STRING  COMMENT '区县-优先使用字段', 

    `phone_country_name`    STRING  COMMENT '国家-手机号归属地', 
    `phone_province_name`   STRING  COMMENT '省-手机号归属地', 
    `phone_city_name`       STRING  COMMENT '市-手机号归属地', 
    `phone_district_name`   STRING  COMMENT '区县-手机号归属地', 

    `idcard_country_name`   STRING  COMMENT '国家-证件归属地', 
    `idcard_province_name`  STRING  COMMENT '省-证件归属地', 
    `idcard_city_name`      STRING  COMMENT '市-证件归属地', 
    `idcard_district_name`  STRING  COMMENT '区县-证件归属地', 

    `idcard`                STRING  COMMENT '游客身份信息', 
    `voucher_type`          TINYINT COMMENT '身份信息类型:1=身份证,2=护照,3=军官证,4=回乡证,5=台胞证,99=其他', 
    `order_time`            INT     COMMENT '逻辑下单时间', 
    `mobile`                STRING  COMMENT '游客手机号', 
    `lid`                   INT     COMMENT '景点ID', 

    `id`                    BIGINT  COMMENT '自增ID', 
    `tourist`               STRING  COMMENT '游客姓名', 
    `update_time`           INT     COMMENT '订单更新时间', 
    `order_month`           TINYINT COMMENT '逻辑下单月份', 
    `check_state`           TINYINT COMMENT '0未验证1已验证2已取消', 
    `idx`                   BIGINT  COMMENT '订单序号', 
    `print_state`           TINYINT COMMENT '打印状态0未打印1已打印', 
    `check_time`            INT     COMMENT '验证时间', 
    `chk_code`              STRING  COMMENT '升级过的凭证号', 
    `member_id`             BIGINT  COMMENT '游客ID', 
    `is_checked`            TINYINT COMMENT '这个门票码是否全部验证', 
    `sync_state`            TINYINT COMMENT '是否同步标示 1:同步,0:无需同步'
)
COMMENT '游客身份证等信息表-苏超临时用表'
STORED AS ORC;


--------------------------------------------------------- 游客信息, 后续计算重复使用 ---------------------------------------------------------


DROP VIEW IF EXISTS tourist_table;
CACHE TABLE tourist_table
AS 
SELECT id, orderid, idcard, voucher_type, mobile, idx, mobile_area
FROM s_tourist_info_d_i_temp;


--------------------------------------------------------- 游客扩展信息表，解析年龄性别及地域 ---------------------------------------------------------
DROP VIEW IF EXISTS tourist_extend_table;
CACHE TABLE tourist_extend_table
AS 
SELECT 
    orderid, 
    idx,

    -- '中国'  AS country_name,
    age,

    CASE sex
        WHEN '1' THEN '男'
        WHEN '0' THEN '女'
        ELSE sex
    END     AS sex,

    CASE provinceName
        WHEN '香港'     THEN '香港特别行政区'
        WHEN '澳门'     THEN '澳门特别行政区'
        WHEN '台湾'     THEN '台湾省'
        ELSE provinceName
    END     AS province_name, 

    CASE provinceName
        WHEN '香港'     THEN '香港特别行政区'
        WHEN '澳门'     THEN '澳门特别行政区'
        WHEN '台湾'     THEN '台湾省'
        WHEN '台湾省'   THEN '台湾省'
        ELSE cityName
    END     AS city_name, 

    CASE provinceName
        WHEN '香港'     THEN '香港特别行政区'
        WHEN '澳门'     THEN '澳门特别行政区'
        WHEN '台湾'     THEN '台湾省'
        WHEN '台湾省'   THEN '台湾省'
        ELSE districtName
    END     AS district_name
FROM 
(
    SELECT 
        orderid, 
        idx,
        -- orderdate,
        GET_JSON_OBJECT(ext_info, '$.age')                  AS age, 
        GET_JSON_OBJECT(ext_info, '$.sex')                  AS sex,
        -- GET_JSON_OBJECT(ext_info, '$.area.city')            AS city,
        -- GET_JSON_OBJECT(ext_info, '$.area.region')          AS region,
        -- GET_JSON_OBJECT(ext_info, '$.area.country')         AS country,
        GET_JSON_OBJECT(ext_info, '$.area.cityName')        AS cityName,
        -- GET_JSON_OBJECT(ext_info, '$.area.district')        AS district,
        -- GET_JSON_OBJECT(ext_info, '$.area.province')        AS province,
        GET_JSON_OBJECT(ext_info, '$.area.districtName')    AS districtName,
        GET_JSON_OBJECT(ext_info, '$.area.provinceName')    AS provinceName
    FROM s_tourist_info_extend_d_i_temp
    WHERE ext_info != '{}'
)  
WHERE ISNOTNULL(cityName)
  AND ISNOTNULL(districtName)
  AND ISNOTNULL(provinceName)
  AND cityName != ''
  AND districtName != ''
  AND provinceName != ''
  AND cityName != 'null'
  AND districtName != 'null'
  AND provinceName != 'null';


--------------------------------------------------------- 证件归属地 ---------------------------------------------------------

DROP VIEW IF EXISTS area_table;
CACHE TABLE area_table
AS
-- voucher_type = 1 身份证
-- 使用地域信息扩展表信息
SELECT 
    id, 
    '中国'                      AS idcard_country_name,
    NVL(province_name, '未知')  AS idcard_province_name,
    NVL(city_name, '未知')      AS idcard_city_name,
    NVL(district_name, '未知')  AS idcard_district_name
FROM 
(
    SELECT id, orderid, idx
    FROM tourist_table 
    WHERE  voucher_type = 1
      -- AND LENGTH(idcard) = 18
) AS info
LEFT JOIN 
(
    SELECT *
    FROM tourist_extend_table 
) AS extend 
ON info.orderid = extend.orderid
AND info.idx = extend.idx

UNION ALL 

-- voucher_type = 2 护照
SELECT 
    id, 
    '境外'  AS idcard_country_name,
    '未知'  AS idcard_province_name,
    '未知'  AS idcard_city_name,
    '未知'  AS idcard_district_name
FROM tourist_table 
WHERE voucher_type = 2
    
UNION ALL 

-- voucher_type = 3  军官证
SELECT 
    id, 
    '中国'  AS idcard_country_name,
    '未知'  AS idcard_province_name,
    '未知'  AS idcard_city_name,
    '未知'  AS idcard_district_name
FROM tourist_table 
WHERE voucher_type = 3

UNION ALL 

-- voucher_type = 4 港澳居民来往大陆通行证（回乡证）
SELECT 
    id,
    '中国'      AS idcard_country_name,
    CASE 
        WHEN SUBSTR(idcard, 1, 1) = 'H' THEN '香港特别行政区'
        WHEN SUBSTR(idcard, 1, 1) = 'M' THEN '澳门特别行政区'
        ELSE  '未知'
    END        AS idcard_province_name,
    CASE 
        WHEN SUBSTR(idcard, 1, 1) = 'H' THEN '香港特别行政区'
        WHEN SUBSTR(idcard, 1, 1) = 'M' THEN '澳门特别行政区'
        ELSE  '未知'
    END         AS idcard_city_name,
    CASE 
        WHEN SUBSTR(idcard, 1, 1) = 'H' THEN '香港特别行政区'
        WHEN SUBSTR(idcard, 1, 1) = 'M' THEN '澳门特别行政区'
        ELSE  '未知'
    END         AS idcard_district_name
FROM tourist_table 
WHERE voucher_type = 4

UNION ALL 

-- voucher_type = 5  台胞证
SELECT 
    id, 
    '中国'      AS idcard_country_name,
    '台湾省'    AS idcard_province_name,
    '台湾省'    AS idcard_city_name,
    '台湾省'    AS idcard_district_name
FROM tourist_table 
WHERE voucher_type = 5

UNION ALL 

-- voucher_type = 6   外国人永久居留证
SELECT 
    id, 
    '中国'  AS idcard_country_name,
    '未知'  AS idcard_province_name,
    '未知'  AS idcard_city_name,
    '未知'  AS idcard_district_name
FROM tourist_table 
WHERE voucher_type = 6

UNION ALL 

-- voucher_type = 7  港澳通行证
SELECT 
    id, 
    '中国'  AS idcard_country_name,
    '未知'  AS idcard_province_name,    
    '未知'  AS idcard_city_name,
    '未知'  AS idcard_district_name
FROM tourist_table 
WHERE voucher_type = 7

UNION ALL 

-- voucher_type = 8  台湾通行证
SELECT 
    id, 
    '中国'      AS idcard_country_name,
    '台湾省'    AS idcard_province_name,
    '台湾省'    AS idcard_city_name,
    '台湾省'    AS idcard_district_name
FROM tourist_table 
WHERE voucher_type = 8

UNION ALL 

-- voucher_type = 9  港澳居民居住证
SELECT 
    id, 
    '中国'  AS idcard_country_name,
    CASE 
        WHEN SUBSTR(idcard, 1, 2) = 81 THEN '香港特别行政区'
        WHEN SUBSTR(idcard, 1, 2) = 82 THEN '澳门特别行政区'
        ELSE  '未知'
    END         AS idcard_province_name, 
    CASE 
        WHEN SUBSTR(idcard, 1, 2) = 81 THEN '香港特别行政区'
        WHEN SUBSTR(idcard, 1, 2) = 82 THEN '澳门特别行政区'
        ELSE  '未知'
    END         AS idcard_city_name,
    CASE 
        WHEN SUBSTR(idcard, 1, 2) = 81 THEN '香港特别行政区'
        WHEN SUBSTR(idcard, 1, 2) = 82 THEN '澳门特别行政区'
        ELSE  '未知'
    END         AS idcard_district_name
FROM tourist_table 
WHERE voucher_type = 9

UNION ALL 

-- voucher_type = 10  台湾居民居住证
SELECT 
    id, 
    '中国'      AS idcard_country_name,
    '台湾省'    AS idcard_province_name,
    '台湾省'    AS idcard_city_name,
    '台湾省'    AS idcard_district_name
FROM tourist_table 
WHERE voucher_type = 10

UNION ALL 

-- voucher_type = 99  其他
SELECT 
    id, 
    '未知'  AS idcard_country_name,
    '未知'  AS idcard_province_name,
    '未知'  AS idcard_city_name,
    '未知'  AS idcard_district_name
FROM tourist_table 
WHERE voucher_type = 99

UNION ALL 

-- voucher_type 其他取值
SELECT 
    id, 
    '未知'  AS idcard_country_name,
    '未知'  AS idcard_province_name,
    '未知'  AS idcard_city_name,
    '未知'  AS idcard_district_name
FROM tourist_table 
WHERE voucher_type NOT IN (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 99);


--------------------------------------------------------- 身份证性别年龄计算 ---------------------------------------------------------


-- CACHE TABLE age_sex_table 
-- AS
-- SELECT id, age, sex
-- FROM (
--     SELECT 
--         id, 
--         FLOOR (
--                 DATEDIFF(
--                     orderdate, 
--                     FROM_UNIXTIME(UNIX_TIMESTAMP(SUBSTR(idcard, 7, 8), 'yyyyMMdd'))
--                 ) / 365
--             )   AS age,
--         IF (SUBSTR(idcard, 17, 1) % 2 = 0, "女", "男")  AS sex
--     FROM tourist_table 
--     WHERE voucher_type = 1 
--       AND LENGTH(idcard) = 18
-- ) WHERE age >= 0 AND age <= 116;


--------------------------------------------------------- 一码多票情况 ---------------------------------------------------------


DROP VIEW IF EXISTS multiple_table;
CACHE TABLE multiple_table 
AS 
-- 一对多
SELECT 
    info.id             AS id,
    order.origin_num    AS tnum
FROM 
(
    -- 订单只有一个码
    SELECT 
        t1.id, 
        t1.orderid
    FROM 
    (
        SELECT id, orderid
        FROM tourist_table
    ) AS t1
    INNER JOIN 
    (
        SELECT orderid, COUNT(1) AS ct
        FROM tourist_table
        GROUP BY orderid
        HAVING ct = 1
    ) AS t2 
    ON t1.orderid = t2.orderid
) AS info
INNER JOIN 
(
    -- 订单多张票
    SELECT orderid, origin_num
    FROM s_order_apply_d_i_temp 
    WHERE 1 = 1
      AND origin_num > 1
) AS order
ON info.orderid = order.orderid;


--------------------------------------------------------- 手机号对应地域 ---------------------------------------------------------


-- 手机号码归属地
DROP VIEW IF EXISTS phone_area;
CACHE TABLE phone_area 
AS 
SELECT 
    id,

    -- 一个中国原则
    IF (
        dt.name_zh IN ('中国', '香港', '澳门', '台湾'),
        '中国',
        NVL(dt.name_zh, '未知')
    )                                       AS phone_country_name,

    -- 取票人省份
    IF (
        -- 港澳台的特殊处理
        dt.name_zh IN ('中国', '香港', '澳门', '台湾'),

        CASE dt.name_zh
            WHEN '香港' THEN '香港特别行政区'
            WHEN '澳门' THEN '澳门特别行政区'
            WHEN '台湾' THEN '台湾省'
            WHEN '中国' THEN IF(LENGTH(ot.mobile) = 11 AND ISNOTNULL(phone.province_name), phone.province_name, '未知')
        END, 

        -- 非中国情况
        IF (
            ISNULL(dt.name_zh) OR dt.name_zh = '',
            '未知',
            dt.name_zh
        )
    )                                       AS phone_province_name,

    -- 取票人市
    IF (
        -- 非中国情况
        dt.name_zh IN ('中国', '香港', '澳门', '台湾'),

        CASE dt.name_zh
            WHEN '香港' THEN '香港特别行政区'
            WHEN '澳门' THEN '澳门特别行政区'
            WHEN '台湾' THEN '台湾省'
            WHEN '中国' THEN IF(LENGTH(ot.mobile) = 11 AND ISNOTNULL(phone.city_name), phone.city_name, '未知')
        END, 

        -- 手机地域未知
        IF (
            ISNULL(dt.name_zh) OR dt.name_zh = '',
            '未知',
            dt.name_zh
        )
    )                                       AS phone_city_name     
FROM 
(
    SELECT id, mobile, mobile_area
    FROM tourist_table
    WHERE LENGTH(mobile) = 11
) AS ot
LEFT JOIN 
(
    -- 手机号国籍
    SELECT phone_area_code, name_zh
    FROM dim_phone_global_d_f
    WHERE pt = FROM_UNIXTIME(UNIX_TIMESTAMP(DATE_SUB(CURRENT_DATE, 1)), 'yyyyMMdd')
) AS dt 
ON ot.mobile_area = dt.phone_area_code
LEFT JOIN 
(
    -- 手机号码地区维表
    SELECT phone_number, province_name, city_name
    FROM dim_phone_city_fixed_d_f 
    WHERE pt = FROM_UNIXTIME(UNIX_TIMESTAMP(DATE_SUB(CURRENT_DATE, 1)), 'yyyyMMdd')
) AS phone 
ON SUBSTR(ot.mobile, 1, 7) = phone.phone_number;


--------------------------------------------------- 数据拼接 ---------------------------------------------------------------

DROP VIEW IF EXISTS result_table;
CACHE TABLE result_table
AS 
SELECT 
    -- 重要 id
    info.`apply_did`                        AS `apply_did`, 
    info.`orderid`                          AS `orderid`, 
    NVL(multiple_table.`tnum`, 1)           AS `multiple`,

    -- 游客画像使用
    NVL(tourist_extend_table.`age`, -1)                   AS `age`, 
    NVL(tourist_extend_table.`sex`, '未知')                AS `sex`,

    NVL(phone_area.`phone_country_name`, '未知')   AS `phone_country_name`, 
    NVL(phone_area.`phone_province_name`, '未知')  AS `phone_province_name`,
    NVL(phone_area.`phone_city_name`, '未知')      AS `phone_city_name`, 
    IF (
        phone_area.`phone_city_name` = area_table.`idcard_city_name`,
        area_table.`idcard_district_name`,
        NVL(phone_area.`phone_city_name`, '未知')
    )                                               AS `phone_district_name`,    

    NVL(area_table.`idcard_country_name`, '未知')   AS `idcard_country_name`,
    NVL(area_table.`idcard_province_name`, '未知')  AS `idcard_province_name`,
    NVL(area_table.`idcard_city_name`, '未知')      AS `idcard_city_name`,
    NVL(area_table.`idcard_district_name`, '未知')  AS `idcard_district_name`,

    -- 游客原始数据
    info.`idcard`               AS `idcard`,              
    info.`voucher_type`         AS `voucher_type`,        
    info.`order_time`           AS `order_time`,          
    info.`mobile`               AS `mobile`,              
    info.`lid`                  AS `lid`, 

    -- 其他字段
    info.`id`                   AS `id`,           
    info.`tourist`              AS `tourist`,      
    info.`update_time`          AS `update_time`,   
    info.`order_month`          AS `order_month`,   
    info.`check_state`          AS `check_state`,  
    info.`idx`                  AS `idx`,                 
    info.`print_state`          AS `print_state`,   
    info.`check_time`           AS `check_time`,    
    info.`chk_code`             AS `chk_code`,     
    info.`member_id`            AS `member_id`,     
    info.`is_checked`           AS `is_checked`,    
    info.`sync_state`           AS `sync_state`
FROM 
(
    SELECT *
    FROM s_tourist_info_d_i_temp
) AS info 
LEFT JOIN area_table ON info.id = area_table.id
LEFT JOIN tourist_extend_table ON info.orderid = tourist_extend_table.orderid AND info.idx = tourist_extend_table.idx
LEFT JOIN multiple_table ON info.id = multiple_table.id
LEFT JOIN phone_area ON info.id = phone_area.id;


-------------------------------------------------- 补充优先使用的归属地信息 ----------------------------------------------------------------


INSERT OVERWRITE TABLE ods_tourist_info_d_i_temp
SELECT 
    INT(`apply_did`),
    `orderid`,
    int(`multiple`),
    `age`,
    `sex`,

    IF (`phone_country_name` != '未知', `phone_country_name`, `idcard_country_name`)        AS `country_name`,
    IF (`phone_province_name` != '未知', `phone_province_name`, `idcard_province_name`)     AS `province_name`,
    IF (`phone_city_name` != '未知', `phone_city_name`, `idcard_city_name`)                 AS `city_name`,
    IF (`phone_district_name` != '未知', `phone_district_name`, `idcard_district_name`)     AS `district_name`,

    `phone_country_name`,
    `phone_province_name`,
    `phone_city_name`,
    `phone_district_name`,

    `idcard_country_name`,
    `idcard_province_name`,
    `idcard_city_name`,
    `idcard_district_name`,

    `idcard`,
    INT(`voucher_type`),
    int(`order_time`),
    `mobile`,
    int(`lid`),

    int(`id`),
    `tourist`,
    int(`update_time`),
    int(`order_month`),
    int(`check_state`),
    int(`idx`),
    int(`print_state`),
    int(`check_time`),
    `chk_code`,
    int(`member_id`),
    int(`is_checked`),
    int(`sync_state`)
FROM result_table
WHERE apply_did in(591889, 591906, 592024, 29821585,30591043);

