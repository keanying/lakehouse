--EMR Spark SQL
--********************************************************************--
--author: 施建伟
--create time: 2026-04-03 14:27:47
--EMR任务只能运行在独享资源组上
--********************************************************************--



create table if NOT EXISTS ads_cus_company_d_f(

    user_id                     		INT    	COMMENT '用户id',
    user_account_id             	  	INT    	COMMENT '账户id',
    user_customer_id            	  	INT    	COMMENT '客户ID',
    user_name                   	   	string 	COMMENT '用户名称/账户名称',
    user_company_name           	   	string 	COMMENT '企业名称',
    customer_name                   	string 	COMMENT '客户名称',
    customer_mobile             	   	string 	COMMENT '客户手机号',
    user_type_code              	   	int 	COMMENT '用户类型编码',
    user_type                   	   	string 	COMMENT '用户类型(供应商/分销商等)',
    user_is_test                	   	string 	COMMENT '测试账号？(正式/测试)',
    user_status                 	   	string 	COMMENT '用户状态',
    customer_certi_status_code  	   	int    	COMMENT '客户资质审核状态编码',
    customer_certi_status       	   	string 	COMMENT '客户资质审核状态',
    customer_country            	   	string 	COMMENT '客户国家',
    customer_province           	   	string 	COMMENT '客户省',
    customer_city               	   	string 	COMMENT '客户市',
    customer_type_code          	   	INT    	COMMENT '客户类型编码',
    customer_type               	   	string 	COMMENT '客户类型(旅行社/景区)',
    user_land_topic             	   	string 	COMMENT '景区业态',
    user_level                  		string 	COMMENT '级别',
    user_contract_model_code    	   	int 	COMMENT '合作模式编码',
    user_contract_model         	  	string 	COMMENT '合作模式',
    signer_id                   	  	int 	COMMENT '签单人id',
    signer                      	   	string 	COMMENT '签单人姓名',
    servicer_id                 	   	int 	COMMENT '客服id',
    servicer                    	  	string 	COMMENT '客服姓名',
    user_curr_package_name              string 	COMMENT '用户当前套餐',
    user_curr_package_begindate                string 	COMMENT '用户当前套餐开始日期',
    user_curr_package_enddate                  string 	COMMENT '用户当前套餐结束日期',
    user_curr_package_pay_amount                string 	COMMENT '套餐实收金额',
    login_num_plat_curr_month               	int 	COMMENT '本月登录平台次数',
    user_login_lasttime         		    	string 	COMMENT '用户上次登录时间',
    onsale_land_num_self                		INT    	COMMENT '在售自供应产品数,不包含删除',  
    off_shelf_land_num_self            	    	INT 	COMMENT '下架自供应产品数',  
    overdue_land_num_self                       INT 	COMMENT '上架过期自供应产品数',  
    partner_num_supp                    		INT    	COMMENT '供应商数',  
    partner_num_ota                     		INT    	COMMENT 'OTA数',
    partner_num_dist                    		INT    	COMMENT '分销商数',
    land_num_dist    							INT 	COMMENT '分销产品数',
    is_open_zyzx  						     	string 	COMMENT '资源中心',
    is_open_wsc  								string 	COMMENT '微商城（旧版）',
    is_open_gzhyx  						     	string 	COMMENT '公众号营销',
    is_open_hbffl 								string 	COMMENT '红包翻翻乐',
    is_open_yhq  								string 	COMMENT '优惠券',
    is_open_zghxf 								string 	COMMENT '公众号吸粉',
    is_open_ptwsc  								string 	COMMENT '拼团(微商城)',
    is_open_kjwsc  								string 	COMMENT '砍价(微商城)',
    is_open_hbtg  								string 	COMMENT '海报推广',
    is_open_xsqg  								string 	COMMENT '限时抢购', 
    is_open_qmyx  								string 	COMMENT '全民营销',
    is_open_xcxzxjq  							string 	COMMENT '小程序中心(景区)',
    is_open_xcxzxlxsb  				    		string 	COMMENT '小程序中心(旅行社版)',
    is_open_xmtfx  								string 	COMMENT '新媒体分销',
    is_open_znyzj  								string 	COMMENT '智能云闸机',
    is_open_zzsqpj  							string 	COMMENT '自助售取票机',
    spare_field1	                            int 	COMMENT '是否开通手持机',
    is_open_yspzd  								string 	COMMENT '云票务',
    is_open_yxdx  								string 	COMMENT '营销短信',
    is_open_dxttzdy  							string 	COMMENT '短信抬头自定义',
    is_openzdydxmb  							string 	COMMENT '自定义短信模板',
    is_open_xxpwxt  							string 	COMMENT '线下票务系统',
    is_open_lynk  								string 	COMMENT '旅游年卡',
    is_open_xykt  								string 	COMMENT '新一卡通',
    is_open_lyykt  								string 	COMMENT '旅游一卡通',
    is_open_yqykt  								string 	COMMENT '园区一卡通',
    is_open_wbmfmgl  							string 	COMMENT '外部码发码管理',
    is_open_wlzx  								string 	COMMENT '物料中心',
    is_open_typtfx  							string 	COMMENT '同业平台分销',
    is_open_typtfxjcb  							string 	COMMENT '同业平台分销(基础版)',
    concat_all_open                             string      COMMENT '已开通列表',
    concat_all_null                             string      COMMENT '未开通列表',
    spare_field2                                int 	COMMENT '海报推广次数',
    spare_field3                                int 	COMMENT '',
    spare_field4                                int 	COMMENT '',
    spare_field5                                int 	COMMENT '',
    spare_field6                                int 	COMMENT '',
    spare_field7                                int 	COMMENT '',
    spare_field8                                int 	COMMENT '',
    spare_field9                                int 	COMMENT '',
    spare_field10                               int 	COMMENT '',

    ticket_num_frist_month     string 	COMMENT '第一个月票量'
    ,ticket_num_second_month    string 	COMMENT '第二个月票量'
    ,ticket_num_third_month     string 	COMMENT '第三个月票量'
    ,gmv_frist_month            string 	COMMENT '第一个月订单金额'
    ,gmv_second_month           string 	COMMENT '第二个月订单金额'
    ,gmv_third_month            string 	COMMENT '第三个月订单金额'
    ,order_num_frist_month      string 	COMMENT '第一个月订单数量'
    ,order_num_second_month     string 	COMMENT '第二个月订单数量'
    ,order_num_third_month      string 	COMMENT '第三个月订单数量'
    ,plat_ticket_num_frist_month                      string COMMENT''               
    ,plat_ticket_num_second_month                     string COMMENT''               
    ,plat_ticket_num_third_month                      string COMMENT''               
    ,plat_gmv_frist_month                             string COMMENT''               
    ,plat_gmv_second_month                            string COMMENT''               
    ,plat_gmv_third_month                             string COMMENT''               
    ,plat_order_num_frist_month                       string COMMENT''               
    ,plat_order_num_second_month                      string COMMENT''               
    ,plat_order_num_third_month                       string COMMENT''                       
    ,account_ticket_num_frist_month                   string COMMENT''               
    ,account_ticket_num_second_month                  string COMMENT''               
    ,account_ticket_num_third_month                   string COMMENT''               
    ,account_gmv_frist_month                          string COMMENT''               
    ,account_gmv_second_month                         string COMMENT''               
    ,account_gmv_third_month                          string COMMENT''               
    ,account_order_num_frist_month                    string COMMENT''               
    ,account_order_num_second_month                   string COMMENT''               
    ,account_order_num_third_month                    string COMMENT''                        
    ,vip_ticket_num_frist_month                       string COMMENT''               
    ,vip_ticket_num_second_month                      string COMMENT''               
    ,vip_ticket_num_third_month                       string COMMENT''               
    ,vip_gmv_frist_month                              string COMMENT''               
    ,vip_gmv_second_month                             string COMMENT''               
    ,vip_gmv_third_month                              string COMMENT''               
    ,vip_order_num_frist_month                        string COMMENT''               
    ,vip_order_num_second_month                       string COMMENT''               
    ,vip_order_num_third_month                        string COMMENT''                            
    ,cloud_ticket_num_frist_month                     string COMMENT''               
    ,cloud_ticket_num_second_month                    string COMMENT''               
    ,cloud_ticket_num_third_month                     string COMMENT''               
    ,cloud_gmv_frist_month                            string COMMENT''               
    ,cloud_gmv_second_month                           string COMMENT''               
    ,cloud_gmv_third_month                            string COMMENT''               
    ,cloud_order_num_frist_month                      string COMMENT''               
    ,cloud_order_num_second_month                     string COMMENT''               
    ,cloud_order_num_third_month                      string COMMENT''                            
    ,mall_ticket_num_frist_month                      string COMMENT''               
    ,mall_ticket_num_second_month                     string COMMENT''               
    ,mall_ticket_num_third_month                      string COMMENT''               
    ,mall_gmv_frist_month                             string COMMENT''               
    ,mall_gmv_second_month                            string COMMENT''               
    ,mall_gmv_third_month                             string COMMENT''               
    ,mall_order_num_frist_month                       string COMMENT''               
    ,mall_order_num_second_month                      string COMMENT''               
    ,mall_order_num_third_month                       string COMMENT''                          
    ,cdm_ticket_num_frist_month                       string COMMENT''               
    ,cdm_ticket_num_second_month                      string COMMENT''               
    ,cdm_ticket_num_third_month                       string COMMENT''               
    ,cdm_gmv_frist_month                              string COMMENT''               
    ,cdm_gmv_second_month                             string COMMENT''               
    ,cdm_gmv_third_month                              string COMMENT''               
    ,cdm_order_num_frist_month                        string COMMENT''               
    ,cdm_order_num_second_month                       string COMMENT''               
    ,cdm_order_num_third_month                        string COMMENT''                          
    ,pc_ticket_num_frist_month                        string COMMENT''               
    ,pc_ticket_num_second_month                       string COMMENT''               
    ,pc_ticket_num_third_month                        string COMMENT''               
    ,pc_gmv_frist_month                               string COMMENT''               
    ,pc_gmv_second_month                              string COMMENT''               
    ,pc_gmv_third_month                               string COMMENT''               
    ,pc_order_num_frist_month                         string COMMENT''               
    ,pc_order_num_second_month                        string COMMENT''               
    ,pc_order_num_third_month                         string COMMENT''                           
    ,agm_ticket_num_frist_month                       string COMMENT''               
    ,agm_ticket_num_second_month                      string COMMENT''               
    ,agm_ticket_num_third_month                       string COMMENT''               
    ,agm_gmv_frist_month                              string COMMENT''               
    ,agm_gmv_second_month                             string COMMENT''               
    ,agm_gmv_third_month                              string COMMENT''               
    ,agm_order_num_frist_month                        string COMMENT''               
    ,agm_order_num_second_month                       string COMMENT''               
    ,agm_order_num_third_month                        string COMMENT''                          
    ,smart_terminal_ticket_num_frist_month            string COMMENT''               
    ,smart_terminal_ticket_num_second_month           string COMMENT''               
    ,smart_terminal_ticket_num_third_month            string COMMENT''               
    ,smart_terminal_gmv_frist_month                   string COMMENT''               
    ,smart_terminal_gmv_second_month                  string COMMENT''               
    ,smart_terminal_gmv_third_month                   string COMMENT''               
    ,smart_terminal_order_num_frist_month             string COMMENT''               
    ,smart_terminal_order_num_second_month            string COMMENT''               
    ,smart_terminal_order_num_num_third_month         string COMMENT''                        
    ,adj_ticket_num_frist_month                       string COMMENT''               
    ,adj_ticket_num_second_month                      string COMMENT''               
    ,adj_ticket_num_third_month                       string COMMENT''               
    ,adj_gmv_frist_month                              string COMMENT''               
    ,adj_gmv_second_month                             string COMMENT''               
    ,adj_gmv_third_month                              string COMMENT''               
    ,adj_order_num_frist_month                        string COMMENT''               
    ,adj_order_num_second_month                       string COMMENT''               
    ,adj_order_num_third_month                        string COMMENT''                         
    ,tb_ticket_num_frist_month                        string COMMENT''               
    ,tb_ticket_num_second_month                       string COMMENT''               
    ,tb_ticket_num_third_month                        string COMMENT''               
    ,tb_gmv_frist_month                               string COMMENT''               
    ,tb_gmv_second_month                              string COMMENT''               
    ,b_gmv_third_month                                string COMMENT''               
    ,tb_order_num_frist_month                         string COMMENT''               
    ,tb_order_num_second_month                        string COMMENT''               
    ,tb_order_num_third_month                         string COMMENT''                          
    ,year_card_ticket_num_frist_month                 string COMMENT''               
    ,year_card_ticket_num_second_month                string COMMENT''               
    ,year_card_ticket_num_third_month                 string COMMENT''               
    ,year_card_gmv_frist_month                        string COMMENT''               
    ,year_card_gmv_second_month                       string COMMENT''               
    ,year_card_gmv_third_month                        string COMMENT''               
    ,year_card_order_num_frist_month                  string COMMENT''               
    ,year_card_order_num_second_month                 string COMMENT''               
    ,year_card_order_num_third_month                  string COMMENT''                         
    ,mall_plat_ticket_num_frist_month                 string COMMENT''               
    ,mall_plat_ticket_num_second_month                string COMMENT''               
    ,mall_plat_ticket_num_third_month                 string COMMENT''               
    ,mall_plat_gmv_frist_month                        string COMMENT''               
    ,mall_plat_gmv_second_month                       string COMMENT''               
    ,mall_plat_gmv_third_month                        string COMMENT''               
    ,mall_plat_order_num_frist_month                  string COMMENT''               
    ,mall_plat_order_num_second_month                 string COMMENT''               
    ,mall_plat_order_num_third_month                  string COMMENT''               
                
    ,ota_ticket_num_frist_month                       string COMMENT''               
    ,ota_ticket_num_second_month                      string COMMENT''               
    ,ota_ticket_num_third_month                       string COMMENT''               
    ,ota_gmv_frist_month                              string COMMENT''               
    ,ota_gmv_second_month                             string COMMENT''               
    ,ota_gmv_third_month                              string COMMENT''               
    ,ota_order_num_frist_month                        string COMMENT''               
    ,ota_order_num_second_month                       string COMMENT''               
    ,ota_order_num_third_month                        string COMMENT''               
                
    ,pay_code_ticket_num_frist_month                  string COMMENT''               
    ,pay_code_ticket_num_second_month                 string COMMENT''               
    ,pay_code_ticket_num_third_month                  string COMMENT''               
    ,pay_code_gmv_frist_month                         string COMMENT''               
    ,pay_code_gmv_second_month                        string COMMENT''               
    ,pay_code_gmv_third_month                         string COMMENT''               
    ,pay_code_order_num_frist_month                   string COMMENT''               
    ,pay_code_order_num_second_month                  string COMMENT''               
    ,pay_code_order_num_third_month                   string COMMENT''               
                
    ,one_card_ticket_num_frist_month                  string COMMENT''               
    ,one_card_ticket_num_second_month                 string COMMENT''               
    ,one_card_ticket_num_third_month                  string COMMENT''               
    ,one_card_gmv_frist_month                         string COMMENT''               
    ,one_card_gmv_second_month                        string COMMENT''               
    ,one_card_gmv_third_month                         string COMMENT''               
    ,one_card_order_num_frist_month                   string COMMENT''               
    ,one_card_order_num_second_month                  string COMMENT''               
    ,one_card_order_num_third_month                   string COMMENT''               
                
    ,subticket_ticket_num_frist_month                 string COMMENT''               
    ,subticket_ticket_num_second_month                string COMMENT''               
    ,subticket_ticket_num_third_month                 string COMMENT''               
    ,subticket_gmv_frist_month                        string COMMENT''               
    ,subticket_gmv_second_month                       string COMMENT''               
    ,subticket_gmv_third_month                        string COMMENT''               
    ,subticket_order_num_frist_month                  string COMMENT''               
    ,subticket_order_num_second_month                 string COMMENT''               
    ,subticket_order_num_third_month                  string COMMENT''               
                
    ,group_ticket_num_frist_month                     string COMMENT''               
    ,group_ticket_num_second_month                    string COMMENT''               
    ,group_ticket_num_third_month                     string COMMENT''               
    ,group_gmv_frist_month                            string COMMENT''               
    ,group_gmv_second_month                           string COMMENT''               
    ,group_gmv_third_month                            string COMMENT''               
    ,group_order_num_frist_month                      string COMMENT''               
    ,group_order_num_second_month                     string COMMENT''               
    ,group_order_num_third_month                      string COMMENT''               
                
    ,efuzhou_ticket_num_frist_month                   string COMMENT''               
    ,efuzhou_ticket_num_second_month                  string COMMENT''               
    ,efuzhou_ticket_num_third_month                   string COMMENT''               
    ,efuzhou_gmv_frist_month                          string COMMENT''               
    ,efuzhou_gmv_second_month                         string COMMENT''               
    ,efuzhou_gmv_third_month                          string COMMENT''               
    ,efuzhou_order_num_frist_month                    string COMMENT''               
    ,efuzhou_order_num_second_month                   string COMMENT''               
    ,efuzhou_order_num_third_month                    string COMMENT''               
                
    ,assorted_ticket_num_frist_month                  string COMMENT''               
    ,assorted_ticket_num_second_month                 string COMMENT''               
    ,assorted_ticket_num_third_month                  string COMMENT''               
    ,assorted_gmv_frist_month                         string COMMENT''               
    ,assorted_gmv_second_month                        string COMMENT''               
    ,assorted_gmv_third_month                         string COMMENT''               
    ,assorted_order_num_frist_month                   string COMMENT''               
    ,assorted_order_num_second_month                  string COMMENT''               
    ,assorted_order_num_third_month                   string COMMENT''               
                
    ,integral_mall_ticket_num_frist_month             string COMMENT''               
    ,integral_mall_ticket_num_second_month            string COMMENT''               
    ,integral_mall_ticket_num_third_month             string COMMENT''               
    ,integral_mall_gmv_frist_month                    string COMMENT''               
    ,integral_mall_gmv_second_month                   string COMMENT''               
    ,integral_mall_gmv_third_month                    string COMMENT''               
    ,integral_mall_order_num_frist_month              string COMMENT''               
    ,integral_mall_order_num_second_month             string COMMENT''               
    ,integral_mall_order_num_third_month              string COMMENT''               
                
    ,pos_ticket_num_frist_month                       string COMMENT''               
    ,pos_ticket_num_second_month                      string COMMENT''               
    ,pos_ticket_num_third_month                       string COMMENT''               
    ,pos_gmv_frist_month                              string COMMENT''               
    ,pos_gmv_second_month                             string COMMENT''               
    ,pos_gmv_third_month                              string COMMENT''               
    ,pos_order_num_frist_month                        string COMMENT''               
    ,pos_order_num_second_month                       string COMMENT''               
    ,pos_order_num_third_month                        string COMMENT''               
                
    ,icbc_ticket_num_frist_month                      string COMMENT''               
    ,icbc_ticket_num_second_month                     string COMMENT''               
    ,icbc_ticket_num_third_month                      string COMMENT''               
    ,icbc_gmv_frist_month                             string COMMENT''               
    ,icbc_gmv_second_month                            string COMMENT''               
    ,icbc_gmv_third_month                             string COMMENT''               
    ,icbc_order_num_frist_month                       string COMMENT''               
    ,icbc_order_num_second_month                      string COMMENT''               
    ,icbc_order_num_third_month                       string COMMENT''               
                
    ,bankunion_ticket_num_frist_month                 string COMMENT''               
    ,bankunion_ticket_num_second_month                string COMMENT''               
    ,bankunion_ticket_num_third_month                 string COMMENT''               
    ,bankunion_gmv_frist_month                        string COMMENT''               
    ,bankunion_gmv_second_month                       string COMMENT''               
    ,bankunion_gmv_third_month                        string COMMENT''               
    ,bankunion_order_num_frist_month                  string COMMENT''               
    ,bankunion_order_num_second_month                 string COMMENT''               
    ,bankunion_order_num_third_month                  string COMMENT''               
                
    ,bankunion_pos_ticket_num_frist_month             string COMMENT''               
    ,bankunion_pos_ticket_num_second_month            string COMMENT''               
    ,bankunion_pos_ticket_num_third_month             string COMMENT''               
    ,bankunion_pos_gmv_frist_month                    string COMMENT''               
    ,bankunion_pos_gmv_second_month                   string COMMENT''               
    ,bankunion_pos_gmv_third_month                    string COMMENT''               
    ,bankunion_pos_order_num_frist_month              string COMMENT''               
    ,bankunion_pos_order_num_second_month             string COMMENT''               
    ,bankunion_pos_order_num_third_month              string COMMENT''               
                
    ,wft_ticket_num_frist_month                       string COMMENT''               
    ,wft_ticket_num_second_month                      string COMMENT''               
    ,wft_ticket_num_third_month                       string COMMENT''               
    ,wft_gmv_frist_month                              string COMMENT''               
    ,wft_gmv_second_month                             string COMMENT''               
    ,wft_gmv_third_month                              string COMMENT''               
    ,wft_order_num_frist_month                        string COMMENT''               
    ,wft_order_num_second_month                       string COMMENT''               
    ,wft_order_num_third_month                        string COMMENT''               
                
    ,yb_ticket_num_frist_month                        string COMMENT''               
    ,yb_ticket_num_second_month                       string COMMENT''               
    ,yb_ticket_num_third_month                        string COMMENT''               
    ,yb_gmv_frist_month                               string COMMENT''               
    ,yb_gmv_second_month                              string COMMENT''               
    ,yb_gmv_third_month                               string COMMENT''               
    ,yb_order_num_frist_month                         string COMMENT''               
    ,yb_order_num_second_month                        string COMMENT''               
    ,yb_order_num_third_month                         string COMMENT''               
                
    ,wx_wpf_ticket_num_frist_month                    string COMMENT''               
    ,wx_wpf_ticket_num_second_month                   string COMMENT''               
    ,wx_wpf_ticket_num_third_month                    string COMMENT''               
    ,wx_wpf_gmv_frist_month                           string COMMENT''               
    ,wx_wpf_gmv_second_month                          string COMMENT''               
    ,wx_wpf_gmv_third_month                           string COMMENT''               
    ,wx_wpf_order_num_frist_month                     string COMMENT''               
    ,wx_wpf_order_num_second_month                    string COMMENT''               
    ,wx_wpf_order_num_third_month                     string COMMENT''               
                
    ,adj_group_ticket_num_frist_month                 string COMMENT''               
    ,adj_group_ticket_num_second_month                string COMMENT''               
    ,adj_group_ticket_num_third_month                 string COMMENT''               
    ,adj_group_gmv_frist_month                        string COMMENT''               
    ,adj_group_gmv_second_month                       string COMMENT''               
    ,adj_group_gmv_third_month                        string COMMENT''               
    ,adj_group_order_num_frist_month                  string COMMENT''               
    ,adj_group_order_num_second_month                 string COMMENT''               
    ,adj_group_order_num_third_month                  string COMMENT''               
                
    ,cloud_union_pay_ticket_num_frist_month           string COMMENT''               
    ,cloud_union_pay_ticket_num_second_month          string COMMENT''               
    ,cloud_union_pay_ticket_num_third_month           string COMMENT''               
    ,cloud_union_pay_gmv_frist_month                  string COMMENT''               
    ,cloud_union_pay_gmv_second_month                 string COMMENT''               
    ,cloud_union_pay_gmv_third_month                  string COMMENT''               
    ,cloud_union_pay_order_num_frist_month            string COMMENT''               
    ,cloud_union_pay_order_num_second_month           string COMMENT''               
    ,cloud_union_pay_order_num_third_month            string COMMENT''               
                
    ,offline_ticket_num_frist_month                   string COMMENT''               
    ,offline_ticket_num_second_month                  string COMMENT''               
    ,offline_ticket_num_third_month                   string COMMENT''               
    ,offline_gmv_frist_month                          string COMMENT''               
    ,offline_gmv_second_month                         string COMMENT''               
    ,offline_gmv_third_month                          string COMMENT''               
    ,offline_order_num_frist_month                    string COMMENT''               
    ,offline_order_num_second_month                   string COMMENT''               
    ,offline_order_num_third_month                    string COMMENT''               
                
    ,staff_card_ticket_num_frist_month                string COMMENT''               
    ,staff_card_ticket_num_second_month               string COMMENT''               
    ,staff_card_ticket_num_third_month                string COMMENT''               
    ,staff_card_gmv_frist_month                       string COMMENT''               
    ,staff_card_gmv_second_month                      string COMMENT''               
    ,staff_card_gmv_third_month                       string COMMENT''               
    ,staff_card_order_num_frist_month                 string COMMENT''               
    ,staff_card_order_num_second_month                string COMMENT''               
    ,staff_card_order_num_third_month                 string COMMENT''               
                
    ,hand_card_ticket_num_frist_month                 string COMMENT''               
    ,hand_card_ticket_num_second_month                string COMMENT''               
    ,hand_card_ticket_num_third_month                 string COMMENT''               
    ,hand_card_gmv_frist_month                        string COMMENT''               
    ,hand_card_gmv_second_month                       string COMMENT''               
    ,hand_card_gmv_third_month                        string COMMENT''               
    ,hand_card_order_num_frist_month                  string COMMENT''               
    ,hand_card_order_num_second_month                 string COMMENT''               
    ,hand_card_order_num_third_month                  string COMMENT''               
                
    ,desk_cloud_ticket_num_frist_month                string COMMENT''               
    ,desk_cloud_ticket_num_second_month               string COMMENT''               
    ,desk_cloud_ticket_num_third_month                string COMMENT''               
    ,desk_cloud_gmv_frist_month                       string COMMENT''               
    ,desk_cloud_gmv_second_month                      string COMMENT''               
    ,desk_cloud_gmv_third_month                       string COMMENT''               
    ,desk_cloud_order_num_frist_month                 string COMMENT''               
    ,desk_cloud_order_num_second_month                string COMMENT''               
    ,desk_cloud_order_num_third_month                 string COMMENT''               
                
    ,app_ticket_num_frist_month                       string COMMENT''               
    ,app_ticket_num_second_month                      string COMMENT''               
    ,app_ticket_num_third_month                       string COMMENT''               
    ,app_gmv_frist_month                              string COMMENT''               
    ,app_gmv_second_month                             string COMMENT''               
    ,app_gmv_third_month                              string COMMENT''               
    ,app_order_num_frist_month                        string COMMENT''               
    ,app_order_num_second_month                       string COMMENT''               
    ,app_order_num_third_month                        string COMMENT''               
                
    ,special_ticket_num_frist_month                   string COMMENT''               
    ,special_ticket_num_second_month                  string COMMENT''               
    ,special_ticket_num_third_month                   string COMMENT''               
    ,special_gmv_frist_month                          string COMMENT''               
    ,special_gmv_second_month                         string COMMENT''               
    ,special_gmv_third_month                          string COMMENT''               
    ,special_order_num_frist_month                    string COMMENT''               
    ,special_order_num_second_month                   string COMMENT''               
    ,special_order_num_third_month                    string COMMENT''               
                
    ,wx_app_ticket_num_frist_month                    string COMMENT''               
    ,wx_app_ticket_num_second_month                   string COMMENT''               
    ,wx_app_ticket_num_third_month                    string COMMENT''               
    ,wx_app_gmv_frist_month                           string COMMENT''               
    ,wx_app_gmv_second_month                          string COMMENT''               
    ,wx_app_gmv_third_month                           string COMMENT''               
    ,wx_app_order_num_frist_month                     string COMMENT''               
    ,wx_app_order_num_second_month                    string COMMENT''               
    ,wx_app_order_num_third_month                     string COMMENT''               
                
    ,dy_tik_ticket_num_frist_month                    string COMMENT''               
    ,dy_tik_ticket_num_second_month                   string COMMENT''               
    ,dy_tik_ticket_num_third_month                    string COMMENT''               
    ,dy_tik_gmv_frist_month                           string COMMENT''               
    ,dy_tik_gmv_second_month                          string COMMENT''               
    ,dy_tik_gmv_third_month                           string COMMENT''               
    ,dy_tik_order_num_frist_month                     string COMMENT''               
    ,dy_tik_order_num_second_month                    string COMMENT''               
    ,dy_tik_order_num_third_month                     string COMMENT''               
                
    ,ali_ticket_num_frist_month                       string COMMENT''               
    ,ali_ticket_num_second_month                      string COMMENT''               
    ,ali_ticket_num_third_month                       string COMMENT''               
    ,ali_gmv_frist_month                              string COMMENT''               
    ,ali_gmv_second_month                             string COMMENT''               
    ,ali_gmv_third_month                              string COMMENT''               
    ,ali_order_num_frist_month                        string COMMENT''               
    ,ali_order_num_second_month                       string COMMENT''               
    ,ali_order_num_third_month                        string COMMENT''               
                
    ,group_purchase_code_ticket_num_frist_month       string COMMENT''               
    ,group_purchase_code_ticket_num_second_month      string COMMENT''               
    ,group_purchase_code_ticket_num_third_month       string COMMENT''               
    ,group_purchase_code_gmv_frist_month              string COMMENT''               
    ,group_purchase_code_gmv_second_month             string COMMENT''               
    ,group_purchase_code_gmv_third_month              string COMMENT''               
    ,group_purchase_code_order_num_frist_month        string COMMENT''               
    ,group_purchase_code_order_num_second_month       string COMMENT''               
    ,group_purchase_code_order_num_third_month        string COMMENT''               
                
    ,jjy_year_ticket_num_frist_month                  string COMMENT''               
    ,jjy_year_ticket_num_second_month                 string COMMENT''               
    ,jjy_year_ticket_num_third_month                  string COMMENT''               
    ,jjy_year_gmv_frist_month                         string COMMENT''               
    ,jjy_year_gmv_second_month                        string COMMENT''               
    ,jjy_year_gmv_third_month                         string COMMENT''               
    ,jjy_year_order_num_frist_month                   string COMMENT''               
    ,jjy_year_order_num_second_month                  string COMMENT''               
    ,jjy_year_order_num_third_month                   string COMMENT''               
                
    ,resource_center_ticket_num_frist_month           string COMMENT''               
    ,resource_center_ticket_num_second_month          string COMMENT''               
    ,resource_center_ticket_num_third_month           string COMMENT''               
    ,resource_center_gmv_frist_month                  string COMMENT''               
    ,resource_center_gmv_second_month                 string COMMENT''               
    ,resource_center_gmv_third_month                  string COMMENT''               
    ,resource_center_order_num_frist_month            string COMMENT''               
    ,resource_center_order_num_second_month           string COMMENT''               
    ,resource_center_order_num_third_month            string COMMENT''               
                
    ,limited_conversion_ticket_num_frist_month        string COMMENT''               
    ,limited_conversion_ticket_num_second_month       string COMMENT''               
    ,limited_conversion_ticket_num_third_month        string COMMENT''               
    ,limited_conversion_gmv_frist_month               string COMMENT''               
    ,limited_conversion_gmv_second_month              string COMMENT''               
    ,limited_conversion_gmv_third_month               string COMMENT''               
    ,limited_conversion_order_num_frist_month         string COMMENT''               
    ,limited_conversion_order_num_second_month        string COMMENT''               
    ,limited_conversion_order_num_third_month         string COMMENT''               
                
    ,kj_ticket_num_frist_month                        string COMMENT''               
    ,kj_ticket_num_second_month                       string COMMENT''               
    ,kj_ticket_num_third_month                        string COMMENT''               
    ,kj_gmv_frist_month                               string COMMENT''               
    ,kj_gmv_second_month                              string COMMENT''               
    ,kj_gmv_third_month                               string COMMENT''               
    ,kj_order_num_frist_month                         string COMMENT''               
    ,kj_order_num_second_month                        string COMMENT''               
    ,kj_order_num_third_month                         string COMMENT''               
                
    ,pt_ticket_num_frist_month                        string COMMENT''               
    ,pt_ticket_num_second_month                       string COMMENT''               
    ,pt_ticket_num_third_month                        string COMMENT''               
    ,pt_gmv_frist_month                               string COMMENT''               
    ,pt_gmv_second_month                              string COMMENT''               
    ,pt_gmv_third_month                               string COMMENT''               
    ,pt_order_num_frist_month                         string COMMENT''               
    ,pt_order_num_second_month                        string COMMENT''               
    ,pt_order_num_third_month                         string COMMENT''               
                
    ,qmyx_ticket_num_frist_month                      string COMMENT''               
    ,qmyx_ticket_num_second_month                     string COMMENT''               
    ,qmyx_ticket_num_third_month                      string COMMENT''               
    ,qmyx_gmv_frist_month                             string COMMENT''               
    ,qmyx_gmv_second_month                            string COMMENT''               
    ,qmyx_gmv_third_month                             string COMMENT''               
    ,qmyx_order_num_frist_month                       string COMMENT''               
    ,qmyx_order_num_second_month                      string COMMENT''               
    ,qmyx_order_num_third_month                       string COMMENT''               
                
    ,yhq_ticket_num_frist_month                       string COMMENT''               
    ,yhq_ticket_num_second_month                      string COMMENT''               
    ,yhq_ticket_num_third_month                       string COMMENT''               
    ,yhq_gmv_frist_month                              string COMMENT''               
    ,yhq_gmv_second_month                             string COMMENT''               
    ,yhq_gmv_third_month                              string COMMENT''               
    ,yhq_order_num_frist_month                        string COMMENT''               
    ,yhq_order_num_second_month                       string COMMENT''               
    ,yhq_order_num_third_month                        string COMMENT''               
                
    ,new_media_ticket_num_frist_month                 string COMMENT''               
    ,new_media_ticket_num_second_month                string COMMENT''               
    ,new_media_ticket_num_third_month                 string COMMENT''               
    ,new_media_gmv_frist_month                        string COMMENT''               
    ,new_media_gmv_second_month                       string COMMENT''               
    ,new_media_gmv_third_month                        string COMMENT''               
    ,new_media_order_num_frist_month                  string COMMENT''               
    ,new_media_order_num_second_month                 string COMMENT''               
    ,new_media_order_num_third_month                  string COMMENT''               
                
    ,external_code_ticket_num_frist_month             string COMMENT''               
    ,external_code_ticket_num_second_month            string COMMENT''               
    ,external_code_ticket_num_third_month             string COMMENT''               
    ,external_code_gmv_frist_month                    string COMMENT''               
    ,external_code_gmv_second_month                   string COMMENT''               
    ,external_code_gmv_third_month                    string COMMENT''               
    ,external_code_order_num_frist_month              string COMMENT''               
    ,external_code_order_num_second_month             string COMMENT''               
    ,external_code_order_num_third_month              string COMMENT''               
                
    ,pft_park_card_ticket_num_frist_month             string COMMENT''               
    ,pft_park_card_ticket_num_second_month            string COMMENT''               
    ,pft_park_card_ticket_num_third_month             string COMMENT''               
    ,pft_park_card_gmv_frist_month                    string COMMENT''               
    ,pft_park_card_gmv_second_month                   string COMMENT''               
    ,pft_park_card_gmv_third_month                    string COMMENT''               
    ,pft_park_card_order_num_frist_month              string COMMENT''               
    ,pft_park_card_order_num_second_month             string COMMENT''               
    ,pft_park_card_order_num_third_month              string COMMENT''               
                
    ,pft_annual_card_ticket_num_frist_month           string COMMENT''               
    ,pft_annual_card_ticket_num_second_month          string COMMENT''               
    ,pft_annual_card_ticket_num_third_month           string COMMENT''               
    ,pft_annual_card_gmv_frist_month                  string COMMENT''               
    ,pft_annual_card_gmv_second_month                 string COMMENT''               
    ,pft_annual_card_gmv_third_month                  string COMMENT''               
    ,pft_annual_card_order_num_frist_month            string COMMENT''               
    ,pft_annual_card_order_num_second_month           string COMMENT''               
    ,pft_annual_card_order_num_third_month            string COMMENT''   

    
    ,cloud_order_num_kh                     int COMMENT '云票务--考核维度考核维度订单量'
    ,mall_order_num_kh                      int COMMENT '微商城--考核维度订单量'
    ,cdm_order_num_kh                       int COMMENT '自助机--考核维度订单量'
    ,pc_order_num_kh                        int COMMENT 'PC商城--考核维度订单量'
    ,agm_order_num_kh                       int COMMENT '闸机--考核维度订单量'
    ,smart_terminal_order_num_kh            int COMMENT '智能终端--考核维度订单量'
    ,tb_order_num_kh                        int COMMENT '淘宝/飞猪--考核维度订单量'
    ,year_card_order_num_kh                 int COMMENT '年卡特权--考核维度订单量'
    ,mall_plat_order_num_kh                 int COMMENT '微平台--考核维度订单量'
    ,ota_order_num_kh                       int COMMENT 'OTA--考核维度订单量'
    ,pay_code_order_num_kh                  int COMMENT '兑换码购票--考核维度订单量'
    ,one_card_order_num_kh                  int COMMENT '一卡通--考核维度订单量'
    ,subticket_order_num_kh                 int COMMENT '套票子票--考核维度订单量'
    ,group_order_num_kh                     int COMMENT '团队预定--考核维度订单量'
    ,assorted_order_num_kh                  int COMMENT '拼团--考核维度订单量'
    ,integral_mall_order_num_kh             int COMMENT '积分商城--考核维度订单量'
    ,pos_order_num_kh                       int COMMENT 'POS支付--考核维度订单量'
    ,wx_wpf_order_num_kh                    int COMMENT '微信-微票房--考核维度订单量'
    ,adj_group_order_num_kh                 int COMMENT '报团计调下单--考核维度订单量'
    ,desk_cloud_order_num_kh                int COMMENT '桌面云票务--考核维度订单量'
    ,app_order_num_kh                       int COMMENT 'APP--考核维度订单量'
    ,special_order_num_kh                   int COMMENT '特殊团队预约--考核维度订单量'
    ,wx_app_order_num_kh                    int COMMENT '微信小程序--考核维度订单量'
    ,dy_tik_order_num_kh                    int COMMENT '抖音-微票房--考核维度订单量'
    ,group_purchase_code_order_num_kh       int COMMENT '团购导码--考核维度订单量'
    ,resource_center_order_num_kh           int COMMENT '资源中心--考核维度订单量'
    ,limited_conversion_order_num_kh        int COMMENT '限时抢购--考核维度订单量'
    ,kj_order_num_kh                        int COMMENT '砍价--考核维度订单量'
    ,pt_order_num_kh                        int COMMENT '拼团--考核维度订单量'
    ,qmyx_order_num_kh                      int COMMENT '全民营销--考核维度订单量'
    ,yhq_order_num_kh                       int COMMENT '优惠券--考核维度订单量'
    ,new_media_order_num_kh                 int COMMENT ''  --新媒体分销考核维度订单量    --考核维度订单量   --购买者或销售者ID为:（12404122 抖音团购   int COMMENT'' ,12513404 快手    int COMMENT'' ,13913690 抖店      int COMMENT'' ,15467659 快手电商开放平台） 
    ,external_code_order_num_kh             int COMMENT '外部发码--考核维度订单量'
    ,pft_park_card_order_num_kh             int COMMENT '园区一卡通--考核维度订单量'
    ,pft_annual_card_order_num_kh           int COMMENT '年卡--考核维度订单量'
    ,ticket_num_hz                          int COMMENT ''
    ,gmv_hz                                 string COMMENT ''
    ,order_num_hz                           int COMMENT ''
    ,user_regist_time                       string COMMENT ''
    ,pft_land_prod_num_kh                   int COMMENT '前三个月产品种数考核'
    ,pft_wlzx_scan_num_kh                   int COMMENT '前三个月物料中心扫码次数考核'
    ,pft_storage_section_num_kh             int COMMENT '前三个月分时预约次数考核'
    ,pft_marking_sms_num_kh                 int COMMENT '营销类短信条数   前3个月'
    ,pft_sms_sign_apply_num_kh              int COMMENT '短信抬头自定义(前3个月)  完成短信抬头修改并应用'
    ,pft_sms_diy_apply_num_kh               int COMMENT '短信模板自定义(前3个月)  完成短信模板修改并应用'
    ,spare_field11                          string COMMENT '开通产品类型列表'
    ,onsale_ticket_num_self                 INT COMMENT '在售自供应产品票种数,不包含删除' 
    ,login_num_plat_last_month              int COMMENT '上月登录平台次数'
    ,spare_field12                          string COMMENT '近60天登录平台次数'
    ,spare_field13                          string COMMENT '近60天登录终端次数'
    ,spare_field14                          string COMMENT '近60天登录平台天数'
    ,spare_field15                          string COMMENT '近60天登录终端天数'
    ,spare_field16                          string COMMENT '合作内容'
    ,user_next_package_begin_date           string COMMENT '用户下个套餐开始日期'
    ,user_next_package_end_date             string COMMENT '用户下个套餐结束日期'
    ,spare_field19                          string COMMENT '合作客户等级关联crm'
    ,is_open_btglgysb  					    int COMMENT '报团管理（供应商版）'
    ,is_open_btglfxsb  						int COMMENT '报团管理（分销商版）'
    ,is_open_fsyy  							int 	COMMENT '分时预约'
 )COMMENT '商户标签表-供应商-分销商-正式' PARTITIONED BY(
    pt int
 )STORED AS ORC;






SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;    -- 开启自适应执行（默认已开启）
SET spark.sql.adaptive.coalescePartitions.enabled=true;   -- 开启分区合并（关键！）
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
--SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
--SET spark.sql.adaptive.coalescePartitions.parallelism=1;
SET spark.sql.adaptive.advisoryPartitionSizeInBytes=256MB;  -- 设置合并后的目标分区大小（例如 256MB），Spark 会自动合并小于此值的分区











--票量、GMV、订单量
drop view if exists cache_user_ticket_gmv_order;
cache table cache_user_ticket_gmv_order as

select a.user_id  
       ,sum(case when yf=1 then ticket_num else 0 end ) as ticket_num_frist_month
       ,sum(case when yf=2 then ticket_num else 0 end ) as ticket_num_second_month
       ,sum(case when yf=3 then ticket_num else 0 end ) as ticket_num_third_month
       ,sum(case when yf=1 then gmv else 0 end ) as gmv_frist_month
       ,sum(case when yf=2 then gmv else 0 end ) as gmv_second_month
       ,sum(case when yf=3 then gmv else 0 end ) as gmv_third_month
       ,sum(case when yf=1 then order_num else 0 end ) as order_num_frist_month
       ,sum(case when yf=2 then order_num else 0 end ) as order_num_second_month
       ,sum(case when yf=3 then order_num else 0 end ) as order_num_third_month
        --平台预定   --票量    --GMV   --订单量
       ,sum(case when yf=1 then plat_ticket_num else 0 end ) as plat_ticket_num_frist_month
       ,sum(case when yf=2 then plat_ticket_num else 0 end ) as plat_ticket_num_second_month
       ,sum(case when yf=3 then plat_ticket_num else 0 end ) as plat_ticket_num_third_month
       ,sum(case when yf=1 then plat_gmv else 0 end ) as plat_gmv_frist_month
       ,sum(case when yf=2 then plat_gmv else 0 end ) as plat_gmv_second_month
       ,sum(case when yf=3 then plat_gmv else 0 end ) as plat_gmv_third_month
       ,sum(case when yf=1 then plat_order_num else 0 end ) as plat_order_num_frist_month
       ,sum(case when yf=2 then plat_order_num else 0 end ) as plat_order_num_second_month
       ,sum(case when yf=3 then plat_order_num else 0 end ) as plat_order_num_third_month
        --普通用户支付   --票量    --GMV   --订单量
       ,sum(case when yf=1 then account_ticket_num else 0 end ) as account_ticket_num_frist_month
       ,sum(case when yf=2 then account_ticket_num else 0 end ) as account_ticket_num_second_month
       ,sum(case when yf=3 then account_ticket_num else 0 end ) as account_ticket_num_third_month
       ,sum(case when yf=1 then account_gmv else 0 end ) as account_gmv_frist_month
       ,sum(case when yf=2 then account_gmv else 0 end ) as account_gmv_second_month
       ,sum(case when yf=3 then account_gmv else 0 end ) as account_gmv_third_month
       ,sum(case when yf=1 then account_order_num else 0 end ) as account_order_num_frist_month
       ,sum(case when yf=2 then account_order_num else 0 end ) as account_order_num_second_month
       ,sum(case when yf=3 then account_order_num else 0 end ) as account_order_num_third_month
        --会员卡购票   --票量    --GMV   --订单量
       ,sum(case when yf=1 then vip_ticket_num else 0 end ) as vip_ticket_num_frist_month
       ,sum(case when yf=2 then vip_ticket_num else 0 end ) as vip_ticket_num_second_month
       ,sum(case when yf=3 then vip_ticket_num else 0 end ) as vip_ticket_num_third_month
       ,sum(case when yf=1 then vip_gmv else 0 end ) 			 as vip_gmv_frist_month
       ,sum(case when yf=2 then vip_gmv else 0 end )  			 as vip_gmv_second_month
       ,sum(case when yf=3 then vip_gmv else 0 end )        as vip_gmv_third_month
       ,sum(case when yf=1 then vip_order_num else 0 end )  as vip_order_num_frist_month
       ,sum(case when yf=2 then vip_order_num else 0 end )  as vip_order_num_second_month
       ,sum(case when yf=3 then vip_order_num else 0 end )  as vip_order_num_third_month
        --云票务   --票量    --GMV   --订单量
       ,sum(case when yf=1 then cloud_ticket_num else 0 end ) as cloud_ticket_num_frist_month
       ,sum(case when yf=2 then cloud_ticket_num else 0 end ) as cloud_ticket_num_second_month
       ,sum(case when yf=3 then cloud_ticket_num else 0 end ) as cloud_ticket_num_third_month
       ,sum(case when yf=1 then cloud_gmv else 0 end ) 			 as cloud_gmv_frist_month
       ,sum(case when yf=2 then cloud_gmv else 0 end )  			 as cloud_gmv_second_month
       ,sum(case when yf=3 then cloud_gmv else 0 end )        as cloud_gmv_third_month
       ,sum(case when yf=1 then cloud_order_num else 0 end )  as cloud_order_num_frist_month
       ,sum(case when yf=2 then cloud_order_num else 0 end )  as cloud_order_num_second_month
       ,sum(case when yf=3 then cloud_order_num else 0 end )  as cloud_order_num_third_month
        --微商城   --票量    --GMV   --订单量
       ,sum(case when yf=1 then mall_ticket_num else 0 end ) as mall_ticket_num_frist_month
       ,sum(case when yf=2 then mall_ticket_num else 0 end ) as mall_ticket_num_second_month
       ,sum(case when yf=3 then mall_ticket_num else 0 end ) as mall_ticket_num_third_month
       ,sum(case when yf=1 then mall_gmv else 0 end ) 		    as mall_gmv_frist_month
       ,sum(case when yf=2 then mall_gmv else 0 end )  		as mall_gmv_second_month
       ,sum(case when yf=3 then mall_gmv else 0 end )        as mall_gmv_third_month
       ,sum(case when yf=1 then mall_order_num else 0 end )  as mall_order_num_frist_month
       ,sum(case when yf=2 then mall_order_num else 0 end )  as mall_order_num_second_month
       ,sum(case when yf=3 then mall_order_num else 0 end )  as mall_order_num_third_month
        --自助机   --票量    --GMV   --订单量
       ,sum(case when yf=1 then cdm_ticket_num else 0 end ) as cdm_ticket_num_frist_month
       ,sum(case when yf=2 then cdm_ticket_num else 0 end ) as cdm_ticket_num_second_month
       ,sum(case when yf=3 then cdm_ticket_num else 0 end ) as cdm_ticket_num_third_month
       ,sum(case when yf=1 then cdm_gmv else 0 end ) 		 as cdm_gmv_frist_month
       ,sum(case when yf=2 then cdm_gmv else 0 end )        as cdm_gmv_second_month
       ,sum(case when yf=3 then cdm_gmv else 0 end )        as cdm_gmv_third_month
       ,sum(case when yf=1 then cdm_order_num else 0 end )  as cdm_order_num_frist_month
       ,sum(case when yf=2 then cdm_order_num else 0 end )  as cdm_order_num_second_month
       ,sum(case when yf=3 then cdm_order_num else 0 end )  as cdm_order_num_third_month
        --PC商城   --票量    --GMV   --订单量
       ,sum(case when yf=1 then pc_ticket_num else 0 end ) as pc_ticket_num_frist_month
       ,sum(case when yf=2 then pc_ticket_num else 0 end ) as pc_ticket_num_second_month
       ,sum(case when yf=3 then pc_ticket_num else 0 end ) as pc_ticket_num_third_month
       ,sum(case when yf=1 then pc_gmv else 0 end ) 	    as pc_gmv_frist_month
       ,sum(case when yf=2 then pc_gmv else 0 end )        as pc_gmv_second_month
       ,sum(case when yf=3 then pc_gmv else 0 end )        as pc_gmv_third_month
       ,sum(case when yf=1 then pc_order_num else 0 end )  as pc_order_num_frist_month
       ,sum(case when yf=2 then pc_order_num else 0 end )  as pc_order_num_second_month
       ,sum(case when yf=3 then pc_order_num else 0 end )  as pc_order_num_third_month
        --闸机   --票量    --GMV   --订单量
       ,sum(case when yf=1 then agm_ticket_num else 0 end ) as agm_ticket_num_frist_month
       ,sum(case when yf=2 then agm_ticket_num else 0 end ) as agm_ticket_num_second_month
       ,sum(case when yf=3 then agm_ticket_num else 0 end ) as agm_ticket_num_third_month
       ,sum(case when yf=1 then agm_gmv else 0 end ) 	     as agm_gmv_frist_month
       ,sum(case when yf=2 then agm_gmv else 0 end )        as agm_gmv_second_month
       ,sum(case when yf=3 then agm_gmv else 0 end )        as agm_gmv_third_month
       ,sum(case when yf=1 then agm_order_num else 0 end )  as agm_order_num_frist_month
       ,sum(case when yf=2 then agm_order_num else 0 end )  as agm_order_num_second_month
       ,sum(case when yf=3 then agm_order_num else 0 end )  as agm_order_num_third_month
        --智能终端   --票量    --GMV   --订单量
       ,sum(case when yf=1 then smart_terminal_ticket_num else 0 end ) as smart_terminal_ticket_num_frist_month
       ,sum(case when yf=2 then smart_terminal_ticket_num else 0 end ) as smart_terminal_ticket_num_second_month
       ,sum(case when yf=3 then smart_terminal_ticket_num else 0 end ) as smart_terminal_ticket_num_third_month
       ,sum(case when yf=1 then smart_terminal_gmv else 0 end ) 	    as smart_terminal_gmv_frist_month
       ,sum(case when yf=2 then smart_terminal_gmv else 0 end )        as smart_terminal_gmv_second_month
       ,sum(case when yf=3 then smart_terminal_gmv else 0 end )        as smart_terminal_gmv_third_month
       ,sum(case when yf=1 then smart_terminal_order_num else 0 end )  as smart_terminal_order_num_frist_month
       ,sum(case when yf=2 then smart_terminal_order_num else 0 end )  as smart_terminal_order_num_second_month
       ,sum(case when yf=3 then smart_terminal_order_num else 0 end )  as smart_terminal_order_num_num_third_month
        --计调   --票量    --GMV   --订单量
       ,sum(case when yf=1 then adj_ticket_num else 0 end ) as adj_ticket_num_frist_month
       ,sum(case when yf=2 then adj_ticket_num else 0 end ) as adj_ticket_num_second_month
       ,sum(case when yf=3 then adj_ticket_num else 0 end ) as adj_ticket_num_third_month
       ,sum(case when yf=1 then adj_gmv else 0 end ) 	     as adj_gmv_frist_month
       ,sum(case when yf=2 then adj_gmv else 0 end )        as adj_gmv_second_month
       ,sum(case when yf=3 then adj_gmv else 0 end )        as adj_gmv_third_month
       ,sum(case when yf=1 then adj_order_num else 0 end )  as adj_order_num_frist_month
       ,sum(case when yf=2 then adj_order_num else 0 end )  as adj_order_num_second_month
       ,sum(case when yf=3 then adj_order_num else 0 end )  as adj_order_num_third_month
        --淘宝/飞猪   --票量    --GMV   --订单量
       ,sum(case when yf=1 then tb_ticket_num else 0 end ) as tb_ticket_num_frist_month
       ,sum(case when yf=2 then tb_ticket_num else 0 end ) as tb_ticket_num_second_month
       ,sum(case when yf=3 then tb_ticket_num else 0 end ) as tb_ticket_num_third_month
       ,sum(case when yf=1 then tb_gmv else 0 end ) 	    as tb_gmv_frist_month
       ,sum(case when yf=2 then tb_gmv else 0 end )        as tb_gmv_second_month
       ,sum(case when yf=3 then tb_gmv else 0 end )        as tb_gmv_third_month
       ,sum(case when yf=1 then tb_order_num else 0 end )  as tb_order_num_frist_month
       ,sum(case when yf=2 then tb_order_num else 0 end )  as tb_order_num_second_month
       ,sum(case when yf=3 then tb_order_num else 0 end )  as tb_order_num_third_month
        --年卡特权   --票量    --GMV   --订单量
       ,sum(case when yf=1 then year_card_ticket_num else 0 end ) as year_card_ticket_num_frist_month
       ,sum(case when yf=2 then year_card_ticket_num else 0 end ) as year_card_ticket_num_second_month
       ,sum(case when yf=3 then year_card_ticket_num else 0 end ) as year_card_ticket_num_third_month
       ,sum(case when yf=1 then year_card_gmv else 0 end ) 	   as year_card_gmv_frist_month
       ,sum(case when yf=2 then year_card_gmv else 0 end )        as year_card_gmv_second_month
       ,sum(case when yf=3 then year_card_gmv else 0 end )        as year_card_gmv_third_month
       ,sum(case when yf=1 then year_card_order_num else 0 end )  as year_card_order_num_frist_month
       ,sum(case when yf=2 then year_card_order_num else 0 end )  as year_card_order_num_second_month
       ,sum(case when yf=3 then year_card_order_num else 0 end )  as year_card_order_num_third_month
        --微平台   --票量    --GMV   --订单量
       ,sum(case when yf=1 then mall_plat_ticket_num else 0 end ) as mall_plat_ticket_num_frist_month
       ,sum(case when yf=2 then mall_plat_ticket_num else 0 end ) as mall_plat_ticket_num_second_month
       ,sum(case when yf=3 then mall_plat_ticket_num else 0 end ) as mall_plat_ticket_num_third_month
       ,sum(case when yf=1 then mall_plat_gmv else 0 end ) 	   as mall_plat_gmv_frist_month
       ,sum(case when yf=2 then mall_plat_gmv else 0 end )        as mall_plat_gmv_second_month
       ,sum(case when yf=3 then mall_plat_gmv else 0 end )        as mall_plat_gmv_third_month
       ,sum(case when yf=1 then mall_plat_order_num else 0 end )  as mall_plat_order_num_frist_month
       ,sum(case when yf=2 then mall_plat_order_num else 0 end )  as mall_plat_order_num_second_month
       ,sum(case when yf=3 then mall_plat_order_num else 0 end )  as mall_plat_order_num_third_month
        --OTA   --票量    --GMV   --订单量
       ,sum(case when yf=1 then ota_ticket_num else 0 end ) as ota_ticket_num_frist_month
       ,sum(case when yf=2 then ota_ticket_num else 0 end ) as ota_ticket_num_second_month
       ,sum(case when yf=3 then ota_ticket_num else 0 end ) as ota_ticket_num_third_month
       ,sum(case when yf=1 then ota_gmv else 0 end ) 	     as ota_gmv_frist_month
       ,sum(case when yf=2 then ota_gmv else 0 end )        as ota_gmv_second_month
       ,sum(case when yf=3 then ota_gmv else 0 end )        as ota_gmv_third_month
       ,sum(case when yf=1 then ota_order_num else 0 end )  as ota_order_num_frist_month
       ,sum(case when yf=2 then ota_order_num else 0 end )  as ota_order_num_second_month
       ,sum(case when yf=3 then ota_order_num else 0 end )  as ota_order_num_third_month
        --兑换码购票   --票量    --GMV   --订单量
       ,sum(case when yf=1 then pay_code_ticket_num else 0 end ) as pay_code_ticket_num_frist_month
       ,sum(case when yf=2 then pay_code_ticket_num else 0 end ) as pay_code_ticket_num_second_month
       ,sum(case when yf=3 then pay_code_ticket_num else 0 end ) as pay_code_ticket_num_third_month
       ,sum(case when yf=1 then pay_code_gmv else 0 end ) 	      as pay_code_gmv_frist_month
       ,sum(case when yf=2 then pay_code_gmv else 0 end )        as pay_code_gmv_second_month
       ,sum(case when yf=3 then pay_code_gmv else 0 end )        as pay_code_gmv_third_month
       ,sum(case when yf=1 then pay_code_order_num else 0 end )  as pay_code_order_num_frist_month
       ,sum(case when yf=2 then pay_code_order_num else 0 end )  as pay_code_order_num_second_month
       ,sum(case when yf=3 then pay_code_order_num else 0 end )  as pay_code_order_num_third_month
        --一卡通   --票量    --GMV   --订单量
       ,sum(case when yf=1 then one_card_ticket_num else 0 end ) as one_card_ticket_num_frist_month
       ,sum(case when yf=2 then one_card_ticket_num else 0 end ) as one_card_ticket_num_second_month
       ,sum(case when yf=3 then one_card_ticket_num else 0 end ) as one_card_ticket_num_third_month
       ,sum(case when yf=1 then one_card_gmv else 0 end ) 	      as one_card_gmv_frist_month
       ,sum(case when yf=2 then one_card_gmv else 0 end )        as one_card_gmv_second_month
       ,sum(case when yf=3 then one_card_gmv else 0 end )        as one_card_gmv_third_month
       ,sum(case when yf=1 then one_card_order_num else 0 end )  as one_card_order_num_frist_month
       ,sum(case when yf=2 then one_card_order_num else 0 end )  as one_card_order_num_second_month
       ,sum(case when yf=3 then one_card_order_num else 0 end )  as one_card_order_num_third_month
        --套票子票   --票量    --GMV   --订单量
       ,sum(case when yf=1 then subticket_ticket_num else 0 end ) as subticket_ticket_num_frist_month
       ,sum(case when yf=2 then subticket_ticket_num else 0 end ) as subticket_ticket_num_second_month
       ,sum(case when yf=3 then subticket_ticket_num else 0 end ) as subticket_ticket_num_third_month
       ,sum(case when yf=1 then subticket_gmv else 0 end ) 	   as subticket_gmv_frist_month
       ,sum(case when yf=2 then subticket_gmv else 0 end )        as subticket_gmv_second_month
       ,sum(case when yf=3 then subticket_gmv else 0 end )        as subticket_gmv_third_month
       ,sum(case when yf=1 then subticket_order_num else 0 end )  as subticket_order_num_frist_month
       ,sum(case when yf=2 then subticket_order_num else 0 end )  as subticket_order_num_second_month
       ,sum(case when yf=3 then subticket_order_num else 0 end )  as subticket_order_num_third_month
        --团队预定   --票量    --GMV   --订单量
       ,sum(case when yf=1 then group_ticket_num else 0 end ) as group_ticket_num_frist_month
       ,sum(case when yf=2 then group_ticket_num else 0 end ) as group_ticket_num_second_month
       ,sum(case when yf=3 then group_ticket_num else 0 end ) as group_ticket_num_third_month
       ,sum(case when yf=1 then group_gmv else 0 end ) 	   as group_gmv_frist_month
       ,sum(case when yf=2 then group_gmv else 0 end )        as group_gmv_second_month
       ,sum(case when yf=3 then group_gmv else 0 end )        as group_gmv_third_month
       ,sum(case when yf=1 then group_order_num else 0 end )  as group_order_num_frist_month
       ,sum(case when yf=2 then group_order_num else 0 end )  as group_order_num_second_month
       ,sum(case when yf=3 then group_order_num else 0 end )  as group_order_num_third_month
        --E福州   --票量    --GMV   --订单量
       ,sum(case when yf=1 then efuzhou_ticket_num else 0 end ) as efuzhou_ticket_num_frist_month
       ,sum(case when yf=2 then efuzhou_ticket_num else 0 end ) as efuzhou_ticket_num_second_month
       ,sum(case when yf=3 then efuzhou_ticket_num else 0 end ) as efuzhou_ticket_num_third_month
       ,sum(case when yf=1 then efuzhou_gmv else 0 end ) 	     as efuzhou_gmv_frist_month
       ,sum(case when yf=2 then efuzhou_gmv else 0 end )        as efuzhou_gmv_second_month
       ,sum(case when yf=3 then efuzhou_gmv else 0 end )        as efuzhou_gmv_third_month
       ,sum(case when yf=1 then efuzhou_order_num else 0 end )  as efuzhou_order_num_frist_month
       ,sum(case when yf=2 then efuzhou_order_num else 0 end )  as efuzhou_order_num_second_month
       ,sum(case when yf=3 then efuzhou_order_num else 0 end )  as efuzhou_order_num_third_month
        --拼团   --票量    --GMV   --订单量
       ,sum(case when yf=1 then assorted_ticket_num else 0 end ) as assorted_ticket_num_frist_month
       ,sum(case when yf=2 then assorted_ticket_num else 0 end ) as assorted_ticket_num_second_month
       ,sum(case when yf=3 then assorted_ticket_num else 0 end ) as assorted_ticket_num_third_month
       ,sum(case when yf=1 then assorted_gmv else 0 end ) 	      as assorted_gmv_frist_month
       ,sum(case when yf=2 then assorted_gmv else 0 end )        as assorted_gmv_second_month
       ,sum(case when yf=3 then assorted_gmv else 0 end )        as assorted_gmv_third_month
       ,sum(case when yf=1 then assorted_order_num else 0 end )  as assorted_order_num_frist_month
       ,sum(case when yf=2 then assorted_order_num else 0 end )  as assorted_order_num_second_month
       ,sum(case when yf=3 then assorted_order_num else 0 end )  as assorted_order_num_third_month
        --积分商城 --票量    --GMV   --订单量
       ,sum(case when yf=1 then integral_mall_ticket_num else 0 end ) as integral_mall_ticket_num_frist_month
       ,sum(case when yf=2 then integral_mall_ticket_num else 0 end ) as integral_mall_ticket_num_second_month
       ,sum(case when yf=3 then integral_mall_ticket_num else 0 end ) as integral_mall_ticket_num_third_month
       ,sum(case when yf=1 then integral_mall_gmv else 0 end ) 	   as integral_mall_gmv_frist_month
       ,sum(case when yf=2 then integral_mall_gmv else 0 end )        as integral_mall_gmv_second_month
       ,sum(case when yf=3 then integral_mall_gmv else 0 end )        as integral_mall_gmv_third_month
       ,sum(case when yf=1 then integral_mall_order_num else 0 end )  as integral_mall_order_num_frist_month
       ,sum(case when yf=2 then integral_mall_order_num else 0 end )  as integral_mall_order_num_second_month
       ,sum(case when yf=3 then integral_mall_order_num else 0 end )  as integral_mall_order_num_third_month
        --POS支付 --票量    --GMV   --订单量
       ,sum(case when yf=1 then pos_ticket_num else 0 end ) as pos_ticket_num_frist_month
       ,sum(case when yf=2 then pos_ticket_num else 0 end ) as pos_ticket_num_second_month
       ,sum(case when yf=3 then pos_ticket_num else 0 end ) as pos_ticket_num_third_month
       ,sum(case when yf=1 then pos_gmv else 0 end ) 	     as pos_gmv_frist_month
       ,sum(case when yf=2 then pos_gmv else 0 end )        as pos_gmv_second_month
       ,sum(case when yf=3 then pos_gmv else 0 end )        as pos_gmv_third_month
       ,sum(case when yf=1 then pos_order_num else 0 end )  as pos_order_num_frist_month
       ,sum(case when yf=2 then pos_order_num else 0 end )  as pos_order_num_second_month
       ,sum(case when yf=3 then pos_order_num else 0 end )  as pos_order_num_third_month
        --招行 --票量    --GMV   --订单量
       ,sum(case when yf=1 then icbc_ticket_num else 0 end ) as icbc_ticket_num_frist_month
       ,sum(case when yf=2 then icbc_ticket_num else 0 end ) as icbc_ticket_num_second_month
       ,sum(case when yf=3 then icbc_ticket_num else 0 end ) as icbc_ticket_num_third_month
       ,sum(case when yf=1 then icbc_gmv else 0 end ) 	      as icbc_gmv_frist_month
       ,sum(case when yf=2 then icbc_gmv else 0 end )        as icbc_gmv_second_month
       ,sum(case when yf=3 then icbc_gmv else 0 end )        as icbc_gmv_third_month
       ,sum(case when yf=1 then icbc_order_num else 0 end )  as icbc_order_num_frist_month
       ,sum(case when yf=2 then icbc_order_num else 0 end )  as icbc_order_num_second_month
       ,sum(case when yf=3 then icbc_order_num else 0 end )  as icbc_order_num_third_month
        --银联商务 --票量    --GMV   --订单量
       ,sum(case when yf=1 then bankunion_ticket_num else 0 end ) as bankunion_ticket_num_frist_month
       ,sum(case when yf=2 then bankunion_ticket_num else 0 end ) as bankunion_ticket_num_second_month
       ,sum(case when yf=3 then bankunion_ticket_num else 0 end ) as bankunion_ticket_num_third_month
       ,sum(case when yf=1 then bankunion_gmv else 0 end ) 	   as bankunion_gmv_frist_month
       ,sum(case when yf=2 then bankunion_gmv else 0 end )        as bankunion_gmv_second_month
       ,sum(case when yf=3 then bankunion_gmv else 0 end )        as bankunion_gmv_third_month
       ,sum(case when yf=1 then bankunion_order_num else 0 end )  as bankunion_order_num_frist_month
       ,sum(case when yf=2 then bankunion_order_num else 0 end )  as bankunion_order_num_second_month
       ,sum(case when yf=3 then bankunion_order_num else 0 end )  as bankunion_order_num_third_month
        --银联pos支付 --票量    --GMV   --订单量
       ,sum(case when yf=1 then bankunion_pos_ticket_num else 0 end ) as bankunion_pos_ticket_num_frist_month
       ,sum(case when yf=2 then bankunion_pos_ticket_num else 0 end ) as bankunion_pos_ticket_num_second_month
       ,sum(case when yf=3 then bankunion_pos_ticket_num else 0 end ) as bankunion_pos_ticket_num_third_month
       ,sum(case when yf=1 then bankunion_pos_gmv else 0 end ) 	   as bankunion_pos_gmv_frist_month
       ,sum(case when yf=2 then bankunion_pos_gmv else 0 end )        as bankunion_pos_gmv_second_month
       ,sum(case when yf=3 then bankunion_pos_gmv else 0 end )        as bankunion_pos_gmv_third_month
       ,sum(case when yf=1 then bankunion_pos_order_num else 0 end )  as bankunion_pos_order_num_frist_month
       ,sum(case when yf=2 then bankunion_pos_order_num else 0 end )  as bankunion_pos_order_num_second_month
       ,sum(case when yf=3 then bankunion_pos_order_num else 0 end )  as bankunion_pos_order_num_third_month
        --威富通 --票量    --GMV   --订单量
       ,sum(case when yf=1 then wft_ticket_num else 0 end ) as wft_ticket_num_frist_month
       ,sum(case when yf=2 then wft_ticket_num else 0 end ) as wft_ticket_num_second_month
       ,sum(case when yf=3 then wft_ticket_num else 0 end ) as wft_ticket_num_third_month
       ,sum(case when yf=1 then wft_gmv else 0 end ) 	     as wft_gmv_frist_month
       ,sum(case when yf=2 then wft_gmv else 0 end )        as wft_gmv_second_month
       ,sum(case when yf=3 then wft_gmv else 0 end )        as wft_gmv_third_month
       ,sum(case when yf=1 then wft_order_num else 0 end )  as wft_order_num_frist_month
       ,sum(case when yf=2 then wft_order_num else 0 end )  as wft_order_num_second_month
       ,sum(case when yf=3 then wft_order_num else 0 end )  as wft_order_num_third_month
        --易宝 --票量    --GMV   --订单量
       ,sum(case when yf=1 then yb_ticket_num else 0 end ) as yb_ticket_num_frist_month
       ,sum(case when yf=2 then yb_ticket_num else 0 end ) as yb_ticket_num_second_month
       ,sum(case when yf=3 then yb_ticket_num else 0 end ) as yb_ticket_num_third_month
       ,sum(case when yf=1 then yb_gmv else 0 end ) 	    as yb_gmv_frist_month
       ,sum(case when yf=2 then yb_gmv else 0 end )        as yb_gmv_second_month
       ,sum(case when yf=3 then yb_gmv else 0 end )        as yb_gmv_third_month
       ,sum(case when yf=1 then yb_order_num else 0 end )  as yb_order_num_frist_month
       ,sum(case when yf=2 then yb_order_num else 0 end )  as yb_order_num_second_month
       ,sum(case when yf=3 then yb_order_num else 0 end )  as yb_order_num_third_month
        --微信-微票房 --票量    --GMV   --订单量
       ,sum(case when yf=1 then wx_wpf_ticket_num else 0 end ) as wx_wpf_ticket_num_frist_month
       ,sum(case when yf=2 then wx_wpf_ticket_num else 0 end ) as wx_wpf_ticket_num_second_month
       ,sum(case when yf=3 then wx_wpf_ticket_num else 0 end ) as wx_wpf_ticket_num_third_month
       ,sum(case when yf=1 then wx_wpf_gmv else 0 end ) 	    as wx_wpf_gmv_frist_month
       ,sum(case when yf=2 then wx_wpf_gmv else 0 end )        as wx_wpf_gmv_second_month
       ,sum(case when yf=3 then wx_wpf_gmv else 0 end )        as wx_wpf_gmv_third_month
       ,sum(case when yf=1 then wx_wpf_order_num else 0 end )  as wx_wpf_order_num_frist_month
       ,sum(case when yf=2 then wx_wpf_order_num else 0 end )  as wx_wpf_order_num_second_month
       ,sum(case when yf=3 then wx_wpf_order_num else 0 end )  as wx_wpf_order_num_third_month
        --报团计调下单 --票量    --GMV   --订单量
       ,sum(case when yf=1 then adj_group_ticket_num else 0 end ) as adj_group_ticket_num_frist_month
       ,sum(case when yf=2 then adj_group_ticket_num else 0 end ) as adj_group_ticket_num_second_month
       ,sum(case when yf=3 then adj_group_ticket_num else 0 end ) as adj_group_ticket_num_third_month
       ,sum(case when yf=1 then adj_group_gmv else 0 end ) 	   as adj_group_gmv_frist_month
       ,sum(case when yf=2 then adj_group_gmv else 0 end )        as adj_group_gmv_second_month
       ,sum(case when yf=3 then adj_group_gmv else 0 end )        as adj_group_gmv_third_month
       ,sum(case when yf=1 then adj_group_order_num else 0 end )  as adj_group_order_num_frist_month
       ,sum(case when yf=2 then adj_group_order_num else 0 end )  as adj_group_order_num_second_month
       ,sum(case when yf=3 then adj_group_order_num else 0 end )  as adj_group_order_num_third_month
        --云闪付下单 --票量    --GMV   --订单量
       ,sum(case when yf=1 then cloud_union_pay_ticket_num else 0 end ) as cloud_union_pay_ticket_num_frist_month
       ,sum(case when yf=2 then cloud_union_pay_ticket_num else 0 end ) as cloud_union_pay_ticket_num_second_month
       ,sum(case when yf=3 then cloud_union_pay_ticket_num else 0 end ) as cloud_union_pay_ticket_num_third_month
       ,sum(case when yf=1 then cloud_union_pay_gmv else 0 end ) 	     as cloud_union_pay_gmv_frist_month
       ,sum(case when yf=2 then cloud_union_pay_gmv else 0 end )        as cloud_union_pay_gmv_second_month
       ,sum(case when yf=3 then cloud_union_pay_gmv else 0 end )        as cloud_union_pay_gmv_third_month
       ,sum(case when yf=1 then cloud_union_pay_order_num else 0 end )  as cloud_union_pay_order_num_frist_month
       ,sum(case when yf=2 then cloud_union_pay_order_num else 0 end )  as cloud_union_pay_order_num_second_month
       ,sum(case when yf=3 then cloud_union_pay_order_num else 0 end )  as cloud_union_pay_order_num_third_month
        --断网离线订单 --票量    --GMV   --订单量
       ,sum(case when yf=1 then offline_ticket_num else 0 end ) as offline_ticket_num_frist_month
       ,sum(case when yf=2 then offline_ticket_num else 0 end ) as offline_ticket_num_second_month
       ,sum(case when yf=3 then offline_ticket_num else 0 end ) as offline_ticket_num_third_month
       ,sum(case when yf=1 then offline_gmv else 0 end ) 	     as offline_gmv_frist_month
       ,sum(case when yf=2 then offline_gmv else 0 end )        as offline_gmv_second_month
       ,sum(case when yf=3 then offline_gmv else 0 end )        as offline_gmv_third_month
       ,sum(case when yf=1 then offline_order_num else 0 end )  as offline_order_num_frist_month
       ,sum(case when yf=2 then offline_order_num else 0 end )  as offline_order_num_second_month
       ,sum(case when yf=3 then offline_order_num else 0 end )  as offline_order_num_third_month
        --员工卡 --票量    --GMV   --订单量
       ,sum(case when yf=1 then staff_card_ticket_num else 0 end ) as staff_card_ticket_num_frist_month
       ,sum(case when yf=2 then staff_card_ticket_num else 0 end ) as staff_card_ticket_num_second_month
       ,sum(case when yf=3 then staff_card_ticket_num else 0 end ) as staff_card_ticket_num_third_month
       ,sum(case when yf=1 then staff_card_gmv else 0 end ) 	    as staff_card_gmv_frist_month
       ,sum(case when yf=2 then staff_card_gmv else 0 end )        as staff_card_gmv_second_month
       ,sum(case when yf=3 then staff_card_gmv else 0 end )        as staff_card_gmv_third_month
       ,sum(case when yf=1 then staff_card_order_num else 0 end )  as staff_card_order_num_frist_month
       ,sum(case when yf=2 then staff_card_order_num else 0 end )  as staff_card_order_num_second_month
       ,sum(case when yf=3 then staff_card_order_num else 0 end )  as staff_card_order_num_third_month
        --手牌 --票量    --GMV   --订单量
       ,sum(case when yf=1 then hand_card_ticket_num else 0 end ) as hand_card_ticket_num_frist_month
       ,sum(case when yf=2 then hand_card_ticket_num else 0 end ) as hand_card_ticket_num_second_month
       ,sum(case when yf=3 then hand_card_ticket_num else 0 end ) as hand_card_ticket_num_third_month
       ,sum(case when yf=1 then hand_card_gmv else 0 end ) 	   as hand_card_gmv_frist_month
       ,sum(case when yf=2 then hand_card_gmv else 0 end )        as hand_card_gmv_second_month
       ,sum(case when yf=3 then hand_card_gmv else 0 end )        as hand_card_gmv_third_month
       ,sum(case when yf=1 then hand_card_order_num else 0 end )  as hand_card_order_num_frist_month
       ,sum(case when yf=2 then hand_card_order_num else 0 end )  as hand_card_order_num_second_month
       ,sum(case when yf=3 then hand_card_order_num else 0 end )  as hand_card_order_num_third_month
        --桌面云票务 --票量    --GMV   --订单量
       ,sum(case when yf=1 then desk_cloud_ticket_num else 0 end ) as desk_cloud_ticket_num_frist_month
       ,sum(case when yf=2 then desk_cloud_ticket_num else 0 end ) as desk_cloud_ticket_num_second_month
       ,sum(case when yf=3 then desk_cloud_ticket_num else 0 end ) as desk_cloud_ticket_num_third_month
       ,sum(case when yf=1 then desk_cloud_gmv else 0 end ) 	    as desk_cloud_gmv_frist_month
       ,sum(case when yf=2 then desk_cloud_gmv else 0 end )        as desk_cloud_gmv_second_month
       ,sum(case when yf=3 then desk_cloud_gmv else 0 end )        as desk_cloud_gmv_third_month
       ,sum(case when yf=1 then desk_cloud_order_num else 0 end )  as desk_cloud_order_num_frist_month
       ,sum(case when yf=2 then desk_cloud_order_num else 0 end )  as desk_cloud_order_num_second_month
       ,sum(case when yf=3 then desk_cloud_order_num else 0 end )  as desk_cloud_order_num_third_month
        --APP --票量    --GMV   --订单量
       ,sum(case when yf=1 then app_ticket_num else 0 end ) as app_ticket_num_frist_month
       ,sum(case when yf=2 then app_ticket_num else 0 end ) as app_ticket_num_second_month
       ,sum(case when yf=3 then app_ticket_num else 0 end ) as app_ticket_num_third_month
       ,sum(case when yf=1 then app_gmv else 0 end ) 	     as app_gmv_frist_month
       ,sum(case when yf=2 then app_gmv else 0 end )        as app_gmv_second_month
       ,sum(case when yf=3 then app_gmv else 0 end )        as app_gmv_third_month
       ,sum(case when yf=1 then app_order_num else 0 end )  as app_order_num_frist_month
       ,sum(case when yf=2 then app_order_num else 0 end )  as app_order_num_second_month
       ,sum(case when yf=3 then app_order_num else 0 end )  as app_order_num_third_month
        --特殊团队预约 --票量    --GMV   --订单量
       ,sum(case when yf=1 then special_ticket_num else 0 end ) as special_ticket_num_frist_month
       ,sum(case when yf=2 then special_ticket_num else 0 end ) as special_ticket_num_second_month
       ,sum(case when yf=3 then special_ticket_num else 0 end ) as special_ticket_num_third_month
       ,sum(case when yf=1 then special_gmv else 0 end ) 	     as special_gmv_frist_month
       ,sum(case when yf=2 then special_gmv else 0 end )        as special_gmv_second_month
       ,sum(case when yf=3 then special_gmv else 0 end )        as special_gmv_third_month
       ,sum(case when yf=1 then special_order_num else 0 end )  as special_order_num_frist_month
       ,sum(case when yf=2 then special_order_num else 0 end )  as special_order_num_second_month
       ,sum(case when yf=3 then special_order_num else 0 end )  as special_order_num_third_month
        --微信小程序 --票量    --GMV   --订单量
       ,sum(case when yf=1 then wx_app_ticket_num else 0 end ) as wx_app_ticket_num_frist_month
       ,sum(case when yf=2 then wx_app_ticket_num else 0 end ) as wx_app_ticket_num_second_month
       ,sum(case when yf=3 then wx_app_ticket_num else 0 end ) as wx_app_ticket_num_third_month
       ,sum(case when yf=1 then wx_app_gmv else 0 end ) 	    as wx_app_gmv_frist_month
       ,sum(case when yf=2 then wx_app_gmv else 0 end )        as wx_app_gmv_second_month
       ,sum(case when yf=3 then wx_app_gmv else 0 end )        as wx_app_gmv_third_month
       ,sum(case when yf=1 then wx_app_order_num else 0 end )  as wx_app_order_num_frist_month
       ,sum(case when yf=2 then wx_app_order_num else 0 end )  as wx_app_order_num_second_month
       ,sum(case when yf=3 then wx_app_order_num else 0 end )  as wx_app_order_num_third_month
        --抖音-微票房 --票量    --GMV   --订单量
       ,sum(case when yf=1 then dy_tik_ticket_num else 0 end ) as dy_tik_ticket_num_frist_month
       ,sum(case when yf=2 then dy_tik_ticket_num else 0 end ) as dy_tik_ticket_num_second_month
       ,sum(case when yf=3 then dy_tik_ticket_num else 0 end ) as dy_tik_ticket_num_third_month
       ,sum(case when yf=1 then dy_tik_gmv else 0 end ) 	    as dy_tik_gmv_frist_month
       ,sum(case when yf=2 then dy_tik_gmv else 0 end )        as dy_tik_gmv_second_month
       ,sum(case when yf=3 then dy_tik_gmv else 0 end )        as dy_tik_gmv_third_month
       ,sum(case when yf=1 then dy_tik_order_num else 0 end )  as dy_tik_order_num_frist_month
       ,sum(case when yf=2 then dy_tik_order_num else 0 end )  as dy_tik_order_num_second_month
       ,sum(case when yf=3 then dy_tik_order_num else 0 end )  as dy_tik_order_num_third_month
        --阿里供销 --票量    --GMV   --订单量
       ,sum(case when yf=1 then ali_ticket_num else 0 end ) as ali_ticket_num_frist_month
       ,sum(case when yf=2 then ali_ticket_num else 0 end ) as ali_ticket_num_second_month
       ,sum(case when yf=3 then ali_ticket_num else 0 end ) as ali_ticket_num_third_month
       ,sum(case when yf=1 then ali_gmv else 0 end ) 	     as ali_gmv_frist_month
       ,sum(case when yf=2 then ali_gmv else 0 end )        as ali_gmv_second_month
       ,sum(case when yf=3 then ali_gmv else 0 end )        as ali_gmv_third_month
       ,sum(case when yf=1 then ali_order_num else 0 end )  as ali_order_num_frist_month
       ,sum(case when yf=2 then ali_order_num else 0 end )  as ali_order_num_second_month
       ,sum(case when yf=3 then ali_order_num else 0 end )  as ali_order_num_third_month
        --团购导码 --票量    --GMV   --订单量
       ,sum(case when yf=1 then group_purchase_code_ticket_num else 0 end ) as group_purchase_code_ticket_num_frist_month
       ,sum(case when yf=2 then group_purchase_code_ticket_num else 0 end ) as group_purchase_code_ticket_num_second_month
       ,sum(case when yf=3 then group_purchase_code_ticket_num else 0 end ) as group_purchase_code_ticket_num_third_month
       ,sum(case when yf=1 then group_purchase_code_gmv else 0 end ) 	     as group_purchase_code_gmv_frist_month
       ,sum(case when yf=2 then group_purchase_code_gmv else 0 end )        as group_purchase_code_gmv_second_month
       ,sum(case when yf=3 then group_purchase_code_gmv else 0 end )        as group_purchase_code_gmv_third_month
       ,sum(case when yf=1 then group_purchase_code_order_num else 0 end )  as group_purchase_code_order_num_frist_month
       ,sum(case when yf=2 then group_purchase_code_order_num else 0 end )  as group_purchase_code_order_num_second_month
       ,sum(case when yf=3 then group_purchase_code_order_num else 0 end )  as group_purchase_code_order_num_third_month
        --京津冀年卡 --票量    --GMV   --订单量
       ,sum(case when yf=1 then jjy_year_ticket_num else 0 end ) as jjy_year_ticket_num_frist_month
       ,sum(case when yf=2 then jjy_year_ticket_num else 0 end ) as jjy_year_ticket_num_second_month
       ,sum(case when yf=3 then jjy_year_ticket_num else 0 end ) as jjy_year_ticket_num_third_month
       ,sum(case when yf=1 then jjy_year_gmv else 0 end ) 	      as jjy_year_gmv_frist_month
       ,sum(case when yf=2 then jjy_year_gmv else 0 end )        as jjy_year_gmv_second_month
       ,sum(case when yf=3 then jjy_year_gmv else 0 end )        as jjy_year_gmv_third_month
       ,sum(case when yf=1 then jjy_year_order_num else 0 end )  as jjy_year_order_num_frist_month
       ,sum(case when yf=2 then jjy_year_order_num else 0 end )  as jjy_year_order_num_second_month
       ,sum(case when yf=3 then jjy_year_order_num else 0 end )  as jjy_year_order_num_third_month
        --资源中心 --票量    --GMV   --订单量
       ,sum(case when yf=1 then resource_center_ticket_num else 0 end ) as resource_center_ticket_num_frist_month
       ,sum(case when yf=2 then resource_center_ticket_num else 0 end ) as resource_center_ticket_num_second_month
       ,sum(case when yf=3 then resource_center_ticket_num else 0 end ) as resource_center_ticket_num_third_month
       ,sum(case when yf=1 then resource_center_gmv else 0 end ) 	     as resource_center_gmv_frist_month
       ,sum(case when yf=2 then resource_center_gmv else 0 end )        as resource_center_gmv_second_month
       ,sum(case when yf=3 then resource_center_gmv else 0 end )        as resource_center_gmv_third_month
       ,sum(case when yf=1 then resource_center_order_num else 0 end )  as resource_center_order_num_frist_month
       ,sum(case when yf=2 then resource_center_order_num else 0 end )  as resource_center_order_num_second_month
       ,sum(case when yf=3 then resource_center_order_num else 0 end )  as resource_center_order_num_third_month
        --限时抢购 --票量    --GMV   --订单量
       ,sum(case when yf=1 then limited_conversion_ticket_num else 0 end ) as limited_conversion_ticket_num_frist_month
       ,sum(case when yf=2 then limited_conversion_ticket_num else 0 end ) as limited_conversion_ticket_num_second_month
       ,sum(case when yf=3 then limited_conversion_ticket_num else 0 end ) as limited_conversion_ticket_num_third_month
       ,sum(case when yf=1 then limited_conversion_gmv else 0 end ) 	    as limited_conversion_gmv_frist_month
       ,sum(case when yf=2 then limited_conversion_gmv else 0 end )        as limited_conversion_gmv_second_month
       ,sum(case when yf=3 then limited_conversion_gmv else 0 end )        as limited_conversion_gmv_third_month
       ,sum(case when yf=1 then limited_conversion_order_num else 0 end )  as limited_conversion_order_num_frist_month
       ,sum(case when yf=2 then limited_conversion_order_num else 0 end )  as limited_conversion_order_num_second_month
       ,sum(case when yf=3 then limited_conversion_order_num else 0 end )  as limited_conversion_order_num_third_month
        --砍价 --票量    --GMV   --订单量
       ,sum(case when yf=1 then kj_ticket_num else 0 end ) as kj_ticket_num_frist_month
       ,sum(case when yf=2 then kj_ticket_num else 0 end ) as kj_ticket_num_second_month
       ,sum(case when yf=3 then kj_ticket_num else 0 end ) as kj_ticket_num_third_month
       ,sum(case when yf=1 then kj_gmv else 0 end ) 	    as kj_gmv_frist_month
       ,sum(case when yf=2 then kj_gmv else 0 end )        as kj_gmv_second_month
       ,sum(case when yf=3 then kj_gmv else 0 end )        as kj_gmv_third_month
       ,sum(case when yf=1 then kj_order_num else 0 end )  as kj_order_num_frist_month
       ,sum(case when yf=2 then kj_order_num else 0 end )  as kj_order_num_second_month
       ,sum(case when yf=3 then kj_order_num else 0 end )  as kj_order_num_third_month
        --拼团 --票量    --GMV   --订单量
       ,sum(case when yf=1 then pt_ticket_num else 0 end ) as pt_ticket_num_frist_month
       ,sum(case when yf=2 then pt_ticket_num else 0 end ) as pt_ticket_num_second_month
       ,sum(case when yf=3 then pt_ticket_num else 0 end ) as pt_ticket_num_third_month
       ,sum(case when yf=1 then pt_gmv else 0 end ) 	    as pt_gmv_frist_month
       ,sum(case when yf=2 then pt_gmv else 0 end )        as pt_gmv_second_month
       ,sum(case when yf=3 then pt_gmv else 0 end )        as pt_gmv_third_month
       ,sum(case when yf=1 then pt_order_num else 0 end )  as pt_order_num_frist_month
       ,sum(case when yf=2 then pt_order_num else 0 end )  as pt_order_num_second_month
       ,sum(case when yf=3 then pt_order_num else 0 end )  as pt_order_num_third_month
        --全民营销 --票量    --GMV   --订单量
       ,sum(case when yf=1 then qmyx_ticket_num else 0 end ) as qmyx_ticket_num_frist_month
       ,sum(case when yf=2 then qmyx_ticket_num else 0 end ) as qmyx_ticket_num_second_month
       ,sum(case when yf=3 then qmyx_ticket_num else 0 end ) as qmyx_ticket_num_third_month
       ,sum(case when yf=1 then qmyx_gmv else 0 end ) 	      as qmyx_gmv_frist_month
       ,sum(case when yf=2 then qmyx_gmv else 0 end )        as qmyx_gmv_second_month
       ,sum(case when yf=3 then qmyx_gmv else 0 end )        as qmyx_gmv_third_month
       ,sum(case when yf=1 then qmyx_order_num else 0 end )  as qmyx_order_num_frist_month
       ,sum(case when yf=2 then qmyx_order_num else 0 end )  as qmyx_order_num_second_month
       ,sum(case when yf=3 then qmyx_order_num else 0 end )  as qmyx_order_num_third_month
        --优惠券 --票量    --GMV   --订单量
       ,sum(case when yf=1 then yhq_ticket_num else 0 end ) as yhq_ticket_num_frist_month
       ,sum(case when yf=2 then yhq_ticket_num else 0 end ) as yhq_ticket_num_second_month
       ,sum(case when yf=3 then yhq_ticket_num else 0 end ) as yhq_ticket_num_third_month
       ,sum(case when yf=1 then yhq_gmv else 0 end ) 	     as yhq_gmv_frist_month
       ,sum(case when yf=2 then yhq_gmv else 0 end )        as yhq_gmv_second_month
       ,sum(case when yf=3 then yhq_gmv else 0 end )        as yhq_gmv_third_month
       ,sum(case when yf=1 then yhq_order_num else 0 end )  as yhq_order_num_frist_month
       ,sum(case when yf=2 then yhq_order_num else 0 end )  as yhq_order_num_second_month
       ,sum(case when yf=3 then yhq_order_num else 0 end )  as yhq_order_num_third_month
        --新媒体分销订单量 --票量    --GMV   --订单量   --购买者或销售者ID为:（12404122 抖音团购12513404 快手）
       ,sum(case when yf=1 then new_media_ticket_num else 0 end ) as new_media_ticket_num_frist_month
       ,sum(case when yf=2 then new_media_ticket_num else 0 end ) as new_media_ticket_num_second_month
       ,sum(case when yf=3 then new_media_ticket_num else 0 end ) as new_media_ticket_num_third_month
       ,sum(case when yf=1 then new_media_gmv else 0 end ) 	   as new_media_gmv_frist_month
       ,sum(case when yf=2 then new_media_gmv else 0 end )        as new_media_gmv_second_month
       ,sum(case when yf=3 then new_media_gmv else 0 end )        as new_media_gmv_third_month
       ,sum(case when yf=1 then new_media_order_num else 0 end )  as new_media_order_num_frist_month
       ,sum(case when yf=2 then new_media_order_num else 0 end )  as new_media_order_num_second_month
       ,sum(case when yf=3 then new_media_order_num else 0 end )  as new_media_order_num_third_month
        --外部发码 --票量    --GMV   --订单量   --购买者或销售者ID为:（12404122 抖音团购12513404 快手）
       ,sum(case when yf=1 then external_code_ticket_num else 0 end ) as external_code_ticket_num_frist_month
       ,sum(case when yf=2 then external_code_ticket_num else 0 end ) as external_code_ticket_num_second_month
       ,sum(case when yf=3 then external_code_ticket_num else 0 end ) as external_code_ticket_num_third_month
       ,sum(case when yf=1 then external_code_gmv else 0 end ) 	   as external_code_gmv_frist_month
       ,sum(case when yf=2 then external_code_gmv else 0 end )        as external_code_gmv_second_month
       ,sum(case when yf=3 then external_code_gmv else 0 end )        as external_code_gmv_third_month
       ,sum(case when yf=1 then external_code_order_num else 0 end )  as external_code_order_num_frist_month
       ,sum(case when yf=2 then external_code_order_num else 0 end )  as external_code_order_num_second_month
       ,sum(case when yf=3 then external_code_order_num else 0 end )  as external_code_order_num_third_month
        --园区一卡通 --票量    --GMV   --订单量   --购买者或销售者ID为:（12404122 抖音团购12513404 快手）
       ,sum(case when yf=1 then pft_park_card_ticket_num else 0 end ) as pft_park_card_ticket_num_frist_month
       ,sum(case when yf=2 then pft_park_card_ticket_num else 0 end ) as pft_park_card_ticket_num_second_month
       ,sum(case when yf=3 then pft_park_card_ticket_num else 0 end ) as pft_park_card_ticket_num_third_month
       ,sum(case when yf=1 then pft_park_card_gmv else 0 end ) 	   as pft_park_card_gmv_frist_month
       ,sum(case when yf=2 then pft_park_card_gmv else 0 end )        as pft_park_card_gmv_second_month
       ,sum(case when yf=3 then pft_park_card_gmv else 0 end )        as pft_park_card_gmv_third_month
       ,sum(case when yf=1 then pft_park_card_order_num else 0 end )  as pft_park_card_order_num_frist_month
       ,sum(case when yf=2 then pft_park_card_order_num else 0 end )  as pft_park_card_order_num_second_month
       ,sum(case when yf=3 then pft_park_card_order_num else 0 end )  as pft_park_card_order_num_third_month
        --年卡 --票量    --GMV   --订单量   --购买者或销售者ID为:（12404122 抖音团购12513404 快手）
       ,sum(case when yf=1 then pft_annual_card_ticket_num else 0 end ) as pft_annual_card_ticket_num_frist_month
       ,sum(case when yf=2 then pft_annual_card_ticket_num else 0 end ) as pft_annual_card_ticket_num_second_month
       ,sum(case when yf=3 then pft_annual_card_ticket_num else 0 end ) as pft_annual_card_ticket_num_third_month
       ,sum(case when yf=1 then pft_annual_card_gmv else 0 end ) 	     as pft_annual_card_gmv_frist_month
       ,sum(case when yf=2 then pft_annual_card_gmv else 0 end )        as pft_annual_card_gmv_second_month
       ,sum(case when yf=3 then pft_annual_card_gmv else 0 end )        as pft_annual_card_gmv_third_month
       ,sum(case when yf=1 then pft_annual_card_order_num else 0 end )  as pft_annual_card_order_num_frist_month
       ,sum(case when yf=2 then pft_annual_card_order_num else 0 end )  as pft_annual_card_order_num_second_month
       ,sum(case when yf=3 then pft_annual_card_order_num else 0 end )  as pft_annual_card_order_num_third_month


       ,sum(case when yf in (123) then cloud_order_num_kh else 0 end  ) cloud_order_num_kh		--云票务--考核维度考核维度订单量
       ,sum(case when yf in (123) then mall_order_num_kh else 0 end  ) mall_order_num_kh			--微商城--考核维度订单量
       ,sum(case when yf in (123) then cdm_order_num_kh else 0 end  ) cdm_order_num_kh			--自助机--考核维度订单量
       ,sum(case when yf in (123) then pc_order_num_kh else 0 end  ) pc_order_num_kh				--PC商城--考核维度订单量
       ,sum(case when yf in (123) then agm_order_num_kh else 0 end  ) agm_order_num_kh			--闸机--考核维度订单量
       ,sum(case when yf in (123) then smart_terminal_order_num_kh else 0 end  ) smart_terminal_order_num_kh	--智能终端--考核维度订单量
       ,sum(case when yf in (123) then tb_order_num_kh else 0 end  ) tb_order_num_kh				--淘宝/飞猪--考核维度订单量
       ,sum(case when yf in (123) then year_card_order_num_kh else 0 end  ) year_card_order_num_kh	--年卡特权--考核维度订单量
       ,sum(case when yf in (123) then mall_plat_order_num_kh else 0 end  ) mall_plat_order_num_kh	--微平台--考核维度订单量
       ,sum(case when yf in (123) then ota_order_num_kh else 0 end  ) ota_order_num_kh				--OTA--考核维度订单量
       ,sum(case when yf in (123) then pay_code_order_num_kh else 0 end  ) pay_code_order_num_kh		--兑换码购票--考核维度订单量
       ,sum(case when yf in (123) then one_card_order_num_kh else 0 end  ) one_card_order_num_kh		--一卡通--考核维度订单量
       ,sum(case when yf in (123) then subticket_order_num_kh else 0 end  ) subticket_order_num_kh	--套票子票--考核维度订单量
       ,sum(case when yf in (123) then group_order_num_kh else 0 end  ) group_order_num_kh			--团队预定--考核维度订单量
       ,sum(case when yf in (123) then assorted_order_num_kh else 0 end  ) assorted_order_num_kh		--拼团--考核维度订单量
       ,sum(case when yf in (123) then integral_mall_order_num_kh else 0 end  ) integral_mall_order_num_kh	--积分商城--考核维度订单量
       ,sum(case when yf in (123) then pos_order_num_kh else 0 end  ) pos_order_num_kh				--POS支付--考核维度订单量
       ,sum(case when yf in (123) then wx_wpf_order_num_kh else 0 end  ) wx_wpf_order_num_kh			--微信-微票房--考核维度订单量
       ,sum(case when yf in (123) then adj_group_order_num_kh else 0 end  ) adj_group_order_num_kh	--报团计调下单--考核维度订单量
       ,sum(case when yf in (123) then desk_cloud_order_num_kh else 0 end  ) desk_cloud_order_num_kh	--桌面云票务--考核维度订单量
       ,sum(case when yf in (123) then app_order_num_kh else 0 end  ) app_order_num_kh				--APP--考核维度订单量
       ,sum(case when yf in (123) then special_order_num_kh else 0 end  ) special_order_num_kh		--特殊团队预约--考核维度订单量
       ,sum(case when yf in (123) then wx_app_order_num_kh else 0 end  ) wx_app_order_num_kh			--微信小程序--考核维度订单量
       ,sum(case when yf in (123) then dy_tik_order_num_kh else 0 end  ) dy_tik_order_num_kh			--抖音-微票房--考核维度订单量
       ,sum(case when yf in (123) then group_purchase_code_order_num_kh else 0 end  ) group_purchase_code_order_num_kh		--团购导码--考核维度订单量
       ,sum(case when yf in (123) then resource_center_order_num_kh else 0 end  ) resource_center_order_num_kh	 			--资源中心--考核维度订单量
       ,sum(case when yf in (123) then limited_conversion_order_num_kh else 0 end  ) limited_conversion_order_num_kh			--限时抢购--考核维度订单量
       ,sum(case when yf in (123) then kj_order_num_kh else 0 end  ) kj_order_num_kh					--砍价--考核维度订单量
       ,sum(case when yf in (123) then pt_order_num_kh else 0 end  ) pt_order_num_kh					--拼团--考核维度订单量
       ,sum(case when yf in (123) then qmyx_order_num_kh else 0 end  ) qmyx_order_num_kh				--全民营销--考核维度订单量
       ,sum(case when yf in (123) then yhq_order_num_kh else 0 end  ) yhq_order_num_kh				--优惠券--考核维度订单量
       ,sum(case when yf in (123) then new_media_order_num_kh else 0 end  ) new_media_order_num_kh	--新媒体分销考核维度订单量--考核维度订单量--购买者或销售者ID为:（12404122抖音团购 else 0 end  )12513404快手 else 0 end  )13913690抖店 else 0 end  )15467659快手电商开放平台）
       ,sum(case when yf in (123) then external_code_order_num_kh else 0 end  ) external_code_order_num_kh	--外部发码--考核维度订单量
       ,sum(case when yf in (123) then pft_park_card_order_num_kh else 0 end  ) pft_park_card_order_num_kh	--园区一卡通--考核维度订单量
       ,sum(case when yf in (123) then pft_annual_card_order_num_kh else 0 end  ) pft_annual_card_order_num_kh --年卡--考核维度订单量
	   
       ,sum(ticket_num) as ticket_num_hz
       ,sum(gmv) 			 as gmv_hz
       ,sum(order_num)  as order_num_hz
	   
       ,sum(case when yf in (123) then pft_storage_section_num_kh else 0 end  ) pft_storage_section_num_kh --分时预约 --考核维度订单量

    from (select a.booking_time    
                ,a.user_id
                ,a.ticket_num
                ,a.gmv
                ,a.order_num

                --平台预定   --票量    --GMV   --订单量
                ,plat_ticket_num
                ,plat_gmv
                ,plat_order_num

                --普通用户支付   --票量    --GMV   --订单量
                ,account_ticket_num
                ,account_gmv
                ,account_order_num
				
                --会员卡购票   --票量    --GMV   --订单量
                ,vip_ticket_num
                ,vip_gmv
                ,vip_order_num
				
                --云票务   --票量    --GMV   --订单量
                ,cloud_ticket_num
                ,cloud_gmv
                ,cloud_order_num
				
                --微商城   --票量    --GMV   --订单量
                ,mall_ticket_num
                ,mall_gmv
                ,mall_order_num
				
				
                --自助机   --票量    --GMV   --订单量
                ,cdm_ticket_num
                ,cdm_gmv
                ,cdm_order_num
				
                --PC商城   --票量    --GMV   --订单量
                ,pc_ticket_num
                ,pc_gmv
                ,pc_order_num
				
                --闸机   --票量    --GMV   --订单量
                ,agm_ticket_num
                ,agm_gmv
                ,agm_order_num
				
                --智能终端   --票量    --GMV   --订单量
                ,smart_terminal_ticket_num
                ,smart_terminal_gmv
                ,smart_terminal_order_num
				
                --计调   --票量    --GMV   --订单量
                ,adj_ticket_num
                ,adj_gmv
                ,adj_order_num
				
                --淘宝/飞猪   --票量    --GMV   --订单量
                ,tb_ticket_num
                ,tb_gmv
                ,tb_order_num
				
                --年卡特权   --票量    --GMV   --订单量
                ,year_card_ticket_num
                ,year_card_gmv
                ,year_card_order_num
				
                --微平台   --票量    --GMV   --订单量
                ,mall_plat_ticket_num
                ,mall_plat_gmv
                ,mall_plat_order_num
				
                --OTA   --票量    --GMV   --订单量
                ,ota_ticket_num
                ,ota_gmv
                ,ota_order_num
				
                --兑换码购票   --票量    --GMV   --订单量
                ,pay_code_ticket_num
                ,pay_code_gmv
                ,pay_code_order_num
				
                --一卡通   --票量    --GMV   --订单量
                ,one_card_ticket_num
                ,one_card_gmv
                ,one_card_order_num
				
                --套票子票   --票量    --GMV   --订单量
                ,subticket_ticket_num
                ,subticket_gmv
                ,subticket_order_num
				
                --团队预定   --票量    --GMV   --订单量
                ,group_ticket_num
                ,group_gmv
                ,group_order_num
				
                --E福州   --票量    --GMV   --订单量
                ,efuzhou_ticket_num
                ,efuzhou_gmv
                ,efuzhou_order_num
				
                --拼团   --票量    --GMV   --订单量
                ,assorted_ticket_num
                ,assorted_gmv
                ,assorted_order_num
				
                --积分商城 --票量    --GMV   --订单量
                ,integral_mall_ticket_num
                ,integral_mall_gmv
                ,integral_mall_order_num
				
                --POS支付 --票量    --GMV   --订单量
                ,pos_ticket_num
                ,pos_gmv
                ,pos_order_num
				
                --招行 --票量    --GMV   --订单量
                ,icbc_ticket_num
                ,icbc_gmv
                ,icbc_order_num            
				
                --银联商务 --票量    --GMV   --订单量
                ,bankunion_ticket_num
                ,bankunion_gmv
                ,bankunion_order_num
				
                --银联pos支付 --票量    --GMV   --订单量
                ,bankunion_pos_ticket_num
                ,bankunion_pos_gmv
                ,bankunion_pos_order_num
				
                --威富通 --票量    --GMV   --订单量
                ,wft_ticket_num
                ,wft_gmv
                ,wft_order_num
				
                --易宝 --票量    --GMV   --订单量
                ,yb_ticket_num
                ,yb_gmv
                ,yb_order_num
				
                --微信-微票房 --票量    --GMV   --订单量
                ,wx_wpf_ticket_num
                ,wx_wpf_gmv
                ,wx_wpf_order_num
				
                --报团计调下单 --票量    --GMV   --订单量
                ,adj_group_ticket_num
                ,adj_group_gmv
                ,adj_group_order_num
				
                --云闪付下单 --票量    --GMV   --订单量
                ,cloud_union_pay_ticket_num
                ,cloud_union_pay_gmv
                ,cloud_union_pay_order_num
				
                --断网离线订单 --票量    --GMV   --订单量
                ,offline_ticket_num
                ,offline_gmv
                ,offline_order_num
				
                --员工卡 --票量    --GMV   --订单量
                ,staff_card_ticket_num
                ,staff_card_gmv
                ,staff_card_order_num
				
                --手牌 --票量    --GMV   --订单量
                ,hand_card_ticket_num
                ,hand_card_gmv
                ,hand_card_order_num
				
                --桌面云票务 --票量    --GMV   --订单量
                ,desk_cloud_ticket_num
                ,desk_cloud_gmv
                ,desk_cloud_order_num
				
                --APP --票量    --GMV   --订单量
                ,app_ticket_num
                ,app_gmv
                ,app_order_num
				
                --特殊团队预约 --票量    --GMV   --订单量
                ,special_ticket_num 
                ,special_gmv
                ,special_order_num
				
                --微信小程序 --票量    --GMV   --订单量
                ,wx_app_ticket_num
                ,wx_app_gmv
                ,wx_app_order_num
				
                --抖音-微票房 --票量    --GMV   --订单量
                ,dy_tik_ticket_num
                ,dy_tik_gmv
                ,dy_tik_order_num
				
                --阿里供销 --票量    --GMV   --订单量
                ,ali_ticket_num
                ,ali_gmv
                ,ali_order_num
				
                --团购导码 --票量    --GMV   --订单量
                ,group_purchase_code_ticket_num
                ,group_purchase_code_gmv
                ,group_purchase_code_order_num
				
                --京津冀年卡 --票量    --GMV   --订单量
                ,jjy_year_ticket_num
                ,jjy_year_gmv
                ,jjy_year_order_num
				
                --资源中心 --票量    --GMV   --订单量
                ,resource_center_ticket_num 
                ,resource_center_gmv 
                ,resource_center_order_num
				
                --限时抢购 --票量    --GMV   --订单量
                ,limited_conversion_ticket_num 
                ,limited_conversion_gmv
                ,limited_conversion_order_num
				
                --砍价 --票量    --GMV   --订单量
                ,kj_ticket_num 
                ,kj_gmv
                ,kj_order_num
				
                --拼团 --票量    --GMV   --订单量
                ,pt_ticket_num 
                ,pt_gmv
                ,pt_order_num
				
                --全民营销 --票量    --GMV   --订单量
                ,qmyx_ticket_num 
                ,qmyx_gmv
                ,qmyx_order_num
				
                --优惠券 --票量    --GMV   --订单量
                ,yhq_ticket_num
                ,yhq_gmv
                ,yhq_order_num
				
                --新媒体分销订单量 --票量    --GMV   --订单量   --购买者或销售者ID为:（12404122 抖音团购12513404 快手）
                ,new_media_ticket_num
                ,new_media_gmv
                ,new_media_order_num
				
                --外部发码 --票量    --GMV   --订单量   --购买者或销售者ID为:（12404122 抖音团购12513404 快手）
                ,external_code_ticket_num
                ,external_code_gmv
                ,external_code_order_num
				
                --园区一卡通 --票量    --GMV   --订单量   --购买者或销售者ID为:（12404122 抖音团购12513404 快手）
                ,pft_park_card_ticket_num
                ,pft_park_card_gmv
                ,pft_park_card_order_num
				
                --年卡 --票量    --GMV   --订单量   --购买者或销售者ID为:（12404122 抖音团购12513404 快手）
                ,pft_annual_card_ticket_num
                ,pft_annual_card_gmv
                ,pft_annual_card_order_num
				
                ,cloud_order_num_kh             --云票务  --考核维度考核维度订单量
                ,mall_order_num_kh           --微商城  --考核维度订单量
                ,cdm_order_num_kh            --自助机  --考核维度订单量   
                ,pc_order_num_kh             --PC商城  --考核维度订单量                   
                ,agm_order_num_kh             --闸机      --考核维度订单量                        
                ,smart_terminal_order_num_kh           --智能终端      --考核维度订单量                     
                ,tb_order_num_kh        --淘宝/飞猪      --考核维度订单量                     
                ,year_card_order_num_kh                --年卡特权      --考核维度订单量                     
                ,mall_plat_order_num_kh                --微平台      --考核维度订单量                         
                ,ota_order_num_kh       --OTA      --考核维度订单量           
                ,pay_code_order_num_kh     --兑换码购票      --考核维度订单量            
                ,one_card_order_num_kh     --一卡通      --考核维度订单量                        
                ,subticket_order_num_kh                --套票子票      --考核维度订单量                    
                ,group_order_num_kh      --团队预定      --考核维度订单量                        
                ,assorted_order_num_kh               --拼团      --考核维度订单量                  
                ,integral_mall_order_num_kh          --积分商城    --考核维度订单量                     
                ,pos_order_num_kh     --POS支付    --考核维度订单量                   
                ,wx_wpf_order_num_kh     --微信-微票房    --考核维度订单量                     
                ,adj_group_order_num_kh              --报团计调下单    --考核维度订单量                   
                ,desk_cloud_order_num_kh            --桌面云票务    --考核维度订单量                    
                ,app_order_num_kh               --APP    --考核维度订单量                     
                ,special_order_num_kh           --特殊团队预约    --考核维度订单量                     
                ,wx_app_order_num_kh            --微信小程序    --考核维度订单量                            
                ,dy_tik_order_num_kh            --抖音-微票房    --考核维度订单量           
                ,group_purchase_code_order_num_kh           --团购导码    --考核维度订单量                 
                ,resource_center_order_num_kh      --资源中心    --考核维度订单量
                ,limited_conversion_order_num_kh      --限时抢购    --考核维度订单量
                ,kj_order_num_kh      --砍价    --考核维度订单量
                ,pt_order_num_kh      --拼团    --考核维度订单量
                ,qmyx_order_num_kh      --全民营销    --考核维度订单量
                ,yhq_order_num_kh      --优惠券    --考核维度订单量   
                ,new_media_order_num_kh      --新媒体分销考核维度订单量    --考核维度订单量   --购买者或销售者ID为:（12404122 抖音团购   12513404 快手   13913690 抖店   15467659 快手电商开放平台）
                ,external_code_order_num_kh      --外部发码    --考核维度订单量
                ,pft_park_card_order_num_kh      --园区一卡通    --考核维度订单量
                ,pft_annual_card_order_num_kh    --年卡    --考核维度订单量
                ,pft_storage_section_num_kh     --分时预约 --考核维度订单量
				
                ,nvl(case when row_number()over(partition by a.user_id order by a.booking_time )=1 then 1 end,0)+
                nvl(case when a.booking_time=max(case when row_number() over(partition by a.user_id order by a.booking_time ) =1 then substr(add_months(a.booking_time,1),1,7) end)over(partition by a.user_id) then 2 end,0) +
                nvl(case when a.booking_time=max(case when row_number() over(partition by a.user_id order by a.booking_time ) =1 then substr(add_months(a.booking_time,2),1,7) end)over(partition by a.user_id) then 3 end,0)  as yf
          from dws_cus_order_channel_aids_d_f a     --it_project.dws_cus_order_channel_aids_d_f a
          where a.pt = ${ds}   -- and substr(a.booking_time,1,4)>='2023'
          and date_format(a.booking_time ,'yyyy-MM') >= date_format(date_add(current_date(), -365), 'yyyy-MM')
         )a 
     group by a.user_id ;
















INSERT OVERWRITE TABLE ads_cus_company_d_f  PARTITION(pt=${ds})
select 
    a.user_id                     	--用户id
    ,user_account_id             	--账户id
    ,user_customer_id            	--客户ID
    ,user_name                   	--用户名称/账户名称
    ,user_company_name           	--企业名称
    ,customer_name               	--客户名称
    ,customer_mobile             	--客户手机号
    ,user_type_code              	--用户类型编码
    ,user_type                   	--用户类型(供应商/分销商等)
    ,user_is_test                	--测试账号？(正式/测试)
    ,user_status                 	--用户状态
    ,customer_certi_status_code  	--客户资质审核状态编码
    ,customer_certi_status       	--客户资质审核状态
    ,customer_country            	--客户国家
    ,customer_province           	--客户省
    ,customer_city               	--客户市
    ,customer_type_code          	--客户类型编码
    ,customer_type               	--客户类型(旅行社/景区)
    ,user_land_topic             	--景区业态
    ,user_level                  	--级别
    ,user_contract_model_code    	--合作模式编码
    ,user_contract_model         	--合作模式
    ,signer_id                   	--签单人id
    ,signer                      	--签单人姓名
    ,servicer_id                 	--客服id
    ,servicer                    	--客服姓名
    ,user_curr_package_name         --用户当前套餐
    ,nvl(user_curr_package_begindate,user_last_package_begindate)   user_curr_package_begindate     --用户当前套餐开始日期
    ,nvl(user_curr_package_enddate,user_last_package_enddate)     user_curr_package_enddate         --用户当前套餐结束日期
    ,user_curr_package_pay_amount           --套餐实收金额
    ,login_num_plat_curr_month              --本月登录平台次数
    ,user_login_lasttime                    --用户上次登录时间
    ,onsale_land_num_self                   --在售自供应产品数,不包含删除
    ,off_shelf_land_num_self                --下架自供应产品数
    ,overdue_land_num_self                  --上架过期自供应产品数
    ,partner_num_supp                    	--供应商数
    ,partner_num_ota                     	--OTA数
    ,partner_num_dist                    	--分销商数
    ,land_num_dist                          --分销产品数
    ,is_open_zyzx  					        --资源中心
    ,is_open_wxzxwsc  						--微信直销（微商城）
    ,is_open_gzhyx  						--公众号营销
    ,is_open_hbffl 						    --红包翻翻乐
    ,is_open_yhq  						    --优惠券
    ,is_open_zghxf 							--公众号吸粉
    ,is_open_ptwsc  						--拼团(微商城)
    ,is_open_kjwsc  						--砍价(微商城)
    ,is_open_hbtg  							--海报推广
    ,is_open_xsqg  							--限时抢购
    ,is_open_qmyx  							--全民营销
    ,is_open_xcxzxjq  						--小程序中心(景区)
    ,is_open_xcxzxlxsb  					--小程序中心(旅行社版)
    ,is_open_xmtfx  						--新媒体分销
    ,is_open_znyzj  							--智能云闸机
    ,is_open_zzsqpj  							--自助售取票机
    ,CAST(spare_field1 as INT) as spare_field1  --是否开通手持机
    ,is_open_yspzd  						--云票务
    ,is_open_yxdx  							--营销短信
    ,is_open_dxttzdy  						--短信抬头自定义
    ,is_openzdydxmb  						--自定义短信模板
    ,is_open_xxpwxt  						--线下票务系统
    ,is_open_lynk  							--旅游年卡
    ,is_open_xykt  							--新一卡通
    ,is_open_lyykt  						--旅游一卡通
    ,is_open_yqykt  						--园区一卡通
    ,is_open_wbmfmgl  						--外部码发码管理
    ,is_open_wlzx  							--物料中心
    ,is_open_typtfx  						--同业平台分销
    ,is_open_typtfxjcb  					--同业平台分销(基础版)


    ,concat(
        case when is_open_zyzx=1 then  '资源中心;' else '' end
        ,case when is_open_wxzxwsc    =1 then  '微商城;'    else '' end
        ,case when is_open_gzhyx  	=1 then  '公众号营销;'    else '' end
        ,case when is_open_hbffl 	=1 then   '红包翻翻乐;'   else '' end
        ,case when is_open_yhq  	=1 then   '优惠券;'    else '' end
        ,case when is_open_zghxf 	=1 then  '公众号吸粉;'    else '' end
        ,case when is_open_ptwsc  	=1 then   '拼团;'    else '' end
        ,case when is_open_kjwsc  	=1 then   '砍价;'   else '' end
        ,case when is_open_hbtg  	=1 then     '海报推广;'  else '' end
        ,case when is_open_xsqg  	=1 then   '限时抢购;'    else '' end
        ,case when is_open_qmyx  	=1 then    '全民营销;'  else '' end
        ,case when is_open_xcxzxjq  =1 then   '玩聚小程序景区;'    else '' end
        ,case when is_open_xcxzxlxsb  =1 then '玩聚小程序旅行社;'     else '' end
        ,case when is_open_xmtfx  	=1 then   '新媒体分销;'    else '' end
        ,case when is_open_znyzj  	=1 then   '智能云闸机;'   else '' end
        ,case when is_open_zzsqpj  	=1 then   '自助售取票机;'   else '' end
        ,case when spare_field1       =1 then   '手持机;'   else '' end
        ,case when is_open_yspzd  	=1 then  '云票务;'    else '' end
        ,case when is_open_yxdx  	=1 then    '营销短信;'   else '' end
        ,case when is_open_dxttzdy  =1 then   '短信抬头自定义;'   else '' end
        ,case when is_openzdydxmb  	=1 then   '自定义短信模板;'   else '' end
        ,case when is_open_xxpwxt  	=1 then    '线下票务系统;'   else '' end
        ,case when is_open_lynk  	=1 then   '旅游年卡;'   else '' end
        ,case when is_open_xykt  	=1 then   '新一卡通;'    else '' end
        ,case when is_open_lyykt  	=1 then    '旅游一卡通;'   else '' end
        ,case when is_open_yqykt  	=1 then    '园区一卡通;'  else '' end
        ,case when is_open_wbmfmgl  =1 then    '外部码发码管理;'  else '' end
        ,case when is_open_wlzx  	=1 then    '物料中心;'  else '' end
        ,case when is_open_typtfx  	=1 then    '同业平台分销;'  else '' end
        ,case when is_open_typtfxjcb  =1 then   '同业平台分销(基础版);'   else '' end
        ,case when is_open_xcxpro  =1 then   '小程序Pro;'   else '' end
        ,case when is_open_dzfp  =1 then   '电子发票;'   else '' end
        ,case when spare_field17  =1 then   '小程序分销员;'   else '' end
        ,case when spare_field18  =1 then   '分销库存;'   else '' end
        
        ,case when is_open_wsc    =1 then  '微商城（旧版）'    else '' end
		,case when is_open_sjlp  =1 then  '数据罗盘'    else '' end
		,case when is_open_miniyzd    =1 then  'MINI云终端'    else '' end
		,case when is_open_ljgg  =1 then  '链接广告'    else '' end
		,case when is_open_appxz  		=1 then  'APP下载'    else '' end
		,case when is_open_jdxd  		=1 then  '计调下单'    else '' end
		,case when is_open_yhqjb  		=1 then  '优惠券(旧版)'    else '' end
		,case when is_open_b2cscpcd  	=1 then  'B2C商城（PC端）'    else '' end
		,case when is_open_jszdrz  		=1 then  '结算自动入帐'    else '' end
		,case when is_open_otaptfx  	=1 then  'OTA平台分销'    else '' end
		,case when is_open_fxdsfcp  	=1 then  '分销第三方产品'    else '' end
		,case when is_open_wqglxt  		=1 then  '温泉管理系统'    else '' end
		,case when is_open_jqpwxt  		=1 then  '景区票务系统'    else '' end
		,case when is_open_zfxcp  		=1 then  '转分销产品'    else '' end
		,case when is_open_dsjfx  		=1 then  '大数据分析'    else '' end
		,case when is_open_flgl  		=1 then  '返利管理'    else '' end
		,case when is_open_mygxdj  		=1 then  '蚂蚁供销对接'    else '' end
		,case when is_open_yzwscdj  	=1 then  '有赞微商城对接'    else '' end
		,case when is_open_miniyxcx  	=1 then  'MiNi云小程序'    else '' end
		,case when is_open_jfsc  		=1 then  '积分商城'    else '' end
		,case when is_open_fxzy  		=1 then  '分销专员'    else '' end
		,case when is_open_hytx  		=1 then  '会员体系'    else '' end
		,case when is_open_xcxsc 		=1 then  '小程序商城'    else '' end
		,case when is_open_fsyy  		=1 then  '分时预约'    else '' end
		,case when is_open_xfxzy  		=1 then  '新分销专员'    else '' end
		,case when is_open_rlzx  		=1 then  '人脸中心'    else '' end
		,case when is_open_ckgl  		=1 then  '窗口管理'    else '' end
		,case when is_open_zpgl  		=1 then  '纸票管理'    else '' end
		,case when is_open_btglgysb  	=1 then  '报团管理（供应商版）'    else '' end
		,case when is_open_btglfxsb  	=1 then  '报团管理（分销商版）'    else '' end
		,case when is_open_schygl  		=1 then  '商城会员管理'    else '' end
		,case when is_open_yqjs  		=1 then  '园区计时'    else '' end
		,case when is_open_jqsjlp  		=1 then  '景区数据罗盘'    else '' end
		,case when is_open_dlymdj  		=1 then  '独立域名搭建'    else '' end
		,case when is_open_wxkq  		=1 then  '微信卡券'    else '' end
		,case when is_open_gpxzhbmd  	=1 then  '购票限制(黑白名单)'    else '' end
		,case when is_open_crysjtj  	=1 then  '出入园数据统计'    else '' end
		--,case when is_open_csyy21wm  	=1 then  '测试应用21（勿买）'    else '' end
		,''  --case when is_open_ylcs  		=1 then  '依赖测试'    else '' end
		,case when is_open_csyyw  		=1 then  '测试应用w'    else '' end
		,case when is_open_qwechb  		=1 then  'qwe_chb'    else '' end
		,case when is_open_cssy  		=1 then  '测试使用'    else '' end
		,case when is_open_zdgl  		=1 then  '终端管理'    else '' end
		,case when is_open_lxssjlp  	=1 then  '旅行社数据罗盘'    else '' end
		,case when is_open_lyxd  		=1 then  '旅游小店'    else '' end
		,case when is_open_xypgl  		=1 then  '协议票管理'    else '' end
		,case when is_open_tstdyy  		=1 then  '特殊团队预约'    else '' end
		,case when is_open_smyzbzb  	=1 then  '扫码验证-标准版'    else '' end
		,case when is_open_smyzzyb  	=1 then  '扫码验证-专业版'    else '' end
		,case when is_open_wpttbfx  	=1 then  '微平台图表分析'    else '' end
		,case when is_open_dyglgysb  	=1 then  '导游管理(供应商版)'    else '' end
		,case when is_open_dyglfxsb  	=1 then  '导游管理(分销商版)'    else '' end
		,case when is_open_test  		=1 then  'test'    else '' end
		,case when is_open_gpqz  		=1 then  '购票前置'    else '' end
		,case when is_open_ddxxyc  	=1 then  '订单信息隐藏'    else '' end
		,case when is_open_kjgp  		=1 then  '快捷购票'    else '' end
		,case when is_open_flglx  		=1 then  '返利管理（新）'    else '' end
		,case when is_open_bbyy  		=1 then  '报表应用'    else '' end
		,case when is_open_csyywm  	=1 then  '测试应用（勿买）'    else '' end
		,case when is_open_tdyy  		=1 then  '团队预约'    else '' end
		,case when is_open_fxskjgp  	=1 then  '分销商快捷购票'    else '' end
		,case when is_open_plzzbb  	=1 then  '票类纸质报表'    else '' end
		,case when is_open_qplfx  		=1 then  '全品类分销'    else '' end
		,case when is_open_tgdm  		=1 then  '团购导码'    else '' end
		,case when is_open_jyjcsj  	=1 then  '经营基础数据'    else '' end
		,case when is_open_jyfxsj  	=1 then  '经营数据中心'    else '' end
		,case when is_open_ycjs  		=1 then  '游船计时'    else '' end
		,case when is_open_jyxpbg  	=1 then  '经营小飘报告'    else '' end
		,case when is_open_jyhysj  	=1 then  '经营行业数据'    else '' end
		,case when is_open_tysy  		=1 then  '统一收银'    else '' end
		,case when is_open_hyzx  		=1 then  '会员中心'    else '' end
		,case when is_open_xcxzxnkb  	=1 then  '小程序中心（年卡版）'    else '' end
		,case when is_open_jdgl  		=1 then  '酒店管理'    else '' end
		,case when is_open_zhdl  		=1 then  '智慧导览'    else '' end
		,case when is_open_jfgl  		=1 then  '积分管理'    else '' end
		,case when is_open_fzbbx  		=1 then  '分账报表(新)'    else '' end
		,case when is_open_xcxfxy  	=1 then  '小程序分销员'    else '' end
		,case when is_open_fxkc  		=1 then  '分销库存'    else '' end
		,case when is_open_cwph  		=1 then  '财务平衡'    else '' end
    ) as concat_all_open


    ,concat(
        case when is_open_zyzx=0 then  '资源中心;' else '' end
        ,case when is_open_wxzxwsc    =0 then  '微商城;'    else '' end
        ,case when is_open_gzhyx  	=0 then  '公众号营销;'    else '' end
        ,case when is_open_hbffl 	=0 then   '红包翻翻乐;'   else '' end
        ,case when is_open_yhq  	=0 then   '优惠券;'    else '' end
        ,case when is_open_zghxf 	=0 then  '公众号吸粉;'    else '' end
        ,case when is_open_ptwsc  	=0 then   '拼团;'    else '' end
        ,case when is_open_kjwsc  	=0 then   '砍价;'   else '' end
        ,case when is_open_hbtg  	=0 then     '海报推广;'  else '' end
        ,case when is_open_xsqg  	=0 then   '限时抢购;'    else '' end
        ,case when is_open_qmyx  	=0 then    '全民营销;'  else '' end
        ,case when is_open_xcxzxjq  =0 then   '玩聚小程序景区;'    else '' end
        ,case when is_open_xcxzxlxsb  =0 then '玩聚小程序旅行社;'     else '' end
        ,case when is_open_xmtfx  	=0 then   '新媒体分销;'    else '' end
        ,case when is_open_znyzj  	=0 then   '智能云闸机;'   else '' end
        ,case when is_open_zzsqpj  	=0 then   '自助售取票机;'   else '' end
        ,case when spare_field1       =0 then   '手持机;'   else '' end
        ,case when is_open_yspzd  	=0 then  '云票务;'    else '' end
        ,case when is_open_yxdx  	=0 then    '营销短信;'   else '' end
        ,case when is_open_dxttzdy  =0 then   '短信抬头自定义;'   else '' end
        ,case when is_openzdydxmb  	=0 then   '自定义短信模板;'   else '' end
        ,case when is_open_xxpwxt  	=0 then    '线下票务系统;'   else '' end
        ,case when is_open_lynk  	=0 then   '旅游年卡;'   else '' end
        ,case when is_open_xykt  	=0 then   '新一卡通;'    else '' end
        ,case when is_open_lyykt  	=0 then    '旅游一卡通;'   else '' end
        ,case when is_open_yqykt  	=0 then    '园区一卡通;'  else '' end
        ,case when is_open_wbmfmgl  =0 then    '外部码发码管理;'  else '' end
        ,case when is_open_wlzx  	=0 then    '物料中心;'  else '' end
        ,case when is_open_typtfx  	=0 then    '同业平台分销;'  else '' end
        ,case when is_open_typtfxjcb  =0 then   '同业平台分销(基础版);'   else '' end
        ,case when is_open_xcxpro  =0 then   '小程序Pro;'   else '' end
        ,case when is_open_dzfp  =0 then   '电子发票;'   else '' end
        ,case when spare_field17  =0 then   '小程序分销员;'   else '' end
        ,case when spare_field18  =0 then   '分销库存;'   else '' end
    ) as concat_all_null

    ,CAST(spare_field2 as INT) as spare_field2   --海报推广次数
    ,a.user_curr_package_id spare_field3   -- 当前套餐ID
    ,is_open_dzfp spare_field4   -- 是否开通电子发票
    ,CAST(spare_field5 as INT) as spare_field5  

    ,CAST(spare_field6 as INT) as spare_field6 
    ,CAST(spare_field7 as INT) as spare_field7  
    ,CAST(spare_field8 as INT) as spare_field8  
    ,CAST(spare_field9 as INT) as spare_field9  
    ,CAST(spare_field10 as INT) as spare_field10  

    ,nvl(b.ticket_num_frist_month,0)  ticket_num_frist_month   
    ,nvl(b.ticket_num_second_month,0) ticket_num_second_month   
    ,nvl(b.ticket_num_third_month,0)  ticket_num_third_month  
    ,nvl(b.gmv_frist_month,0)         gmv_frist_month   
    ,nvl(b.gmv_second_month,0)        gmv_second_month   
    ,nvl(b.gmv_third_month,0)         gmv_third_month     
    ,nvl(b.order_num_frist_month,0)   order_num_frist_month     
    ,nvl(b.order_num_second_month,0)  order_num_second_month     
    ,nvl(b.order_num_third_month,0)   order_num_third_month                                            
    --平台预定   --票量    --GMV   --订单量                                                  
    ,nvl(b.plat_ticket_num_frist_month,0)                    plat_ticket_num_frist_month                                  
    ,nvl(b.plat_ticket_num_second_month,0)                   plat_ticket_num_second_month                                 
    ,nvl(b.plat_ticket_num_third_month,0)                    plat_ticket_num_third_month                                  
    ,nvl(b.plat_gmv_frist_month,0)                           plat_gmv_frist_month                                         
    ,nvl(b.plat_gmv_second_month,0)                          plat_gmv_second_month                                        
    ,nvl(b.plat_gmv_third_month,0)                           plat_gmv_third_month                                         
    ,nvl(b.plat_order_num_frist_month,0)                     plat_order_num_frist_month                                   
    ,nvl(b.plat_order_num_second_month,0)                    plat_order_num_second_month                                  
    ,nvl(b.plat_order_num_third_month,0)                     plat_order_num_third_month                                   
    --普通用户支付   --票量    --GMV   --订单量                                            
    ,nvl(b.account_ticket_num_frist_month,0)                 account_ticket_num_frist_month                               
    ,nvl(b.account_ticket_num_second_month,0)                account_ticket_num_second_month                              
    ,nvl(b.account_ticket_num_third_month,0)                 account_ticket_num_third_month                               
    ,nvl(b.account_gmv_frist_month,0)                        account_gmv_frist_month                                      
    ,nvl(b.account_gmv_second_month,0)                       account_gmv_second_month                                     
    ,nvl(b.account_gmv_third_month,0)                        account_gmv_third_month                                      
    ,nvl(b.account_order_num_frist_month,0)                  account_order_num_frist_month                                
    ,nvl(b.account_order_num_second_month,0)                 account_order_num_second_month                               
    ,nvl(b.account_order_num_third_month,0)                  account_order_num_third_month                                
    --会员卡购票   --票量    --GMV   --订单量                                            
    ,nvl(b.vip_ticket_num_frist_month,0)                     vip_ticket_num_frist_month                                   
    ,nvl(b.vip_ticket_num_second_month,0)                    vip_ticket_num_second_month                                  
    ,nvl(b.vip_ticket_num_third_month,0)                     vip_ticket_num_third_month                                   
    ,nvl(b.vip_gmv_frist_month,0)                            vip_gmv_frist_month                                          
    ,nvl(b.vip_gmv_second_month,0)                           vip_gmv_second_month                                         
    ,nvl(b.vip_gmv_third_month,0)                            vip_gmv_third_month                                          
    ,nvl(b.vip_order_num_frist_month,0)                      vip_order_num_frist_month                                    
    ,nvl(b.vip_order_num_second_month,0)                     vip_order_num_second_month                                   
    ,nvl(b.vip_order_num_third_month,0)                      vip_order_num_third_month                                    
    --云票务   --票量    --GMV   --订单量                                                  
    ,nvl(b.cloud_ticket_num_frist_month,0)                   cloud_ticket_num_frist_month                                 
    ,nvl(b.cloud_ticket_num_second_month,0)                  cloud_ticket_num_second_month                                
    ,nvl(b.cloud_ticket_num_third_month,0)                   cloud_ticket_num_third_month                                 
    ,nvl(b.cloud_gmv_frist_month,0)                          cloud_gmv_frist_month                                        
    ,nvl(b.cloud_gmv_second_month,0)                         cloud_gmv_second_month                                       
    ,nvl(b.cloud_gmv_third_month,0)                          cloud_gmv_third_month                                        
    ,nvl(b.cloud_order_num_frist_month,0)                    cloud_order_num_frist_month                                  
    ,nvl(b.cloud_order_num_second_month,0)                   cloud_order_num_second_month                                 
    ,nvl(b.cloud_order_num_third_month,0)                    cloud_order_num_third_month                                  
    --微商城   --票量    --GMV   --订单量                                                  
    ,nvl(b.mall_ticket_num_frist_month,0)                    mall_ticket_num_frist_month                                  
    ,nvl(b.mall_ticket_num_second_month,0)                   mall_ticket_num_second_month                                 
    ,nvl(b.mall_ticket_num_third_month,0)                    mall_ticket_num_third_month                                  
    ,nvl(b.mall_gmv_frist_month,0)                           mall_gmv_frist_month                                         
    ,nvl(b.mall_gmv_second_month,0)                          mall_gmv_second_month                                        
    ,nvl(b.mall_gmv_third_month,0)                           mall_gmv_third_month                                         
    ,nvl(b.mall_order_num_frist_month,0)                     mall_order_num_frist_month                                   
    ,nvl(b.mall_order_num_second_month,0)                    mall_order_num_second_month                                  
    ,nvl(b.mall_order_num_third_month,0)                     mall_order_num_third_month                                   
    --自助机   --票量    --GMV   --订单量                                                      
    ,nvl(b.cdm_ticket_num_frist_month,0)                     cdm_ticket_num_frist_month                                   
    ,nvl(b.cdm_ticket_num_second_month,0)                    cdm_ticket_num_second_month                                  
    ,nvl(b.cdm_ticket_num_third_month,0)                     cdm_ticket_num_third_month                                   
    ,nvl(b.cdm_gmv_frist_month,0)                            cdm_gmv_frist_month                                          
    ,nvl(b.cdm_gmv_second_month,0)                           cdm_gmv_second_month                                         
    ,nvl(b.cdm_gmv_third_month,0)                            cdm_gmv_third_month                                          
    ,nvl(b.cdm_order_num_frist_month,0)                      cdm_order_num_frist_month                                    
    ,nvl(b.cdm_order_num_second_month,0)                     cdm_order_num_second_month                                   
    ,nvl(b.cdm_order_num_third_month,0)                      cdm_order_num_third_month                                    
    --PC商城   --票量    --GMV   --订单量                                                     
    ,nvl(b.pc_ticket_num_frist_month,0)                      pc_ticket_num_frist_month                                    
    ,nvl(b.pc_ticket_num_second_month,0)                     pc_ticket_num_second_month                                   
    ,nvl(b.pc_ticket_num_third_month,0)                      pc_ticket_num_third_month                                    
    ,nvl(b.pc_gmv_frist_month,0)                             pc_gmv_frist_month                                           
    ,nvl(b.pc_gmv_second_month,0)                            pc_gmv_second_month                                          
    ,nvl(b.pc_gmv_third_month,0)                             pc_gmv_third_month                                           
    ,nvl(b.pc_order_num_frist_month,0)                       pc_order_num_frist_month                                     
    ,nvl(b.pc_order_num_second_month,0)                      pc_order_num_second_month                                    
    ,nvl(b.pc_order_num_third_month,0)                       pc_order_num_third_month                                     
    --闸机   --票量    --GMV   --订单量                                                        
    ,nvl(b.agm_ticket_num_frist_month,0)                     agm_ticket_num_frist_month                                   
    ,nvl(b.agm_ticket_num_second_month,0)                    agm_ticket_num_second_month                                  
    ,nvl(b.agm_ticket_num_third_month,0)                     agm_ticket_num_third_month                                   
    ,nvl(b.agm_gmv_frist_month,0)                            agm_gmv_frist_month                                          
    ,nvl(b.agm_gmv_second_month,0)                           agm_gmv_second_month                                         
    ,nvl(b.agm_gmv_third_month,0)                            agm_gmv_third_month                                          
    ,nvl(b.agm_order_num_frist_month,0)                      agm_order_num_frist_month                                    
    ,nvl(b.agm_order_num_second_month,0)                     agm_order_num_second_month                                   
    ,nvl(b.agm_order_num_third_month,0)                      agm_order_num_third_month                                    
    --智能终端   --票量    --GMV   --订单量                                                 
    ,nvl(b.smart_terminal_ticket_num_frist_month,0)          smart_terminal_ticket_num_frist_month                        
    ,nvl(b.smart_terminal_ticket_num_second_month,0)         smart_terminal_ticket_num_second_month                       
    ,nvl(b.smart_terminal_ticket_num_third_month,0)          smart_terminal_ticket_num_third_month                        
    ,nvl(b.smart_terminal_gmv_frist_month,0)                 smart_terminal_gmv_frist_month                               
    ,nvl(b.smart_terminal_gmv_second_month,0)                smart_terminal_gmv_second_month                              
    ,nvl(b.smart_terminal_gmv_third_month,0)                 smart_terminal_gmv_third_month                               
    ,nvl(b.smart_terminal_order_num_frist_month,0)           smart_terminal_order_num_frist_month                         
    ,nvl(b.smart_terminal_order_num_second_month,0)          smart_terminal_order_num_second_month                        
    ,nvl(b.smart_terminal_order_num_num_third_month,0)       smart_terminal_order_num_num_third_month                     
    --计调   --票量    --GMV   --订单量                                                       
    ,nvl(b.adj_ticket_num_frist_month,0)                     adj_ticket_num_frist_month                                   
    ,nvl(b.adj_ticket_num_second_month,0)                    adj_ticket_num_second_month                                  
    ,nvl(b.adj_ticket_num_third_month,0)                     adj_ticket_num_third_month                                   
    ,nvl(b.adj_gmv_frist_month,0)                            adj_gmv_frist_month                                          
    ,nvl(b.adj_gmv_second_month,0)                           adj_gmv_second_month                                         
    ,nvl(b.adj_gmv_third_month,0)                            adj_gmv_third_month                                          
    ,nvl(b.adj_order_num_frist_month,0)                      adj_order_num_frist_month                                    
    ,nvl(b.adj_order_num_second_month,0)                     adj_order_num_second_month                                   
    ,nvl(b.adj_order_num_third_month,0)                      adj_order_num_third_month                                    
    --淘宝/飞猪   --票量    --GMV   --订单量                                        
    ,nvl(b.tb_ticket_num_frist_month,0)                      tb_ticket_num_frist_month                                    
    ,nvl(b.tb_ticket_num_second_month,0)                     tb_ticket_num_second_month                                   
    ,nvl(b.tb_ticket_num_third_month,0)                      tb_ticket_num_third_month                                    
    ,nvl(b.tb_gmv_frist_month,0)                             tb_gmv_frist_month                                           
    ,nvl(b.tb_gmv_second_month,0)                            tb_gmv_second_month                                          
    ,nvl(b.tb_gmv_third_month,0)                            tb_gmv_third_month                                           
    ,nvl(b.tb_order_num_frist_month,0)                       tb_order_num_frist_month                                     
    ,nvl(b.tb_order_num_second_month,0)                      tb_order_num_second_month                                    
    ,nvl(b.tb_order_num_third_month,0)                       tb_order_num_third_month                                     
    --年卡特权   --票量    --GMV   --订单量                                         
    ,nvl(b.year_card_ticket_num_frist_month,0)               year_card_ticket_num_frist_month                             
    ,nvl(b.year_card_ticket_num_second_month,0)              year_card_ticket_num_second_month                            
    ,nvl(b.year_card_ticket_num_third_month,0)               year_card_ticket_num_third_month                             
    ,nvl(b.year_card_gmv_frist_month,0)                      year_card_gmv_frist_month                                    
    ,nvl(b.year_card_gmv_second_month,0)                     year_card_gmv_second_month                                   
    ,nvl(b.year_card_gmv_third_month,0)                      year_card_gmv_third_month                                    
    ,nvl(b.year_card_order_num_frist_month,0)                year_card_order_num_frist_month                              
    ,nvl(b.year_card_order_num_second_month,0)               year_card_order_num_second_month                             
    ,nvl(b.year_card_order_num_third_month,0)                year_card_order_num_third_month                              
    --微平台   --票量    --GMV   --订单量                                                  
    ,nvl(b.mall_plat_ticket_num_frist_month,0)               mall_plat_ticket_num_frist_month                             
    ,nvl(b.mall_plat_ticket_num_second_month,0)              mall_plat_ticket_num_second_month                            
    ,nvl(b.mall_plat_ticket_num_third_month,0)               mall_plat_ticket_num_third_month                             
    ,nvl(b.mall_plat_gmv_frist_month,0)                      mall_plat_gmv_frist_month                                    
    ,nvl(b.mall_plat_gmv_second_month,0)                     mall_plat_gmv_second_month                                   
    ,nvl(b.mall_plat_gmv_third_month,0)                      mall_plat_gmv_third_month                                    
    ,nvl(b.mall_plat_order_num_frist_month,0)                mall_plat_order_num_frist_month                              
    ,nvl(b.mall_plat_order_num_second_month,0)               mall_plat_order_num_second_month                             
    ,nvl(b.mall_plat_order_num_third_month,0)                mall_plat_order_num_third_month                              
    --OTA   --票量    --GMV   --订单量                                                    
    ,nvl(b.ota_ticket_num_frist_month,0)                     ota_ticket_num_frist_month                                   
    ,nvl(b.ota_ticket_num_second_month,0)                    ota_ticket_num_second_month                                  
    ,nvl(b.ota_ticket_num_third_month,0)                     ota_ticket_num_third_month                                   
    ,nvl(b.ota_gmv_frist_month,0)                            ota_gmv_frist_month                                          
    ,nvl(b.ota_gmv_second_month,0)                           ota_gmv_second_month                                         
    ,nvl(b.ota_gmv_third_month,0)                            ota_gmv_third_month                                          
    ,nvl(b.ota_order_num_frist_month,0)                      ota_order_num_frist_month                                    
    ,nvl(b.ota_order_num_second_month,0)                     ota_order_num_second_month                                   
    ,nvl(b.ota_order_num_third_month,0)                      ota_order_num_third_month                                    
    --兑换码购票   --票量    --GMV   --订单量                                           
    ,nvl(b.pay_code_ticket_num_frist_month,0)                pay_code_ticket_num_frist_month                              
    ,nvl(b.pay_code_ticket_num_second_month,0)               pay_code_ticket_num_second_month                             
    ,nvl(b.pay_code_ticket_num_third_month,0)                pay_code_ticket_num_third_month                              
    ,nvl(b.pay_code_gmv_frist_month,0)                       pay_code_gmv_frist_month                                     
    ,nvl(b.pay_code_gmv_second_month,0)                      pay_code_gmv_second_month                                    
    ,nvl(b.pay_code_gmv_third_month,0)                       pay_code_gmv_third_month                                     
    ,nvl(b.pay_code_order_num_frist_month,0)                 pay_code_order_num_frist_month                               
    ,nvl(b.pay_code_order_num_second_month,0)                pay_code_order_num_second_month                              
    ,nvl(b.pay_code_order_num_third_month,0)                 pay_code_order_num_third_month                               
    --一卡通   --票量    --GMV   --订单量                                                     
    ,nvl(b.one_card_ticket_num_frist_month,0)                one_card_ticket_num_frist_month                              
    ,nvl(b.one_card_ticket_num_second_month,0)               one_card_ticket_num_second_month                             
    ,nvl(b.one_card_ticket_num_third_month,0)                one_card_ticket_num_third_month                              
    ,nvl(b.one_card_gmv_frist_month,0)                       one_card_gmv_frist_month                                     
    ,nvl(b.one_card_gmv_second_month,0)                      one_card_gmv_second_month                                    
    ,nvl(b.one_card_gmv_third_month,0)                       one_card_gmv_third_month                                     
    ,nvl(b.one_card_order_num_frist_month,0)                 one_card_order_num_frist_month                               
    ,nvl(b.one_card_order_num_second_month,0)                one_card_order_num_second_month                              
    ,nvl(b.one_card_order_num_third_month,0)                 one_card_order_num_third_month                               
    --套票子票   --票量    --GMV   --订单量                                              
    ,nvl(b.subticket_ticket_num_frist_month,0)               subticket_ticket_num_frist_month                             
    ,nvl(b.subticket_ticket_num_second_month,0)              subticket_ticket_num_second_month                            
    ,nvl(b.subticket_ticket_num_third_month,0)               subticket_ticket_num_third_month                             
    ,nvl(b.subticket_gmv_frist_month,0)                      subticket_gmv_frist_month                                    
    ,nvl(b.subticket_gmv_second_month,0)                     subticket_gmv_second_month                                   
    ,nvl(b.subticket_gmv_third_month,0)                      subticket_gmv_third_month                                    
    ,nvl(b.subticket_order_num_frist_month,0)                subticket_order_num_frist_month                              
    ,nvl(b.subticket_order_num_second_month,0)               subticket_order_num_second_month                             
    ,nvl(b.subticket_order_num_third_month,0)                subticket_order_num_third_month                              
    --团队预定   --票量    --GMV   --订单量                                              
    ,nvl(b.group_ticket_num_frist_month,0)                   group_ticket_num_frist_month                                 
    ,nvl(b.group_ticket_num_second_month,0)                  group_ticket_num_second_month                                
    ,nvl(b.group_ticket_num_third_month,0)                   group_ticket_num_third_month                                 
    ,nvl(b.group_gmv_frist_month,0)                          group_gmv_frist_month                                        
    ,nvl(b.group_gmv_second_month,0)                         group_gmv_second_month                                       
    ,nvl(b.group_gmv_third_month,0)                          group_gmv_third_month                                        
    ,nvl(b.group_order_num_frist_month,0)                    group_order_num_frist_month                                  
    ,nvl(b.group_order_num_second_month,0)                   group_order_num_second_month                                 
    ,nvl(b.group_order_num_third_month,0)                    group_order_num_third_month                                  
    --E福州   --票量    --GMV   --订单量                                                   
    ,nvl(b.efuzhou_ticket_num_frist_month,0)                 efuzhou_ticket_num_frist_month                               
    ,nvl(b.efuzhou_ticket_num_second_month,0)                efuzhou_ticket_num_second_month                              
    ,nvl(b.efuzhou_ticket_num_third_month,0)                 efuzhou_ticket_num_third_month                               
    ,nvl(b.efuzhou_gmv_frist_month,0)                        efuzhou_gmv_frist_month                                      
    ,nvl(b.efuzhou_gmv_second_month,0)                       efuzhou_gmv_second_month                                     
    ,nvl(b.efuzhou_gmv_third_month,0)                        efuzhou_gmv_third_month                                      
    ,nvl(b.efuzhou_order_num_frist_month,0)                  efuzhou_order_num_frist_month                                
    ,nvl(b.efuzhou_order_num_second_month,0)                 efuzhou_order_num_second_month                               
    ,nvl(b.efuzhou_order_num_third_month,0)                  efuzhou_order_num_third_month                                
    --拼团   --票量    --GMV   --订单量                                                      
    ,nvl(b.assorted_ticket_num_frist_month,0)                assorted_ticket_num_frist_month                              
    ,nvl(b.assorted_ticket_num_second_month,0)               assorted_ticket_num_second_month                             
    ,nvl(b.assorted_ticket_num_third_month,0)                assorted_ticket_num_third_month                              
    ,nvl(b.assorted_gmv_frist_month,0)                       assorted_gmv_frist_month                                     
    ,nvl(b.assorted_gmv_second_month,0)                      assorted_gmv_second_month                                    
    ,nvl(b.assorted_gmv_third_month,0)                       assorted_gmv_third_month                                     
    ,nvl(b.assorted_order_num_frist_month,0)                 assorted_order_num_frist_month                               
    ,nvl(b.assorted_order_num_second_month,0)                assorted_order_num_second_month                              
    ,nvl(b.assorted_order_num_third_month,0)                 assorted_order_num_third_month                               
    --积分商城 --票量    --GMV   --订单量                                              
    ,nvl(b.integral_mall_ticket_num_frist_month,0)           integral_mall_ticket_num_frist_month                         
    ,nvl(b.integral_mall_ticket_num_second_month,0)          integral_mall_ticket_num_second_month                        
    ,nvl(b.integral_mall_ticket_num_third_month,0)           integral_mall_ticket_num_third_month                         
    ,nvl(b.integral_mall_gmv_frist_month,0)                  integral_mall_gmv_frist_month                                
    ,nvl(b.integral_mall_gmv_second_month,0)                 integral_mall_gmv_second_month                               
    ,nvl(b.integral_mall_gmv_third_month,0)                  integral_mall_gmv_third_month                                
    ,nvl(b.integral_mall_order_num_frist_month,0)            integral_mall_order_num_frist_month                          
    ,nvl(b.integral_mall_order_num_second_month,0)           integral_mall_order_num_second_month                         
    ,nvl(b.integral_mall_order_num_third_month,0)            integral_mall_order_num_third_month                          
    --POS支付 --票量    --GMV   --订单量                                                   
    ,nvl(b.pos_ticket_num_frist_month,0)                     pos_ticket_num_frist_month                                   
    ,nvl(b.pos_ticket_num_second_month,0)                    pos_ticket_num_second_month                                  
    ,nvl(b.pos_ticket_num_third_month,0)                     pos_ticket_num_third_month                                   
    ,nvl(b.pos_gmv_frist_month,0)                            pos_gmv_frist_month                                          
    ,nvl(b.pos_gmv_second_month,0)                           pos_gmv_second_month                                         
    ,nvl(b.pos_gmv_third_month,0)                            pos_gmv_third_month                                          
    ,nvl(b.pos_order_num_frist_month,0)                      pos_order_num_frist_month                                    
    ,nvl(b.pos_order_num_second_month,0)                     pos_order_num_second_month                                   
    ,nvl(b.pos_order_num_third_month,0)                      pos_order_num_third_month                                    
    --招行 --票量    --GMV   --订单量                                                        
    ,nvl(b.icbc_ticket_num_frist_month,0)                    icbc_ticket_num_frist_month                                  
    ,nvl(b.icbc_ticket_num_second_month,0)                   icbc_ticket_num_second_month                                 
    ,nvl(b.icbc_ticket_num_third_month,0)                    icbc_ticket_num_third_month                                  
    ,nvl(b.icbc_gmv_frist_month,0)                           icbc_gmv_frist_month                                         
    ,nvl(b.icbc_gmv_second_month,0)                          icbc_gmv_second_month                                        
    ,nvl(b.icbc_gmv_third_month,0)                           icbc_gmv_third_month                                         
    ,nvl(b.icbc_order_num_frist_month,0)                     icbc_order_num_frist_month                                   
    ,nvl(b.icbc_order_num_second_month,0)                    icbc_order_num_second_month                                  
    ,nvl(b.icbc_order_num_third_month,0)                     icbc_order_num_third_month                                   
    --银联商务 --票量    --GMV   --订单量                                                   
    ,nvl(b.bankunion_ticket_num_frist_month,0)               bankunion_ticket_num_frist_month                             
    ,nvl(b.bankunion_ticket_num_second_month,0)              bankunion_ticket_num_second_month                            
    ,nvl(b.bankunion_ticket_num_third_month,0)               bankunion_ticket_num_third_month                             
    ,nvl(b.bankunion_gmv_frist_month,0)                      bankunion_gmv_frist_month                                    
    ,nvl(b.bankunion_gmv_second_month,0)                     bankunion_gmv_second_month                                   
    ,nvl(b.bankunion_gmv_third_month,0)                      bankunion_gmv_third_month                                    
    ,nvl(b.bankunion_order_num_frist_month,0)                bankunion_order_num_frist_month                              
    ,nvl(b.bankunion_order_num_second_month,0)               bankunion_order_num_second_month                             
    ,nvl(b.bankunion_order_num_third_month,0)                bankunion_order_num_third_month                              
    --银联pos支付 --票量    --GMV   --订单量                                             
    ,nvl(b.bankunion_pos_ticket_num_frist_month,0)           bankunion_pos_ticket_num_frist_month                         
    ,nvl(b.bankunion_pos_ticket_num_second_month,0)          bankunion_pos_ticket_num_second_month                        
    ,nvl(b.bankunion_pos_ticket_num_third_month,0)           bankunion_pos_ticket_num_third_month                         
    ,nvl(b.bankunion_pos_gmv_frist_month,0)                  bankunion_pos_gmv_frist_month                                
    ,nvl(b.bankunion_pos_gmv_second_month,0)                 bankunion_pos_gmv_second_month                               
    ,nvl(b.bankunion_pos_gmv_third_month,0)                  bankunion_pos_gmv_third_month                                
    ,nvl(b.bankunion_pos_order_num_frist_month,0)            bankunion_pos_order_num_frist_month                          
    ,nvl(b.bankunion_pos_order_num_second_month,0)           bankunion_pos_order_num_second_month                         
    ,nvl(b.bankunion_pos_order_num_third_month,0)            bankunion_pos_order_num_third_month                          
    --威富通 --票量    --GMV   --订单量                                                    
    ,nvl(b.wft_ticket_num_frist_month,0)                     wft_ticket_num_frist_month                                   
    ,nvl(b.wft_ticket_num_second_month,0)                    wft_ticket_num_second_month                                  
    ,nvl(b.wft_ticket_num_third_month,0)                     wft_ticket_num_third_month                                   
    ,nvl(b.wft_gmv_frist_month,0)                            wft_gmv_frist_month                                          
    ,nvl(b.wft_gmv_second_month,0)                           wft_gmv_second_month                                         
    ,nvl(b.wft_gmv_third_month,0)                            wft_gmv_third_month                                          
    ,nvl(b.wft_order_num_frist_month,0)                      wft_order_num_frist_month                                    
    ,nvl(b.wft_order_num_second_month,0)                     wft_order_num_second_month                                   
    ,nvl(b.wft_order_num_third_month,0)                      wft_order_num_third_month                                    
    --易宝 --票量    --GMV   --订单量                                                     
    ,nvl(b.yb_ticket_num_frist_month,0)                      yb_ticket_num_frist_month                                    
    ,nvl(b.yb_ticket_num_second_month,0)                     yb_ticket_num_second_month                                   
    ,nvl(b.yb_ticket_num_third_month,0)                      yb_ticket_num_third_month                                    
    ,nvl(b.yb_gmv_frist_month,0)                             yb_gmv_frist_month                                           
    ,nvl(b.yb_gmv_second_month,0)                            yb_gmv_second_month                                          
    ,nvl(b.yb_gmv_third_month,0)                             yb_gmv_third_month                                           
    ,nvl(b.yb_order_num_frist_month,0)                       yb_order_num_frist_month                                     
    ,nvl(b.yb_order_num_second_month,0)                      yb_order_num_second_month                                    
    ,nvl(b.yb_order_num_third_month,0)                       yb_order_num_third_month                                     
    --微信-微票房 --票量    --GMV   --订单量                                              
    ,nvl(b.wx_wpf_ticket_num_frist_month,0)                  wx_wpf_ticket_num_frist_month                                
    ,nvl(b.wx_wpf_ticket_num_second_month,0)                 wx_wpf_ticket_num_second_month                               
    ,nvl(b.wx_wpf_ticket_num_third_month,0)                  wx_wpf_ticket_num_third_month                                
    ,nvl(b.wx_wpf_gmv_frist_month,0)                         wx_wpf_gmv_frist_month                                       
    ,nvl(b.wx_wpf_gmv_second_month,0)                        wx_wpf_gmv_second_month                                      
    ,nvl(b.wx_wpf_gmv_third_month,0)                         wx_wpf_gmv_third_month                                       
    ,nvl(b.wx_wpf_order_num_frist_month,0)                   wx_wpf_order_num_frist_month                                 
    ,nvl(b.wx_wpf_order_num_second_month,0)                  wx_wpf_order_num_second_month                                
    ,nvl(b.wx_wpf_order_num_third_month,0)                   wx_wpf_order_num_third_month                                 
    --报团计调下单 --票量    --GMV   --订单量                                           
    ,nvl(b.adj_group_ticket_num_frist_month,0)               adj_group_ticket_num_frist_month                             
    ,nvl(b.adj_group_ticket_num_second_month,0)              adj_group_ticket_num_second_month                            
    ,nvl(b.adj_group_ticket_num_third_month,0)               adj_group_ticket_num_third_month                             
    ,nvl(b.adj_group_gmv_frist_month,0)                      adj_group_gmv_frist_month                                    
    ,nvl(b.adj_group_gmv_second_month,0)                     adj_group_gmv_second_month                                   
    ,nvl(b.adj_group_gmv_third_month,0)                      adj_group_gmv_third_month                                    
    ,nvl(b.adj_group_order_num_frist_month,0)                adj_group_order_num_frist_month                              
    ,nvl(b.adj_group_order_num_second_month,0)               adj_group_order_num_second_month                             
    ,nvl(b.adj_group_order_num_third_month,0)                adj_group_order_num_third_month                              
    --云闪付下单 --票量    --GMV   --订单量                                                  
    ,nvl(b.cloud_union_pay_ticket_num_frist_month,0)         cloud_union_pay_ticket_num_frist_month                       
    ,nvl(b.cloud_union_pay_ticket_num_second_month,0)        cloud_union_pay_ticket_num_second_month                      
    ,nvl(b.cloud_union_pay_ticket_num_third_month,0)         cloud_union_pay_ticket_num_third_month                       
    ,nvl(b.cloud_union_pay_gmv_frist_month,0)                cloud_union_pay_gmv_frist_month                              
    ,nvl(b.cloud_union_pay_gmv_second_month,0)               cloud_union_pay_gmv_second_month                             
    ,nvl(b.cloud_union_pay_gmv_third_month,0)                cloud_union_pay_gmv_third_month                              
    ,nvl(b.cloud_union_pay_order_num_frist_month,0)          cloud_union_pay_order_num_frist_month                        
    ,nvl(b.cloud_union_pay_order_num_second_month,0)         cloud_union_pay_order_num_second_month                       
    ,nvl(b.cloud_union_pay_order_num_third_month,0)          cloud_union_pay_order_num_third_month                        
    --断网离线订单 --票量    --GMV   --订单量                                           
    ,nvl(b.offline_ticket_num_frist_month,0)                 offline_ticket_num_frist_month                               
    ,nvl(b.offline_ticket_num_second_month,0)                offline_ticket_num_second_month                              
    ,nvl(b.offline_ticket_num_third_month,0)                 offline_ticket_num_third_month                               
    ,nvl(b.offline_gmv_frist_month,0)                        offline_gmv_frist_month                                      
    ,nvl(b.offline_gmv_second_month,0)                       offline_gmv_second_month                                     
    ,nvl(b.offline_gmv_third_month,0)                        offline_gmv_third_month                                      
    ,nvl(b.offline_order_num_frist_month,0)                  offline_order_num_frist_month                                
    ,nvl(b.offline_order_num_second_month,0)                 offline_order_num_second_month                               
    ,nvl(b.offline_order_num_third_month,0)                  offline_order_num_third_month                                
    --员工卡 --票量    --GMV   --订单量                                                        
    ,nvl(b.staff_card_ticket_num_frist_month,0)              staff_card_ticket_num_frist_month                            
    ,nvl(b.staff_card_ticket_num_second_month,0)             staff_card_ticket_num_second_month                           
    ,nvl(b.staff_card_ticket_num_third_month,0)              staff_card_ticket_num_third_month                            
    ,nvl(b.staff_card_gmv_frist_month,0)                     staff_card_gmv_frist_month                                   
    ,nvl(b.staff_card_gmv_second_month,0)                    staff_card_gmv_second_month                                  
    ,nvl(b.staff_card_gmv_third_month,0)                     staff_card_gmv_third_month                                   
    ,nvl(b.staff_card_order_num_frist_month,0)               staff_card_order_num_frist_month                             
    ,nvl(b.staff_card_order_num_second_month,0)              staff_card_order_num_second_month                            
    ,nvl(b.staff_card_order_num_third_month,0)               staff_card_order_num_third_month                             
    --手牌 --票量    --GMV   --订单量                                                  
    ,nvl(b.hand_card_ticket_num_frist_month,0)               hand_card_ticket_num_frist_month                             
    ,nvl(b.hand_card_ticket_num_second_month,0)              hand_card_ticket_num_second_month                            
    ,nvl(b.hand_card_ticket_num_third_month,0)               hand_card_ticket_num_third_month                             
    ,nvl(b.hand_card_gmv_frist_month,0)                      hand_card_gmv_frist_month                                    
    ,nvl(b.hand_card_gmv_second_month,0)                     hand_card_gmv_second_month                                   
    ,nvl(b.hand_card_gmv_third_month,0)                      hand_card_gmv_third_month                                    
    ,nvl(b.hand_card_order_num_frist_month,0)                hand_card_order_num_frist_month                              
    ,nvl(b.hand_card_order_num_second_month,0)               hand_card_order_num_second_month                             
    ,nvl(b.hand_card_order_num_third_month,0)                hand_card_order_num_third_month                              
    --桌面云票务 --票量    --GMV   --订单量                                              
    ,nvl(b.desk_cloud_ticket_num_frist_month,0)              desk_cloud_ticket_num_frist_month                            
    ,nvl(b.desk_cloud_ticket_num_second_month,0)             desk_cloud_ticket_num_second_month                           
    ,nvl(b.desk_cloud_ticket_num_third_month,0)              desk_cloud_ticket_num_third_month                            
    ,nvl(b.desk_cloud_gmv_frist_month,0)                     desk_cloud_gmv_frist_month                                   
    ,nvl(b.desk_cloud_gmv_second_month,0)                    desk_cloud_gmv_second_month                                  
    ,nvl(b.desk_cloud_gmv_third_month,0)                     desk_cloud_gmv_third_month                                   
    ,nvl(b.desk_cloud_order_num_frist_month,0)               desk_cloud_order_num_frist_month                             
    ,nvl(b.desk_cloud_order_num_second_month,0)              desk_cloud_order_num_second_month                            
    ,nvl(b.desk_cloud_order_num_third_month,0)               desk_cloud_order_num_third_month                             
    --APP --票量    --GMV   --订单量                                                         
    ,nvl(b.app_ticket_num_frist_month,0)                     app_ticket_num_frist_month                                   
    ,nvl(b.app_ticket_num_second_month,0)                    app_ticket_num_second_month                                  
    ,nvl(b.app_ticket_num_third_month,0)                     app_ticket_num_third_month                                   
    ,nvl(b.app_gmv_frist_month,0)                            app_gmv_frist_month                                          
    ,nvl(b.app_gmv_second_month,0)                           app_gmv_second_month                                         
    ,nvl(b.app_gmv_third_month,0)                            app_gmv_third_month                                          
    ,nvl(b.app_order_num_frist_month,0)                      app_order_num_frist_month                                    
    ,nvl(b.app_order_num_second_month,0)                     app_order_num_second_month                                   
    ,nvl(b.app_order_num_third_month,0)                      app_order_num_third_month                                    
    --特殊团队预约 --票量    --GMV   --订单量                                         
    ,nvl(b.special_ticket_num_frist_month,0)                 special_ticket_num_frist_month                               
    ,nvl(b.special_ticket_num_second_month,0)                special_ticket_num_second_month                              
    ,nvl(b.special_ticket_num_third_month,0)                 special_ticket_num_third_month                               
    ,nvl(b.special_gmv_frist_month,0)                        special_gmv_frist_month                                      
    ,nvl(b.special_gmv_second_month,0)                       special_gmv_second_month                                     
    ,nvl(b.special_gmv_third_month,0)                        special_gmv_third_month                                      
    ,nvl(b.special_order_num_frist_month,0)                  special_order_num_frist_month                                
    ,nvl(b.special_order_num_second_month,0)                 special_order_num_second_month                               
    ,nvl(b.special_order_num_third_month,0)                  special_order_num_third_month                                
    --微信小程序 --票量    --GMV   --订单量                                              
    ,nvl(b.wx_app_ticket_num_frist_month,0)                  wx_app_ticket_num_frist_month                                
    ,nvl(b.wx_app_ticket_num_second_month,0)                 wx_app_ticket_num_second_month                               
    ,nvl(b.wx_app_ticket_num_third_month,0)                  wx_app_ticket_num_third_month                                
    ,nvl(b.wx_app_gmv_frist_month,0)                         wx_app_gmv_frist_month                                       
    ,nvl(b.wx_app_gmv_second_month,0)                        wx_app_gmv_second_month                                      
    ,nvl(b.wx_app_gmv_third_month,0)                         wx_app_gmv_third_month                                       
    ,nvl(b.wx_app_order_num_frist_month,0)                   wx_app_order_num_frist_month                                 
    ,nvl(b.wx_app_order_num_second_month,0)                  wx_app_order_num_second_month                                
    ,nvl(b.wx_app_order_num_third_month,0)                   wx_app_order_num_third_month                                 
    --抖音-微票房 --票量    --GMV   --订单量                                              
    ,nvl(b.dy_tik_ticket_num_frist_month,0)                  dy_tik_ticket_num_frist_month                                
    ,nvl(b.dy_tik_ticket_num_second_month,0)                 dy_tik_ticket_num_second_month                               
    ,nvl(b.dy_tik_ticket_num_third_month,0)                  dy_tik_ticket_num_third_month                                
    ,nvl(b.dy_tik_gmv_frist_month,0)                         dy_tik_gmv_frist_month                                       
    ,nvl(b.dy_tik_gmv_second_month,0)                        dy_tik_gmv_second_month                                      
    ,nvl(b.dy_tik_gmv_third_month,0)                         dy_tik_gmv_third_month                                       
    ,nvl(b.dy_tik_order_num_frist_month,0)                   dy_tik_order_num_frist_month                                 
    ,nvl(b.dy_tik_order_num_second_month,0)                  dy_tik_order_num_second_month                                
    ,nvl(b.dy_tik_order_num_third_month,0)                   dy_tik_order_num_third_month                                 
    --阿里供销 --票量    --GMV   --订单量                                                     
    ,nvl(b.ali_ticket_num_frist_month,0)                     ali_ticket_num_frist_month                                   
    ,nvl(b.ali_ticket_num_second_month,0)                    ali_ticket_num_second_month                                  
    ,nvl(b.ali_ticket_num_third_month,0)                     ali_ticket_num_third_month                                   
    ,nvl(b.ali_gmv_frist_month,0)                            ali_gmv_frist_month                                          
    ,nvl(b.ali_gmv_second_month,0)                           ali_gmv_second_month                                         
    ,nvl(b.ali_gmv_third_month,0)                            ali_gmv_third_month                                          
    ,nvl(b.ali_order_num_frist_month,0)                      ali_order_num_frist_month                                    
    ,nvl(b.ali_order_num_second_month,0)                     ali_order_num_second_month                                   
    ,nvl(b.ali_order_num_third_month,0)                      ali_order_num_third_month                                    
    --团购导码 --票量    --GMV   --订单量                                                   
    ,nvl(b.group_purchase_code_ticket_num_frist_month,0)     group_purchase_code_ticket_num_frist_month                   
    ,nvl(b.group_purchase_code_ticket_num_second_month,0)    group_purchase_code_ticket_num_second_month                  
    ,nvl(b.group_purchase_code_ticket_num_third_month,0)     group_purchase_code_ticket_num_third_month                   
    ,nvl(b.group_purchase_code_gmv_frist_month,0)            group_purchase_code_gmv_frist_month                          
    ,nvl(b.group_purchase_code_gmv_second_month,0)           group_purchase_code_gmv_second_month                         
    ,nvl(b.group_purchase_code_gmv_third_month,0)            group_purchase_code_gmv_third_month                          
    ,nvl(b.group_purchase_code_order_num_frist_month,0)      group_purchase_code_order_num_frist_month                    
    ,nvl(b.group_purchase_code_order_num_second_month,0)     group_purchase_code_order_num_second_month                   
    ,nvl(b.group_purchase_code_order_num_third_month,0)      group_purchase_code_order_num_third_month                    
    --京津冀年卡 --票量    --GMV   --订单量                                                  
    ,nvl(b.jjy_year_ticket_num_frist_month,0)                jjy_year_ticket_num_frist_month                              
    ,nvl(b.jjy_year_ticket_num_second_month,0)               jjy_year_ticket_num_second_month                             
    ,nvl(b.jjy_year_ticket_num_third_month,0)                jjy_year_ticket_num_third_month                              
    ,nvl(b.jjy_year_gmv_frist_month,0)                       jjy_year_gmv_frist_month                                     
    ,nvl(b.jjy_year_gmv_second_month,0)                      jjy_year_gmv_second_month                                    
    ,nvl(b.jjy_year_gmv_third_month,0)                       jjy_year_gmv_third_month                                     
    ,nvl(b.jjy_year_order_num_frist_month,0)                 jjy_year_order_num_frist_month                               
    ,nvl(b.jjy_year_order_num_second_month,0)                jjy_year_order_num_second_month                              
    ,nvl(b.jjy_year_order_num_third_month,0)                 jjy_year_order_num_third_month                               
    --资源中心 --票量    --GMV   --订单量                                             
    ,nvl(b.resource_center_ticket_num_frist_month,0)         resource_center_ticket_num_frist_month                       
    ,nvl(b.resource_center_ticket_num_second_month,0)        resource_center_ticket_num_second_month                      
    ,nvl(b.resource_center_ticket_num_third_month,0)         resource_center_ticket_num_third_month                       
    ,nvl(b.resource_center_gmv_frist_month,0)                resource_center_gmv_frist_month                              
    ,nvl(b.resource_center_gmv_second_month,0)               resource_center_gmv_second_month                             
    ,nvl(b.resource_center_gmv_third_month,0)                resource_center_gmv_third_month                              
    ,nvl(b.resource_center_order_num_frist_month,0)          resource_center_order_num_frist_month                        
    ,nvl(b.resource_center_order_num_second_month,0)         resource_center_order_num_second_month                       
    ,nvl(b.resource_center_order_num_third_month,0)          resource_center_order_num_third_month                        
    --限时抢购 --票量    --GMV   --订单量                                                    
    ,nvl(b.limited_conversion_ticket_num_frist_month,0)      limited_conversion_ticket_num_frist_month                    
    ,nvl(b.limited_conversion_ticket_num_second_month,0)     limited_conversion_ticket_num_second_month                   
    ,nvl(b.limited_conversion_ticket_num_third_month,0)      limited_conversion_ticket_num_third_month                    
    ,nvl(b.limited_conversion_gmv_frist_month,0)             limited_conversion_gmv_frist_month                           
    ,nvl(b.limited_conversion_gmv_second_month,0)            limited_conversion_gmv_second_month                          
    ,nvl(b.limited_conversion_gmv_third_month,0)             limited_conversion_gmv_third_month                           
    ,nvl(b.limited_conversion_order_num_frist_month,0)       limited_conversion_order_num_frist_month                     
    ,nvl(b.limited_conversion_order_num_second_month,0)      limited_conversion_order_num_second_month                    
    ,nvl(b.limited_conversion_order_num_third_month,0)       limited_conversion_order_num_third_month                     
    --砍价 --票量    --GMV   --订单量                                                     
    ,nvl(b.kj_ticket_num_frist_month,0)                      kj_ticket_num_frist_month                                    
    ,nvl(b.kj_ticket_num_second_month,0)                     kj_ticket_num_second_month                                   
    ,nvl(b.kj_ticket_num_third_month,0)                      kj_ticket_num_third_month                                    
    ,nvl(b.kj_gmv_frist_month,0)                             kj_gmv_frist_month                                           
    ,nvl(b.kj_gmv_second_month,0)                            kj_gmv_second_month                                          
    ,nvl(b.kj_gmv_third_month,0)                             kj_gmv_third_month                                           
    ,nvl(b.kj_order_num_frist_month,0)                       kj_order_num_frist_month                                     
    ,nvl(b.kj_order_num_second_month,0)                      kj_order_num_second_month                                    
    ,nvl(b.kj_order_num_third_month,0)                       kj_order_num_third_month                                     
    --拼团 --票量    --GMV   --订单量                                                          
    ,nvl(b.pt_ticket_num_frist_month,0)                      pt_ticket_num_frist_month                                    
    ,nvl(b.pt_ticket_num_second_month,0)                     pt_ticket_num_second_month                                   
    ,nvl(b.pt_ticket_num_third_month,0)                      pt_ticket_num_third_month                                    
    ,nvl(b.pt_gmv_frist_month,0)                             pt_gmv_frist_month                                           
    ,nvl(b.pt_gmv_second_month,0)                            pt_gmv_second_month                                          
    ,nvl(b.pt_gmv_third_month,0)                             pt_gmv_third_month                                           
    ,nvl(b.pt_order_num_frist_month,0)                       pt_order_num_frist_month                                     
    ,nvl(b.pt_order_num_second_month,0)                      pt_order_num_second_month                                    
    ,nvl(b.pt_order_num_third_month,0)                       pt_order_num_third_month                                     
    --全民营销 --票量    --GMV   --订单量                                                 
    ,nvl(b.qmyx_ticket_num_frist_month,0)                    qmyx_ticket_num_frist_month                                  
    ,nvl(b.qmyx_ticket_num_second_month,0)                   qmyx_ticket_num_second_month                                 
    ,nvl(b.qmyx_ticket_num_third_month,0)                    qmyx_ticket_num_third_month                                  
    ,nvl(b.qmyx_gmv_frist_month,0)                           qmyx_gmv_frist_month                                         
    ,nvl(b.qmyx_gmv_second_month,0)                          qmyx_gmv_second_month                                        
    ,nvl(b.qmyx_gmv_third_month,0)                           qmyx_gmv_third_month                                         
    ,nvl(b.qmyx_order_num_frist_month,0)                     qmyx_order_num_frist_month                                   
    ,nvl(b.qmyx_order_num_second_month,0)                    qmyx_order_num_second_month                                  
    ,nvl(b.qmyx_order_num_third_month,0)                     qmyx_order_num_third_month                                   
    --优惠券 --票量    --GMV   --订单量                                                         
    ,nvl(b.yhq_ticket_num_frist_month,0)                     yhq_ticket_num_frist_month                                   
    ,nvl(b.yhq_ticket_num_second_month,0)                    yhq_ticket_num_second_month                                  
    ,nvl(b.yhq_ticket_num_third_month,0)                     yhq_ticket_num_third_month                                   
    ,nvl(b.yhq_gmv_frist_month,0)                            yhq_gmv_frist_month                                          
    ,nvl(b.yhq_gmv_second_month,0)                           yhq_gmv_second_month                                         
    ,nvl(b.yhq_gmv_third_month,0)                            yhq_gmv_third_month                                          
    ,nvl(b.yhq_order_num_frist_month,0)                      yhq_order_num_frist_month                                    
    ,nvl(b.yhq_order_num_second_month,0)                     yhq_order_num_second_month                                   
    ,nvl(b.yhq_order_num_third_month,0)                      yhq_order_num_third_month                                    
    --新媒体分销订单量 --票量    --GMV   --订单量                 
    ,nvl(b.new_media_ticket_num_frist_month,0)               new_media_ticket_num_frist_month                             
    ,nvl(b.new_media_ticket_num_second_month,0)              new_media_ticket_num_second_month                            
    ,nvl(b.new_media_ticket_num_third_month,0)               new_media_ticket_num_third_month                             
    ,nvl(b.new_media_gmv_frist_month,0)                      new_media_gmv_frist_month                                    
    ,nvl(b.new_media_gmv_second_month,0)                     new_media_gmv_second_month                                   
    ,nvl(b.new_media_gmv_third_month,0)                      new_media_gmv_third_month                                    
    ,nvl(b.new_media_order_num_frist_month,0)                new_media_order_num_frist_month                              
    ,nvl(b.new_media_order_num_second_month,0)               new_media_order_num_second_month                             
    ,nvl(b.new_media_order_num_third_month,0)                new_media_order_num_third_month                              
    --外部发码 --票量    --GMV   --订单量 
    ,nvl(b.external_code_ticket_num_frist_month,0)           external_code_ticket_num_frist_month                         
    ,nvl(b.external_code_ticket_num_second_month,0)          external_code_ticket_num_second_month                        
    ,nvl(b.external_code_ticket_num_third_month,0)           external_code_ticket_num_third_month                         
    ,nvl(b.external_code_gmv_frist_month,0)                  external_code_gmv_frist_month                                
    ,nvl(b.external_code_gmv_second_month,0)                 external_code_gmv_second_month                               
    ,nvl(b.external_code_gmv_third_month,0)                  external_code_gmv_third_month                                
    ,nvl(b.external_code_order_num_frist_month,0)            external_code_order_num_frist_month                          
    ,nvl(b.external_code_order_num_second_month,0)           external_code_order_num_second_month                         
    ,nvl(b.external_code_order_num_third_month,0)            external_code_order_num_third_month                          
    --园区一卡通 --票量    --GMV   --订单量             
    ,nvl(b.pft_park_card_ticket_num_frist_month,0)           pft_park_card_ticket_num_frist_month                         
    ,nvl(b.pft_park_card_ticket_num_second_month,0)          pft_park_card_ticket_num_second_month                        
    ,nvl(b.pft_park_card_ticket_num_third_month,0)           pft_park_card_ticket_num_third_month                         
    ,nvl(b.pft_park_card_gmv_frist_month,0)                  pft_park_card_gmv_frist_month                                
    ,nvl(b.pft_park_card_gmv_second_month,0)                 pft_park_card_gmv_second_month                               
    ,nvl(b.pft_park_card_gmv_third_month,0)                  pft_park_card_gmv_third_month                                
    ,nvl(b.pft_park_card_order_num_frist_month,0)            pft_park_card_order_num_frist_month                          
    ,nvl(b.pft_park_card_order_num_second_month,0)           pft_park_card_order_num_second_month                         
    ,nvl(b.pft_park_card_order_num_third_month,0)            pft_park_card_order_num_third_month                          
    --年卡 --票量    --GMV   --订单量  
    ,nvl(b.pft_annual_card_ticket_num_frist_month,0)         pft_annual_card_ticket_num_frist_month                       
    ,nvl(b.pft_annual_card_ticket_num_second_month,0)        pft_annual_card_ticket_num_second_month                      
    ,nvl(b.pft_annual_card_ticket_num_third_month,0)         pft_annual_card_ticket_num_third_month                       
    ,nvl(b.pft_annual_card_gmv_frist_month,0)                pft_annual_card_gmv_frist_month                              
    ,nvl(b.pft_annual_card_gmv_second_month,0)               pft_annual_card_gmv_second_month                             
    ,nvl(b.pft_annual_card_gmv_third_month,0)                pft_annual_card_gmv_third_month                              
    ,nvl(b.pft_annual_card_order_num_frist_month,0)          pft_annual_card_order_num_frist_month                        
    ,nvl(b.pft_annual_card_order_num_second_month,0)         pft_annual_card_order_num_second_month                       
    ,nvl(b.pft_annual_card_order_num_third_month,0)          pft_annual_card_order_num_third_month                        

    ,nvl(b.cloud_order_num_kh,0) as cloud_order_num_kh                     --云票务--考核维度考核维度订单量
    ,nvl(b.mall_order_num_kh,0) as mall_order_num_kh                       --微商城--考核维度订单量
    ,nvl(b.cdm_order_num_kh,0) as cdm_order_num_kh                         --自助机--考核维度订单量
    ,nvl(b.pc_order_num_kh,0) as pc_order_num_kh                           --PC商城--考核维度订单量
    ,nvl(b.agm_order_num_kh,0) as agm_order_num_kh                         --闸机--考核维度订单量
    ,nvl(b.smart_terminal_order_num_kh,0) as smart_terminal_order_num_kh   --智能终端--考核维度订单量
    ,nvl(b.tb_order_num_kh,0) as tb_order_num_kh                           --淘宝/飞猪--考核维度订单量
    ,nvl(b.year_card_order_num_kh,0) as year_card_order_num_kh             --年卡特权--考核维度订单量
    ,nvl(b.mall_plat_order_num_kh,0) as mall_plat_order_num_kh             --微平台--考核维度订单量
    ,nvl(b.ota_order_num_kh,0) as ota_order_num_kh                         --OTA--考核维度订单量
    ,nvl(b.pay_code_order_num_kh,0) as pay_code_order_num_kh               --兑换码购票--考核维度订单量
    ,nvl(b.one_card_order_num_kh,0) as one_card_order_num_kh               --一卡通--考核维度订单量
    ,nvl(b.subticket_order_num_kh,0) as subticket_order_num_kh             --套票子票--考核维度订单量
    ,nvl(b.group_order_num_kh,0) as group_order_num_kh                     --团队预定--考核维度订单量
    ,nvl(b.assorted_order_num_kh,0) as assorted_order_num_kh               --拼团--考核维度订单量
    ,nvl(b.integral_mall_order_num_kh,0) as integral_mall_order_num_kh     --积分商城--考核维度订单量
    ,nvl(b.pos_order_num_kh,0) as pos_order_num_kh                         --POS支付--考核维度订单量
    ,nvl(b.wx_wpf_order_num_kh,0) as wx_wpf_order_num_kh                   --微信-微票房--考核维度订单量
    ,nvl(b.adj_group_order_num_kh,0) as adj_group_order_num_kh             --报团计调下单--考核维度订单量
    ,nvl(b.desk_cloud_order_num_kh,0) as desk_cloud_order_num_kh           --桌面云票务--考核维度订单量
    ,nvl(b.app_order_num_kh,0) as app_order_num_kh                         --APP--考核维度订单量
    ,nvl(b.special_order_num_kh,0) as special_order_num_kh                 --特殊团队预约--考核维度订单量
    ,nvl(b.wx_app_order_num_kh,0) as wx_app_order_num_kh                   --微信小程序--考核维度订单量
    ,nvl(b.dy_tik_order_num_kh,0) as dy_tik_order_num_kh                   --抖音-微票房--考核维度订单量
    ,nvl(b.group_purchase_code_order_num_kh,0) as group_purchase_code_order_num_kh--团购导码--考核维度订单量
    ,nvl(b.resource_center_order_num_kh,0) as resource_center_order_num_kh --资源中心--考核维度订单量
    ,nvl(b.limited_conversion_order_num_kh,0) as limited_conversion_order_num_kh--限时抢购--考核维度订单量
    ,nvl(b.kj_order_num_kh,0) as kj_order_num_kh                           --砍价--考核维度订单量
    ,nvl(b.pt_order_num_kh,0) as pt_order_num_kh                           --拼团--考核维度订单量
    ,nvl(b.qmyx_order_num_kh,0) as qmyx_order_num_kh                       --全民营销--考核维度订单量
    ,nvl(b.yhq_order_num_kh,0) as yhq_order_num_kh                         --优惠券--考核维度订单量
    ,nvl(b.new_media_order_num_kh,0) as new_media_order_num_kh--新媒体分销考核维度订单量--考核维度订单量--购买者或销售者ID为:（12404122抖音团购,0),12513404快手,0),13913690抖店,0),15467659快手电商开放平台）
    ,nvl(b.external_code_order_num_kh,0) as external_code_order_num_kh     --外部发码--考核维度订单量
    ,nvl(b.pft_park_card_order_num_kh,0) as pft_park_card_order_num_kh     --园区一卡通--考核维度订单量
    ,nvl(b.pft_annual_card_order_num_kh,0) as pft_annual_card_order_num_kh --年卡--考核维度订单量

    ,nvl(b.ticket_num_hz,0) as ticket_num_hz
    ,nvl(gmv_hz,0) as gmv_hz
    ,nvl(order_num_hz,0) as order_num_hz
    ,a.user_regist_time  --注册时间
    ,nvl(c.fcount_kh,0) as pft_land_prod_num_kh   --前三个月产品种数考核
    ,nvl(d.fcount_kh,0) as pft_wlzx_scan_num_kh   --前三个月物料中心扫码次数考核
    ,nvl(b.pft_storage_section_num_kh,0) as pft_storage_section_num_kh --前三个月分时预约次数考核
    ,nvl(e.num,0) as pft_marking_sms_num_kh        --营销类短信条数   前3个月
    ,nvl(f.num,0) as pft_sms_sign_apply_num_kh     --短信抬头自定义(前3个月)  完成短信抬头修改并应用
    ,nvl(g.num,0) as pft_sms_diy_apply_num_kh      --短信模板自定义(前3个月)  完成短信模板修改并应用
    ,a.spare_field11                    --产品开通类型列表
    ,a.onsale_ticket_num_self           --在售自供应产品票种数,不包含删除
    ,a.login_num_plat_last_month        --上月登录平台次数
    ,a.spare_field12                    --近60天登录平台次数
    ,a.spare_field13                    --近60天登录终端次数
    ,a.spare_field14                    --近60天登录平台天数
    ,a.spare_field15                    --近60天登录终端天数
    ,a.spare_field16                    --合作内容
    ,a.user_next_package_begin_date     --用户下个套餐开始日期
    ,a.user_next_package_end_date       --用户下个套餐结束日期
    ,a.spare_field19                    --合作客户等级关联crm
    ,is_open_btglgysb                   --报团管理（供应商版）
    ,is_open_btglfxsb                   --报团管理（分销商版）
    ,is_open_fsyy  						--分时预约
from dim_cus_company_d_f a

left join cache_user_ticket_gmv_order b 
    on a.user_id=b.user_id


left join 
    (--前三个月产品类型个数（去重）
     select apply_did, count(distinct p_type) as fcount_kh 
     from (select apply_did,
                p_type,
                substr(passtime,1,7) as passtime,  --审核通过时间
                dense_rank() over(partition by apply_did order by substr(passtime,1,7)) as pm 
           from ods_uu_land_d_f     --data_middle_bi.s_uu_land_d_f 
           where pt = ${ds}   
           and nvl(passtime,'')<>''
          )m 
     where pm <=3 
     group by apply_did
    ) c 
    on a.user_id=c.apply_did



left join 
    (--物料中心（扫码次数）
     select sid, sum(count_num) as fcount_kh 
     from (select sid,
                count_num,
                substr(from_unixtime(create_time,'yyyy-MM-dd'),1,7) as create_time,  --创建时间
                dense_rank() over(partition by sid order by substr(from_unixtime(create_time,'yyyy-MM-dd'),1,7)) as pm 
           from  ods_cus_pft_material_center_d_f     --it_project.ods_cus_pft_material_center_d_f
           where pt = ${ds} 
           and nvl(from_unixtime(create_time,'yyyy-MM-dd'),'')<>''
          ) m 
     where pm <=3 
     group by sid
    ) d 
    on a.user_id=d.sid



left join 
    (----营销类短信条数   前3个月至少单次大于10条短信发送成功的
     select uid, count(*) as num 
     from (select uid
                ,substr(from_unixtime(send_time,'yyyy-MM-dd'),1,7)  as send_time
                ,dense_rank() over(partition by uid order by substr(from_unixtime(send_time,'yyyy-MM-dd'),1,7) ) as pm
           from ods_cus_pft_marketing_sms_task_d_f    --it_project.ods_cus_pft_marketing_sms_task_d_f
           where pt = ${ds}  and state=3 -- 发送完成状态
          ) a 
     where pm<=3
     group by uid
    ) e
    on a.user_id=e.uid



left join 
    (--短信抬头自定义(前3个月)  完成短信抬头修改并应用
     select member_id, count(*) as num 
     from (select member_id,
                substr(from_unixtime(create_time,'yyyy-MM-dd'),1,7) as create_time,
                dense_rank() over(partition by member_id order by substr(from_unixtime(create_time,'yyyy-MM-dd'),1,7) ) as pm
           from ods_cus_pft_sms_sign_apply_d_f    --it_project.ods_cus_pft_sms_sign_apply_d_f
           where pt = ${ds}
           and state=2 --审批通过状态
          )a
     where pm<=3
     group by member_id
    ) f
    on a.user_id=f.member_id



left join 
    (--短信模板自定义(前3个月)  完成短信模板修改并应用
     select member_id, count(*) as num 
     from (select member_id,
                substr(from_unixtime(create_time,'yyyy-MM-dd'),1,7) as create_time,
                dense_rank() over(partition by member_id order by substr(from_unixtime(create_time,'yyyy-MM-dd'),1,7) ) as pm
           from ods_cus_pft_sms_diy_apply_d_f     --it_project.ods_cus_pft_sms_diy_apply_d_f
           where pt= ${ds}
           and state=2 --审批通过状态
          )a
     where pm<=3
     group by member_id
    ) g
    on a.user_id=g.member_id

where a.pt = ${ds}   AND  a.user_type in ('供应商','分销商') and a.user_is_test='正式' ;







