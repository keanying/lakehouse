--EMR Spark SQL
--********************************************************************--
--author: 施建伟
--create time: 2026-03-27 16:04:40
--EMR任务只能运行在独享资源组上
--商户合作伙伴
--********************************************************************--




create table if NOT EXISTS dws_cus_company_partner_d_f(
    stat_date                       STRING COMMENT"统计日期",
    dw_ins_time                     STRING COMMENT"数据插入日期",
    
    user_id                         INT    COMMENT"用户id",
    
    first_add_time                  string comment "首次添加分销商时间",
    end_edit_time                   string comment "最后修改时间",

    partner_num_ota                 STRING COMMENT"ota数量",
    partner_num_dist                STRING COMMENT"分销商数",
    partner_num_staff               STRING COMMENT"员工数",
    partner_num_supp                STRING COMMENT"供应商数",

    partner_num_ticket_system       string comment"线下票务系统数",
    ticket_system_list              string comment"线下票务系统列表"
 
 )COMMENT'商户合作伙伴情况'PARTITIONED BY(
    pt INT
 )STORED AS ORC;





SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;


INSERT OVERWRITE TABLE dws_cus_company_partner_d_f  PARTITION(pt= ${ds})
select
    ${ds}       as stat_date,
    current_date                as dw_ins_time,

    r2.parent_id                             as user_id,
    r2.first_add_time                        as first_add_time,
    r2.end_edit_time                         as end_edit_time,

    r2.partner_num_ota                       as partner_num_ota,
    r2.partner_num_dist                      as partner_num_dist,
    r2.partner_num_staff                     as partner_num_staff,
    r1.partner_num_supp                      as partner_num_supp,           

    third.num                                as partner_num_ticket_system,           
    third.system_list                        as ticket_system_list           

from (SELECT parent_id,
             count( distinct if(son_type='OTA' and relationship_type=0,son_id,null))       as  partner_num_ota,
             count( distinct if(son_type='分销商' AND  relationship_type=0,son_id,null))    as  partner_num_dist,
             count( distinct if(son_type='员工' and relationship_type=1,son_id,null))       as  partner_num_staff,

             min(add_time)                      as  first_add_time,
             max(cut_time)                      as  end_edit_time
      from dim_user_relationship_d_f    --data_middle_bi.dim_user_relationship_d_f
      where pt= ${ds} and status=0
      group by parent_id
    ) as r2

left join
    (SELECT son_id,count(*) partner_num_supp
     from dim_user_relationship_d_f    --data_middle_bi.dim_user_relationship_d_f
     where pt= ${ds} and relationship_type=0
     group by son_id
    ) r1
    on r1.son_id=r2.parent_id

left join
    (select user_id,count(distinct thirdsystem_id) num,cast(collect_set(thirdsystem_name) as string) system_list
     from dim_user_thirdsystem_d_f     --data_middle_bi.dim_user_thirdsystem_d_f 
     where pt= ${ds}
     group by user_id
    ) third
    on third.user_id=r2.parent_id






















