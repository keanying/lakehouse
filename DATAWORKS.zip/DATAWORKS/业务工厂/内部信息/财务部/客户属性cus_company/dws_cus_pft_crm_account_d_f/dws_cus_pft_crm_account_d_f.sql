--EMR Spark SQL
--********************************************************************--
--author: 施建伟
--create time: 2026-04-01 15:16:47
--EMR任务只能运行在独享资源组上
--crm客户表
--********************************************************************--



CREATE table if not EXISTS dws_cus_pft_crm_account_d_f(
    platform_id 				string comment '纷享平台id'
    ,account_no 				string comment '客户编号'
    ,name 						string comment '客户名称'
    ,customer_attributes    	string comment '客户属性'
    ,customer_type  			string comment '客户类型'
    ,customer_level  			string comment '客户分类'
    ,customer_status			string comment '状态（原）'
    ,life_status				string comment '生命状态'
    ,ht_num						string comment '合作次数'
    ,order_amount				string comment '合作总额'
    ,field_0w21l__c				string comment '平台账号/ID/手机'
    ,country_id					string comment '国家编号'
    ,country_name				string comment '国家名称'
    ,province_id				string comment '省份编号'
    ,province_name				string comment '省份名称'
    ,city_id					string comment '市编码'
    ,city_name					string comment '市名称'
    ,area_id 					string comment '区编码'
    ,area_name					string comment '区名称'
    ,address					string comment '详细地址'
    ,tel						string comment '电话'
    ,phone_country_id			string comment '电话归属国家编码'
    ,phone_country_name			string comment '电话归属国家名称'
    ,phone_province_id			string comment '电话归属省份'
    ,phone_province_name		string comment '电话归属省份名称'
    ,phone_city_id				string comment '电话归属市编码'
    ,phone_city_name			string comment '电话归属市名称'
    ,phone_address				string comment '电话归属详细地址'
    ,phone_area					string comment '电话归属区'
    ,phone_belong_place			string comment '电话归属地'
    ,cooperative_properties		string comment '合作属性'
    ,partner_type				string comment '合作伙伴类型'
    ,partners_name				string comment '合作伙伴名称'
    ,main_categories			string comment '主营类目'
    ,scenic_level				string comment '景区等级'
    ,scenic_type				string comment '景区业态'
    ,key_world  				string comment '景区关键词'
    ,field_k678b__c				string comment '景区是否收费' 
    ,travelagency_type			string comment '旅行社类型'
    ,travelagency_group			string comment '旅行社客群'
    ,deal_status				string comment '成交状态'    
    ,last_deal_closed_time		string comment '最后一次成交时间'    
    ,field_tkx02__c				string comment '首签成单日期'
    ,biz_status					string comment '分配状态'
    ,online_compete_cooperate	string comment '线上合作竞品'    
    ,offline_compete_cooperate	string comment '线下合作竞品'
    ,reason_compete_cooperate	string comment '与竞品合作原因'
    ,back_reason				string comment '销售人员退回原因'
    ,field_tdfig__c				string comment '最近跟进内容'
    ,last_follower				string comment '最后跟进人'
    ,last_followed_time			string comment '最后跟进时间'
    ,is_er_enterprise			string comment '是否关联对接企业'
    ,field_r1qr3__c__r			string comment '客户转移人'
    ,field_Z4La2__c				string comment '客户转移时间'    
    ,is_deleted 				string comment '是否删除'
    ,owner__r  					string comment '负责人'
    ,owner_department 			string comment '负责人主属部门'
    ,owner_modified_time		string comment '负责人变更时间'
    ,field_r13cs__c				string comment '历史负责人'
    ,field_R6i8i__c 			string comment '历史负责人'
    ,out_owner					string comment '外部负责人'
    ,created_by__l				string comment '创建人'
    ,create_time				string comment '创建时间'
    ,field_1oLsM__c				string comment '历史创建人'
    ,field_jgcP2__c				string comment '历史创建时间'
    ,relevant_team__r			string comment '相关团队'
    ,data_own_department		string comment '归属部门'
    ,remark						string comment '备注'
    ,leads_id					string comment '源线索id'
    ,leads_id__r				string comment '源线索'
    ,recycled_reason			string comment '退回/收回原因'
    ,returned_time				string comment '退回/收回时间'
    ,last_modified_by__r		string comment '最后修改人'    
    ,last_modified_time			string comment '最后修改时间'
    ,record_type   				string comment '业务类型'
    ,customer_from_source  		string comment '客户来源'
    ,hospitality_relation		string comment '客情关系'
    ,spare_field1		        string COMMENT '预留字段1'
    ,spare_field2		        string COMMENT '预留字段2'
    ,spare_field3		        string COMMENT '预留字段3'
    ,spare_field4		        string COMMENT '预留字段4'   
    ,spare_field5		        string COMMENT '预留字段5'   -- CUB客户分类   
    ,spare_field6		        string COMMENT '预留字段6'
    ,deptId                     string comment 'crm部门id'      
    ,field_w5GSd__c             string comment '景区客户分层数据'
    ,field_i4oZj__c             string comment '合作客户分层数据'


)COMMENT "crm客户表"    
PARTITIONED BY(
    pt int
 )STORED AS ORC;









SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;



INSERT OVERWRITE table dws_cus_pft_crm_account_d_f PARTITION (pt= ${ds})
select platform_id                            -- 纷享平台id
    ,account_no                               -- 客户编号
    ,name                                     -- 客户名称
    ,customer_attributes                      -- 客户属性
    ,customer_type                            -- 客户类型
    ,customer_level                           -- 客户分类
    ,customer_status                          -- 状态（原）
    ,life_status                              -- 生命状态
    ,ht_num                                   -- 合作次数
    ,order_amount                             -- 合作总额
    ,field_0w21l__c                           -- 平台账号/ID/手机
    ,country_id                               -- 国家编号
    ,country_name                             -- 国家名称
    ,province_id                              -- 省份编号
    ,province_name                            -- 省份名称
    ,city_id                                  -- 市编码
    ,city_name                                -- 市名称
    ,area_id                                  -- 区编码
    ,area_name                                -- 区名称
    ,address                                  -- 详细地址
    ,tel                                      -- 电话
    ,phone_country_id                         -- 电话归属国家编码
    ,phone_country_name                       -- 电话归属国家名称
    ,phone_province_id                        -- 电话归属省份
    ,phone_province_name                      -- 电话归属省份名称
    ,phone_city_id                            -- 电话归属市编码
    ,phone_city_name                          -- 电话归属市名称
    ,phone_address                            -- 电话归属详细地址
    ,phone_area                               -- 电话归属区
    ,phone_belong_place                       -- 电话归属地
    ,cooperative_properties                   -- 合作属性
    ,partner_type                             -- 合作伙伴类型
    ,partners_name                            -- 合作伙伴名称
    ,main_categories                          -- 主营类目
    ,scenic_level                             -- 景区等级
    ,scenic_type                              -- 景区业态
    ,key_world                                -- 景区关键词
    ,field_k678b__c                           -- 景区是否收费    
    ,travelagency_type                        -- 旅行社类型
    ,travelagency_group                       -- 旅行社客群
    ,deal_status                              -- 成交状态    
    ,last_deal_closed_time                    -- 最后一次成交时间    
    ,field_tkx02__c                           -- 首签成单日期
    ,biz_status                               -- 分配状态
    ,online_compete_cooperate                 -- 线上合作竞品    
    ,offline_compete_cooperate                -- 线下合作竞品
    ,reason_compete_cooperate                 -- 与竞品合作原因
    ,back_reason                              -- 销售人员退回原因
    ,'' field_tdfig__c                        -- 最近跟进内容（经常出现特殊符号错误，这里先置空）
    ,last_follower                            -- 最后跟进人
    ,last_followed_time                       -- 最后跟进时间
    ,is_er_enterprise                         -- 是否关联对接企业
    ,field_r1qr3__c__r                        -- 客户转移人
    ,field_Z4La2__c                           -- 客户转移时间    
    ,is_deleted                               -- 是否删除
    ,owner__r                                 -- 负责人
    ,owner_department                         -- 负责人主属部门
    ,owner_modified_time                      -- 负责人变更时间
    ,field_r13cs__c                           -- 历史负责人
    ,field_R6i8i__c                           -- 历史负责人
    ,out_owner                                -- 外部负责人
    ,created_by__l                            -- 创建人
    ,create_time                              -- 创建时间
    ,field_1oLsM__c                           -- 历史创建人
    ,field_jgcP2__c                           -- 历史创建时间
    ,relevant_team__r                         -- 相关团队
    ,data_own_department                      -- 归属部门
    ,remark                                   -- 备注
    ,leads_id                                 -- 源线索id
    ,leads_id__r                              -- 源线索
    ,recycled_reason                          -- 退回/收回原因
    ,returned_time                            -- 退回/收回时间
    ,last_modified_by__r                      -- 最后修改人    
    ,last_modified_time                       -- 最后修改时间
    ,record_type                              -- 业务类型
    ,customer_from_source                     -- 客户来源
    ,hospitality_relation                     -- 客情关系
    ,spare_field1                             -- 新老客
    ,spare_field2
    ,spare_field3   
    ,spare_field4                             -- 区域 
    ,case when customer_type like '%景区%' and  sfxm_mark='平台客户' then '景区SaaSCBU'   -- 业态是博物馆的都属于博物馆CBU
          else 
                case when (customer_type like '%景区%' and scenic_level = '5A')  -- 5A级景区
                            or customer_type like '%集团%' 
                            or customer_type like '%政府%'
                            or platform_id in ('619506be24ca2a000160d9b4','63f483fbfacf57000128a6a3','644a38713f7ab80001b5ef6e')   -- 加上婺源的(因为系统上婺源标记为第三方这里特殊处理)
                            then concat(substr(spare_field4,1,2),'CBU') -- '大客CBU'    -- 大客整到各个U里面了   -- 20240709
                    else 
                            case when customer_type like '%景区%'
                                or customer_type like '%集成商%'
                                or customer_type like '%第三方%'
                            then concat(substr(spare_field4,1,2),'CBU')
                                else 
                                    case when customer_type like '%旅行社%'
                                        or customer_type like '%个人%'
                                        or customer_type like '%票务%'
                                    then '渠道CBU'    -- '渠道生态CBU'
                                    end 
                            end 
                    end 
     end 

     as spare_field5                             -- CUB客户分类
    ,spare_field6
    ,deptId                                   -- crm部门id   
    ,field_w5GSd__c                           -- 景区客户分层数据
    ,field_i4oZj__c                           --  合作客户分层数据

from (



    select t1.platform_id     -- 纷享平台id
        ,t1.account_no    -- 客户编号
        ,t1.name            -- 客户名称
        ,case when t1.field_41liw__c=1 then '潜在客户' when t1.field_41liw__c=2 then '意向客户'   
            when t1.field_41liw__c=3 then '成交客户' when t1.field_41liw__c=4 then '丢失客户'   
            when t1.field_41liw__c=5 then '无效客户' when t1.field_41liw__c='other' then '其他'   
        end as customer_attributes                                    -- 客户属性
        
        ,case when t1.account_level=1 then '景区' when t1.account_level=2 then '旅行社'
            when t1.account_level=3 then '政府' when t1.account_level=13 then '旅游集团'
            when t1.account_level=12 then '第三方' when t1.account_level=9 then '玩乐（本地生活）'
            when t1.account_level=4 then '文旅集团' when t1.account_level=5 then '票务公司'
            when t1.account_level=6 then '个人' when t1.account_level=7 then 'OTA'
            when t1.account_level=11 then '集成商' when t1.account_level=10 then '合作伙伴'
            when t1.account_level=8 then '区域平台' when t1.account_level='other' then concat('其他: ',account_level__o)
        end as customer_type  -- 客户类型

        ,case when t1.account_type=1 then 'A' when t1.account_type=2 then 'B' when t1.account_type=3 then 'C' when t1.account_type=4 then 'D' end as customer_level  -- 客户分类
        ,case when t1.account_status=1 then '报备中' when t1.account_status=2 then '未分配' when t1.account_status=3 then '已分配' 
            when t1.account_status=4 then '未生效' when t1.account_status=5 then '变更中' when t1.account_status=99 then '已作废' 
        end as customer_status   -- 状态（原）
        ,case when t1.life_status='ineffective' then '未生效' when t1.life_status='under_review' then '审核中'
            when t1.life_status='normal' then '正常' when t1.life_status='in_change' then '变更中'
            when t1.life_status='invalid' then '作废'
        end as life_status   -- 生命状态

        ,t2.ht_num                                                      --合作次数
        ,t2.order_amount                                                --合作总额
        ,t1.field_0w21l__c                                              -- 平台账号/ID/手机
        ,t1.country as country_id                                       -- 国家编号
        ,t1.country__r as country_name                                  -- 国家名称
        ,t1.province as province_id                                     -- 省份编号
        ,t1.province__r as province_name                                -- 省份名称
        ,t1.city as city_id                                             -- 市编码
        ,t1.city__r as city_name                                        -- 市名称
        ,t1.district as area_id                                         -- 区编码
        ,t1.district__r as area_name                                    -- 区名称
        ,t1.address                                                     -- 详细地址
        ,t1.tel                                                         -- 电话
        ,t1.phone_number_attribution_country as phone_country_id        -- 电话归属国家编码
        ,t1.phone_number_attribution_country__r as phone_country_name   -- 电话归属国家名称
        ,t1.phone_number_attribution_province as phone_province_id      -- 电话归属省份
        ,t1.phone_number_attribution_province__r as phone_province_name -- 电话归属省份名称
        ,t1.phone_number_attribution_city as phone_city_id              -- 电话归属市编码
        ,t1.phone_number_attribution_city__r as phone_city_name         -- 电话归属市名称
        ,t1.phone_number_attribution_address as phone_address           -- 电话归属详细地址
        ,t1.phone_number_attribution_district as phone_area             -- 电话归属区
        ,t1.phone_number_attribution as phone_belong_place              -- 电话归属地
        
        ,case t1.field_mvq72__c when 1 then '已合作' when 2 then '旅资已合作' when 'other' then '其他' end as cooperative_properties      -- 合作属性
        ,case t1.field_SOJx2__c when 1 then 'OTA' when 2 then '银行' when 3 then '运营商' when 4 then '票务公司' when 5 then '集成商' when 6 then '代理商' when 'other' then '其他' end as partner_type   -- 合作伙伴类型
        ,case t1.field_5EhT1__c when 1 then '美团' when 2 then '携程' when 3 then '飞猪' when 4 then '驴妈妈' when 5 then '同程' 
            when 6 then '中国联通' when 7 then '中国电信' when 8 then '中国移动' when 'other' then '其他' 
        end as partners_name  -- 合作伙伴名称

        ,regexp_replace( regexp_replace( regexp_replace( regexp_replace( regexp_replace( regexp_replace( regexp_replace(t1.field_nz4yo__c,'1','票务') ,'2','线路') ,'3','周边游') ,'4','酒店') ,'5','特产') ,'6','境外游') ,'other','其他') as main_categories  -- 主营类目

        ,case t1.field_0ut89__c when 1 then 'A' when 2 then '2A' when 3 then '3A' when 4 then '4A' when 5 then '5A' when 'other' then '其他' end as scenic_level   -- 景区等级
        ,case when t1.field_4h84y__c=1 then '山水人文' when t1.field_4h84y__c=2 then '主题乐园' 
            when t1.field_4h84y__c=3 then '水世界' when t1.field_4h84y__c='Q3owuL25D' then '漂流'
            when t1.field_4h84y__c=4 then '温泉养生' when t1.field_4h84y__c=5 then '古城古镇' 
            when t1.field_4h84y__c=6 then '滑雪场/滑草场' when t1.field_4h84y__c=7 then '综合旅游度假区' 
            when t1.field_4h84y__c=8 then '会展场馆（短期）' when t1.field_4h84y__c=9 then '博物馆' 
            when t1.field_4h84y__c='O1M3OtrN4' then '科技馆' when t1.field_4h84y__c=10 then '动植物园' 
            when t1.field_4h84y__c='8nWX2Ed0z' then '海洋馆' when t1.field_4h84y__c=11 then '剧场演出' 
            when t1.field_4h84y__c='12l77ox64' then '游轮/轮船' when t1.field_4h84y__c='other' then '其他' 
        end as scenic_type   -- 景区业态
        ,t1.key_world                                                   -- 景区关键词
        ,t1.field_k678b__c                                              -- 景区是否收费    

        ,case when t1.field_5q3iq__c=1 then '头部旅行社' when t1.field_5q3iq__c=2 then '中部旅行社' when t1.field_5q3iq__c=3 then '尾部旅行社' when t1.field_5q3iq__c='other' then '其他' end as travelagency_type  -- 旅行社类型
        ,case when t1.field_pqss9__c='cthJzOfKx' then '同业'
            when t1.field_pqss9__c='19shHwah9' then '直客'
            when t1.field_pqss9__c='9lr4h2pn6' then '同业+直客'
            when t1.field_pqss9__c='other' then '其他'
        end as travelagency_group                                     -- 旅行社客群
        ,case when t1.deal_status=1 then '未成交' when t1.deal_status=2 then '已成交' when t1.deal_status=3 then '多次成交' end as deal_status -- 成交状态    
        ,t1.last_deal_closed_time   -- 最后一次成交时间    
        ,t1.field_tkx02__c   -- 首签成单日期
        ,case when t1.biz_status='unallocated' then '未分配' when t1.biz_status='allocated' then '已分配' end as biz_status  -- 分配状态
        
        ,regexp_replace( regexp_replace( regexp_replace( regexp_replace( regexp_replace(
            regexp_replace( regexp_replace( regexp_replace( regexp_replace( regexp_replace(
                regexp_replace( regexp_replace( regexp_replace(t1.field_t72i6__c,'option1','无') ,'6n2AavQ08','票付通') ,'xw37myp1S','天时同城')
                ,'g7xRrAc25','自我游') ,'f1nTMa6H1','智游宝') ,'9m3t2r13K','信天游') ,'q82PSl86G','畅游通') ,'yylV1DA3Y','有赞')
            ,'RzixSpo8D','微盟') ,'e1a4MSYjq','蚂蚁供销（微天下）') ,'Vt41sxka1','票在旅途') ,'Ygo4Oy2bj','集客宝') ,'other','其他')
        as online_compete_cooperate     -- 线上合作竞品    
        ,case when t1.field_3o2h7__c='option1' then '无' when t1.field_3o2h7__c='aQCbB6G4E' then '票付通'   
            when t1.field_3o2h7__c='1' then '深大' when t1.field_3o2h7__c='9WmburNW2' then '九天达'  
            when t1.field_3o2h7__c='iGY12Wfnf' then '深圳鼎游' when t1.field_3o2h7__c='cQv2Tlb62' then '银科环企'  
            when t1.field_3o2h7__c='cDfm2OJhv' then '上海大漠' when t1.field_3o2h7__c='0Jt2d357l' then '华夏票联'  
            when t1.field_3o2h7__c='vdFfz91fb' then '捷信达' when t1.field_3o2h7__c='e4if2vLO1' then '上海邮科院'  
            when t1.field_3o2h7__c='09Clxztvf' then '油菜花' when t1.field_3o2h7__c='i2bp5t3R7' then '去买票'  
            when t1.field_3o2h7__c='eeW56wi0s' then '启明芯'  when t1.field_3o2h7__c='9atIt44l7' then '金飞鹰'  
            when t1.field_3o2h7__c='other' then '其他'  
        end as offline_compete_cooperate                              -- 线下合作竞品
        ,regexp_replace( regexp_replace(  regexp_replace( 
            regexp_replace( regexp_replace( regexp_replace(t1.field_f2192__c,'option1','无') ,'s9u17n2Il','价格') ,'X118i1pE1','功能' ) 
            ,'7VwCtw10g','品牌案例') ,'gZnp0tq5a','切入时间' ) ,'other','其他') 
        as reason_compete_cooperate                                  -- 与竞品合作原因

        ,case when t1.back_reason=0 then '联系不上客户' when t1.back_reason=1 then '客户暂无需求' 
            when t1.back_reason=2 then '未满足客户需求' when t1.back_reason='other' then '其他' 
        end as back_reason                                            -- 销售人员退回原因
        ,t1.field_tdfig__c                                              -- 最近跟进内容
        ,t1.last_follower   -- 最后跟进人
        ,t1.last_followed_time   -- 最后跟进时间
        
        ,t1.is_er_enterprise   -- 是否关联对接企业
        ,t1.field_r1qr3__c__r   -- 客户转移人
        ,t1.field_Z4La2__c   -- 客户转移时间    

        ,t1.is_deleted   -- 是否删除

        ,t1.owner__r   -- 负责人
        ,t1.owner_department   -- 负责人主属部门
        ,t1.owner_modified_time   -- 负责人变更时间
        ,t1.field_r13cs__c   -- 历史负责人
        ,t1.field_R6i8i__c   -- 历史负责人
        ,t1.out_owner   -- 外部负责人
        ,t1.created_by__l   -- 创建人
        ,t1.create_time   -- 创建时间
        ,t1.field_1oLsM__c   -- 历史创建人
        ,t1.field_jgcP2__c   -- 历史创建时间
        
        ,t1.relevant_team__r   -- 相关团队
        ,t1.data_own_department   -- 归属部门

        ,t1.remark   -- 备注
        ,t1.leads_id   -- 源线索id
        ,t1.leads_id__r   -- 源线索
        ,t1.recycled_reason   -- 退回/收回原因
        ,t1.returned_time   -- 退回/收回时间
        ,t1.last_modified_by__r   -- 最后修改人    
        ,t1.last_modified_time   -- 最后修改时间
        ,case when t1.record_type='default__c' then '预设业务类型' end as record_type   -- 业务类型

        ,case t1.account_source when 1 then '业务自拓' when 2 then '外部介绍来源' when 3 then '内部介绍来源' when 4 then '活动来源' when 5 then '官网百度表单' when 6 then '公众号来源' 
            when 7 then '大数据库来源' when 8 then '社群运营来源' when 9 then '流失客户来源' when 10 then '400来源' when 11 then '广告来源（百度、360、搜狗等）' when '8Nd9hbUpW' then '品牌活动来源'
            when 't8b93pbkJ' then '品牌异业资源' when '8uQrtHN1S' then '生态战略' when 'Roq5xYu9y' then 'SDR自拓' when 'enterprise_wechat' then '企业微信' when 'other' then '其他来源' 
        end as customer_from_source     -- 客户来源

        ,case t1.field_X3542__c when 'D0Y3h8wcg' then 'R' when 'moh1Fpe0J' then 'D' when 'vhy2VcbXb' then 'A' when 'k824fcWQK' then 'P' when 'other' then '其他' end as hospitality_relation     -- 客情关系
        ,case when ifnull(t2.he_xlk_mark,0)=1 then '新客' 
            when ifnull(t2.he_xlk_mark,0)>1 then '老客' 
            --when ifnull(t2.ht_num,0)>0 and ifnull(t2.he_xlk_mark,0)=0 THEN '试用客户'   --有签合同，但没有一次是付费的合同
            else '未合作' 
            end  as spare_field1   --新老客
        ,ifnull(last_order_time,'') as spare_field2
        ,ifnull(lost_day,'') as spare_field3
        ,t3.home_area_group  as spare_field4    -- 区域
        ,'' as spare_field5
        ,case when ifnull(t4.account_id,'') ='' then '平台客户' else '项目客户' end as spare_field6
        ,t1.deptId -- string  comment 'crm部门id'      
        ,t1.field_w5GSd__c -- string  comment '景区客户分层数据'
        ,t1.field_i4oZj__c   --  string  comment '合作客户分层数据'
        ,case when ifnull(t4.account_id,'') ='' then '平台客户' else '项目客户' end as sfxm_mark  -- 是否项目标识
    from ods_cus_pft_crm_account t1      --it_project.ods_cus_pft_crm_account t1

    left join
        (select account_id
            ,count(*) as ht_num --合同数
            ,sum(nvl(order_amount,0)) as order_amount  --签约金额
            ,sum(case when order_amount>0 then 1 else 0 end)  as he_xlk_mark --新老客标识    付费合同次数   :付费1次的算新客，大于1次的算老客
            ,max(  case when order_amount>0 then field_pgsdj__c else '' end   ) as last_order_time     --最后一次付费合同到期时间
            ,datediff(current_date(),max(  case when order_amount>0 then field_pgsdj__c else '' end   ))  as lost_day --付费流失天数  天数  负数是还有这么多天流失 
        from ods_con_pft_crm_sales_order    --it_project.ods_con_pft_crm_sales_order 
        where pt= ${ds}
        and life_status='normal' and order_status in (5,3)
        group by account_id
        ) t2
        on t1.platform_id=t2.account_id

    left join dim_crm_home_area_d_f t3      --it_project.dim_crm_home_area_d_f t3
        on t1.province__r = t3.home_area_desc
        and t3.pt= ${ds} 

    left join
        (select account_id
        from ods_con_pft_crm_sales_order    --it_project.ods_con_pft_crm_sales_order 
        where pt= ${ds}
        and life_status='normal' and order_status in (5,3) and record_type = 'record_u1Wpq__c'  -- 项目合同
        group by account_id  
        ) t4
        on t1.platform_id=t4.account_id


    where t1.pt= ${ds}

)k


;





