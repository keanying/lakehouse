--EMR Spark SQL
--********************************************************************--
--author: 施建伟
--create time: 2026-04-03 14:44:12
--EMR任务只能运行在独享资源组上
--********************************************************************--


CREATE TABLE if NOT EXISTS dws_cus_order_channel_aids_d_f(

 booking_time  string COMMENT '月份',    
user_id        string comment '用户ID' ,           
user_name      string comment '用户名称' ,                                   
--汇总
ticket_num    int comment '票量'    ,                
gmv           double comment 'GMV' ,           
order_num     int comment '订单量' ,                          
--平台预定   --票量    --GMV   --订单量
plat_ticket_num     int comment '平台预定票量'   ,              
plat_gmv            double comment '平台预定GMV' ,           
plat_order_num      int comment '平台预定订单量'    ,                          

--普通用户支付   --票量    --GMV   --订单量
account_ticket_num     int comment '普通用户支付票量'  ,              
account_gmv  double comment '普通用户GMV' ,            
account_order_num  int comment '普通用户支付订单量' ,                          

--会员卡购票   --票量    --GMV   --订单量
vip_ticket_num   int comment ''  ,              
vip_gmv  double comment '' ,           
vip_order_num  int comment '' ,                          

--云票务   --票量    --GMV   --订单量
cloud_ticket_num int comment '' ,              
cloud_gmv  double comment '',           
cloud_order_num int comment '' ,                          

--微商城   --票量    --GMV   --订单量
mall_ticket_num int comment '' ,              
mall_gmv  double comment '',           
mall_order_num int comment '' ,                          


--自助机   --票量    --GMV   --订单量
cdm_ticket_num int comment '' ,              
cdm_gmv  double comment '',           
cdm_order_num int comment ''  ,                          

--PC商城   --票量    --GMV   --订单量
pc_ticket_num int comment '' ,              
pc_gmv  double comment '',           
pc_order_num int comment '' ,                          

--闸机   --票量    --GMV   --订单量
agm_ticket_num int comment '' ,              
agm_gmv  double comment '',           
agm_order_num int comment '' ,                          

--智能终端   --票量    --GMV   --订单量
smart_terminal_ticket_num int comment '' ,              
smart_terminal_gmv  double comment '',            
smart_terminal_order_num int comment '' ,                          

--计调   --票量    --GMV   --订单量
adj_ticket_num int comment '' ,              
adj_gmv  double comment '',           
adj_order_num int comment '' ,                          

--淘宝/飞猪   --票量    --GMV   --订单量
tb_ticket_num int comment '' ,              
tb_gmv  double comment '',           
tb_order_num int comment '' ,                          

--年卡特权   --票量    --GMV   --订单量
year_card_ticket_num int comment '' ,              
year_card_gmv  double comment '',           
year_card_order_num int comment '' ,                          

--微平台   --票量    --GMV   --订单量
mall_plat_ticket_num int comment '' ,              
mall_plat_gmv  double comment '',           
mall_plat_order_num int comment '' ,                          

--OTA   --票量    --GMV   --订单量
ota_ticket_num int comment '' ,              
ota_gmv  double comment '',           
ota_order_num int comment '' ,                          

--兑换码购票   --票量    --GMV   --订单量
pay_code_ticket_num int comment '' ,              
pay_code_gmv  double comment '',           
pay_code_order_num int comment '' ,                          

--一卡通   --票量    --GMV   --订单量
one_card_ticket_num int comment '' ,              
one_card_gmv  double comment '',           
one_card_order_num int comment '' ,                          

--套票子票   --票量    --GMV   --订单量
subticket_ticket_num int comment '' ,              
subticket_gmv  double comment '',           
subticket_order_num int comment '' ,                          

--团队预定   --票量    --GMV   --订单量
group_ticket_num int comment '' ,              
group_gmv  double comment '',           
group_order_num int comment '' ,                          

--E福州   --票量    --GMV   --订单量
efuzhou_ticket_num int comment '' ,              
efuzhou_gmv  double comment '',           
efuzhou_order_num int comment '' ,         

--拼团   --票量    --GMV   --订单量
assorted_ticket_num int comment '' ,              
assorted_gmv  double comment '',           
assorted_order_num int comment '' ,                          

--积分商城 --票量    --GMV   --订单量
integral_mall_ticket_num int comment '' ,              
integral_mall_gmv  double comment '',           
integral_mall_order_num int comment '' ,                          

--POS支付 --票量    --GMV   --订单量
pos_ticket_num int comment '' ,              
pos_gmv  double comment '',           
pos_order_num int comment '' ,                          


--招行 --票量    --GMV   --订单量
icbc_ticket_num int comment '' ,              
icbc_gmv  double comment '',           
icbc_order_num int comment '' ,                          

--银联商务 --票量    --GMV   --订单量
bankunion_ticket_num int comment '' ,              
bankunion_gmv  double comment '',           
bankunion_order_num int comment '' ,                          

--银联pos支付 --票量    --GMV   --订单量
bankunion_pos_ticket_num int comment '' ,              
bankunion_pos_gmv  double comment '',           
bankunion_pos_order_num int comment '' ,                          

--威富通 --票量    --GMV   --订单量
wft_ticket_num int comment '' ,              
wft_gmv  double comment '',           
wft_order_num int comment '' ,                          

--易宝 --票量    --GMV   --订单量
yb_ticket_num int comment '' ,              
yb_gmv  double comment '',           
yb_order_num int comment '' ,                          

--微信-微票房 --票量    --GMV   --订单量
wx_wpf_ticket_num int comment '' ,              
wx_wpf_gmv  double comment '',           
wx_wpf_order_num int comment '' ,                          

--报团计调下单 --票量    --GMV   --订单量
adj_group_ticket_num int comment '' ,              
adj_group_gmv  double comment '',           
adj_group_order_num int comment '' ,                          

--云闪付下单 --票量    --GMV   --订单量
cloud_union_pay_ticket_num int comment '' ,              
cloud_union_pay_gmv  double comment '',           
cloud_union_pay_order_num int comment '' ,                          

--断网离线订单 --票量    --GMV   --订单量
offline_ticket_num int comment '' ,              
offline_gmv  double comment '',           
offline_order_num int comment '' ,                          

--员工卡 --票量    --GMV   --订单量
staff_card_ticket_num int comment '' ,              
staff_card_gmv  double comment '',           
staff_card_order_num int comment '' ,                          

--手牌 --票量    --GMV   --订单量
hand_card_ticket_num int comment '' ,              
hand_card_gmv  double comment '',           
hand_card_order_num int comment '' ,                          

--桌面云票务 --票量    --GMV   --订单量
desk_cloud_ticket_num int comment '' ,              
desk_cloud_gmv  double comment '',           
desk_cloud_order_num int comment '' ,                          

--APP --票量    --GMV   --订单量
app_ticket_num int comment '' ,              
app_gmv  double comment '',           
app_order_num int comment '' ,                          

--特殊团队预约 --票量    --GMV   --订单量
special_ticket_num int comment '' ,               
special_gmv  double comment '',           
special_order_num int comment '' ,                          

--微信小程序 --票量    --GMV   --订单量
wx_app_ticket_num int comment '' ,              
wx_app_gmv  double comment '',           
wx_app_order_num int comment '' ,                          

--抖音-微票房 --票量    --GMV   --订单量
dy_tik_ticket_num int comment '' ,              
dy_tik_gmv  double comment '',           
dy_tik_order_num int comment '' ,                          

--阿里供销 --票量    --GMV   --订单量
ali_ticket_num int comment '' ,              
ali_gmv  double comment '',           
ali_order_num int comment '' ,                          

--团购导码 --票量    --GMV   --订单量
group_purchase_code_ticket_num int comment '' ,              
group_purchase_code_gmv  double comment '',           
group_purchase_code_order_num int comment '' ,                     

--京津冀年卡 --票量    --GMV   --订单量
jjy_year_ticket_num int comment '' ,              
jjy_year_gmv  double comment '',           
jjy_year_order_num  int comment ''  ,                    


--资源中心 --票量    --GMV   --订单量
resource_center_ticket_num  int comment '' ,              
resource_center_gmv  double comment '',            
resource_center_order_num int comment '',

--限时抢购 --票量    --GMV   --订单量
limited_conversion_ticket_num  int comment '' ,              
limited_conversion_gmv  double comment '',           
limited_conversion_order_num int comment '',


--砍价 --票量    --GMV   --订单量
kj_ticket_num  int comment '' ,              
kj_gmv  double comment '',           
kj_order_num int comment '',


--拼团 --票量    --GMV   --订单量
pt_ticket_num  int comment '' ,              
pt_gmv  double comment '',           
pt_order_num int comment '',

--全民营销 --票量    --GMV   --订单量
qmyx_ticket_num  int comment '' ,              
qmyx_gmv  double comment '',           
qmyx_order_num int comment '',

--优惠券 --票量    --GMV   --订单量
yhq_ticket_num  int comment '' ,              
yhq_gmv  double comment '',           
yhq_order_num int comment '',

--新媒体分销订单量 --票量    --GMV   --订单量   --购买者或销售者ID为:（12404122 抖音团购,12513404 快手）
new_media_ticket_num int comment '',              
new_media_gmv  double comment '',           
new_media_order_num int comment '',



--外部发码 --票量    --GMV   --订单量   --购买者或销售者ID为:（12404122 抖音团购,12513404 快手）
external_code_ticket_num int comment '',              
external_code_gmv  double comment '',           
external_code_order_num int comment '',

--园区一卡通 --票量    --GMV   --订单量   --购买者或销售者ID为:（12404122 抖音团购,12513404 快手）
pft_park_card_ticket_num int comment '',              
pft_park_card_gmv  double comment '',           
pft_park_card_order_num int comment '',

--年卡 --票量    --GMV   --订单量   --购买者或销售者ID为:（12404122 抖音团购,12513404 快手）
pft_annual_card_ticket_num int comment '',              
pft_annual_card_gmv  double comment '',           
pft_annual_card_order_num int comment '',


user_type                      	string 	COMMENT '用户类型(供应商/分销商等)',
customer_country            	   	string 	COMMENT '客户国家',
customer_province           	  	string 	COMMENT '客户省',
customer_city               	  	string 	COMMENT '客户市',
customer_type               	   	string 	COMMENT '客户类型(旅行社/景区)',
user_land_topic             	    	string 	COMMENT '景区业态',
user_contract_model         	     	string 	COMMENT '合作模式',
signer_id                   	    	int 	COMMENT '签单人id',
signer                      	    	string 	COMMENT '签单人姓名',
servicer_id                 	    	int 	COMMENT '客服id',
servicer                    	    	string 	COMMENT '客服姓名',



cloud_order_num_kh       int comment ''  ,     --云票务  --考核维度考核维度订单量
mall_order_num_kh     int comment ''  ,     --微商城  --考核维度订单量
cdm_order_num_kh     int comment ''  ,      --自助机  --考核维度订单量   
pc_order_num_kh     int comment ''  ,       --PC商城  --考核维度订单量                   
agm_order_num_kh     int comment ''  ,       --闸机      --考核维度订单量                        
smart_terminal_order_num_kh     int comment ''  ,     --智能终端      --考核维度订单量                     
tb_order_num_kh     int comment ''  ,                 --淘宝/飞猪      --考核维度订单量                     
year_card_order_num_kh     int comment ''  ,          --年卡特权      --考核维度订单量                     
mall_plat_order_num_kh     int comment ''  ,          --微平台      --考核维度订单量                         
ota_order_num_kh     int comment ''  ,                --OTA      --考核维度订单量           
pay_code_order_num_kh     int comment ''  ,           --兑换码购票      --考核维度订单量            
one_card_order_num_kh     int comment ''  ,           --一卡通      --考核维度订单量                        
subticket_order_num_kh     int comment ''  ,          --套票子票      --考核维度订单量                    
group_order_num_kh     int comment ''  ,            --团队预定      --考核维度订单量                        
assorted_order_num_kh     int comment ''  ,         --拼团      --考核维度订单量                  
integral_mall_order_num_kh     int comment ''  ,    --积分商城    --考核维度订单量                     
pos_order_num_kh     int comment ''  ,              --POS支付    --考核维度订单量                   
wx_wpf_order_num_kh     int comment ''  ,           --微信-微票房    --考核维度订单量                     
adj_group_order_num_kh     int comment ''  ,        --报团计调下单    --考核维度订单量                   
desk_cloud_order_num_kh     int comment ''  ,      --桌面云票务    --考核维度订单量                    
app_order_num_kh     int comment ''  ,         --APP    --考核维度订单量                     
special_order_num_kh     int comment ''  ,     --特殊团队预约    --考核维度订单量                     
wx_app_order_num_kh     int comment ''  ,      --微信小程序    --考核维度订单量                            
dy_tik_order_num_kh     int comment ''  ,      --抖音-微票房    --考核维度订单量           
group_purchase_code_order_num_kh      int comment ''  ,                   --团购导码    --考核维度订单量                 
resource_center_order_num_kh     int comment ''  ,--资源中心    --考核维度订单量
limited_conversion_order_num_kh     int comment ''  ,--限时抢购    --考核维度订单量
kj_order_num_kh     int comment ''  ,--砍价    --考核维度订单量
pt_order_num_kh     int comment ''  ,--拼团    --考核维度订单量
qmyx_order_num_kh     int comment ''  ,--全民营销    --考核维度订单量
yhq_order_num_kh     int comment ''  ,--优惠券    --考核维度订单量   
new_media_order_num_kh     int comment ''  ,--新媒体分销考核维度订单量    --考核维度订单量   --购买者或销售者ID为:（12404122 抖音团购     int comment ''  ,12513404 快手     int comment ''  ,13913690 抖店     int comment ''  ,15467659 快手电商开放平台） 
external_code_order_num_kh     int comment ''  ,--外部发码    --考核维度订单量
pft_park_card_order_num_kh     int comment ''  ,--园区一卡通    --考核维度订单量
pft_annual_card_order_num_kh  int comment '',  --年卡    --考核维度订单量
pft_storage_section_num_kh  int comment '',   --分时预约
user_account       int comment '账号',

--新媒体分销订单量 --票量    --GMV   --订单量   --购买者或销售者ID为:（12404122 抖音团购）
new_media_dy_ticket_num  int comment '',              
new_media_dy_gmv double comment '',           
new_media_dy_order_num  int comment '',


--新媒体分销订单量 --票量    --GMV   --订单量   --购买者或销售者ID为:（12513404 快手）
new_media_ks_ticket_num  int comment '',              
new_media_ks_gmv double comment '',           
new_media_ks_order_num  int comment '',

--新媒体分销订单量 --票量    --GMV   --订单量   --购买者或销售者ID为:（13913690 抖店）
new_media_dd_ticket_num  int comment '',               
new_media_dd_gmv double comment '',            
new_media_dd_order_num  int comment '',

--新媒体分销订单量 --票量    --GMV   --订单量   --购买者或销售者ID为:（15467659 快手电商开放平台）
new_media_ksds_ticket_num  int comment '',              
new_media_ksds_gmv double comment '',           
new_media_ksds_order_num  int comment '',



--OTA订单量 --票量    --GMV   --订单量   --购买者或销售者ID为:（2175 去哪儿）
ota_qnr_ticket_num  int comment '',              
ota_qnr_gmv double comment '',           
ota_qnr_order_num  int comment '',

--OTA订单量 --票量    --GMV   --订单量   --购买者或销售者ID为:（28227 美团直连V2）
ota_mtzl_ticket_num  int comment '',              
ota_mtzl_gmv double comment '',           
ota_mtzl_order_num  int comment '',

--OTA订单量 --票量    --GMV   --订单量   --购买者或销售者ID为:3663752 携程玩乐）
ota_xcwl_ticket_num  int comment '',              
ota_xcwl_gmv double comment '',           
ota_xcwl_order_num  int comment '',

--OTA订单量 --票量    --GMV   --订单量   --购买者或销售者ID为:9718585 美团圈圈
ota_mtqq_ticket_num  int comment '',              
ota_mtqq_gmv double comment '',           
ota_mtqq_order_num  int comment '',

--OTA订单量 --票量    --GMV   --订单量   --购买者或销售者ID为:1252953 马蜂窝
ota_mfw_ticket_num  int comment '',              
ota_mfw_gmv double comment '',           
ota_mfw_order_num  int comment '',

--OTA订单量 --票量    --GMV   --订单量   --购买者或销售者ID为:9011093 阿里供销平台
ota_ali_ticket_num  int comment '',              
ota_ali_gmv double comment '',           
ota_ali_order_num  int comment '',

--OTA订单量 --票量    --GMV   --订单量   --购买者或销售者ID为:10406130 口碑网
ota_kbw_ticket_num  int comment '',              
ota_kbw_gmv double comment '',           
ota_kbw_order_num  int comment '',

--OTA订单量 --票量    --GMV   --订单量   --购买者或销售者ID为:13151618 马蜂窝自营
ota_mfwzy_ticket_num  int comment '',              
ota_mfwzy_gmv double comment '',           
ota_mfwzy_order_num  int comment '',

--全品类分销   订单量 --票量    --GMV   --订单量   --购买者或销售者ID为:768763 有赞微商
ota_yzwsc_ticket_num  int comment '',              
ota_yzwsc_gmv double comment '',           
ota_yzwsc_order_num  int comment '',

--全品类分销   订单量 --票量    --GMV   --订单量   --购买者或销售者ID为:5624150 京东
ota_jd_ticket_num  int comment '',              
ota_jd_gmv double comment '',           
ota_jd_order_num  int comment '',

--全品类分销   订单量 --票量    --GMV   --订单量   --购买者或销售者ID为:4560136 微盟
ota_wm_ticket_num  int comment '',              
ota_wm_gmv double comment '',           
ota_wm_order_num  int comment '', 

--全品类分销   订单量 --票量    --GMV   --订单量   --购买者或销售者ID为:10141128 高德
ota_gd_ticket_num  int comment '',              
ota_gd_gmv double comment '',           
ota_gd_order_num  int comment '',

--开放功能配置   订单量 --票量    --GMV   --订单量   --购买者或销售者ID为:5269593 美团统一预定
ota_mttyyd_ticket_num  int comment '',              
ota_mttyyd_gmv double comment '',           
ota_mttyyd_order_num  int comment '',

-- 抖音来客
new_media_dylk_ticket_num  int comment '',          
new_media_dylk_gmv double comment '',           
new_media_dylk_order_num int comment '',

--快手本地生活
new_media_ksbdsh_ticket_num int comment '' ,              
new_media_ksbdsh_gmv double comment '',           
new_media_ksbdsh_order_num int comment '',


prod_mp_ticket_num int comment '门票产品票数',              
prod_mp_new_gmv double comment '门票产品GMV',           
prod_mp_order_num int comment '门票产品订单量',
-- 套票产品   
prod_tp_ticket_num int comment '套票产品票数',              
prod_tp_new_gmv double comment '套票产品GMV',           
prod_tp_order_num int comment '套票产品订单量',
-- 演出产品   
prod_yc_ticket_num int comment '演出产品票数',              
prod_yc_new_gmv double comment '演出产品GMV',           
prod_yc_order_num int comment '演出产品订单量',
-- 年卡产品   
prod_nk_ticket_num int comment '年卡产品票数',               
prod_nk_new_gmv double comment '年卡产品GMV',           
prod_nk_order_num int comment '年卡产品订单量',
-- 旅游券产品   
prod_lvq_ticket_num int comment '旅游券产品票数',              
prod_lyq_new_gmv double comment '旅游券产品GMV',           
prod_lyq_order_num int comment '旅游券产品订单量',
-- 酒店产品   
prod_jd_ticket_num int comment '酒店产品票数',              
prod_jd_new_gmv double comment '酒店产品GMV',           
prod_jd_order_num int comment '酒店产品订单量',
-- 特产产品   
prod_tc_ticket_num int comment '特产产品票数',              
prod_tc_new_gmv double comment '特产产品GMV',           
prod_tac_order_num int comment '特产产品订单量',
-- 计时产品   
prod_jscp_ticket_num int comment '计时产品票数',              
prod_jscp_new_gmv double comment '计时产品',           
prod_jscp_order_num int comment '计时产品订单量'
-- ,
-- -- 微信小程序-分销专员
-- xcx_fxzy_ticket_num int comment '微信小程序-分销专员票数',              
-- xcx_fxzy_gmv double comment '微信小程序-分销专员gmv',           
-- xcx_fxzy_order_num int comment '微信小程序-分销专员订单量'

) comment '订单渠道表-月汇总-分销商和供货商的GMV' 
PARTITIONED BY(
    pt string
 )STORED AS ORC;








SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;    -- 开启自适应执行（默认已开启）
SET spark.sql.adaptive.coalescePartitions.enabled=true;   -- 开启分区合并（关键！）
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
--SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
--SET spark.sql.adaptive.coalescePartitions.parallelism=1;
SET spark.sql.adaptive.advisoryPartitionSizeInBytes=256MB;  -- 设置合并后的目标分区大小（例如 256MB），Spark 会自动合并小于此值的分区







INSERT OVERWRITE table dws_cus_order_channel_aids_d_f PARTITION (pt=${ds})

select
    substr(a.booking_time,1,7) as booking_time,      --统计月
    a.aids_seller_id as user_id,                     --用户ID
    b.user_name,                                     --用户名称
    --汇总
    sum(a.ticket_num) as ticket_num,                 --票量
    sum(a.booking_pay_amount)/100 as  gmv,           --GMV
    sum(1) as order_num,                             --订单量
    --平台预定   --票量    --GMV   --订单量
    sum(case when booking_channel=0 then  a.ticket_num else 0 end ) as plat_ticket_num,              
    sum(case when booking_channel=0 then a.booking_pay_amount else 0 end)/100 as  plat_gmv,           
    sum(case when booking_channel=0 then 1 else 0 end) as plat_order_num,                          

    --普通用户支付   --票量    --GMV   --订单量
    sum(case when booking_channel=1 then  a.ticket_num else 0 end ) as account_ticket_num,              
    sum(case when booking_channel=1 then a.booking_pay_amount else 0 end)/100 as  account_gmv,           
    sum(case when booking_channel=1 then 1 else 0 end) as account_order_num,                          

    --会员卡购票   --票量    --GMV   --订单量
    sum(case when booking_channel=9 then  a.ticket_num else 0 end ) as vip_ticket_num,              
    sum(case when booking_channel=9 then a.booking_pay_amount else 0 end)/100 as  vip_gmv,           
    sum(case when booking_channel=9 then 1 else 0 end) as vip_order_num,                          

    --云票务   --票量    --GMV   --订单量
    sum(case when booking_channel=10 then  a.ticket_num else 0 end ) as cloud_ticket_num,              
    sum(case when booking_channel=10 then a.booking_pay_amount else 0 end)/100 as  cloud_gmv,           
    sum(case when booking_channel=10 then 1 else 0 end) as cloud_order_num,                          

    --微商城   --票量    --GMV   --订单量
    sum(case when booking_channel=11 then  a.ticket_num else 0 end ) as mall_ticket_num,              
    sum(case when booking_channel=11 then a.booking_pay_amount else 0 end)/100 as  mall_gmv,           
    sum(case when booking_channel=11 then 1 else 0 end) as mall_order_num,                          


    --自助机   --票量    --GMV   --订单量
    sum(case when booking_channel=12 then  a.ticket_num else 0 end ) as cdm_ticket_num,              
    sum(case when booking_channel=12 then a.booking_pay_amount else 0 end)/100 as cdm_gmv,           
    sum(case when booking_channel=12 then 1 else 0 end) as cdm_order_num,                          

    --PC商城   --票量    --GMV   --订单量
    sum(case when booking_channel=13 then  a.ticket_num else 0 end ) as pc_ticket_num,              
    sum(case when booking_channel=13 then a.booking_pay_amount else 0 end)/100 as pc_gmv,           
    sum(case when booking_channel=13 then 1 else 0 end) as pc_order_num,                          

    --闸机   --票量    --GMV   --订单量
    sum(case when booking_channel=14 then  a.ticket_num else 0 end ) as agm_ticket_num,              
    sum(case when booking_channel=14 then a.booking_pay_amount else 0 end)/100 as agm_gmv,           
    sum(case when booking_channel=14 then 1 else 0 end) as agm_order_num,                          

    --智能终端   --票量    --GMV   --订单量
    sum(case when booking_channel=15 then  a.ticket_num else 0 end ) as smart_terminal_ticket_num,              
    sum(case when booking_channel=15 then a.booking_pay_amount else 0 end)/100 as smart_terminal_gmv,           
    sum(case when booking_channel=15 then 1 else 0 end) as smart_terminal_order_num,                          

    --计调   --票量    --GMV   --订单量
    sum(case when booking_channel=16 then  a.ticket_num else 0 end ) as  adj_ticket_num,              
    sum(case when booking_channel=16 then a.booking_pay_amount else 0 end)/100 as adj_gmv,           
    sum(case when booking_channel=16 then 1 else 0 end) as adj_order_num,                          

    --淘宝/飞猪   --票量    --GMV   --订单量
    sum(case when booking_channel=17 then  a.ticket_num else 0 end ) as  tb_ticket_num,              
    sum(case when booking_channel=17 then a.booking_pay_amount else 0 end)/100 as tb_gmv,           
    sum(case when booking_channel=17 then 1 else 0 end) as tb_order_num,                          

    --年卡特权   --票量    --GMV   --订单量
    sum(case when booking_channel=18 then  a.ticket_num else 0 end ) as  year_card_ticket_num,              
    sum(case when booking_channel=18 then a.booking_pay_amount else 0 end)/100 as year_card_gmv,           
    sum(case when booking_channel=18 then 1 else 0 end) as year_card_order_num,                          

    --微平台   --票量    --GMV   --订单量
    sum(case when booking_channel=19 then  a.ticket_num else 0 end ) as  mall_plat_ticket_num,              
    sum(case when booking_channel=19 then a.booking_pay_amount else 0 end)/100 as mall_plat_gmv,           
    sum(case when booking_channel=19 then 1 else 0 end) as mall_plat_order_num,                          

    --OTA   --票量    --GMV   --订单量
    sum(case when booking_channel=20 then  a.ticket_num else 0 end ) as  ota_ticket_num,              
    sum(case when booking_channel=20 then a.booking_pay_amount else 0 end)/100 as ota_gmv,           
    sum(case when booking_channel=20 then 1 else 0 end) as ota_order_num,                          

    --兑换码购票   --票量    --GMV   --订单量
    sum(case when booking_channel=21 then  a.ticket_num else 0 end ) as  pay_code_ticket_num,              
    sum(case when booking_channel=21 then a.booking_pay_amount else 0 end)/100 as pay_code_gmv,           
    sum(case when booking_channel=21 then 1 else 0 end) as pay_code_order_num,                          

    --一卡通   --票量    --GMV   --订单量
    sum(case when booking_channel=22 then  a.ticket_num else 0 end ) as  one_card_ticket_num,              
    sum(case when booking_channel=22 then a.booking_pay_amount else 0 end)/100 as one_card_gmv,           
    sum(case when booking_channel=22 then 1 else 0 end) as one_card_order_num,                          

    --套票子票   --票量    --GMV   --订单量
    sum(case when booking_channel=23 then  a.ticket_num else 0 end ) as  subticket_ticket_num,              
    sum(case when booking_channel=23 then a.booking_pay_amount else 0 end)/100 as subticket_gmv,           
    sum(case when booking_channel=23 then 1 else 0 end) as subticket_order_num,                          

    --团队预定   --票量    --GMV   --订单量
    sum(case when booking_channel=24 then  a.ticket_num else 0 end ) as  group_ticket_num,              
    sum(case when booking_channel=24 then a.booking_pay_amount else 0 end)/100 as group_gmv,           
    sum(case when booking_channel=24 then 1 else 0 end) as group_order_num,                          

    --E福州   --票量    --GMV   --订单量
    sum(case when booking_channel=33 then  a.ticket_num else 0 end ) as  efuzhou_ticket_num,              
    sum(case when booking_channel=33 then a.booking_pay_amount else 0 end)/100 as efuzhou_gmv,           
    sum(case when booking_channel=33 then 1 else 0 end) as efuzhou_order_num,         

    --拼团   --票量    --GMV   --订单量
    sum(case when booking_channel=34 then  a.ticket_num else 0 end ) as  assorted_ticket_num,              
    sum(case when booking_channel=34 then a.booking_pay_amount else 0 end)/100 as assorted_gmv,           
    sum(case when booking_channel=34 then 1 else 0 end) as assorted_order_num,                          

    --积分商城 --票量    --GMV   --订单量
    sum(case when booking_channel=35 then  a.ticket_num else 0 end ) as  integral_mall_ticket_num,              
    sum(case when booking_channel=35 then a.booking_pay_amount else 0 end)/100 as integral_mall_gmv,           
    sum(case when booking_channel=35 then 1 else 0 end) as integral_mall_order_num,                          

    --POS支付 --票量    --GMV   --订单量
    sum(case when booking_channel=36 then  a.ticket_num else 0 end ) as  pos_ticket_num,              
    sum(case when booking_channel=36 then a.booking_pay_amount else 0 end)/100 as pos_gmv,           
    sum(case when booking_channel=36 then 1 else 0 end) as pos_order_num,                          


    --招行 --票量    --GMV   --订单量
    sum(case when booking_channel=38 then  a.ticket_num else 0 end ) as  icbc_ticket_num,              
    sum(case when booking_channel=38 then a.booking_pay_amount else 0 end)/100 as icbc_gmv,           
    sum(case when booking_channel=38 then 1 else 0 end) as icbc_order_num,                          

    --银联商务 --票量    --GMV   --订单量
    sum(case when booking_channel=39 then  a.ticket_num else 0 end ) as  bankunion_ticket_num,              
    sum(case when booking_channel=39 then a.booking_pay_amount else 0 end)/100 as bankunion_gmv,           
    sum(case when booking_channel=39 then 1 else 0 end) as bankunion_order_num,                          

    --银联pos支付 --票量    --GMV   --订单量
    sum(case when booking_channel=40 then  a.ticket_num else 0 end ) as  bankunion_pos_ticket_num,              
    sum(case when booking_channel=40 then a.booking_pay_amount else 0 end)/100 as bankunion_pos_gmv,           
    sum(case when booking_channel=40 then 1 else 0 end) as bankunion_pos_order_num,                          

    --威富通 --票量    --GMV   --订单量
    sum(case when booking_channel=41 then  a.ticket_num else 0 end ) as  wft_ticket_num,              
    sum(case when booking_channel=41 then a.booking_pay_amount else 0 end)/100 as wft_gmv,           
    sum(case when booking_channel=41 then 1 else 0 end) as wft_order_num,                          

    --易宝 --票量    --GMV   --订单量
    sum(case when booking_channel=42 then  a.ticket_num else 0 end ) as  yb_ticket_num,              
    sum(case when booking_channel=42 then a.booking_pay_amount else 0 end)/100 as yb_gmv,           
    sum(case when booking_channel=42 then 1 else 0 end) as yb_order_num,                          

    --微信-微票房 --票量    --GMV   --订单量
    sum(case when booking_channel=43 then  a.ticket_num else 0 end ) as wx_wpf_ticket_num,              
    sum(case when booking_channel=43 then a.booking_pay_amount else 0 end)/100 as wx_wpf_gmv,           
    sum(case when booking_channel=43 then 1 else 0 end) as wx_wpf_order_num,                          

    --报团计调下单 --票量    --GMV   --订单量
    sum(case when booking_channel=44 then  a.ticket_num else 0 end ) as adj_group_ticket_num,              
    sum(case when booking_channel=44 then a.booking_pay_amount else 0 end)/100 as adj_group_gmv,           
    sum(case when booking_channel=44 then 1 else 0 end) as adj_group_order_num,                          

    --云闪付下单 --票量    --GMV   --订单量
    sum(case when booking_channel=45 then  a.ticket_num else 0 end ) as cloud_union_pay_ticket_num,              
    sum(case when booking_channel=45 then a.booking_pay_amount else 0 end)/100 as cloud_union_pay_gmv,           
    sum(case when booking_channel=45 then 1 else 0 end) as  cloud_union_pay_order_num,                          

    --断网离线订单 --票量    --GMV   --订单量
    sum(case when booking_channel=46 then  a.ticket_num else 0 end ) as offline_ticket_num,              
    sum(case when booking_channel=46 then a.booking_pay_amount else 0 end)/100 as offline_gmv,           
    sum(case when booking_channel=46 then 1 else 0 end) as  offline_order_num,                          

    --员工卡 --票量    --GMV   --订单量
    sum(case when booking_channel=47 then  a.ticket_num else 0 end ) as staff_card_ticket_num,              
    sum(case when booking_channel=47 then a.booking_pay_amount else 0 end)/100 as staff_card_gmv,           
    sum(case when booking_channel=47 then 1 else 0 end) as  staff_card_order_num,                          

    --手牌 --票量    --GMV   --订单量
    sum(case when booking_channel=48 then  a.ticket_num else 0 end ) as hand_card_ticket_num,              
    sum(case when booking_channel=48 then a.booking_pay_amount else 0 end)/100 as hand_card_gmv,           
    sum(case when booking_channel=48 then 1 else 0 end) as  hand_card_order_num,                          

    --桌面云票务 --票量    --GMV   --订单量
    sum(case when booking_channel=49 then  a.ticket_num else 0 end ) as desk_cloud_ticket_num,              
    sum(case when booking_channel=49 then a.booking_pay_amount else 0 end)/100 as desk_cloud_gmv,           
    sum(case when booking_channel=49 then 1 else 0 end) as  desk_cloud_order_num,                          

    --APP --票量    --GMV   --订单量
    sum(case when booking_channel=50 then  a.ticket_num else 0 end ) as app_ticket_num,              
    sum(case when booking_channel=50 then a.booking_pay_amount else 0 end)/100 as app_gmv,           
    sum(case when booking_channel=50 then 1 else 0 end) as  app_order_num,                          

    --特殊团队预约 --票量    --GMV   --订单量
    sum(case when booking_channel=55 then  a.ticket_num else 0 end ) as special_ticket_num,              
    sum(case when booking_channel=55 then a.booking_pay_amount else 0 end)/100 as special_gmv,           
    sum(case when booking_channel=55 then 1 else 0 end) as  special_order_num,                          

    --微信小程序 --票量    --GMV   --订单量
    sum(case when booking_channel=56 then  a.ticket_num else 0 end ) as wx_app_ticket_num,              
    sum(case when booking_channel=56 then a.booking_pay_amount else 0 end)/100 as wx_app_gmv,           
    sum(case when booking_channel=56 then 1 else 0 end) as  wx_app_order_num,                          

    --抖音-微票房 --票量    --GMV   --订单量
    sum(case when booking_channel=57 then  a.ticket_num else 0 end ) as dy_tik_ticket_num,              
    sum(case when booking_channel=57 then a.booking_pay_amount else 0 end)/100 as dy_tik_gmv,           
    sum(case when booking_channel=57 then 1 else 0 end) as  dy_tik_order_num,                          

    --阿里供销 --票量    --GMV   --订单量
    sum(case when booking_channel=58 then  a.ticket_num else 0 end ) as ali_ticket_num,              
    sum(case when booking_channel=58 then a.booking_pay_amount else 0 end)/100 as ali_gmv,           
    sum(case when booking_channel=58 then 1 else 0 end) as  ali_order_num,                          

    --团购导码 --票量    --GMV   --订单量
    sum(case when booking_channel=59 then  a.ticket_num else 0 end ) as group_purchase_code_ticket_num,              
    sum(case when booking_channel=59 then a.booking_pay_amount else 0 end)/100 as group_purchase_code_gmv,           
    sum(case when booking_channel=59 then 1 else 0 end) as  group_purchase_code_order_num ,                     

    -- --京津冀年卡 --票量    --GMV   --订单量
    -- sum(case when booking_channel=60 then  a.ticket_num else 0 end ) as jjy_year_ticket_num,              
    -- sum(case when booking_channel=60 then a.booking_pay_amount else 0 end)/100 as jjy_year_gmv,           
    -- sum(case when booking_channel=60 then 1 else 0 end) as  jjy_year_order_num,                     

    -- 微信小程序-分销专员
    sum(case when ifnull(l.marketing_type,'')='微信小程序-分销专员' then  a.ticket_num else 0 end ) as jjy_year_ticket_num,              
    sum(case when ifnull(l.marketing_type,'')='微信小程序-分销专员' then  a.booking_pay_amount else 0 end)/100 as jjy_year_gmv,           
    sum(case when ifnull(l.marketing_type,'')='微信小程序-分销专员' then  1 else 0 end) as  jjy_year_order_num,


    --资源中心 --票量    --GMV   --订单量
    sum(case when isnotnull(resource_center_supplier_id)  and order_pay_status <2 then  a.ticket_num else 0 end ) as resource_center_ticket_num,              
    sum(case when isnotnull(resource_center_supplier_id)  and order_pay_status <2 then  a.booking_pay_amount else 0 end)/100 as resource_center_gmv,           
    sum(case when isnotnull(resource_center_supplier_id)  and order_pay_status <2 then  1 else 0 end) as  resource_center_order_num,

    --限时抢购 --票量    --GMV   --订单量
    sum(case when d.is_xsqg=1 then a.ticket_num else 0 end ) as limited_conversion_ticket_num,              
    sum(case when d.is_xsqg=1 then a.booking_pay_amount else 0 end)/100 as limited_conversion_gmv,           
    sum(case when d.is_xsqg=1 then 1 else 0 end) as  limited_conversion_order_num,

    --砍价 --票量    --GMV   --订单量
    sum(case when d.is_kj=1 then  a.ticket_num else 0 end ) as kj_ticket_num,              
    sum(case when d.is_kj=1 then  a.booking_pay_amount else 0 end)/100 as kj_gmv,           
    sum(case when d.is_kj=1 then  1 else 0 end) as  kj_order_num,

    --拼团 --票量    --GMV   --订单量
    sum(case when d.is_pt=1 then  a.ticket_num else 0 end ) as pt_ticket_num,              
    sum(case when d.is_pt=1 then  a.booking_pay_amount else 0 end)/100 as pt_gmv,           
    sum(case when d.is_pt=1 then  1 else 0 end) as  pt_order_num,

    --全民营销 --票量    --GMV   --订单量
    sum(case when d.is_qmyx=1 then  a.ticket_num else 0 end ) as qmyx_ticket_num,              
    sum(case when d.is_qmyx=1 then  a.booking_pay_amount else 0 end)/100 as qmyx_gmv,           
    sum(case when d.is_qmyx=1 then  1 else 0 end) as  qmyx_order_num,

    --优惠券 --票量    --GMV   --订单量
    sum(case when d.is_yhq=1 then  a.ticket_num else 0 end ) as yhq_ticket_num,              
    sum(case when d.is_yhq=1 then  a.booking_pay_amount else 0 end)/100 as yhq_gmv,           
    sum(case when d.is_yhq=1 then  1 else 0 end) as  yhq_order_num,

    --新媒体分销订单量 --票量    --GMV   --订单量   --购买者或销售者ID为:（12404122 抖音团购,12513404 快手,13913690 抖店,15467659 快手电商开放平台）
    sum(case when  aids_buyer_id in ('12404122','12513404','13913690','15467659','26856539','27003241')  OR  aids_seller_id in ('12404122','12513404','13913690','15467659','26856539','27003241')  then  a.ticket_num else 0 end ) as new_media_ticket_num,              
    sum(case when  aids_buyer_id in ('12404122','12513404','13913690','15467659','26856539','27003241')  OR  aids_seller_id in ('12404122','12513404','13913690','15467659','26856539','27003241')  then  a.booking_pay_amount else 0 end)/100 as new_media_gmv,           
    sum(case when  aids_buyer_id in ('12404122','12513404','13913690','15467659','26856539','27003241')  OR  aids_seller_id in ('12404122','12513404','13913690','15467659','26856539','27003241')  then  1 else 0 end) as  new_media_order_num,




    --外部发码 --票量    --GMV   --订单量
    sum(case when ifnull(i.marketing_type,'')='外部发码' then  a.ticket_num else 0 end ) as external_code_ticket_num,              
    sum(case when ifnull(i.marketing_type,'')='外部发码' then  a.booking_pay_amount else 0 end)/100 as external_code_gmv,           
    sum(case when ifnull(i.marketing_type,'')='外部发码' then  1 else 0 end) as  external_code_order_num,


    --园区一卡通 --票量    --GMV   --订单量
    sum(case when ifnull(j.marketing_type,'')='园区一卡通' then  a.ticket_num else 0 end ) as pft_park_card_ticket_num,              
    sum(case when ifnull(j.marketing_type,'')='园区一卡通' then  a.booking_pay_amount else 0 end)/100 as pft_park_card_gmv,           
    sum(case when ifnull(j.marketing_type,'')='园区一卡通' then  1 else 0 end) as  pft_park_card_order_num,

    --年卡 --票量    --GMV   --订单量
    sum(case when ifnull(k.marketing_type,'')='年卡' then  a.ticket_num else 0 end ) as pft_annual_card_ticket_num,              
    sum(case when ifnull(k.marketing_type,'')='年卡' then  a.booking_pay_amount else 0 end)/100 as pft_annual_card_gmv,           
    sum(case when ifnull(k.marketing_type,'')='年卡' then  1 else 0 end) as  pft_annual_card_order_num,



    b.user_type                     -- 	string 	COMMENT '用户类型(供应商/分销商等)',
    ,b.customer_country            	--   	string 	COMMENT '客户国家',
    ,b.customer_province           	--  	string 	COMMENT '客户省',
    ,b.customer_city               	--  	string 	COMMENT '客户市',
    ,b.customer_type               	 --  	string 	COMMENT '客户类型(旅行社/景区)',
    ,b.user_land_topic             	  --  	string 	COMMENT '景区业态',
    ,b.user_contract_model         	   --  	string 	COMMENT '合作模式',
    ,b.signer_id                   	   -- 	int 	COMMENT '签单人id',
    ,b.signer                      	   -- 	string 	COMMENT '签单人姓名',
    ,b.servicer_id                 	    --	int 	COMMENT '客服id',
    ,b.servicer                    	    --	string 	COMMENT '客服姓名'




    ,
    0 as cloud_order_num_kh,     --云票务  --考核维度考核维度订单量
    0 as mall_order_num_kh,     --微商城  --考核维度订单量
    0 as cdm_order_num_kh,      --自助机  --考核维度订单量   
    0 as pc_order_num_kh,       --PC商城  --考核维度订单量                   
    0 as agm_order_num_kh,       --闸机      --考核维度订单量                        
    0 as smart_terminal_order_num_kh,     --智能终端      --考核维度订单量                     
    0 as tb_order_num_kh,                 --淘宝/飞猪      --考核维度订单量                     
    0 as year_card_order_num_kh,          --年卡特权      --考核维度订单量                     
    0 as mall_plat_order_num_kh,          --微平台      --考核维度订单量                         
    0 as ota_order_num_kh,                --OTA      --考核维度订单量           
    0 as pay_code_order_num_kh,           --兑换码购票      --考核维度订单量            
    0 as one_card_order_num_kh,           --一卡通      --考核维度订单量                        
    0 as subticket_order_num_kh,          --套票子票      --考核维度订单量                    
    0 as group_order_num_kh,            --团队预定      --考核维度订单量                        
    0 as assorted_order_num_kh,         --拼团      --考核维度订单量                  
    0 as integral_mall_order_num_kh,    --积分商城    --考核维度订单量                     
    0 as pos_order_num_kh,              --POS支付    --考核维度订单量                   
    0 as wx_wpf_order_num_kh,           --微信-微票房    --考核维度订单量                     
    0 as adj_group_order_num_kh,        --报团计调下单    --考核维度订单量                   
    0 as  desk_cloud_order_num_kh,      --桌面云票务    --考核维度订单量                    
    0 as  app_order_num_kh,         --APP    --考核维度订单量                     
    0 as  special_order_num_kh,     --特殊团队预约    --考核维度订单量                     
    0 as  wx_app_order_num_kh,      --微信小程序    --考核维度订单量                            
    0 as  dy_tik_order_num_kh,      --抖音-微票房    --考核维度订单量           
    0 as  group_purchase_code_order_num_kh ,                   --团购导码    --考核维度订单量                 
    0 as  resource_center_order_num_kh,--资源中心    --考核维度订单量
    0 as  limited_conversion_order_num_kh,--限时抢购    --考核维度订单量
    0 as  kj_order_num_kh,--砍价    --考核维度订单量
    0 as  pt_order_num_kh,--拼团    --考核维度订单量
    0 as  qmyx_order_num_kh,--全民营销    --考核维度订单量
    0 as  yhq_order_num_kh,--优惠券    --考核维度订单量   
    0 as  new_media_order_num_kh,--新媒体分销考核维度订单量    --考核维度订单量   --购买者或销售者ID为:（12404122 抖音团购,12513404 快手,13913690 抖店,15467659 快手电商开放平台） 
    0 as  external_code_order_num_kh,--外部发码    --考核维度订单量
    0 as  pft_park_card_order_num_kh,--园区一卡通    --考核维度订单量
    0 as  pft_annual_card_order_num_kh,--年卡    --考核维度订单量


    0 as  pft_storage_section_num_kh--分时预约    --考核维度订单量

    ,CAST(b.user_account as INT) as user_account,



    --新媒体分销订单量 --票量    --GMV   --订单量   --购买者或销售者ID为:（12404122 抖音团购）
    sum(case when  aids_buyer_id in ('12404122')  OR  aids_seller_id in ('12404122')  then  a.ticket_num else 0 end ) as new_media_dy_ticket_num,              
    sum(case when  aids_buyer_id in ('12404122')  OR  aids_seller_id in ('12404122')  then  a.booking_pay_amount else 0 end)/100 as new_media_dy_gmv,           
    sum(case when  aids_buyer_id in ('12404122')  OR  aids_seller_id in ('12404122')  then  1 else 0 end) as  new_media_dy_order_num,


    --新媒体分销订单量 --票量    --GMV   --订单量   --购买者或销售者ID为:（12513404 快手）
    sum(case when  aids_buyer_id in ('12513404')  OR  aids_seller_id in ('12513404')  then  a.ticket_num else 0 end ) as new_media_ks_ticket_num,              
    sum(case when  aids_buyer_id in ('12513404')  OR  aids_seller_id in ('12513404')  then  a.booking_pay_amount else 0 end)/100 as new_media_ks_gmv,           
    sum(case when  aids_buyer_id in ('12513404')  OR  aids_seller_id in ('12513404')  then  1 else 0 end) as  new_media_ks_order_num,

    --新媒体分销订单量 --票量    --GMV   --订单量   --购买者或销售者ID为:（13913690 抖店）
    sum(case when  aids_buyer_id in ('13913690')  OR  aids_seller_id in ('13913690')  then  a.ticket_num else 0 end ) as new_media_dd_ticket_num,              
    sum(case when  aids_buyer_id in ('13913690')  OR  aids_seller_id in ('13913690')  then  a.booking_pay_amount else 0 end)/100 as new_media_dd_gmv,           
    sum(case when  aids_buyer_id in ('13913690')  OR  aids_seller_id in ('13913690')  then  1 else 0 end) as  new_media_dd_order_num,

    --新媒体分销订单量 --票量    --GMV   --订单量   --购买者或销售者ID为:（15467659 快手电商开放平台）
    sum(case when  aids_buyer_id in ('15467659')  OR  aids_seller_id in ('15467659')  then  a.ticket_num else 0 end ) as new_media_ksds_ticket_num,              
    sum(case when  aids_buyer_id in ('15467659')  OR  aids_seller_id in ('15467659')  then  a.booking_pay_amount else 0 end)/100 as new_media_ksds_gmv,           
    sum(case when  aids_buyer_id in ('15467659')  OR  aids_seller_id in ('15467659')  then  1 else 0 end) as  new_media_ksds_order_num,






    --OTA订单量 --票量    --GMV   --订单量   --购买者或销售者ID为:（2175 去哪儿）
    sum(case when  aids_buyer_id in ('2175')  OR  aids_seller_id in ('2175')  then  a.ticket_num else 0 end ) as ota_qnr_ticket_num,              
    sum(case when  aids_buyer_id in ('2175')  OR  aids_seller_id in ('2175')  then  a.booking_pay_amount else 0 end)/100 as ota_qnr_gmv,           
    sum(case when  aids_buyer_id in ('2175')  OR  aids_seller_id in ('2175')  then  1 else 0 end) as  ota_qnr_order_num,

    --OTA订单量 --票量    --GMV   --订单量   --购买者或销售者ID为:（28227 美团直连V2）
    sum(case when  aids_buyer_id in ('28227')  OR  aids_seller_id in ('28227')  then  a.ticket_num else 0 end ) as ota_mtzl_ticket_num,              
    sum(case when  aids_buyer_id in ('28227')  OR  aids_seller_id in ('28227')  then  a.booking_pay_amount else 0 end)/100 as ota_mtzl_gmv,           
    sum(case when  aids_buyer_id in ('28227')  OR  aids_seller_id in ('28227')  then  1 else 0 end) as  ota_mtzl_order_num,

    --OTA订单量 --票量    --GMV   --订单量   --购买者或销售者ID为:3663752 1214 携程玩乐/携程网）
    sum(case when  aids_buyer_id in ('3663752','1214')  OR  aids_seller_id in ('3663752','1214')  then  a.ticket_num else 0 end ) as ota_xcwl_ticket_num,              
    sum(case when  aids_buyer_id in ('3663752','1214')  OR  aids_seller_id in ('3663752','1214')  then  a.booking_pay_amount else 0 end)/100 as ota_xcwl_gmv,           
    sum(case when  aids_buyer_id in ('3663752','1214')  OR  aids_seller_id in ('3663752','1214')  then  1 else 0 end) as  ota_xcwl_order_num,

    --OTA订单量 --票量    --GMV   --订单量   --购买者或销售者ID为:9718585 美团圈圈
    sum(case when  aids_buyer_id in ('9718585')  OR  aids_seller_id in ('9718585')  then  a.ticket_num else 0 end ) as ota_mtqq_ticket_num,              
    sum(case when  aids_buyer_id in ('9718585')  OR  aids_seller_id in ('9718585')  then  a.booking_pay_amount else 0 end)/100 as ota_mtqq_gmv,           
    sum(case when  aids_buyer_id in ('9718585')  OR  aids_seller_id in ('9718585')  then  1 else 0 end) as  ota_mtqq_order_num,

    --OTA订单量 --票量    --GMV   --订单量   --购买者或销售者ID为:1252953 马蜂窝
    sum(case when  aids_buyer_id in ('1252953')  OR  aids_seller_id in ('1252953')  then  a.ticket_num else 0 end ) as ota_mfw_ticket_num,              
    sum(case when  aids_buyer_id in ('1252953')  OR  aids_seller_id in ('1252953')  then  a.booking_pay_amount else 0 end)/100 as ota_mfw_gmv,           
    sum(case when  aids_buyer_id in ('1252953')  OR  aids_seller_id in ('1252953')  then  1 else 0 end) as  ota_mfw_order_num,

    --OTA订单量 --票量    --GMV   --订单量   --购买者或销售者ID为:9011093 阿里供销平台
    sum(case when  aids_buyer_id in ('9011093')  OR  aids_seller_id in ('9011093')  then  a.ticket_num else 0 end ) as ota_ali_ticket_num,              
    sum(case when  aids_buyer_id in ('9011093')  OR  aids_seller_id in ('9011093')  then  a.booking_pay_amount else 0 end)/100 as ota_ali_gmv,           
    sum(case when  aids_buyer_id in ('9011093')  OR  aids_seller_id in ('9011093')  then  1 else 0 end) as  ota_ali_order_num,

    --OTA订单量 --票量    --GMV   --订单量   --购买者或销售者ID为:10406130 口碑网
    sum(case when  aids_buyer_id in ('10406130')  OR  aids_seller_id in ('10406130')  then  a.ticket_num else 0 end ) as ota_kbw_ticket_num,              
    sum(case when  aids_buyer_id in ('10406130')  OR  aids_seller_id in ('10406130')  then  a.booking_pay_amount else 0 end)/100 as ota_kbw_gmv,           
    sum(case when  aids_buyer_id in ('10406130')  OR  aids_seller_id in ('10406130')  then  1 else 0 end) as  ota_kbw_order_num,

    --OTA订单量 --票量    --GMV   --订单量   --购买者或销售者ID为:13151618 马蜂窝自营
    sum(case when  aids_buyer_id in ('13151618')  OR  aids_seller_id in ('13151618')  then  a.ticket_num else 0 end ) as ota_mfwzy_ticket_num,              
    sum(case when  aids_buyer_id in ('13151618')  OR  aids_seller_id in ('13151618')  then  a.booking_pay_amount else 0 end)/100 as ota_mfwzy_gmv,           
    sum(case when  aids_buyer_id in ('13151618')  OR  aids_seller_id in ('13151618')  then  1 else 0 end) as  ota_mfwzy_order_num,

    --全品类分销   订单量 --票量    --GMV   --订单量   --购买者或销售者ID为:768763 有赞微商
    sum(case when  aids_buyer_id in ('768763')  OR  aids_seller_id in ('768763')  then  a.ticket_num else 0 end ) as ota_yzwsc_ticket_num,              
    sum(case when  aids_buyer_id in ('768763')  OR  aids_seller_id in ('768763')  then  a.booking_pay_amount else 0 end)/100 as ota_yzwsc_gmv,           
    sum(case when  aids_buyer_id in ('768763')  OR  aids_seller_id in ('768763')  then  1 else 0 end) as  ota_yzwsc_order_num,

    --全品类分销   订单量 --票量    --GMV   --订单量   --购买者或销售者ID为:5624150 京东
    sum(case when  aids_buyer_id in ('5624150')  OR  aids_seller_id in ('5624150')  then  a.ticket_num else 0 end ) as ota_jd_ticket_num,              
    sum(case when  aids_buyer_id in ('5624150')  OR  aids_seller_id in ('5624150')  then  a.booking_pay_amount else 0 end)/100 as ota_jd_gmv,           
    sum(case when  aids_buyer_id in ('5624150')  OR  aids_seller_id in ('5624150')  then  1 else 0 end) as  ota_jd_order_num,

    --全品类分销   订单量 --票量    --GMV   --订单量   --购买者或销售者ID为:4560136 微盟
    sum(case when  aids_buyer_id in ('4560136')  OR  aids_seller_id in ('4560136')  then  a.ticket_num else 0 end ) as ota_wm_ticket_num,              
    sum(case when  aids_buyer_id in ('4560136')  OR  aids_seller_id in ('4560136')  then  a.booking_pay_amount else 0 end)/100 as ota_wm_gmv,           
    sum(case when  aids_buyer_id in ('4560136')  OR  aids_seller_id in ('4560136')  then  1 else 0 end) as  ota_wm_order_num,

    --全品类分销   订单量 --票量    --GMV   --订单量   --购买者或销售者ID为:10141128 高德
    sum(case when  aids_buyer_id in ('10141128')  OR  aids_seller_id in ('10141128')  then  a.ticket_num else 0 end ) as ota_gd_ticket_num,              
    sum(case when  aids_buyer_id in ('10141128')  OR  aids_seller_id in ('10141128')  then  a.booking_pay_amount else 0 end)/100 as ota_gd_gmv,           
    sum(case when  aids_buyer_id in ('10141128')  OR  aids_seller_id in ('10141128')  then  1 else 0 end) as  ota_gd_order_num,

    --开放功能配置   订单量 --票量    --GMV   --订单量   --购买者或销售者ID为:5269593 美团统一预定
    sum(case when  aids_buyer_id in ('5269593')  OR  aids_seller_id in ('5269593')  then  a.ticket_num else 0 end ) as ota_mttyyd_ticket_num,              
    sum(case when  aids_buyer_id in ('5269593')  OR  aids_seller_id in ('5269593')  then  a.booking_pay_amount else 0 end)/100 as ota_mttyyd_gmv,           
    sum(case when  aids_buyer_id in ('5269593')  OR  aids_seller_id in ('5269593')  then  1 else 0 end) as  ota_mttyyd_order_num,

    --新媒体分销订单量 --票量    --GMV   --订单量   --购买者或销售者ID为:（26856539 抖音来客）
    sum(case when  aids_buyer_id in ('26856539')  OR  aids_seller_id in ('26856539')  then  a.ticket_num else 0 end ) as new_media_dylk_ticket_num,              
    sum(case when  aids_buyer_id in ('26856539')  OR  aids_seller_id in ('26856539')  then  a.booking_pay_amount else 0 end)/100 as new_media_dylk_gmv,           
    sum(case when  aids_buyer_id in ('26856539')  OR  aids_seller_id in ('26856539')  then  1 else 0 end) as  new_media_dylk_order_num,


    --新媒体分销订单量 --票量    --GMV   --订单量   --购买者或销售者ID为:27003241 快手本地生活
    sum(case when  aids_buyer_id in ('27003241')  OR  aids_seller_id in ('27003241')  then  a.ticket_num else 0 end ) as new_media_ksbdsh_ticket_num,              
    sum(case when  aids_buyer_id in ('27003241')  OR  aids_seller_id in ('27003241')  then  a.booking_pay_amount else 0 end)/100 as new_media_ksbdsh_gmv,           
    sum(case when  aids_buyer_id in ('27003241')  OR  aids_seller_id in ('27003241')  then  1 else 0 end) as  new_media_ksbdsh_order_num,







    -- 景区产品   
    sum(case when land_type_name='景区'  then  a.ticket_num else 0 end ) as prod_mp_ticket_num,              
    sum(case when land_type_name='景区'  then  a.booking_pay_amount else 0 end)/100 as prod_mp_new_gmv,           
    sum(case when land_type_name='景区' then  1 else 0 end) as  prod_mp_order_num,


    -- 套票产品   
    sum(case when land_type_name='套票'  then  a.ticket_num else 0 end ) as prod_tp_ticket_num,              
    sum(case when land_type_name='套票'  then  a.booking_pay_amount else 0 end)/100 as prod_tp_new_gmv,           
    sum(case when land_type_name='套票' then  1 else 0 end) as  prod_tp_order_num,

    -- 演出产品   
    sum(case when land_type_name='演出'  then  a.ticket_num else 0 end ) as prod_yc_ticket_num,              
    sum(case when land_type_name='演出'  then  a.booking_pay_amount else 0 end)/100 as prod_yc_new_gmv,           
    sum(case when land_type_name='演出' then  1 else 0 end) as  prod_yc_order_num,

    -- 年卡产品   
    sum(case when land_type_name='年卡'  then  a.ticket_num else 0 end ) as prod_nk_ticket_num,              
    sum(case when land_type_name='年卡'  then  a.booking_pay_amount else 0 end)/100 as prod_nk_new_gmv,           
    sum(case when land_type_name='年卡' then  1 else 0 end) as  prod_nk_order_num,

    -- 旅游券产品   
    sum(case when land_type_name='旅游券'  then  a.ticket_num else 0 end ) as prod_lvq_ticket_num,              
    sum(case when land_type_name='旅游券'  then  a.booking_pay_amount else 0 end)/100 as prod_lyq_new_gmv,           
    sum(case when land_type_name='旅游券' then  1 else 0 end) as  prod_lyq_order_num,

    -- 酒店产品   
    sum(case when land_type_name='酒店'  then  a.ticket_num else 0 end ) as prod_jd_ticket_num,              
    sum(case when land_type_name='酒店'  then  a.booking_pay_amount else 0 end)/100 as prod_jd_new_gmv,           
    sum(case when land_type_name='酒店' then  1 else 0 end) as  prod_jd_order_num,


    -- 特产产品   
    sum(case when land_type_name='特产'  then  a.ticket_num else 0 end ) as prod_tc_ticket_num,              
    sum(case when land_type_name='特产'  then  a.booking_pay_amount else 0 end)/100 as prod_tc_new_gmv,           
    sum(case when land_type_name='特产' then  1 else 0 end) as  prod_tac_order_num,

    -- 计时产品   
    sum(case when land_type_name='计时产品'  then  a.ticket_num else 0 end ) as prod_jscp_ticket_num,              
    sum(case when land_type_name='计时产品'  then  a.booking_pay_amount else 0 end)/100 as prod_jscp_new_gmv,           
    sum(case when land_type_name='计时产品' then  1 else 0 end) as  prod_jscp_order_num
    -- ,
    -- --园区一卡通 --票量    --GMV   --订单量
    -- sum(case when ifnull(l.marketing_type,'')='微信小程序-分销专员' then  a.ticket_num else 0 end ) as xcx_fxzy_ticket_num,              
    -- sum(case when ifnull(l.marketing_type,'')='微信小程序-分销专员' then  a.booking_pay_amount else 0 end)/100 as xcx_fxzy_gmv,           
    -- sum(case when ifnull(l.marketing_type,'')='微信小程序-分销专员' then  1 else 0 end) as  xcx_fxzy_order_num


from dwd_order_split_d_i a       --data_middle_bi.dwd_order_split_d_i a
inner join dim_user_d_f b      --data_middle_bi.dim_user_d_f  b 
    on  a.aids_seller_id=b.user_id
    and b.user_type in ('供应商','分销商') 
    and b.user_is_test='正式'
    and b.pt = ${ds}


left join
    (select order_id    --,marketing_type  --限时抢购
          ,MAX(case when marketing_type = '限时抢购' then 1 else 0 end) as is_xsqg
          ,MAX(case when marketing_type = '砍价' then 1 else 0 end) as is_kj
          ,MAX(case when marketing_type = '拼团' then 1 else 0 end) as is_pt
          ,MAX(case when marketing_type = '全民营销' then 1 else 0 end) as is_qmyx
          ,MAX(case when marketing_type = '优惠券' then 1 else 0 end) as is_yhq
     from dwd_sales_tr_marketing_order_d_f     --it_project.dwd_sales_tr_marketing_order_d_f
     where pt = ${ds}
     and marketing_type in ('限时抢购','砍价','拼团','全民营销','优惠券')     --'限时抢购'
     group by order_id    --,marketing_type  --限时抢购
    ) d
    on a.order_id=d.order_id



left join
    (select ordernum,'外部发码' as marketing_type
     from ods_cus_pft_external_code_order_d_f    --it_project.ods_cus_pft_external_code_order_d_f
     where pt = ${ds}
     group by ordernum
    ) i
    on a.order_id=i.ordernum


left join
    (select ordernum,'园区一卡通' as marketing_type
     from ods_cus_pft_park_card_order_d_f     --it_project.ods_cus_pft_park_card_order_d_f
     where pt = ${ds}
     group by ordernum
    ) j
    on a.order_id=j.ordernum


left join
    (select ordernum,'年卡' as marketing_type
     from ods_cus_pft_annual_card_order_d_f     --it_project.ods_cus_pft_annual_card_order_d_f
     where pt = ${ds}
     group by ordernum
    ) k
    on a.order_id=k.ordernum


left join
    (
     -- select ordernum,'分时预约' as marketing_type
     -- from it_project.ods_ord_pft_order_storage_section_d_f
     -- where pt="${bdp.system.bizdate}"
     -- group by ordernum
     -- 把分时预约改成微信小程序-分销专员
     select order_num,'微信小程序-分销专员' as marketing_type
     from ods_pft_distribute_order_d_f    --it_project.ods_pft_distribute_order_d_f
     where pt = ${ds}
     group by order_num
    ) l
    on a.order_id=l.order_num


where substr(a.orderdate,1,10)>=date_format(add_months(to_date(cast(${ds} as string),'yyyyMMdd'), -24), 'yyyy-MM-dd')
--substr(a.orderdate,1,7)>=substr(add_months( FROM_UNIXTIME(UNIX_TIMESTAMP(CAST(${ds} AS STRING), 'yyyyMMdd'), 'yyyy-MM-dd'), -24),1,7)

--substr(add_months( ${ds2}, -24),1,7)   -- 近24个月
 -- a.orderdate >= '2023-06-01' 
-- DATE_SUB("${bdp.system.bizdate2}", 365)   近365天

group by substr(a.booking_time,1,7),
    b.user_name,
    a.aids_seller_id
    ,b.user_type                     -- 	string 	COMMENT '用户类型(供应商/分销商等)',
    ,b.customer_country            	--   	string 	COMMENT '客户国家',
    ,b.customer_province           	--  	string 	COMMENT '客户省',
    ,b.customer_city               	--  	string 	COMMENT '客户市',
    ,b.customer_type               	 --  	string 	COMMENT '客户类型(旅行社/景区)',
    ,b.user_land_topic             	  --  	string 	COMMENT '景区业态',
    ,b.user_contract_model         	   --  	string 	COMMENT '合作模式',
    ,b.signer_id                   	   -- 	int 	COMMENT '签单人id',
    ,b.signer                      	   -- 	string 	COMMENT '签单人姓名',
    ,b.servicer_id                 	    --	int 	COMMENT '客服id',
    ,b.servicer                    	    --	string 	COMMENT '客服姓名'
    ,CAST(b.user_account as INT)
;










