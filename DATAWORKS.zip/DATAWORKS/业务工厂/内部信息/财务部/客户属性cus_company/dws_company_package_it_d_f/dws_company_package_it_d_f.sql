--@exclude_input=default_workspace_svwh.default.dwd_user_package_d_f
--EMR Spark SQL
--********************************************************************--
--author: 施建伟
--create time: 2026-03-27 14:23:07
--EMR任务只能运行在独享资源组上
--商户（供应商+分销商）各套餐周期及自供应产品订单情况
--********************************************************************--




create table if NOT EXISTS dws_company_package_it_d_f(
    stat_date                                   STRING COMMENT"统计日期",
    dw_ins_time                                 STRING COMMENT"数据插入日期",

    user_id                                     INT    COMMENT"用户id",
    user_group                                  STRING COMMENT"用户分群",

    user_first_supplier_begindate               STRING COMMENT"用户第一次合作供应商套餐开始日期",
    user_first_supplier_enddate                 STRING COMMENT"用户第一次合作供应商套餐结束日期",
    user_first_supplier_package_id              STRING COMMENT"用户第一次合作供应商套餐ID",
    user_first_supplier_package_name            STRING COMMENT"用户第一次合作供应商套餐名称",
    user_first_supplier_package_price           STRING COMMENT"用户第一次合作供应商套餐价格",
    user_first_supplier_package_classify_name   STRING COMMENT"用户第一次合作供应商套餐组",
    user_first_supplier_package_pay_amount      int    COMMENT"用户第一次合作供应商实收金额（分）",
    user_first_supplier_add_time                STRING COMMENT"用户第一次合作供应添加时间",


    user_first_package_begindate                STRING COMMENT"用户第一次合作开始日期",
    user_first_package_enddate                  STRING COMMENT"用户第一次合作结束日期",
    user_first_package_id                       INT    COMMENT"用户第一次套餐id",
    user_first_package_name                     STRING COMMENT"用户第一次套餐名称",
    user_first_package_price                    int    COMMENT"用户第一次套餐价格(分)",
    user_first_package_role                     STRING COMMENT"用户第一次套餐角色,供应商/分销商",
    user_first_package_classify_name            string COMMENT '用户第一次套餐套餐组',
    user_first_package_pay_amount               int    COMMENT '用户第一次套餐实收金额（分）',
    user_first_add_time                         string COMMENT '用户第一次套餐添加日期',
    

    user_package_num_buy                        int    COMMENT"用户购买套餐次数",
    user_package_num_used                       int    COMMENT"用户已用套餐次数",
    max_package_price                           int    COMMENT"用户使用套餐最大价格",
    sum_pay_amount_package                      int    comment"用户实付套餐费合计",
    sum_price_package                           int    comment"用户套餐单价合计",

    --当前套餐情况
    user_curr_package_id                        INT    COMMENT"用户当前套餐id",
    user_curr_package_name                      STRING COMMENT"用户当前套餐名称",
    user_curr_package_begin_date                STRING COMMENT"用户当前套餐开始日期",
    user_curr_package_end_date                  STRING COMMENT"用户当前套餐结束日期",
    user_curr_package_add_date                  STRING COMMENT"用户当前套餐添加日期",
    user_curr_package_price                     int    COMMENT"用户当前套餐价格(分)",
    user_curr_package_pay_amount                int    COMMENT"用户当前套餐实收金额(分)",
    user_curr_package_role                      STRING COMMENT"用户当前套餐角色,供应商/分销商",
    user_curr_package_classify_name             STRING COMMENT"用户当前套餐套餐组",
    user_curr_package_signer                    STRING COMMENT"用户当前套餐签单人",
    user_curr_package_signer_depart             STRING COMMENT"用户当前套餐签单人部门",
    user_curr_package_contract_model            STRING COMMENT"用户下个套餐合作模式",

    ---上次套餐订单情况
    user_last_package_id                    int    COMMENT"用户上次套餐id",
    user_last_package_name                  STRING COMMENT"用户上次套餐名称",
    user_last_package_begin_date            STRING COMMENT"用户上次套餐开始日期",
    user_last_package_end_date              STRING COMMENT"用户上次套餐结束日期",
    user_last_package_add_date              STRING COMMENT"用户上次套餐添加日期",
    user_last_package_price                 int    COMMENT"用户上次套餐价格（分）",
    user_last_package_pay_amount            int    COMMENT"用户上次套餐实收金额（分）",
    user_last_package_role                  STRING COMMENT"用户上次套餐角色,供应商/分销商",
    user_last_package_classify_name         STRING COMMENT"用户上次套餐套餐组",
    --续费套餐信息
    user_next_package_id                    int    COMMENT"用户下个套餐id",
    user_next_package_name                  STRING COMMENT"用户下个套餐名称",
    user_next_package_begin_date            STRING COMMENT"用户下个套餐开始日期",
    user_next_package_end_date              STRING COMMENT"用户下个套餐结束日期",
    user_next_package_add_date              STRING COMMENT"用户下个套餐添加日期",
    user_next_package_price                 int    COMMENT"用户下个套餐价格（分）",
    user_next_package_pay_amount            int    COMMENT"用户下个套餐实收金额（分）",
    user_next_package_signer                STRING COMMENT"用户下个套餐签单人",
    user_next_package_signer_depart         STRING COMMENT"用户下个套餐签单人部门",
    user_next_package_contract_model        STRING COMMENT"用户下个套餐合作模式",

    --最后套餐信息
    user_end_package_id                     int    COMMENT"用户最终套餐id",
    user_end_package_name                   STRING COMMENT"用户最终套餐名称",
    user_end_package_begin_date             STRING COMMENT"用户最终套餐开始日期",
    user_end_package_end_date               STRING COMMENT"用户最终套餐结束日期",
    user_end_package_add_date               STRING COMMENT"用户最终套餐添加日期",
    user_end_package_price                  int    COMMENT"用户最终套餐价格（分）",
    user_end_package_pay_amount             int    COMMENT"用户最终套餐实收金额（分）"

 )COMMENT'商户套餐及订单情况'PARTITIONED BY(
    pt string
 )STORED AS ORC;





SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;


INSERT OVERWRITE TABLE dws_company_package_it_d_f  PARTITION(pt= ${ds})
SELECT ${ds} AS stat_date
    ,current_date AS dw_ins_time
    ,user_id
    ,IF(MAX(end_time) < current_date,
         IF(MAX(period_days) < 31, '试用未签约', '流失用户'),
         IF(SUM(IF(period_days >= 90, 1, 0)) > 1, '续费用户', 
             IF(MAX(period_days) < 31, '试用', '新用户'))) AS user_group
    ,min(case when package_open_id = first_supply_package_open_id then begin_time end) as user_first_supplier_begin_date
    ,min(case when package_open_id = first_supply_package_open_id then end_time end) as user_first_supplier_end_date
    ,min(case when package_open_id = first_supply_package_open_id then package_id end) as user_first_supplier_package_id
    ,min(case when package_open_id = first_supply_package_open_id then package_name end) as user_first_supplier_package_name
    ,min(case when package_open_id = first_supply_package_open_id then package_price end) as user_first_supplier_package_price
    ,min(case when package_open_id = first_supply_package_open_id then package_classify_name end) as user_first_supplier_package_classify_name
    ,min(case when package_open_id = first_supply_package_open_id then package_pay_amount end) as user_first_supplier_package_pay_amount
    ,min(case when package_open_id = first_supply_package_open_id then add_time end) as user_first_supplier_add_time
    ,min(case when package_open_id = first_package_open_id then begin_time end) as user_first_package_begin_date
    ,min(case when package_open_id = first_package_open_id then end_time end) as user_first_package_end_date
    ,max(case when package_open_id = first_package_open_id then package_id end) as user_first_package_id
    ,max(case when package_open_id = first_package_open_id then package_name end) as user_first_package_name
    ,max(case when package_open_id = first_package_open_id then package_price end) as user_first_package_price
    ,max(case when package_open_id = first_package_open_id then package_role end) as user_first_package_role
    ,max(case when package_open_id = first_package_open_id then package_classify_name end) as user_first_package_classify_name
    ,max(case when package_open_id = first_package_open_id then package_pay_amount end) as user_first_package_pay_amount
    ,max(case when package_open_id = first_package_open_id then add_time end) as user_first_add_time
    ,count(*) as user_package_num_buy
    ,sum(if(package_status <> '未到', 1, 0)) as user_package_num_used
    ,max(package_price) as max_package_price
    ,sum(package_pay_amount) as sum_pay_amount_package
    ,sum(package_price) as sum_price_package
    ,max(case when package_open_id = curr_package_open_id then package_id end) as user_curr_package_id
    ,max(case when package_open_id = curr_package_open_id then package_name end) as user_curr_package_name
    ,max(case when package_open_id = curr_package_open_id then begin_time end) as user_curr_package_begin_date
    ,max(case when package_open_id = curr_package_open_id then end_time end) as user_curr_package_end_date
    ,max(case when package_open_id = curr_package_open_id then add_time end) as user_curr_package_add_date
    ,max(case when package_open_id = curr_package_open_id then package_price end) as user_curr_package_price
    ,max(case when package_open_id = curr_package_open_id then package_pay_amount end) as user_curr_package_pay_amount
    ,max(case when package_open_id = curr_package_open_id then package_role end) as user_curr_package_role
    ,max(case when package_open_id = curr_package_open_id then package_classify_name end) as user_curr_package_classify_name
    ,max(case when package_open_id = curr_package_open_id then sale_man_name end) as user_curr_package_signer
    ,max(case when package_open_id = curr_package_open_id then sale_man_department end) as user_curr_package_signer_depart
    ,max(case when package_open_id = curr_package_open_id then user_contract_model end) as user_curr_package_contract_model
    ,max(case when package_open_id = last_package_open_id then package_id end) as user_last_package_id
    ,max(case when package_open_id = last_package_open_id then package_name end) as user_last_package_name
    ,max(case when package_open_id = last_package_open_id then begin_time end) as user_last_package_begin_date
    ,max(case when package_open_id = last_package_open_id then end_time end) as user_last_package_end_date
    ,max(case when package_open_id = last_package_open_id then add_time end) as user_last_package_add_date
    ,max(case when package_open_id = last_package_open_id then package_price end) as user_last_package_price
    ,max(case when package_open_id = last_package_open_id then package_pay_amount end) as user_last_package_pay_amount
    ,max(case when package_open_id = last_package_open_id then package_role end) as user_last_package_role
    ,max(case when package_open_id = last_package_open_id then package_classify_name end) as user_last_package_classify_name
    ,max(case when package_open_id = next_package_open_id then package_id end) as user_next_package_id
    ,max(case when package_open_id = next_package_open_id then package_name end) as user_next_package_name
    ,max(case when package_open_id = next_package_open_id then begin_time end) as user_next_package_begin_date
    ,max(case when package_open_id = next_package_open_id then end_time end) as user_next_package_end_date
    ,max(case when package_open_id = next_package_open_id then add_time end) as user_next_package_add_date
    ,max(case when package_open_id = next_package_open_id then package_price end) as user_next_package_price
    ,max(case when package_open_id = next_package_open_id then package_pay_amount end) as user_next_package_pay_amount
    ,max(case when package_open_id = next_package_open_id then sale_man_name end) as user_next_package_signer
    ,max(case when package_open_id = next_package_open_id then sale_man_department end) as user_next_package_signer_depart
    ,max(case when package_open_id = next_package_open_id then user_contract_model end) as user_next_package_contract_model
    ,max(case when package_open_id = end_package_open_id then package_id end) as user_end_package_id
    ,max(case when package_open_id = end_package_open_id then package_name end) as user_end_package_name
    ,max(case when package_open_id = end_package_open_id then begin_time end) as user_end_package_begin_date
    ,max(case when package_open_id = end_package_open_id then end_time end) as user_end_package_end_date
    ,max(case when package_open_id = end_package_open_id then add_time end) as user_end_package_add_date
    ,max(case when package_open_id = end_package_open_id then package_price end) as user_end_package_price
    ,max(case when package_open_id = end_package_open_id then package_pay_amount end) as user_end_package_pay_amount
FROM (
    SELECT *
        ,FIRST_VALUE( case when package_role = '供应商' then package_open_id end, true)
				OVER (PARTITION BY user_id ORDER BY case when package_role = '供应商' then add_time end ASC NULLS LAST
				       ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING
                     ) AS first_supply_package_open_id
		,FIRST_VALUE(package_open_id, true) OVER (partition by user_id order by add_time asc
                 ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING
             ) AS first_package_open_id
        ,max(case when package_status = '当前' then package_open_id end) over (partition by user_id) as curr_package_open_id
        ,FIRST_VALUE(case when package_status = '过期' then package_open_id end,true)
		        OVER (partition by user_id order by end_time desc
                       ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING
                     ) AS last_package_open_id
        ,FIRST_VALUE(case when package_status = '未到' then package_open_id end,true)
				OVER (partition by user_id order by begin_time asc
                       ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING
                     ) AS next_package_open_id
        ,max(package_open_id) over (partition by user_id) as end_package_open_id
    from dwd_user_package_d_f 
    where pt= ${ds} and stop_type <> '作废'
) as user_packages
group by user_id;











