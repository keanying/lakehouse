--EMR Spark SQL
--********************************************************************--
--author: 施建伟
--create time: 2026-04-03 15:11:30
--EMR任务只能运行在独享资源组上

-- '支付方式：0 = 余额支付,1 = 支付宝,2 = 授信支付,3 = 产品自销,4 = 现场支付,5 = 微信支付,6 = 会员卡支付,7 = 银联支付,8 = 环迅支付,9 = 现金支付,10 = 会员卡,11 = 拉卡拉（商户）,12 = 拉卡拉（平台）,13 = 特权支付（年卡）,14 = 微信（聚合）,15 = 平安银行,16 = 支付宝（聚合）,17 = 会员卡支付,18 = 计时卡支付,25 = 招行一网通支付,26 = 银联商务支付,27 = 银联商务POS支付,28 = 威富通支付,29 = 易宝云企付,33 = 博思支付,35 = 积分支付,36 = POS支',
-- drop table dwd_sales_tr_marketing_order_d_f;
--alter table dwd_sales_tr_marketing_order_d_f         DROP IF EXISTS PARTITION (pt=${before6day});
--********************************************************************--


create table if NOT EXISTS  dwd_sales_tr_marketing_order_d_f(
    stat_date                        STRING COMMENT '统计日期',
    dw_ins_time                      STRING COMMENT '插入时间',

    order_id                         STRING COMMENT '订单号',
    marketing_publisher_id           INT    COMMENT '营销活动发布商id',
    marketing_type                   STRING COMMENT '营销活动类型',
    ticket_num                       INT    COMMENT '票数',
    booking_time                     STRING COMMENT '订单时间',
    reduce_pay                       INT    COMMENT '优惠金额'
)PARTITIONED BY(
    pt string
 )STORED AS ORC;






SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;



INSERT OVERWRITE  TABLE dwd_sales_tr_marketing_order_d_f PARTITION (pt= ${ds}) 
-- 限时抢购--pft001
SELECT ${ds}                     as stat_date,
        current_date()                          as dw_ins_time,
        ordernum                                as order_id,
        CAST(sid AS INT)                        as marketing_publisher_id,
        '限时抢购'                              as marketing_type,
        CAST(tnum AS INT)                       as ticket_num,
        from_unixtime(create_time)              as booking_time,
        0                                       as reduce_pay
from (SELECT *
      from (select distinct ordernum,tnum,seckill_id,create_time
            from ods_sales_pft_seckill_log_d_f    --it_project.ods_sales_pft_seckill_log_d_f
            where pt= ${ds}
            and not isnull(ordernum) and ordernum<>'' and activity_id>0
          )  sl
      left join (select id,activity_id,sid from ods_sales_pft_seckill_d_f where pt= ${ds}) s  --it_project.ods_sales_pft_seckill_d_f
          on s.activity_id=sl.seckill_id
      
      UNION ALL 
      SELECT *
      from (select distinct ordernum,tnum,seckill_id,create_time
            from ods_sales_pft_seckill_log_d_f    --it_project.ods_sales_pft_seckill_log_d_f
            where pt= ${ds}
            and not isnull(ordernum) and ordernum<>'' and activity_id=0
          )  sl
      left join (select id,activity_id,sid from ods_sales_pft_seckill_d_f where pt= ${ds}) s   --it_project.ods_sales_pft_seckill_d_f
          on s.id=sl.seckill_id
    ) o


-- 砍价（19800套餐）--pft001
union all
select ${ds}                     as stat_date,
        current_date()                            as dw_ins_time,

        cut.ordernum                              as order_id,
        CAST(cut.sid AS INT)                      as marketing_publisher_id,
        '砍价'                                    as marketing_type,
        0                                         as ticket_num,
        from_unixtime(cut.update_time)            as booking_time,
        0                                         as reduce_pay
from (select * from ods_sales_pft_cut_price_join_d_f where pt= ${ds} and status=2) cut   --it_project.ods_sales_pft_cut_price_join_d_f


-- 拼团(19800套餐)--pft001
union all
select ${ds}                        as stat_date,
        current_date()                               as dw_ins_time,
        group_booking.ordernum                       as order_id,
      CAST(  substr(group_booking.data,LOCATE('"upAid":',group_booking.data)+8,LOCATE(',"openid":',group_booking.data)-LOCATE('"upAid":',group_booking.data)-8) AS INT)    as marketing_publisher_id,
        '拼团'                                       as marketing_type,
      CAST( substr(group_booking.data,LOCATE('"tnum":',group_booking.data)+7,LOCATE(',"price":',group_booking.data)-LOCATE('"tnum":',group_booking.data)-7) AS INT)      as ticket_num,
        from_unixtime(group_booking.create_time)     as booking_time,
        0                                            as reduce_pay
from  (select * from ods_sales_pft_group_booking_orders_d_f   --it_project.ods_sales_pft_group_booking_orders_d_f
       where pt= ${ds}
       and substr(`data`,LOCATE('"group_id":',`data`)+11,LOCATE(',"open_id":',`data`)-LOCATE('"group_id":',`data`)-11)>0
      ) group_booking



-- 全民分销--pft002
UNION ALL 
select ${ds}                   as stat_date,
        current_date()                          as dw_ins_time,

        all_dis.order_id                        as order_id,
        CAST(all_dis.sid AS INT)                as marketing_publisher_id,
        '全民营销'                              as marketing_type,
        CAST(all_dis.tnum AS INT)                            as ticket_num,
        from_unixtime(all_dis.create_time)      as booking_time,
        0                                       as reduce_pay
from (select distinct sid,order_id,tnum,create_time from ods_sales_pft_all_dis_orders_d_f where pt= ${ds} and is_new=1) all_dis     --it_project.ods_sales_pft_all_dis_orders_d_f



-- 新版优惠券--myuu
union all
select ${ds}                   as stat_date,
        current_date()                          as dw_ins_time,

        coupons.use_order_num                   as order_id,
        CAST(coupons.aid AS INT)               as marketing_publisher_id,
        '优惠券'                                as marketing_type,
        CAST(cnum AS INT)                                    as ticket_num,
        from_unixtime(coupons.use_time)         as booking_time,
        CAST(all_use_coupon_money AS INT)                    as reduce_pay
from (select * from ods_sales_pft_coupon_use_log_d_f where pt= ${ds} and status=2) coupons    --it_project.ods_sales_pft_coupon_use_log_d_f
LEFT JOIN
    (SELECT use_order_num,count(*) as cnum
     from (select use_order_num,explode(split(coupon_code,',')) from ods_sales_pft_coupon_use_log_d_f where pt= ${ds} and status=2) cu  --it_project.ods_sales_pft_coupon_use_log_d_f
     GROUP BY use_order_num
    ) mc
    on coupons.use_order_num=mc.use_order_num