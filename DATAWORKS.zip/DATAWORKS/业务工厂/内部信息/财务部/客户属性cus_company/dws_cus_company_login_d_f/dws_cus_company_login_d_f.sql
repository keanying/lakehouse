--@exclude_input=default_workspace_svwh.default.dwd_user_package_d_f
--@exclude_input=default_workspace_svwh.default.dwd_user_package_d_f
--EMR Spark SQL
--********************************************************************--
--author: 施建伟
--create time: 2026-03-27 14:23:07
--EMR任务只能运行在独享资源组上
--登录汇总
--********************************************************************--



create table if NOT EXISTS  dws_cus_company_login_d_f(
    stat_date                             STRING COMMENT '统计日期',
    dw_ins_time                           STRING COMMENT '插入时间',

    user_id                               int comment '商户id',

    login_num_plat_curr_week              int COMMENT '本周登录平台次数',
    login_num_terminal_curr_week          int COMMENT '本周登录终端次数',
    login_date_num_plat_curr_week         int COMMENT '本周登录平台天数',
    login_date_num_terminal_curr_week     int COMMENT '本周登录终端天数',
    login_num_plat_last_week              int COMMENT '上周登录平台次数',
    login_num_terminal_last_week          int COMMENT '上周登录终端次数',
    login_date_num_plat_last_week         int COMMENT '上周登录平台天数',
    login_date_num_terminal_last_week     int COMMENT '上周登录终端天数',
    
    login_num_plat_curr_month             int COMMENT '本月登录平台次数',
    login_num_terminal_curr_month         int COMMENT '本月登录终端次数',
    login_date_num_plat_curr_month        int COMMENT '本月登录平台天数',
    login_date_num_terminal_curr_month    int COMMENT '本月登录终端天数',
    login_num_plat_last_month             int COMMENT '上月登录平台次数',
    login_num_terminal_last_month         int COMMENT '上月登录终端次数',
    login_date_num_plat_last_month        int COMMENT '上月登录平台天数',
    login_date_num_terminal_last_month    int COMMENT '上月登录终端天数',

    login_num_plat_curr_quarter           int COMMENT '本季登录平台次数',
    login_num_terminal_curr_quarter       int COMMENT '本季登录终端次数',
    login_date_num_plat_curr_quarter      int COMMENT '本季登录平台天数',
    login_date_num_terminal_curr_quarter  int COMMENT '本季登录终端天数',
    login_num_plat_last_quarter           int COMMENT '上季登录平台次数',
    login_num_terminal_last_quarter       int COMMENT '上季登录终端次数',
    login_date_num_plat_last_quarter      int COMMENT '上季登录平台天数',
    login_date_num_terminal_last_quarter  int COMMENT '上季登录终端天数',


    login_num_plat_60_day  int COMMENT '近60天登录终端次数',
    login_num_terminal_60_day  int COMMENT '近60天登录终端次数',
    login_date_num_plat_60_day  int COMMENT '近60天登录终端天数',
    login_date_num_terminal_60_day  int COMMENT '近60天登录终端天数'


)COMMENT'登录汇总' PARTITIONED BY(
    pt STRING  
 )STORED AS ORC;





SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;



-- 仅筛选商户
INSERT OVERWRITE  TABLE dws_cus_company_login_d_f PARTITION (pt= ${ds}) 
SELECT ${ds} as stat_date,
        current_date() as dw_ins_time,

        user_id,
        --本周
        count(if(login_source<>2 and weekofyear(login_time)=weekofyear(current_date()) and year(login_time)=year(current_date),login_time,null)) as login_num_plat_curr_week,
        count(if(login_source=2  and weekofyear(login_time)=weekofyear(current_date()) and year(login_time)=year(current_date),login_time,null)) as login_num_terminal_curr_week,
        count(distinct if(login_source<>2 and weekofyear(login_time)=weekofyear(current_date()) and year(login_time)=year(current_date),to_date(login_time),null)) as login_date_num_plat_curr_week,
        count(distinct if(login_source=2 and weekofyear(login_time)=weekofyear(current_date()) and year(login_time)=year(current_date),to_date(login_time),null)) as login_date_num_terminal_curr_week,
        --上周
        count(if(login_source<>2 and weekofyear(login_time)=weekofyear(date_sub(current_date(),7)),login_time,null)) as login_num_plat_last_week,
        count(if(login_source=2 and weekofyear(login_time)=weekofyear(date_sub(current_date(),7)),login_time,null)) as login_num_terminal_last_week,
        count(distinct if(login_source<>2 and weekofyear(login_time)=weekofyear(date_sub(current_date(),7)),to_date(login_time),null)) as login_date_num_plat_last_week,
        count(distinct if(login_source=2 and weekofyear(login_time)=weekofyear(date_sub(current_date(),7)),to_date(login_time),null)) as login_date_num_terminal_last_week,

        --本月
        count(if(login_source<>2 and date_format(login_time,'yyyyMM')=date_format(add_months(current_date(), -0), 'yyyyMM') ,login_time,null)) as login_num_plat_curr_month,
        count(if(login_source=2 and date_format(login_time,'yyyyMM')=date_format(add_months(current_date(), -0), 'yyyyMM') ,login_time,null)) as login_num_terminal_curr_month,
        count(distinct if(login_source<>2 and date_format(login_time,'yyyyMM')=date_format(add_months(current_date(), -0), 'yyyyMM'),to_date(login_time),null)) as login_date_num_plat_curr_month,
        count(distinct if(login_source=2 and date_format(login_time,'yyyyMM')=date_format(add_months(current_date(), -0), 'yyyyMM'),to_date(login_time),null)) as login_date_num_terminal_curr_month,

        --上月
        count(if(login_source<>2 and date_format(login_time,'yyyyMM')=date_format(add_months(current_date(), -1), 'yyyyMM'),login_time,null)) as login_num_plat_last_month,
        count(if(login_source=2 and date_format(login_time,'yyyyMM')=date_format(add_months(current_date(), -1), 'yyyyMM'),login_time,null)) as login_num_terminal_last_month,
        count(distinct if(login_source<>2 and date_format(login_time,'yyyyMM')=date_format(add_months(current_date(), -1), 'yyyyMM'),to_date(login_time),null)) as login_date_num_plat_last_month,
        count(distinct if(login_source=2 and date_format(login_time,'yyyyMM')=date_format(add_months(current_date(), -1), 'yyyyMM'),to_date(login_time),null)) as login_date_num_terminal_last_month,

        --本季
        count(if(login_source<>2 and quarter(login_time)=quarter(current_date()) and year(login_time)=year(current_date),login_time,null)) as login_num_plat_curr_quarter,
        count(if(login_source=2 and quarter(login_time)=quarter(current_date()) and year(login_time)=year(current_date),login_time,null)) as login_num_terminal_curr_quarter,
        count(distinct if(login_source<>2 and quarter(login_time)=quarter(current_date()) and year(login_time)=year(current_date),to_date(login_time),null)) as login_date_num_plat_curr_quarter,
        count(distinct if(login_source=2 and quarter(login_time)=quarter(current_date()) and year(login_time)=year(current_date),to_date(login_time),null)) as login_date_num_terminal_curr_quarter,

        --上季
        count(if(login_source<>2 and quarter(login_time)=quarter(date_sub(current_date(),91)) and year(login_time)=year(date_sub(current_date,91)),login_time,null)) as login_num_plat_last_quarter,
        count(if(login_source=2 and quarter(login_time)=quarter(date_sub(current_date(),91)) and year(login_time)=year(date_sub(current_date,91)),login_time,null)) as login_num_terminal_last_quarter,
        count(distinct if(login_source<>2 and quarter(login_time)=quarter(date_sub(current_date(),91)) and year(login_time)=year(date_sub(current_date,91)),to_date(login_time),null)) as login_date_num_plat_last_quarter,
        count(distinct if(login_source=2 and quarter(login_time)=quarter(date_sub(current_date(),91)) and year(login_time)=year(date_sub(current_date,91)),to_date(login_time),null)) as login_date_num_terminal_last_quarter,

        --近60天
        count(if(login_source<>2 and substr(login_time,1,7)>=date_sub(current_date,60) and substr(login_time,1,7)<current_date ,login_time,null)) as login_num_plat_60_day,
        count(if(login_source=2 and substr(login_time,1,7)>=date_sub(current_date,60) and substr(login_time,1,7)<current_date,login_time,null)) as login_num_terminal_60_day,
        count(distinct if(login_source<>2 and substr(login_time,1,7)>=date_sub(current_date,60) and substr(login_time,1,7)<current_date,to_date(login_time),null)) as login_date_num_plat_60_day,
        count(distinct if(login_source=2 and substr(login_time,1,7)>=date_sub(current_date,60) and substr(login_time,1,7)<current_date,to_date(login_time),null)) as login_date_num_terminal_60_day



from dwd_company_login_d_f
where pt= ${ds} and login_time>=date_sub(current_date,100) 
group by user_id;




