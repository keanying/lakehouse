--EMR Spark SQL
--********************************************************************--
--author: 施建伟
--create time: 2026-03-27 16:11:34
--EMR任务只能运行在独享资源组上
--商户 自供应产品、转分销产品
--********************************************************************--


create table if NOT EXISTS dws_cus_company_prod_d_f(
    stat_date                             STRING COMMENT"统计日期",
    dw_ins_time                           STRING COMMENT"数据插入日期",
    
    user_id                               INT    COMMENT"用户id",
    
    first_add_ticket_time                 string COMMENT "首次添加票时间",
    end_edit_ticket_time                  string COMMENT "最后编辑票时间",

    ticket_num_self                       int COMMENT "自供应产品票种数（上架且未过期）",
    land_num_self                         int COMMENT "自供应产品数（上架且未过期）",
    resource_num_self                     int COMMENT "自供应资源数（上架且未过期）",
    not_link_resource_landnum             int COMMENT "未关联资源产品数（上架且未过期）",

    off_shelf_ticket_num_self             INT COMMENT '下架自供应产品票种数',  
    off_shelf_land_num_self               INT COMMENT '下架自供应产品数',  
    off_shelf_resource_num_self           INT COMMENT '下架自供应资源数',

    overdue_ticket_num_self               INT COMMENT '过期自供应产品票种数',  
    overdue_land_num_self                 INT COMMENT '过期自供应产品数',  
    overdue_resource_num_self             INT COMMENT '过期自供应资源数',

    add_ticket_num_self_curr_week         INT COMMENT '本周新编辑自供应票种数',  
    add_land_num_self_curr_week           INT COMMENT '本周新编辑自供应产品数',  
    add_resource_num_self_curr_week       INT COMMENT '本周新编辑自供应资源数',

    add_ticket_num_self_curr_month        INT COMMENT '本月新编辑自供应票种数',  
    add_land_num_self_curr_month          INT COMMENT '本月新编辑自供应产品数',  
    add_resource_num_self_curr_month      INT COMMENT '本月新编辑自供应资源数',

    add_ticket_num_self_curr_quarter      INT COMMENT '本季新编辑自供应票种数',  
    add_land_num_self_curr_quarter        INT COMMENT '本季新编辑自供应产品数',  
    add_resource_num_self_curr_quarter    INT COMMENT '本季新编辑自供应资源数',  


    ticket_num_dist                       int COMMENT"分销票种数",
    land_num_dist                         int COMMENT"分销产品数",
    resource_num_dist                     int COMMENT"分销资源数"

 )COMMENT'商户销售产品数量表'PARTITIONED BY(
    pt int
 )STORED AS ORC;




SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;


-- 自供应产品
INSERT OVERWRITE TABLE dws_cus_company_prod_d_f  PARTITION(pt= ${ds})
select
      ${ds}                 as stat_date,
      current_date                          as dw_ins_time,

      l.user_id                             as user_id,
      
      l.first_add_ticket_time               as first_add_ticket_time,
      l.end_edit_ticket_time                as end_edit_ticket_time,
      
      l.ticket_num_self                     as ticket_num_self,

      l.land_num_self                       as land_num_self,
      l.resource_num_self                   as resource_num_self,
      l.no_link_resource_land_num           as no_link_resource_land_num,

      
      l.off_shelf_ticket_num_self           as off_shelf_ticket_num_self,
      l.off_shelf_land_num_self             as off_shelf_land_num_self,
      l.off_shelf_resource_num_self         as off_shelf_resource_num_self, 

      l.overdue_ticket_num_self             as overdue_ticket_num_self,
      l.overdue_land_num_self               as overdue_land_num_self,
      l.overdue_resource_num_self           as overdue_resource_num_self, 

      l.add_ticket_num_self_curr_week       as add_ticket_num_self_curr_week,
      l.add_land_num_self_curr_week         as add_land_num_self_curr_week,
      l.add_resource_num_self_curr_week     as add_resource_num_self_curr_week, 

      l.add_ticket_num_self_curr_month      as add_ticket_num_self_curr_month,
      l.add_land_num_self_curr_month        as add_land_num_self_curr_month,
      l.add_resource_num_self_curr_month    as add_resource_num_self_curr_month,

      l.add_ticket_num_self_curr_quarter      as add_ticket_num_self_curr_quarter,
      l.add_land_num_self_curr_quarter        as add_land_num_self_curr_quarter,
      l.add_resource_num_self_curr_quarter    as add_resource_num_self_curr_quarter,

      dis.ticket_num_dist                     as ticket_num_dist, 
      dis.land_num_dist                       as land_num_dist, 
      dis.resource_num_dist                   as resource_num_dist

from (select land_publisher_id as user_id,
             min(ticket_update_time)                                                             as first_add_ticket_time,
             max(ticket_update_time)                                                             as end_edit_ticket_time,

             count(distinct if(ticket_status='上架' , ticket_id,null))                            as ticket_num_self,
             count(distinct if(ticket_status='上架' , land_id,null))                              as land_num_self,
             count(distinct if(ticket_status='上架' and resource_id>0,resource_id,null))          as resource_num_self, 
             count(distinct if(ticket_status='上架' and resource_id=0 ,land_id,null))             as no_link_resource_land_num,

             count(distinct if(ticket_status='下架'  , ticket_id,null))                           as off_shelf_ticket_num_self,
             count(distinct if(ticket_status='下架'  , land_id,null))                             as off_shelf_land_num_self,
             count(distinct if(ticket_status='下架' and resource_id>0,resource_id,null))          as off_shelf_resource_num_self, 

             count(distinct if(ticket_status='过期', ticket_id,null))                             as overdue_ticket_num_self,
             count(distinct if(ticket_status='过期', land_id,null))                               as overdue_land_num_self,
             count(distinct if(ticket_status='过期' and resource_id>0,resource_id,null))          as overdue_resource_num_self, 

             count(distinct if(weekofyear(ticket_update_time)=weekofyear(current_date) and year(ticket_update_time)=year(current_date), ticket_id,null))                            as add_ticket_num_self_curr_week,
             count(distinct if(weekofyear(ticket_update_time)=weekofyear(current_date) and year(ticket_update_time)=year(current_date), land_id,null))                              as add_land_num_self_curr_week,
             count(distinct if(weekofyear(ticket_update_time)=weekofyear(current_date) and year(ticket_update_time)=year(current_date) and resource_id>0,resource_id,null))         as add_resource_num_self_curr_week, 

             count(distinct if(to_date(ticket_update_time)>=trunc(current_date,'MM'), ticket_id,null))                                                                              as add_ticket_num_self_curr_month,
             count(distinct if(to_date(ticket_update_time)>=trunc(current_date,'MM'), land_id,null))                                                                                as add_land_num_self_curr_month,
             count(distinct if(to_date(ticket_update_time)>=trunc(current_date,'MM') and resource_id>0,resource_id,null))                                                           as add_resource_num_self_curr_month, 

             count(distinct if(quarter(ticket_update_time)=quarter(current_date) and year(ticket_update_time)=year(current_date), ticket_id,null))                                  as add_ticket_num_self_curr_quarter,
             count(distinct if(quarter(ticket_update_time)=quarter(current_date) and year(ticket_update_time)=year(current_date), land_id,null))                                    as add_land_num_self_curr_quarter,
             count(distinct if(quarter(ticket_update_time)=quarter(current_date) and year(ticket_update_time)=year(current_date) and resource_id>0,resource_id,null))               as add_resource_num_self_curr_quarter

      from dim_prod_d_f     --data_middle_bi.dim_prod_d_f
      where pt= ${ds}    -- and ticket_status_code<3               --非删除状态
      group by land_publisher_id
    ) l
left join
    (SELECT distributor_id as user_id,
             count(distinct ticket_id) ticket_num_dist,
             count(distinct land_id) land_num_dist,
             count(distinct resource_id) resource_num_dist
      from dim_prod_distribute_d_f    --data_middle_bi.dim_prod_distribute_d_f
      where pt= ${ds}
      group by distributor_id
      ) dis
      on dis.user_id=l.user_id
;
























