--EMR Spark SQL
--********************************************************************--
--author: 施建伟
--create time: 2026-03-27 15:36:50
--EMR任务只能运行在独享资源组上
--company维度表
--********************************************************************--




create table if NOT EXISTS dim_cus_company_d_f(
	user_id                     		    	INT    	COMMENT '用户id',
    user_account_id             		    	INT    	COMMENT '账户id',
    user_customer_id            		    	INT    	COMMENT '客户ID',
    user_name                   		    	string 	COMMENT '用户名称/账户名称',
    user_company_name           		    	string 	COMMENT '企业名称',
    customer_name               		 		string 	COMMENT '客户名称',
    customer_mobile             		    	string 	COMMENT '客户手机号',
    user_type_code              		    	int 	COMMENT '用户类型编码',
    user_type                   		    	string 	COMMENT '用户类型(供应商/分销商等)',
    user_is_test                		    	string 	COMMENT '测试账号？(正式/测试)',
    user_status                 		    	string 	COMMENT '用户状态',
    customer_certi_status_code  		    	int    	COMMENT '客户资质审核状态编码',
    customer_certi_status       		    	string 	COMMENT '客户资质审核状态',
    customer_country            		    	string 	COMMENT '客户国家',
    customer_province           		    	string 	COMMENT '客户省',
    customer_city               		    	string 	COMMENT '客户市',
    customer_type_code          		    	INT    	COMMENT '客户类型编码',
    customer_type               		    	string 	COMMENT '客户类型(旅行社/景区)',
    user_land_topic             		    	string 	COMMENT '景区业态',
    user_level                  				string 	COMMENT '级别',
    user_contract_model_code    		    	int 	COMMENT '合作模式编码',
    user_contract_model         		    	string 	COMMENT '合作模式',
    signer_id                   		    	int 	COMMENT '签单人id',
    signer                      		    	string 	COMMENT '签单人姓名',
    servicer_id                 		    	int 	COMMENT '客服id',
    servicer                    		    	string 	COMMENT '客服姓名',
    user_regist_time            		    	string 	COMMENT '用户注册时间',
    user_contarct_firstdate     		    	string 	COMMENT '用户首次合日期',
    user_login_lasttime         		    	string 	COMMENT '用户上次登录时间',
	
    -- 合作伙伴情况	
    first_add_distributor_time           		string 	comment '首次添加分销商时间',
    end_edit_distributor_time            		string 	comment '最后编辑分销商时间',
	
    partner_num_supp                    		INT    	COMMENT '供应商数',  
    partner_num_ota                     		INT    	COMMENT 'OTA数',
    partner_num_dist                    		INT    	COMMENT '分销商数',
    partner_num_staff                   		INT    	COMMENT '员工数',
    partner_num_ticket_system           		INT    	COMMENT '票务系统数',
    partner_ticket_system_list          		string 	COMMENT '票务系统列表',
		
    -- 销售产品情况		
    first_add_ticket_time               		string 	comment '首次添加票时间',
    end_edit_ticket_time                		string 	comment '最后编辑票时间',
		
    onsale_ticket_num_self              		INT    	COMMENT '在售自供应产品票种数,不包含删除',  
    onsale_land_num_self                		INT    	COMMENT '在售自供应产品数,不包含删除',  
    onsale_resource_num_self            		INT    	COMMENT '在售自供应资源数,不包含删除',  
    onsale_land_num_dist                		INT    	COMMENT '分销产品数，有分销票的产品（过滤删除票）',  
		
    off_shelf_ticket_num_self           		INT		COMMENT '下架自供应产品票种数',  
    off_shelf_land_num_self             		INT 	COMMENT '下架自供应产品数',  
    off_shelf_resource_num_self         		INT 	COMMENT '下架自供应资源数',
			
    overdue_ticket_num_self             		INT 	COMMENT '上架过期自供应产品票种数',  
    overdue_land_num_self               		INT 	COMMENT '上架过期自供应产品数',  
    overdue_resource_num_self           		INT 	COMMENT '上架过期自供应资源数',
			
    add_ticket_num_self_curr_week       		INT 	COMMENT '本周新编辑自供应票种数',  
    add_land_num_self_curr_week         		INT 	COMMENT '本周新编辑自供应产品数',  
    add_resource_num_self_curr_week     		INT 	COMMENT '本周新编辑自供应资源数',
			
    add_ticket_num_self_curr_month      		INT 	COMMENT '本月新编辑自供应票种数',  
    add_land_num_self_curr_month        		INT 	COMMENT '本月新编辑自供应产品数',  
    add_resource_num_self_curr_month    		INT 	COMMENT '本月新编辑自供应资源数',
			
    add_ticket_num_self_curr_quarter    		INT 	COMMENT '本季新编辑自供应票种数',  
    add_land_num_self_curr_quarter      		INT 	COMMENT '本季新编辑自供应产品数',  
    add_resource_num_self_curr_quarter  		INT 	COMMENT '本季新编辑自供应资源数',  
	
	ticket_num_dist    							INT 	COMMENT '分销票种数',
    land_num_dist    							INT 	COMMENT '分销产品数',
    resource_num_dist    						INT 	COMMENT '分销资源数',
	
    --购买套餐情况	
	amount_package                 				int 	comment '套餐费合计',
    user_package_num_buy                    	int    	COMMENT '用户购买套餐次数',
    user_package_num_used                   	int    	COMMENT '用户已用套餐次数',
															    
    user_first_supplier_begindate               string 	COMMENT '用户第一次合作供应商套餐开始日期',
    user_first_supplier_enddate                 string 	comment '用户第一次合作供应商套餐结束日期',
    user_first_supplier_package_id              string 	COMMENT '用户第一次合作供应商套餐ID',
    user_first_supplier_package_name            string 	COMMENT '用户第一次合作供应商套餐名称',
    user_first_supplier_package_price           string 	COMMENT '用户第一次合作供应商套餐价格',
    user_first_supplier_package_classify_name   string 	COMMENT '用户第一次合作供应商套餐组',
    user_first_supplier_package_pay_amount      int    	COMMENT '用户第一次合作供应商实收金额（分）',
    user_first_supplier_add_time                string 	COMMENT '用户第一次合作供应添加时间',
															    
    user_first_package_begindate                string 	COMMENT '用户第一次合作套餐开始日期',
    user_first_package_enddate                  string 	comment '用户第一次合作套餐结束日期',
    user_first_package_id                       INT    	COMMENT '用户第一次套餐id',
    user_first_package_name                     string 	COMMENT '用户第一次套餐名称',
    user_first_package_price                    int    	COMMENT '用户第一次套餐价格(分)',
    user_first_package_role                     string 	COMMENT '用户第一次套餐角色,供应商/分销商',
    user_first_package_classify_name            string 	COMMENT '用户第一次套餐套餐组',
    user_first_package_pay_amount               int    	COMMENT '用户第一次套餐实收金额（分）',
    user_first_add_time                         string 	COMMENT '用户第一次套餐添加日期',
	
    user_curr_package_id                        INT    	COMMENT '用户当前套餐id',
    user_curr_package_name                      string 	COMMENT '用户当前套餐名称',
    user_curr_package_adddate                   string 	COMMENT '用户当前套餐签约日期',
    user_curr_package_begindate                 string 	COMMENT '用户当前套餐开始日期',
    user_curr_package_enddate                   string 	COMMENT '用户当前套餐结束日期',
    user_curr_package_price                     int    	COMMENT '用户当前套餐价格(分)',
    user_curr_package_pay_amount                int    	COMMENT '用户当前套餐实收金额(分)',
    user_curr_package_role                      string 	COMMENT '用户当前套餐角色',
    user_curr_package_classify_name             string 	COMMENT '用户当前套餐套餐组',
    user_curr_package_diff_month                int    	COMMENT '用户当前套餐套餐周期（月）',
    user_curr_package_avg_pay_amount            int    	COMMENT '用户当前套餐客单价（分）',
    user_curr_package_signer                    string 	COMMENT '用户当前套餐签单人',
    --user_curr_package_signer_depart           string 	COMMENT '用户当前套餐签单人部门',
    user_curr_package_prepay_months             int    	comment '用户当前套餐提前续费月数',
    user_curr_package_contract_model            string 	comment '用户当前套餐合作模式',
	
    user_last_package_id                        int    	COMMENT '用户上次套餐id',
    user_last_package_name                      string 	COMMENT '用户上次套餐名称',
    user_last_package_adddate                   string 	COMMENT '用户上次套餐签约日期',
    user_last_package_begindate                 string 	COMMENT '用户上次套餐开始日期',
    user_last_package_enddate                   string 	COMMENT '用户上次套餐结束日期',
    user_last_package_price                     int    	COMMENT '用户上次套餐价格（分）',
    user_last_package_pay_amount                int    	COMMENT '用户上次套餐实收金额(分)',
    user_last_package_role                      string 	COMMENT '用户上次套餐角色',
    user_last_package_classify_name             string 	COMMENT '用户上次套餐套餐组',
    user_last_package_diff_month                int    	COMMENT '用户上次套餐套餐周期（月）',
    user_last_package_avg_pay_amount            int    	COMMENT '用户上次套餐客单价（分）',

    --续费套餐信息
    user_next_package_id                        int    	COMMENT '用户下个套餐id',
    user_next_package_name                      string 	COMMENT '用户下个套餐名称',
    user_next_package_add_date                  string 	COMMENT '用户下个套餐签约日期',
    user_next_package_begin_date                string 	COMMENT '用户下个套餐开始日期',
    user_next_package_end_date                  string 	COMMENT '用户下个套餐结束日期',
    user_next_package_price                     int    	COMMENT '用户下个套餐价格（分）',
    user_next_package_pay_amount                int    	COMMENT '用户下个套餐实收金额（分）',
    user_next_package_signer                    string 	COMMENT '用户下个套餐签单人',
    --user_next_package_signer_depart           string 	COMMENT '用户下个套餐签单人部门',
    user_next_package_prepay_months             int    	comment '用户下个套餐提前续费月数',
    user_next_package_contract_model            string 	comment '用户下个套餐合作模式',
	
    user_end_package_id                         int    	COMMENT '用户最终套餐id',
    user_end_package_name                       string 	COMMENT '用户最终套餐名称',
    user_end_package_adddate                    string 	COMMENT '用户最终套餐签约日期',
    user_end_package_begindate                  string 	COMMENT '用户最终套餐开始日期',
    user_end_package_enddate                    string 	COMMENT '用户最终套餐结束日期',
    user_end_package_price                      int    	COMMENT '用户最终套餐价格（分）',
    user_end_package_pay_amount                 int    	COMMENT '用户最终套餐实收金额(分)',


    -- 登录情况
    login_num_plat_curr_week              		int 	COMMENT '本周登录平台次数',
    login_num_terminal_curr_week          		int 	COMMENT '本周登录终端次数',
    login_date_num_plat_curr_week         		int 	COMMENT '本周登录平台天数',
    login_date_num_terminal_curr_week     		int 	COMMENT '本周登录终端天数',
    login_num_plat_last_week              		int 	COMMENT '上周登录平台次数',
    login_num_terminal_last_week          		int 	COMMENT '上周登录终端次数',
    login_date_num_plat_last_week         		int 	COMMENT '上周登录平台天数',
    login_date_num_terminal_last_week     		int 	COMMENT '上周登录终端天数',
				
    login_num_plat_curr_month             		int 	COMMENT '本月登录平台次数',
    login_num_terminal_curr_month         		int 	COMMENT '本月登录终端次数',
    login_date_num_plat_curr_month        		int 	COMMENT '本月登录平台天数',
    login_date_num_terminal_curr_month    		int 	COMMENT '本月登录终端天数',
    login_num_plat_last_month             		int 	COMMENT '上月登录平台次数',
    login_num_terminal_last_month         		int 	COMMENT '上月登录终端次数',
    login_date_num_plat_last_month        		int 	COMMENT '上月登录平台天数',
    login_date_num_terminal_last_month    		int 	COMMENT '上月登录终端天数',
			
    login_num_plat_curr_quarter           		int 	COMMENT '本季登录平台次数',
    login_num_terminal_curr_quarter       		int 	COMMENT '本季登录终端次数',
    login_date_num_plat_curr_quarter      		int 	COMMENT '本季登录平台天数',
    login_date_num_terminal_curr_quarter  		int 	COMMENT '本季登录终端天数',
    login_num_plat_last_quarter           		int 	COMMENT '上季登录平台次数',
    login_num_terminal_last_quarter       		int 	COMMENT '上季登录终端次数',
    login_date_num_plat_last_quarter      		int 	COMMENT '上季登录平台天数',
    login_date_num_terminal_last_quarter  		int 	COMMENT '上季登录终端天数',

	-- 应用开通
	is_open_wsc  								int 	COMMENT '微商城（旧版）',
	is_open_hbtg  								int 	COMMENT '海报推广',
	is_open_sjlp  								int 	COMMENT '数据罗盘',
	is_open_qmyx  								int 	COMMENT '全民营销',
	is_open_yspzd  								int 	COMMENT '云售票终端',
	is_open_miniyzd 							int 	COMMENT 'MINI云终端',
	is_open_znyzj  								int 	COMMENT '智能云闸机',
	is_open_lyykt  								int 	COMMENT '旅游一卡通',
	is_open_ljgg  								int 	COMMENT '链接广告',
	is_open_zzsqpj  							int 	COMMENT '自助售取票机',
	is_open_appxz  								int 	COMMENT 'APP下载',
	is_open_xxpwxt  							int 	COMMENT '线下票务系统',
	is_open_jdxd  								int 	COMMENT '计调下单',
	is_open_yhqjb  								int 	COMMENT '优惠券(旧版)',
	is_open_lynk  								int 	COMMENT '旅游年卡',
	is_open_b2cscpcd  							int 	COMMENT 'B2C商城（PC端）',
	is_open_jszdrz  							int 	COMMENT '结算自动入帐',
	is_open_otaptfx  							int 	COMMENT 'OTA平台分销',
	is_open_typtfx  							int 	COMMENT '同业平台分销',
	is_open_fxdsfcp  							int 	COMMENT '分销第三方产品',
	is_open_wqglxt  							int 	COMMENT '温泉管理系统',
	is_open_jqpwxt  							int 	COMMENT '景区票务系统',
	is_open_yqykt  								int 	COMMENT '园区一卡通',
	is_open_zfxcp  								int 	COMMENT '转分销产品',
	is_open_dzfp  								int 	COMMENT '电子发票',
	is_open_xsqg  								int 	COMMENT '限时抢购',
	is_open_dsjfx  								int 	COMMENT '大数据分析',
	is_open_flgl  								int 	COMMENT '返利管理',
	is_open_mygxdj  							int 	COMMENT '蚂蚁供销对接',
	is_open_yzwscdj  							int 	COMMENT '有赞微商城对接',
	is_open_kjwsc  								int 	COMMENT '砍价(微商城)',
	is_open_ptwsc  								int 	COMMENT '拼团(微商城)',
	is_open_miniyxcx  							int 	COMMENT 'MiNi云小程序',
	is_open_jfsc  								int 	COMMENT '积分商城',
	is_open_fxzy  								int 	COMMENT '分销专员',
	is_open_hytx  								int 	COMMENT '会员体系',
	is_open_zghxf 								int 	COMMENT '公众号吸粉',
	is_open_hbffl 								int 	COMMENT '红包翻翻乐',
	is_open_zyzx  								int 	COMMENT '资源中心',
	is_open_wxzxwsc  							int 	COMMENT '微信直销（微商城）',
	is_open_xcxsc  								int 	COMMENT '小程序商城',
	is_open_yhq  								int 	COMMENT '优惠券',
	is_open_fsyy  								int 	COMMENT '分时预约',
	is_open_gzhyx  								int 	COMMENT '公众号营销',
	is_open_xcxpro  							int 	COMMENT '小程序Pro',
	is_open_xfxzy  								int 	COMMENT '新分销专员',
	is_open_rlzx  								int 	COMMENT '人脸中心',
	is_open_ckgl  								int 	COMMENT '窗口管理',
	is_open_zpgl  								int 	COMMENT '纸票管理',
	is_open_btglgysb  							int 	COMMENT '报团管理（供应商版）',
	is_open_btglfxsb  							int 	COMMENT '报团管理（分销商版）',
	is_open_schygl  							int 	COMMENT '商城会员管理',
	is_open_yqjs  								int 	COMMENT '园区计时',
	is_open_jqsjlp  							int 	COMMENT '景区数据罗盘',
	is_open_dlymdj  							int 	COMMENT '独立域名搭建',
	is_open_wbmfmgl  							int 	COMMENT '外部码发码管理',
	is_open_typtfxjcb  							int 	COMMENT '同业平台分销(基础版)',
	is_open_wxkq  								int 	COMMENT '微信卡券',
	is_open_gpxzhbmd  							int 	COMMENT '购票限制(黑白名单)',
	is_open_crysjtj  							int 	COMMENT '出入园数据统计',
	--is_open_csyy21wm  							int 	COMMENT '测试应用21（勿买）',
	--is_open_ylcs  								int 	COMMENT '依赖测试',
	--is_open_csyyw  								int 	COMMENT '测试应用w',
	--is_open_qwechb  							int 	COMMENT 'qwe_chb',
	--is_open_cssy  								int 	COMMENT '测试使用',
	is_open_zdgl  								int 	COMMENT '终端管理',
	is_open_lxssjlp  							int 	COMMENT '旅行社数据罗盘',
	is_open_dxttzdy  							int 	COMMENT '短信抬头自定义',
	is_openzdydxmb  							int 	COMMENT '自定义短信模板',
	is_open_lyxd  								int 	COMMENT '旅游小店',
	is_open_xypgl  								int 	COMMENT '协议票管理',
	is_open_tstdyy  							int 	COMMENT '特殊团队预约',
	is_open_smyzbzb  							int 	COMMENT '扫码验证-标准版',
	is_open_smyzzyb  							int 	COMMENT '扫码验证-专业版',
	is_open_wlzx  								int 	COMMENT '物料中心',
	is_open_wpttbfx  							int 	COMMENT '微平台图表分析',
	is_open_dyglgysb  							int 	COMMENT '导游管理(供应商版)',
	is_open_dyglfxsb  							int 	COMMENT '导游管理(分销商版)',
	is_open_yxdx  								int 	COMMENT '营销短信',
	--is_open_test  								int 	COMMENT 'test',
	is_open_gpqz  								int 	COMMENT '购票前置',
	is_open_ddxxyc  							int 	COMMENT '订单信息隐藏',
	is_open_kjgp  								int 	COMMENT '快捷购票',
	is_open_xmtfx  								int 	COMMENT '新媒体分销',
	is_open_flglx  								int 	COMMENT '返利管理（新）',
	is_open_bbyy  								int 	COMMENT '报表应用',
	--is_open_csyywm  							int 	COMMENT '测试应用（勿买）',
	is_open_tdyy  								int 	COMMENT '团队预约',
	is_open_fxskjgp  							int 	COMMENT '分销商快捷购票',
	is_open_plzzbb  							int 	COMMENT '票类纸质报表',
	is_open_qplfx  								int 	COMMENT '全品类分销',
	is_open_tgdm  								int 	COMMENT '团购导码',
	is_open_xcxzxjq  							int 	COMMENT '小程序中心(景区)',
	is_open_xcxzxlxsb  							int 	COMMENT '小程序中心(旅行社版)',
	is_open_jyjcsj  							int 	COMMENT '经营基础数据',
	is_open_jyfxsj  							int 	COMMENT '经营分析数据',
	is_open_ycjs  								int 	COMMENT '游船计时',
	is_open_jyxpbg  							int 	COMMENT '经营小飘报告',
	is_open_jyhysj  							int 	COMMENT '经营行业数据',
	is_open_tysy  								int 	COMMENT '统一收银',
	is_open_xykt  								int 	COMMENT '新一卡通',
	is_open_hyzx  								int 	COMMENT '会员中心',
	is_open_xcxzxnkb  							int 	COMMENT '小程序中心（年卡版）',
	is_open_jdgl  								int 	COMMENT '酒店管理',
	is_open_zhdl  								int 	COMMENT '智慧导览',
	is_open_jfgl  								int 	COMMENT '积分管理',
	is_open_fzbbx  								int 	COMMENT '分账报表(新)',

    -- 预留字段
	spare_field1								string 	COMMENT '预留字段1',
	spare_field2								string 	COMMENT '预留字段2',
	spare_field3								string 	COMMENT '预留字段3',
	spare_field4								string 	COMMENT '预留字段4',
	spare_field5								string 	COMMENT '预留字段5',
	spare_field6								string 	COMMENT '预留字段6',
	spare_field7								string 	COMMENT '预留字段7',
	spare_field8								string 	COMMENT '预留字段8',
	spare_field9								string 	COMMENT '预留字段9',
	spare_field10								string 	COMMENT '预留字段10',
	spare_field11								string 	COMMENT '预留字段11',
	spare_field12								string 	COMMENT '预留字段12',
	spare_field13								string 	COMMENT '预留字段13',
	spare_field14								string 	COMMENT '预留字段14',
	spare_field15								string 	COMMENT '预留字段15',
	spare_field16								string 	COMMENT '预留字段16',
	spare_field17								string 	COMMENT '预留字段17',
	spare_field18								string 	COMMENT '预留字段18',
	spare_field19								string 	COMMENT '预留字段19',
	spare_field20								string 	COMMENT '预留字段20',
	spare_field21								string 	COMMENT '预留字段21',
	spare_field22								string 	COMMENT '预留字段22',
	spare_field23								string 	COMMENT '预留字段23',
	spare_field24								string 	COMMENT '预留字段24',
	spare_field25								string 	COMMENT '预留字段25'
 )COMMENT '商户标签表' PARTITIONED BY(
    pt string
 )STORED AS ORC;






SET spark.sql.mergeSmallFiles.enabled=true;
SET spark.sql.sources.partitionOverwriteMode=dynamic;
SET spark.sql.adaptive.enabled=true;
SET spark.sql.adaptive.coalescePartitions.enabled=true;
SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
SET spark.sql.adaptive.coalescePartitions.parallelism=1;



INSERT OVERWRITE TABLE dim_cus_company_d_f  PARTITION(pt= ${ds})

select t1.user_id  -- 用户id
    ,t1.user_account_id  -- 账户id
    ,t1.user_customer_id  -- 客户ID
    ,t1.user_name  -- 用户名称/账户名称
    ,t1.user_company_name  -- 公司名称
    ,t1.customer_name  -- 客户名称
    ,t1.customer_mobile  -- 客户手机号
    ,t1.user_type_code  -- 用户类型编码
    ,t1.user_type  -- 用户类型(供应商/分销商等)
    ,t1.user_is_test  -- 测试账号？(正式/测试)
    ,t1.user_status  -- 用户状态
    ,CAST(t1.customer_certi_status_code as INT) as customer_certi_status_code   -- 客户资质审核状态编码
    ,t1.customer_certi_status  -- 客户资质审核状态
    ,t1.customer_country  -- 客户国家
    ,t1.customer_province  -- 客户省
    ,t1.customer_city  -- 客户市
    ,t1.customer_type_code  -- 客户类型编码
    ,t1.customer_type  -- 客户类型(旅行社/景区)
    ,t1.user_land_topic  -- 景区业态
    ,t1.user_level  -- 级别
    ,t1.user_contract_model_code  -- 合作模式编码
    ,t1.user_contract_model  -- 合作模式
    ,t1.signer_id  -- 签单人id
    ,case when ifnull(t1.signer,'')='' then t21.user_name else t1.signer end as signer-- t1.signer  --签单人姓名
    ,t1.servicer_id  -- 客服id（客户成功经理id）
    ,case when ifnull(t1.servicer,'')='' then t22.user_name else t1.servicer end as servicer-- t1.servicer  -- 客服姓名
    ,t1.user_regist_time  -- 用户注册时间
    ,t1.user_contarct_firstdate  -- 用户首次合日期
    ,t1.user_login_lasttime  -- 用户上次登录时间


    --- 合作伙伴情况    
    ,t5.first_add_time  -- 首次添加分销商时间
    ,t5.end_edit_time  -- 最后编辑分销商时间
    
    ,CAST(t5.partner_num_supp as INT) as partner_num_supp  -- 供应商数
    ,coalesce(CAST(t5.partner_num_ota as INT),0)  -- OTA数
    ,coalesce(CAST(t5.partner_num_dist as INT),0)  -- 分销商数
    ,CAST(t5.partner_num_staff as INT) as partner_num_staff  -- 员工数
    ,CAST(t5.partner_num_ticket_system as INT) as partner_num_ticket_system  -- 票务系统数
    ,CAST(t5.ticket_system_list as INT) as ticket_system_list  -- 票务系统列表

    --- 销售产品情况    
    ,t6.first_add_ticket_time  -- 首次添加票时间
    ,t6.end_edit_ticket_time  -- 最后编辑票时间

    ,t6.ticket_num_self  -- 在售自供应产品票种数,不包含删除
    ,coalesce(t6.land_num_self,0)  -- 在售自供应产品数,不包含删除
    ,t6.resource_num_self  -- 在售自供应资源数,不包含删除
    ,coalesce(t6.land_num_dist,0)  -- 分销产品数，有分销票的产品（过滤删除票）

    ,t6.off_shelf_ticket_num_self  -- 下架自供应产品票种数
    ,t6.off_shelf_land_num_self  -- 下架自供应产品数
    ,t6.off_shelf_resource_num_self   -- 下架自供应资源数

    ,t6.overdue_ticket_num_self  -- 上架过期自供应产品票种数
    ,t6.overdue_land_num_self  -- 上架过期自供应产品数
    ,t6.overdue_resource_num_self  -- 上架过期自供应资源数

    ,t6.add_ticket_num_self_curr_week  -- 本周新编辑自供应票种数
    ,t6.add_land_num_self_curr_week  -- 本周新编辑自供应产品数
    ,t6.add_resource_num_self_curr_week  -- 本周新编辑自供应资源数 

    ,t6.add_ticket_num_self_curr_month  -- 本月新编辑自供应票种数
    ,t6.add_land_num_self_curr_month  -- 本月新编辑自供应产品数
    ,t6.add_resource_num_self_curr_month  -- 本月新编辑自供应资源数

    ,t6.add_ticket_num_self_curr_quarter  -- 本季新编辑自供应票种数
    ,t6.add_land_num_self_curr_quarter  -- 本季新编辑自供应产品数
    ,t6.add_resource_num_self_curr_quarter  -- 本季新编辑自供应资源数

    ,t6.ticket_num_dist  -- 分销票种数
    ,t6.land_num_dist  -- 分销产品数
    ,t6.resource_num_dist  -- 分销资源数


    -- 购买套餐情况
    ,t2.sum_pay_amount_package  -- 套餐费合计
    ,t2.user_package_num_buy  -- 用户购买套餐次数
    ,t2.user_package_num_used  -- 用户已用套餐次数

    ,t2.user_first_supplier_begindate  -- 用户第一次合作供应商套餐开始日期
    ,t2.user_first_supplier_enddate  -- 用户第一次合作供应商套餐结束日期
    ,t2.user_first_supplier_package_id  -- 用户第一次合作供应商套餐ID
    ,t2.user_first_supplier_package_name  -- 用户第一次合作供应商套餐名称
    ,t2.user_first_supplier_package_price  -- 用户第一次合作供应商套餐价格
    ,t2.user_first_supplier_package_classify_name  -- 用户第一次合作供应商套餐组
    ,t2.user_first_supplier_package_pay_amount  -- 用户第一次合作供应商实收金额（分）
    ,t2.user_first_supplier_add_time  -- 用户第一次合作供应添加时间

    ,t2.user_first_package_begindate  -- 用户第一次合作套餐开始日期
    ,t2.user_first_package_enddate  -- 用户第一次合作套餐结束日期 
    ,t2.user_first_package_id  -- 用户第一次套餐id
    ,t2.user_first_package_name  -- 用户第一次套餐名称
    ,t2.user_first_package_price  -- 用户第一次套餐价格(分)
    ,t2.user_first_package_role  -- 用户第一次套餐角色,供应商/分销商
    ,t2.user_first_package_classify_name  -- 用户第一次套餐套餐组
    ,t2.user_first_package_pay_amount  -- 用户第一次套餐实收金额（分）
    ,t2.user_first_add_time  -- 用户第一次套餐添加日期

    ,t2.user_curr_package_id  -- 用户当前套餐id
    ,t2.user_curr_package_name  -- 用户当前套餐名称
    ,t2.user_curr_package_add_date  -- 用户当前套餐签约日期
    ,t2.user_curr_package_begin_date  -- 用户当前套餐开始日期
    ,t2.user_curr_package_end_date  -- 用户当前套餐结束日期
    ,t2.user_curr_package_price  -- 用户当前套餐价格(分)
    ,t2.user_curr_package_pay_amount  -- 用户当前套餐实收金额(分)
    ,t2.user_curr_package_role  -- 用户当前套餐角色
    ,t2.user_curr_package_classify_name  -- 用户当前套餐套餐组
    ,ceil(months_between(t2.user_curr_package_end_date,t2.user_curr_package_begin_date)) as user_curr_package_diff_month  -- 用户当前套餐套餐周期（月）
    ,round(t2.user_curr_package_pay_amount/ceil(months_between(t2.user_curr_package_end_date,t2.user_curr_package_begin_date)),0) as user_curr_package_avg_pay_amount  -- 用户当前套餐客单价（分）
    ,t2.user_curr_package_signer  -- 用户当前套餐签单人
    --,st1.lv2_team  -- 用户当前套餐签单人部门
    ,datediff(t2.user_curr_package_add_date,t2.user_last_package_end_date)/30 as user_curr_package_prepay_months  -- 用户当前套餐提前续费月数
    ,t2.user_curr_package_contract_model  -- 用户当前套餐合作模式

    ,t2.user_last_package_id  -- 用户上次套餐id
    ,t2.user_last_package_name  -- 用户上次套餐名称
    ,t2.user_last_package_add_date  -- 用户上次套餐签约日期
    ,t2.user_last_package_begin_date  -- 用户上次套餐开始日期
    ,t2.user_last_package_end_date  -- 用户上次套餐结束日期
    ,t2.user_last_package_price  -- 用户上次套餐价格（分）
    ,t2.user_last_package_pay_amount  -- 用户上次套餐实收金额(分)
    ,t2.user_last_package_role  -- 用户上次套餐角色
    ,t2.user_last_package_classify_name  -- 用户上次套餐套餐组
    ,ceil(months_between(t2.user_last_package_end_date,t2.user_last_package_begin_date)) as user_last_package_diff_month  -- 用户上次套餐套餐周期（月）
    ,round(t2.user_last_package_pay_amount/ceil(months_between(t2.user_last_package_end_date,t2.user_last_package_begin_date)),0) as user_last_package_avg_pay_amount  -- 用户上次套餐客单价（分）

    ,t2.user_next_package_id  -- 用户下个套餐id
    ,t2.user_next_package_name  -- 用户下个套餐名称
    ,t2.user_next_package_add_date  -- 用户下个套餐签约日期
    ,t2.user_next_package_begin_date  -- 用户下个套餐开始日期
    ,t2.user_next_package_end_date  -- 用户下个套餐结束日期
    ,t2.user_next_package_price  -- 用户下个套餐价格（分）
    ,t2.user_next_package_pay_amount  -- 用户下个套餐实收金额（分）
    ,t2.user_next_package_signer  -- 用户下个套餐签单人
    --,st2.lv2_team  -- 用户下个套餐签单人部门
    ,datediff(t2.user_next_package_add_date,t2.user_curr_package_end_date)/30   as user_next_package_prepay_months  -- 用户下个套餐提前续费月数
    ,t2.user_next_package_contract_model  -- 用户下个套餐合作模式

    ,t2.user_end_package_id  -- 用户最终套餐id
    ,t2.user_end_package_name  -- 用户最终套餐名称
    ,t2.user_end_package_add_date  -- 用户最终套餐签约日期
    ,t2.user_end_package_begin_date  -- 用户最终套餐开始日期
    ,t2.user_end_package_end_date  -- 用户最终套餐结束日期
    ,t2.user_end_package_price  -- 用户最终套餐价格（分）
    ,t2.user_end_package_pay_amount  -- 用户最终套餐实收金额(分)



    -- 登录情况
    ,t3.login_num_plat_curr_week  -- 本周登录平台次数
    ,t3.login_num_terminal_curr_week  -- 本周登录终端次数
    ,t3.login_date_num_plat_curr_week  -- 本周登录平台天数
    ,t3.login_date_num_terminal_curr_week  -- 本周登录终端天数
	
    ,t3.login_num_plat_last_week  -- 上周登录平台次数
    ,t3.login_num_terminal_last_week  -- 上周登录终端次数
    ,t3.login_date_num_plat_last_week  -- 上周登录平台天数
    ,t3.login_date_num_terminal_last_week  -- 上周登录终端天数
	
    ,t3.login_num_plat_curr_month  -- 本月登录平台次数
    ,t3.login_num_terminal_curr_month  -- 本月登录终端次数
    ,t3.login_date_num_plat_curr_month  -- 本月登录平台天数
    ,t3.login_date_num_terminal_curr_month  -- 本月登录终端天数
	
    ,t3.login_num_plat_last_month  -- 上月登录平台次数
    ,t3.login_num_terminal_last_month  -- 上月登录终端次数
    ,t3.login_date_num_plat_last_month  -- 上月登录平台天数
    ,t3.login_date_num_terminal_last_month  -- 上月登录终端天数
	
    ,t3.login_num_plat_curr_quarter  -- 本季登录平台次数
    ,t3.login_num_terminal_curr_quarter  -- 本季登录终端次数
    ,t3.login_date_num_plat_curr_quarter  -- 本季登录平台天数
    ,t3.login_date_num_terminal_curr_quarter  -- 本季登录终端天数
	
    ,t3.login_num_plat_last_quarter  -- 上季登录平台次数
    ,t3.login_num_terminal_last_quarter  -- 上季登录终端次数
    ,t3.login_date_num_plat_last_quarter  -- 上季登录平台天数
    ,t3.login_date_num_terminal_last_quarter  -- 上季登录终端天数

	
	
	-- 应用开通
	,coalesce(t4.is_open_wsc,0)  as is_open_wsc -- 微商城（旧版）
	,coalesce(t4.is_open_hbtg,0) as is_open_hbtg -- 海报推广
	,coalesce(t4.is_open_sjlp,0) as is_open_sjlp  -- 数据罗盘
	,coalesce(t4.is_open_qmyx,0) as is_open_qmyx -- 全民营销
	,coalesce(t4.is_open_yspzd,0) as is_open_yspzd  -- 云售票终端
	,coalesce(t4.is_open_miniyzd,0)  as is_open_miniyzd-- MINI云终端
	,coalesce(t4.is_open_znyzj,0) as is_open_znyzj -- 智能云闸机
	,coalesce(t4.is_open_lyykt,0) as is_open_lyykt  -- 旅游一卡通
	,coalesce(t4.is_open_ljgg,0) as is_open_ljgg  -- 链接广告
	,coalesce(t4.is_open_zzsqpj,0) as is_open_zzsqpj -- 自助售取票机
	,coalesce(t4.is_open_appxz,0)  as is_open_appxz -- APP下载
	,coalesce(t4.is_open_xxpwxt,0)  is_open_xxpwxt-- 线下票务系统
	,coalesce(t4.is_open_jdxd,0) is_open_jdxd -- 计调下单
	,coalesce(t4.is_open_yhqjb,0) is_open_yhqjb -- 优惠券(旧版)
	,coalesce(t4.is_open_lynk,0)  is_open_lynk-- 旅游年卡
	,coalesce(t4.is_open_b2cscpcd,0) is_open_b2cscpcd -- B2C商城（PC端）
	,coalesce(t4.is_open_jszdrz,0)  is_open_jszdrz-- 结算自动入帐
	,coalesce(t4.is_open_otaptfx,0) is_open_otaptfx -- OTA平台分销
	,coalesce(t4.is_open_typtfx,0) is_open_typtfx -- 同业平台分销
	,coalesce(t4.is_open_fxdsfcp,0) is_open_fxdsfcp -- 分销第三方产品
	,coalesce(t4.is_open_wqglxt,0)  is_open_wqglxt-- 温泉管理系统
	,coalesce(t4.is_open_jqpwxt,0)  is_open_jqpwxt-- 景区票务系统
	,coalesce(t4.is_open_yqykt,0) is_open_yqykt -- 园区一卡通
	,coalesce(t4.is_open_zfxcp,0)  is_open_zfxcp-- 转分销产品
	,coalesce(t4.is_open_dzfp,0) is_open_dzfp -- 电子发票
	,coalesce(t4.is_open_xsqg,0)  is_open_xsqg-- 限时抢购
	,coalesce(t4.is_open_dsjfx,0) is_open_dsjfx -- 大数据分析
	,coalesce(t4.is_open_flgl,0) is_open_flgl -- 返利管理
	,coalesce(t4.is_open_mygxdj,0)  is_open_mygxdj-- 蚂蚁供销对接
	,coalesce(t4.is_open_yzwscdj,0)  is_open_yzwscdj-- 有赞微商城对接
	,coalesce(t4.is_open_kjwsc,0) is_open_kjwsc -- 砍价(微商城)
	,coalesce(t4.is_open_ptwsc,0) is_open_ptwsc -- 拼团(微商城)
	,coalesce(t4.is_open_miniyxcx,0) is_open_miniyxcx -- MiNi云小程序
	,coalesce(t4.is_open_jfsc,0) is_open_jfsc -- 积分商城
	,coalesce(t4.is_open_fxzy,0) is_open_fxzy -- 分销专员
	,coalesce(t4.is_open_hytx,0) is_open_hytx -- 会员体系
	,coalesce(t4.is_open_zghxf,0) is_open_zghxf -- 公众号吸粉
	,coalesce(t4.is_open_hbffl,0) is_open_hbffl -- 红包翻翻乐
	,coalesce(t4.is_open_zyzx,0) is_open_zyzx -- 资源中心
	,coalesce(t4.is_open_wxzxwsc,0) is_open_wxzxwsc -- 微信直销（微商城）
	,coalesce(t4.is_open_xcxsc,0) is_open_xcxsc -- 小程序商城
	,coalesce(t4.is_open_yhq,0) is_open_yhq -- 优惠券
	,coalesce(t4.is_open_fsyy,0) is_open_fsyy -- 分时预约
	,coalesce(t4.is_open_gzhyx,0)  is_open_gzhyx-- 公众号营销
	,coalesce(t4.is_open_xcxpro,0)  is_open_xcxpro-- 小程序Pro
	,coalesce(t4.is_open_xfxzy,0)  is_open_xfxzy-- 新分销专员
	,coalesce(t4.is_open_rlzx,0)  is_open_rlzx-- 人脸中心
	,coalesce(t4.is_open_ckgl,0) is_open_ckgl -- 窗口管理
	,coalesce(t4.is_open_zpgl,0) is_open_zpgl -- 纸票管理
	,coalesce(t4.is_open_btglgysb,0) is_open_btglgysb -- 报团管理（供应商版）
	,coalesce(t4.is_open_btglfxsb,0)  is_open_btglfxsb-- 报团管理（分销商版）
	,coalesce(t4.is_open_schygl,0) is_open_schygl -- 商城会员管理
	,coalesce(t4.is_open_yqjs,0)  is_open_yqjs-- 园区计时
	,coalesce(t4.is_open_jqsjlp,0)  is_open_jqsjlp-- 景区数据罗盘
	,coalesce(t4.is_open_dlymdj,0)  is_open_dlymdj-- 独立域名搭建
	,coalesce(t4.is_open_wbmfmgl,0) is_open_wbmfmgl -- 外部码发码管理
	,coalesce(t4.is_open_typtfxjcb,0)  is_open_typtfxjcb-- 同业平台分销(基础版)
	,coalesce(t4.is_open_wxkq,0)  is_open_wxkq-- 微信卡券
	,coalesce(t4.is_open_gpxzhbmd,0) is_open_gpxzhbmd -- 购票限制(黑白名单)
	,coalesce(t4.is_open_crysjtj,0)  is_open_crysjtj-- 出入园数据统计
	--,t4.is_open_csyy21wm  -- 测试应用21（勿买）
	--,t4.is_open_ylcs  -- 依赖测试
	--,t4.is_open_csyyw  -- 测试应用w
	--,t4.is_open_qwechb  -- qwe_chb
	--,t4.is_open_cssy  -- 测试使用
	,coalesce(t4.is_open_zdgl,0) is_open_zdgl -- 终端管理
	,coalesce(t4.is_open_lxssjlp,0) is_open_lxssjlp -- 旅行社数据罗盘
	,coalesce(t4.is_open_dxttzdy,0) is_open_dxttzdy -- 短信抬头自定义
	,coalesce(t4.is_openzdydxmb,0) is_openzdydxmb -- 自定义短信模板
	,coalesce(t4.is_open_lyxd,0) is_open_lyxd -- 旅游小店
	,coalesce(t4.is_open_xypgl,0) is_open_xypgl -- 协议票管理
	,coalesce(t4.is_open_tstdyy,0)  is_open_tstdyy-- 特殊团队预约
	,coalesce(t4.is_open_smyzbzb,0)  is_open_smyzbzb-- 扫码验证-标准版
	,coalesce(t4.is_open_smyzzyb,0) is_open_smyzzyb -- 扫码验证-专业版
	,coalesce(t4.is_open_wlzx,0) is_open_wlzx -- 物料中心
	,coalesce(t4.is_open_wpttbfx,0) is_open_wpttbfx -- 微平台图表分析
	,coalesce(t4.is_open_dyglgysb,0) is_open_dyglgysb -- 导游管理(供应商版)
	,coalesce(t4.is_open_dyglfxsb,0) is_open_dyglfxsb -- 导游管理(分销商版)
	,coalesce(t4.is_open_yxdx,0) is_open_yxdx -- 营销短信
	--,t4.is_open_test  -- test
	,coalesce(t4.is_open_gpqz,0) is_open_gpqz -- 购票前置
	,coalesce(t4.is_open_ddxxyc,0)  is_open_ddxxyc-- 订单信息隐藏
	,coalesce(t4.is_open_kjgp,0)  is_open_kjgp-- 快捷购票
	,coalesce(t4.is_open_xmtfx,0) is_open_xmtfx -- 新媒体分销
	,coalesce(t4.is_open_flglx,0) is_open_flglx  -- 返利管理（新）
	,coalesce(t4.is_open_bbyy,0) is_open_bbyy -- 报表应用
	--,t4.is_open_csyywm  -- 测试应用（勿买）
	,coalesce(t4.is_open_tdyy,0)  is_open_tdyy-- 团队预约
	,coalesce(t4.is_open_fxskjgp,0) is_open_fxskjgp -- 分销商快捷购票
	,coalesce(t4.is_open_plzzbb,0) is_open_plzzbb -- 票类纸质报表
	,coalesce(t4.is_open_qplfx,0)  is_open_qplfx-- 全品类分销
	,coalesce(t4.is_open_tgdm,0) is_open_tgdm  -- 团购导码
	,coalesce(t4.is_open_xcxzxjq,0) is_open_xcxzxjq -- 小程序中心(景区)
	,coalesce(t4.is_open_xcxzxlxsb,0) is_open_xcxzxlxsb  -- 小程序中心(旅行社版)
	,coalesce(t4.is_open_jyjcsj,0) is_open_jyjcsj -- 经营基础数据
	,coalesce(t4.is_open_jyfxsj,0) is_open_jyfxsj -- 经营分析数据
	,coalesce(t4.is_open_ycjs,0)  is_open_ycjs-- 游船计时
	,coalesce(t4.is_open_jyxpbg,0)  is_open_jyxpbg-- 经营小飘报告
	,coalesce(t4.is_open_jyhysj,0)  is_open_jyhysj-- 经营行业数据
	,coalesce(t4.is_open_tysy,0)  is_open_tysy-- 统一收银
	,coalesce(t4.is_open_xykt,0)  is_open_xykt-- 新一卡通
	,coalesce(t4.is_open_hyzx,0) is_open_hyzx -- 会员中心
	,coalesce(t4.is_open_xcxzxnkb,0) is_open_xcxzxnkb -- 小程序中心（年卡版）
	,coalesce(t4.is_open_jdgl,0) is_open_jdgl -- 酒店管理
	,coalesce(t4.is_open_zhdl,0) is_open_zhdl -- 智慧导览
	,coalesce(t4.is_open_jfgl,0) is_open_jfgl -- 积分管理
	,coalesce(t4.is_open_fzbbx,0) is_open_fzbbx -- 分账报表(新)
	
	
	-- 预留字段
	-- ,case when ifnull(t7.user_id,'')='' then 0 else 1 end as spare_field1 --是否开通手持机
    ,0 as spare_field1 --是否开通手持机
	,ifnull(t8.fcount,0)  as    spare_field2   --海报推广次数
	,ifnull(t9.fcount,0)  as    spare_field3   --产品类型数
	,ifnull(t10.fcount,0) as    spare_field4   --ota分销商数
	,ifnull(t11.fcount,0) as    spare_field5   --线下票务系统接口数
	,ifnull(t12.fcount,0) as    spare_field6   --销售报表下载次数
	,ifnull(t13.fcount,0) as    spare_field7   --物料中心（扫码次数）
	,ifnull(t14.fcount,0) as    spare_field8-- ifnull(t14.fcount,0) as    spare_field8   --短信条数
	,ifnull(t15.fcount,0) as    spare_field9   --营销类短信条数
	,t1.user_account  as spare_field10  --账号
	,case when ifnull(t16.product_type_list,'') = '' then t20.product_type_list else ifnull(t16.product_type_list,'') end spare_field11  --产品开通列表
	,t3.login_num_plat_60_day spare_field12  -- 近60天登录终端次数
	,t3.login_num_terminal_60_day spare_field13 -- 近60天登录终端次数
	,t3.login_date_num_plat_60_day spare_field14 -- 近60天登录终端天数
	,t3.login_date_num_terminal_60_day spare_field15 -- 近60天登录终端天数
	,ifnull(t17.coop_content_list,'')  spare_field16  -- 合作内容
	,coalesce(t4.is_open_xcxfxy,0) spare_field17 -- 小程序分销员 spare_field17
	,coalesce(t4.is_open_fxkc,0) spare_field18 -- 分销库存 spare_field18
	,ifnull(t18.field_i4oZj__c,t19.field_i4oZj__c) spare_field19  -- 合作客户等级
	,null spare_field20
	,null spare_field21
	,null spare_field22
	,null spare_field23
	,null spare_field24
	,null spare_field25
from dim_user_d_f t1   --data_middle_bi.dim_user_d_f t1
left join dws_company_package_it_d_f t2    --it_project.dws_company_package_it_d_f t2   -- 套餐
    on t1.user_id=t2.user_id
    and t2.pt = ${ds}
left join dws_cus_company_login_d_f t3    --it_project.dws_cus_company_login_d_f t3  -- 登录信息
    on t1.user_id=t3.user_id
    and t3.pt = ${ds}

left join
    (select c.member_id
        ,case when sum(case when c.id=1 then 1 else 0 end) > 0 then 1 else 0 end as is_open_wsc  -- 微商城（旧版）
        ,case when sum(case when c.id=2 then 1 else 0 end) > 0 then 1 else 0 end as is_open_hbtg  -- 海报推广
        ,case when sum(case when c.id=3 then 1 else 0 end) > 0 then 1 else 0 end as is_open_sjlp  -- 数据罗盘
        ,case when sum(case when c.id=5 then 1 else 0 end) > 0 then 1 else 0 end as is_open_qmyx  -- 全民营销
        ,case when sum(case when c.id=9 then 1 else 0 end) > 0 then 1 else 0 end as is_open_yspzd  -- 云售票终端
        ,case when sum(case when c.id=10 then 1 else 0 end) > 0 then 1 else 0 end as is_open_miniyzd  -- MINI云终端
        ,case when sum(case when c.id=11 then 1 else 0 end) > 0 then 1 else 0 end as is_open_znyzj  -- 智能云闸机
        ,case when sum(case when c.id=12 then 1 else 0 end) > 0 then 1 else 0 end as is_open_lyykt  -- 旅游一卡通
        ,case when sum(case when c.id=13 then 1 else 0 end) > 0 then 1 else 0 end as is_open_ljgg  -- 链接广告
        ,case when sum(case when c.id=15 then 1 else 0 end) > 0 then 1 else 0 end as is_open_zzsqpj  -- 自助售取票机
        ,case when sum(case when c.id=16 then 1 else 0 end) > 0 then 1 else 0 end as is_open_appxz  -- APP下载
        ,case when sum(case when c.id=17 then 1 else 0 end) > 0 then 1 else 0 end as is_open_xxpwxt  -- 线下票务系统
        ,case when sum(case when c.id=18 then 1 else 0 end) > 0 then 1 else 0 end as is_open_jdxd  -- 计调下单
        ,case when sum(case when c.id=20 then 1 else 0 end) > 0 then 1 else 0 end as is_open_yhqjb  -- 优惠券(旧版)
        ,case when sum(case when c.id=21 then 1 else 0 end) > 0 then 1 else 0 end as is_open_lynk  -- 旅游年卡
        ,case when sum(case when c.id=22 then 1 else 0 end) > 0 then 1 else 0 end as is_open_b2cscpcd  -- B2C商城（PC端）
        ,case when sum(case when c.id=23 then 1 else 0 end) > 0 then 1 else 0 end as is_open_jszdrz  -- 结算自动入帐
        ,case when sum(case when c.id=25 then 1 else 0 end) > 0 then 1 else 0 end as is_open_otaptfx  -- OTA平台分销
        ,case when sum(case when c.id=26 then 1 else 0 end) > 0 then 1 else 0 end as is_open_typtfx  -- 同业平台分销
        ,case when sum(case when c.id=27 then 1 else 0 end) > 0 then 1 else 0 end as is_open_fxdsfcp  -- 分销第三方产品
        ,case when sum(case when c.id=29 then 1 else 0 end) > 0 then 1 else 0 end as is_open_wqglxt  -- 温泉管理系统
        ,case when sum(case when c.id=35 then 1 else 0 end) > 0 then 1 else 0 end as is_open_jqpwxt  -- 景区票务系统
        ,case when sum(case when c.id=36 then 1 else 0 end) > 0 then 1 else 0 end as is_open_yqykt  -- 园区一卡通
        ,case when sum(case when c.id=37 then 1 else 0 end) > 0 then 1 else 0 end as is_open_zfxcp  -- 转分销产品
        ,case when sum(case when c.id=39 then 1 else 0 end) > 0 then 1 else 0 end as is_open_dzfp  -- 电子发票
        ,case when sum(case when c.id=40 then 1 else 0 end) > 0 then 1 else 0 end as is_open_xsqg  -- 限时抢购
        ,case when sum(case when c.id=41 then 1 else 0 end) > 0 then 1 else 0 end as is_open_dsjfx  -- 大数据分析
        ,case when sum(case when c.id=42 then 1 else 0 end) > 0 then 1 else 0 end as is_open_flgl  -- 返利管理
        ,case when sum(case when c.id=43 then 1 else 0 end) > 0 then 1 else 0 end as is_open_mygxdj  -- 蚂蚁供销对接
        ,case when sum(case when c.id=44 then 1 else 0 end) > 0 then 1 else 0 end as is_open_yzwscdj  -- 有赞微商城对接
        ,case when sum(case when c.id=45 then 1 else 0 end) > 0 then 1 else 0 end as is_open_kjwsc  -- 砍价(微商城)
        ,case when sum(case when c.id=46 then 1 else 0 end) > 0 then 1 else 0 end as is_open_ptwsc  -- 拼团(微商城)
        ,case when sum(case when c.id=47 then 1 else 0 end) > 0 then 1 else 0 end as is_open_miniyxcx  -- MiNi云小程序
        ,case when sum(case when c.id=48 then 1 else 0 end) > 0 then 1 else 0 end as is_open_jfsc  -- 积分商城
        ,case when sum(case when c.id=51 then 1 else 0 end) > 0 then 1 else 0 end as is_open_fxzy  -- 分销专员
        ,case when sum(case when c.id=52 then 1 else 0 end) > 0 then 1 else 0 end as is_open_hytx  -- 会员体系
        ,case when sum(case when c.id=55 then 1 else 0 end) > 0 then 1 else 0 end as is_open_zghxf  -- 公众号吸粉
        ,case when sum(case when c.id=56 then 1 else 0 end) > 0 then 1 else 0 end as is_open_hbffl  -- 红包翻翻乐
        ,case when sum(case when c.id=57 then 1 else 0 end) > 0 then 1 else 0 end as is_open_zyzx  -- 资源中心
        ,case when sum(case when c.id=58 then 1 else 0 end) > 0 then 1 else 0 end as is_open_wxzxwsc  -- 微信直销（微商城）
        ,case when sum(case when c.id=59 then 1 else 0 end) > 0 then 1 else 0 end as is_open_xcxsc  -- 小程序商城
        ,case when sum(case when c.id=60 then 1 else 0 end) > 0 then 1 else 0 end as is_open_yhq  -- 优惠券
        ,case when sum(case when c.id=61 then 1 else 0 end) > 0 then 1 else 0 end as is_open_fsyy  -- 分时预约
        ,case when sum(case when c.id=62 then 1 else 0 end) > 0 then 1 else 0 end as is_open_gzhyx  -- 公众号营销
        ,case when sum(case when c.id=63 then 1 else 0 end) > 0 then 1 else 0 end as is_open_xcxpro  -- 小程序Pro
        ,case when sum(case when c.id=65 then 1 else 0 end) > 0 then 1 else 0 end as is_open_xfxzy  -- 新分销专员
        ,case when sum(case when c.id=66 then 1 else 0 end) > 0 then 1 else 0 end as is_open_rlzx  -- 人脸中心
        ,case when sum(case when c.id=67 then 1 else 0 end) > 0 then 1 else 0 end as is_open_ckgl  -- 窗口管理
        ,case when sum(case when c.id=68 then 1 else 0 end) > 0 then 1 else 0 end as is_open_zpgl  -- 纸票管理
        ,case when sum(case when c.id=69 then 1 else 0 end) > 0 then 1 else 0 end as is_open_btglgysb  -- 报团管理（供应商版）
        ,case when sum(case when c.id=70 then 1 else 0 end) > 0 then 1 else 0 end as is_open_btglfxsb  -- 报团管理（分销商版）
        ,case when sum(case when c.id=71 then 1 else 0 end) > 0 then 1 else 0 end as is_open_schygl  -- 商城会员管理
        ,case when sum(case when c.id=72 then 1 else 0 end) > 0 then 1 else 0 end as is_open_yqjs  -- 园区计时
        ,case when sum(case when c.id=73 then 1 else 0 end) > 0 then 1 else 0 end as is_open_jqsjlp  -- 景区数据罗盘
        ,case when sum(case when c.id=74 then 1 else 0 end) > 0 then 1 else 0 end as is_open_dlymdj  -- 独立域名搭建
        ,case when sum(case when c.id=75 then 1 else 0 end) > 0 then 1 else 0 end as is_open_wbmfmgl  -- 外部码发码管理
        ,case when sum(case when c.id=76 then 1 else 0 end) > 0 then 1 else 0 end as is_open_typtfxjcb  -- 同业平台分销(基础版)
        ,case when sum(case when c.id=77 then 1 else 0 end) > 0 then 1 else 0 end as is_open_wxkq  -- 微信卡券
        ,case when sum(case when c.id=78 then 1 else 0 end) > 0 then 1 else 0 end as is_open_gpxzhbmd  -- 购票限制(黑白名单)
        ,case when sum(case when c.id=79 then 1 else 0 end) > 0 then 1 else 0 end as is_open_crysjtj  -- 出入园数据统计
        ,case when sum(case when c.id=80 then 1 else 0 end) > 0 then 1 else 0 end as is_open_csyy21wm  -- 测试应用21（勿买）
        ,case when sum(case when c.id=81 then 1 else 0 end) > 0 then 1 else 0 end as is_open_ylcs  -- 依赖测试
        ,case when sum(case when c.id=82 then 1 else 0 end) > 0 then 1 else 0 end as is_open_csyyw  -- 测试应用w
        ,case when sum(case when c.id=83 then 1 else 0 end) > 0 then 1 else 0 end as is_open_qwechb  -- qwe_chb
        ,case when sum(case when c.id=84 then 1 else 0 end) > 0 then 1 else 0 end as is_open_cssy  -- 测试使用
        ,case when sum(case when c.id=85 then 1 else 0 end) > 0 then 1 else 0 end as is_open_zdgl  -- 终端管理
        ,case when sum(case when c.id=86 then 1 else 0 end) > 0 then 1 else 0 end as is_open_lxssjlp  -- 旅行社数据罗盘
        ,case when sum(case when c.id=87 then 1 else 0 end) > 0 then 1 else 0 end as is_open_dxttzdy  -- 短信抬头自定义
        ,case when sum(case when c.id=88 then 1 else 0 end) > 0 then 1 else 0 end as is_openzdydxmb  -- 自定义短信模板
        ,case when sum(case when c.id=89 then 1 else 0 end) > 0 then 1 else 0 end as is_open_lyxd  -- 旅游小店
        ,case when sum(case when c.id=90 then 1 else 0 end) > 0 then 1 else 0 end as is_open_xypgl  -- 协议票管理
        ,case when sum(case when c.id=91 then 1 else 0 end) > 0 then 1 else 0 end as is_open_tstdyy  -- 特殊团队预约
        ,case when sum(case when c.id=92 then 1 else 0 end) > 0 then 1 else 0 end as is_open_smyzbzb  -- 扫码验证-标准版
        ,case when sum(case when c.id=93 then 1 else 0 end) > 0 then 1 else 0 end as is_open_smyzzyb  -- 扫码验证-专业版
        ,case when sum(case when c.id=94 then 1 else 0 end) > 0 then 1 else 0 end as is_open_wlzx  -- 物料中心
        ,case when sum(case when c.id=95 then 1 else 0 end) > 0 then 1 else 0 end as is_open_wpttbfx  -- 微平台图表分析
        ,case when sum(case when c.id=96 then 1 else 0 end) > 0 then 1 else 0 end as is_open_dyglgysb  -- 导游管理(供应商版)
        ,case when sum(case when c.id=97 then 1 else 0 end) > 0 then 1 else 0 end as is_open_dyglfxsb  -- 导游管理(分销商版)
        ,case when sum(case when c.id=176 then 1 else 0 end) > 0 then 1 else 0 end as is_open_yxdx  -- 营销短信
        ,case when sum(case when c.id=177 then 1 else 0 end) > 0 then 1 else 0 end as is_open_test  -- test
        ,case when sum(case when c.id=178 then 1 else 0 end) > 0 then 1 else 0 end as is_open_gpqz  -- 购票前置
        ,case when sum(case when c.id=179 then 1 else 0 end) > 0 then 1 else 0 end as is_open_ddxxyc  -- 订单信息隐藏
        ,case when sum(case when c.id=180 then 1 else 0 end) > 0 then 1 else 0 end as is_open_kjgp  -- 快捷购票
        ,case when sum(case when c.id=181 then 1 else 0 end) > 0 then 1 else 0 end as is_open_xmtfx  -- 新媒体分销
        ,case when sum(case when c.id=182 then 1 else 0 end) > 0 then 1 else 0 end as is_open_flglx  -- 返利管理（新）
        ,case when sum(case when c.id=183 then 1 else 0 end) > 0 then 1 else 0 end as is_open_bbyy  -- 报表应用
        ,case when sum(case when c.id=184 then 1 else 0 end) > 0 then 1 else 0 end as is_open_csyywm  -- 测试应用（勿买）
        ,case when sum(case when c.id=185 then 1 else 0 end) > 0 then 1 else 0 end as is_open_tdyy  -- 团队预约
        ,case when sum(case when c.id=186 then 1 else 0 end) > 0 then 1 else 0 end as is_open_fxskjgp  -- 分销商快捷购票
        ,case when sum(case when c.id=187 then 1 else 0 end) > 0 then 1 else 0 end as is_open_plzzbb  -- 票类纸质报表
        ,case when sum(case when c.id=243 then 1 else 0 end) > 0 then 1 else 0 end as is_open_qplfx  -- 全品类分销
        ,case when sum(case when c.id=244 then 1 else 0 end) > 0 then 1 else 0 end as is_open_tgdm  -- 团购导码
        ,case when sum(case when c.id=245 then 1 else 0 end) > 0 then 1 else 0 end as is_open_xcxzxjq  -- 小程序中心(景区)
        ,case when sum(case when c.id=246 then 1 else 0 end) > 0 then 1 else 0 end as is_open_xcxzxlxsb  -- 小程序中心(旅行社版)
        ,case when sum(case when c.id=247 then 1 else 0 end) > 0 then 1 else 0 end as is_open_jyjcsj  -- 经营基础数据
        ,case when sum(case when c.id=248 then 1 else 0 end) > 0 then 1 else 0 end as is_open_jyfxsj  -- 经营分析数据
        ,case when sum(case when c.id=249 then 1 else 0 end) > 0 then 1 else 0 end as is_open_ycjs  -- 游船计时
        ,case when sum(case when c.id=250 then 1 else 0 end) > 0 then 1 else 0 end as is_open_jyxpbg  -- 经营小飘报告
        ,case when sum(case when c.id=251 then 1 else 0 end) > 0 then 1 else 0 end as is_open_jyhysj  -- 经营行业数据
        ,case when sum(case when c.id=252 then 1 else 0 end) > 0 then 1 else 0 end as is_open_tysy  -- 统一收银
        ,case when sum(case when c.id=254 then 1 else 0 end) > 0 then 1 else 0 end as is_open_xykt  -- 新一卡通
        ,case when sum(case when c.id=255 then 1 else 0 end) > 0 then 1 else 0 end as is_open_hyzx  -- 会员中心
        ,case when sum(case when c.id=256 then 1 else 0 end) > 0 then 1 else 0 end as is_open_xcxzxnkb  -- 小程序中心（年卡版）
        ,case when sum(case when c.id=257 then 1 else 0 end) > 0 then 1 else 0 end as is_open_jdgl  -- 酒店管理
        ,case when sum(case when c.id=258 then 1 else 0 end) > 0 then 1 else 0 end as is_open_zhdl  -- 智慧导览
        ,case when sum(case when c.id=259 then 1 else 0 end) > 0 then 1 else 0 end as is_open_jfgl  -- 积分管理
        ,case when sum(case when c.id=265 then 1 else 0 end) > 0 then 1 else 0 end as is_open_fzbbx  -- 分账报表(新)
        -- 新增模块
        ,case when sum(case when c.id=308 then 1 else 0 end) > 0 then 1 else 0 end as is_open_xcxfxy  -- 小程序分销员
        ,case when sum(case when c.id=298 then 1 else 0 end) > 0 then 1 else 0 end as is_open_fxkc  -- 分销库存
        ,case when sum(case when c.id=332 then 1 else 0 end) > 0 then 1 else 0 end as is_open_cwph  -- 财务平衡

    from (--模块
          select a.member_id ,b.id ,b.name 
          from ods_pft001_pft_module_used_d_f a    --data_middle_bi.s_pft001_pft_module_used_d_f a
          inner join ods_pft001_pft_module_d_f b     --data_middle_bi.s_pft001_pft_module_d_f b
              on a.module_id=b.id
              and b.pt = ${ds}
          where a.pt = ${ds} and a.status=1  -- 状态 1=正常使用，2=过期
          -- and a.begin_time <= unix_timestamp( concat('${bdp.system.bizdate2}',' 00:00:00') ) and a.expire_time > unix_timestamp( concat('${bdp.system.bizdate2}',' 00:00:00') )

          union
          --套餐-拆模块
          select a.user_id ,b.module_id ,c.name 
          from dwd_user_package_d_f a    --data_middle_bi.dwd_user_package_d_f a
          left join dim_prod_pft_module_package_detail_d_f b   --it_project.dim_prod_pft_module_package_detail_d_f b 
              on a.package_id=b.package_id
              and b.pt= ${ds}
          left join ods_pft001_pft_module_d_f c    --data_middle_bi.s_pft001_pft_module_d_f c 
              on b.module_id=c.id
              and c.pt= ${ds}
          where a.pt= ${ds} and a.package_status in ('当前','未到')
         ) c  -- 应用模块明细
     group by c.member_id
    ) t4
    on t1.user_id=t4.member_id

left join dws_cus_company_partner_d_f t5     --it_project.dws_cus_company_partner_d_f t5  -- 商户合作伙伴情况
    on t1.user_id=t5.user_id
    and t5.pt= ${ds}
left join dws_cus_company_prod_d_f t6    --it_project.dws_cus_company_prod_d_f t6  -- 商户销售产品数量表
    on t1.user_id=t6.user_id
    and t6.pt= ${ds}
-- left join 
--     (
--         select distinct user_id from data_middle_bi.ods_pft_login_log_d_f
--          where  pt='pt' and login_source=2  and  substr(login_time,1,4)>='2023'  --2022年后终端登陆

--     )t7
--        on t1.user_id=t7.user_id


left join 
    (
	--海报推广次数
	select -- substr(from_unixtime(create_time,'yyyy-MM-dd HH:mm:ss'),1,7)  create_time,
        member_id,COUNT(*) as fcount
	from ods_cha_pft_posters_d_f
	where pt = ${ds}
	GROUP BY 
	-- substr(from_unixtime(create_time,'yyyy-MM-dd HH:mm:ss'),1,7) ,
	member_id
    )t8
    on t1.user_id=t8.member_id

left join 
    (
	--产品类型个数
	select apply_did,count(distinct p_type) as fcount 
	from ods_uu_land_d_f    --data_middle_bi.s_uu_land_d_f where pt ='${bdp.system.bizdate}' 
	where pt= ${ds}
    and nvl(passtime,'')<>''
	group by apply_did
	)t9
    on t1.user_id=t9.apply_did

left join
    (--ota分销商数
      SELECT a.parent_id,
      count(distinct case when a.son_type='OTA' and a.relationship_type=0 and  ifnull(b.user_id,'')<>''    then  a.son_id else null end )      as  fcount
      from dim_user_relationship_d_f a     --data_middle_bi.dim_user_relationship_d_f  a
      left join dim_user_d_f b     --data_middle_bi.dim_user_d_f b
          on a.parent_id=b.user_id
          and b.pt= ${ds}
          and b.user_is_test='正式'
          and b.user_type='分销商'
      where a.pt= ${ds} and a.status=0
      group by a.parent_id
	)t10
	on t1.user_id=t10.parent_id
	
left join
    (--线下票务系统接口数
	 select pft_memberid,count(distinct cid) as fcount
     from ods_pft_con_sys_member_d_f   --data_middle_bi.s_pft_con_sys_member_d_f
	 where pt= ${ds} and status=0   --0是绑定状态
	 group by pft_memberid
	) t11
	on t1.user_id=t11.pft_memberid

left join
    (--销售报表下载次数
	 select fid,sum(download) as fcount from ods_cus_excel_task_d_f     --it_project.ods_cus_excel_task_d_f
	 where pt= ${ds}
	 group by fid
	) t12
	on t1.user_id=t12.fid

left join
    (--物料中心（扫码次数）
	 select sid,sum(count_num) as fcount from ods_cus_pft_material_center_d_f    --it_project.ods_cus_pft_material_center_d_f
	 where pt= ${ds}
	 group by sid
	)t13
	on t1.user_id=t13.sid

left join
    (--短信条数
	 select aid,sum(msgcnt) as  fcount  
	 from ods_cus_pft_sms_journal_d_i
	 group by aid
	) t14
    on t1.user_id=t14.aid

left join
    (--营销类短信条数
	 select uid,count(*)  as fcount
	 from ods_cus_pft_marketing_sms_task_d_f    --it_project.ods_cus_pft_marketing_sms_task_d_f
	 where pt= ${ds} 
	 group by uid
	)t15
    on t1.user_id=t15.uid


left join 
	(select fid  as user_id
	    ,concat_ws(';',collect_set(ifnull(
                case when  product_type ='A' then '景区'  when  product_type ='B' then '线路'
                    when  product_type ='C' then '酒店'  when  product_type ='F' then '套票'
                    when  product_type ='G' then '餐饮'  when  product_type ='I' then '年卡'
                    when  product_type ='H' then '演出'  when  product_type ='J' then '特产'
                    when  product_type ='K' then '计时产品'  when  product_type ='Q' then '旅游券'
                    else '其他'
                end 
		   ,'') )) as product_type_list
     from ods_cus_pft_member_product_config_d_f    --it_project.ods_cus_pft_member_product_config_d_f
	 where pt= ${ds}
	 and is_deleted=0  --未删除
	 and open_status=1 --已开通
	 group by fid
	) t16
	on t1.user_id=t16.user_id







left join 
	(select fid as user_id    
        ,concat_ws(',',collect_list(ifnull(
                case when  coop_content_list =1 then '分销平台系统'  when  coop_content_list =2 then '商城小程序系统'
                        when  coop_content_list =3 then '短信合作'  when  coop_content_list =4 then '年卡系统'
                        when  coop_content_list =5 then '一卡通系统'  when  coop_content_list =6 then '云票务系统'
                        when  coop_content_list =7 then '手持机合作'  when  coop_content_list =8 then '自助机合作'
                        when  coop_content_list =9 then '闸机合作'   when  coop_content_list =10 then '票务系统硬件'
                        when  coop_content_list =11 then '停车场系统'  when  coop_content_list =12 then '收银系统'
                        when  coop_content_list =13 then '一机游'  when  coop_content_list =14 then '全域旅游'
                        when  coop_content_list =15 then '综管平台'
                        else ''
                    end 
            ,'') )) as coop_content_list
	 from (select fid,coop_content_list
		   from (select fid
			 		,get_json_object(ext,'$.cooperation_content')  as coop_content
			 	 from ods_myuu_pft_member_extinfo_d_f    --data_middle_bi.s_myuu_pft_member_extinfo_d_f 
			 	 where pt= ${ds}
			 	 and get_json_object(ext,'$.cooperation_content') <>''
			    )a
			lateral view explode(split(coop_content,',')) t as  coop_content_list
		 )a
		group by fid
	) t17
    on t1.user_id=t17.user_id


left join
	(select field_0w21l__c,field_i4oZj__c -- 合作客户等级
	        ,row_number() over(partition by field_0w21l__c order by last_deal_closed_time desc ) as pm
	 from dws_cus_pft_crm_account_d_f     --it_project.dws_cus_pft_crm_account_d_f
	 where pt = ${ds}
	) t18  
	on t1.user_id=t18.field_0w21l__c
    and t18.pm = 1

left join 
	(select field_0w21l__c ,field_i4oZj__c -- 合作客户等级
	    ,row_number() over(partition by field_0w21l__c order by last_deal_closed_time desc ) as pm
	 from dws_cus_pft_crm_account_d_f    --it_project.dws_cus_pft_crm_account_d_f
	 where pt = ${ds}
	) t19  
	on t1.customer_mobile=t19.field_0w21l__c
    and t19.pm = 1

left join 
	(select package_id  
	    ,concat_ws(';',collect_set(ifnull(
                case when  product_type ='A' then '景区'   when  product_type ='B' then '线路'
                        when  product_type ='C' then '酒店'   when  product_type ='F' then '套票'
                        when  product_type ='G' then '餐饮'   when  product_type ='I' then '年卡'
                        when  product_type ='H' then '演出'   when  product_type ='J' then '特产'
                        when  product_type ='K' then '计时产品'   when  product_type ='Q' then '旅游券'
                        else '其他'
                    end 
		    ,'') )) as product_type_list
	 from ods_cus_pft_package_product_config_d_f    --it_project.ods_cus_pft_package_product_config_d_f
	 where pt =  ${ds}
	 and is_deleted=0
	 group by package_id
	) t20
	on t2.user_curr_package_id = t20.package_id  


left join
    (select user_id,user_name
     from ods_pft_member_d_f    --data_middle_bi.ods_pft_member_d_f
     where pt= ${ds} and user_type='员工'
    ) t21 
	on t1.signer_id = t21.user_id

left join
    (select user_id,user_name
     from ods_pft_member_d_f     --data_middle_bi.ods_pft_member_d_f
     where pt= ${ds} and user_type='员工'
    ) t22
	on t1.servicer_id = t22.user_id

where t1.pt = ${ds}

;















