--********************************************************************--
--author: 施建伟
--create time: 2026-06-03 17:17:43
--EMR任务只能运行在独享资源组上
--********************************************************************--
/*
CREATE TABLE IF NOT EXISTS ads_resource_center_cutchain_order_d_f(
    order_id                STRING  COMMENT '订单号',
    main_order_id           STRING  COMMENT '主票id',
    order_type              STRING  COMMENT '订单类型 套票主票/套票子票/单票',
    remote_order_id         STRING  COMMENT '远程订单号',
    is_team                 TINYINT COMMENT "是否为团队订单：0否 1是",
    team_order_id           STRING  COMMENT '团队订单号',
    order_status_code       INT     COMMENT '订单状态编码',
    order_status            STRING  COMMENT '订单状态',
    order_pay_status        INT     COMMENT '订单支付状态:0=现场支付,1=已支付,2=未支付', 
    booking_time            STRING  COMMENT '下单时间',
    vertify_time            STRING  COMMENT '验证时间',
    cancel_time             STRING  COMMENT '取消时间',
    play_time               STRING  COMMENT '预计游玩时间',
    begin_time              STRING  COMMENT '开始时间',
    end_time                STRING  COMMENT '结束时间', 
    seller_id               STRING  COMMENT '销售者/收款人', 
    booker_id               STRING  COMMENT '购买者', 
    booker_name             STRING  COMMENT '购买者名称', 
    booker_type             STRING  COMMENT "购买者身份",
    ticket_num              INT     COMMENT '票数',
    order_pay_amount        BIGINT  COMMENT '订单支付金额',
    land_type               STRING  COMMENT '景区类型代码：A景区B线路C酒店F套票G餐饮I年卡H演出J特产K计时产品',
    land_type_name          STRING  COMMENT '景区类型：A景区B线路C酒店F套票G餐饮I年卡H演出J特产K计时产品',
    land_topic              STRING  COMMENT "景区主题类型",
    resource_id             INT     COMMENT '资源ID',
    resource_name           STRING  COMMENT '资源名',
    product_id              INT     COMMENT '产品id',
    ticket_id               INT     COMMENT '票id',
    ticket_fullname         STRING  COMMENT '票名',
    land_id                 INT     COMMENT '景区id',
    land_name               STRING  COMMENT "景区名",
    land_publisher_id       INT     COMMENT '景区发布商id',
    land_publisher_name     STRING  COMMENT "景区名"  ,
    land_province           STRING  COMMENT "景区所在省",
    land_city               STRING  COMMENT '景区城市名称',
    is_ota                  STRING  COMMENT "是否OTA订单",
    distribute_system_name  STRING  COMMENT "对接分销平台名称",
    booking_channel         STRING  COMMENT '销售渠道ID',
    booking_channel_name    STRING  COMMENT '销售渠道名称',
    belong_area             STRING  COMMENT '产品归属区域',
    booking_num             INT    COMMENT '预定票数',
    booking_pay_amount      BIGINT COMMENT '预定金额',
    fail_reason             STRING COMMENT '失败原因',
    fail_code               STRING COMMENT '失败代码',
    ticket_taker_province   STRING COMMENT '客源地省',
    ticket_taker_city       STRING COMMENT '客源地市',
    resource_center_supplier_id             INT COMMENT '资源中心供货商id',
    resource_center_purchase_id             INT COMMENT '资源中心采购商id',
    resource_center_supplier_account        STRING COMMENT "资源中心上架产品商户账号",
    resource_center_supplier_name           STRING COMMENT "资源中心上架产品商户名称",
    resource_center_supplier_province       STRING COMMENT "资源中心上架产品商户省",
    resource_center_supplier_city           STRING COMMENT "资源中心上架产品商户市",
    resource_center_supplier_belong_area    STRING COMMENT "资源中心上架产品商户市归属区域",
    resource_center_supplier_is_test        STRING COMMENT "资源中心上架产品商户是否测试账号",
    resource_center_supplier_type           STRING COMMENT "资源中心上架产品商户类型",
    resource_center_supplier_auto_get       STRING COMMENT "资源中心上架产品商为自动获取？",
    resource_center_purchase_account        STRING COMMENT "资源中心采购商账号",
    resource_center_purchase_name           STRING COMMENT "资源中心采购商名称",
    resource_center_purchase_province       STRING COMMENT "资源中心采购商省",
    resource_center_purchase_city           STRING COMMENT "资源中心采购商市",
    resource_center_purchase_belong_area    STRING COMMENT "资源中心采购商归属区域",
    resource_center_purchase_is_test        STRING COMMENT "资源中心采购商是否测试账号",
    resource_center_purchase_type           STRING COMMENT "资源中心采购商类型"
)PARTITIONED BY(
    pt INT 
)STORED AS ORC;
*/
CACHE TABLE cache_dim_user_d_f
SELECT user_id, user_account, user_name, customer_province, customer_city, user_is_test, user_type, is_resource_center_auto_get_user
FROM dim_user_d_f 
WHERE pt = '${ds}' AND user_type IN ('分销商','供应商') AND user_is_test='正式';
INSERT OVERWRITE TABLE ads_resource_center_cutchain_order_d_f PARTITION (pt = "${ds}") 
SELECT  
    a.orderid               ,
    o.main_order_id         ,
    o.order_type            ,
    o.remote_order_id       ,
    o.is_team               ,
    o.team_order_id         ,
    o.order_status_code     ,
    o.order_status          ,
    o.order_pay_status      ,
    o.booking_time          ,
    o.verify_time           ,
    o.cancel_time           ,
    o.play_time             ,
    o.begin_time            ,
    o.end_time              ,
    o.seller_id             ,
    o.booker_id             ,
    o.booker_name           ,
    o.booker_type           ,
    o.ticket_num            ,
    o.order_pay_amount      ,
    o.land_type             ,
    o.land_type_name        ,
    o.land_topic            ,
    o.resource_id           ,
    o.resource_name         ,
    o.product_id            ,
    o.ticket_id             ,
    o.ticket_fullname       ,
    o.land_id               ,
    o.land_name             ,
    o.land_publisher_id     ,
    o.land_publisher_name   ,
    o.land_province         ,
    o.land_city             ,
    --分销类型：末级对接第三方平台类型是OTA且不是直销的为OTA 
    --卖家是资源中心采购商或供应商为采购商直销 否则为分销
    CASE 
        WHEN o.distribute_system_type = 'OTA' OR (o.booking_channel = 17) THEN '是' 
        ELSE '否' 
    END                                             AS is_ota,
    -- 第三方分销也列出对接系统名称
    CASE 
        WHEN o.booking_channel = 20 THEN o.distribute_system_name
        WHEN o.booking_channel = 17 THEN '淘宝/飞猪'
    END                                             AS distribute_system_name,
    o.booking_channel                               AS booking_channel,
    --下单渠道为OTA（booking_channel=20） 且 末级第三方平台类型是OTA 的为OTA 剩下的下单渠道为OTA（booking_channel=20）的为第三方对接 
    --下单渠道booking_channel=17(淘宝/飞猪) 为OTA
    CASE 
        WHEN (o.distribute_system_type = 'OTA' AND o.booking_channel = 20) OR (o.booking_channel = 17) THEN 'OTA'
        ELSE IF(o.booking_channel = 20,'第三方对接', o.booking_channel_name)
    END                                             AS booking_channel_name,
    di.district                                     AS belong_area,
    o.booking_num                                   AS booking_num,
    o.booking_pay_amount                            AS booking_pay_amount,
    NULL                                            AS fail_reason,
    NULL                                            AS fail_code,
    o.ticket_taker_province,
    o.ticket_taker_city,
    a.sellerid                                      AS resource_center_supplier_id,
    a.buyerid                                       AS resource_center_purchase_id,
    ms.user_account                                 AS resource_center_supplier_account,
    ms.user_name                                    AS resource_center_supplier_name,
    ms.customer_province                            AS resource_center_supplier_province,
    ms.customer_city                                AS resource_center_supplier_city,
    ds.district                                     AS resource_center_supplier_belong_area,
    ms.user_is_test                                 AS resource_center_supplier_is_test,
    ms.user_type                                    AS resource_center_supplier_type,
    ms.is_resource_center_auto_get_user             AS resource_center_supplier_auto_get,
    mp.user_account                                 AS resource_center_purchase_account,
    mp.user_name                                    AS resource_center_purchase_name,
    mp.customer_province                            AS resource_center_purchase_province,
    mp.customer_city                                AS resource_center_purchase_city,
    dp.district                                     AS resource_center_purchase_belong_area,
    mp.user_is_test                                 AS resource_center_purchase_is_test,
    mp.user_type                                    AS resource_center_purchase_type
FROM 
(
    SELECT orderid, sellerid, buyerid 
    FROM ods_order_split_d_i 
    WHERE orderdate > DATE_FORMAT(date_sub(TO_DATE('${ds}', 'yyyyMMdd'), 732), 'yyyyMMdd')
) AS a
-- 关联旅资断联的分销关系
JOIN 
(
    SELECT r1.parent_id, r1.son_id, MIN(r1.add_time) AS add_time --r1.relationship_type,r1.cut_time,r1.status
    FROM 
    (
        SELECT parent_id, son_id, add_time, cut_time, relationship_type, status 
        FROM dim_user_relationship_d_f  
        WHERE pt = '${ds}' AND status = 0 AND relationship_type = 0
    ) AS r1
    JOIN 
    (
        SELECT parent_id, son_id, add_time, cut_time, relationship_type, status 
        FROM dim_user_relationship_d_f  
        WHERE pt = '${ds}' AND status = 1 AND relationship_type = 4
    ) AS r2 
    ON r1.parent_id = r2.parent_id AND r1.son_id = r2.son_id AND r1.add_time >= r2.cut_time
    GROUP BY r1.parent_id, r1.son_id
) b ON a.sellerid = b.parent_id AND a.buyerid = b.son_id
LEFT JOIN cache_dim_user_d_f AS ms 
ON a.sellerid = ms.user_id 
LEFT JOIN cache_dim_user_d_f AS mp 
ON a.buyerid = mp.user_id
-- 过滤资源中心订单,未支付订单
JOIN 
(
    SELECT 
        main_order_id,  
        order_type,     
        remote_order_id,
        is_team,             
        team_order_id,       
        order_status_code,   
        order_status,        
        order_pay_status,    
        booking_time,        
        verify_time,        
        cancel_time,         
        play_time,           
        begin_time,          
        end_time,            
        seller_id,           
        booker_id,           
        booker_name,         
        booker_type,         
        ticket_num,          
        order_pay_amount,    
        land_type,           
        land_type_name,      
        land_topic,          
        resource_id,         
        resource_name,       
        product_id,          
        ticket_id,           
        ticket_fullname,     
        land_id,             
        land_name,           
        land_publisher_id,   
        land_publisher_name, 
        land_province,       
        land_city,           
        distribute_system_type,
        booking_channel,
        booking_num,
        booking_pay_amount,
        ticket_taker_province,
        ticket_taker_city,
        order_id,
        booking_time,
        record_id,
        distribute_system_name,
        booking_channel_name 
    FROM dwd_order_d_i 
    WHERE booking_date > DATE_FORMAT(date_sub(TO_DATE('${ds}', 'yyyyMMdd'), 732), 'yyyyMMdd')
    AND order_pay_status <> 2 AND resource_center_supplier_id IS NULL
) AS o 
ON a.orderid = o.order_id AND b.add_time < o.booking_time
-- OTA失败订单去重
JOIN 
(
    SELECT o1.order_id_sigle, MAX(o1.record_id) AS record_id
    FROM 
    (
        SELECT IF(remote_order_id IS NULL OR remote_order_id='',order_id,remote_order_id) AS order_id_sigle, record_id, order_id, remote_order_id
        FROM dwd_order_d_i 
        WHERE booking_date > DATE_FORMAT(date_sub(TO_DATE('${ds}', 'yyyyMMdd'), 732), 'yyyyMMdd')
          AND resource_center_supplier_id IS NULL AND order_pay_status <2 
    ) AS o1
    GROUP BY o1.order_id_sigle 
) AS o2 
ON o.record_id=o2.record_id
LEFT JOIN 
(
    SELECT district, province
    FROM dim_resource_center_district_o_f
) AS ds  
ON ms.customer_province=ds.province
LEFT JOIN 
(
    SELECT district, province
    FROM dim_resource_center_district_o_f
) AS dp 
ON mp.customer_province=dp.province
-- 关联产品归属区域
LEFT JOIN 
(
    SELECT district, province
    FROM dim_resource_center_district_o_f
) AS di 
ON o.land_province=di.province
WHERE ms.user_id IS NOT NULL AND mp.user_id IS NOT NULL