--********************************************************************--
--author: 施建伟
--create time: 2026-05-25 09:42:20
--EMR任务只能运行在独享资源组上
--********************************************************************--
create table if NOT EXISTS ads_res_center_assessment_province2022_detail_d_f
(
booking_month       string COMMENT '考核月份',
belong_area         string COMMENT '归属区域',
province            string COMMENT '省',
resource_land_id    string COMMENT 'ID',
type                string COMMENT '分类'
,resource_land_name string COMMENT '名称'
)COMMENT'资源中心新增考核指标表-明细'
PARTITIONED BY (
    pt STRING
)STORED AS ORC;
insert OVERWRITE table ads_res_center_assessment_province2022_detail_d_f PARTITION (pt="${ds}") 
select distinct  a.booking_month,
       case when d.district is null then '未知' else  d.district  end  as belong_area,
       a.province,
       a.resource_land_id,
       a.type
       ,a.resource_land_name
from (
      ----新增手动供应业态景区数（部门考核）-直签 --resource_type  注释：资源选项 0：未知  1：第三方 2：直签
      select substr(booking_month,1,10) as booking_month
            ,land_province province
            ,resource_land_id
            ,'新增唯一产品数（部门考核）-直签（大于10单）' as type 
            ,resource_land_name
      from (select a.booking_time as booking_month
                ,a.resource_land_id
                ,a.land_province
                ,b.resource_type
                ,b.add_time
                ,resource_land_name
                ,row_number() over(partition by a.resource_land_id,a.land_province,b.resource_type,b.add_time order by  a.booking_time ) as pm
            from ads_resource_center_order_d_f  a
            inner join
                (select a.add_time
                      ,a.resource_land_id
                      ,a.resource_type
                 from (select * from dws_res_resource_center_land_attr_detail_d_f where pt = ${ds} ) a
                 where  a.pm=1
                ) b
                on a.resource_land_id=b.resource_land_id
            where a.pt = ${ds}
            and b.resource_type in(1,2)
            and a.booking_time>=b.add_time
           ) c
      where pm=10 and resource_type=2
      ----新增手动供应业态景区数（部门考核）-直签 --resource_type  注释：资源选项 0：未知  1：第三方 2：直签
      union all
      select substr(booking_month,1,10) as booking_month
            ,land_province province
            , resource_land_id
            ,'新增唯一产品数（部门考核）-第三方（大于10单）' as type 
            ,resource_land_name
      from (select a.booking_time as booking_month
                    ,a.resource_land_id
                    ,a.land_province
                    ,b.resource_type
                    ,b.add_time
                    ,resource_land_name
                    ,row_number() over(partition by a.resource_land_id,a.land_province,b.resource_type,b.add_time order by  a.booking_time ) as pm
            from ads_resource_center_order_d_f  a
            inner join
                (select a.resource_land_add_time as add_time
                      ,a.resource_land_id
                      ,a.resource_type
                 from (select * from dws_res_resource_center_land_attr_detail_d_f where pt = ${ds} ) a
                 where  a.pm=1   
                ) b
                on a.resource_land_id=b.resource_land_id
            where a.pt = ${ds}
            and b.resource_type in(1,2)
            and a.booking_time>=b.add_time
      ) c
      where pm=10 and resource_type=1
      --资源中心订单表中采购商产生第10单的时间为考核时间
      UNION ALL 
      select substr(booking_month,1,10) as booking_month
            ,land_province as province
            ,resource_center_purchase_id
            ,'累计交易10单采购商数' as  type
            ,resource_center_purchase_name
      from (select booking_time as booking_month    --下单时间
                 ,resource_center_purchase_province as land_province   --省
                 ,resource_center_purchase_id --采购商ID
                 ,resource_center_purchase_name
                 ,row_number() over(partition by  resource_center_purchase_province,resource_center_purchase_id order by  booking_time   ) as pm
            from  ads_resource_center_order_d_f
            where pt = ${ds}
          ) a
      where substr(booking_month,1,10)>='2022-01-01' and pm=10
      union all 
      select booking_month
            ,land_province
            ,resource_center_supplier_id
            ,'新增标杆景区供货商数'  AS TYPE
            ,resource_center_supplier_name
      from (select substr(a.booking_time,1,10) as booking_month
                ,a.resource_center_supplier_province as land_province
                ,a.resource_center_supplier_id
                ,a.resource_center_supplier_name
                ,count(*) over(partition by substr(a.booking_time,1,7),a.resource_center_supplier_province,a.resource_center_supplier_id) AS fcount
            from ads_resource_center_order_d_f  a
            where a.pt = ${ds}
            and a.resource_center_supplier_id in 
                (select user_id
                 from dim_resource_center_user_d_f b     --判断是否供货商
                 where  b.pt = ${ds}
                 and b.customer_type='景区'
                 and b.settled_time<>''
                )
            --不知道为什么不能用inner join所以用这个写法 找到问题了是out of memory了   要调整参数才能
          ) k 
      where fcount>=250 
      union all 
      select booking_month
            ,land_province
            ,resource_center_supplier_id
            ,'新增标杆旅行社供货商数'  AS TYPE
            ,resource_center_supplier_name
      from (select substr(a.booking_time,1,10) as booking_month
                ,a.resource_center_supplier_province as land_province
                ,a.resource_center_supplier_id
                ,a.resource_center_supplier_name
                ,count(*) over(partition by substr(a.booking_time,1,7),a.resource_center_supplier_province,a.resource_center_supplier_id) AS fcount
            from ads_resource_center_order_d_f  a
            where a.pt = ${ds}
            and a.resource_center_supplier_id in
                (select user_id
                 from dim_resource_center_user_d_f b     --判断是否供货商
                 where b.pt = ${ds}
                 and b.customer_type<>'景区'
                 and b.settled_time<>''
                )
            --不知道为什么不能用inner join所以用这个写法 找到问题了是out of memory了   要调整参数才能
           )k 
      where fcount>=750
      union all 
      select substr(b.booking_time,1,10) as booking_month,
            b.land_province,
            b.resource_center_purchase_id,
            '新增标杆采购商数'  AS TYPE
            ,resource_center_purchase_name
      from (select resource_center_purchase_province as land_province,
                booking_time,
                resource_center_purchase_id,
                resource_center_purchase_name,
                sum(order_pay_amount) over(partition by substr(booking_time,1,7),resource_center_purchase_province,resource_center_purchase_id) as order_pay_amount
            from ads_resource_center_order_d_f
            where pt = ${ds}
            ) b
      where order_pay_amount>=100000
      --资源中心订单表中采购商产生超过10单后有产生订单的月份都算
      union all
      select substr(booking_month,1,10) as booking_month
              ,land_province as province
              ,resource_center_purchase_id
              ,'累计交易超过10单采购商数' as  type
              ,resource_center_purchase_name
      from (select substr(booking_month,1,7) as booking_month
                  ,land_province
                  ,resource_center_purchase_id
                  ,resource_center_purchase_name
                  ,sum(case when pm>=10 then 1 else 0 end) as fmark
            from (select booking_time as booking_month    --下单时间
                      ,resource_center_purchase_province as land_province   --省
                      ,resource_center_purchase_id --采购商ID
                      ,resource_center_purchase_name
                      ,row_number() over(partition by  resource_center_purchase_province,resource_center_purchase_id order by booking_time ) as pm
                  from  ads_resource_center_order_d_f
                  where pt = ${ds}
                ) a 
            group by substr(booking_month,1,7)  ,land_province  ,resource_center_purchase_id  ,resource_center_purchase_name
          ) a
      where fmark>0
      UNION ALL
      select substr(booking_time,1,10) as booking_month
            ,resource_center_purchase_province province
            ,resource_center_purchase_id
            ,'交易采购商数' as type
            ,resource_center_purchase_name
      from  dwd_resource_center_order_d_f
      where pt = ${ds}
    ) a
left join (select * from dim_res_resource_center_district_2022_d_f) d
    on d.province=a.province
where  booking_month>='2022-01-01' 
-- order by booking_month desc,a.belong_area,a.province
;
