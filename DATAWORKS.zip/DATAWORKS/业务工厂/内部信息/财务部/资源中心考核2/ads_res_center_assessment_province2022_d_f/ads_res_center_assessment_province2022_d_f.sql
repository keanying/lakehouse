--********************************************************************--
--author: 施建伟
--create time: 2026-05-21 10:51:40
--EMR任务只能运行在独享资源组上
--资源中心新增考核指标表
--********************************************************************--
create table if NOT EXISTS ads_res_center_assessment_province2022_d_f(
    booking_month               string COMMENT '考核月份',
    belong_area                 string COMMENT '归属区域',
    province                    string COMMENT '省',
    active_num                  int COMMENT '新增激活用户数（订单>=1）',
    enter_num                   int COMMENT '新增入驻用户数',  
    ticket_num                  int COMMENT '新增手动供应票种数',
    ticket_active_num           int COMMENT '新增启用票类（订单>=1）',
    land_num                    int COMMENT '新增手动供应产品数',
    land_active_num             int COMMENT '新增启用产品数（订单>=1）',
    active_10_num               int COMMENT '新增激活用户数（订单>=10）',
    land_active_10_num          int COMMENT '新增激活产品数（订单>=10）',
    active_purchase_num         int comment '新增激活采购商数（订单>=1）',
    trade_purchase_num          int comment '交易采购商数',
    order_pay_amount            bigint COMMENT 'gmv(预定金额)元',
    cutchain_pay_amount         bigint COMMENT '断连gmv(预定金额)元',
    order_pay_cg_amount         bigint COMMENT '采购商-gmv(预定金额)元',
    cutchain_pay_cg_amount      bigint COMMENT '采购商-断连gmv(预定金额)元',
    land_num_depart             bigint COMMENT '新增唯一产品数（部门考核）',
    land_num_depart_direct      bigint COMMENT '新增唯一产品数（部门考核）-直签',
    land_num_depart_third       bigint COMMENT '新增唯一产品数（部门考核）-第三方',
    land_num_company            bigint COMMENT '当月发生交易SPU数',
    land_num_depart_direct_10   bigint COMMENT '新增唯一产品数（部门考核）-直签（大于10单）',
    land_num_depart_third_10    bigint COMMENT '新增唯一产品数（部门考核）-第三方（大于10单）',
    land_purchase_num_10        bigint COMMENT '累计交易10单采购商数',
    land_num_250                bigint COMMENT '新增标杆景区供货商数',
    noland_num_750              bigint COMMENT '新增标杆旅行社供货商数',
    purchase_account_10         bigint COMMENT '新增标杆采购商数',
    purchase_account_10_add     bigint COMMENT '累计交易超过10单采购商数',
    import_province             int  comment '1--重要省',
    -- 新增字段
    profit                      bigint COMMENT '利润元'
) COMMENT'资源中心新增考核指标表'
PARTITIONED BY(`pt` string) 
STORED AS ORC;
insert OVERWRITE table ads_res_center_assessment_province2022_d_f PARTITION (pt="${ds}") 
select a.booking_month
       --5月起营收   林丰：浙江 江苏 上海 湖南 海南   王佳鑫：湖北 山西 河北 安徽  河南
       ,case when d.district is null then '未知'
             when a.booking_month>='2026-05' and d.district='陈娟芳' then
                  case when a.province in ('浙江省','江苏省','上海市','湖南省','海南省') then '林丰'
                       when a.province in ('湖北省','山西省','河北省','安徽省','河南省') then '王佳鑫'
                    end
             else  d.district  end  as belong_area
       ,a.province
       ,sum(if(type='新增激活',num,0)) as active_num
       ,sum(if(type='新增入驻',num,0)) as enter_num
       ,sum(if(type='新增票类',num,0)) as ticket_num
       ,sum(if(type='新增启用票类',num,0)) as ticket_active_num
       ,sum(if(type='新增产品数',num,0)) as land_num
       ,sum(if(type='新增启用产品数',num,0)) as land_active_num
       ,sum(if(type='新增订单≥10用户数',num,0)) as active_10_num
       ,sum(if(type='新增订单≥10产品数',num,0)) as land_active_10_num
       ,sum(if(type='新增激活采购商数',num,0)) as active_purchase_num
       ,sum(if(type='交易采购商数',num,0)) as trade_purchase_num
       ,sum(if(type='GMV',num,0)) as order_pay_amount
       ,sum(if(type='断连GMV',num,0)) as cutchain_pay_amount
       ,sum(if(type='GMV-采购商',num,0)) as order_pay_cg_amount
       ,sum(if(type='断连GMV-采购商',num,0)) as cutchain_pay_cg_amount
       ,sum(if(type='新增唯一产品数（部门考核）',num,0)) as land_num_depart
       ,sum(if(type='新增唯一产品数（部门考核）-直签',num,0)) as land_num_depart_direct
       ,sum(if(type='新增唯一产品数（部门考核）-第三方',num,0)) as land_num_depart_third
       ,sum(if(type='当月发生交易SPU数',num,0)) as land_num_company
       ,sum(if(type='新增唯一产品数（部门考核）-直签（大于10单）',num,0)) as land_num_depart_direct_10
       ,sum(if(type='新增唯一产品数（部门考核）-第三方（大于10单）',num,0)) as land_num_depart_third_10
       ,sum(if(type='累计交易10单采购商数',num,0)) as land_purchase_num_10
       ,sum(if(type='新增标杆景区供货商数',num,0)) as land_num_250
       ,sum(if(type='新增标杆旅行社供货商数',num,0)) as noland_num_750
       ,sum(if(type='新增标杆采购商数',num,0)) as purchase_account_10
       ,sum(if(type='累计交易超过10单采购商数',num,0)) as purchase_account_10_add
       ,cast (d.import_province as int) as import_province
       ,sum(if(type='利润',num,0)) as profit        -- 利润
from (---新增激活用户（供货商+采购商），首单即激活
      select substr(a.first_booking_time,1,7) as booking_month--,a.belong_area
            ,a.province
            ,count(distinct a.user_id) as num ,'新增激活' as type 
      from (select case when  min_purchase_booking_time is null and min_supply_booking_time is not null then min_supply_booking_time
                        when  min_purchase_booking_time is not null and min_supply_booking_time is  null then min_purchase_booking_time
                        when  min_purchase_booking_time > min_supply_booking_time then min_supply_booking_time
                        else  min_purchase_booking_time
                     end first_booking_time
                  ,belong_area,customer_province province,user_id
            from dws_resource_center_user_d_f 
            where pt = ${ds}
               and (min_supply_booking_time is not null or min_purchase_booking_time is not null)
               --and enter_resource_status<>'未入驻' -- and year(enter_time)=year(date_sub(current_date(),1)) 
          ) a
      group by substr(a.first_booking_time,1,7) ,a.province
      ----新增入驻
      union all
      select booking_month
            ,case when user_id=38302503 then '福建省' else province end as province
            ,count(distinct user_id) as num ,'新增入驻' as type 
      from (select a.member_id user_id
                ,b.customer_province province
                ,min(from_unixtime(a.add_time,'yyyy-MM'))  as booking_month  
            from ods_pft_resource_amount_operation_track_d_f a 
            left join dws_resource_center_user_d_f  b 
                on a.member_id=b.user_id
                and b.pt = ${ds}
            where a.pt = ${ds}
            and a.op_type=1
            and a.member_id not in('46992','13912747','12041060','14475274','16753023','23604282','24443195','7309895','32343705' 
                  ,'38320338','38322741','38335458')
            group by a.member_id,b.customer_province
           ) c 
      group by booking_month,case when user_id=38302503 then '福建省' else province end
      ----新增启用票类（订单>=1）
      union all
      select substr(min_booking_time,1,7) as booking_month
            ,land_province province,count(distinct ticket_id) as num,'新增启用票类' as type 
      from ads_resource_center_ticket_summary_d_f
      where pt = ${ds}
      group by substr(min_booking_time,1,7) ,land_province
      ----新增启用产品（订单>=1）
      union all
      select substr(min_booking_time,1,7) as booking_month--,belong_area
            ,land_province province,count(distinct land_id) as num,'新增启用产品数' as type 
      from dws_resource_center_land_summary_d_f
      where pt = ${ds}
      group by substr(min_booking_time,1,7) ,land_province
      ----新增手动供应票类
      union all
      select substr(min_add_time,1,7) as booking_month--,belong_area
            ,land_province province,count(distinct ticket_id) as num,'新增票类' as type 
      from ads_resource_center_ticket_summary_d_f
      where pt = ${ds} and supply_type='手动供应' --and year(min_add_time)=year(date_sub(current_date(),1))
      group by substr(min_add_time,1,7) ,land_province
      union all
      ----新增手动供应产品数
      select substr(min_add_time,1,7) as booking_month--,belong_area
            ,land_province province,count(distinct land_id) as num,'新增产品数' as type 
      from dws_resource_center_land_summary_d_f
      where pt = ${ds} and supply_type='手动供应'  -- and year(min_add_time)=year(date_sub(current_date(),1))
      group by substr(min_add_time,1,7) ,land_province
      union all
      ----新增手动供应业态景区数（部门考核）
      select substr(a.resource_land_add_time,1,7) as booking_month--,belong_area
            ,land_province province,count(distinct a.resource_land_id) as num,'新增唯一产品数（部门考核）' as type 
      from (select resource_land_id,belong_area,land_province,min(resource_land_add_time) resource_land_add_time 
            from dws_resource_center_land_summary_d_f
            where pt = ${ds} and supply_type='手动供应'  -- and year(min_add_time)=year(date_sub(current_date(),1))
            group by resource_land_id,belong_area,land_province
           ) a
      group by substr(resource_land_add_time,1,7) ,land_province
      ----新增手动供应业态景区数（部门考核）-直签 --resource_type  注释：资源选项 0：未知  1：第三方 2：直签
      union all
      select substr(a.add_time,1,7) as booking_month--,belong_area  
            ,land_province province,count(distinct a.resource_land_id) as num,'新增唯一产品数（部门考核）-直签' as type 
      from (select * from dws_res_resource_center_land_attr_detail_d_f where pt = ${ds} ) a
      where a.resource_type=2 and a.pm=1
      group by substr(a.add_time,1,7) ,a.land_province
      ----新增手动供应业态景区数（部门考核）-第三方 --resource_type  注释：资源选项 0：未知  1：第三方 2：直签
      union all
      select substr(a.resource_land_add_time,1,7) as booking_month--,belong_area  
            ,land_province province,count(distinct a.resource_land_id) as num,'新增唯一产品数（部门考核）-第三方' as type 
      from (select * from dws_res_resource_center_land_attr_detail_d_f where pt = ${ds} ) a
      where a.resource_type=1 and a.pm=1
      group by substr(a.resource_land_add_time,1,7) ,a.land_province
      --当月发生交易SPU数
      UNION ALL 
      select substr(a.resource_land_add_time,1,7) as booking_month--,belong_area
            ,land_province province,count( a.resource_land_id) as num,'当月发生交易SPU数' as type 
      from (select resource_land_id,belong_area,land_province,resource_land_add_time resource_land_add_time 
            from dws_resource_center_land_summary_d_f
            where pt = ${ds}   -- and year(min_add_time)=year(date_sub(current_date(),1))
            and resource_land_add_time is not null
           ) a
      group by substr(resource_land_add_time,1,7) ,land_province
      -- 新增激活用户数（订单>=10）
      UNION ALL 
      select substr(booking_time,1,7) as booking_month --,belong_area
            ,province,count(distinct user_id) as num,'新增订单≥10用户数' as type
      from (select a.*,row_number() over(partition by user_id order by booking_time) as rn  
            from (select order_id,booking_time,resource_center_supplier_id as user_id,resource_center_supplier_belong_area  belong_area,resource_center_supplier_province province
                  from dwd_resource_center_order_d_f 
                  where pt = ${ds}
                  union all
                  select order_id,booking_time,resource_center_purchase_id as user_id,resource_center_purchase_belong_area belong_area,resource_center_purchase_province province
                  from dwd_resource_center_order_d_f 
                  where pt = ${ds}
                  ) a
            ) a 
      where rn=10
      group by substr(booking_time,1,7) ,province
      -- 新增激活产品数（订单≥10）
      union all
      select substr(booking_time,1,7) as booking_month --,belong_area
            ,land_province province,count(distinct land_id) as num,'新增订单≥10产品数' as type 
      from  dwd_resource_center_order_d_f
      where pt = ${ds} and order_no_land=10
      group by substr(booking_time,1,7) ,land_province
      -- 交易采购商数
      union all
      select substr(booking_time,1,7) as booking_month --,resource_center_purchase_belong_area belong_area
            ,resource_center_purchase_province province,count(distinct resource_center_purchase_id) as num,'交易采购商数' as type
      from dwd_resource_center_order_d_f
      where pt = ${ds}
      group by substr(booking_time,1,7) ,resource_center_purchase_province
      ----gmv(预定金额)
      UNION ALL 
      select substr(booking_time,1,7) as booking_month--,belong_area
            ,land_province province,round(sum(booking_pay_amount),2) as order_pay_amount,'GMV' as type
      from dwd_resource_center_order_d_f a
      where pt =  ${ds} --and a.booking_time>='2021-01-01'
      group by substr(booking_time,1,7) ,land_province
      ----断连gmv(预定金额)
      UNION ALL 
      select substr(booking_time,1,7) as booking_month--,belong_area
            ,land_province province,round(sum(booking_pay_amount),2) as order_pay_amount,'断连GMV' as type
      from ads_resource_center_cutchain_order_d_f a
      where pt = ${ds} --and a.booking_time>='2021-01-01'
      group by substr(booking_time,1,7) ,land_province
      -- 新增激活采购商数（有采购行为并首次产生订单≥10）
      union all
      select substr(pur.min_booking_time,1,7) as booking_month --,pur.belong_area
            ,pur.resource_center_purchase_province province,count(distinct pur.resource_center_purchase_id) as num,'新增激活采购商数' as type
      from (select resource_center_purchase_id,belong_area,resource_center_purchase_province, min_booking_time
            from (select resource_center_purchase_id,resource_center_purchase_belong_area belong_area,resource_center_purchase_province,booking_time as min_booking_time
                        ,row_number() over(PARTITION by resource_center_purchase_id order by booking_time) as pm
                        ,count(*)over(PARTITION by resource_center_purchase_id) as fcount
                  from dwd_resource_center_order_d_f
                  where pt = ${ds}
                 ) kl where pm=1 and fcount>=10
           ) pur
      group by substr(pur.min_booking_time,1,7) ,resource_center_purchase_province
      ----gmv(预定金额)-采购商
      UNION ALL 
      select substr(booking_time,1,7) as booking_month--,belong_area
            ,resource_center_purchase_province province,round(sum(booking_pay_amount),2) as order_pay_amount,'GMV-采购商' as type
      from dwd_resource_center_order_d_f a
      where pt = ${ds} --and a.booking_time>='2021-01-01'
      group by substr(booking_time,1,7) ,resource_center_purchase_province
      ----断连gmv(预定金额)-采购商
      UNION ALL 
      select substr(booking_time,1,7) as booking_month--,belong_area
            ,resource_center_purchase_province province,round(sum(booking_pay_amount),2) as order_pay_amount,'断连GMV-采购商' as type
      from ads_resource_center_cutchain_order_d_f a
      where pt = ${ds}  --and a.booking_time>='2021-01-01'
      group by substr(booking_time,1,7)  ,resource_center_purchase_province
      ----新增手动供应业态景区数（部门考核）-直签 --resource_type  注释：资源选项 0：未知  1：第三方 2：直签 
      union all
      select substr(booking_month,1,7) as booking_month
            ,land_province province
            ,count(distinct resource_land_id) as num,'新增唯一产品数（部门考核）-直签（大于10单）' as type 
      from (select 
                a.booking_time as booking_month
                ,a.resource_land_id
                ,a.land_province
                ,b.resource_type
                ,b.add_time
                ,row_number() over(partition by a.resource_land_id,a.land_province,b.resource_type,b.add_time order by  a.booking_time ) as pm
            from ads_resource_center_order_d_f a
            inner join
                (select a.add_time
                      ,a.resource_land_id
                      ,a.resource_type
                 from (select * from dws_res_resource_center_land_attr_detail_d_f where pt = ${ds} ) a
                 where a.pm=1
                ) b
                on a.resource_land_id=b.resource_land_id
            where a.pt= ${ds} and b.resource_type in(1,2)
            and a.booking_time>=b.add_time
           ) c
      where pm=10 and resource_type=2
      group by substr(booking_month,1,7) ,land_province
      ----新增手动供应业态景区数（部门考核）-直签 --resource_type  注释：资源选项 0：未知  1：第三方 2：直签
      union all
      select substr(booking_month,1,7) as booking_month
            ,land_province province
            ,count(distinct resource_land_id) as num,'新增唯一产品数（部门考核）-第三方（大于10单）' as type 
      from (select a.booking_time as booking_month
                ,a.resource_land_id
                ,a.land_province
                ,b.resource_type
                ,b.add_time
                ,row_number() over(partition by a.resource_land_id,a.land_province,b.resource_type,b.add_time order by  a.booking_time ) as pm
            from ads_resource_center_order_d_f a
            inner join
                (select a.resource_land_add_time as add_time
                        ,a.resource_land_id
                        ,a.resource_type
                 from (select * from dws_res_resource_center_land_attr_detail_d_f where pt= ${ds} ) a
                 where a.pm=1
                ) b
                on a.resource_land_id=b.resource_land_id
            where a.pt = ${ds} and b.resource_type in(1,2)
            and a.booking_time>=b.add_time
           ) c
      where pm=10 and resource_type=1
      group by substr(booking_month,1,7) ,land_province
      --资源中心订单表中采购商产生第10单的时间为考核时间
      UNION ALL 
      select substr(booking_month,1,7) as booking_month
            ,land_province as province
            ,count(distinct resource_center_purchase_id) as num
            ,'累计交易10单采购商数' as  type
      from (select booking_time as booking_month    --下单时间
                ,resource_center_purchase_province as land_province   --省
                ,resource_center_purchase_id --采购商ID
                ,row_number() over(partition by  resource_center_purchase_province,resource_center_purchase_id order by  booking_time ) as pm
            from ads_resource_center_order_d_f
            where pt = ${ds}
           ) a
      where substr(booking_month,1,10)>='2022-01-01' and pm=10
      group by substr(booking_month,1,7)  ,land_province
      union all 
      select booking_month
            ,land_province
            ,count(distinct resource_center_supplier_id) as num
            ,'新增标杆景区供货商数'  AS TYPE
      from (select l.booking_month,
                    l.land_province,
                    l.resource_center_supplier_id,
                    l.fcount,
                    dense_rank() over(partition  by  l.land_province,l.resource_center_supplier_id order by  l.booking_month )  as pm
            from (select substr(a.booking_time,1,7) as booking_month
                        ,a.resource_center_supplier_province as land_province
                        ,a.resource_center_supplier_id
                        ,count(*) over(partition by substr(a.booking_time,1,7),a.resource_center_supplier_province,a.resource_center_supplier_id) AS fcount
                  from ads_resource_center_order_d_f a
                  where a.pt = ${ds}
                  and a.resource_center_supplier_id in
                        (select user_id from dim_resource_center_user_d_f b     --判断是否供货商
                         where b.pt = ${ds}  and b.customer_type='景区'  and b.settled_time<>''
                        )
                )l
            where fcount>=250 
            --不知道为什么不能用inner join所以用这个写法 找到问题了是out of memory了   要调整参数才能
          ) k 
      where pm=1
      group by booking_month ,land_province
      union all 
      select booking_month
            ,land_province
            ,count(distinct resource_center_supplier_id) as num
            ,'新增标杆旅行社供货商数'  AS TYPE
      from (select l.booking_month,
                l.land_province,
                l.resource_center_supplier_id,
                l.fcount,
                dense_rank() over(partition  by  l.land_province,l.resource_center_supplier_id order by  l.booking_month )  as pm
            from (select substr(a.booking_time,1,7) as booking_month
                        ,a.resource_center_supplier_province as land_province
                        ,a.resource_center_supplier_id
                        ,count(*) over(partition by substr(a.booking_time,1,7),a.resource_center_supplier_province,a.resource_center_supplier_id) AS fcount
                  from ads_resource_center_order_d_f a
                  where a.pt = ${ds}
                  and a.resource_center_supplier_id in
                        (select  user_id from dim_resource_center_user_d_f b     --判断是否供货商
                         where b.pt=  ${ds}  and b.customer_type<>'景区'  and b.settled_time<>''
                        )
                )l
            where fcount>=750 
            --不知道为什么不能用inner join所以用这个写法 找到问题了是out of memory了   要调整参数才能
          )k 
      where pm=1
      group by booking_month ,land_province
      union all 
      select substr(b.booking_time,1,7) as booking_month,
            b.land_province,
            count(distinct b.resource_center_purchase_id) as num,
            '新增标杆采购商数'  AS TYPE
      from (select land_province,
                    booking_time,
                    resource_center_purchase_id,
                    order_pay_amount,
                    dense_rank() over(partition  by  l.land_province,l.resource_center_purchase_id order by  l.booking_time )  as pm
            from (select resource_center_purchase_province as land_province,
                        substr(booking_time,1,7) booking_time,
                        resource_center_purchase_id,
                        sum(order_pay_amount) over(partition by substr(booking_time,1,7),resource_center_purchase_province,resource_center_purchase_id) as order_pay_amount
                  from ads_resource_center_order_d_f
                  where pt = ${ds}
                ) L
            where l.order_pay_amount>=100000
           ) b
      where pm=1
      group by substr(b.booking_time,1,7) , b.land_province
      --资源中心订单表中采购商产生超过10单后有产生订单的月份都算
      union all
      select substr(booking_month,1,7) as booking_month
            ,land_province as province
            ,count(distinct resource_center_purchase_id) as num
            ,'累计交易超过10单采购商数' as  type
      from (select substr(booking_month,1,7) as booking_month
                ,land_province
                ,resource_center_purchase_id
                ,sum(case when pm>=10 then 1 else 0 end) as fmark
            from (select booking_time as booking_month    --下单时间
                        ,resource_center_purchase_province as land_province   --省
                        ,resource_center_purchase_id --采购商ID
                        ,row_number() over(partition by  resource_center_purchase_province,resource_center_purchase_id order by  booking_time   ) as pm
                  from ads_resource_center_order_d_f
                  where pt = ${ds}
                ) a 
            group by substr(booking_month,1,7)  ,land_province ,resource_center_purchase_id
           ) a
      where fmark>0
      group by substr(booking_month,1,7) ,land_province
      -- 新增利润 20250317 -- gl
      UNION ALL
      -- 20250326 -- gl 资源中心利润  修正后的订单状态（只能趋于真实情况）
      select substr(a.booking_time,1,7) as booking_month--,belong_area
            ,a.land_province province
            ,round(sum(     (coalesce(b.sale_money,0)-coalesce(b.cost_money,0))*coalesce(a.booking_num,0)   ),2) as order_pay_amount,'利润' as type
      from ads_resource_center_order_d_f a
      left join s_order_split_d_i b 
          on a.order_id=b.orderid 
          and b.orderdate>='20241001'
          and a.resource_center_supplier_id = b.sellerid
      -- 订单状态修复用
      left join dim_order_d_i c 
          on a.order_id = c.orderid 
          and c.orderdate>='20250101'
      left join dim_order_status_o_f d 
          on c.order_status = d.order_status
      where a.pt = ${ds}
      and a.resource_center_supplier_account in ('65129163','5902514','71065544')
      and ifnull(d.order_status_name,a.order_status)  in ('已使用，特产时为确认收货','订单完结')
      -- and a.order_id='73785018813282'
      and substr(a.booking_time,1,7)>='2025-01'
      group by substr(booking_time,1,7)  ,land_province
     ) a
left join (select * from dim_res_resource_center_district_2022_d_f) d
    on d.province=a.province
group by a.booking_month
      ,case when d.district is null then '未知'
             when a.booking_month>='2026-05' and d.district='陈娟芳' then
                  case when a.province in ('浙江省','江苏省','上海市','湖南省','海南省') then '林丰'
                       when a.province in ('湖北省','山西省','河北省','安徽省','河南省') then '王佳鑫'
                    end
             else  d.district  end
      ,a.province
      ,cast (d.import_province as int)
having booking_month>='2022-01' 
-- order by booking_month desc,a.belong_area,a.province
;
