--EMR Spark SQL
--********************************************************************--
--author: 施建伟
--create time: 2026-05-21 14:36:39
--EMR任务只能运行在独享资源组上
--********************************************************************--
--资源中心三方直签明细
create TABLE if not EXISTS dws_res_resource_center_land_attr_detail_d_f
(    
    supply_user_id       string comment '供应商ID', --供应商ID
    land_id              string comment '产品ID',--产品ID
    land_name            string comment '产品名称', --产品名称  
    land_province        string comment '景区省', --景区省
    belong_area          string comment '区域',   --区域
    resource_land_id     string comment '业态景区ID', --业态景区ID
    resource_land_name   string comment '业态景区名称',--业态景区名称
    add_time             string comment '供应商+产品最早上架资源中心票的时间', --供应商+产品最早上架资源中心票的时间
    resource_land_add_time   string comment '业态景区关联时间', --业态景区关联时间
    resource_type        string comment '直签/第三方',  --直签/第三方    1：三方 2:直签
    salesman_id          string comment '业务员'  ,    --业务员
    dname                string comment '业务员姓名' ,     --业务员姓名
    pm                   string comment '一个产品多个供应商同一个状态取最早的上架时间的供应商'
) COMMENT '三方直签明细'
PARTITIONED BY(`pt` string) 
STORED AS ORC;



INSERT OVERWRITE table dws_res_resource_center_land_attr_detail_d_f PARTITION (pt='${ds}')
select  
      a.supply_user_id, --供应商ID
      a.land_id,--产品ID
      a.land_name, --产品名称  
      a.land_province, --景区省
      case when d.district is null then '未知' else  d.district  end  as belong_area,   --区域
      l.resource_land_id, --业态景区ID
      l.resource_land_name,--业态景区名称
      max(a.add_time) as add_time, --供应商+产品最早上架资源中心票的时间
      l.resource_land_add_time, --业态景区关联时间
      rl.resource_type,  --直签/第三方    1：三方 2:直签
      rl.salesman_id    --业务员
      ,m.dname           --业务员姓名
      ,row_number()over(partition by l.resource_land_id,l.resource_land_name,rl.resource_type
            order by  --l.resource_land_add_time,
                    max(a.add_time)  ) as pm  
from dim_resource_center_purchase_d_f  a  
left join (select * from dim_land_d_f where pt = ${ds}) l
    on a.land_id=l.land_id
left join
    (select distinct q.resource_type,q.lid,q.sid,q1.salesman_id
     from ods_res_pft_resource_land_attr_d_f  q
     left join 
         (select a.lid
                ,a.sid
                ,a.salesman_id
                ,a.resource_type 
          from (select lid
                    ,sid
                    ,salesman_id
                    ,resource_type
                    ,from_unixtime(update_time,'yyyy-MM-dd HH:mm:ss')  as update_time
                    ,row_number() over(partition by lid,sid order by from_unixtime(update_time,'yyyy-MM-dd HH:mm:ss')  desc )   as pm 
                from ods_res_pft_resource_salesman_log_d_f
                where pt = ${ds}
               )a
          where a.pm=1
         )q1
          on q.lid=q1.lid and q.sid=q1.sid
     where q.pt = ${ds}
    )  as rl
    on  a.land_id=rl.lid and a.supply_user_id=rl.sid
left join (select * from dim_res_resource_center_district_2022_d_f)  d 
    on d.province=a.land_province
left join (select * from s_myuu_pft_member_d_f where pt= ${ds} ) as m 
    on rl.salesman_id=m.id
where a.pt = ${ds}   --and a.land_name='临沂凤凰欢乐大世界-QC（禁止上OTA）'
group by a.supply_user_id, --供应商ID
      a.land_id,--产品ID
      a.land_name, --产品名称  
      a.land_province, --景区省
      case when d.district is null then '未知' else  d.district  end ,   --区域
      l.resource_land_id, --业态景区ID
      l.resource_land_name,--业态景区名称
      l.resource_land_add_time, --业态景区关联时间
      rl.resource_type,  --直签/第三方    1：三方 2:直签
      rl.salesman_id    --业务员
      ,m.dname           --业务员姓名
having ifnull(max(a.add_time),'')<>'' and rl.resource_type in(2)

UNION ALL 

select a.supply_user_id, --供应商ID
      a.land_id,--产品ID
      a.land_name, --产品名称  
      a.land_province, --景区省
      case when d.district is null then '未知' else  d.district  end  as belong_area,   --区域
      l.resource_land_id, --业态景区ID
      l.resource_land_name,--业态景区名称
      max(a.add_time) as add_time, --供应商+产品最早上架资源中心票的时间
      l.resource_land_add_time, --业态景区关联时间
      rl.resource_type,  --直签/第三方    1：三方 2:直签
      rl.salesman_id    --业务员
      ,m.dname           --业务员姓名
      ,row_number()over(partition by l.resource_land_id,l.resource_land_name,rl.resource_type
            order by  l.resource_land_add_time
                -- ,max(a.add_time) 
             ) as pm  
from dim_resource_center_purchase_d_f a  
left join (select * from dim_land_d_f where pt= ${ds} ) l
    on a.land_id=l.land_id   
left join 
    (select distinct  q.resource_type,q.lid,q.sid,q1.salesman_id
     from ods_res_pft_resource_land_attr_d_f  q
     left join 
         (select a.lid
                ,a.sid
                ,a.salesman_id
                ,a.resource_type 
          from (select lid
                    ,sid
                    ,salesman_id
                    ,resource_type
                    ,from_unixtime(update_time,'yyyy-MM-dd HH:mm:ss')  as update_time
                    ,row_number() over(partition by lid,sid order by from_unixtime(update_time,'yyyy-MM-dd HH:mm:ss')  desc )   as pm 
                    from ods_res_pft_resource_salesman_log_d_f
                    where pt = ${ds}
               )a 
           where a.pm=1
         ) q1
         on q.lid=q1.lid and q.sid=q1.sid
     where q.pt = ${ds}
    ) rl
    on a.land_id=rl.lid and a.supply_user_id=rl.sid
left join (select * from dim_res_resource_center_district_2022_d_f)  d 
    on d.province=a.land_province
left join (select * from s_myuu_pft_member_d_f where pt= ${ds} ) as m 
    on rl.salesman_id=m.id
where a.pt= ${ds}   --and a.land_name='临沂凤凰欢乐大世界-QC（禁止上OTA）'
group by a.supply_user_id, --供应商ID
      a.land_id,--产品ID
      a.land_name, --产品名称  
      a.land_province, --景区省
      case when d.district is null then '未知' else  d.district  end ,   --区域
      l.resource_land_id, --业态景区ID
      l.resource_land_name,--业态景区名称
      l.resource_land_add_time, --业态景区关联时间
      rl.resource_type,  --直签/第三方    1：三方 2:直签
      rl.salesman_id    --业务员
      ,m.dname           --业务员姓名
having  ifnull(max(a.add_time),'')<>'' and rl.resource_type in(1)
;