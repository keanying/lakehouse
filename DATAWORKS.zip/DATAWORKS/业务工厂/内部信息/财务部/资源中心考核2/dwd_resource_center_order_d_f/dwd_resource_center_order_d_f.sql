--EMR Spark SQL
--********************************************************************--
--author: 施建伟
--create time: 2026-05-29 09:15:06
--EMR任务只能运行在独享资源组上
--********************************************************************--
-- desc 资源中心订单明细
-- drop table dwd_resource_center_order_d_f;
-- alter table dwd_resource_center_order_d_f add columns(order_no_supplier string comment '供货商订单序号');
-- alter table dwd_resource_center_order_d_f add columns(order_no_purchase string comment '采购商订单序号');
-- alter table dwd_resource_center_order_d_f add columns(order_no_land string comment '产品订单序号');
-- alter table dwd_resource_center_order_d_f add columns(resource_land_id  int  comment '业态景区id');
-- alter table dwd_resource_center_order_d_f add columns(resource_land_name  string comment '业态景区名称');
-- alter table dwd_resource_center_order_d_f add columns(land_topic  string comment '景区主题');
-- alter table dwd_resource_center_order_d_f add columns(cost_price  int  comment '供货商成本价');
-- alter table dwd_resource_center_order_d_f add columns(sale_price  int  comment '零售价');
-- alter table dwd_resource_center_order_d_f add columns(rn  int  comment '价格排序');
CREATE TABLE IF NOT EXISTS dwd_resource_center_order_d_f
(
    stat_date                             STRING COMMENT '统计日期'
    ,dw_ins_time                          STRING COMMENT '插入时间'
    ,order_id                             STRING COMMENT "订单号"
    ,remote_order_id                      STRING COMMENT '远程订单号'
    ,order_status                         STRING COMMENT "订单状态"
    ,ticket_num                           INT COMMENT "实际票数"
    ,booking_time                         STRING COMMENT "下单时间"
    ,vertify_time                         STRING COMMENT "验证时间"
    ,resource_center_supplier_id          INT COMMENT "资源中心上架产品商户id"
    ,resource_center_purchase_id          INT COMMENT "资源中心采购商id"
    ,land_id                              INT COMMENT "产品ID"
    ,land_name                            STRING COMMENT "产品名称"
    ,land_type                            STRING COMMENT '产品类型编码'
    ,land_type_name                       STRING COMMENT "产品类型"
    ,land_province                        STRING COMMENT "景区所在省"
    ,land_city                            STRING COMMENT '景区城市名称'
    ,belong_area                          STRING COMMENT '产品归属区域'
    ,ticket_id                            INT COMMENT "票ID"
    ,ticket_fullname                      STRING COMMENT "票全称"
    ,resource_id                          INT COMMENT "资源ID"
    ,resource_name                        STRING COMMENT "资源名称"
    ,distribute_system_type               STRING COMMENT "对接分销平台"
    ,distribute_system_name               STRING COMMENT "对接分销平台名称"
    ,booking_channel                      STRING COMMENT '销售渠道ID'
    ,booking_channel_name                 STRING COMMENT '销售渠道名称'
    ,booking_price                        INT COMMENT '票价'
    ,booking_num                          INT COMMENT '预定票数'
    ,booking_pay_amount                   BIGINT COMMENT '预定金额'
    ,order_pay_amount                     FLOAT COMMENT "订单支付金额（元）"
    ,distributor_id                       INT COMMENT '一级分销商id'
    ,seller_id                            INT COMMENT '销售者id'
    ,booker_id                            INT COMMENT '购买者id'
    ,ticket_taker_province                STRING COMMENT '客源省'
    ,ticket_taker_city                    STRING COMMENT '客源市'
    ,fail_reason                          STRING COMMENT '失败原因'
    ,fail_code                            STRING COMMENT '失败代码'
    ,is_ota                               STRING COMMENT 'ota订单？ 是/否'
    ,resource_center_supplier_account     STRING COMMENT "资源中心上架产品商户账号"
    ,resource_center_supplier_name        STRING COMMENT "资源中心上架产品商户名称"
    ,resource_center_supplier_province    STRING COMMENT "资源中心上架产品商户省"
    ,resource_center_supplier_city        STRING COMMENT "资源中心上架产品商户市"
    ,resource_center_supplier_belong_area STRING COMMENT "资源中心上架产品商户市归属区域"
    ,resource_center_supplier_is_test     STRING COMMENT "资源中心上架产品商户是否测试账号"
    ,resource_center_supplier_type        STRING COMMENT "资源中心上架产品商户类型"
    ,resource_center_supplier_auto_get    STRING COMMENT "资源中心上架产品商为自动获取？"
    ,resource_center_purchase_account     STRING COMMENT "资源中心采购商账号"
    ,resource_center_purchase_name        STRING COMMENT "资源中心采购商名称"
    ,resource_center_purchase_province    STRING COMMENT "资源中心采购商省"
    ,resource_center_purchase_city        STRING COMMENT "资源中心采购商市"
    ,resource_center_purchase_belong_area STRING COMMENT "资源中心采购商归属区域"
    ,resource_center_purchase_is_test     STRING COMMENT "资源中心采购商是否测试账号"
    ,resource_center_purchase_type        STRING COMMENT "资源中心采购商类型"
    ,order_no_supplier                    INT COMMENT '供货商订单序号'
    ,order_no_purchase                    INT COMMENT '采购商订单序号'
    ,order_no_land                        INT COMMENT '产品订单序号'
    ,resource_land_id                     INT COMMENT '业态景区id'
    ,resource_land_name                   STRING COMMENT '业态景区名称'
    ,resource_center_purchase_price       INT COMMENT '采购商采购成本价'
    ,land_topic                           STRING COMMENT '景区主题'
    ,cost_price                           INT COMMENT '供货商成本价'
    ,sale_price                           INT COMMENT '零售价'
    ,rn                                   INT COMMENT '价格排序'
)
COMMENT "资源中心订单"
PARTITIONED BY 
(
    pt                                    INT
)
STORED AS ORC
;





drop view if exists cache_dim_user_d_f;
cache table  cache_dim_user_d_f
select user_id,user_account,user_name,customer_province,customer_city,user_is_test,user_type,is_resource_center_auto_get_user 
from dim_user_d_f 
where pt="${ds}" and user_type in ('分销商','供应商');



--新增优化
drop view if exists cache_constants;
cache table  cache_constants
select DATE_FORMAT(DATE_SUB(TO_DATE('${ds}', 'yyyyMMdd'), 732), 'yyyyMMdd') as threshold_date;
drop view if exists cache_dwd_order_d_i;
cache table  cache_dwd_order_d_i
select record_id,
        order_id,
        remote_order_id,
        order_status,
        ticket_num,
        booking_time,
        verify_time,
        resource_center_supplier_id,
        resource_center_purchase_id,
        land_id,
        land_name,
        land_type,
        land_type_name,
        land_province,
        land_city,
        ticket_id,
        ticket_fullname,
        resource_id,
        resource_name,
        distribute_system_type,
        distribute_system_name,
        booking_channel,
        booking_channel_name,
        booking_price,
        booking_num,
        booking_pay_amount,
        order_pay_amount,
        distributor_id,
        seller_id,
        booker_id,
        ticket_taker_province,
        ticket_taker_city,
        resource_land_id,
        resource_land_name,
        land_topic,
        -- 计算周几（用于匹配价格表）
        pmod(floor((unix_timestamp(booking_time) - unix_timestamp('1970-01-05 00:00:00')) / (3600 * 24)) + 1, 7) as booking_weekofday,
        -- 取每个订单标识（合并remote_order_id）的最新记录
        row_number() over (
            partition by if(remote_order_id is null or remote_order_id = '', order_id, remote_order_id) order by record_id desc
        ) as rn_max
    from dwd_order_d_i, cache_constants
    where booking_date > cache_constants.threshold_date
      and isnotnull(resource_center_supplier_id)
      and order_pay_status < 2
;





-- 资源中心产生的订单
-- 过滤上架商、采购商为测试账号的订单
-- 过滤未支付，取消、撤销的订单
-- 按唯一订单号选择记录id最大的订单，唯一订单号= 远程订单号>平台订单号(因为ota订单下单失败会重试，所以可能出现远程订单号重复订单
INSERT OVERWRITE TABLE dwd_resource_center_order_d_f PARTITION (pt = "${ds}")
SELECT  *
FROM (
         SELECT  '${ds}' as stat_date
                    ,current_date() as dw_ins_time
                    ,o.order_id
                    ,o.remote_order_id
                    ,o.order_status
                    ,o.ticket_num
                    ,o.booking_time
                    ,o.verify_time as vertify_time
                    ,o.resource_center_supplier_id
                    ,o.resource_center_purchase_id
                    ,o.land_id
                    ,o.land_name
                    ,o.land_type
                    ,o.land_type_name
                    ,o.land_province
                    ,o.land_city
                    ,di.district AS belong_area
                    ,o.ticket_id
                    ,o.ticket_fullname
                    ,o.resource_id
                    ,o.resource_name
                    ,o.distribute_system_type
                    ,o.distribute_system_name
                    ,o.booking_channel
                    ,o.booking_channel_name
                    ,o.booking_price
                    ,o.booking_num
                    ,o.booking_pay_amount
                    ,o.order_pay_amount
                    ,o.distributor_id
                    ,INT(o.seller_id) AS seller_id
                    ,INT(o.booker_id) AS booker_id
                    ,o.ticket_taker_province
                    ,o.ticket_taker_city
                    ,t.fail_reason
                    ,t.fail_code   -- ''                     as   fail_reason,
                    -- ''                       as   fail_code,
                    ,IF(o.distribute_system_type = 'OTA' OR (o.booking_channel = 17),'是','否') AS is_ota
                    ,ms.user_account AS resource_center_supplier_account
                    ,ms.user_name AS resource_center_supplier_name
                    ,ms.customer_province AS resource_center_supplier_province
                    ,ms.customer_city AS resource_center_supplier_city
                    ,ds.district AS resource_center_supplier_belong_area
                    ,ms.user_is_test AS resource_center_supplier_is_test
                    ,ms.user_type AS resource_center_supplier_type
                    ,ms.is_resource_center_auto_get_user AS resource_center_supplier_auto_get
                    ,mp.user_account AS resource_center_purchase_account
                    ,mp.user_name AS resource_center_purchase_name
                    ,mp.customer_province AS resource_center_purchase_province
                    ,mp.customer_city AS resource_center_purchase_city
                    ,dp.district AS resource_center_purchase_belong_area
                    ,mp.user_is_test AS resource_center_purchase_is_test
                    ,mp.user_type AS resource_center_purchase_type
                    ,o.order_no_supplier
                    ,o.order_no_purchase
                    ,o.order_no_land
                    ,int(o.resource_land_id) as resource_land_id
                    ,o.resource_land_name
                    ,a.sale_money as resource_center_purchase_price
                    ,o.land_topic
                    ,int(p.cost_price) as cost_price
                    ,int(if(p.sale_price > o.booking_price,p.sale_price,o.booking_price)) as sale_price
                    ,ROW_NUMBER() over (partition by o.order_id order by abs(datediff(p.end_date,o.booking_time)),p.ptype desc ) as rn
         from (select t1.*
                    ,ROW_NUMBER() over (partition by resource_center_supplier_id order by booking_time ) as order_no_supplier
                    ,ROW_NUMBER() over (partition by resource_center_purchase_id order by booking_time ) as order_no_purchase
                    ,ROW_NUMBER() over (partition by land_id order by booking_time ) as order_no_land 
               from cache_dwd_order_d_i t1
               where rn_max = 1
              ) o
        --     JOIN    (
        --                 SELECT  o1.order_id_sigle
        --                         ,MAX(o1.record_id) AS record_id
        --                 FROM    (
        --                             SELECT  IF(remote_order_id IS NULL OR remote_order_id = '',order_id,remote_order_id) AS order_id_sigle
        --                                     ,record_id
        --                                     ,order_id
        --                                     ,remote_order_id
        --                             FROM    dwd_order_d_i
        --                             WHERE   booking_date > DATE_FORMAT(DATE_SUB(TO_DATE('${ds}','yyyyMMdd'),732),'yyyyMMdd')
        --                             AND     isnotnull(resource_center_supplier_id)
        --                             AND     order_pay_status < 2
        --                         ) o1
        --                 GROUP BY o1.order_id_sigle
        --             ) o2
        --     ON      o.record_id = o2.record_id -- 关联产品归属区域
         left join dim_resource_center_district_o_f di
             on o.land_province = di.province           -- 对接第三方下单失败原因(去除where条件 250715修订)
         left join (select pftOrder ,fail_reason ,fail_code from ods_api_order_track_d_f) t
             on t.pftOrder = o.order_id
         -- 上架商信息及归属区域
         left join cache_dim_user_d_f ms
             on ms.user_id = o.resource_center_supplier_id
         -- 采购商信息及归属区域
         left join dim_resource_center_district_o_f ds
             on ms.customer_province = ds.province
         left join cache_dim_user_d_f mp
             on mp.user_id = o.resource_center_purchase_id
         left join dim_resource_center_district_o_f dp
             on mp.customer_province = dp.province
         left join
             (select orderid ,sale_money
              from ods_order_split_d_i, cache_constants
              where orderdate > cache_constants.threshold_date
              and member_relationship = 1
             ) a
             on o.order_id = a.orderid --a.buyer_id=o.resource_center_purchase_id and
         -- 发布商成本价、零售价
         left join
             (select  ticket_id
                      ,ptype
                      ,cost_price
                      ,sale_price
                      ,end_date
                      ,weekdays
              from dim_prod_price_d_f
              where    pt = ${ds}
             ) p
             on o.ticket_id = p.ticket_id
            and p.weekdays like CONCAT('%',o.booking_weekofday,'%')
        ) 
WHERE rn = 1;