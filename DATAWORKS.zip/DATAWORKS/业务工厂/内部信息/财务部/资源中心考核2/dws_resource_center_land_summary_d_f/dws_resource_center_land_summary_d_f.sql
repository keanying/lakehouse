--EMR Spark SQL
--********************************************************************--
--author: 施建伟
--create time: 2026-05-21 11:53:15
--EMR任务只能运行在独享资源组上
--********************************************************************--
--资源中心产品维度汇总
--包含订单、采购相关信息
--产品和票状态只有有一个上架即为上架
--采购状态只要有被采购即为采购
-- drop table ads_resource_center_land_summary_d_f
-- alter table ads_resource_center_land_summary_d_f add columns(supply_type string comment '资源中心供应类型：自动拉取/手动供应');
-- alter table ads_resource_center_land_summary_d_f add columns(booking_pay_amount  bigint comment '预定金额(分)');
-- alter table ads_resource_center_land_summary_d_f add columns(place_list  string comment '推荐板块列表');
-- alter table ads_resource_center_land_summary_d_f add columns(resource_land_id  int comment '业态景区id');
-- alter table ads_resource_center_land_summary_d_f add columns(resource_land_name  string comment '业态景区名称');
-- alter table ads_resource_center_land_summary_d_f add columns(order_10th_booking_time  string comment '第10个订单时间');
-- alter table ads_resource_center_land_summary_d_f add columns(resource_land_add_time string comment '业态景区关联时间');
create table if not exists dws_resource_center_land_summary_d_f(
    land_id                     INT     COMMENT'产品id',
    land_name                   string  COMMENT'产品名称',
    land_province               string  COMMENT '景区省',
    land_city                   string  COMMENT '景区市',
    land_type_name              string  comment '景区/产品类型',
    apply_did                   int     COMMENT'景区供应商',
    apply_type                  string  COMMENT '资源中心供应商类型',
    purchace_status             string  COMMENT'采购状态',
    land_ticket_status          string  COMMENT'产品和票状态',
    supply_user_num             int     COMMENT'供应商数量',
    purchase_user_num           int     COMMENT'采购商数量',
    purchase_distribute_num     int     COMMENT'有分销的采购商数量',
    max_add_time                string  COMMENT'最新上架时间',
    min_add_time                string  COMMENT '首次上架时间',
    max_off_time                string  COMMENT '最后一次下架时间',
    max_resource_update_time    string  COMMENT'资源中心产品最新更新时间',
    min_booking_time            string  COMMENT'首次订单时间',
    max_booking_time            string  COMMENT'最近订单时间',
    order_num                   int     COMMENT'总订单数',
    ticket_num                  int     COMMENT'总票数',
    order_pay_amount            float   COMMENT'总金额（元）',
    order_num_last_7            int     COMMENT'近7日订单数',
    order_num_last_30           int     COMMENT'近30日订单数',
    order_num_month             int     COMMENT'本月预定订单数',
    order_num_month_month       int     COMMENT '上月预定订单数',
    ota_order_num               int     COMMENT'ota订单数',
    ota_ticket_num              int     COMMENT'ota票数',
    ota_order_pay_amount        int     COMMENT'ota订单金额（元）',
    ---票类标签
    month_trade_active          string COMMENT '本月交易活跃度 活跃-月订单>=100、微活跃-月订单50~100、产生交易-月订单1~50、无交易-无订单',
    belong_area                 string comment '产品归属区域',
    forcast_life_cycle          float  comment '预计生命周期（月）（最大有效时间-首次上架时间）/30',
    order_life_cycle            float  comment '订单生命周期（月）最大下单时间-首次下单时间）/30',
    supply_type                 string comment '资源中心供应类型：自动拉取/手动供应',
    booking_pay_amount          bigint   COMMENT'预定金额（分）',
    ota_booking_pay_amount      bigint   COMMENT'ota预定总金额（分）',
    place_list                  string comment '推荐板块列表',
    resource_id                 int    comment '资源ID',
    resource_name               string comment '资源名称',
    land_topic                  string comment '主题',
    land_publisher_name         string comment '供应商名称',
    resource_land_id            int    comment '业态景区id',
    resource_land_name          string comment '业态景区名称',
    order_10th_booking_time     string comment '第10个订单下单时间',
    resource_land_add_time  string comment '业态景区关联时间'
 )comment'资源中心产品维度汇总'
PARTITIONED BY(`pt` string) 
STORED AS ORC;
insert OVERWRITE table dws_resource_center_land_summary_d_f PARTITION (pt="${ds}")
SELECT
    a.land_id,
    a.land_name,
    a.land_province,
    a.land_city,
    a.land_type_name,
    a.apply_did,
    case when a.apply_code=1 then '顶级供应商' else '一级供应商' end apply_type,
    a.purchace_status,
    a.land_ticket_status,
    a.supply_user_num,
    a.purchase_user_num,
    a.purchase_distribute_num,
    a.max_add_time,
    a.min_add_time,
    a.max_off_time,
    a.max_resource_update_time,
    b.min_booking_time,
    b.max_booking_time,
    b.order_num,
    b.ticket_num,
    b.order_pay_amount,
    b.order_num_last_7,
    b.order_num_last_30,
    b.order_num_month,
    b.order_num_month_month,
    b.ota_order_num,
    b.ota_ticket_num,
    b.ota_order_pay_amount,
    ---票类标签
    case when b.order_num_month>=100 then '活跃'
         when b.order_num_month>=50 then '微活跃'
         when b.order_num_month>=1 then '产生交易'
         else '无订单' end month_trade_active,
    di.district as belong_area,
    datediff(a.ticket_max_expiration_date,a.min_add_time)/30 as  forcast_life_cycle,
    datediff(b.max_booking_time,b.min_booking_time)/30 as  order_life_cycle,
    a.supply_type                  as supply_type,
    b.booking_pay_amount,
    b.ota_booking_pay_amount,
    re1.place_list,
    l.resource_id,
    l.resource_name,
    l.land_topic,
    l.land_publisher_name,
    l.resource_land_id,
    l.resource_land_name,
    b.order_10th_booking_time,
    l.resource_land_add_time
FROM (SELECT land_id,
            land_name,
            land_province,
            land_city,
            land_type_name,
            apply_did,
            max(ticket_max_expiration_date) as ticket_max_expiration_date,
            supply_type,
            max(apply_code) as apply_code,
            case when count(distinct purchase_user_id)=0 then '未采购' 
                 when sum(is_auto_purchace_status)=0 then '仅人工'
                 when count(*)=sum(is_auto_purchace_status) then '仅自动'
                 else '双采购' end purchace_status,
            case when sum(land_ticket_status)>=1 and max(ticket_max_expiration_status)=1 then '在售' 
                 when sum(land_ticket_status)=0 and max(ticket_max_expiration_status)=1 then '下架'
                 when sum(ticket_max_expiration_status)=0 then '过期' 
            end land_ticket_status,
            count(distinct supply_user_id) supply_user_num,
            count(distinct purchase_user_id) purchase_user_num,
            count(distinct if(purchase_distribute_num>0,purchase_user_id,null)) as purchase_distribute_num,
            to_date(max(add_time)) as max_add_time,
            to_date(min(add_time)) as min_add_time,
            to_date(max(resource_update_time)) as max_resource_update_time ,
            to_date(max(off_time)) as   max_off_time
      FROM (select a0.*
                ,case when supply_user_id=apply_did then 1 else 0 end apply_code
                ,case when resource_product_status='上架'  and product_status ='上架'  then 1               
                      when not (resource_product_status='上架' and product_status ='上架') then 0                   
                   end land_ticket_status
                ,case when ticket_max_expiration_date>now() then 1 else 0 end ticket_max_expiration_status
                ,case when is_auto_purchace='是' then 1 else 0 end is_auto_purchace_status
            from dim_resource_center_purchase_d_f a0            
            where pt="${ds}" 
          )  a1
      group by land_id, land_name, land_province, land_city, land_type_name, apply_did, supply_type 
    ) a 
left join
    (select land_id,
            to_date(max(booking_time))          as max_booking_time,
            to_date(min(booking_time))          as min_booking_time,
            count(distinct order_id)            as order_num ,
            sum(ticket_num)                     as ticket_num,
            sum(order_pay_amount)               as order_pay_amount,
            sum(booking_pay_amount)             as booking_pay_amount,
            count(distinct if(booking_time>=date_sub(now(),7),order_id,null)) as order_num_last_7,
            count(distinct if(booking_time>=date_sub(now(),30),order_id,null)) as order_num_last_30,
            count(distinct if(booking_time>=trunc(date_sub(current_date(),1),'MM'),order_id,null)) as order_num_month,
            count(distinct if(booking_time>=add_months(trunc(date_sub(current_date(),1),'MM'),-1) and booking_time<add_months(current_date(),-1) ,order_id,null)) as order_num_month_month,
            count(distinct if(is_ota='是',order_id,null)) as ota_order_num,
            sum( if(is_ota='是',ticket_num,null)) as ota_ticket_num,
            sum( if(is_ota='是',order_pay_amount,null)) as ota_order_pay_amount,  
            sum( if(is_ota='是',booking_pay_amount,null)) as ota_booking_pay_amount,
            max( if(order_no_land=10,booking_time,null))  as order_10th_booking_time 
     from dwd_resource_center_order_d_f
     where pt="${ds}"
     group by land_id
    ) b 
    on a.land_id=b.land_id
-- 关联归属区域
left join dim_resource_center_district_o_f di
    on a.land_province=di.province
-- 推荐板块
left join
    (select rec.lid,
            cast(collect_set(con.title) as string) place_list
         from (select * from ods_pft_resource_recommend_land_d_f where pt="${ds}")  rec
         join (select * from ods_pft_resource_recommend_config_d_f where pt="${ds}") con
         on con.id=rec.recommend_id 
         where rec.enabled_state=1
     group by rec.lid
    ) re1
    on re1.lid=a.land_id
left join (select * from dim_land_d_f where pt="${ds}") l
    on l.land_id=a.land_id
;