--EMR Spark SQL
--********************************************************************--
--author: 施建伟
--create time: 2026-04-29 09:19:36
--EMR任务只能运行在独享资源组上
--********************************************************************--

-- CREATE TABLE if NOT EXISTS ads_cus_landtravel_d_f(
--  insertdate                 string COMMENT '核验日期'
-- ,user_name                  string COMMENT '客户名称'
-- ,user_account               string COMMENT '账号'
-- ,apply_did                  string COMMENT '客户id'
-- ,servicer                   string COMMENT '客功'  
-- ,verify_num                 string COMMENT '核验数'
-- ,msgcnt                     string COMMENT '短信发送量'
-- ,jl_records_num             string COMMENT '景旅app开票数'
-- ,records_num                string COMMENT '总开票数'

-- ,verify_num_1               string COMMENT '景旅纵横认证-1大陆居民身份证'
-- ,verify_num_2               string COMMENT '景旅纵横认证-2老年人'
-- ,verify_num_3               string COMMENT '景旅纵横认证-3儿童'
-- ,verify_num_4               string COMMENT '景旅纵横认证-4残疾人'
-- ,verify_num_5               string COMMENT '景旅纵横认证-5参保本地人'
-- ,verify_num_6               string COMMENT '景旅纵横认证-6大学生'
-- ,verify_num_7               string COMMENT '景旅纵横认证-7港澳居民居住证'
-- ,verify_num_8               string COMMENT '景旅纵横认证-8台湾居民居住证'
-- ,verify_num_9               string COMMENT '景旅纵横认证-9港澳居民来往内地通行证'
-- ,verify_num_10              string COMMENT '景旅纵横认证-10台湾居民来往内地通行证'
-- ,verify_num_11              string COMMENT '景旅纵横认证-11外国人永久居留身份证'
-- ,verify_num_12              string COMMENT '景旅纵横认证-12中国公民普通护照'
-- ,verify_num_13              string COMMENT '景旅纵横认证-13医生'
-- ,verify_num_14              string COMMENT '景旅纵横认证-14护士'
-- ,verify_num_15              string COMMENT '景旅纵横认证-15中小学生'
-- ,verify_num_16              string COMMENT '景旅纵横认证-16退役军人'
-- ,verify_num_17              string COMMENT '景旅纵横认证-17教师'

-- ,jl_verify_num_1            string COMMENT '景旅认证-1大陆居民'
-- ,jl_verify_num_2            string COMMENT '景旅认证-2港澳人'
-- ,jl_verify_num_3            string COMMENT '景旅认证-3台湾人'
-- ,jl_verify_num_4            string COMMENT '景旅认证-4外国人'
-- ,jl_verify_num_5            string COMMENT '景旅认证-5残疾人（福建省）'
-- ,jl_verify_num_6            string COMMENT '景旅认证-6参保人（福建省）'
-- ,jl_verify_num_7            string COMMENT '景旅认证-7退伍军人（福建省）'
-- ,jl_verify_num_8            string COMMENT '景旅认证-8大学生（全国）'
-- ,jl_verify_num_9            string COMMENT '景旅认证-9医生（福建省）'
-- ,jl_verify_num_10           string COMMENT '景旅认证-10护士（福建省）'
-- ,jl_verify_num_11           string COMMENT '景旅认证-11教师（福建省）'
-- ,jl_verify_num_12           string COMMENT '景旅认证-12中小学生（福建省）'

-- ,spare_field1               string COMMENT '自定义字段1'
-- ,spare_field2               string COMMENT '自定义字段2'
-- ,spare_field3               string COMMENT '自定义字段3'
-- ,spare_field4               string COMMENT '自定义字段4'
-- ,spare_field5               string COMMENT '自定义字段5'
-- ,spare_field6               string COMMENT '自定义字段6'
-- ,spare_field7               string COMMENT '自定义字段7'
-- ,spare_field8               string COMMENT '自定义字段8'
-- ,spare_field9               string COMMENT '自定义字段9'
-- ,spare_field10              string COMMENT '自定义字段10'
-- ,spare_field11              string COMMENT '自定义字段11'
-- ,spare_field12              string COMMENT '自定义字段12'
-- ,spare_field13              string COMMENT '自定义字段13'
-- ,spare_field14              string COMMENT '自定义字段14'
-- ,spare_field15              string COMMENT '自定义字段15'
-- ,spare_field16              string COMMENT '自定义字段16'
-- ,spare_field17              string COMMENT '自定义字段17'
-- ,spare_field18              string COMMENT '自定义字段18'
-- ,spare_field19              string COMMENT '自定义字段19'
-- ,spare_field20              string COMMENT '自定义字段20'

-- ) comment '景旅纵横底表' 
-- PARTITIONED BY(`pt` string) 
-- STORED AS ORC;


-- SET spark.sql.mergeSmallFiles.enabled=true;
-- SET spark.sql.sources.partitionOverwriteMode=dynamic;
-- SET spark.sql.adaptive.enabled=true;
-- SET spark.sql.adaptive.coalescePartitions.enabled=true;
-- SET spark.sql.adaptive.coalescePartitions.minPartitionSize=64MB;
-- SET spark.sql.adaptive.coalescePartitions.initialPartitionNum=1;
-- SET spark.sql.adaptive.coalescePartitions.parallelism=1;









-- 1. 景区纵横认证（提前打标 + 聚合取 MAX）
--with cache_landtravel_user_verify AS (
DROP TABLE IF EXISTS cache_landtravel_user_verify;
CREATE TABLE cache_landtravel_user_verify  STORED as ORC as
SELECT id_no
    
	-- 每个身份类别的标志位：只要存在至少一条记录满足 like，则标记为 1
    ,max(case when identity_item like '%1大陆居民身份证%' then 1 else 0 end) as verify_flag_1
    ,max(case when identity_item like '%2老年人%' then 1 else 0 end) as verify_flag_2
    ,max(case when identity_item like '%3儿童%' then 1 else 0 end) as verify_flag_3
    ,max(case when identity_item like '%4残疾人%' then 1 else 0 end) as verify_flag_4
    ,max(case when identity_item like '%5参保本地人%' then 1 else 0 end) as verify_flag_5
    ,max(case when identity_item like '%6大学生%' then 1 else 0 end) as verify_flag_6
    ,max(case when identity_item like '%7港澳居民居住证%' then 1 else 0 end) as verify_flag_7
    ,max(case when identity_item like '%8台湾居民居住证%' then 1 else 0 end) as verify_flag_8
    ,max(case when identity_item like '%9港澳居民来往内地通行证%' then 1 else 0 end) as verify_flag_9
    ,max(case when identity_item like '%10台湾居民来往内地通行证%' then 1 else 0 end) as verify_flag_10
    ,max(case when identity_item like '%11外国人永久居留身份证%' then 1 else 0 end) as verify_flag_11
    ,max(case when identity_item like '%12中国公民普通护照(华侨)%' then 1 else 0 end) as verify_flag_12
    ,max(case when identity_item like '%13医生%' then 1 else 0 end) as verify_flag_13
    ,max(case when identity_item like '%14护士%' then 1 else 0 end) as verify_flag_14
    ,max(case when identity_item like '%15中小学生%' then 1 else 0 end) as verify_flag_15
    ,max(case when identity_item like '%16退役军人%' then 1 else 0 end) as verify_flag_16
    ,max(case when identity_item like '%17教师%' then 1 else 0 end) as verify_flag_17

from (select b.id_no ,CONCAT(a.identity_type, c.tag_desc) AS identity_item   
      from ods_cus_user_auth_info_d_f a
      left join ods_cus_user_info_d_f b
          on a.user_id = b.id
          and b.pt=${ds}
      left join ods_cus_pft_special_user_config_d_f c
          on c.id= a.identity_type
          -- and c.status=1
          and c.pt=${ds}
      where a.pt=${ds}
      and ifnull(b.id_no,'')<>''
      and a.status=1
     ) t
     group by id_no
;




-- 2. 景旅认证（提前打标 + 聚合取 MAX）
--cache_landtravel_tourist_verify AS (
DROP TABLE IF EXISTS cache_landtravel_tourist_verify;
CREATE TABLE cache_landtravel_tourist_verify  STORED as ORC as
select certificate_no

	,max(case when identity_item like '%1大陆居民%' then 1 else 0 end) as jl_flag_1
    ,max(case when identity_item like '%2港澳人%' then 1 else 0 end) as jl_flag_2
    ,max(case when identity_item like '%3台湾人%' then 1 else 0 end) as jl_flag_3
    ,max(case when identity_item like '%4外国人%' then 1 else 0 end) as jl_flag_4
    ,max(case when identity_item like '%5残疾人%' then 1 else 0 end) as jl_flag_5
    ,max(case when identity_item like '%6参保人%' then 1 else 0 end) as jl_flag_6
    ,max(case when identity_item like '%7退伍军人%' then 1 else 0 end) as jl_flag_7
    ,max(case when identity_item like '%8大学生%' then 1 else 0 end) as jl_flag_8
    ,max(case when identity_item like '%9医生%' then 1 else 0 end) as jl_flag_9
    ,max(case when identity_item like '%10护士%' then 1 else 0 end) as jl_flag_10
    ,max(case when identity_item like '%11教师%' then 1 else 0 end) as jl_flag_11
    ,max(case when identity_item like '%12中小学生%' then 1 else 0 end) as jl_flag_12
    ,max(case when identity_item like '%13居住证%' then 1 else 0 end) as jl_flag_13
	
from (select b.certificate_no ,CONCAT(a.identity_id, c.name) AS identity_item
     from ods_cus_tourist_auth_info_d_f a
     left join ods_cus_tourist_info_d_f b
         on a.tourist_id = b.id
         and b.pt=${ds}
     left join ods_cus_identity_info_d_f c
         on c.id= a.identity_id
         and c.pt=${ds}
     where ifnull(b.certificate_no,'')<>''
     and a.status=1
     and a.pt=${ds}
    ) t
     group by certificate_no
;







-- 3. 供应商用户维度
--cache_landtravel_user_info AS (
DROP TABLE IF EXISTS cache_landtravel_user_info;
CREATE TABLE cache_landtravel_user_info  STORED as ORC as
SELECT user_id, user_name, user_account, servicer
    FROM dim_user_d_f
    WHERE pt = ${ds}
      AND user_type = '供应商'
;


--游客核验信息表
DROP TABLE IF EXISTS cache_landtravel_user_verify_info;
CREATE TABLE cache_landtravel_user_verify_info  STORED as ORC as
select a.insertdate   -- 核验日期
        ,b.user_name  -- 客户名称
        ,b.user_account  -- 账号
        ,a.apply_did  -- 客户ID
        ,b.servicer
        ,a.verify_num
        ,a.idcard
    from dwd_tourist_verify_d_i  a
    inner join cache_landtravel_user_info b        -- 供应商用户
        on a.apply_did = b.user_id

    where a.insertdate>= ${ds366};















--短信发送总量
--cache_landtravel_msg_send as (
DROP TABLE IF EXISTS cache_landtravel_msg_send;
CREATE TABLE cache_landtravel_msg_send  STORED as ORC as
select aid
    ,replace( from_unixtime(send_time, 'yyyy-MM-dd'), '-' ,'') AS send_time
    ,sum(msgcnt) as msgcnt 
    from ods_cus_pft_sms_journal_d_i
    where pt>='20250101'  --and pt >= date_format(date_sub(current_date(), 366), 'yyyyMMdd')
    and pt >= CAST(DATE_FORMAT(DATE_SUB(TO_DATE(CAST(${ds} AS STRING), 'yyyyMMdd'), 366), 'yyyyMMdd') AS INT) 
    group by aid,from_unixtime(send_time, 'yyyy-MM-dd')
;


--开票
--cache_landtravel_records as (
DROP TABLE IF EXISTS cache_landtravel_records;
CREATE TABLE cache_landtravel_records  STORED as ORC as
select sid     -- 供应商id
    ,replace( from_unixtime(add_time, 'yyyy-MM-dd'), '-' ,'') AS send_time  -- 开票时间
    ,count(distinct id) as records_num  -- 总开票数
    ,count(distinct case when source = 'jlzh_app' then id end) as  jl_records_num  -- 景旅app开票数
    from ods_fin_pft_invoice_records_d_f
    where pt = ${ds}
    and from_unixtime(add_time, 'yyyy-MM-dd') >='2025-01-01'   
   -- and from_unixtime(add_time, 'yyyy-MM-dd') >=DATE_SUB(TO_DATE(CAST(${ds} AS STRING), 'yyyyMMdd'), 366)
    group by sid,from_unixtime(add_time, 'yyyy-MM-dd')
;












INSERT OVERWRITE table ads_cus_landtravel_d_f PARTITION (pt="${ds}")
select t.insertdate   
    ,t.user_name 
    ,t.user_account 
    ,t.apply_did
    ,t.servicer
    ,t.verify_num  
    ,t1.msgcnt   
    ,t2.jl_records_num  
    ,t2.records_num
    ,t.verify_num_1
    ,t.verify_num_2
    ,t.verify_num_3
    ,t.verify_num_4
    ,t.verify_num_5
    ,t.verify_num_6
    ,t.verify_num_7
    ,t.verify_num_8
    ,t.verify_num_9
    ,t.verify_num_10
    ,t.verify_num_11
    ,t.verify_num_12
    ,t.verify_num_13
    ,t.verify_num_14
    ,t.verify_num_15
    ,t.verify_num_16
    ,t.verify_num_17
    ,t.jl_verify_num_1
    ,t.jl_verify_num_2
    ,t.jl_verify_num_3
    ,t.jl_verify_num_4
    ,t.jl_verify_num_5
    ,t.jl_verify_num_6
    ,t.jl_verify_num_7
    ,t.jl_verify_num_8
    ,t.jl_verify_num_9
    ,t.jl_verify_num_10
    ,t.jl_verify_num_11
    ,t.jl_verify_num_12

    ,case when ifnull(t3.member_id,'')<>'' then '特定人员模块' else '' end  as spare_field1               -- string COMMENT '特定人员模块标签'
    ,case when ifnull(t4.sid,'')<>'' then '身份动态码核销' else '' end as spare_field2               -- string COMMENT '身份动态码核销'
    ,jl_verify_num_13 as spare_field3               -- string COMMENT '景旅认证-居住证'
    ,'' as spare_field4               -- string COMMENT '自定义字段4'
    ,'' as spare_field5               -- string COMMENT '自定义字段5'
    ,'' as spare_field6               -- string COMMENT '自定义字段6'
    ,'' as spare_field7               -- string COMMENT '自定义字段7'
    ,'' as spare_field8               -- string COMMENT '自定义字段8'
    ,'' as spare_field9               -- string COMMENT '自定义字段9'
    ,'' as spare_field10              -- string COMMENT '自定义字段10'
    ,'' as spare_field11              -- string COMMENT '自定义字段11'
    ,'' as spare_field12              -- string COMMENT '自定义字段12'
    ,'' as spare_field13              -- string COMMENT '自定义字段13'
    ,'' as spare_field14              -- string COMMENT '自定义字段14'
    ,'' as spare_field15              -- string COMMENT '自定义字段15'
    ,'' as spare_field16              -- string COMMENT '自定义字段16'
    ,'' as spare_field17              -- string COMMENT '自定义字段17'
    ,'' as spare_field18              -- string COMMENT '自定义字段18'
    ,'' as spare_field19              -- string COMMENT '自定义字段19'
    ,'' as spare_field20              -- string COMMENT '自定义字段20'

from (--游客核验信息表
    select a.insertdate   -- 核验日期
        ,a.user_name  -- 客户名称
        ,a.user_account  -- 账号
        ,a.apply_did  -- 客户ID
        ,a.servicer
        ,sum(a.verify_num) as verify_num  -- 入园人数
        
        -- 景旅纵横认证
        ,sum(a.verify_num * c.verify_flag_1) as verify_num_1
        ,sum(a.verify_num * c.verify_flag_2) as verify_num_2
        ,sum(a.verify_num * c.verify_flag_3) as verify_num_3
        ,sum(a.verify_num * c.verify_flag_4) as verify_num_4
        ,sum(a.verify_num * c.verify_flag_5) as verify_num_5
        ,sum(a.verify_num * c.verify_flag_6) as verify_num_6
        ,sum(a.verify_num * c.verify_flag_7) as verify_num_7
        ,sum(a.verify_num * c.verify_flag_8) as verify_num_8
        ,sum(a.verify_num * c.verify_flag_9) as verify_num_9
        ,sum(a.verify_num * c.verify_flag_10) as verify_num_10
        ,sum(a.verify_num * c.verify_flag_11) as verify_num_11
        ,sum(a.verify_num * c.verify_flag_12) as verify_num_12
        ,sum(a.verify_num * c.verify_flag_13) as verify_num_13
        ,sum(a.verify_num * c.verify_flag_14) as verify_num_14
        ,sum(a.verify_num * c.verify_flag_15) as verify_num_15
        ,sum(a.verify_num * c.verify_flag_16) as verify_num_16
        ,sum(a.verify_num * c.verify_flag_17) as verify_num_17


        -- 景旅认证
        ,sum(a.verify_num * d.jl_flag_1) as jl_verify_num_1
        ,sum(a.verify_num * d.jl_flag_2) as jl_verify_num_2
        ,sum(a.verify_num * d.jl_flag_3) as jl_verify_num_3
        ,sum(a.verify_num * d.jl_flag_4) as jl_verify_num_4
        ,sum(a.verify_num * d.jl_flag_5) as jl_verify_num_5
        ,sum(a.verify_num * d.jl_flag_6) as jl_verify_num_6
        ,sum(a.verify_num * d.jl_flag_7) as jl_verify_num_7
        ,sum(a.verify_num * d.jl_flag_8) as jl_verify_num_8
        ,sum(a.verify_num * d.jl_flag_9) as jl_verify_num_9
        ,sum(a.verify_num * d.jl_flag_10) as jl_verify_num_10
        ,sum(a.verify_num * d.jl_flag_11) as jl_verify_num_11
        ,sum(a.verify_num * d.jl_flag_12) as jl_verify_num_12
        ,sum(a.verify_num * d.jl_flag_13) as jl_verify_num_13


    from cache_landtravel_user_verify_info  a      -- 供应商用户

    left join cache_landtravel_user_verify c       -- 景区纵横认证
        on a.idcard = c.id_no

    left join cache_landtravel_tourist_verify d    -- 景旅认证
        on a.idcard = d.certificate_no

    group by a.insertdate,a.user_name,a.user_account,a.apply_did,a.servicer
    ) t      --游客核验信息表

left join cache_landtravel_msg_send t1      --短信发送总量
    on t.apply_did = t1.aid and  t.insertdate = t1.send_time

left join cache_landtravel_records t2       --开票
    on t.apply_did = t2.sid and  t.insertdate = t2.send_time

left join 
    (select distinct a.member_id
     from ods_pft001_pft_module_used_d_f a
     where a.pt = ${ds}
     and a.module_id='325'

     --套餐-拆模块
     union
     select distinct a.user_id
     from dwd_user_package_d_f a
     left join dim_prod_pft_module_package_detail_d_f b 
         on a.package_id=b.package_id
         and b.pt=${ds}
     left join ods_pft001_pft_module_d_f c 
         on b.module_id=c.id
         and c.pt=${ds}
     where a.pt=${ds}  and b.module_id = '325'
    ) t3
    on t.apply_did = t3.member_id

left join 
    (select sid
     from ods_pft_member_access_account_d_f
     where pt = ${ds}
     and app_id = '134'
     group by sid
    ) t4
    on t.apply_did = t4.sid
;











