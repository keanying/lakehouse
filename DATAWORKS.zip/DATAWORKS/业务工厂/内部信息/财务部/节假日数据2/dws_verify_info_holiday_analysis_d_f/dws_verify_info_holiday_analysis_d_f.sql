--EMR Spark SQL
--********************************************************************--
--author: 施建伟
--create time: 2026-04-23 15:09:13
--EMR任务只能运行在独享资源组上
--********************************************************************--





create table if NOT EXISTS dws_verify_info_holiday_analysis_d_f
(
    insertdate	            int     COMMENT '下单日期'
    ,ordernum	            string  COMMENT '订单号'
    --,origin_num	            int     COMMENT '预定票数(订单轨迹表清洗的预定票数)'
    --,pay_num	            int     COMMENT '支付票数(订单轨迹表清洗的支付票数)'
    --,sale_price             int     COMMENT '实际售价(uu_ss_order表的tprice)'
    ,verify_ticket_num      int     COMMENT '验证票数'
    ,verify_ticket_moner    int     COMMENT '验证金额'

    ,apply_did	            int     COMMENT '原始供应商ID'
    ,lid	                int     COMMENT '景区id'
    ,tid	                int     COMMENT '门票id'
    ,pid	                int     COMMENT '产品id'
    ,product_type	        string  COMMENT '商品类型'
    ,channel_class1_id	    int     COMMENT '渠道一级分类id'
    ,channel_class1_name	string  COMMENT '渠道一级分类名称'
    ,channel_class2_id	    int     COMMENT '渠道二级分类id'
    ,channel_class2_name	string  COMMENT '渠道二级分类名称'
    ,booking_time	        string  COMMENT '下单时间'
    ,verify_time	        string  COMMENT '验证时间'
    ,play_time	            string  COMMENT '预计游玩时间'
    ,cancel_time	        string  COMMENT '取消时间'
    ,ticket_id	            int	    COMMENT '票id'
    ,ticket_fullname	    string  COMMENT '票名'
    ,seller_id	            string  COMMENT '销售者/收款人'
    ,booker_id	            string  COMMENT '购买者'
    ,ticket_taker_age	    int     COMMENT '取票人年龄'
    ,ticket_taker_sex	    string  COMMENT '取票人性别'
    ,booking_channel	    string  COMMENT '销售渠道ID'
    ,booking_channel_name	string  COMMENT '销售渠道名称'
    ,land_province	        string  COMMENT '景区所在省'
    ,land_city	            string  COMMENT '景区城市名称'
    ,ticket_taker_province	string  COMMENT '取票人所在省-活动地归属'
    ,ticket_taker_city	    string  COMMENT '取票人所在市-活动地归属'
    ,user_name	            string  COMMENT '用户名称/账户名称'
    ,user_type	            string  COMMENT '用户类型'
    ,customer_type	        string  COMMENT '客户类型'
    ,user_contract_model	string  COMMENT '合作模式'
    ,user_land_topic	    string  COMMENT '景区业态'
    ,user_level	            string  COMMENT '级别'
    ,customer_province	    string  COMMENT '客户省'
    ,customer_city	        string  COMMENT '客户市'
    ,land_type_name	        string  COMMENT '景区类型'
    ,channel                string  COMMENT 'ota类型'
    ,age_mark               string  COMMENT '年龄段'
    ,yyts       	        string  COMMENT '提前预约天数'
    ,holiday_type           string  COMMENT '节假日类型'
) comment '节假日分析的数据--验证' 
PARTITIONED BY(`pt` string) 
STORED AS ORC;






















insert overwrite table dws_verify_info_holiday_analysis_d_f partition (pt = "${ds}")

-- ================= 增量分支：只计算配置表里尚未加载过的节假日日期 =================
select t1.insertdate
    ,t1.ordernum
    ,t1.verify_ticket_num
    ,t1.verify_ticket_moner
    ,t1.apply_did
    ,t1.lid
    ,t1.tid
    ,t1.pid
    ,t1.product_type
    ,t1.channel_class1_id
    ,t1.channel_class1_name
    ,t1.channel_class2_id
    ,t1.channel_class2_name
    ,t2.booking_time
    ,t2.verify_time
    ,t2.play_time
    ,t2.cancel_time
    ,t2.ticket_id
    ,t2.ticket_fullname
    ,t2.seller_id
    ,t2.booker_id
    ,t2.ticket_taker_age
    ,t2.ticket_taker_sex
    ,t2.booking_channel
    ,t2.booking_channel_name
    ,t2.land_province
    ,t2.land_city
    ,t2.ticket_taker_province
    ,t2.ticket_taker_city
    ,t3.user_name
    ,t3.user_type
    ,t3.customer_type
    ,t3.user_contract_model
    ,t3.user_land_topic
    ,t3.user_level
    ,t3.customer_province
    ,t3.customer_city
    ,t4.land_type_name

    -- ota类型
    ,case when t2.booking_channel in (17, 58, 20) then
            case when (t2.seller_id in ('28227','9718585','5269593','27819617') or t2.booker_id in ('28227','9718585','5269593','27819617')) then 'OTA-美团'
                when (t2.seller_id = '2175' or t2.booker_id = '2175') then 'OTA-去哪儿'
                when (t2.seller_id in ('3663752','1214') or t2.booker_id in ('3663752','1214')) then 'OTA-携程'
                when (t2.seller_id = '10141128' or t2.booker_id = '10141128') then 'OTA-高德'
                when (t2.seller_id in ('12404122','26856539','13913690') or t2.booker_id in ('12404122','26856539','13913690')) then 'OTA-抖音'
                when (t2.seller_id = '9011093' or t2.booker_id = '9011093') then 'OTA-阿里'
                when (t2.seller_id in ('12513404','27003241','15467659') or t2.booker_id in ('12513404','27003241','15467659')) then 'OTA-快手'
                when (t2.seller_id = '1472' or t2.booker_id = '1472') then 'OTA-驴妈妈'
                when (t2.seller_id in ('13151618','1252953') or t2.booker_id in ('13151618','1252953')) then 'OTA-马蜂窝'
                when (t2.seller_id = '1454' or t2.booker_id = '1454') then 'OTA-同程'
                when (t2.seller_id = '3034' or t2.booker_id = '3034') then 'OTA-途牛'
                when (t2.seller_id = '4560136' or t2.booker_id = '4560136') then 'OTA-微盟'
                when (t2.seller_id = '23433252' or t2.booker_id = '23433252') then 'OTA-有赞'
                when (t2.seller_id = '10406130' or t2.booker_id = '10406130') then 'OTA-支付宝'
                else 'OTA-其他'
            end
        else t2.booking_channel_name
        end as channel

    -- 年龄段
    ,case when t2.ticket_taker_age >= 0  and t2.ticket_taker_age <= 6  then '幼儿'
          when t2.ticket_taker_age >= 7  and t2.ticket_taker_age <= 15 then '小学、初中'
          when t2.ticket_taker_age >= 16 and t2.ticket_taker_age <= 18 then '高中'
          when t2.ticket_taker_age >= 19 and t2.ticket_taker_age <= 21 then '大学'
          when t2.ticket_taker_age >= 22 and t2.ticket_taker_age <= 30 then '初入社会'
          when t2.ticket_taker_age >= 31 and t2.ticket_taker_age <= 40 then '小家庭'
          when t2.ticket_taker_age >= 41 and t2.ticket_taker_age <= 50 then '壮年'
          when t2.ticket_taker_age >= 51 and t2.ticket_taker_age <= 55 then '中年'
          when t2.ticket_taker_age >= 56 and t2.ticket_taker_age <= 60 then '女退休'
          when t2.ticket_taker_age >= 61 and t2.ticket_taker_age <= 65 then '老人'
          when t2.ticket_taker_age >= 66 and t2.ticket_taker_age <= 70 then '男退休'
          when t2.ticket_taker_age >= 71 and t2.ticket_taker_age <= 130 then '老人'
     end as age_mark

    -- 提前预约天数
    ,case when datediff(substr(t2.verify_time, 1, 10), substr(t2.booking_time,1,10)) = 1 then '提前一天'
          when datediff(substr(t2.verify_time, 1, 10), substr(t2.booking_time,1,10)) > 1
               and datediff(substr(t2.verify_time, 1, 10), substr(t2.booking_time,1,10)) <= 3 then '提前一至三天'
          when datediff(substr(t2.verify_time, 1, 10), substr(t2.booking_time,1,10)) > 3
               and datediff(substr(t2.verify_time, 1, 10), substr(t2.booking_time,1,10)) <= 7 then '提前三至七天'
          when datediff(substr(t2.verify_time, 1, 10), substr(t2.booking_time,1,10)) > 7 then '提前七天以上'
     end as yyts

    -- 节假日类型：直接取配置表，不再写死日期
    ,nd.holiday_type

from dwd_order_track_d_i t1

-- 窗口表（极小，自动广播）：既做日期过滤，又带出 holiday_type
inner join cache_tmp_holiday_newdates nd
    on cast(t1.insertdate as int) = nd.insertdate


-- -- 节假日配置表（极小表，自动广播），替代原来写死的 12 段日期区间
-- cross join dim_holiday_calendar cal

-- -- 排除昨天分区里已经加载过的日期（首次运行时昨天分区不存在，此处为空，全部日期都会加载）
-- left anti join (select insertdate from cache_tmp_verify_holiday group by insertdate) prev
--     on cast(t1.insertdate as int) = prev.insertdate


left join dwd_order_d_i t2
    on t1.ordernum = t2.order_id

left join
    (select user_id
        ,user_name
        ,user_type
        ,customer_type
        ,user_contract_model
        ,user_land_topic
        ,user_level
        ,customer_province
        ,customer_city
     from dim_user_d_f
     where pt = '${ds}' and user_is_test = '正式'
    ) t3
    on t1.apply_did = t3.user_id

left join (select ticket_id,land_type_name from dim_prod_d_f where pt = '${ds}') t4
    on t1.tid = t4.ticket_id

where t1.verify_ticket_num > 0
--   and cast(t1.insertdate as int) >= cal.holiday_start
--   and cast(t1.insertdate as int) <= cal.holiday_end




-- ================= 存量分支：原样复制昨天分区的全部数据 =================
union all
select
     insertdate
    ,ordernum
    ,verify_ticket_num
    ,verify_ticket_moner
    ,apply_did
    ,lid
    ,tid
    ,pid
    ,product_type
    ,channel_class1_id
    ,channel_class1_name
    ,channel_class2_id
    ,channel_class2_name
    ,booking_time
    ,verify_time
    ,play_time
    ,cancel_time
    ,ticket_id
    ,ticket_fullname
    ,seller_id
    ,booker_id
    ,ticket_taker_age
    ,ticket_taker_sex
    ,booking_channel
    ,booking_channel_name
    ,land_province
    ,land_city
    ,ticket_taker_province
    ,ticket_taker_city
    ,user_name
    ,user_type
    ,customer_type
    ,user_contract_model
    ,user_land_topic
    ,user_level
    ,customer_province
    ,customer_city
    ,land_type_name
    ,channel
    ,age_mark
    ,yyts
    ,holiday_type
from cache_tmp_verify_holiday ;



























-- INSERT OVERWRITE table dws_verify_info_holiday_analysis_d_f PARTITION (pt="${ds}")
-- select t1.insertdate     --orderdate			--t1.insertdate               --动作日期
--     ,t1.ordernum       --orderid    				--,t1.ordernum                   --订单号ID
-- --    ,t1.origin_num              --预定票数(订单轨迹表清洗的预定票数)
-- --    ,t1.pay_num                 --支付票数(订单轨迹表清洗的支付票数)
	
--     --,t1.booking_ticket_num         --预定票数
--     --,t1.booking_ticket_monery      --预定金额
--     ,t1.verify_ticket_num          --验证票数
--     ,t1.verify_ticket_moner        --验证金额
--     --,t1.cancel_ticket_num          --退票数
--     --,t1.cancel_ticket_moner        --退票金额
--     ,t1.apply_did                  --原始供应商ID
--     ,t1.lid                        --景区id
--     ,t1.tid                        --门票id
--     ,t1.pid                        --产品id
--     ,t1.product_type               --商品类型
--     ,t1.channel_class1_id          --渠道一级分类id
--     ,t1.channel_class1_name        --渠道一级分类名称
--     ,t1.channel_class2_id          --渠道二级分类id
--     ,t1.channel_class2_name        --渠道二级分类名称



--     ,t2.booking_time            --下单时间
--     ,t2.verify_time             --验证时间
--     ,t2.play_time               --预计游玩时间
--     ,t2.cancel_time
--     ,t2.ticket_id               --票id
--     ,t2.ticket_fullname         --票名
--     ,t2.seller_id               --销售者/收款人
--     ,t2.booker_id               --购买者
--     ,t2.ticket_taker_age        --取票人年龄
--     ,t2.ticket_taker_sex        --取票人性别
--     ,t2.booking_channel         --销售渠道ID
--     ,t2.booking_channel_name    --销售渠道名称
--     ,t2.land_province           --景区所在省
--     ,t2.land_city               --景区城市名称
--     ,t2.ticket_taker_province   --取票人所在省-活动地归属
--     ,t2.ticket_taker_city       --取票人所在市-活动地归属


--     ,t3.user_name
--     ,t3.user_type
--     ,t3.customer_type
--     ,t3.user_contract_model
--     ,t3.user_land_topic            
--     ,t3.user_level
--     ,t3.customer_province
--     ,t3.customer_city

--     ,t4.land_type_name          --景区类型



--     ,case when t2.booking_channel in (17, 58, 20) then 
--             case when (t2.seller_id in ('28227','9718585','5269593','27819617') or t2.booker_id in  ('28227','9718585','5269593','27819617')) THEN 'OTA-美团' 
--                 when (t2.seller_id = '2175' or t2.booker_id = '2175') THEN 'OTA-去哪儿'
--                 when (t2.seller_id in ('3663752','1214') or t2.booker_id in ('3663752','1214')) THEN 'OTA-携程'
--                 when (t2.seller_id = '10141128' or t2.booker_id = '10141128') THEN 'OTA-高德'
--                 when (t2.seller_id in ('12404122','26856539','13913690') or t2.booker_id in ('12404122','26856539','13913690')) THEN 'OTA-抖音'
--                 when (t2.seller_id = '9011093' or t2.booker_id = '9011093') THEN 'OTA-阿里'
--                 when (t2.seller_id in ('12513404','27003241','15467659') or t2.booker_id in ('12513404','27003241','15467659')) THEN 'OTA-快手'
--                 when (t2.seller_id = '1472' or t2.booker_id = '1472') THEN 'OTA-驴妈妈'
--                 when (t2.seller_id in ('13151618','1252953') or booker_id in ('13151618','1252953')) THEN 'OTA-马蜂窝'
--                 when (t2.seller_id = '1454' or t2.booker_id = '1454') THEN 'OTA-同程'
--                 when (t2.seller_id = '3034' or t2.booker_id = '3034') THEN 'OTA-途牛'
--                 when (t2.seller_id = '4560136' or t2.booker_id = '4560136') THEN 'OTA-微盟'
--                 when (t2.seller_id = '23433252' or t2.booker_id = '23433252') THEN 'OTA-有赞'
--                 when (t2.seller_id = '10406130' or t2.booker_id = '10406130') THEN 'OTA-支付宝'
--                 else 'OTA-其他'
--             end
--         else t2.booking_channel_name
--         end as channel

--     --年龄段
--     ,case when t2.ticket_taker_age >= 0 and t2.ticket_taker_age <= 6 then '幼儿' 
-- 		  when t2.ticket_taker_age >= 7 and t2.ticket_taker_age <= 15 then '小学、初中' 
-- 		  when t2.ticket_taker_age >= 16 and t2.ticket_taker_age <= 18 then '高中' 
-- 		  when t2.ticket_taker_age >= 19 and t2.ticket_taker_age <= 21 then '大学' 
-- 		  when t2.ticket_taker_age >= 22 and t2.ticket_taker_age <= 30 then '初入社会' 
-- 		  when t2.ticket_taker_age >= 31 and t2.ticket_taker_age <= 40 then '小家庭' 
-- 		  when t2.ticket_taker_age >= 41 and t2.ticket_taker_age <= 50 then '壮年' 
-- 		  when t2.ticket_taker_age >= 51 and t2.ticket_taker_age <= 55 then '中年' 
-- 		  when t2.ticket_taker_age >= 56 and t2.ticket_taker_age <= 60 then '女退休' 
-- 		  when t2.ticket_taker_age >= 61 and t2.ticket_taker_age <= 65 then '老人' 
-- 		  when t2.ticket_taker_age >= 66 and t2.ticket_taker_age <= 70 then '男退休' 
-- 		  when t2.ticket_taker_age >= 71 and t2.ticket_taker_age <= 130 then '老人' 
-- 		end as age_mark

--     -- 提前预约天数
--     ,case when datediff(substr(verify_time, 1, 10), substr(booking_time,1,10)) = 1 then '提前一天' 
-- 			when datediff(substr(verify_time, 1, 10), substr(booking_time,1,10)) > 1 and datediff(substr(verify_time, 1, 10), substr(booking_time,1,10)) <= 3 then '提前一至三天' 
-- 			when datediff(substr(verify_time, 1, 10), substr(booking_time,1,10)) > 3 and datediff(substr(verify_time, 1, 10), substr(booking_time,1,10)) <= 7 then '提前三至七天'
-- 			when datediff(substr(verify_time, 1, 10), substr(booking_time,1,10)) > 7 then '提前七天以上' 
-- 		end as yyts



--     ,case when (t1.insertdate >='20250128' and t1.insertdate <='20250204') 
--                 or (t1.insertdate >='20260215' and t1.insertdate <='20260223')
--                 or (t1.insertdate >='20240210' and t1.insertdate <='20240217') then '春节'

--           when (t1.insertdate >='20260404' and t1.insertdate <='20260406') 
--                 or (t1.insertdate >='20250404' and t1.insertdate <='20250406') 
--                 or (t1.insertdate >='20240404' and t1.insertdate <='20240406') then '清明'

--           when (t1.insertdate >= '20260501' and t1.insertdate <='20260505')
--                 or (t1.insertdate >= '20250501' and t1.insertdate <='20250505')
--                 or (t1.insertdate >= '20240501' and t1.insertdate <='20240505') then '五一'
          
--           when (t1.insertdate >= '20260619' and t1.insertdate <='20260621')
--                 or (t1.insertdate >= '20250531' and t1.insertdate <='20250602') 
--                 or (t1.insertdate >= '20240608' and t1.insertdate <='20240610') then '端午'

--         end as holiday_type   --节假日类型

-- from dwd_order_track_d_i t1   --s_order_track_d_i t1
-- --dim_order_d_i t1

-- left join dwd_order_d_i t2
--     on t1.ordernum=t2.order_id

-- left join dim_user_d_f t3
--     on t1.apply_did=t3.user_id
--     and t3.user_is_test='正式'
--     and t3.pt=${ds}

-- left join dim_prod_d_f t4 
--     on t1.tid = t4.ticket_id
--     and t4.pt =${ds}

 
--  where t1.verify_ticket_num>0
-- --      (
-- --         (t1.action = 5 and get_json_object(ext_content, '$.need_write_num') > 0)
-- --         or (t1.action = 5 and source not in (53, 54, 32, 85))
-- --         OR (t1.action = 33 and source in (32, 85))
-- --      )

-- and (   --春节
--         (t1.insertdate >= '20250128' and t1.insertdate <='20250204') 
--         or (t1.insertdate >= '20260215' and t1.insertdate <='20260223')
--         or (t1.insertdate >= '20240210' and t1.insertdate <='20240217') 

--         --清明
--         or (t1.insertdate >= '20260404' and t1.insertdate <='20260406') 
--         or (t1.insertdate >= '20250404' and t1.insertdate <='20250406') 
--         or (t1.insertdate >= '20240404' and t1.insertdate <='20240406')

--         --五一
--         or (t1.insertdate >= '20260501' and t1.insertdate <='20260505')
--         or (t1.insertdate >= '20250501' and t1.insertdate <='20250505') 
--         or (t1.insertdate >= '20240501' and t1.insertdate <='20240505') 

--         --端午
--         or (t1.insertdate >= '20260619' and t1.insertdate <='20260621')
--         or (t1.insertdate >= '20250531' and t1.insertdate <='20250602') 
--         or (t1.insertdate >= '20240608' and t1.insertdate <='20240610') 
--     );











----------------------------------------------------------

--订单、票数、GMV
drop table ads_verify_holiday_analysis_1_ddpsgmv;
create table ads_verify_holiday_analysis_1_ddpsgmv as
select substr(insertdate,1,4) as oper_year        --年
    ,holiday_type   --节假日类型
    ,count(distinct ordernum) as ordernum
    ,sum( nvl(verify_ticket_num,0) ) as ticket_num
    ,sum( nvl(verify_ticket_moner,0) ) as gmv
from dws_verify_info_holiday_analysis_d_f
where pt=${ds}
group by substr(insertdate,1,4),holiday_type;



 --每日客流
drop table ads_verify_holiday_analysis_2_mrkl;
create table ads_verify_holiday_analysis_2_mrkl as
select oper_year
    ,holiday_type   --节假日类型
    ,insertdate
    ,concat('第',row_number() over(partition by substr(insertdate,1,4),holiday_type order by insertdate asc),'天') as holiday_desc
    ,ticket_num
from (select substr(insertdate,1,4) as oper_year
          ,holiday_type   --节假日类型
          ,insertdate
          ,sum(nvl(verify_ticket_num,0)) as ticket_num
      from dws_verify_info_holiday_analysis_d_f
      where pt=${ds}
      group by substr(insertdate,1,4),holiday_type,insertdate
    );



--业态：订单、票数、GMV
drop table ads_verify_holiday_analysis_3_yt_ddpsgmv;
create table ads_verify_holiday_analysis_3_yt_ddpsgmv as
select substr(insertdate,1,4) as oper_year
    ,holiday_type   --节假日类型
    ,user_land_topic
    ,count(distinct ordernum) as ordernum
    ,sum( nvl(verify_ticket_num,0) ) as ticket_num
    ,sum( nvl(verify_ticket_moner,0) ) as gmv
from dws_verify_info_holiday_analysis_d_f
where pt=${ds}
group by substr(insertdate,1,4),holiday_type,user_land_topic;




--渠道：订单
drop table ads_verify_holiday_analysis_4_qd_ddpsgmv;
create table ads_verify_holiday_analysis_4_qd_ddpsgmv as
select substr(insertdate,1,4) as oper_year        --年
    ,holiday_type   --节假日类型
    ,channel_class1_name    --渠道一级分类名称
    ,channel_class2_name    --渠道二级分类名称
    ,count(distinct ordernum) as ordernum
    ,sum( nvl(verify_ticket_num,0) ) as ticket_num
    ,sum( nvl(verify_ticket_moner,0) ) as gmv
from dws_verify_info_holiday_analysis_d_f
where pt=${ds}
group by substr(insertdate,1,4),holiday_type,channel_class1_name,channel_class2_name;




--ota：订单
drop table ads_verify_holiday_analysis_5_ota_ddpsgmv;
create table ads_verify_holiday_analysis_5_ota_ddpsgmv as
select substr(insertdate,1,4) as oper_year        --年
    ,holiday_type   --节假日类型
    ,channel
    ,count(distinct ordernum) as ordernum
    ,sum( nvl(verify_ticket_num,0) ) as ticket_num
    ,sum( nvl(verify_ticket_moner,0) ) as gmv
from dws_verify_info_holiday_analysis_d_f
where pt=${ds}
group by substr(insertdate,1,4),holiday_type,channel;




--年龄段：票数
drop table ads_verify_holiday_analysis_6_age_ddpsgmv;
create table ads_verify_holiday_analysis_6_age_ddpsgmv as
select substr(insertdate,1,4) as oper_year        --年
    ,holiday_type   --节假日类型
    ,age_mark 
    ,count(distinct ordernum) as ordernum
    ,sum( nvl(verify_ticket_num,0) ) as ticket_num
    ,sum( nvl(verify_ticket_moner,0) ) as gmv
from dws_verify_info_holiday_analysis_d_f
where pt=${ds}
group by substr(insertdate,1,4),holiday_type,age_mark;




--提前天数
drop table ads_verify_holiday_analysis_7_perday_ddpsgmv;
create table ads_verify_holiday_analysis_7_perday_ddpsgmv as
select substr(insertdate,1,4) as oper_year        --年
    ,holiday_type   --节假日类型
    ,yyts -- 提前预约天数
    ,count(distinct ordernum) as ordernum
    ,sum( nvl(verify_ticket_num,0) ) as ticket_num
    ,sum( nvl(verify_ticket_moner,0) ) as gmv
from dws_verify_info_holiday_analysis_d_f
where pt=${ds}
group by substr(insertdate,1,4),holiday_type,yyts;




--结伴：票数
drop table ads_verify_holiday_analysis_8_jb_ddpsgmv;
create table ads_verify_holiday_analysis_8_jb_ddpsgmv as
select substr(insertdate,1,4) as oper_year        --年
    ,holiday_type   --节假日类型
    ,case when verify_ticket_num > 0 and verify_ticket_num <= 1 then '单人' 
		  when verify_ticket_num > 1 and verify_ticket_num <= 4 then '2-4人' 
		  when verify_ticket_num > 4 and verify_ticket_num <= 10 then '5-10人' 
		  when verify_ticket_num > 10 then '10人以上' 
		end as cyrs
    ,count(distinct ordernum) as ordernum
    ,sum( nvl(verify_ticket_num,0) ) as ticket_num
    ,sum( nvl(verify_ticket_moner,0) ) as gmv
from dws_verify_info_holiday_analysis_d_f
where pt=${ds}
group by substr(insertdate,1,4),holiday_type
     ,case when verify_ticket_num > 0 and verify_ticket_num <= 1 then '单人' 
		  when verify_ticket_num > 1 and verify_ticket_num <= 4 then '2-4人' 
		  when verify_ticket_num > 4 and verify_ticket_num <= 10 then '5-10人' 
		  when verify_ticket_num > 10 then '10人以上' 
		end;




--提前天数、业态
drop table ads_verify_holiday_analysis_9_perday_yt_ddpsgmv;
create table ads_verify_holiday_analysis_9_perday_yt_ddpsgmv as
select substr(insertdate,1,4) as oper_year        --年
    ,holiday_type   --节假日类型
    ,yyts -- 提前预约天数
    ,user_land_topic
    ,count(distinct ordernum) as ordernum
    ,sum( nvl(verify_ticket_num,0) ) as ticket_num
    ,sum( nvl(verify_ticket_moner,0) ) as gmv
from dws_verify_info_holiday_analysis_d_f
where pt=${ds}
group by substr(insertdate,1,4),holiday_type,yyts,user_land_topic;




--跨省
drop table ads_verify_holiday_analysis_10_ks_ddpsgmv;
create table ads_verify_holiday_analysis_10_ks_ddpsgmv as
select substr(insertdate,1,4) as oper_year        --年
    ,holiday_type   --节假日类型
    ,land_province
    ,case when land_province <> ticket_taker_province then '跨省' else '省内' end as fmark_sfks
    ,count(distinct ordernum) as ordernum
    ,sum( nvl(verify_ticket_num,0) ) as ticket_num
    ,sum( nvl(verify_ticket_moner,0) ) as gmv
from dws_verify_info_holiday_analysis_d_f
where pt=${ds}
group by substr(insertdate,1,4),holiday_type,land_province
    ,case when land_province <> ticket_taker_province then '跨省' else '省内' end;




--景区客均
drop table ads_verify_holiday_analysis_11_jqkj_ps;
create table ads_verify_holiday_analysis_11_jqkj_ps as
select substr(insertdate,1,4) as oper_year        --年
    ,holiday_type   --节假日类型
    ,land_province
    ,round( SUM( nvl(verify_ticket_num,0) )/count(distinct apply_did) ,0) as kjll-- 景区客均流量
from dws_verify_info_holiday_analysis_d_f
where pt=${ds}
    and user_type = '供应商'
    and customer_type = '景区'
    and user_contract_model='项目'
group by substr(insertdate,1,4),holiday_type,land_province;













/*
--订单、票数、GMV
select * from ads_verify_holiday_analysis_1_ddpsgmv;

 --每日客流(票数)
select * from ads_verify_holiday_analysis_2_mrkl;

--业态(订单、票数、GMV)
select * from ads_verify_holiday_analysis_3_yt_ddpsgmv;

--渠道(订单、票数、GMV)
select * from ads_verify_holiday_analysis_4_qd_ddpsgmv;

--ota(订单、票数、GMV)
select * from ads_verify_holiday_analysis_5_ota_ddpsgmv;

--年龄段(订单、票数、GMV)
select * from ads_verify_holiday_analysis_6_age_ddpsgmv;

--提前天数(订单、票数、GMV)
select * from ads_verify_holiday_analysis_7_perday_ddpsgmv;

--结伴(订单、票数、GMV)
select * from ads_verify_holiday_analysis_8_jb_ddpsgmv;

--提前天数、业态(订单、票数、GMV)
select * from ads_verify_holiday_analysis_9_perday_yt_ddpsgmv;

--跨省(订单、票数、GMV)
select * from ads_verify_holiday_analysis_10_ks_ddpsgmv;

--景区客均(票数)
select * from ads_verify_holiday_analysis_11_jqkj_ps;

*/










