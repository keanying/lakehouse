--EMR Spark SQL
--********************************************************************--
--author: 施建伟
--create time: 2026-09-28 10:47:07
--EMR任务只能运行在独享资源组上
--********************************************************************--










--存量数据
DROP TABLE IF EXISTS cache_tmp_verify_holiday;
CREATE TABLE cache_tmp_verify_holiday  STORED as ORC as
select insertdate
    ,ordernum
    ,verify_ticket_num
    ,verify_ticket_moner
    ,apply_did
    ,lid
    ,tid
    ,pid
    ,product_type
    ,channel_class1_id
    ,channel_class1_name
    ,channel_class2_id
    ,channel_class2_name
    ,booking_time
    ,verify_time
    ,play_time
    ,cancel_time
    ,ticket_id
    ,ticket_fullname
    ,seller_id
    ,booker_id
    ,ticket_taker_age
    ,ticket_taker_sex
    ,booking_channel
    ,booking_channel_name
    ,land_province
    ,land_city
    ,ticket_taker_province
    ,ticket_taker_city
    ,user_name
    ,user_type
    ,customer_type
    ,user_contract_model
    ,user_land_topic
    ,user_level
    ,customer_province
    ,customer_city
    ,land_type_name
    ,channel
    ,age_mark
    ,yyts
    ,holiday_type
FROM dws_verify_info_holiday_analysis_d_f
WHERE pt in (select max(pt) as pt from dws_verify_info_holiday_analysis_d_f);








--存量数据
DROP TABLE IF EXISTS cache_tmp_order_holiday;
CREATE TABLE cache_tmp_order_holiday  STORED as ORC as
select orderdate     			--t1.insertdate               --发生时间
    ,orderid    				--,t1.ordernum                   --订单号ID
    ,origin_num              --预定票数(订单轨迹表清洗的预定票数)
    ,pay_num                 --支付票数(订单轨迹表清洗的支付票数)
	,sale_price                 --实际售价(uu_ss_order表的tprice)
    ,apply_did                  --原始供应商ID
    ,lid                        --景区id
    ,tid                        --门票id
    ,pid                        --产品id
    ,product_type               --商品类型
    ,channel_class1_id          --渠道一级分类id
    ,channel_class1_name        --渠道一级分类名称
    ,channel_class2_id          --渠道二级分类id
    ,channel_class2_name        --渠道二级分类名称
    ,booking_time            --下单时间
    ,verify_time             --验证时间
    ,play_time               --预计游玩时间
    ,cancel_time
    ,ticket_id               --票id
    ,ticket_fullname         --票名
    ,seller_id               --销售者/收款人
    ,booker_id               --购买者
    ,ticket_taker_age        --取票人年龄
    ,ticket_taker_sex        --取票人性别
    ,booking_channel         --销售渠道ID
    ,booking_channel_name    --销售渠道名称
    ,land_province           --景区所在省
    ,land_city               --景区城市名称
    ,ticket_taker_province   --取票人所在省-活动地归属
    ,ticket_taker_city       --取票人所在市-活动地归属
    ,user_name
    ,user_type
    ,customer_type
    ,user_contract_model
    ,user_land_topic            
    ,user_level
    ,customer_province
    ,customer_city
    ,land_type_name          --景区类型
    ,channel
    ,age_mark
    ,yyts
    ,holiday_type   --节假日类型
FROM dws_order_info_holiday_analysis_d_f
WHERE pt in (select max(pt) as pt from dws_order_info_holiday_analysis_d_f);







-- ============================================================================
-- 第一部分：节假日配置表（一次性执行，建好表并初始化历史区间）
-- ============================================================================
create table if not exists dim_holiday_calendar
(
    holiday_type   string  comment '节假日类型: 春节/清明/五一/端午/中秋/国庆...'
    ,holiday_start int     comment '节假日开始日期 yyyymmdd'
    ,holiday_end   int     comment '节假日结束日期 yyyymmdd'
)
comment '节假日日期区间配置表——节假日快到时手工新增一行即可，增量任务自动识别';


-- 初始化：把原脚本中已有的 12 段日期区间写入配置表（与原脚本完全一致）
-- 【以后新增节假日只需要这一步】节假日快到时，手工执行下面这种 insert（按需改日期）：
-- insert into table dim_holiday_calendar select '中秋', 20260925, 20260927;
-- insert into table dim_holiday_calendar select '国庆', 20261001, 20261007;
-- insert into table dim_holiday_calendar select '春节', 20270206, 20270212;
--insert into table dim_holiday_calendar select '中秋国庆', 20240915, 20240917;
--insert into table dim_holiday_calendar select '中秋国庆', 20241001, 20241007;
--insert into table dim_holiday_calendar select '中秋国庆', 20251001, 20251008;
--insert into table dim_holiday_calendar select '中秋国庆', 20260925, 20260927;
--insert into table dim_holiday_calendar select '中秋国庆', 20261001, 20261007;


-- ============================================================================
-- 第二部分：确定增量日期窗口（轻量，毫秒级）
--    = 配置表里所有节假日日期 - ① 存量里已加载过的日期
--    带出每个日期的 holiday_type，按日期去重（防重叠区间导致 join 出重复行）
-- ============================================================================
drop table if exists cache_tmp_holiday_newdates;
create table cache_tmp_holiday_newdates stored as orc as
select insertdate, min(holiday_type) as holiday_type
from (
      select cast(date_format(cd.d, 'yyyyMMdd') as int) as insertdate
            ,cd.holiday_type
      from (-- 把配置表的区间展开成逐日日期
            select explode(
                    sequence(
                        to_date(cast(holiday_start as string), 'yyyyMMdd'),
                        to_date(cast(holiday_end   as string), 'yyyyMMdd'),
                        interval 1 day
                    )
                ) as d
                ,holiday_type
            from dim_holiday_calendar
           ) cd
      left anti join (select distinct insertdate from cache_tmp_verify_holiday) prev   -- 只读存量临时表的 insertdate 单列，代价很小
      on cast(date_format(cd.d, 'yyyyMMdd') as int) = prev.insertdate
    ) t
group by insertdate;


