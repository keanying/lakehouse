--@exclude_input=default_workspace_svwh.ods_pft_trade_journal_d_i
--EMR Spark SQL
--********************************************************************--
--author: 施建伟
--create time: 2026-03-11 17:32:38
--EMR任务只能运行在独享资源组上
--********************************************************************--








CREATE TABLE if NOT EXISTS dwd_pft_trade_journal_d_f(
	oper_month 				string COMMENT '月份',
	customer_id 			string COMMENT '客户ID',
	account_id 				string COMMENT '账户ID',
	template_item_code 		string COMMENT '模板费用项编码',
	dmoney 					string COMMENT '本次记录金额',
	fid 					string comment '用户id',
	code_num				string comment '条数'
) comment '交易记录小汇总' 
PARTITIONED BY(`pt` string) 
STORED AS ORC;





INSERT OVERWRITE table dwd_pft_trade_journal_d_f PARTITION (pt="${ds}")
select substr(rectime,1,7) as oper_month
    ,customer_id
    ,account_id
    ,template_item_code
    ,sum(dmoney/100/1.06) as dmoney
	,fid
	,count(id) as code_num
from ods_pft_trade_journal_d_i
where substr(rectime,1,7)>='2023-01'
group by customer_id,account_id,substr(rectime,1,7) ,template_item_code,fid