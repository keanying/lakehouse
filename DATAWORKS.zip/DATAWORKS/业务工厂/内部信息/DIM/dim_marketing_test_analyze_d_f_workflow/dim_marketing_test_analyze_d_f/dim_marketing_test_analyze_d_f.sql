-- name dim_marketing_test_analyze_d_f
-- type SparkSQL
-- author yemengdan@12301.cc
-- create time 2020-12-18 11:55:56
-- desc 

CREATE table if not EXISTS dim_marketing_test_analyze_d_f(
    type                               string COMMENT '考试类型',
    `date`                             string COMMENT '考试日期',
    test_name                          string COMMENT '考试名称',
    staff_name                         string COMMENT '考试人员',
    score                              string COMMENT '分数',
    score_no                           string COMMENT '分数排名',
    remark                             string COMMENT '备注'
)COMMENT "市场部考试成绩表" PARTITIONED  BY (
    pt INT   
) stored as orc;

INSERT OVERWRITE TABLE dim_marketing_test_analyze_d_f PARTITION (pt="${ds}")
SELECT    
        type,
        `date`,
        test_name,
        ts.name    as staff_name,
        score,
        row_number() OVER (partition by `date`,test_name order by score desc) as score_no,
        ts.remark
FROM ods_marketing_test_score_d_f as ts
JOIN ods_marketing_test_d_f as t ON ts.test_name=t.name and t.pt='${ds}'
where ts.pt='${ds}'