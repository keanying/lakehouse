
-- name dim_contract_d_f
-- type SparkSQL
-- author linnong@12301.cc
-- create time 2020-12-21 15:52:51
-- desc 项目部合同
-- DROP TABLE dim_contract_d_f

-- alter table dim_contract_d_f add columns(project_manage              string comment '移交项目管理？ null/项管部');

create table if not EXISTS dim_contract_d_f(
    id                                      STRING COMMENT 'id',
    contract_no                             string COMMENT '合同编号',
    contract_name                           string COMMENT '合同名称',
    contrac_type                            string comment '合同类型',
    land_name                               string COMMENT '景区名称',
    project_name                            string comment '项目名称',
    part_A_name                             string COMMENT '甲方名称',
    cooperate_type                          string COMMENT '合作类型',
    is_new_renewal                          string COMMENT '新增/续费',
    project_period                          string COMMENT '项目周期(年)',
    
    province                                STRING COMMENT '省',
    city                                    STRING COMMENT '市',
    bid_win_time                            STRING COMMENT '中标时间',
    cor_type                                STRING COMMENT '合作类型',
    business_type                           STRING COMMENT '业务类型',
    third_party_money                       STRING COMMENT '第三方出资', 
    mt                                      STRING COMMENT '美团', 

    contract_amount                         int comment '合同总价(分)',
    pre_pay_amount                          int comment '预付款(分)',
    pre_pay_pay_period                      int comment '预付款(分)支付工作日',
    dev_arrival_amount                      int comment '到货款(分)',
    dev_arrival_pay_period                  int comment '到货款(分)支付工作日',
    check_and_accept_amount                 int comment '验收款(分)',
    check_and_accept_pay_period             int comment '验收款(分)支付工作日',
    warranty_amount                         int comment '质保金(分)',
    warranty_amount_start_offset            string comment '质保金支付开始日期：签订日/到货日/验收日',
    warranty_start_offset                   string comment '质保开始日期：签订日/到货日/验收日',
    warranty_period                         string COMMENT '质保期（年）',
    warranty_start_date                     string comment '质保开始日期',
    warranty_end_date                       string comment '质保结束日期',
    maintenance_amount_appoint              int comment '约定维保款，不含在合同内',
    maintenance_amount                      int comment '维保款(分)',
    maintenance_period                      int comment '维保期（年）',
    maintenance_start_date                  string comment '维保开始日期',
    maintenance_end_date                    string comment '维保结束日期',

    software_amount                         int comment '软件金额(分)',
    device_amount                           int comment '硬件金额(分)',
    fix_train_amount                        int comment '安装培训费(分)',
    freight_amount                          int comment '运费(分)',

    pre_pay_percent                          int comment '预付款比例',
    dev_arrival_percent                      int comment '到货款比例',
    check_and_accept_percent                 int comment '验收款比例',
    warranty_percent                         int comment '质保金比例',
    maintenance_percent                      int comment '维保款比例',


    achievements_divide                     int     comment '业绩划分',
    apply_sub_department                    string  comment '销售人员子部门名称',
    apply_sub_department_id                 int     comment '销售人员子部门id',
    apply_department                        string  comment '销售人员部门名称',
    applier                                 string  comment '销售人员',
    applier_id                              int     comment '销售人员id',

    create_time                             string comment '创建时间',
    sign_date                               string comment '签约日期',
    begin_time                              string comment '合同开始日期',
    end_time                                string comment '合同结束日期',

    user_id                                 string comment '商户id',
    package_name                            string comment '套餐名称',
    user_name                               string comment '账号名称',
    user_company_name                       string comment '企业名称',
    project_manage                          string comment '移交项目管理？ null/项管部',
    project_status                          string comment 'OA合同台账中历史项目阶段'

)COMMENT '合同' PARTITIONED by(
    pt INT
) stored as orc;


-- 一个合同编号可能多条数据，取时间最近的一条
INSERT OVERWRITE table dim_contract_d_f PARTITION (pt='${ds}')
select    --/*+mapjoin(d,d1)*/
   c1.id                    as id,
   c1.htbh                  as contract_no,
   c1.htmc                  as contract_name,
   case c1.htlx 
        when 0 then '平台合同'
        when 1 then '项目合同'   
        when 2 then '项目新签' 
        when 3 then '平台增补' 
        when 4 then '平台新签' 
        when 5 then '设备增补' 
        when 6 then '平台续费'  
   end                      as contrac_type,
   c1.jqmc                  as land_name,
   c1.xmmc                  as project_name,
   c1.jfmc                  as part_A_name,
   c1.hzlx                  as cooperate_type,
   c1.xqxf                  as is_new_renewal,
   case
      when c1.xmzq='一年'                       then 1
      when c1.xmzq like '%三年'                 then 3
      when c1.xmzq like '%年'                   then substr(c1.xmzq,1,locate('年',c1.xmzq)-1)
      when c1.xmzq like '%天' or c1.xmzq like '%日' or c1.xmzq='' or c1.xmzq is null                  then 0
      when c1.xmzq like '%-%'                   then substr(c1.xmzq,locate('-',c1.xmzq)+1,4)-substr(c1.xmzq,1,4)
      when c1.xmzq<=5                           then c1.xmzq
      else  0
   end                          as project_period,

   	pr.provincename             AS province,
	city.cityname               AS city,
	c1.zbsj                     AS bid_win_time,
    CASE	c1.hzlx 
	    WHEN 0 THEN	'项目激活' 
	    WHEN 1 THEN	'项目增补' 
	    WHEN 2 THEN	'平台激活' 
	    WHEN 3 THEN	'平台续费' 
	    WHEN 4 THEN	'项目维保' 
	END AS cor_type,
    CASE  c1.ywlx 
	    WHEN 3 THEN	'直销' 
	    WHEN 5 THEN	'第三方出资' 
	    WHEN 6 THEN	'集成商' 
	    WHEN 7 THEN	'服务商' 
	END AS business_type,
    CASE	c1.dsfcz 
	    WHEN 0 THEN	'美团' 
	    WHEN 1 THEN	'携程' 
	    WHEN 2 THEN	'其他OTA' 
	    WHEN 3 THEN	'银行' 
	    WHEN 4 THEN	'运营商' 
	    WHEN 5 THEN	'旅行社' 
	END AS third_party_money,
    CASE	c1.mt 
	    WHEN 0 THEN	'美团指定' 
	    WHEN 1 THEN	'美团招标' 
	END AS mt,
   
   coalesce(c1.htbddsbzj*100,0)              as contract_amount,
   coalesce(c1.yfk*100,0)                    as pre_pay_amount,
   coalesce(c1.htsxhdstfk,0)                 as pre_pay_pay_period,
   coalesce(c1.dhk*100,0)                    as dev_arrival_amount,
   coalesce(c1.dhdstfk,0)                    as dev_arrival_pay_period,
   coalesce(c1.ysk*100,0)                    as check_and_accept_amount,
   coalesce(c1.ysdstfk,0)                    as check_and_accept_pay_period,
   coalesce(c1.zbj*100,0)                    as warranty_amount,
   case c1.zbqqjfs
       when 0  then '签订日'
       when 1  then '到货日'
       when 2  then '验收日'
   end                                      as  warranty_amount_start_offset,
   case c1.zbqqjfs
       when 0  then '签订日'
       when 1  then '到货日'
       when 2  then '验收日'
   end                                      as warranty_start_offset,
   coalesce(c1.zbqn,0)                                                                       as warranty_period,
   if(c1.zbqssj is not null,c1.zbqssj,if(c1.zbqqjfs=0,c1.qyrq,null))                         as warranty_start_date,
   if(c1.zbdqsj is not null,c1.zbdqsj,if(c1.zbqqjfs=0,date_add(c1.qyrq,INT(c1.zbqn*365)),null))   as warranty_end_date,

   coalesce(c1.wbf*100,0)                                            as maintenance_amount_appoint,
   if(c1.hthwb=0,coalesce(c1.wbf*100,0),0)                           as maintenance_amount,
   coalesce(c1.wbqn,0)                                               as maintenance_period,
   if(c1.wbqn>0 and c1.wbfyfsj is not null,c1.wbfyfsj,null)          as maintenance_start_date,
   if(c1.wbqn>0 and c1.wbdqsj is not null,c1.wbdqsj,null)            as maintenance_end_date,

   coalesce(if(f233.yjsj is null,c1.rjje,f233.yjsj)*100,0)           as software_amount,
   coalesce(if(f233.rjsj is null,c1.yjje,f233.rjsj)*100,0)           as device_amount,
   coalesce(c1.azdsxtpxf*100,0)                                      AS fix_train_amount,
   coalesce(if(f233.yssj is null,c1.ysfbj,f233.yssj)*100,0)          AS freight_amount,

   c1.yfkbl                                                          as pre_pay_percent,
   c1.dhkbl                                                          as dev_arrival_percent,
   c1.yskbl                                                          as check_and_accept_percent,
   c1.zbjbl                                                          as warranty_percent,
   c1.wbfbl                                                          as maintenance_percent,
   
   c1.yjhf                                                           as achievements_divide,
   st.team                                                           as apply_sub_department,
   INT(st.team_id)                                                   as apply_sub_department_id,
   st.departmentname                                                 as apply_department,
   st.name                                                           as applier,
   INT(st.staff_id)                                                  as applier_id,

   c1.modedatacreatedate                                             as create_time,
   if(c1.qyrq is not null,c1.qyrq,c1.modedatacreatedate)             as sign_date,
   c1.hzksrq                                                         as begin_time,
   c1.hzjzrq                                                         as end_time,

   if(u.user_id is null,if(u1.user_id is null,u2.user_id,u1.user_id) ,u.user_id)                          as user_id,
   p.package_name                                                      as package_name,
   if(u.user_id is null,if(u1.user_name is null,u2.user_name,u1.user_name) ,u.user_name)                      as user_name,
   if(u.user_id is null,if(u1.user_company_name is null,u2.user_company_name,u1.user_company_name),u.user_company_name)      as user_company_name,
   if(f.contract_no is not null,'项管部',null)                          as project_manage,
   case  c1.htzt
      when 0  then '预付'
      when 1  then '到货'
      when 2  then '验收'
      when 3  then '质保'
      when 4  then '维保'
      when 5  then '票抵款'
      when 6  then '未结清'
      when 7  then '完结'
   end                                                                as project_status

from (     
          select htbh,max(id)id
          from ods_oa_uf_httzbd_d_f 
          where pt='${ds}' 
          and htbddsbzj>0 and htbh<>'' and length(htbh)>6
          group by htbh
	 ) c
left join ods_oa_uf_httzbd_d_f c1 on  c1.pt='${ds}' and  c1.id=c.id
-- 合同报价流程，获取软件售价、硬件售价、运输售价
left join ods_oa_formtable_main_233_d_f  f233  on    f233.pt='${ds}' and  f233.requestid=c1.glbjsp
--人员及部门
LEFT JOIN dwd_staff_basic_d_f as st on if(c1.xsry is null,c1.sqr,c1.xsry)=st.staff_id and st.pt='${ds}'
LEFT JOIN dwd_user_package_d_f as p on c1.htbh=p.contract_no and p.pt='${ds}'
LEFT JOIN dim_user_d_f u on  u.pt='${ds}' and  p.user_id=u.user_id 
-- 合同交接流程获取账号/手机号
left join (
    select d.contract_no,f194.pftzh from ods_oa_formatable_main_194_d_f f194
    LEFT JOIN dim_contract_id_d_f d on d.pt='${ds}' and d.id=f194.htbh
    where f194.pt='${ds}' and isnotnull(f194.pftzh) and not(f194.pftzh like '%暂%') and f194.pftzh<>'' and isnotnull(d.contract_no)
    )  f on f.contract_no=c.htbh
LEFT JOIN dim_user_d_f u1 ON  u1.pt='${ds}'  and f.pftzh=u1.user_account
LEFT JOIN dim_user_d_f u2 ON  u2.pt='${ds}'  and f.pftzh=u2.customer_mobile
left join ods_oa_hrmcity_d_f city on city.id=c1.ds and city.pt='${ds}'
left join ods_oa_hrmprovince_d_f pr on pr.id=c1.s and pr.pt='${ds}'
;













-- -- name dim_contract_d_f
-- -- type SparkSQL
-- -- author linnong@12301.cc
-- -- create time 2020-12-21 15:52:51
-- -- desc 项目部合同
-- -- DROP TABLE dim_contract_d_f

-- -- alter table dim_contract_d_f add columns(project_manage              string comment '移交项目管理？ null/项管部');

-- create table if not EXISTS dim_contract_d_f(
--     id                                      STRING COMMENT 'id',
--     contract_no                             string COMMENT '合同编号',
--     contract_name                           string COMMENT '合同名称',
--     contrac_type                            string comment '合同类型',
--     land_name                               string COMMENT '景区名称',
--     project_name                            string comment '项目名称',
--     part_A_name                             string COMMENT '甲方名称',
--     cooperate_type                          string COMMENT '合作类型',
--     is_new_renewal                          string COMMENT '新增/续费',
--     project_period                          string COMMENT '项目周期(年)',
    
--     province                                STRING COMMENT '省',
--     city                                    STRING COMMENT '市',
--     bid_win_time                            STRING COMMENT '中标时间',
--     cor_type                                STRING COMMENT '合作类型',
--     business_type                           STRING COMMENT '业务类型',
--     third_party_money                       STRING COMMENT '第三方出资', 
--     mt                                      STRING COMMENT '美团', 

--     contract_amount                         int comment '合同总价(分)',
--     pre_pay_amount                          int comment '预付款(分)',
--     pre_pay_pay_period                      int comment '预付款(分)支付工作日',
--     dev_arrival_amount                      int comment '到货款(分)',
--     dev_arrival_pay_period                  int comment '到货款(分)支付工作日',
--     check_and_accept_amount                 int comment '验收款(分)',
--     check_and_accept_pay_period             int comment '验收款(分)支付工作日',
--     warranty_amount                         int comment '质保金(分)',
--     warranty_amount_start_offset            string comment '质保金支付开始日期：签订日/到货日/验收日',
--     warranty_start_offset                   string comment '质保开始日期：签订日/到货日/验收日',
--     warranty_period                         string COMMENT '质保期（年）',
--     warranty_start_date                     string comment '质保开始日期',
--     warranty_end_date                       string comment '质保结束日期',
--     maintenance_amount_appoint              int comment '约定维保款，不含在合同内',
--     maintenance_amount                      int comment '维保款(分)',
--     maintenance_period                      int comment '维保期（年）',
--     maintenance_start_date                  string comment '维保开始日期',
--     maintenance_end_date                    string comment '维保结束日期',

--     software_amount                         int comment '软件金额(分)',
--     device_amount                           int comment '硬件金额(分)',
--     fix_train_amount                        int comment '安装培训费(分)',
--     freight_amount                          int comment '运费(分)',

--     pre_pay_percent                          int comment '预付款比例',
--     dev_arrival_percent                      int comment '到货款比例',
--     check_and_accept_percent                 int comment '验收款比例',
--     warranty_percent                         int comment '质保金比例',
--     maintenance_percent                      int comment '维保款比例',


--     achievements_divide                     int     comment '业绩划分',
--     apply_sub_department                    string  comment '销售人员子部门名称',
--     apply_sub_department_id                 int     comment '销售人员子部门id',
--     apply_department                        string  comment '销售人员部门名称',
--     applier                                 string  comment '销售人员',
--     applier_id                              int     comment '销售人员id',

--     create_time                             string comment '创建时间',
--     sign_date                               string comment '签约日期',
--     begin_time                              string comment '合同开始日期',
--     end_time                                string comment '合同结束日期',

--     user_id                                 string comment '商户id',
--     package_name                            string comment '套餐名称',
--     user_name                               string comment '账号名称',
--     user_company_name                       string comment '企业名称',
--     project_manage                          string comment '移交项目管理？ null/项管部',
--     project_status                          string comment 'OA合同台账中历史项目阶段'

-- )COMMENT '合同' PARTITIONED by(
--     pt string
-- ) LIFECYCLE 7;


-- -- 一个合同编号可能多条数据，取时间最近的一条
-- INSERT OVERWRITE table dim_contract_d_f PARTITION (pt='${ds}')
-- select    /*+mapjoin(d,d1)*/
--    c1.id                    as id,
--    c1.htbh                  as contract_no,
--    c1.htmc                  as contract_name,
--    case c1.htlx 
--         when 0 then '平台合同'
--         when 1 then '项目合同'   
--         when 2 then '项目新签' 
--         when 3 then '平台增补' 
--         when 4 then '平台新签' 
--         when 5 then '设备增补' 
--         when 6 then '平台续费'  
--    end                      as contrac_type,
--    c1.jqmc                  as land_name,
--    c1.xmmc                  as project_name,
--    c1.jfmc                  as part_A_name,
--    c1.hzlx                  as cooperate_type,
--    c1.xqxf                  as is_new_renewal,
--    case
--       when c1.xmzq='一年'                       then 1
--       when c1.xmzq like '%三年'                 then 3
--       when c1.xmzq like '%年'                   then substr(c1.xmzq,1,locate('年',c1.xmzq)-1)
--       when c1.xmzq like '%天' or c1.xmzq like '%日' or c1.xmzq='' or c1.xmzq is null                  then 0
--       when c1.xmzq like '%-%'                   then substr(c1.xmzq,locate('-',c1.xmzq)+1,4)-substr(c1.xmzq,1,4)
--       when c1.xmzq<=5                           then c1.xmzq
--       else  0
--    end                          as project_period,

--    	pr.provincename             AS province,
-- 	city.cityname               AS city,
-- 	c1.zbsj                     AS bid_win_time,
--     CASE	c1.hzlx 
-- 	    WHEN 0 THEN	'项目激活' 
-- 	    WHEN 1 THEN	'项目增补' 
-- 	    WHEN 2 THEN	'平台激活' 
-- 	    WHEN 3 THEN	'平台续费' 
-- 	    WHEN 4 THEN	'项目维保' 
-- 	END AS cor_type,
--     CASE  c1.ywlx 
-- 	    WHEN 3 THEN	'直销' 
-- 	    WHEN 5 THEN	'第三方出资' 
-- 	    WHEN 6 THEN	'集成商' 
-- 	    WHEN 7 THEN	'服务商' 
-- 	END AS business_type,
--     CASE	c1.dsfcz 
-- 	    WHEN 0 THEN	'美团' 
-- 	    WHEN 1 THEN	'携程' 
-- 	    WHEN 2 THEN	'其他OTA' 
-- 	    WHEN 3 THEN	'银行' 
-- 	    WHEN 4 THEN	'运营商' 
-- 	    WHEN 5 THEN	'旅行社' 
-- 	END AS third_party_money,
--     CASE	c1.mt 
-- 	    WHEN 0 THEN	'美团指定' 
-- 	    WHEN 1 THEN	'美团招标' 
-- 	END AS mt,
   
--    coalesce(c1.htbddsbzj*100,0)              as contract_amount,
--    coalesce(c1.yfk*100,0)                    as pre_pay_amount,
--    coalesce(c1.htsxhdstfk,0)                 as pre_pay_pay_period,
--    coalesce(c1.dhk*100,0)                    as dev_arrival_amount,
--    coalesce(c1.dhdstfk,0)                    as dev_arrival_pay_period,
--    coalesce(c1.ysk*100,0)                    as check_and_accept_amount,
--    coalesce(c1.ysdstfk,0)                    as check_and_accept_pay_period,
--    coalesce(c1.zbj*100,0)                    as warranty_amount,
--    case c1.zbqqjfs
--        when 0  then '签订日'
--        when 1  then '到货日'
--        when 2  then '验收日'
--    end                                      as  warranty_amount_start_offset,
--    case c1.zbqqjfs
--        when 0  then '签订日'
--        when 1  then '到货日'
--        when 2  then '验收日'
--    end                                      as warranty_start_offset,
-- --    case                    
-- --       when  c1.bxq like '%一年%' or c1.bxq like '%1年%' or c1.bxq in ('360','12.00','123')   then 1
-- --       when  c1.bxq like '%两年%' or c1.bxq like '%贰年%' or c1.bxq in ('24个月','18.00')   then 2
-- --       when  c1.bxq like '%三年%' or c1.bxq like '%3年%' or  c1.bxq in ('1095')  then 3
-- --       when  c1.bxq like '%五年%'                          then 5
-- --       when  c1.bxq like '%年'                            then substr(c1.bxq,1,locate('年',c1.bxq)-1)
-- --       when  c1.bxq like '%.%'                             then substr(c1.bxq,1,locate('.',c1.bxq)-1)
-- --       when  c1.bxq=0 or c1.bxq like '%天'                 then 0     
-- --       when  c1.bxq='' or  c1.bxq is null                  then 1     -- 默认质保1年
-- --       else c1.bxq
-- --    end                      as warranty_period,
--    coalesce(c1.zbqn,0)                                                                       as warranty_period,
--    if(c1.zbqssj is not null,c1.zbqssj,if(c1.zbqqjfs=0,c1.qyrq,null))                         as warranty_start_date,
--    if(c1.zbdqsj is not null,c1.zbdqsj,if(c1.zbqqjfs=0,date_add(c1.qyrq,c1.zbqn*365),null))   as warranty_end_date,

--    coalesce(c1.wbf*100,0)                                            as maintenance_amount_appoint,
--    if(c1.hthwb=0,coalesce(c1.wbf*100,0),0)                           as maintenance_amount,
--    coalesce(c1.wbqn,0)                                               as maintenance_period,
--    if(c1.wbqn>0 and c1.wbfyfsj is not null,c1.wbfyfsj,null)          as maintenance_start_date,
--    if(c1.wbqn>0 and c1.wbdqsj is not null,c1.wbdqsj,null)            as maintenance_end_date,

--    coalesce(if(f233.yjsj is null,c1.rjje,f233.yjsj)*100,0)           as software_amount,
--    coalesce(if(f233.rjsj is null,c1.yjje,f233.rjsj)*100,0)           as device_amount,
--    coalesce(c1.azdsxtpxf*100,0)                                      AS fix_train_amount,
--    coalesce(if(f233.yssj is null,c1.ysfbj,f233.yssj)*100,0)          AS freight_amount,

--    c1.yfkbl                                                          as pre_pay_percent,
--    c1.dhkbl                                                          as dev_arrival_percent,
--    c1.yskbl                                                          as check_and_accept_percent,
--    c1.zbjbl                                                          as warranty_percent,
--    c1.wbfbl                                                          as maintenance_percent,
   
--    c1.yjhf                                                           as achievements_divide,
--    st.team                                                           as apply_sub_department,
--    st.team_id                                                        as apply_sub_department_id,
--    st.departmentname                                                 as apply_department,
--    st.name                                                           as applier,
--    st.staff_id                                                       as applier_id,

--    c1.modedatacreatedate                                             as create_time,
--    if(c1.qyrq is not null,c1.qyrq,c1.modedatacreatedate)             as sign_date,
--    c1.hzksrq                                                         as begin_time,
--    c1.hzjzrq                                                         as end_time,

--    if(u.user_id is null,u1.user_id,u.user_id)                          as user_id,
--    p.package_name                                                      as package_name,
--    if(u.user_id is null,u1.user_name,u.user_name)                      as user_name,
--    if(u.user_id is null,u1.user_company_name,u.user_company_name)      as user_company_name,
--    if(f.contract_no is not null,'项管部',null)                          as project_manage,
--    case  c1.htzt
--       when 0  then '预付'
--       when 1  then '到货'
--       when 2  then '验收'
--       when 3  then '质保'
--       when 4  then '维保'
--       when 5  then '票抵款'
--       when 6  then '未结清'
--       when 7  then '完结'
--    end                                                                as project_status

-- from (select c0.htbh,max(c0.id) id
-- 	  from (select htbh,id from s_oa_uf_httzbd_d_f where pt='${ds}' and htbddsbzj>0 and htbh<>'' and length(htbh)>6) c0
-- 	  group by c0.htbh
-- 	 ) c
-- left join (select * from s_oa_uf_httzbd_d_f where pt='${ds}' )  c1 on c1.id=c.id
-- -- 合同报价流程，获取软件售价、硬件售价、运输售价
-- left join (select * from s_oa_formtable_main_233_d_f where pt='${ds}' )  f233 on f233.requestid=c1.glbjsp
-- --人员及部门
-- LEFT JOIN dwd_staff_basic_d_f as st on if(c1.xsry is null,c1.sqr,c1.xsry)=st.staff_id and st.pt='${ds}'
-- -- LEFT JOIN dim_oa_department_d_f as dp on c1.sqbm=dp.lv2_team_id and dp.pt='${ds}'
-- LEFT JOIN dwd_user_package_d_f as p on c1.htbh=p.contract_no and p.pt='${ds}'
-- LEFT JOIN (select user_id,user_name,user_company_name from dim_user_d_f where pt='${ds}')  u on p.user_id=u.user_id 
-- -- 合同交接流程获取账号/手机号
-- left join (select d.contract_no,f194.pftzh from s_oa_formatable_main_194_d_f f194
--            LEFT JOIN dim_contract_id_d_f d on d.pt='${ds}' and d.id=f194.htbh
--            where f194.pt='${ds}' and isnotnull(f194.pftzh) and not(f194.pftzh like '%暂%') and f194.pftzh<>'' and isnotnull(d.contract_no))  f on f.contract_no=c.htbh
-- LEFT JOIN (select user_id,user_name,user_company_name,user_account,customer_mobile from  dim_user_d_f where pt='${ds}') as u1 on (f.pftzh=u1.user_account or f.pftzh=u1.customer_mobile) 
-- left join s_oa_hrmcity_d_f city on city.id=c1.ds and city.pt='${ds}'
-- left join s_oa_hrmprovince_d_f pr on pr.id=c1.s and pr.pt='${ds}'
-- ;

-- -- select *
-- -- from dwd_staff_basic_d_f where pt='${ds}' and staff_id=30
-- -- ;
-- -- select htbh,id,sqr,xsry from s_oa_uf_httzbd_d_f where pt='${ds}' and htbddsbzj>0 and htbh<>'' and length(htbh)>6
-- --        AND  htbh='PFT20181022'
-- -- ;
-- -- select contract_no,part_A_name,province,city,applier,applier_id,apply_department
-- -- from dim_contract_d_f where pt='${ds}' AND  contract_no='PFT2018040041'

-- -- select contract_no,contract_amount,pre_pay_amount,dev_arrival_amount,
-- --     check_and_accept_amount,
-- --     warranty_amount,
-- --     maintenance_amount
-- -- from  dim_contract_d_f where pt='${ds}' and contract_no='D-PFT-CP-201801'
-- -- having contract_amount<>pre_pay_amount+dev_arrival_amount+    check_and_accept_amount+    warranty_amount+    maintenance_amount  and apply_department='文旅事业部'