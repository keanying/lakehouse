-- name dim_oa_department_d_f
-- type SparkSQL
-- author yemengdan@12301.cc
-- create time 2020-12-22 11:16:33
-- desc 
-- DROP TABLE dim_oa_department_d_f


CREATE TABLE if NOT EXISTS dim_oa_department_d_f(
    departmentname_id                       STRING COMMENT "部门id",
    departmentname                          STRING COMMENT "部门名称",
    lv1_team_id                             STRING COMMENT "一级组id",
    lv1_team                                STRING COMMENT "一级组名称",
    lv2_team_id                             STRING COMMENT "二级组id",
    lv2_team                                STRING COMMENT "二级组名称",
    lv3_team_id                             STRING COMMENT "三级组id",
    lv3_team                                STRING COMMENT "三级组名称",
    full_dep_name                           STRING COMMENT "部门全称",
    is_canceled                             STRING COMMENT "是否取消",
    amb_level1                              string COMMENT "阿米巴一级标签",
    amb_level2                              string COMMENT "阿米巴二级标签",
    amb_level3                              string COMMENT "阿米巴三级标签"
)COMMENT "部门基本表" PARTITIONED by(
    pt INT 
) stored as orc;

INSERT OVERWRITE table dim_oa_department_d_f PARTITION (pt="${ds}")
SELECT 
        case when hd1.SUPDEPID=0 then hd1.id
        when hd2.SUPDEPID=0 then hd2.id
        when hd3.SUPDEPID=0 then hd3.id
        else hd4.id end departmentname_id,
        case when hd1.SUPDEPID=0 then hd1.DEPARTMENTNAME
        when hd2.SUPDEPID=0 then hd2.DEPARTMENTNAME
        when hd3.SUPDEPID=0 then hd3.DEPARTMENTNAME
        else hd4.DEPARTMENTNAME end departmentname,
        -- 如果没有二级组，则为一级部门
        case when hd1.SUPDEPID=0 then hd1.id
        when hd2.SUPDEPID=0 then hd1.id
        when hd3.SUPDEPID=0 then hd2.id
        else hd3.id end lv1_team_id,
        case when hd1.SUPDEPID=0 then hd1.DEPARTMENTNAME
        when hd2.SUPDEPID=0 then hd1.DEPARTMENTNAME
        when hd3.SUPDEPID=0 then hd2.DEPARTMENTNAME
        else hd3.DEPARTMENTNAME end lv1_team,
        -- 如果没有三级组，则为二级组
        case when hd1.SUPDEPID=0 then hd1.id
        when hd2.SUPDEPID=0 then hd1.id
        when hd3.SUPDEPID=0 then hd1.id
        else hd2.id end lv2_team_id,
        case when hd1.SUPDEPID=0 then hd1.DEPARTMENTNAME
        when hd2.SUPDEPID=0 then hd1.DEPARTMENTNAME
        when hd3.SUPDEPID=0 then hd1.DEPARTMENTNAME
        else hd2.DEPARTMENTNAME end lv2_team,

        hd1.id as lv3_team_id,
        hd1.DEPARTMENTNAME as lv3_team,

        case when hd1.SUPDEPID=0 then hd1.DEPARTMENTNAME
        when hd2.SUPDEPID=0 then concat(hd2.DEPARTMENTNAME,'>',hd1.DEPARTMENTNAME)
        when hd3.SUPDEPID=0 then concat(hd3.DEPARTMENTNAME,'>',hd2.DEPARTMENTNAME,'>',hd1.DEPARTMENTNAME)
        when hd4.SUPDEPID=0 then concat(hd4.DEPARTMENTNAME,'>',hd3.DEPARTMENTNAME,'>',hd2.DEPARTMENTNAME,'>',hd1.DEPARTMENTNAME) end full_dep_name,

        if(hd1.canceled=1,'是','否') as is_canceled,
    -- 阿米巴标签 暂时手工 后面杨猷翔确定维表来源从表关联       
        if(yjbq=0,'二级巴',null) amb_level1,
        case de.ejbq when 0 then '费用巴' 
        when 1 then '发展巴'
        when 2 then '利润巴（平台）'
        when 3 then '利润巴（文旅）'
        when 4 then '利润巴（运营）'
        end amb_level2,
        case de.sjbq when 0 then '费用中心' 
        when 1 then '发展中心'
        when 2 then '利润中心'
        end  amb_level3
FROM ods_oa_hrmdepartment_d_f as hd1
left join ods_oa_hrmdepartment_d_f as hd2 on hd1.SUPDEPID=hd2.id and hd2.pt='${ds}'
left join ods_oa_hrmdepartment_d_f as hd3 on hd2.SUPDEPID=hd3.id and hd3.pt='${ds}'
left join ods_oa_hrmdepartment_d_f as hd4 on hd3.SUPDEPID=hd4.id and hd4.pt='${ds}'
left join ods_oa_hrmdepartmentdefined_d_f de on hd1.id=de.deptid and de.pt='${ds}'
WHERE hd1.pt='${ds}';


