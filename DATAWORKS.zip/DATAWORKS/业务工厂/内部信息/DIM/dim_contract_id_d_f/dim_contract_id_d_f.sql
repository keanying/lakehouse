-- 调度状态:启用
-- name dim_contract_id_d_f
-- type SparkSQL
-- author linnong@12301.cc
-- create time 2021-02-03 09:37:04
-- desc OA合同台账流程编码表

create table if not EXISTS dim_contract_id_d_f(
    id                                      STRING COMMENT 'id',
    contract_no                             string COMMENT '合同编号'

)COMMENT '合同流程编码' PARTITIONED by(
    pt int
) stored as orc;


-- 过滤合同编号为空，不正确的
INSERT OVERWRITE table dim_contract_id_d_f PARTITION (pt='${ds}')
select    
   id                    as id,
   htbh                  as contract_no

from ods_oa_uf_httzbd_d_f 
where pt='${ds}'  and  isnotnull(htbh) and length(htbh)>4
;