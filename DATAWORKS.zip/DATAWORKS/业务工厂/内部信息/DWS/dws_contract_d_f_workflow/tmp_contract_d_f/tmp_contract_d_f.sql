-- name tmp_contract_d_f
-- type SparkSQL
-- author linnong@12301.cc
-- create time 2021-02-02 17:23:11
-- desc 合同中间表
-- DROP TABLE tmp_contract_d_f

create table if not EXISTS tmp_contract_d_f(
    id                                      STRING COMMENT 'id',
    contract_no                             string COMMENT '合同编号',
    contract_name                           string COMMENT '合同名称',
    contrac_type                            string comment '合同类型',
    land_name                               string COMMENT '景区名称',
    project_name                            string comment '项目名称',
    part_A_name                             string COMMENT '甲方名称',
    cooperate_type                          string COMMENT '合作类型',
    is_new_renewal                          string COMMENT '新增/续费',
    project_period                          string COMMENT '项目施工周期',
    
    province                                STRING COMMENT '省',
    city                                    STRING COMMENT '市',
    bid_win_time                            STRING COMMENT '中标时间',
    cor_type                                STRING COMMENT '合作类型',
    business_type                           STRING COMMENT '业务类型',
    third_party_money                       STRING COMMENT '第三方出资', 
    mt                                      STRING COMMENT '美团', 

    create_time                             string comment '创建时间',
    sign_date                               string comment '合同生效日期：第一次开票时间>签约日期>合同创建时间',
    begin_time                              string comment '合同开始日期',
    end_time                                string comment '合同结束日期',

    contract_amount                         int comment '合同总价(分)',
    pre_pay_amount                          int comment '预付款(分)',
    pre_pay_pay_period                      int comment '预付款(分)支付工作日',
    dev_arrival_amount                      int comment '到货款(分)',
    dev_arrival_pay_period                  int comment '到货款(分)支付工作日',
    check_and_accept_amount                 int comment '验收款(分)',
    check_and_accept_pay_period             int comment '验收款(分)支付工作日',
    warranty_amount                         int comment '质保金(分)',
    warranty_amount_start_offset            string comment '质保金支付开始日期：签订日/到货日/验收日',
    warranty_start_offset                   string comment '质保开始日期：签订日/到货日/验收日',
    warranty_period                         string COMMENT '质保期（年）',
    warranty_start_date                     string comment '质保开始日期',
    warranty_end_date                       string comment '质保结束日期',
    maintenance_amount_appoint              int comment '约定维保费（不在合同金额中）',
    maintenance_amount                      int comment '维保款(分)',
    maintenance_period                      int comment '维保期（年）',
    maintenance_start_date                  string comment '维保开始日期',
    maintenance_end_date                    string comment '维保结束日期',

    software_amount                         int comment '软件金额(分)',
    device_amount                           int comment '硬件金额(分)',
    fix_train_amount                        int comment '安装培训费(分)',
    freight_amount                          int comment '运费(分)',

    pre_pay_percent                         int comment '预付款比例',
    dev_arrival_percent                     int comment '到货款比例',
    check_and_accept_percent                int comment '验收款比例',
    warranty_percent                        int comment '质保金比例',
    maintenance_percent                     int comment '维保款比例',

    achievements_divide                     int    comment '业绩划分',
    apply_sub_department                    string comment '销售人员子部门名称',
    apply_sub_department_id                 int    comment '销售人员子部门id',
    apply_department                        string comment '销售人员部门名称',
    applier                                 string comment '销售人员',
    applier_id                              int    comment '销售人员id',


    user_id                                 string comment '商户id',
    package_name                            string comment '套餐名称',
    user_name                               string comment '账号名称',
    user_company_name                       string comment '企业名称',

    -- 开票情况
    billed_amount                           int comment '已开票金额(分)',
    pre_pay_billed                          int comment '预付款开票金额（分）',
    dev_arrival_billed                      int comment '到货款开票金额（分）',
    check_and_accept_billed                 int comment '验收款开票金额（分）',
    warranty_billed                         int comment '质保金开票金额（分）',
    maintenance_billed                      int comment '维保款开票金额（分）',

    software_billed                          int comment '软件开票金额（分）',
    device_billed                            int comment '硬件开票金额（分）',
    fix_train_billed                         int comment '安装培训开票金额（分）',
    maintenance_billed_actual                int comment '维保开票金额（分）',

    --回款情况
    pre_pay_finish_amount                   int    comment '已回预付款金额（分）',
    pre_pay_finish_date                     string comment '已回预付款日期',
    dev_arrival_finish_amount               int    comment '已回到货款金额（分）',
    dev_arrival_finish_date                 string comment '已回到货款日期',
    check_and_accept_finish_amount          int    comment '已回验收款金额（分）',
    check_and_accept_finish_date            string comment '已回验收款日期',
    warranty_finish_amount                  int    comment '已回质保款金额（分）',
    warranty_finish_date                    string comment '已回质保款日期',
    maintenance_finish_amount               int    comment '已回维保款金额（分）',
    maintenance_finish_date                 string comment '已回维保款日期',

    paid_amount                             int    comment '总回款金额(分)',
    not_paid_amount                         int    COMMENT '未回款金余额（分）=合同金额-总回款金额',

    -- 发货信息（设备申请）
    erp_no                                  string COMMENT 'ERP出入库单号',
    logistics_no                            string COMMENT '物流单号',
    by_post_date                            string comment '到货时间',
    -- 项目验收情况
    final_check_date                        string COMMENT '终验日期',
    final_check_no                          string COMMENT '验收编号',

    pre_pay_pay_end_date                    string comment '预付款截至支付日期',
    dev_arrival_pay_end_date                string comment '到货款截至支付日期',
    check_and_accept_pay_end_date           string comment '验收款截至支付日期',
    warranty_pay_end_date                   string comment '质保款截至支付日期',
    maintenance_pay_end_date                string comment '维保款截至支付日期',

    project_manage                          string comment '移交项目管理? null/项管部',
    project_status                          string comment 'OA合同台账项目状态'

)COMMENT '项目合同' PARTITIONED by(
    pt int
)STORED AS ORC;


-- 一个合同编号可能多条数据，取时间最近的一条
INSERT OVERWRITE table tmp_contract_d_f PARTITION (pt='${ds}')
select    /*+mapjoin(d,d1)*/
   c.id                           as id,
   c.contract_no                  as contract_no,
   c.contract_name                as contract_name,
   c.contrac_type                 as contrac_type,
   c.land_name                    as land_name,
   c.project_name                 as project_name,
   c.part_A_name                  as part_A_name,
   c.cooperate_type               as cooperate_type,
   c.is_new_renewal               as is_new_renewal,
   c.project_period               as project_period,

   c.province                     AS province,
   c.city                         AS city,
   c.bid_win_time                 AS bid_win_time,
   c.cor_type                     AS cor_type,
   c.business_type                AS business_type,
   c.third_party_money            AS third_party_money,
   c.mt                           AS mt,
   
   c.create_time                  as create_time,
   -- 合同生效日期：最小开票日期>签约日期> 合同流程创建日期
   if(b.bill_min_date is not null and b.bill_min_date>c.sign_date,b.bill_min_date,c.sign_date)                   as sign_date,
   c.begin_time                   as begin_time,
   c.end_time                     as end_time,

   coalesce(c.contract_amount,0)             as contract_amount,
   coalesce(c.pre_pay_amount,0)              as pre_pay_amount,
   coalesce(c.pre_pay_pay_period,0)           as pre_pay_pay_period,
   coalesce(c.dev_arrival_amount,0)          as dev_arrival_amount,
   coalesce(c.dev_arrival_pay_period,0)      as dev_arrival_pay_period,
   coalesce(c.check_and_accept_amount,0)     as check_and_accept_amount,
   coalesce(c.check_and_accept_pay_period,0) as check_and_accept_pay_period,
   coalesce(c.warranty_amount,0)             as warranty_amount,
   c.warranty_amount_start_offset            as  warranty_amount_start_offset,
   c.warranty_start_offset                   as warranty_start_offset,
   c.warranty_period                         as warranty_period,
   case
       when c.warranty_start_date is not null then c.warranty_start_date
       when c.warranty_start_offset='签订日'   then c.sign_date
       when c.warranty_start_offset='到货日'   then p.by_post_date
       when c.warranty_start_offset='验收日'   then ck.final_check_date
   end                                      as warranty_start_date,
   case
       when c.warranty_start_date is not null then  date_add(c.warranty_start_date,c.warranty_period*365)
       when c.warranty_start_offset='签订日'   then date_add(c.sign_date,c.warranty_period*365)
       when c.warranty_start_offset='到货日'   then date_add(p.by_post_date,c.warranty_period*365)
       when c.warranty_start_offset='验收日'   then date_add(ck.final_check_date,c.warranty_period*365)
   end                                      as warranty_end_date,
   
   c.maintenance_amount_appoint              as maintenance_amount_appoint,
   coalesce(c.maintenance_amount,0)          as maintenance_amount,
   c.maintenance_period                      as maintenance_period,
   --质保结束即开始维保，
   --无维保情况，维保结束日期=质保结束日期
   case
       when c.maintenance_period>0 and c.maintenance_start_date is not null then  c.maintenance_start_date
       when c.warranty_start_offset='签订日'  then date_add(c.sign_date,c.warranty_period*365+1) 
       when c.warranty_start_offset='到货日'  then date_add(p.by_post_date,c.warranty_period*365+1)
       when c.warranty_start_offset='验收日'  then date_add(ck.final_check_date,c.warranty_period*365+1)
   end                                      as maintenance_start_date,
   case
       when c.maintenance_period>0 and c.maintenance_start_date is not null then  c.maintenance_start_date
       when c.warranty_start_offset='签订日'  then date_add(c.sign_date,(c.warranty_period+c.maintenance_period)*365+1) 
       when c.warranty_start_offset='到货日'  then date_add(p.by_post_date,(c.warranty_period+c.maintenance_period)*365+1)
       when c.warranty_start_offset='验收日'  then date_add(ck.final_check_date,(c.warranty_period+c.maintenance_period)*365+1)
   end                                      as maintenance_end_date,

   coalesce(c.software_amount,0)             as software_amount,
   coalesce(c.device_amount,0)               as device_amount,
   coalesce(c.fix_train_amount,0)            AS fix_train_amount,
   coalesce(c.freight_amount,0)              AS freight_amount,

   coalesce(c.pre_pay_percent,0)             as pre_pay_percent,
   coalesce(c.dev_arrival_percent,0)         as dev_arrival_percent,
   coalesce(c.check_and_accept_percent,0)    as check_and_accept_percent,
   coalesce(c.warranty_percent,0)            as warranty_percent,
   coalesce(c.maintenance_percent,0)         as maintenance_percent,
   
   c.achievements_divide                     as achievements_divide,
   c.apply_sub_department                    as apply_sub_department,
   c.apply_sub_department_id                 as apply_sub_department_id,
   c.apply_department                        as apply_department,
   c.applier                                 as applier,
   c.applier_id                              as applier_id,

   c.user_id                                 as user_id,
   c.package_name                            as package_name,
   c.user_name                               as user_name,
   c.user_company_name                       as user_company_name,

   -- 开票情况
    coalesce(b.total_bill,0)                     as billed_amount,
    coalesce(b.pre_pay_bill,0)                   as pre_pay_billed,
    coalesce(b.dev_arrival_bill,0)               as dev_arrival_billed,
    coalesce(b.check_and_accept_bill,0)          as check_and_accept_billed,
    coalesce(b.warranty_bill,0)                  as warranty_billed,
    coalesce(b.maintenance_bill,0)               as maintenance_billed,
    coalesce(b.bill_software_amount,0)           as software_billed,
    coalesce(b.bill_device_amount,0)             as device_billed,
    coalesce(b.bill_other_amount,0)              as fix_train_billed,
    coalesce(b.bill_maintenance_amount,0)        as maintenance_billed_actual,

   -- 回款情况
    coalesce(ba.pre_pay_back,0)                 as pre_pay_finish_amount,
    ba.pre_pay_back_date                        as pre_pay_finish_date,
    coalesce(ba.dev_arrival_back,0)             as dev_arrival_finish_amount,
    ba.dev_arrival_back_date                    as dev_arrival_finish_date,
    coalesce(ba.check_and_accept_back,0)        as check_and_accept_finish_amount,
    ba.check_and_accept_back_date               as check_and_accept_finish_date,
    coalesce(ba.warranty_back,0)                as warranty_finish_amount,
    ba.warranty_back_date                       as warranty_finish_date,
    coalesce(ba.maintenance_back,0)             as maintenance_finish_amount,
    ba.maintenance_back_date                    as maintenance_finish_date,

    coalesce(ba.total_back,0)                   as paid_amount,  
    coalesce(c.contract_amount,0)-coalesce(ba.total_back,0) as not_paid_amount, 
                   
    -- 发货信息
    p.erp_no                                    as erp_no,
    p.logistics_no                              as logistics_no,
    p.by_post_date                              as by_post_date,
    -- 项目验收情况
    ck.final_check_date                         as final_check_date,
    ck.final_check_no                           as final_check_no,

    -- 质保金、维保费都是在质保期结束支付
    date_add(if(b.bill_min_date is not null and b.bill_min_date>c.sign_date,b.bill_min_date,c.sign_date),c.pre_pay_pay_period*7/5+0.5)      as pre_pay_pay_end_date,
    if(p.by_post_date is not null,date_add(p.by_post_date,c.dev_arrival_pay_period*7/5+0.5) ,null)                                          as dev_arrival_pay_end_date,
    if(ck.final_check_date is not null,date_add(ck.final_check_date,c.check_and_accept_pay_period*7/5+0.5),null)                            as check_and_accept_pay_end_date,
    case
        when c.warranty_amount=0 then null
        when c.warranty_start_date is not null then  date_add(c.warranty_start_date,c.warranty_period*365)
        when c.warranty_start_offset='签订日'   then date_add(c.sign_date,c.warranty_period*365)
        when c.warranty_start_offset='到货日'   then date_add(p.by_post_date,c.warranty_period*365)
        when c.warranty_start_offset='验收日'   then date_add(ck.final_check_date,c.warranty_period*365)
    end                                      as warranty_pay_end_date,
    case
        when c.maintenance_amount=0 then null
        when c.warranty_start_date is not null then  date_add(c.warranty_start_date,c.warranty_period*365)
        when c.warranty_start_offset='签订日'   then date_add(c.sign_date,c.warranty_period*365)
        when c.warranty_start_offset='到货日'   then date_add(p.by_post_date,c.warranty_period*365)
        when c.warranty_start_offset='验收日'   then date_add(ck.final_check_date,c.warranty_period*365)
    end                                      as maintenance_pay_end_date,

    c.project_manage                         as project_manage,
    c.project_status                          as project_status

from (select * from dim_contract_d_f where pt='${ds}') C
-- 开票
left join (select * from dws_contract_bill_d_f where pt='${ds}') b on c.contract_no=b.contract_no
-- 回款
left join (select * from dws_contract_call_back_d_f where pt='${ds}') ba on c.contract_no=ba.contract_no
-- 发货
left join (select * from dws_contract_by_post_d_f where pt='${ds}') p on c.contract_no=p.contract_no
-- 验收
left join (select * from dws_contract_check_d_f where pt='${ds}') ck on c.contract_no=ck.contract_no
;


-- select contract_no,contract_amount,paid_amount,not_paid_amount
--     -- check_and_accept_amount,
--     -- warranty_amount,
--     -- maintenance_amount
-- from  tmp_contract_d_f where pt='${ds}' and contract_no='PFTBJ20191111001'