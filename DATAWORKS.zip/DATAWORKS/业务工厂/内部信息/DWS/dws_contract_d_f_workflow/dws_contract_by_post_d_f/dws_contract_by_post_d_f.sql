-- name dws_project_by_post_d_f
-- type SparkSQL
-- author linnong@12301.cc
-- create time 2021-02-02 17:22:11
-- desc 合同发货汇总

-- drop table if EXISTS dws_contract_by_post_d_f

CREATE table if not EXISTS dws_contract_by_post_d_f(
    contract_no                         STRING  COMMENT '合同编号',
    by_post_date                        STRING  COMMENT '最终发货日期',
    erp_no                              string COMMENT 'ERP出入库单号',
    logistics_no                        string COMMENT '物流单号'

)COMMENT "合同发货" PARTITIONED  BY (
    pt INT   
)STORED AS ORC;

INSERT OVERWRITE TABLE dws_contract_by_post_d_f PARTITION (pt="${ds}")
--OA 设备申请 
select contract_no,
       max(if(is_finished='是',by_post_date,null))              as by_post_date,
       concat_ws(',',collect_set(erp_no))                       as erp_no,
       concat_ws(',',collect_set(logistics_no))                 as logistics_no
from dwd_project_by_post_d_f a where pt='${ds}' 
group by contract_no
;
