-- name dws_contract_main
-- type SparkSQL
-- author linnong@12301.cc
-- create time 2021-02-02 17:23:11
-- desc 合同汇总
-- DROP TABLE dws_contract_d_f

-- alter table dws_contract_d_f add columns(need_pay_amount               bigint comment '需支付金额（分）');
-- alter table dws_contract_d_f add columns(project_manage                string comment '移交项目管理？ null/项管部');

create table if not EXISTS dws_contract_d_f(
    id                                      STRING COMMENT 'id',
    contract_no                             string COMMENT '合同编号',
    contract_name                           string COMMENT '合同名称',
    contrac_type                            string comment '合同类型',
    land_name                               string COMMENT '景区名称',
    project_name                            string comment '项目名称',
    part_A_name                             string COMMENT '甲方名称',
    cooperate_type                          string COMMENT '合作类型',
    is_new_renewal                          string COMMENT '新增/续费',
    project_period                          string COMMENT '项目施工周期',
    
    province                                STRING COMMENT '省',
    city                                    STRING COMMENT '市',
    bid_win_time                            STRING COMMENT '中标时间',
    cor_type                                STRING COMMENT '合作类型',
    business_type                           STRING COMMENT '业务类型',
    third_party_money                       STRING COMMENT '第三方出资', 
    mt                                      STRING COMMENT '美团', 

    create_time                             string comment '创建时间',
    sign_date                               string comment '合同生效日期：第一次开票时间>签约日期>合同创建时间',
    begin_time                              string comment '合同开始日期',
    end_time                                string comment '合同结束日期',

    contract_amount                         int comment '合同总价(分)',
    pre_pay_amount                          int comment '预付款(分)',
    pre_pay_pay_period                      int comment '预付款(分)支付工作日',
    dev_arrival_amount                      int comment '到货款(分)',
    dev_arrival_pay_period                  int comment '到货款(分)支付工作日',
    check_and_accept_amount                 int comment '验收款(分)',
    check_and_accept_pay_period             int comment '验收款(分)支付工作日',
    warranty_amount                         int comment '质保金(分)',
    warranty_amount_start_offset            string comment '质保金支付开始日期：签订日/到货日/验收日',
    warranty_start_offset                   string comment '质保开始日期：签订日/到货日/验收日',
    warranty_period                         string COMMENT '质保期（年）',
    warranty_start_date                     string comment '质保开始日期',
    warranty_end_date                       string comment '质保结束日期',
    maintenance_amount_appoint              int comment '合同是否包含维保款：是/否',
    maintenance_amount                      int comment '维保款(分)',
    maintenance_period                      int comment '维保期（年）',
    maintenance_start_date                  string comment '维保开始日期',
    maintenance_end_date                    string comment '维保结束日期',

    software_amount                         int comment '软件金额(分)',
    device_amount                           int comment '硬件金额(分)',
    fix_train_amount                        int comment '安装培训费(分)',
    freight_amount                          int comment '运费(分)',

    pre_pay_percent                         int comment '预付款比例',
    dev_arrival_percent                     int comment '到货款比例',
    check_and_accept_percent                int comment '验收款比例',
    warranty_percent                        int comment '质保金比例',
    maintenance_percent                     int comment '维保款比例',

    achievements_divide                     int    comment '业绩划分',
    apply_sub_department                    string comment '销售人员子部门名称',
    apply_sub_department_id                 int    comment '销售人员子部门id',
    apply_department                        string comment '销售人员部门名称',
    applier                                 string comment '销售人员',
    applier_id                              int    comment '销售人员id',


    user_id                                 string comment '商户id',
    package_name                            string comment '套餐名称',
    user_name                               string comment '账号名称',
    user_company_name                       string comment '企业名称',

    -- 开票情况
    billed_amount                           int comment '已开票金额(分)',
    pre_pay_billed                          int comment '预付款开票金额（分）',
    dev_arrival_billed                      int comment '到货款开票金额（分）',
    check_and_accept_billed                 int comment '验收款开票金额（分）',
    warranty_billed                         int comment '质保金开票金额（分）',
    maintenance_billed                      int comment '维保款开票金额（分）',

    software_billed                          int comment '软件开票金额（分）',
    device_billed                            int comment '硬件开票金额（分）',
    fix_train_billed                         int comment '安装培训开票金额（分）',
    maintenance_billed_actual                int comment '维保开票金额（分）',

    --回款情况
    pre_pay_finish_amount                   int    comment '已回预付款金额（分）',
    pre_pay_finish_date                     string comment '已回预付款日期',
    dev_arrival_finish_amount               int    comment '已回到货款金额（分）',
    dev_arrival_finish_date                 string comment '已回到货款日期',
    check_and_accept_finish_amount          int    comment '已回验收款金额（分）',
    check_and_accept_finish_date            string comment '已回验收款日期',
    warranty_finish_amount                  int    comment '已回质保款金额（分）',
    warranty_finish_date                    string comment '已回质保款日期',
    maintenance_finish_amount               int    comment '已回维保款金额（分）',
    maintenance_finish_date                 string comment '已回维保款日期',

    paid_amount                             int    comment '总回款金额(分)',
    not_paid_amount                         int    COMMENT '未回款金余额（分）=合同金额-总回款金额',

    -- 发货信息（设备申请）
    erp_no                                  string COMMENT 'ERP出入库单号',
    logistics_no                            string COMMENT '物流单号',
    by_post_date                            string comment '到货时间',
    -- 项目验收情况
    final_check_date                        string COMMENT '终验日期',
    final_check_no                          string COMMENT '验收编号',

    pre_pay_pay_end_date                    string comment '预付款截至支付日期',
    dev_arrival_pay_end_date                string comment '到货款截至支付日期',
    check_and_accept_pay_end_date           string comment '验收款截至支付日期',
    warranty_pay_end_date                   string comment '质保款截至支付日期',
    maintenance_pay_end_date                string comment '维保款截至支付日期',

    project_manage                          string comment '移交项目管理? null/项管部',
    project_status                          string comment 'OA合同台帐项目状态',
    
    ---项目阶段
    project_stage                           string COMMENT '项目阶段',
    project_stage_start_date                string COMMENT '项目阶段开始日期',

    not_payment_stage                       string COMMENT '待回款阶段',
    not_payment_end_date                    string COMMENT '待回款阶段结束日期',
    need_pay_amount                         bigint comment '需支付金额（分）',
    need_pay_amount_pre_pay                 bigint comment '需支付预付款（分）',
    need_pay_amount_dev_arrival             bigint comment '需支付到货款（分）',
    need_pay_amount_check_and_accept        bigint comment '需支付验收款（分）',
    need_pay_amount_warranty                bigint comment '需支付质保金（分）',
    need_pay_amount_maintenance             bigint comment '需支付维保款（分）',

    exceed_days                             int    comment '逾期天数',
    exceed_amount                           bigint comment '逾期金额（分）',

    exceed_amount_pre_pay                   bigint comment '预付款逾期金额（分）',
    exceed_days_pre_pay                     int    comment '预付款逾期天数',
    exceed_amount_dev_arrival               bigint comment '到货款逾期金额（分）',
    exceed_days_dev_arrival                 int    comment '到货款逾期天数',
    exceed_amount_check_and_accept          bigint comment '验收款逾期金额（分）',
    exceed_days_check_and_accept            int    comment '验收款逾期天数',
    exceed_amount_warranty                  bigint comment '质保款逾期金额（分）',
    exceed_days_warranty                    int    comment '质保款逾期天数',
    exceed_amount_maintenance               bigint comment '维保款逾期金额（分）',
    exceed_days_maintenance                 int    comment '维保款逾期天数'

)COMMENT '项目合同' PARTITIONED by(
    pt int
)STORED AS ORC;


-- 一个合同编号可能多条数据，取时间最近的一条
INSERT OVERWRITE table dws_contract_d_f PARTITION (pt='${ds}')
select    
   c.id                           as id,
   c.contract_no                  as contract_no,
   c.contract_name                as contract_name,
   c.contrac_type                 as contrac_type,
   c.land_name                    as land_name,
   c.project_name                 as project_name,
   c.part_A_name                  as part_A_name,
   c.cooperate_type               as cooperate_type,
   c.is_new_renewal               as is_new_renewal,
   c.project_period               as project_period,

   c.province                     AS province,
   c.city                         AS city,
   c.bid_win_time                 AS bid_win_time,
   c.cor_type                     AS cor_type,
   c.business_type                AS business_type,
   c.third_party_money            AS third_party_money,
   c.mt                           AS mt,
   
   c.create_time                  as create_time,
   -- 合同生效日期：最小开票日期>签约日期> 合同流程创建日期
   c.sign_date                   as sign_date,
   c.begin_time                   as begin_time,
   c.end_time                     as end_time,

   coalesce(c.contract_amount,0)             as contract_amount,
   coalesce(c.pre_pay_amount,0)              as pre_pay_amount,
   coalesce(c.pre_pay_pay_period,0)          as pre_pay_pay_period,
   coalesce(c.dev_arrival_amount,0)          as dev_arrival_amount,
   coalesce(c.dev_arrival_pay_period,0)      as dev_arrival_pay_period,
   coalesce(c.check_and_accept_amount,0)     as check_and_accept_amount,
   coalesce(c.check_and_accept_pay_period,0) as check_and_accept_pay_period,
   coalesce(c.warranty_amount,0)             as warranty_amount,
   c.warranty_amount_start_offset            as warranty_amount_start_offset,
   c.warranty_start_offset                   as warranty_start_offset,
   c.warranty_period                         as warranty_period,
   c.warranty_start_date                     as warranty_start_date,
   c.warranty_end_date                       as warranty_end_date,
   
   c.maintenance_amount_appoint              as maintenance_amount_appoint,
   coalesce(c.maintenance_amount,0)          as maintenance_amount,
   c.maintenance_period                      as maintenance_period,
   --质保结束即开始维保
   c.maintenance_start_date                  as maintenance_start_date,
   c.maintenance_end_date                    as maintenance_end_date,

   coalesce(c.software_amount,0)             as software_amount,
   coalesce(c.device_amount,0)               as device_amount,
   coalesce(c.fix_train_amount,0)            AS fix_train_amount,
   coalesce(c.freight_amount,0)              AS freight_amount,

   coalesce(c.pre_pay_percent,0)             as pre_pay_percent,
   coalesce(c.dev_arrival_percent,0)         as dev_arrival_percent,
   coalesce(c.check_and_accept_percent,0)    as check_and_accept_percent,
   coalesce(c.warranty_percent,0)            as warranty_percent,
   coalesce(c.maintenance_percent,0)         as maintenance_percent,
   
   c.achievements_divide                     as achievements_divide,
   c.apply_sub_department                    as apply_sub_department,
   c.apply_sub_department_id                 as apply_sub_department_id,
   c.apply_department                        as apply_department,
   c.applier                                 as applier,
   c.applier_id                              as applier_id,

   c.user_id                                 as user_id,
   c.package_name                            as package_name,
   c.user_name                               as user_name,
   c.user_company_name                       as user_company_name,

   -- 开票情况
    coalesce(c.billed_amount,0)                  as billed_amount,
    coalesce(c.pre_pay_billed,0)                 as pre_pay_billed,
    coalesce(c.dev_arrival_billed,0)             as dev_arrival_billed,
    coalesce(c.check_and_accept_billed,0)        as check_and_accept_billed,
    coalesce(c.warranty_billed,0)                as warranty_billed,
    coalesce(c.maintenance_billed,0)             as maintenance_billed,
    coalesce(c.software_billed,0)                as software_billed,
    coalesce(c.device_billed,0)                  as device_billed,
    coalesce(c.fix_train_billed,0)               as fix_train_billed,
    coalesce(c.maintenance_billed_actual,0)      as maintenance_billed_actual,

   -- 回款情况
    coalesce(c.pre_pay_finish_amount,0)           as pre_pay_finish_amount,
    c.pre_pay_finish_date                         as pre_pay_finish_date,
    coalesce(c.dev_arrival_finish_amount,0)       as dev_arrival_finish_amount,
    c.dev_arrival_finish_date                     as dev_arrival_finish_date,
    coalesce(c.check_and_accept_finish_amount,0)  as check_and_accept_finish_amount,
    c.check_and_accept_finish_date                as check_and_accept_finish_date,
    coalesce(c.warranty_finish_amount,0)          as warranty_finish_amount,
    c.warranty_finish_date                        as warranty_finish_date,
    coalesce(c.maintenance_finish_amount,0)       as maintenance_finish_amount,
    c.maintenance_finish_date                     as maintenance_finish_date,

    coalesce(c.paid_amount,0)                     as paid_amount,  
    coalesce(c.not_paid_amount,0)                 as not_paid_amount, 
                   
    -- 发货信息
    c.erp_no                                    as erp_no,
    c.logistics_no                              as logistics_no,
    c.by_post_date                              as by_post_date,
    -- 项目验收情况
    c.final_check_date                         as final_check_date,
    c.final_check_no                           as final_check_no,

    c.pre_pay_pay_end_date                     as pre_pay_pay_end_date,
    c.dev_arrival_pay_end_date                 as dev_arrival_pay_end_date,
    c.check_and_accept_pay_end_date            as check_and_accept_pay_end_date,
    c.warranty_pay_end_date                    as warranty_pay_end_date,
    c.maintenance_pay_end_date                 as maintenance_pay_end_date,

    c.project_manage                            as project_manage,
    c.project_status                            as project_status,

    -- 项目阶段
    case 
        when c.maintenance_end_date<current_date                                                 then '完结'
        when c.maintenance_end_date>current_date and c.maintenance_start_date<=current_date      then '维保'
        when c.warranty_end_date>current_date and c.warranty_start_date<=current_date            then '质保'
        when c.by_post_date is not null                                                          then '验收'
        when c.final_check_date is not null                                                      then '发货'
        else '预付'
    end                                         as project_stage,

    case 
        when c.maintenance_end_date<current_date                                                then c.maintenance_end_date
        when c.maintenance_end_date>current_date and c.maintenance_start_date<=current_date     then c.maintenance_start_date
        when c.warranty_end_date>current_date and c.warranty_start_date<=current_date           then c.warranty_start_date
        when c.final_check_date is not null                                                     then c.final_check_date
        when c.by_post_date is not null                                                         then c.by_post_date
        else c.sign_date
    end                                        as project_stage_start_date,


    --待回款项阶段
    case 
        when c.not_paid_amount<=0                                             then '全回款'
        when c.pre_pay_finish_amount<c.pre_pay_amount                         then '预付款'
        when c.dev_arrival_finish_amount<c.dev_arrival_amount                 then '到货款'
        when c.check_and_accept_finish_amount<c.check_and_accept_amount       then '验收款'
        when c.warranty_finish_amount<c.warranty_amount                       then '质保金'
        when c.maintenance_finish_amount< c.maintenance_amount                then '维保款'
    end                      as not_payment_stage,
    case 
        when c.not_paid_amount<=0                                             then null
        when c.pre_pay_finish_amount<c.pre_pay_amount                         then c.pre_pay_pay_end_date
        when c.dev_arrival_finish_amount<c.dev_arrival_amount                 then c.dev_arrival_pay_end_date
        when c.check_and_accept_finish_amount<c.check_and_accept_amount       then c.check_and_accept_pay_end_date
        when c.warranty_finish_amount<c.warranty_amount                       then c.warranty_pay_end_date
        when c.maintenance_finish_amount< c.maintenance_amount                then c.maintenance_pay_end_date
   end                      as not_payment_end_date,

   -- 应付
   case 
        when c.maintenance_start_date<current_date                                  then c.contract_amount
        when c.warranty_end_date<current_date                                       then greatest(c.pre_pay_amount+c.dev_arrival_amount+c.check_and_accept_amount+c.warranty_amount,0)
        when c.final_check_date is not null and c.final_check_date<current_date     then greatest(c.pre_pay_amount+c.dev_arrival_amount+c.check_and_accept_amount,0)
        when c.by_post_date is not null and c.by_post_date<current_date             then greatest(c.pre_pay_amount+c.dev_arrival_amount,0)
        when c.sign_date<current_date                                               then greatest(c.pre_pay_amount,0)
   end                                                                                                       as need_pay_amount,
   c.pre_pay_amount                                                                                          as need_pay_amount_pre_pay,
   if(c.by_post_date is not null,c.dev_arrival_amount,0)                                                     as need_pay_amount_dev_arrival,
   if(c.final_check_date is not null,c.check_and_accept_amount,0)                                            as need_pay_amount_check_and_accept,
   if(c.final_check_date is not null and c.warranty_pay_end_date<current_date,c.warranty_amount,0)           as need_pay_amount_warranty,
   if(c.final_check_date is not null and c.warranty_pay_end_date<current_date,c.maintenance_amount,0)        as need_pay_amount_maintenance,


    --逾期天数、逾期金额
    case 
        when c.not_paid_amount<=0                                                                                            then 0
        when c.pre_pay_finish_amount<c.pre_pay_amount   and   c.pre_pay_pay_end_date<current_date                            then datediff(current_date,c.pre_pay_pay_end_date)
        when c.dev_arrival_finish_amount<c.dev_arrival_amount  and c.dev_arrival_pay_end_date<current_date                   then datediff(current_date,c.dev_arrival_pay_end_date)
        when c.check_and_accept_finish_amount<c.check_and_accept_amount and c.check_and_accept_pay_end_date<current_date     then datediff(current_date,c.check_and_accept_pay_end_date)
        when c.warranty_finish_amount<c.warranty_amount   and c.warranty_pay_end_date<current_date                           then datediff(current_date,c.warranty_pay_end_date)
        when c.maintenance_finish_amount< c.maintenance_amount  and c.maintenance_pay_end_date<current_date                  then datediff(current_date,c.maintenance_pay_end_date)
   end                      as exceed_days,

   case 
        when c.maintenance_pay_end_date<current_date                                                      then c.not_paid_amount
        when c.warranty_pay_end_date<current_date                                                         then greatest(c.pre_pay_amount+c.dev_arrival_amount+c.check_and_accept_amount+c.warranty_amount-c.paid_amount,0)
        when c.check_and_accept_pay_end_date is not null and c.check_and_accept_pay_end_date<current_date then greatest(c.pre_pay_amount+c.dev_arrival_amount+c.check_and_accept_amount-c.paid_amount,0)
        when c.dev_arrival_pay_end_date is not null and c.dev_arrival_pay_end_date<current_date           then greatest(c.pre_pay_amount+c.dev_arrival_amount-c.paid_amount,0)
        when c.pre_pay_pay_end_date<current_date                                                          then greatest(c.pre_pay_amount-c.paid_amount,0)
        else 0
   end                      as exceed_amount,

    if(c.pre_pay_finish_amount<c.pre_pay_amount,c.pre_pay_amount-c.pre_pay_finish_amount,0)                                                   as exceed_amount_pre_pay,
    if(c.pre_pay_finish_amount<c.pre_pay_amount,datediff(current_date,c.pre_pay_pay_end_date),null)                                           as exceed_days_pre_pay,
    if(c.dev_arrival_finish_amount<c.dev_arrival_amount,c.dev_arrival_amount-c.dev_arrival_finish_amount,0)                                   as exceed_amount_dev_arrival,
    if(c.dev_arrival_finish_amount<c.dev_arrival_amount,datediff(current_date,c.dev_arrival_pay_end_date),0)                                  as exceed_days_dev_arrival,
    if(c.check_and_accept_finish_amount<c.check_and_accept_amount,c.check_and_accept_amount-c.check_and_accept_finish_amount,0)               as exceed_amount_check_and_accept,
    if(c.check_and_accept_finish_amount<c.check_and_accept_amount,datediff(current_date,c.check_and_accept_pay_end_date),null)                as exceed_days_check_and_accept,
    if(c.warranty_finish_amount<c.warranty_amount,c.warranty_amount-c.warranty_finish_amount,0)                                               as exceed_amount_warranty,
    if(c.warranty_finish_amount<c.warranty_amount,datediff(current_date,c.warranty_pay_end_date),0)                                           as exceed_days_warranty,
    if(c.maintenance_finish_amount< c.maintenance_amount,c.maintenance_amount-c.maintenance_finish_amount,0)                                  as exceed_amount_maintenance,
    if(c.maintenance_finish_amount< c.maintenance_amount,datediff(current_date,c.maintenance_pay_end_date),0)                                 as exceed_days_maintenance

from (select * from tmp_contract_d_f where pt='${ds}') C
;

-- select contract_no,contract_amount,pre_pay_amount,dev_arrival_amount,
--     check_and_accept_amount,
--     warranty_amount,
--     maintenance_amount
-- from  tmp_contract_d_f where pt='${ds}' and contract_no='PFT20180801'
;
