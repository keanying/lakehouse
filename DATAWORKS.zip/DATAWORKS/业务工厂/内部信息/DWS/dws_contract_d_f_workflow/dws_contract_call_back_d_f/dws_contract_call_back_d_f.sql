-- name dws_call_back_d_f
-- type SparkSQL
-- author linnong@12301.cc
-- create time 2021-02-02 17:21:16
-- desc 回款汇总

-- drop table dws_contract_call_back_d_f;

CREATE table if not EXISTS dws_contract_call_back_d_f(
    contract_no                           STRING  COMMENT '合同编号',
    pre_pay_back                          int     comment '预付款回款金额(分)',
    pre_pay_back_date                     string  comment '预付款回款日期',
    dev_arrival_back                      int     comment '到货款回款金额(分)',
    dev_arrival_back_date                 string  comment '到货款回款日期',
    check_and_accept_back                 int     comment '验收款回款金额(分)',
    check_and_accept_back_date            string  comment '验收款回款日期',
    warranty_back                         int     comment '质保金回款金额(分)',
    warranty_back_date                    string  comment '质保金回款日期',
    maintenance_back                      int     comment '维保款回款金额(分)',
    maintenance_back_date                 string  comment '维保款回款日期',

    total_back                            INT     comment '总回款金额(分)',
    back_max_date                         string   comment '最后回款日期'

)COMMENT "合同回款汇总" PARTITIONED  BY (
    pt INT   
)STORED AS ORC;

INSERT OVERWRITE TABLE dws_contract_call_back_d_f PARTITION (pt="${ds}")
SELECT contract_no,
       coalesce(sum(pre_pay_amount),0)                          as pre_pay_back,
       max(if(pre_pay_amount>0,recevice_date,null))             as pre_pay_back_date,
       coalesce(sum(dev_arrival_amount),0)                      as dev_arrival_back,
       max(if(dev_arrival_amount>0,recevice_date,null))         as dev_arrival_back_date,
       coalesce(sum(check_and_accept_amount),0)                 as check_and_accept_back,
       max(if(check_and_accept_amount>0,recevice_date,null))    as check_and_accept_back_date,
       coalesce(sum(warranty_amount),0)                         as warranty_back,
       max(if(warranty_amount>0,recevice_date,null))            as warranty_back_date,
       coalesce(sum(maintenance_amount),0)                      as maintenance_back,
       max(if(maintenance_amount>0,recevice_date,null))         as maintenance_back_date,
       
       coalesce(sum(recevice_amount),0)                         as total_back,
       max(recevice_date)                                       as back_max_date
from dwd_project_call_back_d_f 
where pt='${ds}'
group by contract_no
;

-- select *
-- from dws_contract_call_back_d_f
-- where pt='${bdp.system.bizdate}'
