-- name dws_contract_check_d_f
-- type SparkSQL
-- author linnong@12301.cc
-- create time 2021-02-03 10:48:59
-- desc 合同终验汇总

-- drop table if EXISTS dws_contract_check_d_f

CREATE table if not EXISTS dws_contract_check_d_f(
    contract_no                         STRING  COMMENT '合同编号',
    final_check_date                    STRING  COMMENT '终验日期',
    final_check_no                      STRING  COMMENT '终验单号',
    check_date_list                     string COMMENT '验收日期清单'

)COMMENT "合同终验" PARTITIONED  BY (
    pt INT   
)STORED AS ORC;

INSERT OVERWRITE TABLE dws_contract_check_d_f PARTITION (pt="${ds}")
--OA 设备申请 
select contract_no,
       max(if(check_type='终验',check_date,null))              as final_check_date,
       max(if(check_type='终验',check_no,null))                as final_check_no,
       concat_ws(',',collect_set(check_date))                  as check_date
from dwd_project_check_d_f a where pt='${ds}' 
group by contract_no