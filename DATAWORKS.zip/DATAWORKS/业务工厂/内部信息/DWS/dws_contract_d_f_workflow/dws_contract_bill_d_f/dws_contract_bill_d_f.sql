-- name dws_contract_bill_d_f
-- type SparkSQL
-- author linnong@12301.cc
-- create time 2021-02-02 17:20:50
-- desc 开票汇总
-- drop table if  EXISTS dws_contract_bill_d_f

CREATE table if not EXISTS dws_contract_bill_d_f(
    contract_no                           STRING COMMENT '合同编号',
    pre_pay_bill                          int    comment '预付款开票金额(分)',
    pre_pay_bill_date                     string comment '预付款开票日期',
    dev_arrival_bill                      int    comment '到货款开票金额(分)',
    dev_arrival_bill_date                 string comment '到货款开票日期',
    check_and_accept_bill                 int    comment '验收款开票金额(分)',
    check_and_accept_bill_date            string comment '验收款开票日期',
    warranty_bill                         int    comment '质保金开票金额(分)',
    warranty_bill_date                    string comment '质保金开票日期',
    maintenance_bill                      int    comment '维保款开票金额(分)',
    maintenance_bill_date                 string comment '维保款开票日期',

    bill_device_amount                      bigint comment '开票的硬件金额(分)',
    bill_software_amount                    bigint comment '开票的软件金额(分)',
    bill_other_amount                       bigint comment '开票的其他（运费、安装培训费）(分)',
    bill_maintenance_amount                 bigint comment '开票的维保费）(分)',


    total_bill                            INT comment '总开票金额(分)',
    bill_max_date                         string comment '最后开票日期',
    bill_min_date                         string comment '最早开票日期'

)COMMENT "合同开票汇总" PARTITIONED  BY (
    pt INT   
)STORED AS ORC;

INSERT OVERWRITE TABLE dws_contract_bill_d_f PARTITION (pt="${ds}")
SELECT contract_no,
       sum(pre_pay_amount)                                              as pre_pay_bill,
       max(if(pre_pay_amount>0,bill_date,null))                         as pre_pay_bill_date,
       sum(dev_arrival_amount)                                          as dev_arrival_bill,
       max(if(dev_arrival_amount>0,bill_date,null))                     as dev_arrival_bill_date,
       sum(check_and_accept_amount)                                     as check_and_accept_bill,
       max(if(check_and_accept_amount>0,bill_date,null))                as check_and_accept_bill_date,
       sum(warranty_amount)                                             as warranty_bill,
       max(if(warranty_amount>0,bill_date,null))                        as warranty_bill_date,
       sum(maintenance_amount)                                          as maintenance_bill,
       max(if(maintenance_amount>0,bill_date,null))                     as maintenance_bill_date,

       sum(bill_device_amount)                                          as bill_device_amount,      
       sum(bill_software_amount)                                        as bill_software_amount,    
       sum(bill_other_amount)                                           as bill_other_amount,       
       sum(bill_maintenance_amount)                                     as bill_maintenance_amount, 
       
       sum(bill_amount)                                                 as total_bill,
       max(bill_date)                                                   as bill_max_date,
       min(bill_date)                                                   as bill_min_date
       
from dwd_project_bill_d_f 
where pt='${ds}'
group by contract_no
;