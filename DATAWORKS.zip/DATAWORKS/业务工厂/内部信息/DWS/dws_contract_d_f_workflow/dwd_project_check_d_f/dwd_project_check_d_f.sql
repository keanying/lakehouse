-- 调度状态:启用
-- name dwd_project_check_d_f
-- type SparkSQL
-- author linnong@12301.cc
-- create time 2021-01-27 14:49:59
-- desc 

-- drop table if EXISTS dwd_project_check_d_f;

CREATE table if not EXISTS dwd_project_check_d_f(
    contract_no                         STRING  COMMENT '合同编号',
    check_type                          STRING  COMMENT '验收类型',
    check_date                          STRING  COMMENT '验收日期',
    check_no                            STRING  COMMENT '验收单号',
    remark                              string  COMMENT '备注'

)COMMENT "合同验收" PARTITIONED  BY (
    pt INT   
)STORED AS ORC;

INSERT OVERWRITE TABLE dwd_project_check_d_f PARTITION (pt="${ds}")
---OA验收申请流程
select c.contract_no,
       if(cyyssj is not null,'初验','终验')             as check_type,
       to_date(if(cyyssj is not null,cyyssj,zyyssj))   as check_date,
       ysbh                                            as check_no,
       ''                                              as remark
from (select * from ods_oa_formtable_main_268_d_f a 
      where pt='${ds}' and (cyyssj is not null or  zyyssj is not null)) m 
left join (select id,contract_no from dim_contract_id_d_f where pt='${ds}')  c on c.id=m.htbh
having check_date<>''

union all
---关联历史验收时间
select contract_no,
       if(check_finished=1,'终验','初验') check_type,
       check_date,
       '' check_no,
       check_detail remark
from  ods_project_check_his_o_f
