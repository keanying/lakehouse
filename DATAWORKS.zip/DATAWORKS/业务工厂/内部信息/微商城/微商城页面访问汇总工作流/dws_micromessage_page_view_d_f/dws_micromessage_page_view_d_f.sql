-- name dws_micromessage_page_view_d_f
-- type SparkSQL
-- author xiaoning@12301.cc
-- create time 2020-05-29 18:30:24
-- desc 

create table if not exists dws_micromessage_page_view_d_f(
    business_id STRING COMMENT '账户id',
    click_date STRING COMMENT '点击日期',
    platid STRING COMMENT '005为新版微商城003为旧版微商城',
    click_cnt STRING  COMMENT  '点击次数',
    user_cnt string COMMENT '用户人数',
    INSERT_TIME STRING COMMENT '数据插入时间'
)COMMENT '微商城页面访问汇总(近一月)'PARTITIONED BY(
    `pt` INT
 )STORED AS ORC;

insert OVERWRITE table dws_micromessage_page_view_d_f partition (pt='${ds}')
select
    a.business_id,
    a.click_date,
    a.platid,
    a.click_cnt,
    a.user_cnt,
    a.INSERT_TIME 
from
    ods_micromessage_page_view_d_f a
where
    pt='${ds}'




