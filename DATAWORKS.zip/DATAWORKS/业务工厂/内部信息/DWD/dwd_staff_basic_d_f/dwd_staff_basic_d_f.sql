-- name dwd_staff_basic_d_f
-- type SparkSQL
-- author yemengdan@12301.cc
-- create time 2020-10-19 19:41:09
-- desc 
-- DROP TABLE dwd_staff_basic_d_f
-- s_oa_hrmresource_d_f表：学历id为空时，则设为未知；岗位id为空时，则设为未知；入职日期取companystartdate，若为空则关联入职审批表formtable_main_134取jyksgzr；
-- 对员工根据离职日期和员工状态进行判断；人员表里有测试数据类的，进行排除；
-- 若人员表的STATUS=5，则为离职，人员表关联离职审批表formtable_main_53（有员工已离职未在离职审批表，或者提离职单实际未离职），取离职审批表的lzrq，若为空，则取人员表s_oa_hrmresource_d_f的enddate；
-- 关联岗级表cus_fielddata，由于岗级表里面有重复数据、大小写不一致、格式不为P-之类的问题，对岗级进行处理，最后进行去重；
-- 员工状态为正常的，工作期限为今日-入职日期，离职员工则为离职日期-入职日期；有部分员工日期有误，工作期限为负数，则置为0


CREATE TABLE if NOT EXISTS dwd_staff_basic_d_f(
    staff_id                          STRING COMMENT "员工id",
    LOGINID                           STRING COMMENT "登录id",
    name                              STRING COMMENT "员工名字",
    departmentname_id                 STRING COMMENT "所属部门id",
    departmentname                    STRING COMMENT "所属部门",
    team_id                           STRING COMMENT "所属组id",
    team                              STRING COMMENT "所属组",
    lv1_team_id                       STRING COMMENT "一级组id",
    lv1_team                          STRING COMMENT "一级组名称",
    lv2_team_id                       STRING COMMENT "二级组id",
    lv2_team                          STRING COMMENT "二级组名称",
    full_dep_name                     STRING COMMENT "部门全称",
    amb_level1                        STRING COMMENT "阿米巴一级标签",
    amb_level2                        STRING COMMENT "阿米巴二级标签",
    amb_level3                        STRING COMMENT "阿米巴三级标签",
    level                             STRING COMMENT "岗级",
    superior_name                     STRING COMMENT "上级领导",
    edu_name                          STRING COMMENT "学历",
    job_name                          STRING COMMENT "岗位",
    entry_date                        STRING COMMENT "入职日期",
    positive_date                     STRING COMMENT "试用期结束日期",
    contract_startdate                STRING COMMENT "合同开始日期",
    contract_enddate                  STRING COMMENT "合同结束日期",
    type                              STRING COMMENT "员工类型",
    left_date                         STRING COMMENT "离职日期",
    left_type                         STRING COMMENT "离职类型",
    work_length                       STRING COMMENT "工作期限"
)COMMENT "员工基本表" PARTITIONED by(
    pt INT 
) stored as orc;

INSERT OVERWRITE table dwd_staff_basic_d_f PARTITION (pt="${ds}")
select  
        staff_id,
        LOGINID,
        name,
        departmentname_id,
        departmentname,
        team_id,
        team,
        lv1_team_id,
        lv1_team,
        lv2_team_id,
        lv2_team,
        full_dep_name,
        amb_level1,
        amb_level2,
        amb_level3,
        level,
        superior_name,
        edu_name,
        job_name,
        entry_date,
        positive_date,
        contract_startdate,
        contract_enddate,
        -- 判断员工当前的状态
        case 
             when substr(left_date,1,7)=substr(current_date(),1,7) THEN '本月离职'
             WHEN substr(entry_date,1,7)=substr(current_date(),1,7) THEN '本月入职'
             WHEN left_date<=positive_date or (isnotnull(left_date) and DATEDIFF(left_date,entry_date)<=90) THEN '试用期离职'
             WHEN isnotnull(left_date) THEN '已离职'
             WHEN isnull(left_date) THEN '正常'
        ELSE '其他' END as type,
	left_date,
        left_type,
	if(work_length<0,0,work_length) as work_length
from (
        SELECT  *,
                CASE WHEN isnull(left_date) and isnotnull(entry_date)  THEN DATEDIFF(current_date(),entry_date)
                     WHEN isnull(left_date) and isnull(entry_date)  THEN DATEDIFF(current_date(),contract_startdate)
                     WHEN isnotnull(left_date) and isnull(entry_date) THEN DATEDIFF(left_date,contract_startdate)
                ELSE DATEDIFF(left_date,entry_date)
                END as work_length,
                row_number() OVER (partition by staff_id order by level DESC ) as no
        FROM (
                SELECT DISTINCT * 
                FROM (
                        SELECT 
                                hr.ID                                                             as staff_id,
                                hr.LOGINID,
                                hr.LASTNAME                                                       as name,
                                dp.departmentname_id                                              as departmentname_id,
                                dp.departmentname                                                 as departmentname,
                                dp.lv3_team_id                                                    as team_id,
                                dp.lv3_team                                                       as team,
                                dp.lv1_team_id,
                                dp.lv1_team,
                                dp.lv2_team_id,
                                dp.lv2_team,
                                dp.full_dep_name,
                                dp.amb_level1,
                                dp.amb_level2,
                                dp.amb_level3,
                                -- 若新岗级字段不为空则取新岗级字段，否则取旧数据
                                if(isnotnull(cus1.field6),cus1.field6,cus2.field0)                as level,
                                hr1.LASTNAME                                                      as superior_name,
                                -- 部分人学历id为空，则令学历id为空的设为未知
                                if(isnotnull(he.NAME),he.NAME,'未知')                             as edu_name,
                                -- 部分人岗位id为空，则令岗位id为空的设为未知
                                if(isnotnull(hj.JOBTITLEMARK),hj.JOBTITLEMARK,'未知')             as job_name,
                                -- 取入职日期，若入职日期为空则取入职表单的入职日期，若都无，则设置为离职表中的入职日期，都没有，则为空
                                if(isnotnull(hr.companystartdate),hr.companystartdate,if(isnotnull(f134.jyksgzr),f134.jyksgzr,f53.rzrq))         as entry_date,
                                hr.PROBATIONENDDATE                                               as positive_date,
                                hr.startdate                                                      as contract_startdate,
                                hr.enddate                                                        as contract_enddate,
                                -- 在11月份前离职的，直接取合同结束日期；在11月份后离职，直接取离职表单的日期
                                case when hr.status=5 and hr.enddate<'2020-11-01'  THEN hr.enddate
                                     when hr.status=5 and hr.enddate>='2020-11-01' then f53.nlzrq
                                     else NULL 
                                END as left_date,
                                case when hr.status=5 and f53.lzlx=0 THEN '合同期满'
                                     when hr.status=5 and f53.lzlx=1 THEN '辞职'
                                     when hr.status=5 and f53.lzlx=2 THEN '辞退'
                                     when hr.status=5 and f53.lzlx=3 THEN '调动'
                                     when hr.status=5 and f53.lzlx=4 THEN '其他'
                                end as left_type
                        FROM ods_oa_hrmresource_d_f as hr
                        -- 按姓名、生日去重
                        join (select lastname,birthday,max(id) max_id 
                              from ods_oa_hrmresource_d_f 
                              where pt='${ds}' 
                              group by lastname,birthday) hr0 on hr0.max_id=hr.id
                        -- 主管信息
                        left join ods_oa_hrmresource_d_f as hr1 on hr.managerid=hr1.id and hr1.pt='${ds}'
                        left join dim_oa_department_d_f as dp on hr.departmentid=dp.lv3_team_id and dp.pt='${ds}'
                        -- left join dim_oa_department_month_d_f as dp on hr.departmentid=dp.lv3_team_id and dp.pt='${cur_month}'
                        left join ods_oa_hrmeducationlevel_d_f as he on hr.educationlevel=he.id and he.pt='${ds}'
                        left join ods_oa_hrmjobtitles_d_f as hj on hr.jobtitle=hj.id and hj.pt='${ds}'
                        left join (select distinct sqr,nlzrq,lzlx,rzrq from ods_oa_formtable_main_53_d_f where pt='${ds}' and nlzrq<>'') as f53 on hr.ID=f53.sqr
                        -- 在职员工岗级字段为新的field6
                        left join (
                                  select ID,concat('P',substr(field6,2,1),'-',substr(field6,4,1)) as field6
                                  from ods_oa_cus_fielddata_d_f 
                                  where pt='${ds}' and scopeid=3 and field6<>''
                                ) as cus1 on hr.ID=cus1.ID
                        -- 已离职员工岗级字段为旧数据field0
                        left join (
                                  select ID,concat('P',substr(field0,2,1),'-',substr(field0,4,1)) as field0
                                  from ods_oa_cus_fielddata_d_f 
                                  where pt='${ds}' and scopeid=-1 and field0<>''
                                ) as cus2 on hr.ID=cus2.ID
                        LEFT JOIN ods_oa_formtable_main_134_d_f as f134 on hr.LASTNAME=f134.xm and f134.pt='${ds}'
                        -- 过滤三个非员工的员工id，过滤状态不为5但LOGINID为空的，过滤部门id为空的员工
                        where hr.pt='${ds}' and hr.LASTNAME NOT IN ('测试人员2','测试人员','会议室专用') and not (hr.STATUS<>5 and hr.LOGINID='') and isnotnull(dp.lv3_team_id)
                ) as k
        ) as s
) as s1
where staff_id<>'494' and no=1
;


-- select *
-- from dwd_staff_basic_d_f
-- where pt='${ds}' and name='叶梦丹' --and left_date>='2021-04-01' and left_date<'2021-05-01'