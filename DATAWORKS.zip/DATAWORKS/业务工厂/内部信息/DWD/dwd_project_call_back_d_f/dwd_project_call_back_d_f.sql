-- name dwd_project_call_back_d_f
-- type SparkSQL
-- author yemengdan@12301.cc
-- create time 2021-01-28 14:23:22
-- desc   项目回款
-- drop table dwd_project_call_back_d_f;


CREATE table if not EXISTS dwd_project_call_back_d_f(
    contract_no                         STRING  COMMENT '合同编号',
    amount_type                         STRING  COMMENT '款项类型',
    recevice_date                       STRING  COMMENT '回款日期',
    recevice_amount                     STRING  COMMENT '回款金额',
    pre_pay_amount                      bigint comment '预付款回款(分)',
    dev_arrival_amount                  bigint comment '到货款回款(分)',
    check_and_accept_amount             bigint comment '验收款回款(分)',
    warranty_amount                     bigint comment '质保金回款(分)',
    maintenance_amount                  bigint comment '维保款回款(分)',
    remark                              string  COMMENT '备注'
)COMMENT "回款流程详细表" PARTITIONED  BY (
    pt INT   
) stored as orc;

--2021.1月回款数据在f265表，2月份以后在明细表
INSERT OVERWRITE TABLE dwd_project_call_back_d_f PARTITION (pt="${ds}")
SELECT contract_no,amount_type,substr(recevice_date,1,10) recevice_date,
       recevice_amount,pre_pay_amount,dev_arrival_amount,check_and_accept_amount,warranty_amount,INT(maintenance_amount),
       remark 
from ods_project_call_back_his_o_f where pt='2021'
UNION ALL
SELECT 
       c.contract_no                as contract_no,
       CASE 
            WHEN if(d.xmjd is null,f265.xmjd,d.xmjd)=0 or if(d.hkje1 is null,f265.hkje,d.hkje1)=d.yfje THEN '预付款'
            WHEN if(d.xmjd is null,f265.xmjd,d.xmjd)=1 or if(d.hkje1 is null,f265.hkje,d.hkje1)=d.dhje THEN '到货款'
            WHEN if(d.xmjd is null,f265.xmjd,d.xmjd) in (2,4) or if(d.hkje1 is null,f265.hkje,d.hkje1)=d.ysje THEN '验收款'    -- '4-完结款'
            WHEN if(d.xmjd is null,f265.xmjd,d.xmjd)=3 or if(d.hkje1 is null,f265.hkje,d.hkje1)=d.zbje THEN '质保金'
            WHEN if(d.xmjd is null,f265.xmjd,d.xmjd)=5 or if(d.hkje1 is null,f265.hkje,d.hkje1)=d.wbje THEN '维保款'
       END                          as amount_type,
       f265.hkrq                    as recevice_date,
       
       if(d.hkje1 is null,f265.hkje,d.hkje1)*100                                                                             as recevice_amount,
       if(if(d.xmjd is null,f265.xmjd,d.xmjd)=0 and (d.yfje=0 or d.yfje is null),if(d.hkje1 is null,f265.hkje,d.hkje1),d.yfje)*100                 as pre_pay_amount,
       if(if(d.xmjd is null,f265.xmjd,d.xmjd)=1 and (d.dhje=0 or d.dhje is null)    ,if(d.hkje1 is null,f265.hkje,d.hkje1),d.dhje)*100               as dev_arrival_amount,
       if(if(d.xmjd is null,f265.xmjd,d.xmjd) in (2,4) and (d.ysje=0 or d.ysje is null),if(d.hkje1 is null,f265.hkje,d.hkje1),d.ysje)*100               as check_and_accept_amount,
       if(if(d.xmjd is null,f265.xmjd,d.xmjd)=3 and (d.zbje=0 or d.zbje is null)    ,if(d.hkje1 is null,f265.hkje,d.hkje1),d.zbje)*100               as warranty_amount,
       INT(if(if(d.xmjd is null,f265.xmjd,d.xmjd)=5 and (d.wbje=0 or d.wbje is null)    ,if(d.hkje1 is null,f265.hkje,d.hkje1),d.wbje)*100)              as maintenance_amount_amount,

       '' as remark
from ods_oa_formtable_main_265_d_f as f265
left JOIN (select * from ods_oa_formtable_main_265_dt1_d_f where pt='${ds}' )  d on f265.id=d.mainid
left join (select id,contract_no from dim_contract_id_d_f where pt='${ds}')  c on c.id=d.htbh
where f265.pt='${ds}' and f265.hkrq>='2020-12-01' and f265.lcbh<>'';