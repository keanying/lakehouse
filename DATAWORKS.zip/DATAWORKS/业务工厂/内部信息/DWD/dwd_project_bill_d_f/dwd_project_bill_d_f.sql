-- name dwd_project_bill_d_f
-- type SparkSQL
-- author yemengdan@12301.cc
-- create time 2021-01-27 14:49:59
-- desc 
-- drop table dwd_project_bill_d_f;

CREATE table if not EXISTS dwd_project_bill_d_f(
    contract_no                             STRING  COMMENT '合同编号',
    amount_type                             STRING  COMMENT '款项类型',
    bill_date                               STRING  COMMENT '开票日期',
    bill_amount                             bigint  COMMENT '开票金额(分)',
    pre_pay_amount                          bigint comment '预付款(分)',
    dev_arrival_amount                      bigint comment '到货款(分)',
    check_and_accept_amount                 bigint comment '验收款(分)',
    warranty_amount                         bigint comment '质保金(分)',
    maintenance_amount                      bigint comment '维保款(分)',

    bill_device_amount                      bigint comment '开票的硬件金额(分)',
    bill_software_amount                    bigint comment '开票的软件金额(分)',
    bill_other_amount                       bigint comment '开票的其他（运费、安装培训费）(分)',
    bill_maintenance_amount                 bigint comment '开票的维保费）(分)',

    remark                              string  COMMENT '备注'

)COMMENT "开票流程详细表" PARTITIONED  BY (
    pt INT   
) stored as orc;

INSERT OVERWRITE TABLE dwd_project_bill_d_f PARTITION (pt="${ds}")
SELECT contract_no,
        amount_type,
        substr(bill_date,1,10) bill_date,
        bill_amount,
        pre_pay_amount,
        dev_arrival_amount,
        check_and_accept_amount,
        warranty_amount,
        maintenance_amount,
        bill_device_amount,
        bill_software_amount,
        bill_other_amount,
        bill_maintenance_amount,
        remark 
from ods_project_bill_his_o_f where pt='2021'
UNION ALL 
SELECT 
       c.contract_no as contract_no,
       CASE f111.fkjd
            WHEN 0 THEN '预付款'
            WHEN 1 THEN '验收款'
            WHEN 2 THEN '终验款'
            WHEN 3 THEN '质保金'
            WHEN 4 THEN '维保款'
            WHEN 5 THEN '到货款'
            WHEN 6 THEN '验收款'
       END              as amount_type,
       if(d.kprq is null,f111.kprq,d.kprq)                as bill_date,
       if(d.bcsqje is null,f111.kpje,d.bcsqje)*100        as bill_amount,
       if(f111.fkjd=0 and (d.yfkje=0 or d.yfkje is null),if(d.bcsqje is null,f111.kpje,d.bcsqje),d.yfkje)*100            as pre_pay_amount,
       if(f111.fkjd=5 and (d.dhkje=0 or d.dhkje is null),if(d.bcsqje is null,f111.kpje,d.bcsqje),d.dhkje)*100             as dev_arrival_amount,
       if(f111.fkjd in (1,6) and (d.yskje=0 or d.yskje is null),if(d.bcsqje is null,f111.kpje,d.bcsqje),d.yskje)*100      as check_and_accept_amount,
       if(f111.fkjd=3 and (d.zbje=0 or d.zbje is null),if(d.bcsqje is null,f111.kpje,d.bcsqje),d.zbje)*100               as warranty_amount,
       if(f111.fkjd=4 and (d.wbf1=0 or d.wbf1 is null),if(d.bcsqje is null,f111.kpje,d.bcsqje),d.wbf1)*100               as maintenance_amount,
       d.yj*100         as bill_device_amount,
       d.rj*100         as bill_software_amount,
       d.azdsf*100      as bill_other_amount,
       d.wbf2*100       as bill_maintenance_amount,
       ''               as remark
from (select * from ods_oa_formtable_main_111_d_f where pt='${ds}'  and lcbh<>'') as f111
left join (select id,contract_no from dim_contract_id_d_f where pt='${ds}')  c on c.id=f111.htbh
left join (select * from ods_oa_formtable_main_111_dt1_d_f where pt='${ds}' and kprq>='2020-12-01') d on d.mainid=f111.id
;