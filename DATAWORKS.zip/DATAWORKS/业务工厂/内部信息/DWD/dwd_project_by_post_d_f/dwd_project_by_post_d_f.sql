-- name dwd_project_bill_d_f
-- type SparkSQL
-- author yemengdan@12301.cc
-- create time 2021-01-27 14:49:59
-- desc 
-- drop table if EXISTS dwd_project_by_post_d_f

CREATE table if not EXISTS dwd_project_by_post_d_f(
    contract_no                         STRING  COMMENT '合同编号',
    is_finished                         STRING  COMMENT '是否完结,是/否',
    by_post_date                        STRING  COMMENT '发货日期',
    erp_no                              STRING  COMMENT 'ERP出入库单号',
    logistics_no                        STRING  COMMENT '物流单号'
)COMMENT "合同发货" PARTITIONED  BY (
    pt INT   
) stored as orc;

INSERT OVERWRITE TABLE dwd_project_by_post_d_f PARTITION (pt="${ds}")
--OA 设备申请 
select c.contract_no,
       if(b.bcfhyqbwc=0,'是','否')  as  is_finished,
       to_date(b_dt2.fhsj)          as by_post_date,
       b.erpcrkdh                   as erp_no,
       b_dt2.wldh                   as logistics_no
from (select * from ods_oa_formtable_main_176_d_f a where pt='${ds}' and (erpcrkdh is not null or wldh is not null)) b 
left join (select id,contract_no from dim_contract_id_d_f where pt='${ds}')  c on c.id=b.htbh
-- 发货明细 
left join (select mainid,fhsj,wldh from ods_oa_formtable_main_176_dt2_d_f where pt='${ds}' ) b_dt2 on b.id=b_dt2.mainid
where to_date(b_dt2.fhsj) is not null and to_date(b_dt2.fhsj)<>''

union all
-- 历史发货信息
select contract_no,
       if(is_finished=1,'是','否') is_finished,
       by_post_date,
       '' erp_no,
       '' logistics_no 
from ods_project_waybill_his_o_f
;

