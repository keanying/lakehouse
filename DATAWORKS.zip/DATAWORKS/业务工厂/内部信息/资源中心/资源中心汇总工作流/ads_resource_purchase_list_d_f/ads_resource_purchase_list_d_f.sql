-- name ads_resource_purchase_list_d_f
-- type SparkSQL
-- author zhengchunyan@12301.cc
-- create time 2021-06-28 18:18:31
-- desc 

CREATE TABLE IF NOT EXISTS ads_resource_purchase_list_d_f(
    purchase_id                 INT    COMMENT "资源中心采购商id",
    purchase_name               STRING COMMENT "资源中心采购商名称",
    purchase_province           STRING COMMENT "资源中心采购商省",
    purchase_city               STRING COMMENT "资源中心采购商市",
    purchase_belong_area        STRING COMMENT "资源中心采购商归属区域",
    purchase_order_num_month    INT    COMMENT "本月采购商总订单数-资源中心",
    purchase_ticket_num_month   INT    COMMENT "本月采购商总票数-资源中心",
    purchase_amount_month       INT    COMMENT "本月采购商总金额(元)-资源中心",
    purchase_order_num_year     INT    COMMENT "本年采购商总订单数-资源中心",
    purchase_ticket_num_year    INT    COMMENT "本年采购商总门票数-资源中心",
    purchase_amount_year        INT    COMMENT "本年采购商总金额(元)-资源中心",
    purchase_order_num_month_1  INT    COMMENT "上月采购商总订单数-资源中心",
    purchase_ticket_num_month_1 INT    COMMENT "上月采购商总订单数-资源中心",
    purchase_amount_month_1     INT    COMMENT "上月采购商总金额(元)-资源中心",
    pt_order_num_month          INT    COMMENT "本月采购商总订单数-平台",
    pt_ticket_num_month         INT    COMMENT "本月采购商总票数数-平台",
    pt_amount_month             INT    COMMENT "本月采购商总金额(元)-平台",
    pt_order_num_year           INT    COMMENT "本年采购商总订单数-平台",
    pt_ticket_num_year          INT    COMMENT "本年采购商总票数-平台",
    pt_amount_year              INT    COMMENT "本年采购商总金额(元)-平台",
    pt_order_num_month_1        INT    COMMENT "上月采购商总订单数-平台",
    pt_ticket_num_month_1       INT    COMMENT "上月采购商总票数-平台",
    pt_amount_month_1           INT    COMMENT "上月采购商总金额(元)-平台",
    ratio_order_num_month       FLOAT  COMMENT "月订单数占比(资源中心/平台)",
    ratio_order_num_year        FLOAT  COMMENT "年订单数占比(资源中心/平台)",
    Chain_ratio_order_num_month FLOAT  COMMENT "月订单数环比"
)COMMENT'采购商清单汇总'
PARTITIONED BY(
    `pt` INT
) STORED AS ORC;

INSERT OVERWRITE TABLE ads_resource_purchase_list_d_f PARTITION (pt = "${ds}")
SELECT 
    user_id,
    user_name,
    customer_province,
    customer_city,
    belong_area,
    purchase_order_num_month,           -- 本月采购商总订单数-资源中心 
    purchase_ticket_num_month,          -- 本月采购商总票数-资源中心 
    purchase_amount_month,              -- 本月采购商总金额(元)-资源中心 
    purchase_order_num_year,            -- 本年采购商总订单数-资源中心
    purchase_ticket_num_year,           -- 本年采购商总门票数-资源中心
    purchase_amount_year,               -- 本年采购商总金额(元)-资源中心
    purchase_order_num_month_1,         -- 上月采购商总订单数-资源中心
    purchase_ticket_num_month_1,        -- 上月采购商总订单数-资源中心
    purchase_amount_month_1,            -- 上月采购商总金额(元)-资源中心
    NVL(pt.pt_order_num_month, 0)       AS pt_order_num_month,      -- 本月采购商总订单数-平台
    NVL(pt.pt_ticket_num_month, 0)      AS pt_ticket_num_month,     -- 本月采购总票数-平台
    NVL(pt.pt_amount_month, 0)          AS pt_amount_month,         -- 本月采购商总金额(元)-平台
    NVL(pt.pt_order_num_year, 0)        AS pt_order_num_year,       -- 本年采购商总订单数-平台
    NVL(pt.pt_ticket_num_year, 0)       AS pt_ticket_num_year,      -- 本年采购商总票数-平台
    NVL(pt.pt_amount_year, 0)           AS pt_amount_year,          -- 本年采购商总金额(元)-平台
    NVL(pt.pt_order_num_month_1, 0)     AS pt_order_num_month_1,    -- 上月采购商总订单数-平台
    NVL(pt.pt_ticket_num_month_1, 0)    AS pt_ticket_num_month_1,   -- 上月采购商总票数数-平台
    NVL(pt.pt_amount_month_1, 0)        AS pt_amount_month_1,       -- 上月采购商总金额(元)-平台
    NVL(ROUND(purchase_order_num_month / IF(pt.pt_order_num_month = 0, NULL, pt.pt_order_num_month), 4), 0)     AS ratio_order_num_month,   -- 月订单数占比(资源中心/平台)
    NVL(ROUND(purchase_order_num_year / IF(pt.pt_order_num_year = 0, NULL, pt.pt_order_num_year), 4) ,0)        AS ratio_order_num_year,    -- 年订单数占比(资源中心/平台)
    NVL(ROUND((purchase_order_num_month-purchase_order_num_month_1m) / IF(purchase_order_num_month_1m = 0, NULL, purchase_order_num_month_1m), 4),0)  AS Chain_ratio_order_num_month  --月订单数环比
FROM 
(
    SELECT * 
    FROM dws_resource_center_user_d_f 
    WHERE pt="${ds}"
    AND ISNOTNULL(min_purchace_time)
) AS re
LEFT JOIN 
(
    SELECT 
        fid,
        SUM(IF(SUBSTR(`date`,1,6) = SUBSTR(FROM_UNIXTIME(UNIX_TIMESTAMP(DATE_SUB(CURRENT_DATE,1)),'yyyyMMdd'),1,6),order_num,0))        AS pt_order_num_month,  -- 本月采购商总订单数-平台
        SUM(IF(SUBSTR(`date`,1,6) = SUBSTR(FROM_UNIXTIME(UNIX_TIMESTAMP(DATE_SUB(CURRENT_DATE,1)),'yyyyMMdd'),1,6),order_ticket,0))     AS pt_ticket_num_month, -- 本月采购总票数-平台
        SUM(IF(SUBSTR(`date`,1,6) = SUBSTR(FROM_UNIXTIME(UNIX_TIMESTAMP(DATE_SUB(CURRENT_DATE,1)),'yyyyMMdd'),1,6),sale_money,0))/100   AS pt_amount_month,     -- 本月采购商总金额(元)-平台
        SUM(IF(SUBSTR(`date`,1,4) = YEAR(CURRENT_DATE()),order_num,0))                                                                   AS pt_order_num_year,   -- 本年采购商总订单数-平台
        SUM(IF(SUBSTR(`date`,1,4) = YEAR(CURRENT_DATE()),order_ticket,0))                                                                AS pt_ticket_num_year,  -- 本年采购商总票数-平台
        SUM(IF(SUBSTR(`date`,1,4) = YEAR(CURRENT_DATE()),sale_money,0))/100                                                              AS pt_amount_year,      -- 本年采购商总金额(元)-平台
        SUM(IF(SUBSTR(`date`,1,6) = SUBSTR(FROM_UNIXTIME(UNIX_TIMESTAMP(add_months(date_sub(current_date,1),-1)),'yyyyMMdd'),1,6),order_num,0))         AS pt_order_num_month_1,    -- 上月采购商总订单数-平台
        SUM(IF(SUBSTR(`date`,1,6) = SUBSTR(FROM_UNIXTIME(UNIX_TIMESTAMP(add_months(date_sub(current_date,1),-1)),'yyyyMMdd'),1,6),order_ticket,0))      AS pt_ticket_num_month_1,   -- 上月采购商总票数数-平台
        SUM(IF(SUBSTR(`date`,1,6) = SUBSTR(FROM_UNIXTIME(UNIX_TIMESTAMP(add_months(date_sub(current_date,1),-1)),'yyyyMMdd'),1,6),sale_money,0))/100    AS pt_amount_month_1        -- 上月采购商总金额(元)-平台
    FROM 
    (
        SELECT * 
        FROM ods_pft_report_order_two_d_i
        WHERE date >= CONCAT((YEAR(CURRENT_DATE()) - 1), '01', '01')
          AND main_tid = 0
    ) AS t
    GROUP BY fid
) AS pt  
ON re.user_id = pt.fid;

