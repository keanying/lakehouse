-- name ads_resource_center_order_d_f
-- type SparkSQL
-- author linnong@12301.cc
-- create time 2020-04-29 16:56:04
-- desc 资源中心订单

-- drop table ads_resource_center_order_d_f;
-- alter table ads_resource_center_order_d_f add columns(product_supply_type string comment '资源中心自动拉取产品商户标识');
-- alter table ads_resource_center_order_d_f add columns(booking_num int comment '预定票数');
-- alter table ads_resource_center_order_d_f add columns(booking_pay_amount bigint comment '预定金额');
-- alter table ads_resource_center_order_d_f add columns(fail_reason string comment '失败原因');
-- alter table ads_resource_center_order_d_f add columns(fail_code  string comment '失败代码');
-- alter table ads_resource_center_order_d_f add columns(ticket_taker_province  string comment '客源地省');
-- alter table ads_resource_center_order_d_f add columns(ticket_taker_city  string comment '客源地市');
-- alter table ads_resource_center_order_d_f add columns(land_type  string comment '产品类型编码');
-- alter table ads_resource_center_order_d_f add columns(land_type_name  string comment '产品类型');
-- alter table ads_resource_center_order_d_f add columns(land_topic  string comment '景区主题');
-- alter table ads_resource_center_order_d_f add columns(resource_land_id    int comment '业态景区id');
-- alter table ads_resource_center_order_d_f add columns(resource_land_name  string comment '业态景区名称');
-- alter table ads_resource_center_order_d_f add columns(resource_center_purchase_is_OTA  string comment '采购商是否为OTA');
-- alter table ads_resource_center_order_d_f add columns(cost_price  int  comment '供货商成本价');
-- alter table ads_resource_center_order_d_f add columns(sale_price  int  comment '零售价');

create table if not EXISTS ads_resource_center_order_d_f(
    stat_date                               STRING COMMENT '统计日期',
    dw_ins_time                             STRING COMMENT '插入时间',

    order_id                                string COMMENT "订单号",
    remote_order_id                         string comment '远程订单号',
    order_status                            STRING  COMMENT "订单状态",
    ticket_num                              int    COMMENT "实际票数",
    booking_time                            STRING COMMENT "下单时间",
    vertify_time                            STRING COMMENT "验证时间",


    resource_center_supplier_id             INT    COMMENT "资源中心上架产品商户id",
    resource_center_purchase_id             INT    COMMENT "资源中心采购商id",
    resource_center_supplier_account        string COMMENT "资源中心上架产品商户账号",
    resource_center_supplier_name           string COMMENT "资源中心上架产品商户名称",
    resource_center_supplier_province       string COMMENT "资源中心上架产品商户省",
    resource_center_supplier_city           string COMMENT "资源中心上架产品商户市",
    resource_center_purchase_account        string COMMENT "资源中心采购商账号",
    resource_center_purchase_name           string COMMENT "资源中心采购商名称",
    resource_center_purchase_province       string COMMENT "资源中心采购商省",
    resource_center_purchase_city           string COMMENT "资源中心采购商市",
    order_pay_amount                        float  comment "订单支付金额（元）",
    land_id                                 int     COMMENT "产品ID",
    land_name                               string  COMMENT "产品名称",
    land_province                           STRING  COMMENT "景区所在省",
    land_city                               STRING  COMMENT '景区城市名称',    

    ticket_id                               int     COMMENT "票ID",
    ticket_fullname                         STRING  COMMENT "票全称",
    resource_id                             int     COMMENT "资源ID",
    resource_name                           string  COMMENT "资源名称",
    distribute_type                         string  COMMENT "直分销标识",
    distribute_level                        string  COMMENT "分销级别:-1直销 1分销1级 2分销2级 3 分销3级",
    is_ota                                  string  COMMENT "是否OTA订单",
    distribute_system_name                  STRING  COMMENT "对接分销平台名称",
    booking_channel                         STRING  COMMENT '销售渠道ID',
    booking_channel_name                    STRING  COMMENT '销售渠道名称',
    belong_area                             string  comment '产品归属区域',

    product_supply_type                     string comment '产品供应类型,自动拉取/手动供应',
    booking_num                             int    comment'预定票数',
    booking_pay_amount                      bigint comment'预定金额',

    fail_reason                             string comment '失败原因',
    fail_code                               string comment '失败代码',

    ticket_taker_province                   string comment '客源地省',
    ticket_taker_city                       string comment '客源地市',

    land_type                               string comment '产品类型编码',
    land_type_name                          string comment '产品类型',

    booker_id                               int comment '购买者id',
    booker_name                             string comment '购买者名称',
    booker_type                             string comment '购买者类型',

    resource_center_purchase_price          int comment '资源中心采购价',
    booking_price                           int comment '预定价格',
    profit                                  int comment '利润',

    land_topic                              string comment '景区主题',
    resource_land_id                        int  comment '业态景区id',
    resource_land_name                      string comment '业态景区名称',
    resource_center_purchase_is_OTA         string comment '采购商是否为OTA',

    cost_price                              int comment '供货商成本价',
    sale_price                              int comment '零售价'

)COMMENT "资源中心订单" PARTITIONED by(
    pt INT
)STORED AS ORC;

-- 资源中心产生的订单
-- 过滤上架商、采购商为测试账号的订单
-- 过滤未支付
-- 
INSERT OVERWRITE table ads_resource_center_order_d_f PARTITION (pt="${ds}")
select 
    '${ds}'                       as stat_date,
    current_date()                                as  dw_ins_time,

    o.order_id                                     as order_id,
    o.remote_order_id                              as remote_order_id,
    o.order_status                                 as order_status,
    o.ticket_num                                   as ticket_num,
    o.booking_time                                 as booking_time,
    o.vertify_time                                 as vertify_time,

    ----资源中心商户情况
    o.resource_center_supplier_id                  as resource_center_supplier_id,
    o.resource_center_purchase_id                  as resource_center_purchase_id,
    o.resource_center_supplier_account             as resource_center_supplier_account,
    o.resource_center_supplier_name                as resource_center_supplier_name,
    o.resource_center_supplier_province            as resource_center_supplier_province,
    o.resource_center_supplier_city                as resource_center_supplier_city,
    o.resource_center_purchase_account             as resource_center_purchase_account,
    o.resource_center_purchase_name                as resource_center_purchase_name,
    o.resource_center_purchase_province            as resource_center_purchase_province,
    o.resource_center_purchase_city                as resource_center_purchase_city,
    o.order_pay_amount/100                         as order_pay_amount,


    o.land_id                                      as land_id,
    o.land_name                                    as land_name,
    o.land_province                                as land_province,
    o.land_city                                    as land_city,

    o.ticket_id                                    as ticket_id,
    o.ticket_fullname                              as ticket_fullname,
    o.resource_id                                  as resource_id,
    o.resource_name                                as resource_name,
    --分销类型：末级对接第三方平台类型是OTA且不是直销的为OTA 
    --卖家是资源中心采购商或供应商为采购商直销 否则为分销
    case 
       when (o.distribute_system_type ='OTA' and o.booker_id<>o.resource_center_purchase_id) or (o.booking_channel=17) then 'OTA'
       when o.booking_channel=20  then '第三方分销'
--       when o.booking_channel=17  then '淘宝/飞猪'
       when o.seller_id=o.resource_center_purchase_id or o.seller_id=o.resource_center_supplier_id then '采购商直销' 
       else '分销' 
    end distribute_type,
    --采购商直销 就无分销数
    --上架商为一级分销商时，中间层级的分销链数-1
    --其它分销链数为中间层级分销链数
    case when o.seller_id=o.resource_center_purchase_id or o.seller_id=o.resource_center_supplier_id then -1
         when o.distributor_id=o.resource_center_supplier_id then a.num-1
         else a.num end distribute_num,
    case 
         when o.distribute_system_type='OTA' or (o.booking_channel=17) then '是' 
         else '否' 
    end                                                                     as is_ota,
    -- 第三方分销也列出对接系统名称
    case 
--         when o.distribute_system_type='OTA' then o.distribute_system_name
         when o.booking_channel=20 then o.distribute_system_name
         when o.booking_channel=17 then '淘宝/飞猪'
    end                                                                     as distribute_system_name,
    o.booking_channel                                                       as booking_channel,
    --下单渠道为OTA（booking_channel=20） 且 末级第三方平台类型是OTA 的为OTA 剩下的下单渠道为OTA（booking_channel=20）的为第三方对接 
    -- 下单渠道booking_channel=17(淘宝/飞猪) 为OTA
    case 
        when (o.distribute_system_type ='OTA' and o.booking_channel=20) or (o.booking_channel=17) then 'OTA'
        else if(o.booking_channel=20,'第三方对接',o.booking_channel_name)
    end booking_channel_name,
    o.belong_area      as belong_area,

    if(o.resource_center_supplier_auto_get='是','自动拉取','手动供应')             as product_supply_type,
    o.booking_num                                                                  as booking_num,
    o.booking_pay_amount                                                           as booking_pay_amount,

    o.fail_reason   as   fail_reason,
    o.fail_code     as   fail_code,

    o.ticket_taker_province,
    o.ticket_taker_city,

    o.land_type,
    o.land_type_name,

    o.booker_id,
    mb.user_name                    as booker_name,
    mb.user_type                    as booker_type,

    o.resource_center_purchase_price,
    o.booking_price,
--    coalesce(o.booking_price,0)-coalesce(o.resource_center_purchase_price,0)       as profit,
    coalesce(o.sale_price,0)-coalesce(o.resource_center_purchase_price,0)       as profit,

    o.land_topic,
    o.resource_land_id,
    o.resource_land_name,
    mb.user_is_OTA                 as resource_center_purchase_is_OTA,   

    o.cost_price,
    o.sale_price                   as sale_price
    
FROM  (-- 按唯一订单号选择记录id最大的订单，唯一订单号= 远程订单号>平台订单号(因为ota订单下单失败会重试，所以可能出现远程订单号重复订单)
       select *   from dwd_resource_center_order_d_f
       where pt="${ds}" and resource_center_supplier_is_test='正式' and resource_center_purchase_is_test='正式'
       ) o
-- join (select * from dim_user_d_f where pt="${ds}" and user_is_test='正式') ms on ms.user_id=o.resource_center_supplier_id
-- join (select * from dim_user_d_f where pt="${ds}" and user_is_test='正式') mp on mp.user_id=o.resource_center_purchase_id
----求分销链个数
left join (
    -- select order_id,count(*) as num from ods_order_aids_split_d_f 
    -- where pt="${ds}" and level =2
    -- group by order_id

    SELECT orderid, count(*) as num
    FROM ods_order_split_d_i
    WHERE orderdate > DATE_FORMAT(date_sub(TO_DATE('${ds}', 'yyyyMMdd'), 732), 'yyyyMMdd')
    AND level =2
    group by orderid
           ) a on a.orderid=o.order_id
-- 购买者信息
left join (select user_id,user_account,user_name,user_type,user_is_OTA
      from dim_user_d_f where pt="${ds}" ) mb on mb.user_id=o.booker_id
           
-- left join (select o1.order_id,count(*) as num 
--            from (select order_id from dwd_order_d_f
--                  where pt="${ds}" and  isnotnull(resource_center_supplier_id) and order_pay_status <2 ) o1
--            left join (select order_id from ods_order_aids_split_d_f where pt="${ds}" and level =2) a0 on o1.order_id=a0.order_id
--            group by o1.order_id) a on a.order_id=o.order_id
;

-- select order_id,distribute_system_name
-- from ads_resource_center_order_d_f
-- where pt='${ds}' and distribute_system_name is not null
-- group by distribute_type,distribute_system_name

-- select if(remote_order_id is null or remote_order_id='',order_id,remote_order_id) order_id,count(*) num
-- from ads_resource_center_order_d_f where  pt='${ds}'
-- group by if(remote_order_id is null or remote_order_id='',order_id,remote_order_id)
-- having num>1