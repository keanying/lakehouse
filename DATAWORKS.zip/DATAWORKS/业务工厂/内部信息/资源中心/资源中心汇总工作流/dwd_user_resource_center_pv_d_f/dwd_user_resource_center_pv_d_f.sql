-- name dwd_user_resource_center_pv_d_f
-- type SparkSQL
-- author xiaoning@12301.cc
-- create time 2021-03-04 16:29:41
-- desc 资源中心首页pv情况（神策数据）

CREATE table if not EXISTS dwd_user_resource_center_pv_d_f(
distinct_id         string COMMENT '登录id',
user_id             string COMMENT '用户id',
user_account        string COMMENT '用户帐号',
click_date          string COMMENT '浏览日期',
pv_cnt              string COMMENT '浏览次数'
)COMMENT "资源中心首页pv情况" PARTITIONED  BY (
    pt INT   
)STORED AS ORC;

INSERT OVERWRITE TABLE  dwd_user_resource_center_pv_d_f PARTITION (pt="${ds}")
select distinct a.distinct_id,a.user_id,a.user_account,a.click_date,a.pv_cnt 
from (select distinct a.distinct_id,b.user_id,b.user_account,a.click_date,a.pv_cnt 
      from ods_user_resource_center_pv_d_f a 
      join (select b.user_id,b.customer_mobile,b.user_account from dim_user_d_f b where pt='${ds}') b on a.distinct_id=b.customer_mobile
      where a.pt='${ds}' 
      UNION ALL 
      select distinct a.distinct_id,b.user_id,b.user_account,a.click_date,a.pv_cnt 
      from ods_user_resource_center_pv_d_f a 
      join (select b.user_id,b.customer_mobile,b.user_account from dim_user_d_f b where pt='${ds}') b on  a.distinct_id=b.user_account
      where a.pt='${ds}'  ) a;

