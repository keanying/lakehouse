-- name dws_resource_center_user_d_f
-- type SparkSQL
-- author linnong@12301.cc
-- create time 2019-12-30 11:54:08
-- 资源中心 商户使用情况

-- drop table if exists dws_resource_center_user_d_f;
-- alter table dws_resource_center_user_d_f add columns(distribute_system_name string COMMENT'对接分销平台名称' );
-- alter table dws_resource_center_user_d_f add columns(last_enter_resource_center  string COMMENT'最后一次登录资源中心时间' );
-- alter table dws_resource_center_user_d_f add columns(resource_center_pv_30d     int  COMMENT'近30天登录资源中心次数' );
-- alter table dws_resource_center_user_d_f add columns(supply_parent_id int comment '上级供应商户数'); 20210608修改

-- 20210626新增
-- alter table dws_resource_center_user_d_f add columns(purchase_order_num_year     int     COMMENT '采购商本年总订单数'   );
-- alter table dws_resource_center_user_d_f add columns(purchase_ticket_num_year    int     COMMENT '采购商本年总门票数'   );
-- alter table dws_resource_center_user_d_f add columns(purchase_amount_year        int     COMMENT '采购商本年总金额(元)' );
-- alter table dws_resource_center_user_d_f add columns(purchase_order_num_month_1  int     COMMENT '采购商上月总订单数'   );
-- alter table dws_resource_center_user_d_f add columns(purchase_ticket_num_month_1 int     COMMENT '采购商上月总门票数'   );
-- alter table dws_resource_center_user_d_f add columns(purchase_amount_month_1     int     COMMENT '采购商上月总金额(元)' );
-- alter table dws_resource_center_user_d_f add columns(purchase_order_num_month_1m  int     COMMENT '采购商上月同期总订单数'   );
-- alter table dws_resource_center_user_d_f add columns(purchase_ticket_num_month_1m int     COMMENT '采购商上月同期总门票数'   );
-- alter table dws_resource_center_user_d_f add columns(purchase_amount_month_1m     int     COMMENT '采购商上月同期总金额(元)' );

CREATE table if not EXISTS dws_resource_center_user_d_f(
    stat_date                             STRING  COMMENT '统计日期',
    dw_ins_time                           STRING  COMMENT '插入时间',
        
    -- 基础信息           
    user_id                               int     COMMENT '用户id',
    user_type                             STRING  COMMENT '账户类型',
    user_company_name                     string  COMMENT '企业名称',
    user_name                             string  COMMENT '账户名称',
    user_login_lasttime                   string  COMMENT '最近登录时间',
        
    customer_type                         string COMMENT '企业类型',
    enter_resource_status                 string COMMENT '入驻状态',
    settled_status                        string COMMENT '供货商入驻状态',
    purchase_settled_status               string COMMENT '采购商入驻状态',
    settled_time                          string COMMENT '供货商入驻时间',
    purchase_settled_time                 string COMMENT '采购商入驻时间',
    bond_state                            string comment '保证金状态',
    customer_service_hotline              string comment '服务热线',
    customer_mobile                       string COMMENT '手机号',
    customer_certi_status                 string COMMENT '企业资质审核状态',
    customer_province                     STRING COMMENT "客户省",
    customer_city                         STRING COMMENT "客户市",

    signer                                string  COMMENT '签单人姓名',
    enter_time                            string  COMMENT '加入资源中心时间',


    -- 拥有的自供应及一级分销 产品
    prod_num_self                         int     COMMENT '拥有产品数-自供应',
    ticket_num_self                       int     COMMENT '拥有票种数-自供应',
    prod_num_distribute_1                 int     COMMENT '拥有产品数-1级分销',
    ticket_num_distribute_1               int     COMMENT '拥有票种数-1级分销',
                    
    -- 上架产品、被采购产品
    max_add_time                          string  COMMENT '产品最大上架时间',
    min_add_time                          string  COMMENT '产品最小上架时间',
    supply_product_status                 String  COMMENT '产品上架状态',
    up_ticket_num                         int  COMMENT '上架票种数（有效）',
    up_prod_num                           int  COMMENT '上架产品数（有效）' ,
    up_ticket_num_off                     int  COMMENT '失效票种数' ,
    up_prod_num_off                       int  COMMENT '失效产品数',
    purchase_supplier_num                 int  COMMENT '资源中心采购商数（供应商类型）',
    purchase_distributor_num              int  COMMENT '资源中心采购商数（分销商类型）' ,
    purchase_ota_num                      int  COMMENT '采购商数（OTA类型）',
    distribute_product_num                int  COMMENT '分销产品数'  ,
    distribute_ticket_num                 int  COMMENT '分销票种数',
    up_prod_num_land                      int     COMMENT '上架产品数-景区',
    up_ticket_num_land                    int     COMMENT '上架票种数-景区',
    sale_fid_num_land                     int     COMMENT '采购的分销商数-景区',
    sale_prod_num_land                    int     COMMENT '被采购产品数-景区',
    sale_ticket_num_land                  int     COMMENT '被采购票种数-景区',

    up_prod_num_speciality                int     COMMENT '上架产品数-特产',
    up_ticket_num_speciality              int     COMMENT '上架票种数-特产',
    sale_fid_num_speciality               int     COMMENT '采购的分销商数-特产',
    sale_prod_num_speciality              int     COMMENT '被采购产品数-特产',
    sale_ticket_num_speciality            int     COMMENT '被采购票种数-特产',

    up_prod_num_hotel                     int     COMMENT '上架产品数-酒店',
    up_ticket_num_hotel                   int     COMMENT '上架票种数-酒店',
    sale_fid_num_hotel                    int     COMMENT '采购的分销商数-酒店',
    sale_prod_num_hotel                   int     COMMENT '被采购产品数-酒店',
    sale_ticket_num_hotel                 int     COMMENT '被采购票种数-酒店',

    -- 采购产品    
    max_purchace_time                     string  COMMENT '产品最大采购时间',
    min_purchace_time                     string  COMMENT '产品最小采购时间',
    purchase_product_status               String  COMMENT '采购产品状态',        
    buy_ticket_num                        int     COMMENT '可售采购票种数',
    buy_prod_num                          int     COMMENT '可售采购产品数',     
    buy_sid_num_land                      int     COMMENT '可售采购产品供应商数-景区',
    buy_prod_num_land                     int     COMMENT '可售采购产品数-景区',
    buy_ticket_num_land                   int     COMMENT '可售采购票种数-景区',

    buy_prod_num_land_ota                 int     comment '可售采购产品上架OTA数量-景区',  -- 上架OTA产品
    buy_prod_num_land_distribute          int     comment '可售采购产品分销下级数量-景区',   -- 转分销产品


    buy_sid_num_speciality                int     COMMENT '可售采购产品供应商数-特产',
    buy_prod_num_speciality               int     COMMENT '可售采购产品数-特产',
    buy_ticket_num_speciality             int     COMMENT '可售采购票种数-特产',

    buy_prod_num_speciality_ota           INT     comment '可售采购产品上架OTA数量-特产', 
    buy_prod_num_speciality_distribute    int     comment '可售采购产品分销下级数量-特产',


    buy_sid_num_hotel                      int     COMMENT '可售采购产品供应商数-酒店',
    buy_prod_num_hotel                     int     COMMENT '可售采购产品数-酒店',
    buy_ticket_num_hotel                   int     COMMENT '可售采购票种数-酒店',

--    buy_prod_num_hotel_ota                 INT     comment '采购产品上架OTA数量-酒店', 
--    buy_prod_num_hotel_distribute          int     comment '采购产品分销下级数量-酒店',
     

    -- 上架商产品订单情况
    max_supply_booking_time                 string  COMMENT '上架商最晚产生订单时间',
    min_supply_booking_time                 string  COMMENT '上架商最早产生订单时间',

    supply_order_num                        int comment '上架商总订单数',
    supply_ticket_num                       int comment '上架商总门票数',
    supply_amount                           int comment '上架商总金额(元)',

    supply_order_num_month                  int comment '本月上架商总订单数',
    supply_ticket_num_month                 int comment '本月上架商总门票数',
    supply_amount_month                     int comment '本月上架商总金额（元）',

    supply_order_num_30d                    int comment '近30日上架商总订单数',
    supply_ticket_num_30d                   int comment '近30日上架商总门票数',
    supply_amount_30d                       int comment '近30日上架商总金额(元)',
    
    order_prod_num_land                    int     COMMENT '上架商有订单产品数-景区',
    order_ticket_num_land                  int     COMMENT '上架商有订单票种数-景区',

    order_num_land                         int     COMMENT '上架商总订单数-景区',
    ticket_num_land                        int     COMMENT '上架商总票数-景区',
    amount_land                            bigint  COMMENT '上架商总金额-景区(元)',

    order_num_30d_land                     int     COMMENT '上架商近一月订单数-景区',
    ticket_num_30d_land                    int     COMMENT '上架商近一月票数-景区',
    amount_30d_land                        bigint  COMMENT '上架商近一月金额-景区(元)',

    --
    order_prod_num_speciality              int     COMMENT '上架商有订单产品数-特产',
    order_ticket_num_speciality            int     COMMENT '上架商有订单票种数-特产',

    order_num_speciality                   int     COMMENT '上架商总订单数-特产',
    ticket_num_speciality                  int     COMMENT '上架商总票数-特产',
    amount_speciality                      bigint  COMMENT '上架商总金额-特产(元)',

    order_num_30d_speciality               int     COMMENT '上架商近一月订单数-特产',
    ticket_num_30d_speciality              int     COMMENT '上架商近一月票数-特产',
    amount_30d_speciality                  bigint  COMMENT '上架商近一月金额-特产(元)',

    --
    order_prod_num_hotel                   int     COMMENT '上架商有订单产品数-酒店',
    order_ticket_num_hotel                 int     COMMENT '上架商有订单票种数-酒店',
 
    order_num_hotel                        int     COMMENT '上架商总订单数-酒店',
    ticket_num_hotel                       int     COMMENT '上架商总票数-酒店',
    amount_hotel                           bigint  COMMENT '上架商总金额-酒店(元)',
 
    order_num_30d_hotel                    int     COMMENT '上架商近一月订单数-酒店',
    ticket_num_30d_hotel                   int     COMMENT '上架商近一月票数-酒店',
    amount_30d_hotel                       bigint  COMMENT '上架商近一月金额-酒店(元)',

    -- 采购商订单情况
    max_purchase_booking_time                 string  COMMENT '采购商最晚产生订单时间',
    min_purchase_booking_time                 string  COMMENT '采购商最早产生订单时间',

    purchase_order_num                          int     COMMENT '采购商总订单数',
    purchase_ticket_num                         int     COMMENT '采购商总门票数',
    purchase_amount                             int     COMMENT '采购商总金额(元)',

    purchase_order_num_month                 int comment '本月采购商总订单数',
    purchase_ticket_num_month                int comment '本月采购商总票数数',
    purchase_amount_month                    int comment '本月采购商总金额（元）',

    purchase_order_num_30d                      int     COMMENT '采购商近30日总订单数',
    purchase_ticket_num_30d                     int     COMMENT '采购商近30日总门票数',
    purchase_amount_30d                         int     COMMENT '采购商近30日总金额(元)',

    purchase_order_prod_num_land           int     COMMENT '采购商有订单产品数-景区',
    purchase_order_ticket_num_land         int     COMMENT '采购商有订单票种数-景区',
    
    purchase_order_num_land                int     COMMENT '采购商总订单数-景区',
    purchase_ticket_num_land               int     COMMENT '采购商总票数-景区',
    purchase_amount_land                   bigint  COMMENT '采购商总金额-景区(元)',
    
    purchase_order_num_30d_land            int     COMMENT '采购商近一月订单数-景区',
    purchase_ticket_num_30d_land           int     COMMENT '采购商近一月票数-景区',
    purchase_amount_30d_land               bigint  COMMENT '采购商近一月金额-景区(元)',

    --
    purchase_order_prod_num_speciality     int     COMMENT '采购商有订单产品数-特产',
    purchase_order_ticket_num_speciality   int     COMMENT '采购商有订单票种数-特产',

    purchase_order_num_speciality          int     COMMENT '采购商总订单数-特产',
    purchase_ticket_num_speciality         int     COMMENT '采购商总票数-特产',
    purchase_amount_speciality             bigint  COMMENT '采购商总金额-特产(元)',

    purchase_order_num_30d_speciality      int     COMMENT '采购商近一月订单数-特产',
    purchase_ticket_num_30d_speciality     int     COMMENT '采购商近一月票数-特产',
    purchase_amount_30d_speciality         bigint  COMMENT '采购商近一月金额-特产(元)',

    --
    purchase_order_prod_num_hotel          int     COMMENT '采购商有订单产品数-酒店',
    purchase_order_ticket_num_hotel        int     COMMENT '采购商有订单票种数-酒店',

    purchase_order_num_hotel               int     COMMENT '采购商总订单数-酒店',
    purchase_ticket_num_hotel              int     COMMENT '采购商总票数-酒店',
    purchase_amount_hotel                  bigint  COMMENT '采购商总金额-酒店(元)',

    purchase_order_num_30d_hotel           int     COMMENT '采购商近一月订单数-酒店',
    purchase_ticket_num_30d_hotel          int     COMMENT '采购商近一月票数-酒店',
    purchase_amount_30d_hotel              bigint  COMMENT '采购商近一月金额-酒店(元)',

    -----用户套餐相关信息
    user_curr_package_begindate             string  COMMENT '当前套餐开始时间',
    user_curr_package_enddate               string  COMMENT '当前套餐结束时间',
    user_last_package_begindate             string  COMMENT '上个套餐开始时间',
    user_last_package_enddate               string  COMMENT '上个套餐结束时间',
    user_end_package_begindate              STRING COMMENT "用户最终套餐开始日期",
    user_end_package_enddate                string  COMMENT '用户最终套餐结束日期',
    user_group                              string  COMMENT '用户分群',
    user_account                            string  COMMENT '用户账号',
    user_status                             string  COMMENT '用户状态，有效，失效-套餐过期/模块过期/资源中心商户状态为无效',

    ----资源中心应用模块起止时间
    module_begin_time                       string  COMMENT '应用模块起始时间',
    module_end_time                         string  COMMENT '应用模块截止时间',
    module_user_status                      string  COMMENT '模块使用状态,当前/过期',
    module_status                           string  COMMENT '模块是否上下架',

    ----关联平台商家产品数
    plat_prod_num                           int  COMMENT '商家平台产品数',   
    palt_ticket_num                         int  COMMENT '商家平台票数',

    ----平台分销数ota用户数情况
    plat_dis_num                            int  COMMENT '商家平台分销数',
    plat_ota_num                            int  COMMENT '商家平台产ota数',


    ----商户标签数据
    use_mode                                string COMMENT '使用方式 采购-仅采购产品、供应-仅供应产品、双向-采购产品且供应商产品、僵尸- 未做任何采购、供应操作',
    enter_status                            string COMMENT '入驻状态 在驻-非 “未入驻” 且 套餐/资源中心模块 均未到期、过期-套餐/资源中心模块 任一到期、未入驻- “未入驻”状态',
    month_trade_active                      string COMMENT '本月交易活跃度 活跃-月订单>=100、微活跃-月订单50~100、产生交易-月订单1~50、无交易-无订单',
    month_active                            string COMMENT '本月活跃度 点击进入资源中心首页的商户',
    month_active_new                        string COMMENT '本月新增活跃度 首次点击进入资源中心首页的商户',
    activation_status                       string COMMENT '激活状态 激活-累计订单>=100、启用 -累计订单[5~100)、试用-累计订单[1~5) 或 上架/采购产品、未用-无订单 且 未上架/采购 产品',
    belong_area                             string comment '用户归属区域',
    distribute_system_name                  string comment '对接分销平台名称',

    last_enter_resource_center              string comment '最后一次登录资源中心时间',
    resource_center_pv_30d                  int    comment '近30天登录资源中心次数',
    resource_center_date_num_30d            int    comment '近30天登录资源中心次数',
    user_bind_taobao                        string comment '绑定淘宝',
    purchase_date_num_30d                   int    comment '近30天采购天数',

    supply_parent_id                        int    comment '上级供应商户数',

    --- 采购商数据补录
    purchase_order_num_year                 int     COMMENT '采购商本年总订单数',
    purchase_ticket_num_year                int     COMMENT '采购商本年总门票数',
    purchase_amount_year                    int     COMMENT '采购商本年总金额(元)',

    purchase_order_num_month_1              int     COMMENT '采购商上月总订单数',
    purchase_ticket_num_month_1             int     COMMENT '采购商上月总门票数',
    purchase_amount_month_1                 int     COMMENT '采购商上月总金额(元)',

    purchase_order_num_month_1m             int     COMMENT '采购商上月同期总订单数',
    purchase_ticket_num_month_1m            int     COMMENT '采购商上月同期总门票数',
    purchase_amount_month_1m                int     COMMENT '采购商上月同期总金额(元)'
    
)COMMENT "资源中心商户使用情况" PARTITIONED  BY (
    pt INT   
) STORED AS ORC;



-- 资源中心商户清单（过滤测试账号、员工账号）
-- 上架产品、采购产品，被采购情况
-- 商户销售情况（总订单量、OTA订单量、线下订单量、线上订单量）
INSERT OVERWRITE TABLE  dws_resource_center_user_d_f PARTITION (pt="${ds}")
select 
    "${ds}"             as stat_date,
    current_date                      as dw_ins_time,

    mr.user_id                        as user_id,
    mr.user_type                      as user_type,
    mr.user_company_name              as user_company_name,
    mr.user_name                      as user_name,
    mr.user_login_lasttime            as user_login_lasttime,

    mr.customer_type                  as customer_type,
    case when mr.enter_status = '入驻' then '入驻' 
    when (up_ticket_num+up_ticket_num_off) >0 then '续费问题导致未入驻'
    else '未入驻' end     as enter_resource_status,
    mr.settled_status                    as settled_status ,
    mr.purchase_settled_status           as purchase_settled_status,
    mr.settled_time                      as settled_time,
    mr.purchase_settled_time             as purchase_settled_time,
    mr.bond_state                        as bond_state,
    mr.customer_service_hotline       as customer_service_hotline,
    mr.customer_mobile                as customer_mobile,
    mr.customer_certi_status          as customer_certi_status,
    mr.customer_province              as customer_province,
    mr.customer_city                  as customer_city,


    mr.signer                         as signer,
    mr.enter_time                     as enter_time,

    -- 拥有的自供应及一级分销 产品
    self.prod_num_self                as prod_num_self,
    self.ticket_num_self              as ticket_num_self,

    self.prod_num_distribute_1        as prod_num_distribute_1,
    self.ticket_num_distribute_1      as ticket_num_distribute_1,

    -- 产品供应、被采购 情况
    rp.max_add_time,
    rp.min_add_time,
    case when rp.product_status>=1 then '有效' when rp.product_status=0 then '无效' end supply_product_status,
    rp.up_ticket_num,
    rp.up_prod_num,
    rp.up_ticket_num_off,
    rp.up_prod_num_off,
    rp.purchase_supplier_num,
    rp.purchase_distributor_num,
    rp.purchase_ota_num,
    rp.distribute_product_num,
    rp.distribute_ticket_num,
    rp.up_prod_num_land               as up_prod_num_land,
    rp.up_ticket_num_land             as up_ticket_num_land,
    rp.sale_fid_num_land              as sale_fid_num_land,
    rp.sale_prod_num_land             as sale_prod_num_land,
    rp.sale_ticket_num_land           as sale_ticket_num_land,

    --特产
    rp.up_prod_num_speciality         as up_prod_num_speciality,
    rp.up_ticket_num_speciality       as up_ticket_num_speciality,
    rp.sale_fid_num_speciality        as sale_fid_num_speciality,
    rp.sale_prod_num_speciality       as sale_prod_num_speciality,
    rp.sale_ticket_num_speciality     as sale_ticket_num_speciality,

    --酒店
    rp.up_prod_num_hotel              as up_prod_num_hotel,
    rp.up_ticket_num_hotel            as up_ticket_num_hotel,
    rp.sale_fid_num_hotel             as sale_fid_num_hotel,
    rp.sale_prod_num_hotel            as sale_prod_num_hotel,
    rp.sale_ticket_num_hotel          as sale_ticket_num_hotel,

    -- 采购产品、分销下级、上架ota情况
    pur.max_purchace_time,
    pur.min_purchace_time,
    case when pur.purchase_status>=1 then '有效' when  pur.purchase_status= 0 then '无效' end purchase_product_status,
    pur.buy_ticket_num,
    pur.buy_prod_num,
    pur.buy_sid_num_land              as buy_sid_num_land,
    pur.buy_prod_num_land             as buy_prod_num_land,
    pur.buy_ticket_num_land           as buy_ticket_num_land,

    pur.buy_prod_num_land_ota         as buy_prod_num_land_ota, 
    pur.buy_prod_num_land_distribute  as buy_prod_num_land_distribute, 

    pur.buy_sid_num_speciality        as buy_sid_num_speciality,
    pur.buy_prod_num_speciality       as buy_prod_num_speciality,
    pur.buy_ticket_num_speciality     as buy_ticket_num_speciality,

    pur.buy_prod_num_speciality_ota         as buy_prod_num_speciality_ota, 
    pur.buy_prod_num_speciality_distribute  as buy_prod_num_speciality_distribute, 

    pur.buy_sid_num_hotel             as buy_sid_num_hotel,
    pur.buy_prod_num_hotel            as buy_prod_num_hotel,
    pur.buy_ticket_num_hotel          as buy_ticket_num_hotel,

--    pur.buy_prod_num_hotel_ota         as buy_prod_num_hotel_ota, 
--    pur.buy_prod_num_hotel_distribute  as buy_prod_num_hotel_distribute, 


    -- 供应商订单
    os.max_supply_booking_time,
    os.min_supply_booking_time,
    
    nvl(os.supply_order_num,0) as supply_order_num,
    nvl(os.supply_ticket_num,0) as supply_ticket_num,
    nvl(os.supply_amount,0) as supply_amount,

    nvl(os.supply_order_num_month,0),
    nvl(os.supply_ticket_num_month,0),
    nvl(os.supply_amount_month,0),

    nvl(os.supply_order_num_30d,0),
    nvl(os.supply_ticket_num_30d,0),
    nvl(os.supply_amount_30d,0),

    os.order_prod_num_land            as order_prod_num_land,
    os.order_ticket_num_land          as order_ticket_num_land,
    os.order_num_land                 as order_num_land,
    os.ticket_num_land                as ticket_num_land,
    os.amount_land                    as amount_land,
    os.order_num_30d_land             as order_num_30d_land,
    os.ticket_num_30d_land            as ticket_num_30d_land,
    os.amount_30d_land                as amount_30d_land, 

    os.order_prod_num_speciality      as order_prod_num_speciality,
    os.order_ticket_num_speciality    as order_ticket_num_speciality,
    os.order_num_speciality           as order_num_speciality,
    os.ticket_num_speciality          as ticket_num_speciality,
    os.amount_speciality              as amount_speciality,
    os.order_num_30d_speciality       as order_num_30d_speciality,
    os.ticket_num_30d_speciality      as ticket_num_30d_specialityd,
    os.amount_30d_speciality          as amount_30d_speciality,    

    os.order_prod_num_hotel           as order_prod_num_hotel,
    os.order_ticket_num_hotel         as order_ticket_num_hotel,
    os.order_num_hotel                as order_num_hotel,
    os.ticket_num_hotel               as ticket_num_hotel,
    os.amount_hotel                   as amount_hotel,
    os.order_num_30d_hotel            as order_num_30d_hotel,
    os.ticket_num_30d_hotel           as ticket_num_30d_hotel,
    os.amount_30d_hotel               as amount_30d_hotel,

    -- 采购商订单情况
    op.max_purchase_booking_time,
    op.min_purchase_booking_time,

    if(op.purchase_order_num>0,op.purchase_order_num,0)             as purchase_order_num,
    if(op.purchase_ticket_num>0,op.purchase_ticket_num,0)           as purchase_ticket_num,
    if(op.purchase_amount>0,op.purchase_amount,0)                   as purchase_amount,

    nvl(op.purchase_order_num_month,0),
    nvl(op.purchase_ticket_num_month,0),
    nvl(op.purchase_amount_month,0),

    if(op.purchase_order_num_30d>0,op.purchase_order_num_30d,0)     as purchase_order_num_30d,
    if(op.purchase_ticket_num_30d>0,op.purchase_ticket_num_30d,0)   as purchase_ticket_num_30d,
    if(op.purchase_amount_30d>0,op.purchase_amount_30d,0)           as purchase_amount_30d,

    op.purchase_order_prod_num_land            as purchase_order_prod_num_land,
    op.purchase_order_ticket_num_land          as purchase_order_ticket_num_land,
    op.purchase_order_num_land                 as purchase_order_num_land,
    op.purchase_ticket_num_land                as purchase_ticket_num_land,
    op.purchase_amount_land                    as purchase_amount_land,
    op.purchase_order_num_30d_land             as purchase_order_num_30d_land,
    op.purchase_ticket_num_30d_land            as purchase_ticket_num_30d_land,
    op.purchase_amount_30d_land                as purchase_amount_30d_land, 

    op.purchase_order_prod_num_speciality      as purchase_order_prod_num_speciality,
    op.purchase_order_ticket_num_speciality    as purchase_order_ticket_num_speciality,
    op.purchase_order_num_speciality           as purchase_order_num_speciality,
    op.purchase_ticket_num_speciality          as purchase_ticket_num_speciality,
    op.purchase_amount_speciality              as purchase_amount_speciality,
    op.purchase_order_num_30d_speciality       as purchase_order_num_30d_speciality,
    op.purchase_ticket_num_30d_speciality      as purchase_ticket_num_30d_specialityd,
    op.purchase_amount_30d_speciality          as purchase_amount_30d_speciality,    

    op.purchase_order_prod_num_hotel           as purchase_order_prod_num_hotel,
    op.purchase_order_ticket_num_hotel         as purchase_order_ticket_num_hotel,
    op.purchase_order_num_hotel                as purchase_order_num_hotel,
    op.purchase_ticket_num_hotel               as purchase_ticket_num_hotel,
    op.purchase_amount_hotel                   as purchase_amount_hotel,
    op.purchase_order_num_30d_hotel            as purchase_order_num_30d_hotel,
    op.purchase_ticket_num_30d_hotel           as purchase_ticket_num_30d_hotel,
    op.purchase_amount_30d_hotel               as purchase_amount_30d_hotel,
    
    -----用户套餐相关信息
    cm.user_curr_package_begin_date            as user_curr_package_begindate,
    cm.user_curr_package_end_date              as user_curr_package_enddate,
    cm.user_last_package_begin_date            as user_last_package_begindate,
    cm.user_last_package_end_date              as user_last_package_enddate,
    cm.user_end_package_begin_date             as user_end_package_begindate,
    cm.user_end_package_end_date               as user_end_package_enddate,
    cm.user_group,
    mr.user_account,
    case 
       when mr.attr_status=0 or cm.user_end_package_end_date<current_date or md.end_time<current_date then '无效'
       else '有效'
    end                                     as user_status,

    ----应用模块起止时间
    md.begin_time                           as module_begin_time,
    md.end_time                             as module_end_time,
    md.module_user_status                   as module_user_status,
    case 
       when md.module_status=1 then '上架' 
       when md.module_status=0  then '下架' 
    end                                     as module_status,

    ----平台商家产品情况
    pro.land_num                            as plat_prod_num,
    pro.ticket_num                          as plat_ticket_num,

    ----平台分销商ota用户数
    rel.plat_dis_num,
    rel.plat_ota_num,

    ----商户标签数据
    case 
        when rp.up_prod_num>0 and pur.buy_prod_num>0 then '双向' 
        when rp.up_prod_num>0 then '供应'
        when pur.buy_prod_num>0 then '采购'
        else '僵尸'
    end use_mode,     
    case 
        when cm.user_end_package_end_date<=now() or md.end_time<=now() then '过期'
        when mr.enter_status='未入驻' then '未入驻'
        when (mr.enter_status = '入驻'  or (if(up_ticket_num>0,up_ticket_num,0)+if(up_ticket_num_off>0,up_ticket_num_off,0) >0)) 
              and cm.user_end_package_end_date>now() and md.end_time>now() then '在驻' 
--        else '未入驻'
    end enter_status         ,     
    case 
       when if(os.supply_order_num_month>0,os.supply_order_num_month,0)+if(op.purchase_order_num_month>0,op.purchase_order_num_month,0)>=100 then '活跃'
       when if(os.supply_order_num_month>0,os.supply_order_num_month,0)+if(op.purchase_order_num_month>0,op.purchase_order_num_month,0)>=50 then '微活跃'
       when if(os.supply_order_num_month>0,os.supply_order_num_month,0)+if(op.purchase_order_num_month>0,op.purchase_order_num_month,0)>=1 then '产生交易'
    else '无交易'
    end month_trade_active   ,
    if(pv.max_click_date>=trunc(date_sub(current_date,1),'MM') ,'活跃','非活跃') month_active,
    if(pv.min_click_date>=trunc(date_sub(current_date,1),'MM') ,'活跃','非活跃') month_active_new,
    case 
        when if(os.supply_order_num>0,os.supply_order_num,0)+if(op.purchase_order_num>0,op.purchase_order_num,0)>=100 then '激活' 
        when if(os.supply_order_num>0,os.supply_order_num,0)+if(op.purchase_order_num>0,op.purchase_order_num,0)>=5 then '启用'
        when if(os.supply_order_num>0,os.supply_order_num,0)+if(op.purchase_order_num>0,op.purchase_order_num,0)>=1 or rp.supply_user_id is not null or pur.purchase_status>=1 then '试用'
        else '未用'
    end activation_status,
    di.district                              as belong_area  ,
    mr.distribute_system_name                as distribute_system_name,

    pv.max_click_date                        as last_enter_resource_center,
    pv.pv_30d                                as resource_center_pv_30d,
    pv.date_num_30d                          as resource_center_date_num_30d,
    mr.user_bind_taobao,
    pur.purchase_date_num_30d,

    nvl(mem.supply_parent_id,0) as  supply_parent_id,

    -- 采购商数据补录

    nvl(op.purchase_order_num_year,0)  ,
    nvl(op.purchase_ticket_num_year,0) ,
    nvl(op.purchase_amount_year,0) ,

    nvl(op.purchase_order_num_month_1,0) ,
    nvl(op.purchase_ticket_num_month_1,0) ,
    nvl(op.purchase_amount_month_1,0),

    nvl(op.purchase_order_num_month_1m,0) ,
    nvl(op.purchase_ticket_num_month_1m,0) ,
    nvl(op.purchase_amount_month_1m,0)             

-- 已过滤测试账号
from (select * from dim_resource_center_user_d_f
      where pt="${ds}")  mr
-- 自身拥有的自供应产品及 一级分销产品
left join(SELECT distributor_id, 
                 count(distinct if(distribute_level=0,land_id,null)) prod_num_self,
                 count(distinct if(distribute_level=0,ticket_id,null)) ticket_num_self,

                 count(distinct if(distribute_level=1,land_id,null)) prod_num_distribute_1,
                 count(distinct if(distribute_level=1,ticket_id,null)) ticket_num_distribute_1
          from dim_prod_distribute_d_f 
          where pt="${ds}" and distribute_level<2
          group by distributor_id
) self on self.distributor_id=mr.user_id
-- 上架、被采购情况
left join (select supply_user_id,
                  max(max_add_time) as max_add_time,
                  min(add_time) as min_add_time,
                  sum(case when product_status='上架' then 1 else 0 end) as product_status,
                  count(distinct if(resource_product_status='上架' and product_status='上架' and ticket_max_expiration_date> now(),ticket_id,null)) as up_ticket_num,
                  count(distinct if(resource_product_status='上架' and product_status='上架' and ticket_max_expiration_date> now(),land_id,null)) as up_prod_num,
                  count(distinct if(resource_product_status<>'上架' or product_status<>'上架' or ticket_max_expiration_date<= now(),ticket_id,null)) as up_ticket_num_off,
                  count(distinct if(resource_product_status<>'上架' or product_status<>'上架' or ticket_max_expiration_date<= now(),land_id,null)) as up_prod_num_off,

                  count(distinct if(b.user_type='供应商',purchase_user_id,null)) as purchase_supplier_num,
                  count(distinct if(b.user_type='分销商',purchase_user_id,null)) as purchase_distributor_num,
                  COUNT(distinct if(b.user_is_OTA='OTA',purchase_user_id,null)) as purchase_ota_num,
                  
                  count(distinct if(purchase_distribute_num > 1,land_id,null))                                                  as distribute_product_num,
                  count(distinct if(purchase_distribute_num > 1,ticket_id,null))                                                  as distribute_ticket_num,
                

                  count(distinct if(resource_product_status='上架' and land_type_name='景区',land_id,null))                            as up_prod_num_land,
                  count(distinct if(resource_product_status='上架' and land_type_name='景区',ticket_id,null))                          as up_ticket_num_land, 
                  count(distinct if(resource_product_status='上架' and land_type_name='景区',purchase_user_id,null))                   as sale_fid_num_land,
                  count(distinct if(resource_product_status='上架' and land_type_name='景区' and purchace_status='已采购',land_id,null))      as sale_prod_num_land,
                  count(distinct if(resource_product_status='上架' and land_type_name='景区' and purchace_status='已采购',ticket_id,null))    as sale_ticket_num_land,

                  count(distinct if(resource_product_status='上架' and land_type_name='特产',land_id,null))                            as up_prod_num_speciality,
                  count(distinct if(resource_product_status='上架'and land_type_name='特产',ticket_id,null))                          as up_ticket_num_speciality, 
                  count(distinct if(resource_product_status='上架' and land_type_name='特产',purchase_user_id,null))                   as sale_fid_num_speciality,
                  count(distinct if(resource_product_status='上架' and land_type_name='特产' and purchace_status='已采购',land_id,null))      as sale_prod_num_speciality,
                  count(distinct if(resource_product_status='上架' and land_type_name='特产' and purchace_status='已采购',ticket_id,null))    as sale_ticket_num_speciality,

                  count(distinct if(resource_product_status='上架' and land_type_name='酒店',land_id,null))                            as up_prod_num_hotel,
                  count(distinct if(resource_product_status='上架' and land_type_name='酒店',ticket_id,null))                          as up_ticket_num_hotel,
                  count(distinct if(resource_product_status='上架' and land_type_name='酒店',purchase_user_id,null))                   as sale_fid_num_hotel,
                  count(distinct if(resource_product_status='上架' and land_type_name='酒店' and purchace_status='已采购',land_id,null))      as sale_prod_num_hotel,
                  count(distinct if(resource_product_status='上架' and land_type_name='酒店' and purchace_status='已采购',ticket_id,null))    as sale_ticket_num_hotel

                  -- count(distinct if(status=0,land_id,null)) down_land_num_land,
                  -- count(distinct if(status=0,ticket_id,null)) down_ticket_num_land, 

           from dim_resource_center_purchase_d_f a 
           left join dim_user_d_f b on a.purchase_user_id=b.user_id and b.pt="${ds}"
           where a.pt="${ds}" 
           group by a.supply_user_id) rp on rp.supply_user_id=mr.user_id
--采购情况           
left join (select purchase_user_id,
                  max(purchase_time) as max_purchace_time,
                  min(purchase_time) as min_purchace_time,
                  count(distinct if(purchase_time>date_sub(current_date,30),to_date(purchase_time),null))      as purchase_date_num_30d,
                  sum(case when purchace_status='已采购' then '1' else 0 end)                                 as purchase_status,

                  count(distinct if(purchace_status='已采购' and product_status='上架',ticket_id,null))       as buy_ticket_num,
                  count(distinct if(purchace_status='已采购' and product_status='上架',land_id,null))         as buy_prod_num,
                  count(distinct if(land_type_name='景区' and purchace_status='已采购' and product_status='上架',supply_user_id,null))     as buy_sid_num_land,
                  count(distinct if(land_type_name='景区' and purchace_status='已采购' and product_status='上架',land_id,null))            as buy_prod_num_land,
                  count(distinct if(land_type_name='景区' and purchace_status='已采购' and product_status='上架',ticket_id,null))          as buy_ticket_num_land, 

                  count(distinct if(land_type_name='景区' and purchase_ota_num>0 and purchace_status='已采购' and product_status='上架',land_id,0))            as buy_prod_num_land_ota, 
                  count(distinct if(land_type_name='景区' and purchase_distribute_num>0 and purchace_status='已采购' and product_status='上架',land_id,null))  as buy_prod_num_land_distribute, 


                  count(distinct if(land_type_name='特产' and purchace_status='已采购' and product_status='上架',supply_user_id,null))     as buy_sid_num_speciality,
                  count(distinct if(land_type_name='特产' and purchace_status='已采购' and product_status='上架',land_id,null))            as buy_prod_num_speciality,
                  count(distinct if(land_type_name='特产' and purchace_status='已采购' and product_status='上架',ticket_id,null))          as buy_ticket_num_speciality,

                  count(distinct if(land_type_name='特产' and purchase_ota_num>0 and purchace_status='已采购' and product_status='上架',land_id,0))            as buy_prod_num_speciality_ota, 
                  count(distinct if(land_type_name='特产' and purchase_distribute_num>0 and purchace_status='已采购' and product_status='上架',land_id,null))  as buy_prod_num_speciality_distribute, 


                  count(distinct if(land_type_name='酒店' and purchace_status='已采购' and product_status='上架',supply_user_id,null))     as buy_sid_num_hotel,
                  count(distinct if(land_type_name='酒店' and purchace_status='已采购' and product_status='上架',land_id,null))            as buy_prod_num_hotel,
                  count(distinct if(land_type_name='酒店' and purchace_status='已采购' and product_status='上架',ticket_id,null))          as buy_ticket_num_hotel,

                  count(distinct if(land_type_name='酒店' and purchase_ota_num>0 and purchace_status='已采购' and product_status='上架',land_id,0))            as buy_prod_num_hotel_ota, 
                  count(distinct if(land_type_name='酒店' and purchase_distribute_num>0 and purchace_status='已采购' and product_status='上架',land_id,null))  as buy_prod_num_hotel_distribute

                  -- count(distinct if(status=0,p1.sid,null)) cancel_buy_sid_num,
                  -- count(distinct if(status=0,t.landid,null)) cancel_buy_land_num,
                  -- count(distinct if(status=0,p1.ticket_id,null)) cancel_buy_ticket_num
           from dim_resource_center_purchase_d_f  
           where pt="${ds}" and purchace_status<>'未采购'
           group by purchase_user_id ) pur on pur.purchase_user_id=mr.user_id
           
--供货商订单情况           
left join (select resource_center_supplier_id,
                  max(booking_time) as max_supply_booking_time,
                  min(booking_time) as min_supply_booking_time,
                  count(DISTINCT order_id)  as supply_order_num,
                  sum(ticket_num) as supply_ticket_num,
                  sum(order_pay_amount)/100 as supply_amount,
                  
                  ---本月订单情况
                  count(if(booking_time>=trunc(date_sub(current_date,1),'MM'),order_id,null))        as supply_order_num_month,
                  sum(if(booking_time>=trunc(date_sub(current_date,1),'MM'),ticket_num,0))           as supply_ticket_num_month,
                  sum(if(booking_time>=trunc(date_sub(current_date,1),'MM'),order_pay_amount,0))/100     as supply_amount_month,  

                  ---近30日订单情况
                  count(if(booking_time>=date_sub(current_date,30),order_id,null))        as supply_order_num_30d,
                  sum(if(booking_time>=date_sub(current_date,30),ticket_num,0))           as supply_ticket_num_30d,
                  sum(if(booking_time>=date_sub(current_date,30),order_pay_amount,0))/100     as supply_amount_30d,

                  count(if(land_type_name='景区',land_id,null))         as order_prod_num_land,
                  count(if(land_type_name='景区',ticket_id,null))       as order_ticket_num_land,

                  count(if(land_type_name='景区',order_id,null))        as order_num_land,
                  sum(if(land_type_name='景区',ticket_num,0))           as ticket_num_land,
                  sum(if(land_type_name='景区',order_pay_amount,0))/100     as amount_land,

                  count(if(land_type_name='景区' and booking_time>=date_sub(current_date,30),order_id,null))        as order_num_30d_land,
                  sum(if(land_type_name='景区' and booking_time>=date_sub(current_date,30),ticket_num,0))           as ticket_num_30d_land,
                  sum(if(land_type_name='景区' and booking_time>=date_sub(current_date,30),order_pay_amount,0))/100     as amount_30d_land,

                  --
                  count(if(land_type_name='特产',land_id,null))         as order_prod_num_speciality,
                  count(if(land_type_name='特产',ticket_id,null))       as order_ticket_num_speciality,

                  count(if(land_type_name='特产',order_id,null))        as order_num_speciality,
                  sum(if(land_type_name='特产',ticket_num,0))           as ticket_num_speciality,
                  sum(if(land_type_name='特产',order_pay_amount,0))/100     as amount_speciality,

                  count(if(land_type_name='特产' and booking_time>=date_sub(current_date,30),order_id,null))        as order_num_30d_speciality,
                  sum(if(land_type_name='特产' and booking_time>=date_sub(current_date,30),ticket_num,0))           as ticket_num_30d_speciality,
                  sum(if(land_type_name='特产' and booking_time>=date_sub(current_date,30),order_pay_amount,0))/100     as amount_30d_speciality,

                  --
                  count(if(land_type_name='酒店',land_id,null))         as order_prod_num_hotel,
                  count(if(land_type_name='酒店',ticket_id,null))       as order_ticket_num_hotel,

                  count(if(land_type_name='酒店',order_id,null))        as order_num_hotel,
                  sum(if(land_type_name='酒店',ticket_num,0))           as ticket_num_hotel,
                  sum(if(land_type_name='酒店',order_pay_amount,0))/100     as amount_hotel,

                  count(if(land_type_name='酒店' and booking_time>=date_sub(current_date,30),order_id,null))        as order_num_30d_hotel,
                  sum(if(land_type_name='酒店' and booking_time>=date_sub(current_date,30),ticket_num,0))           as ticket_num_30d_hotel,
                  sum(if(land_type_name='酒店' and booking_time>=date_sub(current_date,30),order_pay_amount,0))/100     as amount_30d_hotel

           from (select booking_time,order_id,ticket_num,booking_pay_amount as order_pay_amount,
                        land_type_name,land_id,ticket_id,resource_center_supplier_id,resource_center_purchase_id 
                 from dwd_resource_center_order_d_f
                 where pt="${ds}"and booking_time>='2020-02-24' 
                 )  o1
           join (select user_id from dim_user_d_f where pt="${ds}" and user_is_test='正式') ms on ms.user_id=o1.resource_center_purchase_id
           group by o1.resource_center_supplier_id)  os on os.resource_center_supplier_id=mr.user_id         
--采购商订单情况           
left join (select resource_center_purchase_id,
                  max(booking_time) as max_purchase_booking_time,
                  min(booking_time) as min_purchase_booking_time,
                  
                  count(DISTINCT order_id)  as purchase_order_num,
                  sum(ticket_num) as purchase_ticket_num,
                  sum(order_pay_amount)/100 as purchase_amount,

                ---本月订单情况
                  count(if(booking_time>=trunc(date_sub(current_date,1),'MM'),order_id,null))        as purchase_order_num_month,
                  sum(if(booking_time>=trunc(date_sub(current_date,1),'MM'),ticket_num,0))           as purchase_ticket_num_month,
                  sum(if(booking_time>=trunc(date_sub(current_date,1),'MM'),order_pay_amount,0))/100     as purchase_amount_month,

                ---近30日订单情况    
                  count(if(booking_time>=date_sub(current_date,30),order_id,null))        as purchase_order_num_30d,
                  sum(if(booking_time>=date_sub(current_date,30),ticket_num,0))           as purchase_ticket_num_30d,
                  sum(if(booking_time>=date_sub(current_date,30),order_pay_amount,0))/100     as purchase_amount_30d,

                --- 本年订单情况
                  count(if(booking_time>=trunc(date_sub(current_date,1),'YY'),order_id,null))        as purchase_order_num_year,
                  sum(if(booking_time>=trunc(date_sub(current_date,1),'YY'),ticket_num,0))           as purchase_ticket_num_year,
                  sum(if(booking_time>=trunc(date_sub(current_date,1),'YY'),order_pay_amount,0))/100     as purchase_amount_year,

                --- 上月订单情况
                  count(if(booking_time>=trunc(add_months(date_sub(current_date,1),-1),'MM') and booking_time<=date_add(trunc(date_sub(current_date,1),'MM'),-1),order_id,null))        as purchase_order_num_month_1,
                  sum(if(booking_time>=trunc(add_months(date_sub(current_date,1),-1),'MM') and booking_time<=date_add(trunc(date_sub(current_date,1),'MM'),-1),ticket_num,0))           as purchase_ticket_num_month_1,
                  sum(if(booking_time>=trunc(add_months(date_sub(current_date,1),-1),'MM') and booking_time<=date_add(trunc(date_sub(current_date,1),'MM'),-1),order_pay_amount,0))/100     as purchase_amount_month_1,

                --- 上月同期订单情况
                  count(if(booking_time>=trunc(add_months(date_sub(current_date,1),-1),'MM') and booking_time<=add_months(date_sub(current_date,1),-1),order_id,null))        as purchase_order_num_month_1m,
                  sum(if(booking_time>=trunc(add_months(date_sub(current_date,1),-1),'MM') and booking_time<=add_months(date_sub(current_date,1),-1),ticket_num,0))           as purchase_ticket_num_month_1m,
                  sum(if(booking_time>=trunc(add_months(date_sub(current_date,1),-1),'MM') and booking_time<=add_months(date_sub(current_date,1),-1),order_pay_amount,0))/100     as purchase_amount_month_1m,

                  count(if(land_type_name='景区',land_id,null))                  as purchase_order_prod_num_land,
                  count(if(land_type_name='景区',ticket_id,null))                as purchase_order_ticket_num_land,
                  count(if(land_type_name='景区',order_id,null))                 as purchase_order_num_land,
                  sum(if(land_type_name='景区',ticket_num,0))                    as purchase_ticket_num_land,
                  sum(if(land_type_name='景区',order_pay_amount,0))/100              as purchase_amount_land,
                  count(if(land_type_name='景区' and booking_time>=date_sub(current_date,30),order_id,null))        as purchase_order_num_30d_land,
                  sum(if(land_type_name='景区' and booking_time>=date_sub(current_date,30),ticket_num,0))           as purchase_ticket_num_30d_land,
                  sum(if(land_type_name='景区' and booking_time>=date_sub(current_date,30),order_pay_amount,0))/100     as purchase_amount_30d_land,
                  
                  count(if(land_type_name='特产',land_id,null))                  as purchase_order_prod_num_speciality,
                  count(if(land_type_name='特产',ticket_id,null))                as purchase_order_ticket_num_speciality,
                  count(if(land_type_name='特产',order_id,null))                 as purchase_order_num_speciality,
                  sum(if(land_type_name='特产',ticket_num,0))                    as purchase_ticket_num_speciality,
                  sum(if(land_type_name='特产',order_pay_amount,0))/100              as purchase_amount_speciality,
                  count(if(land_type_name='特产' and booking_time>=date_sub(current_date,30),order_id,null))        as purchase_order_num_30d_speciality,
                  sum(if(land_type_name='特产' and booking_time>=date_sub(current_date,30),ticket_num,0))           as purchase_ticket_num_30d_speciality,
                  sum(if(land_type_name='特产' and booking_time>=date_sub(current_date,30),order_pay_amount,0))/100     as purchase_amount_30d_speciality,

                  count(if(land_type_name='酒店',land_id,null))                  as purchase_order_prod_num_hotel,
                  count(if(land_type_name='酒店',ticket_id,null))                as purchase_order_ticket_num_hotel,
                  count(if(land_type_name='酒店',order_id,null))                 as purchase_order_num_hotel,
                  sum(if(land_type_name='酒店',ticket_num,0))                    as purchase_ticket_num_hotel,
                  sum(if(land_type_name='酒店',order_pay_amount,0))/100              as purchase_amount_hotel,
                  count(if(land_type_name='酒店' and booking_time>=date_sub(current_date,30),order_id,null))        as purchase_order_num_30d_hotel,
                  sum(if(land_type_name='酒店' and booking_time>=date_sub(current_date,30),ticket_num,0))           as purchase_ticket_num_30d_hotel,
                  sum(if(land_type_name='酒店' and booking_time>=date_sub(current_date,30),order_pay_amount,0))/100     as purchase_amount_30d_hotel

           from (select booking_time,order_id,ticket_num,booking_pay_amount as order_pay_amount,
                        land_type_name,land_id,ticket_id,resource_center_supplier_id,resource_center_purchase_id 
                 from dwd_resource_center_order_d_f
                 where pt="${ds}" and booking_time>='2020-02-24'
                 ) o2
           join (select user_id from dim_user_d_f where pt="${ds}" and user_is_test='正式') ms1 on ms1.user_id=o2.resource_center_supplier_id
           group by o2.resource_center_purchase_id)  op on op.resource_center_purchase_id=mr.user_id  
-----关联用户套餐情况
left join  dws_company_package_d_f cm on cm.user_id=mr.user_id and cm.pt="${ds}"
-----关联应用模块起止日期
left join  dim_user_module_d_f md on md.user_id=mr.user_id and md.pt="${ds}" and md.module_name="资源中心"
-----关联平台商家产品数
left join (select land_publisher_id,count(distinct land_id) as land_num,count(distinct ticket_id) as ticket_num 
                from dim_prod_d_f 
                    where pt="${ds}" and ticket_status in ('上架','新增') and ticket_max_expiration_date>now() group by land_publisher_id) pro on pro.land_publisher_id=mr.user_id 
-- 关联平台情况
left join (select parent_id,count(if(son_type='分销商',son_id,null)) as plat_dis_num,count(if(son_type='OTA',son_id,null)) as plat_ota_num from dim_user_relationship_d_f where pt="${ds}" and relationship_type=0 group by parent_id)  rel on rel.parent_id=mr.user_id
-- 关联归属区域
left join dim_resource_center_district_o_f di on mr.customer_province=di.province
-- 关联神策访问资源中心首页数据
left join (select user_id,min(click_date) as min_click_date,max(click_date) as max_click_date,
                  sum(if(click_date>=date_sub(current_date,30),pv_cnt,0))  pv_30d,
                  count(distinct if(click_date>=date_sub(current_date,30),to_date(click_date),null))  date_num_30d
           from dwd_user_resource_center_pv_d_f a where pt="${ds}" 
           group by user_id)  pv on pv.user_id=mr.user_id
-- 关联商上级供应商
left join (select son_id,count(distinct parent_id) supply_parent_id from dim_user_relationship_d_f where  pt="${ds}" and relationship_type in (0,4) group by son_id) mem on mr.user_id= mem.son_id
;

-- ======================================================
-- select *
-- from dws_resource_center_user_d_f
-- where pt='${ds}' and user_id in (1076195,4397391)

-- select user_id,user_name
-- from dim_user_d_f where pt="${ds}" and user_is_test='正式' and user_id in (1076195,4397391)