-- name dws_user_report_order_month_d_f
-- type SparkSQL
-- author linnong@12301.cc
-- create time 2020-06-09 17:31:59
-- desc 商户月订单情况，含转分销

-- drop table if exists dws_user_report_order_month_d_f;

CREATE TABLE if NOT EXISTS dws_user_report_order_month_d_f(
      user_id                           int     COMMENT '用户ID',
      order_month                       STRING  COMMENT '月份：2020-02',
      order_num                         int     COMMENT '预订订单数',
      order_num_self                    int     COMMENT '自供应预订订单数',
      order_num_micro_shop              INT     COMMENT '预定订单数-微商城',
      order_num_plat_direct             INT     COMMENT '预定订单数-平台',
      order_num_resource_center         INT     COMMENT '预定订单数-资源中心',
      order_num_ota                     INT     COMMENT '预定订单数-ota',
      
      order_ticket                      int     COMMENT '预订门票数',
      order_ticket_self                 int     COMMENT '自供应预订门票数',
      order_ticket_micro_shop           INT     COMMENT '预定门票数-微商城',
      order_ticket_plat_direct          INT     COMMENT '预定门票数-平台',
      order_ticket_resource_center      INT     COMMENT '预定门票数-资源中心',
      order_ticket_ota                  INT     COMMENT '预定门票数-ota',

      sale_money                        bigint  COMMENT '预定金额',
      sale_money_self                   bigint  COMMENT '自供应预定金额',
      sale_money_micro_shop             BIGINT  COMMENT '预定金额-微商城',
      sale_money_plat_direct            BIGINT  COMMENT '预定金额-平台',
      sale_money_resource_center        BIGINT  COMMENT '预定金额-资源中心',
      sale_money_ota                    BIGINT  COMMENT '预定金额-ota',

      active_level                      int     comment '活跃度，票数在0~250：0,251~300：1,301~：2'

)COMMENT "用户预定月汇总" PARTITIONED by(
    pt INT
)STORED AS ORC;

--drop table user_order_month_resource_center_tmp;

-- CREATE TABLE if NOT EXISTS user_order_month_resource_center_tmp(
--       fid                               int     COMMENT '用户ID',
--       order_date                        string  COMMENT '日期',
--       order_num_resource_center         INT     COMMENT '预定订单数-资源中心',
--       ticket_num_resource_center        INT     COMMENT '预定门票数-资源中心',
--       booking_amount_resource_center     BIGINT  COMMENT '预定金额-资源中心'

-- )COMMENT "用户月资源中心订单量" 
-- LIFECYCLE 999;


-- -- 资源中心订单量
-- INSERT OVERWRITE table user_order_month_resource_center_tmp 
-- select o2.fid                            as fid,
--        o2.`date`                         as order_date,
--        count(*)                          as order_num_resource_center,
--        sum(ro.booking_num)               as ticket_num_resource_center,
--        sum(ro.booking_pay_amount)        as booking_amount_resource_center
-- --from (select o.fid,o.`date`,translate(translate(split(o.order_id,',')[0],'[',''),'"','') order_id
-- from (select o.fid,o.`date`,split(o.order_id,',')[0] order_id
--       from (
--             select fid,`date`,explode(split(orders_info,'],')) order_id  
--             from  data_middle_bi.dwd_pft_report_order_two_d_f
--             where pt='${ds}' and `date`>date_format('${ds}','YYYY-01-01')) o
--             ) o2
-- join ( select * from  data_middle_bi.dwd_resource_center_order_d_f 
--        where pt='${ds}' and booking_time>date_format('${ds}','YYYY-01-01') ) ro on o2.order_id like concat('%,ro.order_id,%')
-- --       where pt='20210428' and booking_time>date_format('${ds}','YYYY-01-01') ) ro on ro.order_id=o2.order_id
-- group by o2.fid,o2.`date`
-- ;



INSERT OVERWRITE table dws_user_report_order_month_d_f PARTITION (pt="${ds}")
SELECT
    o1.fid                                                              as user_id,
    substr(o1.booking_date,1,7)                                         as order_month,

    sum(o1.order_num)                                                   as order_num,    
    sum(o1.order_num_self)                                              as order_num_self,    
    sum(o1.order_num_micro_shop)                                        as order_num_micro_shop,    
    sum(o1.order_num_plat_b)                                            as order_num_plat_direct, 
    sum(r1.order_num_resource_center)                                   as order_num_resource_center,
    sum(o1.order_num_OTA)                                               as order_num_OTA,    

    sum(o1.ticket_num)                                                  as order_ticket, 
    sum(o1.ticket_num_self)                                             as order_ticket_self, 
    sum(o1.ticket_num_micro_shop)                                       as order_ticket_micro_shop,    
    sum(o1.ticket_num_plat_b)                                           as order_ticket_plat_direct, 
    sum(r1.ticket_num_resource_center)                                  as order_ticket_resource_center,
    sum(o1.ticket_num_OTA)                                              as ticket_num_OTA,    

    sum(o1.booking_amount)                                              as sale_money,
    sum(o1.booking_amount_self)                                         as sale_money_self,
    sum(o1.booking_amount_micro_shop)                                   as sale_money_micro_shop,    
    sum(o1.booking_amount_direct)                                       as sale_money_plat_direct, 
    sum(r1.booking_amount_resource_center)                              as sale_money_resource_center,
    sum(o1.booking_amount_OTA)                                          as sale_money_OTA,

    case 
       when sum(o1.ticket_num)>728  then 2
       when sum(o1.ticket_num)>250  then 1
       else 0
    END                                    as active_level

from (select fid,
             CONCAT(
                  SUBSTR(o.`date`,1,4),
                  '-',
                  SUBSTR(o.`date`,5,2),
                  '-',
                  SUBSTR(o.`date`,7,2)
            )                                                       as booking_date,
            sum(order_num)                                          as order_num, 
            sum(if(o.fid=p.land_publisher_id,order_num,0))          as order_num_self, 
            sum(if(channel=11,order_num,0))                         as order_num_micro_shop,    
            sum(if(channel=0,order_num,0))                          as order_num_plat_b, 
            sum(if(channel in (17,20),order_num,0))                 as order_num_OTA,    

            sum(order_ticket)                                       as ticket_num, 
            sum(if(o.fid=p.land_publisher_id,order_ticket,0))       as ticket_num_self, 
            sum(if(channel=11,order_ticket,0))                      as ticket_num_micro_shop,    
            sum(if(channel=0,order_ticket,0))                       as ticket_num_plat_b, 
            sum(if(channel in (17,20),order_ticket,0))              as ticket_num_OTA,    

            sum(sale_money)                                         as booking_amount,
            sum(if(o.fid=p.land_publisher_id,sale_money,0))         as booking_amount_self,
            sum(if(channel=11,sale_money,0))                        as booking_amount_micro_shop,    
            sum(if(channel=0 ,sale_money,0))                        as booking_amount_direct, 
            sum(if(channel in (17,20),sale_money,0))                as booking_amount_OTA

      from  (
            SELECT
                  `date`
                  ,sid              AS fid
                  ,tid
                  ,order_num
                  ,order_ticket
                  ,order_sale_money AS sale_money
                  ,pay_way
                  ,channel
            FROM  dws_report_order_d_i   
            WHERE `date`>='20230101' 
                  AND `date` >= DATE_FORMAT(DATE_SUB(TO_DATE('${ds}','yyyyMMdd'),730),'yyyyMMdd')
                  AND main_tid=0
            ) O
      left join (select * from dim_prod_d_f where pt='${ds}') p on o.tid=p.ticket_id
      group by fid,`date`
      ) o1
-- 资源中心订单
left join (
            select a.sellerid                         as seller_id,
                    to_date(ro.booking_time)          as booking_date,
                    count(*)                          as order_num_resource_center,
                    count(ro.booking_num)             as ticket_num_resource_center,
                    count(ro.booking_pay_amount)      as booking_amount_resource_center
             from (select order_id,booking_time,booking_num,booking_pay_amount 
                   from  dwd_resource_center_order_d_f
                   where pt='${ds}' and booking_time>date_format('${ds}','YYYY-01-01'))  ro 
             -- left join ods_order_aids_split_d_f  a on ro.order_id=a.order_id and a.pt='${ds}'
             left join ods_order_split_d_i a on ro.order_id=a.orderid and orderdate > DATE_FORMAT(DATE_SUB(TO_DATE('${ds}','yyyyMMdd'),732),'yyyyMMdd')
             group by a.sellerid,to_date(ro.booking_time)
             ) r1   on r1.seller_id=o1.fid and r1.booking_date=o1.booking_date
group by o1.fid,substr(o1.booking_date,1,7)
;

