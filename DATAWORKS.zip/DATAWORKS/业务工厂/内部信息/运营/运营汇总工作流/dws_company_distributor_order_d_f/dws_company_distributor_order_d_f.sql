-- name dws_company_distributor_order_d_f
-- type SparkSQL
-- author xiaoning@12301.cc
-- create time 2020-08-11 15:11:13
-- desc 
-- 分销商产生订单情况
-- 2020年以后的订单
-- drop table dws_company_distributor_order_d_f;

create table if not EXISTS  dws_company_distributor_order_d_f
(
    stat_date                 STRING COMMENT"统计日期",
    dw_ins_time               STRING COMMENT"数据插入日期",

    user_id                   INT    COMMENT"用户id",
    first_order_time          STRING COMMENT"首次下单日期",  
    last_order_time           STRING COMMENT"上次下单日期",  

    order_num_all             INT COMMENT"总订单量（本年）",  
    ticket_num_all            INT COMMENT"总门票量（本年）",  
    pay_amount_all            float COMMENT"总销售金额（本年）",
    land_num_all              INT COMMENT "有订单产品数"  ,


    order_num_7d              INT    COMMENT"近7日订单数",
    ticket_num_7d             INT    COMMENT"近7日门票数",
    pay_amount_7d             float COMMENT"近7日金额（元）",

    order_num_30d             INT    COMMENT"近30日订单数",
    ticket_num_30d            INT    COMMENT"近30日门票数",
    pay_amount_30d            float COMMENT"近30日金额（元）"

 )COMMENT'分销商订单情况'PARTITIONED BY(
    pt INT
 )STORED AS ORC;


insert OVERWRITE table dws_company_distributor_order_d_f partition(pt='${ds}')
SELECT 
    '${ds}'                                               as stat_date,
    now()                                                                 as dw_ins_time,

    o.fid                                                                 as user_id ,
    concat(min(o.booking_date), ' 00:00:00')                              as frist_order_time,
    concat(max(o.booking_date), ' 00:00:00')                              as last_order_time,

    sum(o.order_num)                                                      as order_num_all,
    sum(o.order_ticket)                                                   as ticket_num_all,
    sum(o.sale_money)                                                     as pay_amount_all,
    count(distinct o.lid)                                                 as land_num_all,
    sum(if(o.booking_date>=DATE_sub(current_date, 7),o.order_num,0))      as order_num_7d,
    sum(if(o.booking_date>=DATE_sub(current_date, 7),o.order_ticket,0))   as ticket_num_7d,
    sum(if(o.booking_date>=DATE_sub(current_date, 7),o.sale_money,0))     as pay_amount_7d,

    sum(if(o.booking_date>=DATE_sub(current_date, 30),o.order_num,0))     as order_num_30d,
    sum(if(o.booking_date>=DATE_sub(current_date, 30),o.order_ticket,0))  as ticket_num_30d,
    sum(if(o.booking_date>=DATE_sub(current_date, 30),o.sale_money,0))    as pay_amount_30d

from (
    SELECT 
        sid                                 AS fid,
        lid                                 AS lid,
        order_ticket                        AS order_ticket,
        order_num                           AS order_num,
        order_sale_money                    AS sale_money,
        CONCAT(
                SUBSTR(`date`,1,4),
                '-',
                SUBSTR(`date`,5,2),
                '-',
                SUBSTR(`date`,7,2)
        )                                   AS booking_date
    FROM dws_report_order_d_i 
    WHERE `date`>= 20230101
        AND main_tid=0
) o
join (select user_id from dim_user_d_f 
       where pt="${ds}"  and user_type= '分销商' and user_is_test='正式' ) m on o.fid=m.user_id
group by o.fid
;

-- select 
-- '${ds}' as stat_date,
-- now() as dw_ins_time,

-- a.user_id ,
-- min(to_date(o.booking_time))                                                 as frist_order_time,
-- max(to_date(o.booking_time))                                                 as last_order_time,

-- count(o.order_id)                                                            as order_num_all,
-- sum(o.ticket_num)                                                            as ticket_num_all,
-- sum(o.order_pay_amount)                                                      as pay_amount_all,
-- count(distinct o.land_id)                                                    as land_num_all,
-- sum(if(to_date(o.booking_time)>=DATE_sub(current_date, 7),1,0))                                       as order_num_7d,
-- sum(if(to_date(o.booking_time)>=DATE_sub(current_date, 7),o.ticket_num,0))                            as ticket_num_7d,
-- sum(if(to_date(o.booking_time)>=DATE_sub(current_date, 7),o.order_pay_amount,0))                      as pay_amount_7d,

-- sum(if(to_date(o.booking_time)>=DATE_sub(current_date, 30),1,0))                                      as order_num_30d,
-- sum(if(to_date(o.booking_time)>=DATE_sub(current_date, 30),o.ticket_num,0))                           as ticket_num_30d,
-- sum(if(to_date(o.booking_time)>=DATE_sub(current_date, 30),o.order_pay_amount,0))                     as pay_amount_30d


-- from (
-- select distinct a.user_id,order_id
--     from data_middle_bi.dim_user_d_f a
--         left join  (select * from data_middle_bi.ods_order_aids_split_d_f where pt='${ds}') as sp on a.user_id=sp.buyer_id 
--     where a.pt="${ds}"
--     and a.user_type= '分销商' and a.user_is_test='正式'
-- ) a 
-- left join (select * from data_middle_bi.dwd_order_d_f b where pt="${ds}" and order_pay_status<2 and booking_time>='2020-01-01 00:00:00') o on a.order_id=o.order_id
-- group by a.user_id;

