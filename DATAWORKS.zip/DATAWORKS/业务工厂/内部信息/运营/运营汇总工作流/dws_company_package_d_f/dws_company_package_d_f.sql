-- name dws_company_package_d_f
-- type SparkSQL
-- author linnong@12301.cc
-- create time 2019-05-07 08:48:10
-- desc 商户（供应商+分销商）各套餐周期及自供应产品订单情况
-- DROP table if EXISTS dws_company_package_d_f;

create table if NOT EXISTS dws_company_package_d_f(
    stat_date                                   STRING COMMENT"统计日期",
    dw_ins_time                                 STRING COMMENT"数据插入日期",

    user_id                                     INT    COMMENT"用户id",
    user_group                                  STRING COMMENT"用户分群",

    user_first_supplier_begindate               STRING COMMENT"用户第一次合作供应商套餐开始日期",
    user_first_supplier_enddate                 STRING COMMENT"用户第一次合作供应商套餐结束日期",
    user_first_supplier_package_id              STRING COMMENT"用户第一次合作供应商套餐ID",
    user_first_supplier_package_name            STRING COMMENT"用户第一次合作供应商套餐名称",
    user_first_supplier_package_price           STRING COMMENT"用户第一次合作供应商套餐价格",
    user_first_supplier_package_classify_name   STRING COMMENT"用户第一次合作供应商套餐组",
    user_first_supplier_package_pay_amount      int    COMMENT"用户第一次合作供应商实收金额（分）",
    user_first_supplier_add_time                STRING COMMENT"用户第一次合作供应添加时间",


    user_first_package_begindate                STRING COMMENT"用户第一次合作开始日期",
    user_first_package_enddate                  STRING COMMENT"用户第一次合作结束日期",
    user_first_package_id                       INT    COMMENT"用户第一次套餐id",
    user_first_package_name                     STRING COMMENT"用户第一次套餐名称",
    user_first_package_price                    int    COMMENT"用户第一次套餐价格(分)",
    user_first_package_role                     STRING COMMENT"用户第一次套餐角色,供应商/分销商",
    user_first_package_classify_name            string COMMENT '用户第一次套餐套餐组',
    user_first_package_pay_amount               int    COMMENT '用户第一次套餐实收金额（分）',
    user_first_add_time                         string COMMENT '用户第一次套餐添加日期',
    

    user_package_num_buy                        int    COMMENT"用户购买套餐次数",
    user_package_num_used                       int    COMMENT"用户已用套餐次数",
    max_package_price                           int    COMMENT"用户使用套餐最大价格",
    sum_pay_amount_package                      int    comment"用户实付套餐费合计",
    sum_price_package                           int    comment"用户套餐单价合计",

    --当前套餐情况
    user_curr_package_id                        INT    COMMENT"用户当前套餐id",
    user_curr_package_name                      STRING COMMENT"用户当前套餐名称",
    user_curr_package_begin_date                STRING COMMENT"用户当前套餐开始日期",
    user_curr_package_end_date                  STRING COMMENT"用户当前套餐结束日期",
    user_curr_package_add_date                  STRING COMMENT"用户当前套餐添加日期",
    user_curr_package_price                     int    COMMENT"用户当前套餐价格(分)",
    user_curr_package_pay_amount                int    COMMENT"用户当前套餐实收金额(分)",
    user_curr_package_role                      STRING COMMENT"用户当前套餐角色,供应商/分销商",
    user_curr_package_classify_name             STRING COMMENT"用户当前套餐套餐组",
    user_curr_package_signer                    STRING COMMENT"用户当前套餐签单人",
    user_curr_package_signer_depart             STRING COMMENT"用户当前套餐签单人部门",
    user_curr_package_contract_model            STRING COMMENT"用户下个套餐合作模式",

--     user_curr_package_order_land_num    INT COMMENT"当前套餐期间有订单景区数",  
--     user_curr_package_order_resource_num    INT COMMENT"当前套餐期间有订单景区数",  
--     user_curr_package_order_days        INT COMMENT"当前套餐期间有订单天数",  
--     user_curr_package_order_months      INT COMMENT"当前套餐期间有订单月数",  
--     user_curr_package_order_month_list  STRING COMMENT"当前套餐期间有订单月份列表",  

--     user_curr_package_order_num          INT    COMMENT"当前套餐订单数",
--     user_curr_package_ticket_num         INT    COMMENT"当前套餐门票数",
--     user_curr_package_order_amount         bigint COMMENT"当前套餐订单金额（分）",
--     user_curr_package_order_num_OTA      INT    COMMENT"当前套餐OTA订单数",
--     user_curr_package_ticket_num_OTA     INT    COMMENT"当前套餐OTA门票数",
--     user_curr_package_order_amount_OTA     bigint COMMENT"当前套餐OTA金额（分）",

    ---上次套餐订单情况
    user_last_package_id                    int    COMMENT"用户上次套餐id",
    user_last_package_name                  STRING COMMENT"用户上次套餐名称",
    user_last_package_begin_date            STRING COMMENT"用户上次套餐开始日期",
    user_last_package_end_date              STRING COMMENT"用户上次套餐结束日期",
    user_last_package_add_date              STRING COMMENT"用户上次套餐添加日期",
    user_last_package_price                 int    COMMENT"用户上次套餐价格（分）",
    user_last_package_pay_amount            int    COMMENT"用户上次套餐实收金额（分）",
    user_last_package_role                  STRING COMMENT"用户上次套餐角色,供应商/分销商",
    user_last_package_classify_name         STRING COMMENT"用户上次套餐套餐组",
--     user_last_package_order_land_num      INT COMMENT"上次套餐期间有订单景区数",  
--     user_last_package_order_resource_num  INT COMMENT"上次套餐期间有订单景区数",  
--     user_last_package_order_days          INT COMMENT"上次套餐期间有订单天数",  
--     user_last_package_order_months        INT COMMENT"上次套餐期间有订单月数",  
--     user_last_package_order_month_list    STRING COMMENT"上次套餐期间有订单月份列表",  

--     user_last_package_order_num          INT    COMMENT"上次套餐订单数",
--     user_last_package_ticket_num         INT    COMMENT"上次套餐门票数",
--     user_last_package_order_amount         bigint COMMENT"上次套餐订单金额（分）",
--     user_last_package_order_num_OTA      INT    COMMENT"上次套餐OTA订单数",
--     user_last_package_ticket_num_OTA     INT    COMMENT"上次套餐OTA门票数",
--     user_last_package_order_amount_OTA     bigint COMMENT"上次套餐OTA金额（分）",
    --续费套餐信息
    user_next_package_id                    int    COMMENT"用户下个套餐id",
    user_next_package_name                  STRING COMMENT"用户下个套餐名称",
    user_next_package_begin_date            STRING COMMENT"用户下个套餐开始日期",
    user_next_package_end_date              STRING COMMENT"用户下个套餐结束日期",
    user_next_package_add_date              STRING COMMENT"用户下个套餐添加日期",
    user_next_package_price                 int    COMMENT"用户下个套餐价格（分）",
    user_next_package_pay_amount            int    COMMENT"用户下个套餐实收金额（分）",
    user_next_package_signer                STRING COMMENT"用户下个套餐签单人",
    user_next_package_signer_depart         STRING COMMENT"用户下个套餐签单人部门",
    user_next_package_contract_model        STRING COMMENT"用户下个套餐合作模式",

    --最后套餐信息
    user_end_package_id                     int    COMMENT"用户最终套餐id",
    user_end_package_name                   STRING COMMENT"用户最终套餐名称",
    user_end_package_begin_date             STRING COMMENT"用户最终套餐开始日期",
    user_end_package_end_date               STRING COMMENT"用户最终套餐结束日期",
    user_end_package_add_date               STRING COMMENT"用户最终套餐添加日期",
    user_end_package_price                  int    COMMENT"用户最终套餐价格（分）",
    user_end_package_pay_amount             int    COMMENT"用户最终套餐实收金额（分）"

 )COMMENT'商户套餐及订单情况'PARTITIONED BY(
    pt INT
 )STORED AS ORC;


INSERT OVERWRITE    TABLE dws_company_package_d_f  PARTITION(pt='${ds}')
select
   ${ds}                                   as stat_date,
   current_date                                            as dw_ins_time,

   p.user_id                                               as user_id,

   if(max(p.end_time)<current_date,
        if(max(p.period_days)<31,'试用未签约','流失用户'),
        if(sum(if(p.period_days>=90,1,0))>1,'续费用户',if(max(p.period_days)<31,'试用','新用户')))                as user_group,

   min(if(p.package_open_id=p1.first_supply_package_open_id,p.begin_time,null))                                   as user_first_supplier_begin_date,
   min(if(p.package_open_id=p1.first_supply_package_open_id,p.end_time,null))                                     as user_first_supplier_end_date,
   min(if(p.package_open_id=p1.first_supply_package_open_id,p.package_id,null))                                   as user_first_supplier_package_id,
   min(if(p.package_open_id=p1.first_supply_package_open_id,p.package_name,null))                                 as user_first_supplier_package_name,
   min(if(p.package_open_id=p1.first_supply_package_open_id,p.package_price,null))                                as user_first_supplier_package_price,
   min(if(p.package_open_id=p1.first_supply_package_open_id,p.package_classify_name,null))                        as user_first_supplier_package_classify_name,
   min(if(p.package_open_id=p1.first_supply_package_open_id,p.package_pay_amount,null))                           as user_first_supplier_package_pay_amount,
   min(if(p.package_open_id=p1.first_supply_package_open_id,p.add_time,null))                                     as user_first_supplier_add_time,


   min(if(p.package_open_id=p1.first_package_open_id,begin_time,null))                                            as user_first_package_begin_date,
   min(if(p.package_open_id=p1.first_package_open_id,end_time,null))                                              as user_first_package_end_date,
   max(if(p.package_open_id=p1.first_package_open_id,package_id,null))                                            as user_first_package_id,
   max(if(p.package_open_id=p1.first_package_open_id,package_name,null))                                          as user_first_package_name,
   max(if(p.package_open_id=p1.first_package_open_id,package_price,null))                                         as user_first_package_price,
   max(if(p.package_open_id=p1.first_package_open_id,package_role,null))                                          as user_first_package_role,
   max(if(p.package_open_id=p1.first_package_open_id,package_classify_name,null))                                 as user_first_package_classify_name,
   max(if(p.package_open_id=p1.first_package_open_id,package_pay_amount,null))                                    as user_first_package_pay_amount,
   max(if(p.package_open_id=p1.first_package_open_id,add_time,null))                                              as user_first_add_time,
   
   count(*)                                                                                                       as user_package_num_buy, 
   sum(if(p.package_status<>'未到',1,0))                                                                          as user_package_num_used, 
   max(p.package_price)                                                                                           as max_package_price,
   sum(p.package_pay_amount)                                                                                      as sum_pay_amount_package,
   sum(p.package_price)                                                                                           as sum_price_package,

   -- 当前套餐情况
   max(if(p.package_open_id=p1.curr_package_open_id,package_id,null))                                              as user_curr_package_id,
   max(if(p.package_open_id=p1.curr_package_open_id,package_name,null))                                            as user_curr_package_name,
   max(if(p.package_open_id=p1.curr_package_open_id,begin_time,null))                                              as user_curr_package_begin_date,
   max(if(p.package_open_id=p1.curr_package_open_id,end_time,null))                                                as user_curr_package_end_date,
   max(if(p.package_open_id=p1.curr_package_open_id,add_time,null))                                                as user_curr_package_add_date,
   max(if(p.package_open_id=p1.curr_package_open_id,package_price,null))                                           as user_curr_package_price,
   max(if(p.package_open_id=p1.curr_package_open_id,package_pay_amount,null))                                      as user_curr_package_pay_amount,
   max(if(p.package_open_id=p1.curr_package_open_id,package_role,null))                                            as user_curr_package_role,
   max(if(p.package_open_id=p1.curr_package_open_id,package_classify_name,null))                                   as user_curr_package_classify_name,
   max(if(p.package_open_id=p1.curr_package_open_id,sale_man_name,null))                                           as user_curr_package_signer,
   max(if(p.package_open_id=p1.curr_package_open_id,sale_man_department,null))                                     as user_curr_package_signer_depart,
   max(if(p.package_open_id=p1.curr_package_open_id,user_contract_model,null))                                     as user_curr_package_contract_model,


--    max(if(p.package_open_id=p1.curr_package_open_id,package_order_land_num,null))                                  as user_curr_package_land_num,
--    max(if(p.package_open_id=p1.curr_package_open_id,package_order_resource_num,null))                              as user_curr_package_resource_num,
--    max(if(p.package_open_id=p1.curr_package_open_id,package_order_days,null))                                      as user_curr_package_days,
--    max(if(p.package_open_id=p1.curr_package_open_id,package_order_months,null))                                    as user_curr_package_months,
--    max(if(p.package_open_id=p1.curr_package_open_id,package_order_month_list,null))                                as user_curr_order_month_list,

--    max(if(p.package_open_id=p1.curr_package_open_id,package_order_num,null))                                       as user_curr_package_order_num,
--    max(if(p.package_open_id=p1.curr_package_open_id,package_ticket_num,null))                                      as user_curr_package_ticket_num,
--    max(if(p.package_open_id=p1.curr_package_open_id,package_order_amount,null))                                    as user_curr_package_order_amount,

--    max(if(p.package_open_id=p1.curr_package_open_id,package_order_num_OTA,null))                                   as user_curr_package_order_num_OTA,
--    max(if(p.package_open_id=p1.curr_package_open_id,package_ticket_num_OTA,null))                                  as user_curr_package_ticket_num_OTA,
--    max(if(p.package_open_id=p1.curr_package_open_id,package_order_amount_OTA,null))                                as user_curr_package_order_amount_OTA,


   -- 上次套餐情况
   max(if(p.package_open_id=p1.last_package_open_id,package_id,null))                                              as user_last_package_id,
   max(if(p.package_open_id=p1.last_package_open_id,package_name,null))                                            as user_last_package_name,
   max(if(p.package_open_id=p1.last_package_open_id,begin_time,null))                                              as user_last_package_begin_date,
   max(if(p.package_open_id=p1.last_package_open_id,end_time,null))                                                as user_last_package_end_date,
   max(if(p.package_open_id=p1.last_package_open_id,add_time,null))                                                as user_last_package_add_date,
   max(if(p.package_open_id=p1.last_package_open_id,package_price,null))                                           as user_last_package_price,
   max(if(p.package_open_id=p1.last_package_open_id,package_pay_amount,null))                                      as user_last_package_pay_amount,
   max(if(p.package_open_id=p1.last_package_open_id,package_role,null))                                            as user_last_package_role,
   max(if(p.package_open_id=p1.last_package_open_id,package_classify_name,null))                                   as user_last_package_classify_name,
--    max(if(p.package_open_id=p1.last_package_open_id,package_order_land_num,null))                                  as user_last_package_land_num,
--    max(if(p.package_open_id=p1.last_package_open_id,package_order_resource_num,null))                              as user_last_package_resource_num,
--    max(if(p.package_open_id=p1.last_package_open_id,package_order_days,null))                                      as user_last_package_days,
--    max(if(p.package_open_id=p1.last_package_open_id,package_order_months,null))                                    as user_last_package_months,
--    max(if(p.package_open_id=p1.last_package_open_id,package_order_month_list,null))                                as user_last_order_month_list,

--    max(if(p.package_open_id=p1.last_package_open_id,package_order_num,null))                                       as user_last_package_order_num,
--    max(if(p.package_open_id=p1.last_package_open_id,package_ticket_num,null))                                      as user_last_package_ticket_num,
--    max(if(p.package_open_id=p1.last_package_open_id,package_order_amount,null))                                    as user_last_package_order_amount,

--    max(if(p.package_open_id=p1.last_package_open_id,package_order_num_OTA,null))                                   as user_last_package_order_num_OTA,
--    max(if(p.package_open_id=p1.last_package_open_id,package_ticket_num_OTA,null))                                  as user_last_package_ticket_num_OTA,
--    max(if(p.package_open_id=p1.last_package_open_id,package_order_amount_OTA,null))                                as user_last_package_order_amount_OTA,
    --下一个套餐情况
   max(if(p.package_open_id=p1.next_package_open_id,package_id,null))                                               as user_next_package_id,
   max(if(p.package_open_id=p1.next_package_open_id,package_name,null))                                             as user_next_package_name,
   max(if(p.package_open_id=p1.next_package_open_id,begin_time,null))                                               as user_next_package_begin_date,
   max(if(p.package_open_id=p1.next_package_open_id,end_time,null))                                                 as user_next_package_end_date,
   max(if(p.package_open_id=p1.next_package_open_id,add_time,null))                                                 as user_next_package_add_date,
   max(if(p.package_open_id=p1.next_package_open_id,package_price,null))                                            as user_next_package_price,
   max(if(p.package_open_id=p1.next_package_open_id,package_pay_amount,null))                                       as user_next_package_pay_amount,
   max(if(p.package_open_id=p1.next_package_open_id,sale_man_name,null))                                            as user_next_package_signer,
   max(if(p.package_open_id=p1.next_package_open_id,sale_man_department,null))                                      as user_next_package_signer_depart,
   max(if(p.package_open_id=p1.next_package_open_id,user_contract_model,null))                                      as user_next_package_contract_model,

   -- 最后套餐情况
   max(if(p.package_open_id=p1.end_package_open_id,package_id,null))                                               as user_end_package_id,
   max(if(p.package_open_id=p1.end_package_open_id,package_name,null))                                             as user_end_package_name,
   max(if(p.package_open_id=p1.end_package_open_id,begin_time,null))                                               as user_end_package_begin_date,
   max(if(p.package_open_id=p1.end_package_open_id,end_time,null))                                                 as user_end_package_end_date,
   max(if(p.package_open_id=p1.end_package_open_id,add_time,null))                                                 as user_end_package_add_date,
   max(if(p.package_open_id=p1.end_package_open_id,package_price,null))                                            as user_end_package_price,
   max(if(p.package_open_id=p1.end_package_open_id,package_pay_amount,null))                                       as user_end_package_pay_amount

from (SELECT  * 
      from dwd_user_package_d_f 
      where pt='${ds}' and stop_type<>'作废'
      ) p
left join
     (SELECT  user_id, 
              min(if(package_role='供应商',package_open_id,null))        as first_supply_package_open_id,
              min(package_open_id)                                       as first_package_open_id,
              min(if(package_status='当前',package_open_id,null))        as curr_package_open_id,
              max(if(package_status='过期',package_open_id,null))        as last_package_open_id,
              min(if(package_status='未到',package_open_id,null))        as next_package_open_id,
              max(package_open_id)                                       as end_package_open_id
      from dwd_user_package_d_f
      where pt='${ds}' and stop_type<>'作废'
      group by user_id
      ) p1 on p.user_id=p1.user_id  and (p.package_open_id=p1.curr_package_open_id  or p.package_open_id=p1.last_package_open_id or p.package_open_id=p1.end_package_open_id or p.package_open_id=p1.first_package_open_id or p.package_open_id=p1.next_package_open_id)
group by p.user_id
;

-- select *
-- from dws_company_package_d_f
-- where pt='${ds}'


-- select *
-- from  data_middle_bi.dwd_user_package_d_f 
--       where pt='${ds}' and stop_type<>'作废' and user_id=4094374