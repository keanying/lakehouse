-- name ads_order_play_d_f
-- type SparkSQL
-- create time 2021-03-26 17:17:13
-- desc 订单按游玩时间汇总 
-- 预定时间小于今天
CREATE TABLE IF NOT EXISTS ads_order_play_d_f(
    land_publisher_id   INT     COMMENT '商户id',
    play_date           STRING  COMMENT '预计游玩日期',
    ticket_num          INT     COMMENT '票数'
) COMMENT'预计游玩人数'
PARTITIONED BY(
    pt INT  
)STORED AS ORC;


INSERT OVERWRITE TABLE ads_order_play_d_f PARTITION (pt="${ds}") 
SELECT 
    land_publisher_id,
    TO_DATE(play_time)  AS play_date,
    SUM(ticket_num)     AS ticket_num
FROM 
(
    SELECT land_publisher_id, play_time, ticket_num 
    FROM dwd_order_d_i 
    WHERE 1 = 1 
        -- 24/04/07 修订增加内容
        -- 仅取最近6个月下单
        -- 过滤未支付以及票量为0
      AND booking_date < ${ds}
      AND booking_date >= ${ds180}
      AND pay_time IS NOT NULL 
      AND ticket_num > 0      
      AND play_time >= ${ds2}
) AS o
-- join (select * from dim_dalian_user_d_f where pt='${bdp.system.bizdate}') u on u.user_id=o.land_publisher_id
GROUP BY o.land_publisher_id, TO_DATE(play_time);

