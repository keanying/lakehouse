-- name ads_plat_distribution_d_f
-- type SparkSQL
-- author linnong@12301.cc
-- create time 2019-07-28 13:15:22
-- desc 公司大屏分销渠道


CREATE TABLE IF NOT EXISTS ads_plat_distribution_d_f(
    stat_date               STRING  COMMENT '统计日期',
    dw_ins_time             STRING  COMMENT '插入时间',

    booking_date            STRING  COMMENT '下单日期',
    distributor_id          INT     COMMENT 'OTAID',
    distributor_name        STRING  COMMENT 'OTA企业名称',
    distributor_short_name  STRING  COMMENT 'OTA简称',
    ticket_num              INT     COMMENT '游客数',
    order_num               INT     COMMENT '订单数',
    pay_amount              BIGINT  COMMENT '订单支付金额（分）',
    -- 2023/04/11修订增加
    booking_channel         INT     COMMENT '渠道ID',
    ota_type                STRING  COMMENT 'OTA分类'
) COMMENT "OTA分销量" 
PARTITIONED BY(
    pt INT  
)STORED AS ORC;


INSERT OVERWRITE TABLE ads_plat_distribution_d_f PARTITION (pt="${ds}")
SELECT 
    ${ds}               AS stat_date,
    CURRENT_DATE                        AS dw_ins_time,

    fulldate                            AS booking_date,
    channel_class2_id                   AS distributor_id,
    channel_class2_name                 AS distributor_name,
    channel_class2_name                 AS distributor_short_name,
    
    SUM(paid_ticket_count)              AS ticket_num,
    SUM(paid_count)                     AS order_num,
    SUM(paid_amount)                    AS pay_amount,

    channel_class2_id                   AS booking_channel,

    'OTA'                               AS ota_type
FROM dws_distribution_aggregation_d_i
WHERE 1=1
  AND fulldate >= '${ds366}'
  AND channel_class1_id = 3
GROUP BY fulldate, channel_class2_id, channel_class2_name;

-- 老版本
-- -- 渠道20的, 通过member进行标识
-- SELECT 
--     ${ds}               AS stat_date,
--     CURRENT_DATE                        AS dw_ins_time,

--     booking_date                        AS booking_date,
--     order_table.booker_id               AS distributor_id,
--     member_table.company_name           AS distributor_name,
--     member_table.company_name           AS distributor_short_name,
--     SUM(order_table.ticket_num)         AS ticket_num,
--     COUNT(*)                            AS order_num,
--     SUM(order_table.order_pay_amount)   AS pay_amount,
--     member_table.company_channle        AS booking_channel,
--     member_table.company_app_type       AS ota_type    
-- FROM  
-- (
--     -- 近一年, 付款且票数非零单
--     SELECT 
--         booker_id, 
--         ticket_num, 
--         booking_date, 
--         booking_channel,
--         order_pay_amount 
--     FROM data_middle_bi.dwd_order_d_i 
--     WHERE 1=1  
--       AND booking_date >= DATE_SUB(CURRENT_DATE, 365) 
--       AND booking_channel = 20
--       AND ticket_num > 0 
-- ) AS order_table
-- JOIN 
-- -- 开通用户以及渠道
-- (
--     SELECT 
--         ods_member.user_id,
--         dim_channel.company_name,
--         dim_channel.company_channle,
--         dim_channel.company_app_type
--     FROM dim_distributor_channel_d_f AS dim_channel
--     JOIN ods_pft_member_d_f AS ods_member 
--     ON ods_member.pt='${ds}'
--     AND dim_channel.account = ods_member.user_account
--     AND dim_channel.company_channle = 20
-- ) AS member_table
-- ON order_table.booker_id = member_table.user_id
-- GROUP BY 
--     booking_date,
--     order_table.booker_id,
--     member_table.company_name,
--     member_table.company_channle,
--     member_table.company_app_type


-- -- 渠道非20的, 通过渠道标识. 目前仅有飞猪和阿里供销两种
-- UNION ALL
-- SELECT 
--     ${ds}               AS stat_date,
--     CURRENT_DATE                        AS dw_ins_time,

--     booking_date                        AS booking_date,
--     member_table.account                AS distributor_id,
--     member_table.company_name           AS distributor_name,
--     member_table.company_name           AS distributor_short_name,
--     SUM(order_table.ticket_num)         AS ticket_num,
--     COUNT(*)                            AS order_num,
--     SUM(order_table.order_pay_amount)   AS pay_amount,
--     member_table.company_channle        AS booking_channel,
--     member_table.company_app_type       AS ota_type  
-- FROM  
-- -- 近一年, 付款且票数非零单
-- (
--     SELECT 
--         ticket_num, 
--         booking_date, 
--         booking_channel,
--         order_pay_amount 
--     FROM data_middle_bi.dwd_order_d_i 
--     WHERE 1=1  
--       AND booking_date >= DATE_SUB(CURRENT_DATE, 365) 
--       AND booking_channel IN (17, 58)
--       AND ticket_num > 0 
-- ) AS order_table
-- JOIN 
-- -- 开通用户以及渠道
-- (
--     SELECT 
--         account,
--         company_name,
--         company_channle,
--         company_app_type
--     FROM dim_distributor_channel_d_f
--     WHERE company_channle != 20
-- ) AS member_table
-- ON order_table.booking_channel = member_table.company_channle
-- GROUP BY 
--     booking_date,
--     member_table.company_name,
--     member_table.account,
--     member_table.company_channle,
--     member_table.company_app_type;

