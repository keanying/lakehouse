-- name ads_source_area_sell_num_d_f
-- type SparkSQL
-- author linyao@12301.cc
-- create time 2019-07-29 11:19:25
-- desc 

CREATE TABLE IF NOT EXISTS ads_source_area_sell_d_f(
    ticket_taker_province       STRING COMMENT "省份",
    ticket_taker_city           STRING COMMENT "城市",
    tourist_num_total           STRING COMMENT "销售总票数",  
    per_capita_votes            STRING COMMENT "人均票数",
    tourist_pay_amount_total    STRING COMMENT "销售总金额",
    per_capita_amount           STRING COMMENT "人均金额"
)COMMENT "城市销售排行" 
PARTITIONED BY(
    pt INT 
)STORED AS ORC;

INSERT OVERWRITE TABLE ads_source_area_sell_d_f PARTITION (pt="${ds}")
SELECT 
    ticket_taker_province,
    ticket_taker_city,
    SUM(ticket_num),
    ROUND(SUM(ticket_num) / COUNT(DISTINCT ticket_taker_mobile), 0),
    SUM(order_pay_amount),
    ROUND(SUM(order_pay_amount) / COUNT(DISTINCT ticket_taker_mobile), 2)
FROM dwd_order_d_i 
WHERE booking_date > '${ds732}'
  AND ticket_taker_city NOT IN("未知") 
  AND ISNOTNULL(ticket_taker_mobile) 
GROUP BY ticket_taker_city, ticket_taker_province
ORDER BY SUM(ticket_num) DESC;
