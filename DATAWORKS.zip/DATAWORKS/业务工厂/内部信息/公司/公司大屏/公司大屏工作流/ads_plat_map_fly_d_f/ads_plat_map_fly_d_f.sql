-- name ads_plat_map_fly_d_f
-- type SparkSQL
-- author linnong@12301.cc
-- create time 2019-07-31 12:45:47
-- desc 地图飞线


CREATE TABLE IF NOT EXISTS ads_plat_map_fly_d_f(
    stat_date           STRING COMMENT "统计日期",
    dw_ins_time         STRING COMMENT "插入时间",

    land_publisher_id   STRING COMMENT "产品发布商id",
    booking_time        STRING COMMENT "下单时间",
    ordernum            STRING COMMENT "订单号",
    tourist_name        STRING COMMENT "游客姓名",
    tourist_mobile      STRING COMMENT "游客手机号",
    together_num        INT    COMMENT "同行数量",

    from_province       STRING COMMENT "客源省",
    from_city           STRING COMMENT "客源市",
    from_lng            STRING COMMENT "客源lng",
    from_lat            STRING COMMENT "客源lat",
    from_adcode         STRING COMMENT "客源省行政编码",

    to_province         STRING COMMENT "目的地省",
    to_city             STRING COMMENT "目的地市",
    to_lng              STRING COMMENT "目的地lng",
    to_lat              STRING COMMENT "目的地lat"
)COMMENT '预订人数' 
PARTITIONED BY(
    pt INT 
)STORED AS ORC;


-- 游客旅游起止地不同的数据
INSERT OVERWRITE TABLE ads_plat_map_fly_d_f PARTITION (pt="${ds}")
SELECT 
    '${ds}'                     AS stat_date,
    CURRENT_DATE()              AS dw_ins_time,
    o.land_publisher_id         AS land_publisher_id,
    CONCAT(CURRENT_DATE(), SUBSTR(o.booking_time, 11, 9))   AS booking_time,
    o.booker_name               AS tourist_name,
    o.order_id                  AS ordernum,
    o.ticket_taker_mobile       AS tourist_mobile,
    o.ticket_num                AS together_num,
    o.ticket_taker_province     AS from_province,
    o.ticket_taker_city         AS from_city,
    cf.lng                      AS from_lng,
    cf.lat                      AS from_lat,
    CONCAT(SUBSTR(o.ticket_taker_adcode, 1, 2),'0000')      AS from_adcode,
    o.land_province             AS to_province,
    o.land_city                 AS to_city,
    ct.lng                      AS to_lng,
    ct.lat                      AS to_lat
FROM 
(
    SELECT 
        order_id,
        land_id,
        ticket_taker_mobile,
        ticket_num,
        ticket_taker_province,
        ticket_taker_city,
        ticket_taker_adcode,
        booker_name,
        booking_time,
        land_province, 
        land_city,
        land_zip_code,
        ticket_zip_code,
        land_publisher_id
    FROM dwd_order_d_i 
    WHERE booking_date >= "${ds}"
      AND ticket_num > 0
) AS o
LEFT JOIN
(
    SELECT * 
    FROM dim_city_d_f 
    WHERE pt='${ds}'
) AS ct 
ON ct.zip_code = o.land_zip_code
LEFT JOIN  
(
    SELECT * 
    FROM dim_city_d_f
    WHERE pt='${ds}'
) AS cf 
ON cf.zip_code = o.ticket_zip_code
WHERE ISNOTNULL(ct.lng) 
  AND ISNOTNULL(cf.lng) 
  AND o.ticket_taker_city <> o.land_city;

