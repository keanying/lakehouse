-- name ads_plat_yesterday_order_hour_d_i
-- type SparkSQL
-- author linnong@12301.cc
-- create time 2020-10-04 14:22:51
-- desc 公司大屏--昨日分时预定、检票

CREATE TABLE IF NOT EXISTS  ads_plat_yesterday_order_hour_d_i(
    stat_date               STRING  COMMENT '统计日期',
    dw_ins_time             STRING  COMMENT '插入时间',
    series                  STRING  COMMENT '操作：昨日预定/昨日检票',
    oper_hour               STRING  COMMENT '操作小时',
    order_num               INT     COMMENT "订单数",
    ticket_num              INT     COMMENT "游客数",
    pay_amount              BIGINT  COMMENT "订单支付金额（分）"
) COMMENT "OTA分销量" PARTITIONED BY(
    pt INT  
)STORED AS ORC;


-- 报表数据，
--1、包含 uu_ss_order left join order_aids_split 转分销数据,
--2、对于末级为商户订单  补充了 商户->散客 链数据,销售单价为门市价
-- 
-- 昨日预定、检票分时 （含转分销,过滤未支付）
INSERT OVERWRITE TABLE  ads_plat_yesterday_order_hour_d_i PARTITION (pt="${ds}")
SELECT
      '${ds}'                   AS stat_date,
      DATE_FORMAT(CURRENT_DATE,'yyyy-MM-dd')    AS dw_ins_time,
      '昨日预定'                                 AS series,
       HOUR(FROM_UNIXTIME(update_time))         AS oper_hour,
       SUM(order_num)                           AS order_num,
       SUM(order_ticket)                        AS ticket_num,
       0                                        AS pay_amount
FROM ods_pft_report_order_two_d_i
WHERE date = '${ds}'
AND main_tid = 0
GROUP BY HOUR(FROM_UNIXTIME(update_time))

UNION ALL

SELECT
    '${ds}'                     AS stat_date,
    DATE_FORMAT(CURRENT_DATE, 'yyyy-MM-dd')     AS dw_ins_time,
    '昨日检票'                                   AS series,
    HOUR(FROM_UNIXTIME(update_time))            AS oper_hour,
    SUM(order_num)                              AS order_num,
    SUM(order_ticket)                           AS ticket_num,
    0                                           AS pay_amount
FROM ods_pft_report_checked_two_d_i 
WHERE `date` = '${ds}'
AND main_tid = 0
GROUP BY HOUR(FROM_UNIXTIME(update_time))
ORDER BY series, oper_hour;