-- name ads_plat_third_order_d_f
-- type SparkSQL
-- author linnong@12301.cc
-- create time 2019-10-30 16:56:51
-- desc 近一年第三方订单量TOP6 用户月订单量


CREATE TABLE IF NOT EXISTS ads_plat_third_purchase_order_d_f(
    stat_date               STRING COMMENT '统计日期',
    dw_ins_time             STRING COMMENT '插入时间',
    booking_year            STRING COMMENT '预定年',
    booking_month           STRING COMMENT '预定月份',
    purchase_system_name    STRING COMMENT '第三方线下票务系统名称',
    purchase_system_code    STRING COMMENT '第三方线下票务系统编码',
    month_rank              INT    COMMENT '月排行',
    order_num               INT    COMMENT '订单量',
    ticket_num              INT    COMMENT '票数',
    pay_amount              BIGINT    COMMENT '金额(分)'
)PARTITIONED BY(
    pt INT
)STORED AS ORC;


INSERT OVERWRITE TABLE ads_plat_third_purchase_order_d_f PARTITION (pt='${ds}') 
SELECT  
    ${ds}                       AS stat_date,
    CURRENT_DATE                                AS dw_ins_time,
    SUBSTR(booking_time, 1, 4)                  AS booking_year,
    CONCAT(SUBSTR(booking_time, 1, 7), '-01')   AS booking_month,
    purchase_system                             AS purchase_system_name,
    purchase_system_code                        AS purchase_system_code,
    ROW_NUMBER() OVER (PARTITION BY SUBSTR(booking_time, 1, 7) ORDER BY COUNT(*) DESC) AS month_rank,
    COUNT(*)                                    AS order_num,
    SUM(ticket_num)                             AS ticket_num,
    SUM(order_pay_amount)                       AS pay_amount
FROM dwd_order_d_i 
WHERE booking_date > '${ds366}'
  AND ISNOTNULL(purchase_system_code)
GROUP BY 
    SUBSTR(booking_time, 1, 4),
    SUBSTR(booking_time, 1, 7),
    purchase_system,
    purchase_system_code;

