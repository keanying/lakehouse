-- name ads_marketing_department_supply_gmv_d_f
-- type SparkSQL
-- author xiaoning@12301.cc
-- create time 2020-12-01 10:02:40
-- desc
-- 市场部需求  按省汇总 近一年顶级供应商订单情况和订单商户情况
-- 有效商户
-- drop table ads_marketing_department_supply_gmv_d_f

CREATE TABLE IF NOT EXISTS ads_marketing_department_supply_gmv_d_f(
    customer_province           STRING  COMMENT '产品归属省',
    total_land_num              INT     COMMENT '总产品数',
    total_ticket_num            INT     COMMENT '总票类数',
    total_order_num             INT     COMMENT '总订单数',
    total_order_ticket_num      INT     COMMENT '总票数',
    total_gmv                   FLOAT   COMMENT '总gmv(万元)',
    scenic_land_num             INT     COMMENT '景区产品数',
    scenic_ticket_num           INT     COMMENT '景区票类数',
    scenic_order_num            INT     COMMENT '景区订单数',
    scenic_order_ticket_num     INT     COMMENT '景区票数',
    scenic_gmv                  FLOAT   COMMENT '景区gmv(万元)',
    travel_land_num             INT     COMMENT '旅行社产品数',
    travel_ticket_num           INT     COMMENT '旅行社票类数',
    travel_order_num            INT     COMMENT '旅行社订单数',
    travel_order_ticket_num     INT     COMMENT '旅行社票数',
    travel_gmv                  FLOAT   COMMENT '旅行社gmv(万元)',
    total_supply_user_num       INT     COMMENT '总交易供应商数',
    total_distribute_user_num   INT     COMMENT '总交易分销商数',
    scenic_supply_user_num      INT     COMMENT '景区交易供应商数',
    scenic_distribute_user_num  INT     COMMENT '景区交易分销商数',
    travel_supply_user_num      INT     COMMENT '旅行社交易供应商数',
    travel_distribute_user_num  INT     COMMENT '旅行社交易分销商数'
)COMMENT "省汇总近一年顶级供应商订单情况和订单商户情况"
PARTITIONED  BY(
    pt INT
)STORED AS ORC;


INSERT OVERWRITE TABLE ads_marketing_department_supply_gmv_d_f PARTITION(pt = '${ds}' )
SELECT 
    a.*,
    b.total_supply_user_num,
    b.total_distribute_user_num,
    b.scenic_supply_user_num,
    b.scenic_distribute_user_num,
    b.travel_supply_user_num,
    b.travel_distribute_user_num 
FROM 
(
    SELECT 
        u.customer_province,
        COUNT(DISTINCT o.lid)                               AS total_land_num,
        COUNT(DISTINCT o.tid)                               AS total_ticket_num,
        SUM(o.order_num)                                    AS total_order_num,
        SUM(o.order_ticket)                                 AS total_order_ticket_num,
        ROUND(SUM(o.sale_money) / 100 / 10000, 2)           AS total_gmv,
        COUNT(DISTINCT IF(u.customer_type='景区', o.lid, NULL)) AS scenic_land_num,
        COUNT(DISTINCT IF(u.customer_type='景区', o.tid, NULL)) AS scenic_ticket_num,
        SUM(IF(u.customer_type = '景区', o.order_num, 0))       AS scenic_order_num,
        SUM(IF(u.customer_type = '景区', o.order_ticket, 0))    AS scenic_order_ticket_num,
        ROUND(SUM(IF(u.customer_type = '景区', o.sale_money, 0))/100/10000,2)           AS scenic_gmv,
        COUNT(DISTINCT IF(u.customer_type = '旅行社', o.lid, NULL))                     AS travel_land_num,
        COUNT(DISTINCT IF(u.customer_type = '旅行社', o.tid, NULL))                     AS travel_ticket_num,
        SUM(IF(u.customer_type = '旅行社', o.order_num, 0))                             AS travel_order_num,
        SUM(IF(u.customer_type = '旅行社', o.order_ticket, 0))                          AS travel_order_ticket_num,
        ROUND(SUM(IF(u.customer_type = '旅行社', o.sale_money, 0)) / 100 / 10000, 2)    AS travel_gmv
    FROM 
    (
        SELECT fid, lid, tid, order_num, order_ticket, sale_money 
        FROM ods_pft_report_order_two_d_i
        WHERE main_tid=0
        AND `date`> DATE_FORMAT(DATE_SUB(CURRENT_DATE,365), 'yyyyMMdd' )  
    ) AS o
    JOIN dim_land_d_f AS l 
    ON o.lid = l.land_id 
    AND l.pt = '${ds}'
    JOIN dim_user_d_f AS u 
    ON l.land_publisher_id = u.user_id 
    AND u.pt = '${ds}'
    -- 过滤套餐过期用户
    JOIN 
    (
        SELECT DISTINCT user_id 
        FROM dwd_user_package_d_f 
        WHERE pt='${ds}' 
        AND end_time >= CURRENT_DATE() 
    ) AS p 
    ON l.land_publisher_id = p.user_id
    GROUP BY u.customer_province
) AS a
LEFT JOIN 
(
    SELECT
        b.customer_province,
        COUNT(DISTINCT IF(b.user_type='供应商',b.user_id,NULL)) AS total_supply_user_num,
        COUNT(DISTINCT IF(b.user_type='分销商',b.user_id,NULL)) AS total_distribute_user_num,
        COUNT(DISTINCT IF(b.user_type='供应商' AND b.customer_type='景区',b.user_id,NULL)) AS scenic_supply_user_num,
        COUNT(DISTINCT IF(b.user_type='分销商' AND b.customer_type='景区',b.user_id,NULL)) AS scenic_distribute_user_num,
        COUNT(DISTINCT IF(b.user_type='供应商' AND b.customer_type='旅行社',b.user_id,NULL)) AS travel_supply_user_num,
        COUNT(DISTINCT IF(b.user_type='分销商' AND b.customer_type='旅行社',b.user_id,NULL)) AS travel_distribute_user_num
    FROM ods_pft_report_order_two_d_i AS a
    LEFT JOIN dim_user_d_f AS b 
    ON a.fid = b.user_id AND b.pt='${ds}' 
    -- WHERE date >= CONCAT((YEAR(CURRENT_DATE()) - 1), '01', '01') 
    -- 过滤套餐过期用户
    JOIN 
    (
        SELECT DISTINCT user_id 
        FROM dwd_user_package_d_f 
        WHERE pt='${ds}' 
        AND end_time >= CURRENT_DATE() 
    ) AS p 
    ON a.fid = p.user_id
    WHERE `date` > DATE_FORMAT(date_sub(TO_DATE('${ds}', 'yyyyMMdd'), 365), 'yyyyMMdd')
    GROUP BY b.customer_province
) AS b
ON a.customer_province = b.customer_province;





