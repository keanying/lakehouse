-- name dwd_company_cooperation_other_d_f
-- type SparkSQL
-- author xiaoning@12301.cc
-- create time 2021-03-02 15:06:14
-- desc 用户平台其他合作类型金额
-- drop table dwd_company_cooperation_other_d_f
create table if NOT EXISTS dwd_company_cooperation_other_d_f(
    `id` bigint COMMENT '主键id',
    `user_id` bigint COMMENT '申请人ID',
    `cooperat_type` tinyint COMMENT '合作类型：1硬件 2软件 3其他',
    `cooperat_money` bigint COMMENT '合作金额 单位分',
    `cooperat_time` string COMMENT '合作日期',
    `repayment_time` string COMMENT '回款日期',
    `sales_id` bigint COMMENT '签单人id',
    `plat_staff_name` string COMMENT '签单人姓名',
    `plat_staff_department` string COMMENT '签单人部门',
    `remark` string COMMENT '备注',
    `create_time` string COMMENT '添加时间',
    `update_time` string COMMENT '更新时间'
)COMMENT'其他合作(签单人员配置)'PARTITIONED BY(
    pt INT  
 )STORED AS ORC;


INSERT OVERWRITE TABLE dwd_company_cooperation_other_d_f PARTITION (pt="${ds}") 
select  id,
        a.member_id as user_id,
        a.cooperat_type,
        a.cooperat_money,
        from_unixtime(a.cooperat_time,'yyyy-MM-dd hh:mm:ss') as cooperat_time,
        from_unixtime(a.repayment_time,'yyyy-MM-dd hh:mm:ss') as repayment_time,
        sales_id,
        u.plat_staff_name,
        u.plat_staff_department,
        a.remark,
        from_unixtime(a.create_time,'yyyy-MM-dd hh:mm:ss') as create_time,
        from_unixtime(a.update_time,'yyyy-MM-dd hh:mm:ss') as update_time
from ods_pft001_pft_cooperation_other_d_f a
left join (select plat_staff_id,plat_staff_name,plat_staff_department 
from dim_plat_staff_d_f where pt='${ds}') u on u.plat_staff_id=a.sales_id
where a.pt='${ds}' and is_delete=0;



