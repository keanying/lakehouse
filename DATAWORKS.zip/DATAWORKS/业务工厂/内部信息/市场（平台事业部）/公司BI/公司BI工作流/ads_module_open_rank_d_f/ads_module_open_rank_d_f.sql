-- name ads_module_open_rank_d_f
-- type SparkSQL
-- author xiaoning@12301.cc
-- create time 2020-08-17 10:21:43
-- desc 
-- 用户模块开通月排行
-- 过滤下架模块
-- drop table ads_module_open_rank_d_f

CREATE table if not EXISTS ads_module_open_rank_d_f(
    module_id           int COMMENT "模块id",
    module_name         string COMMENT "模块名称",
    module_price             float   COMMENT '模块单价（元）',
    module_pay_amount        float   COMMENT '模块支付金额（元）',
    module_open_type    STRING  comment '开通类型 0自开通 1管理员开通 2管理员关闭',
    user_type           STRING  comment '用户类型',
    begin_month         STRING  COMMENT '开通月份',
    user_num            int     COMMENT '开通用户数'
)COMMENT "商户模块开通情况月排行表" PARTITIONED  BY (
    pt INT   
)STORED AS ORC;



INSERT OVERWRITE TABLE ads_module_open_rank_d_f PARTITION (pt="${ds}")
select
    INT(a.module_id),
    a.module_name,
    a.module_price,
    a.module_pay_amount,
    a.module_open_type,
    b.user_type,
    substr((case when  create_time>update_time then begin_time
    else update_time end),1,7) as begin_month,
    count(distinct a.user_id) as user_num   
from
    dim_user_module_d_f a  
left join
    dim_user_d_f b          
        on a.user_id=b.user_id 
        and b.pt='${ds}'
where
    a.pt='${ds}'          
    -- and a.module_user_status='当前'  
    and module_status=1        
    and a.begin_time>='2020-01-01' 
    -- and b.user_type='供应商'  
group by
    a.module_id,
    a.module_name,
    a.module_price,
    a.module_pay_amount,
    a.module_open_type,
    substr((case when  a.create_time>a.update_time then a.begin_time
    else a.update_time end),1,7),
    b.user_type
order by
    substr((case when  a.create_time>a.update_time then a.begin_time
    else a.update_time end),1,7) asc,
    count(distinct a.user_id) desc;



