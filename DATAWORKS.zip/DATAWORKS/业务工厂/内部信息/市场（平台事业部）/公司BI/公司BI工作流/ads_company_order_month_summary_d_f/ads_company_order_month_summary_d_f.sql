-- name ads_company_order_month_summary_d_f
-- type SparkSQL
-- author xiaoning@12301.cc
-- create time 2020-11-23 17:43:42
-- 按顶级供应商月汇总订单情况

CREATE TABLE IF NOT EXISTS ads_company_order_month_summary_d_f(
    user_id             INT     COMMENT "用户ID",
    user_name           STRING  COMMENT "用户名称",
    booking_month       STRING  COMMENT "月份",
    order_num           INT     COMMENT "订单数",
    ticket_num          INT     COMMENT "票数",
    order_pay_amount    FLOAT   COMMENT "订单金额（元）"
)COMMENT "商户订单情况月汇总" 
PARTITIONED  BY (
    pt INT   
)STORED AS ORC;


INSERT OVERWRITE TABLE ads_company_order_month_summary_d_f PARTITION (pt='${ds}') 
SELECT
    land_publisher_id           AS user_id,
    land_publisher_name         AS user_name,
    SUBSTR(booking_time, 1, 7)  AS booking_month,
    COUNT(DISTINCT order_id)    AS order_num,
    SUM(ticket_num) AS ticket_num,
    ROUND(SUM(order_pay_amount) / 100, 2) AS order_pay_amount 
FROM dwd_order_d_i 
WHERE booking_date > DATE_FORMAT(date_sub(TO_DATE('${ds}', 'yyyyMMdd'), 732), 'yyyyMMdd')
  AND order_pay_status < 2 
GROUP BY
    land_publisher_id,
    land_publisher_name,
    SUBSTR(booking_time, 1, 7);