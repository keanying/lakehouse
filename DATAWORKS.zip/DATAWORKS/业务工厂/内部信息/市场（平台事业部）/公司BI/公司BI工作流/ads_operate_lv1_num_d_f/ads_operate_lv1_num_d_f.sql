-- name ads_operate_lv1_num_d_f
-- type SparkSQL
-- author yemengdan@12301.cc
-- create time 2020-09-27 11:40:29
-- dwd_order_d_f表中下级分销商distributor_id的数量，且这个下级分销商的身份为供应商且有客服

CREATE TABLE IF NOT EXISTS ads_operate_lv1_num_d_f(
    ever_month    STRING COMMENT "月份",
    lv1_num       STRING COMMENT "订单一级供应商数量"
)COMMENT "一级供应商数" 
PARTITIONED  BY (
    pt INT   
)STORED AS ORC;

INSERT OVERWRITE TABLE ads_operate_lv1_num_d_f PARTITION (pt="${ds}")
SELECT 
    `month`                         AS ever_month,
    COUNT(DISTINCT distributor_id)  AS lv1_num
FROM 
(
    SELECT 
        SUBSTR(booking_time,1,7)    AS `month`,
        distributor_id,COUNT(*)     AS num  
    FROM dwd_order_d_i 
    WHERE booking_date > DATE_FORMAT(date_sub(TO_DATE('${ds}', 'yyyyMMdd'), 732), 'yyyyMMdd')
      AND SUBSTR(booking_time, 1, 7) = SUBSTR('${ds}', 1, 7)  
    GROUP BY 
        SUBSTR(booking_time, 1, 7),
        distributor_id
) AS o
JOIN 
(
    SELECT user_id,customer_province 
    FROM dim_user_d_f 
    WHERE pt='${ds}' 
      AND servicer LIKE '%客户成功%' 
      AND user_type='供应商'
) AS u 
ON o.distributor_id=u.user_id
GROUP BY `month`