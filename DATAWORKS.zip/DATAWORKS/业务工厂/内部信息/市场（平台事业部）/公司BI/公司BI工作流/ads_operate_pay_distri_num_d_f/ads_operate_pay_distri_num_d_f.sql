-- name ads_operate_pay_distri_num_d_f
-- type SparkSQL
-- author yemengdan@12301.cc
-- create time 2020-09-27 16:02:27
-- desc 
-- DROP TABLE ads_operate_pay_distri_num_d_f
-- 本年付费分销商个数（模块付费）和套餐付费分销商的开始、结束及最大结束时间

CREATE table if not EXISTS ads_operate_pay_distri_num_d_f(
    s                     STRING COMMENT '类型',
    m_num                 STRING COMMENT '模块数',
    user_id               STRING COMMENT '商家id',
    begin_time            STRING COMMENT '开始时间',
    end_time              STRING COMMENT '结束时间',
    maxdate               STRING COMMENT '最大结束时间'

)COMMENT "本年付费分销商情况" PARTITIONED  BY (
    pt INT   
)STORED AS ORC;

INSERT OVERWRITE TABLE ads_operate_pay_distri_num_d_f PARTITION (pt="${ds}")
SELECT 
       '模块' as s,
       count(DISTINCT m.user_id) as m_num,
       null as user_id,
       null as begin_time,
       null as end_time,
       null as maxdate
FROM (select * from dwd_user_module_d_f where pt='${ds}' and module_status='当前') as m
JOIN (SELECT user_id FROM dwd_user_package_d_f where pt='${ds}' and package_role='分销商' and package_price=0 and package_status='当前') as p on m.user_id=p.user_id

UNION ALL 

SELECT 
       '套餐' as s,
       NULL as m_num,
       p1.user_id   as user_id,
       begin_time,
       end_time,
       maxdate
FROM (
    SELECT user_id,begin_time,end_time
    from dwd_user_package_d_f 
    where pt='${ds}' and package_role='分销商' and package_price>0 and end_time>='2020-01'
    GROUP BY user_id,begin_time,end_time
) as p1
JOIN (
    SELECT user_id,max(end_time) as maxdate
    from dwd_user_package_d_f 
    where pt='${ds}' and package_role='分销商' and package_price>0 and end_time>='2020-01'
    GROUP BY user_id
) as p2 on p1.user_id=p2.user_id