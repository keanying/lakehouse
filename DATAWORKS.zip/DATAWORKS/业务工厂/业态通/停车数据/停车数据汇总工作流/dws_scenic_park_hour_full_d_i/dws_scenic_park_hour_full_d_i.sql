-- name dws_scenic_park_hour_full_d_i
-- type Spark SQL
-- author wanghaiyang@12301.cc
-- create time 2024-12-06 17:51:48
-- desc 停车场全维度按小时汇总

CREATE TABLE IF NOT EXISTS `dws_scenic_park_hour_full_d_i`(
    `hour`          INT     COMMENT'小时时间数',
    `sid`           INT     COMMENT'供应商id',
    `con_sys_bind`  INT     COMMENT'绑定ID',
    `car_no_pre`    STRING  COMMENT'车牌号前缀',
    `in`            INT     COMMENT'入场数',
    `out`           INT     COMMENT'出场数'
 )comment '停车场全维度按小时汇总'
 partitioned by(
    `fulldate`          INT     COMMENT'时间,格式是：Ymd 例如：20240101'
 )stored as orc;


INSERT OVERWRITE TABLE dws_scenic_park_hour_full_d_i PARTITION(`fulldate`)
SELECT 
    `hour`              AS  `hour`, 
    `sid`               AS  `sid`,  
    `con_sys_bind`      AS  `con_sys_bind`, 
    `car_no_pre`        AS  `car_no_pre`, 
    SUM(`in`)           AS  `in`, 
    SUM(`out`)          AS  `out`,
    `fulldate`
FROM (
    SELECT `entry_date` as fulldate, hour(in_time) AS hour, con_sys_bind, member_id AS sid, SUBSTR(car_no, 0, 2) AS car_no_pre, 1 AS `in`, 0 AS `out`
    FROM ods_parking_daoer5_entry_record_d_i 
    WHERE `entry_date`=${ds}
    UNION ALL
    SELECT `entry_date` as fulldate, hour(entry_time) AS hour, con_sys_bind, member_id AS sid, SUBSTR(car_no, 0, 2) AS car_no_pre, 1 AS `in`, 0 AS `out`
    FROM ods_parking_daoer_entry_record_d_i 
    WHERE `entry_date`=${ds}
    UNION ALL
    SELECT `entry_date` as fulldate, hour(cap_time) AS hour, con_sys_bind, member_id AS sid, SUBSTR(plate_no, 0, 2) AS car_no_pre, 1 AS `in`, 0 AS `out`
    FROM ods_parking_ketuo_entry_record_d_i 
    WHERE `entry_date`=${ds}
    UNION ALL
    SELECT `entry_date` as fulldate, hour(enter_time) AS hour, con_sys_bind, member_id AS sid, SUBSTR(car_no, 0, 2) AS car_no_pre, 1 AS `in`, 0 AS `out`
    FROM ods_parking_zhihui_entry_record_d_i 
    WHERE `entry_date`=${ds}
    UNION ALL
    SELECT `entry_date`, hour(enter_time) AS hour, con_sys_bind, member_id AS sid, SUBSTR(plate_num, 0, 2) AS car_no_pre, 1 AS `in`, 0 AS `out`
    FROM ods_parking_shuaichen_entry_record_d_i 
    WHERE `entry_date`=${ds}
    
    UNION ALL

    SELECT `exit_date` as fulldate, hour(out_time) AS hour, con_sys_bind, member_id AS sid, SUBSTR(car_no, 0, 2) AS car_no_pre, 0 AS `in`, 1 AS `out`
    FROM ods_parking_daoer5_exit_record_d_i 
    WHERE `exit_date`=${ds}
    UNION ALL
    SELECT `exit_date` as fulldate, hour(exit_time) AS hour, con_sys_bind, member_id AS sid, SUBSTR(car_no, 0, 2) AS car_no_pre, 0 AS `in`, 1 AS `out`
    FROM ods_parking_daoer_exit_record_d_i 
    WHERE `exit_date`=${ds}
    UNION ALL
    SELECT `exit_date` as fulldate, hour(cap_time) AS hour, con_sys_bind, member_id AS sid, SUBSTR(plate_no, 0, 2) AS car_no_pre, 0 AS `in`, 1 AS `out`
    FROM ods_parking_ketuo_exit_record_d_i 
    WHERE `exit_date`=${ds}
    UNION ALL
    SELECT `exit_date` as fulldate, hour(out_time) AS hour, con_sys_bind, member_id AS sid, SUBSTR(car_no, 0, 2) AS car_no_pre, 0 AS `in`, 1 AS `out`
    FROM ods_parking_zhihui_exit_record_d_i 
    WHERE `exit_date`=${ds}
    UNION ALL
    SELECT `exit_date`, hour(exit_time) AS hour, con_sys_bind, member_id AS sid, SUBSTR(plate_num, 0, 2) AS car_no_pre, 0 AS `in`, 1 AS `out`
    FROM ods_parking_shuaichen_exit_record_d_i 
    WHERE `exit_date`=${ds}
) GROUP BY `fulldate`, hour, con_sys_bind, sid, car_no_pre;