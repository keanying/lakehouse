-- name dws_scenic_park_location_day_d_i
-- type Spark SQL
-- author wanghaiyang@12301.cc
-- create time 2024-12-06 17:51:48
-- desc 车场每日省市出入记录数

CREATE TABLE IF NOT EXISTS `dws_scenic_park_location_day_d_i`(
    `year`          INT     COMMENT'年，例如：2024',
    `month`         INT     COMMENT'年月，例如202401',
    `week`          INT     COMMENT'年周，例如：202401',
    `sid`           INT     COMMENT'供应商id',
    `con_sys_bind`  INT     COMMENT'绑定ID',
    `province`      STRING  COMMENT'省份',
    `city`          STRING  COMMENT'城市',
    `in`            INT     COMMENT'入场数',
    `out`           INT     COMMENT'出场数'
 )comment   '车场每日省市出入记录数'
 partitioned by(
    `fulldate`          INT     COMMENT'时间,格式是：Ymd 例如：20240101'
 )stored as orc 
 ;

INSERT OVERWRITE TABLE dws_scenic_park_location_day_d_i PARTITION(`fulldate`)
SELECT
    YEAR(`date`)                                        AS `year`,
    YEAR(`date`) * 100 + MONTH(`date`)                  AS `month`,
    CAST(isoweek AS INT)                                AS `week`,
    `sid`                                               AS `sid`,
    `con_sys_bind`                                      AS `con_sys_bind`, 
    NVL(`province`,'未知')                              AS `province`,
    NVL(`city`,'未知')                                  AS `city`,
    SUM(`in`)                                           AS `in`,
    SUM(`out`)                                          AS `out`,
    fullTab.`fulldate`
FROM(
    SELECT 
        `sid` ,  
        `con_sys_bind`, 
        `car_no_pre`,  
        `in`, 
        `out`,
        `fulldate`
    FROM dws_scenic_park_hour_full_d_i
    WHERE `fulldate`=${ds}
) fullTab
LEFT JOIN dim_car_location_o_f carLocation
ON fullTab.car_no_pre = carLocation.car_no_pre
LEFT JOIN dim_date_isoweek_o_f dim_isoweek 
ON fullTab.fulldate = dim_isoweek.`fulldate`
GROUP BY 
    fullTab.`fulldate`,
    dim_isoweek.`date`, 
    dim_isoweek.isoweek, 
    fullTab.con_sys_bind, 
    fullTab.sid, 
    province,
    city;