-- name dws_scenic_park_hour_d_i
-- type Spark SQL
-- author wanghaiyang@12301.cc
-- create time 2024-12-06 17:51:48
-- desc 车场小时出入记录表

CREATE TABLE IF NOT EXISTS `dws_scenic_park_hour_d_i`(
    `duration`      INT     COMMENT'小时时间数',
    `sid`           INT     COMMENT'供应商id',
    `con_sys_bind`  INT     COMMENT'绑定ID',
    `in`            INT     COMMENT'入场数',
    `out`           INT     COMMENT'出场数',
    `being`         INT     COMMENT'在园数'
 )comment   '车场小时出入记录表'
 partitioned by(
    `fulldate`          INT     COMMENT'时间,格式是：Ymd 例如：20240101'
 )stored as orc 
;


INSERT OVERWRITE TABLE dws_scenic_park_hour_d_i PARTITION(`fulldate`)
SELECT 
    `hour`              AS  `duration`, 
    `sid`               AS  `sid`,  
    `con_sys_bind`      AS  `con_sys_bind`, 
    SUM(`in`)           AS  `in`, 
    SUM(`out`)          AS  `out`,
    SUM(`in`-`out`)     AS  `being`,
    `fulldate`
FROM dws_scenic_park_hour_full_d_i 
WHERE `fulldate`=${ds}
GROUP BY `fulldate`, hour, con_sys_bind, sid;