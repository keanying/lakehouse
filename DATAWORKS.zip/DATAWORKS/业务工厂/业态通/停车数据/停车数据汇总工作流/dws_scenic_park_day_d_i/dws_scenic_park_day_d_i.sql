-- name dws_scenic_park_day_d_i
-- type Spark SQL
-- author wanghaiyang@12301.cc
-- create time 2024-12-06 17:51:48
-- desc 车场每日出入记录数


CREATE TABLE IF NOT EXISTS `dws_scenic_park_day_d_i`(
    `year`          INT     COMMENT'年，例如：2024',
    `month`         INT     COMMENT'年月，例如202401',
    `week`          INT     COMMENT'年周，例如：202401',
    `sid`           INT     COMMENT'供应商id',
    `con_sys_bind`  INT     COMMENT'绑定ID',
    `in`            INT     COMMENT'入场数',
    `out`           INT     COMMENT'出场数'
 )comment   '车场每日出入记录数'
 partitioned by(
    `fulldate`          INT     COMMENT'时间,格式是：Ymd 例如：20240101'
 )stored as orc 
 ;

INSERT OVERWRITE TABLE dws_scenic_park_day_d_i PARTITION(`fulldate`)
SELECT
    `year`              AS  `year`,
    `month`             AS  `month`,
    `week`              AS  `week`, 
    `sid`               AS  `sid`,
    `con_sys_bind`      AS  `con_sys_bind`,
    SUM(`in`)           AS  `in`,
    SUM(`out`)          AS  `out`,
    `fulldate`
FROM dws_scenic_park_location_day_d_i
WHERE `fulldate`=${ds}
GROUP BY 
    `year`,
    `month`, 
    `week`, 
    `sid`,
    `con_sys_bind`,
    `fulldate`;