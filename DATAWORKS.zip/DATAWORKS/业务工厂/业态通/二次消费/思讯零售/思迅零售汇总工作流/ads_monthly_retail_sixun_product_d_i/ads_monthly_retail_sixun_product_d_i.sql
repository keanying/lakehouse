-- name ads_monthly_retail_sixun_product_d_i
-- type Spark SQL
-- author wanghaiyang@12301.cc
-- create time 2025-03-19 18:05:38
-- desc 思迅每月零售商品销售情况汇总表

CREATE TABLE IF NOT EXISTS `ads_monthly_retail_sixun_product_d_i` (
    `year`              INT         COMMENT '年',
    `sid`               INT         COMMENT '供应商ID',
    `shop_code`         STRING      COMMENT '销售门店号',
    `con_sys_bind`      INT         COMMENT '绑定ID',
    `shop_category`     STRING      COMMENT '店铺分类',
    `product_name`      STRING      COMMENT '销售商品名称',
    `operator`          STRING      COMMENT '操作人员',
    `sale_num`          BIGINT      COMMENT '销售数量',
    `sale_money`        BIGINT      COMMENT '销售金额(分)'
)COMMENT '思迅每月零售商品销售情况汇总表'
partitioned by(
    `month`             INT         COMMENT '年月'
)stored as orc ;


INSERT OVERWRITE TABLE ads_monthly_retail_sixun_product_d_i PARTITION(`month`)
SELECT 
    `year`,
    `sid`,
    `shop_code`,
    `con_sys_bind`,
    `shop_category`,
    `product_name`,
    `operator`,
    SUM(`sale_num`)     AS `sale_num`,
    SUM(`sale_money`)   AS `sale_money`,
    `month`
FROM ads_daily_retail_sixun_product_d_i
WHERE SUBSTR(`fulldate`, 0, 6) = SUBSTR('${ds}', 0, 6)
GROUP BY  
    `year`,
    `month`,
    `sid`,
    `shop_code`,
    `con_sys_bind`,
    `shop_category`,
    `product_name`,
    `operator`
UNION ALL
SELECT 
    1970                                    AS  `year`,
    0                                       AS  `sid`,
    0                                       AS  `shop_code`,
    0                                       AS  `con_sys_bind`,
    0                                       AS  `shop_category`,
    '未知'                                  AS  `product_name`,
    '未知'                                  AS  `operator`,
    0                                       AS  `sale_num`,
    0                                       AS  `sale_money`,
    INT(SUBSTR('${ds}', 0, 6))              AS  `month`;
