-- name ads_daily_retail_sixun_summary_d_i
-- type Spark SQL
-- author wanghaiyang@12301.cc
-- create time 2025-03-19 18:05:38
-- desc 思迅每日零售汇总表

CREATE TABLE IF NOT EXISTS `ads_daily_retail_sixun_summary_d_i` (
    `year`              INT         COMMENT '年',
    `month`             INT         COMMENT '年月',
    `week`              INT         COMMENT '年周',
    `sid`               INT         COMMENT '供应商ID',
    `shop_code`         STRING      COMMENT '销售门店号',
    `con_sys_bind`      INT         COMMENT '绑定ID',
    `shop_category`     STRING      COMMENT '店铺分类',
    `operator`          STRING      COMMENT '操作人员',
    `order_num`         BIGINT      COMMENT '订单数',
    `payment_money`     BIGINT      COMMENT '支付金额(分)',
    `settlement_money`  BIGINT      COMMENT '实收金额(分)',
    `number_of_people`  BIGINT      COMMENT '人数'
)COMMENT '思迅每日零售汇总表'
partitioned by(
    fulldate INT COMMENT'全日期'
)stored as orc ;


INSERT OVERWRITE TABLE ads_daily_retail_sixun_summary_d_i PARTITION(`fulldate`)
SELECT 
    YEAR(dim_isoweek.date)                                          AS `year`,
    YEAR(dim_isoweek.date) * 100 + MONTH(dim_isoweek.date)          AS `month`,
    CAST(isoweek AS INT)                                            AS `week`,
    orderTab.`member_id`                                            AS `sid`,
    orderTab.`shop_code`                                            AS `shop_code`,
    orderTab.`con_sys_bind`                                         AS `con_sys_bind`,
    NVL(shopTab.`shop_category`,'')                                 AS `shop_category`,
    orderTab.`operator`                                             AS `operator`,
    COUNT(DISTINCT(orderTab.`order_no`))                            AS `order_num`,
    SUM(orderTab.`payment_money`)                                   AS `payment_money`,
    SUM(orderTab.`settlement_money`)                                AS `settlement_money`,
    SUM(orderTab.`number_of_people`)                                AS `number_of_people`,
    `orderdate`                                                     AS `fulldate`
FROM (
    SELECT
        `con_sys_bind`,
        `member_id`,
        `shop_code`,
        `status`,
        `order_no`,
        `operator`,
        `payment_money` * 100       AS `payment_money`,
        `settlement_money` * 100    AS `settlement_money`,
        `number_of_people`,
        `orderdate`
    FROM ods_retail_sixun_order_d_i
    WHERE orderdate = '${ds}'
        AND `status` = 'Y'
) orderTab
LEFT JOIN (
    SELECT 
        `con_sys_bind`,
        `shop_category`,
        `shop_code`,
        `member_id`
    FROM ods_retail_sixun_shop_d_f
    WHERE pt = FROM_UNIXTIME(UNIX_TIMESTAMP(DATE_SUB(CURRENT_DATE, 1)), 'yyyyMMdd')
) shopTab 
ON orderTab.`shop_code` = shopTab.`shop_code` 
    AND orderTab.`member_id` = shopTab.`member_id` 
    AND orderTab.`con_sys_bind` = shopTab.`con_sys_bind` 
LEFT JOIN dim_date_isoweek_o_f AS dim_isoweek 
ON orderTab.`orderdate` = dim_isoweek.`fulldate`
GROUP BY 
    orderTab.`member_id`,
    orderTab.`shop_code`,
    orderTab.`con_sys_bind`,
    dim_isoweek.isoweek,
    dim_isoweek.date,
    shopTab.`shop_category`,
    orderTab.`operator`,
    orderTab.`orderdate`
UNION ALL
SELECT 
    1970                                                                        AS  `year`,
    197001                                                                      AS  `month`,
    197001                                                                      AS  `week`,
    0                                                                           AS  `sid`,
    0                                                                           AS  `shop_code`,
    0                                                                           AS  `con_sys_bind`,
    0                                                                           AS  `shop_category`,
    '未知'                                                                      AS  `operator`,
    0                                                                           AS  `order_num`,
    0                                                                           AS  `payment_money`,
    0                                                                           AS  `settlement_money`,
    0                                                                           AS  `number_of_people`,
    CAST('${ds}' AS INT)                                                        AS  `fulldate`;