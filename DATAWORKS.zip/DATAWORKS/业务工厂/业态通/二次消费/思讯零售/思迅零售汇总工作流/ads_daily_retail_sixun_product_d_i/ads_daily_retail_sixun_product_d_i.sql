-- name ads_daily_retail_sixun_product_d_i
-- type Spark SQL
-- author wanghaiyang@12301.cc
-- create time 2025-03-19 18:05:38
-- desc 思迅每日零售商品销售情况汇总表

CREATE TABLE IF NOT EXISTS `ads_daily_retail_sixun_product_d_i` (
    `year`              INT         COMMENT '年',
    `month`             INT         COMMENT '年月',
    `week`              INT         COMMENT '年周',
    `sid`               INT         COMMENT '供应商ID',
    `shop_code`         STRING      COMMENT '销售门店号',
    `con_sys_bind`      INT         COMMENT '绑定ID',
    `shop_category`     STRING      COMMENT '店铺分类',
    `product_name`      STRING      COMMENT '销售商品名称',
    `operator`          STRING      COMMENT '操作人员',
    `sale_num`          BIGINT      COMMENT '销售数量',
    `sale_money`        BIGINT      COMMENT '销售金额(分)'
)COMMENT '思迅每日零售商品销售情况汇总表'
partitioned by(
    fulldate INT COMMENT'全日期'
)stored as orc ;


INSERT OVERWRITE TABLE ads_daily_retail_sixun_product_d_i PARTITION(`fulldate`)
SELECT 
    YEAR(dim_isoweek.date)                                                  AS  `year`,
    YEAR(dim_isoweek.date) * 100 + MONTH(dim_isoweek.date)                  AS  `month`,
    CAST(isoweek AS INT)                                                    AS  `week`,
    orderTab.`member_id`                                                    AS  `sid`,
    orderTab.`shop_code`                                                    AS  `shop_code`,
    orderTab.`con_sys_bind`                                                 AS  `con_sys_bind`,
    NVL(shopTab.`shop_category`,'')                                         AS  `shop_category`,
    productTab.`product_name`                                               AS  `product_name`,
    productTab.`operator`                                                   AS  `operator`,
    SUM(`sale_num`)                                                         AS  `sale_num`,
    SUM(`sale_money`)                                                       AS  `sale_money`,
    `orderdate`                                                             AS  `fulldate`
FROM (
    SELECT
        `con_sys_bind`,
        `member_id`,
        `shop_code`,
        `status`,
        `order_no`,
        `orderdate`
    FROM ods_retail_sixun_order_d_i
    WHERE orderdate = '${ds}'
        AND `status` = 'Y'
) orderTab
JOIN (
    SELECT
        `con_sys_bind`,
        `member_id`,
        `shop_code`,
        `order_no`,
        `operator`,
        `product_name`,
        `sale_num`,
        `sale_money`* 100 AS `sale_money`
    FROM ods_retail_sixun_order_sale_detail_d_i
    WHERE saledate >= regexp_replace(date_sub(to_date(from_unixtime(unix_timestamp('${ds}', 'yyyyMMdd'))),20), '-', '')
) productTab
ON orderTab.`con_sys_bind` = productTab.`con_sys_bind` 
    AND orderTab.`member_id` = productTab.`member_id` 
    AND orderTab.`shop_code` = productTab.`shop_code` 
    AND orderTab.`order_no` = productTab.`order_no`
LEFT JOIN (
    SELECT 
        `con_sys_bind`,
        `shop_category`,
        `shop_code`,
        `member_id`
    FROM ods_retail_sixun_shop_d_f
    WHERE pt = FROM_UNIXTIME(UNIX_TIMESTAMP(DATE_SUB(CURRENT_DATE, 1)), 'yyyyMMdd')
) shopTab 
ON orderTab.`shop_code` = shopTab.`shop_code` 
    AND orderTab.`member_id` = shopTab.`member_id` 
    AND orderTab.`con_sys_bind` = shopTab.`con_sys_bind` 
LEFT JOIN dim_date_isoweek_o_f AS dim_isoweek 
ON orderTab.`orderdate` = dim_isoweek.`fulldate`
GROUP BY 
    dim_isoweek.isoweek,
    dim_isoweek.date,
    orderTab.`member_id`,
    orderTab.`shop_code`,
    orderTab.`con_sys_bind`,
    shopTab.`shop_category`,
    productTab.`operator`,
    productTab.`product_name`,
    orderTab.`orderdate`
UNION ALL
SELECT 
    1970                                                                        AS  `year`,
    197001                                                                      AS  `month`,
    197001                                                                      AS  `week`,
    0                                                                           AS  `sid`,
    0                                                                           AS  `shop_code`,
    0                                                                           AS  `con_sys_bind`,
    0                                                                           AS  `shop_category`,
    '未知'                                                                      AS  `product_name`,
    '未知'                                                                      AS  `operator`,
    0                                                                           AS  `sale_num`,
    0                                                                           AS  `sale_money`,
    CAST('${ds}' AS INT)                                                        AS  `fulldate`;