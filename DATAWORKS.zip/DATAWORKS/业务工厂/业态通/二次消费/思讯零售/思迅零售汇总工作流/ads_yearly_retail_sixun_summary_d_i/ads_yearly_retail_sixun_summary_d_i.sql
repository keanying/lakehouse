-- name ads_yearly_retail_sixun_summary_d_i
-- type Spark SQL
-- author wanghaiyang@12301.cc
-- create time 2025-03-19 18:05:38
-- desc 思迅每年零售汇总表

CREATE TABLE IF NOT EXISTS `ads_yearly_retail_sixun_summary_d_i` (
    `sid`               INT         COMMENT '供应商ID',
    `shop_code`         STRING      COMMENT '销售门店号',
    `con_sys_bind`      INT         COMMENT '绑定ID',
    `shop_category`     STRING      COMMENT '店铺分类',
    `operator`          STRING      COMMENT '操作人员',
    `order_num`         BIGINT      COMMENT '订单数',
    `payment_money`     BIGINT      COMMENT '支付金额(分)',
    `settlement_money`  BIGINT      COMMENT '实收金额(分)',
    `number_of_people`  BIGINT      COMMENT '人数'
)COMMENT '思迅每年零售汇总表'
partitioned by(
    `year`             INT         COMMENT '年'
)stored as orc ;


INSERT OVERWRITE TABLE ads_yearly_retail_sixun_summary_d_i PARTITION(`year`)
SELECT 
    `sid`,
    `shop_code`,
    `con_sys_bind`,
    `shop_category`,
    `operator`,
    SUM(`order_num`)        AS  `order_num`,
    SUM(`payment_money`)    AS  `payment_money`,
    SUM(`settlement_money`) AS  `settlement_money`,
    SUM(`number_of_people`) AS  `number_of_people`,
    `year`
FROM ads_monthly_retail_sixun_summary_d_i
WHERE SUBSTR(`month`, 0, 4) = SUBSTR('${ds}', 0, 4)
GROUP BY 
    `year`,
    `sid`,
    `shop_code`,
    `con_sys_bind`,
    `shop_category`,
    `operator`
UNION ALL
SELECT 
    0                           AS  `sid`,
    0                           AS  `shop_code`,
    0                           AS  `con_sys_bind`,
    0                           AS  `shop_category`,
    '未知'                       AS  `operator`,
    0                           AS  `order_num`,
    0                           AS  `payment_money`,
    0                           AS  `settlement_money`,
    0                           AS  `number_of_people`,
    INT(SUBSTR('${ds}', 0, 4))  AS  `year`;
