-- name ads_daily_retail_yinbao_pay_channel_d_i
-- type Spark SQL
-- author wanghaiyang@12301.cc
-- create time 2026-01-22 18:57:01
-- desc 银豹零售每日支付渠道汇总表

 CREATE TABLE IF NOT EXISTS `ads_daily_retail_yinbao_pay_channel_d_i`(
    `year` int COMMENT'年',
    `month` int COMMENT'年月',
    `week` int COMMENT'年周',
    `sid` int COMMENT'供应商ID',
    `shop_code` string COMMENT'bind_id',
    `con_sys_bind` int COMMENT'绑定ID',
    `shop_category` string COMMENT'店铺分类',
    `payment_name` string COMMENT'支付方式名称',
    `operator` string COMMENT'操作人员',
    `payment_money` bigint COMMENT'支付金额(分)'
 )comment'银豹零售每日支付渠道汇总表'partitioned by(
    fulldate int
 )stored as orc;


INSERT OVERWRITE TABLE ads_daily_retail_yinbao_pay_channel_d_i  PARTITION(`fulldate`)
SELECT 
   YEAR(dim_isoweek.`date`)                                    AS `year`,
   YEAR(dim_isoweek.`date`) * 100 + MONTH(dim_isoweek.`date`)  AS `month`,
   CAST(dim_isoweek.isoweek  AS INT)                           AS `week`,
   countTab.sid                                                AS `sid`,
   countTab.shop_code                                          AS `shop_code`,
   countTab.con_sys_bind                                       AS `con_sys_bind`,
   '无'                                                        AS `shop_category`,
   CASE WHEN get_json_object(single_payment, '$.code') = 'payCode_-201' THEN '抖音团购券(-201)'
        WHEN get_json_object(single_payment, '$.code') = 'payCode_-5000' THEN '美团团购券(-5000)'
        WHEN get_json_object(single_payment, '$.name') IS NULL THEN CONCAT('未知(', SUBSTR(get_json_object(single_payment, '$.code'), LENGTH('payCode_') + 1), ')')
    ELSE CONCAT(get_json_object(single_payment, '$.name'), '(', SUBSTR(get_json_object(single_payment, '$.code'), LENGTH('payCode_') + 1), ')') END
                                                               AS `payment_name`,
   countTab.operator                                           AS `operator`,
   SUM(get_json_object(single_payment, '$.amount'))*100        AS `payment_money`,                            
   INT(fulldate)                                               AS `fulldate`
 FROM(
    SELECT 
        con_sys_bind   AS shop_code, 
        con_sys_bind   AS con_sys_bind, 
        member_id      AS sid, 
        cashier_uid    AS operator,
        explode(
            split(
                regexp_replace(
                    regexp_replace(payments, '^\\[|\\]$', ''),  -- 移除方括号
                    '\\}\\,\\{', 
                    '}\\|\\{'  -- 将},{替换为}|{以便分割
                ), 
                '\\|'  -- 按照|分割
            )
        ) as single_payment,
        orderdate
    FROM ods_retail_yinbao_ticket_d_i
    WHERE orderdate = ${ds}
      AND ticket_type = 'SELL'
) countTab
LEFT JOIN dim_date_isoweek_o_f AS dim_isoweek 
ON `countTab`.`orderdate` = dim_isoweek.`fulldate`
GROUP BY 
    countTab.sid,
    countTab.shop_code,
    countTab.con_sys_bind,
    CASE WHEN get_json_object(single_payment, '$.code') = 'payCode_-201' THEN '抖音团购券(-201)'
        WHEN get_json_object(single_payment, '$.code') = 'payCode_-5000' THEN '美团团购券(-5000)'
        WHEN get_json_object(single_payment, '$.name') IS NULL THEN CONCAT('未知(', SUBSTR(get_json_object(single_payment, '$.code'), LENGTH('payCode_') + 1), ')')
    ELSE CONCAT(get_json_object(single_payment, '$.name'), '(', SUBSTR(get_json_object(single_payment, '$.code'), LENGTH('payCode_') + 1), ')') END,
    countTab.operator,
    dim_isoweek.`date`,
    dim_isoweek.`fulldate`,
    dim_isoweek.`isoweek`
;
