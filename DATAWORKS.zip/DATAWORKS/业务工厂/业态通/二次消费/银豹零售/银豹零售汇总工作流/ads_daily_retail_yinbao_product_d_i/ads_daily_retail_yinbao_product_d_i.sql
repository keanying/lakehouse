-- name ads_daily_retail_yinbao_product_d_i
-- type Spark SQL
-- author wanghaiyang@12301.cc
-- create time 2026-01-22 18:56:13
-- desc 银豹零售每日产品销售汇总表

CREATE TABLE IF NOT EXISTS `ads_daily_retail_yinbao_product_d_i`(
    `year` int COMMENT'年',
    `month` int COMMENT'年月',
    `week` int COMMENT'年周',
    `sid` int COMMENT'供应商ID',
    `shop_code` string COMMENT'销售门店号',
    `con_sys_bind` int COMMENT'绑定ID',
    `shop_category` string COMMENT'店铺分类',
    `product_id` bigint COMMENT'销售商品ID',
    `product_name` string COMMENT'销售商品名称',
    `operator` string COMMENT'操作人员',
    `sale_num` bigint COMMENT'销售数量',
    `sale_money` bigint COMMENT'销售金额(分)',
    `payment_money` bigint COMMENT'支付金额(分)',
    `profit_money` bigint COMMENT'利润金额(分)',
    `cancel_num` bigint COMMENT'取消数量',
    `cancel_sale_money` bigint COMMENT'取消销售金额(分)',
    `cancel_payment_money` bigint COMMENT'取消支付金额(分)',
    `cancel_profit_money` bigint COMMENT'取消利润金额(分)'
 )COMMENT'银豹零售每日产品销售汇总表'partitioned by(
    fulldate int
 )stored as orc;

INSERT OVERWRITE TABLE ads_daily_retail_yinbao_product_d_i PARTITION(`fulldate`)
SELECT 
   YEAR(dim_isoweek.`date`)                                                                                     AS    `year`,
   YEAR(dim_isoweek.`date`) * 100 + MONTH(dim_isoweek.`date`)                                                   AS    `month`,
   CAST(dim_isoweek.isoweek  AS INT)                                                                            AS    `week`,
   sid                                                                                                          AS    `sid`,
   con_sys_bind                                                                                                 AS    `shop_code`,
   con_sys_bind                                                                                                 AS    `con_sys_bind`,
   '无'                                                                                                         AS    `shop_category`,
   product_id                                                                                                   AS    `product_id`,
   product_name                                                                                                 AS    `product_name`,
   cashier_uid                                                                                                  AS    `operator`,
   SUM(IF (ticket_type = 'SELL', quantity, 0))                                                                  AS    `sale_num`,
   SUM(IF (ticket_type = 'SELL', sell_price*quantity*100, 0))                                                   AS    `sale_money`,
   SUM(IF (ticket_type = 'SELL', total_amount*100, 0))                                                          AS    `payment_money`, 
   SUM(IF (ticket_type = 'SELL', total_profit*100, 0))                                                          AS    `profit_money`, 
   SUM(IF ((ticket_type = 'SELL' AND invalid=1) OR ticket_type = 'SELL_RETURN', quantity, 0))                   AS    `cancel_num`,
   SUM(IF ((ticket_type = 'SELL' AND invalid=1) OR ticket_type = 'SELL_RETURN', sell_price*quantity*100, 0))    AS    `cancel_sale_money`,
   SUM(IF ((ticket_type = 'SELL' AND invalid=1) OR ticket_type = 'SELL_RETURN', total_amount*100, 0))           AS    `cancel_payment_money`, 
   SUM(IF ((ticket_type = 'SELL' AND invalid=1) OR ticket_type = 'SELL_RETURN', total_profit*100, 0))           AS    `cancel_profit_money`, 
   INT(dim_isoweek.fulldate)                                                                                    AS    `fulldate`
FROM(
   SELECT 
      itemTab.con_sys_bind,
      itemTab.sid,
      itemTab.product_id,
      itemTab.product_name,
      itemTab.uid,
      itemTab.sell_price,
      itemTab.total_amount,
      itemTab.total_profit,
      itemTab.quantity,
      orderTab.cashier_uid,
      orderTab.ticket_type,
      orderTab.invalid,
      itemTab.orderdate
   FROM (
      SELECT 
         con_sys_bind, 
         member_id      AS sid, 
         product_uid    AS product_id,
         name           AS product_name,
         uid,
         sell_price,
         total_amount,
         total_profit,
         quantity,
         orderdate
      FROM ods_retail_yinbao_ticket_item_d_i
      WHERE orderdate = ${ds}
   ) itemTab
   JOIN (
      SELECT 
         uid,
         con_sys_bind, 
         member_id, 
         cashier_uid,
         ticket_type,
         invalid
      FROM ods_retail_yinbao_ticket_d_i
      WHERE orderdate = ${ds}
      AND NOT (ticket_type = 'SELL_RETURN' AND invalid = 1)
   ) orderTab
   ON itemTab.con_sys_bind = orderTab.con_sys_bind 
    AND itemTab.sid = orderTab.member_id 
    AND itemTab.uid = orderTab.uid  
) countTab
LEFT JOIN dim_date_isoweek_o_f AS dim_isoweek 
ON `countTab`.`orderdate` = dim_isoweek.`fulldate`
GROUP BY 
   con_sys_bind,
   sid,
   product_id,
   product_name,
   cashier_uid,
   dim_isoweek.fulldate,
   dim_isoweek.date,
   dim_isoweek.isoweek
;
