--Serverless Spark SQL
--********************************************************************--
--author: 王海阳
--create time: 2026-03-27 19:32:12
--Serverless Spark SQL任务只能运行在独享资源组上
--********************************************************************--
CREATE TABLE IF NOT EXISTS ods_retail_yinbao_ticket_item_d_i (
  id BIGINT COMMENT '自增ID',
  con_sys_bind INT COMMENT '绑定ID',
  member_id INT COMMENT '供应商ID',
  sync_create_time STRING COMMENT '首次同步时间',
  sync_update_time STRING COMMENT '最后同步时间',
  sn STRING COMMENT '单据序列号',
  uid BIGINT COMMENT '单据唯一标识',
  product_uid BIGINT COMMENT '商品唯一标识',
  name STRING COMMENT '商品名称',
  buy_price DECIMAL(10,2) COMMENT '商品进货价',
  sell_price DECIMAL(10,2) COMMENT '商品销售价',
  customer_price DECIMAL(10,2) COMMENT '商品会员价',
  quantity DECIMAL(10,2) COMMENT '销售数量',
  discount DECIMAL(10,2) COMMENT '折扣比例',
  customer_discount DECIMAL(10,2) COMMENT '会员折扣比例',
  total_amount DECIMAL(10,2) COMMENT '条目总价',
  total_profit DECIMAL(10,2) COMMENT '条目总利润',
  is_customer_discount INT COMMENT '是否会员折扣（1=是）',
  product_barcode STRING COMMENT '商品条码',
  ticket_item_attributes STRING COMMENT '商品属性/备注',
  discount_details STRING COMMENT '折扣明细',
  sale_guider_list STRING COMMENT '导购员列表',
  orderdate INT)
USING orc
PARTITIONED BY (orderdate)
COMMENT '银豹单据商品条目';

REFRESH TABLE s_retail_yinbao_ticket_item_d_i;
REFRESH TABLE ods_retail_yinbao_ticket_d_i;

INSERT OVERWRITE TABLE ods_retail_yinbao_ticket_item_d_i PARTITION(`orderdate`)
SELECT 
    itemTab.id,
    itemTab.con_sys_bind,
    itemTab.member_id,
    itemTab.sync_create_time,
    itemTab.sync_update_time,
    itemTab.sn,
    itemTab.uid,
    itemTab.product_uid,
    itemTab.name,
    itemTab.buy_price,
    itemTab.sell_price,
    itemTab.customer_price,
    itemTab.quantity,
    itemTab.discount,
    itemTab.customer_discount,
    itemTab.total_amount,
    itemTab.total_profit,
    itemTab.is_customer_discount,
    itemTab.product_barcode,
    itemTab.ticket_item_attributes,
    itemTab.discount_details,
    itemTab.sale_guider_list,
    ticketTab.orderdate
FROM s_retail_yinbao_ticket_item_d_i itemTab
JOIN ods_retail_yinbao_ticket_d_i ticketTab
ON itemTab.uid = ticketTab.uid
WHERE ticketTab.orderdate = '${ds}' AND itemTab.pt = '${ds}'

