-- name ads_yearly_retail_yinbao_product_d_i
-- type Spark SQL
-- author wanghaiyang@12301.cc
-- create time 2026-01-22 18:56:13
-- desc 银豹零售每年产品销售汇总表

CREATE TABLE IF NOT EXISTS `ads_yearly_retail_yinbao_product_d_i`(
    `sid` int COMMENT'供应商ID',
    `shop_code` string COMMENT'销售门店号',
    `con_sys_bind` int COMMENT'绑定ID',
    `shop_category` string COMMENT'店铺分类',
    `product_id` bigint COMMENT'销售商品ID',
    `product_name` string COMMENT'销售商品名称',
    `operator` string COMMENT'操作人员',
    `sale_num` bigint COMMENT'销售数量',
    `sale_money` bigint COMMENT'销售金额(分)',
    `payment_money` bigint COMMENT'支付金额(分)',
    `profit_money` bigint COMMENT'利润金额(分)',
    `cancel_num` bigint COMMENT'销售数量',
    `cancel_sale_money` bigint COMMENT'取消销售金额(分)',
    `cancel_payment_money` bigint COMMENT'取消支付金额(分)',
    `cancel_profit_money` bigint COMMENT'取消利润金额(分)'
 )COMMENT'银豹零售每月产品销售汇总表'partitioned by(
    `year` int COMMENT'年'
 )stored as orc;

INSERT OVERWRITE TABLE ads_yearly_retail_yinbao_product_d_i PARTITION(`year`)
SELECT 
    `sid`                           AS   `sid`,
    `shop_code`                     AS   `shop_code`,
    `con_sys_bind`                  AS   `con_sys_bind`,
    `shop_category`                 AS   `shop_category`,
    `product_id`                    AS   `product_id`,
    MAX(`product_name`)             AS   `product_name`,
    `operator`                      AS   `operator`,
    SUM(`sale_num`)                 AS   `sale_num`,
    SUM(`sale_money`)               AS   `sale_money`,
    SUM(`payment_money`)            AS   `payment_money`, 
    SUM(`profit_money`)             AS   `profit_money`, 
    SUM(`cancel_num`)               AS   `cancel_num`,
    SUM(`cancel_sale_money`)        AS   `cancel_sale_money`,
    SUM(`cancel_payment_money`)     AS   `cancel_payment_money`, 
    SUM(`cancel_profit_money`)      AS   `cancel_profit_money`, 
    `year`                          AS   `year`
FROM ads_monthly_retail_yinbao_product_d_i
WHERE SUBSTR(`month`, 0, 4) = SUBSTR('${ds}', 0, 4)
GROUP BY 
    `year`,
    `sid`,
    `shop_code`,
    `con_sys_bind`,
    `shop_category`,
    `product_id`,
    `operator`;