-- name ads_monthly_retail_yinbao_summary_d_i
-- type Spark SQL
-- author wanghaiyang@12301.cc
-- create time 2026-01-22 18:57:01
-- desc 银豹零售每月汇总表

CREATE TABLE IF NOT EXISTS `ads_monthly_retail_yinbao_summary_d_i`(
    `year` int COMMENT'年',
    `sid` int COMMENT'供应商ID',
    `shop_code` string COMMENT'bind_id',
    `con_sys_bind` int COMMENT'绑定ID',
    `shop_category` string COMMENT'店铺分类(默认无,找下有没相关数据)',
    `operator` string COMMENT'操作人员',
    `order_num` bigint COMMENT'订单数',
    `payment_money` bigint COMMENT'支付金额(分)',
    `sale_money` bigint COMMENT'销售金额(分)',
    `profit_money` bigint COMMENT'利润金额(分)',
    `cancel_order_num` bigint COMMENT'取消订单数',
    `cancel_payment_money` bigint COMMENT'取消支付金额(分)',
    `cancel_sale_money` bigint COMMENT'取消销售金额(分)',
    `cancel_profit_money` bigint COMMENT'取消利润金额(分)'
 )comment'银豹零售每月汇总表'partitioned by(
    `month` int COMMENT'年月'
 )stored as orc;


INSERT OVERWRITE TABLE ads_monthly_retail_yinbao_summary_d_i PARTITION(`month`)
SELECT 
    `year`                          AS   `year`,
    `sid`                           AS   `sid`,
    `shop_code`                     AS   `shop_code`,
    `con_sys_bind`                  AS   `con_sys_bind`,
    `shop_category`                 AS   `shop_category`,
    `operator`                      AS   `operator`,
    SUM(`order_num`)                AS   `order_num`,
    SUM(`payment_money`)            AS   `payment_money`,
    SUM(`sale_money`)               AS   `sale_money`,
    SUM(`profit_money`)             AS   `profit_money`,
    SUM(`cancel_order_num`)         AS   `cancel_order_num`,
    SUM(`cancel_payment_money`)     AS   `cancel_payment_money`,
    SUM(`cancel_sale_money`)        AS   `cancel_sale_money`,
    SUM(`cancel_profit_money`)      AS   `cancel_profit_money`,
    `month`                         AS   `month`
FROM ads_daily_retail_yinbao_summary_d_i
WHERE SUBSTR(`fulldate`, 0, 6) = SUBSTR('${ds}', 0, 6)
GROUP BY 
    `year`,
    `month`,
    `sid`,
    `shop_code`,
    `con_sys_bind`,
    `shop_category`,
    `operator`
;