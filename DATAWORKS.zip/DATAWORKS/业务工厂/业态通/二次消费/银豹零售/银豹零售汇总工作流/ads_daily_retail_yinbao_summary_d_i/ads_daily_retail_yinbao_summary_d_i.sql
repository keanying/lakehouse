-- name ads_daily_retail_yinbao_summary_d_i
-- type Spark SQL
-- author wanghaiyang@12301.cc
-- create time 2026-01-22 18:57:01
-- desc 银豹零售每日汇总表

CREATE TABLE IF NOT EXISTS `ads_daily_retail_yinbao_summary_d_i`(
    `year` int COMMENT'年',
    `month` int COMMENT'年月',
    `week` int COMMENT'年周',
    `sid` int COMMENT'供应商ID',
    `shop_code` string COMMENT'bind_id',
    `con_sys_bind` int COMMENT'绑定ID',
    `shop_category` string COMMENT'店铺分类(默认无,找下有没相关数据)',
    `operator` string COMMENT'操作人员',
    `order_num` bigint COMMENT'订单数',
    `payment_money` bigint COMMENT'支付金额(分)',
    `sale_money` bigint COMMENT'销售金额(分)',
    `profit_money` bigint COMMENT'利润金额(分)',
    `cancel_order_num` bigint COMMENT'取消订单数',
    `cancel_payment_money` bigint COMMENT'取消支付金额(分)',
    `cancel_sale_money` bigint COMMENT'取消销售金额(分)',
    `cancel_profit_money` bigint COMMENT'取消利润金额(分)'
 )comment'银豹零售每日汇总表'partitioned by(
    fulldate int
 )stored as orc;


INSERT OVERWRITE TABLE ads_daily_retail_yinbao_summary_d_i PARTITION(`fulldate`)
SELECT 
   YEAR(dim_isoweek.`date`)                                    AS `year`,
   YEAR(dim_isoweek.`date`) * 100 + MONTH(dim_isoweek.`date`)  AS `month`,
   CAST(dim_isoweek.isoweek  AS INT)                           AS `week`,
   countTab.sid                                                AS `sid`,
   countTab.shop_code                                          AS `shop_code`,
   countTab.con_sys_bind                                       AS `con_sys_bind`,
   '无'                                                        AS `shop_category`,
   countTab.operator                                           AS `operator`,
   countTab.order_num                                          AS `order_num`,
   countTab.payment_money                                      AS `payment_money`,
   countTab.sale_money                                         AS `sale_money`,
   countTab.profit_money                                       AS `profit_money`,
   countTab.cancel_order_num                                   AS `cancel_order_num`,
   countTab.cancel_payment_money                               AS `cancel_payment_money`,
   countTab.cancel_sale_money                                  AS `cancel_sale_money`,
   countTab.cancel_profit_money                                AS `cancel_profit_money`,
   INT(fulldate)                                               AS `fulldate`
 FROM(
   SELECT 
      con_sys_bind   AS shop_code, 
      con_sys_bind   AS con_sys_bind, 
      member_id      AS sid, 
      cashier_uid    AS operator,
      sum(if (ticket_type = 'SELL', 1, 0))                                                                              AS  order_num, 
      sum(if (ticket_type = 'SELL', total_amount*100, 0))                                                               AS  payment_money, 
      sum(if (ticket_type = 'SELL', total_amount/discount*100*100, 0))                                                  AS  sale_money, 
      sum(if (ticket_type = 'SELL', total_profit*100, 0))                                                               AS  profit_money,
      sum(if ((ticket_type = 'SELL' AND invalid=1) OR ticket_type = 'SELL_RETURN', 1, 0))                               AS  cancel_order_num, 
      sum(if ((ticket_type = 'SELL' AND invalid=1) OR ticket_type = 'SELL_RETURN', total_amount*100, 0))                AS  cancel_payment_money, 
      sum(if ((ticket_type = 'SELL' AND invalid=1) OR ticket_type = 'SELL_RETURN', total_amount/discount*100*100, 0))   AS  cancel_sale_money, 
      sum(if ((ticket_type = 'SELL' AND invalid=1) OR ticket_type = 'SELL_RETURN', total_profit*100, 0))                AS  cancel_profit_money,
      orderdate
   FROM ods_retail_yinbao_ticket_d_i
   WHERE orderdate = ${ds}
   AND NOT (ticket_type = 'SELL_RETURN' AND invalid = 1)
   GROUP BY orderdate, con_sys_bind, member_id, cashier_uid
) countTab
LEFT JOIN dim_date_isoweek_o_f AS dim_isoweek 
ON `countTab`.`orderdate` = dim_isoweek.`fulldate`
;