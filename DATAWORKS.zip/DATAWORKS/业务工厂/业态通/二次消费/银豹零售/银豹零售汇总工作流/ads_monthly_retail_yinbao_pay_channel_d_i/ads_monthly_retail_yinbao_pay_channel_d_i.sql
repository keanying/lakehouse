 -- name ads_daily_retail_yinbao_pay_channel_d_i
-- type Spark SQL
-- author wanghaiyang@12301.cc
-- create time 2026-01-22 18:57:01
-- desc 银豹零售每月支付渠道汇总表

 CREATE TABLE IF NOT EXISTS `ads_monthly_retail_yinbao_pay_channel_d_i`(
    `year` int COMMENT'年',
    `sid` int COMMENT'供应商ID',
    `shop_code` string COMMENT'bind_id',
    `con_sys_bind` int COMMENT'绑定ID',
    `shop_category` string COMMENT'店铺分类',
    `payment_name` string COMMENT'支付方式名称',
    `operator` string COMMENT'操作人员',
    `payment_money` bigint COMMENT'支付金额(分)'
 )comment'银豹零售每月支付渠道汇总表'partitioned by(
    month int COMMENT'年月'
 )stored as orc;


INSERT OVERWRITE TABLE ads_monthly_retail_yinbao_pay_channel_d_i  PARTITION(`month`)
SELECT 
    `year`                 AS `year`,
    `sid`                  AS `sid`,
    `shop_code`            AS `shop_code`,
    `con_sys_bind`         AS `con_sys_bind`,
    `shop_category`        AS `shop_category`,
    `payment_name`         AS `payment_name`,
    `operator`             AS `operator`,
    SUM(`payment_money`)   AS `payment_money`,                            
    `month`
 FROM ads_daily_retail_yinbao_pay_channel_d_i
 WHERE SUBSTR(`fulldate`, 0, 6) = SUBSTR('${ds}', 0, 6)
 GROUP BY 
    `year`,
    `month`,
    `sid`,
    `shop_code`,
    `con_sys_bind`,
    `shop_category`,
    `payment_name`,
    `operator`;
 

